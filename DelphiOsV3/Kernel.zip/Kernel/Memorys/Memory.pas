unit Memory;

interface

uses
  SysUtils;

const
  SYSTEM_RAM = $0A00000;      // 10MB kernel rezervi
  MEMORY_ADDRESS: PByte = PByte($500000);

  // Header Magic değerleri
  HEAP_MAGIC_USED = $DEADBEEF;
  HEAP_MAGIC_FREE = $CAFEBABE;

  // Footer Magic (buffer overflow tespiti için)
  HEAP_FOOTER_MAGIC = $FEEDFACE;

type
 PtrUInt = LongWord;

type
  PHeapBlock = ^THeapBlock;
  THeapBlock = packed record
    Magic: LongWord;      // $DEADBEEF = aktif, $CAFEBABE = serbest
    UserSize: LongWord;   // Kullanıcının talep ettiği gerçek boyut
    PageCount: LongWord;  // Ayrılan 4K sayfa sayısı
    Next: PHeapBlock;     // Çift yönlü linked list
    Prev: PHeapBlock;
  end;

  PHeapFooter = ^THeapFooter;
  THeapFooter = packed record
    Magic: LongWord;      // $FEEDFACE (taşma tespiti)
  end;

{===========================================================================}
{  PMM - Physical Memory Manager                                            }
{===========================================================================}

function PMM_Init: Boolean;
function PMM_GetTotalMemory: Integer;
function PMM_AllocPages(PageCount: Integer): Pointer;
procedure PMM_FreePages(Addr: Pointer; PageCount: Integer);
function PMM_FindFreePages(PageCount: Integer): Integer;
function PMM_GetFreePageCount: Integer;
function PMM_GetTotalPageCount: Integer;
function PMM_GetUsedPageCount: Integer;

{===========================================================================}
{  HEAP - Header + Footer + Linked List                                     }
{===========================================================================}

function HeapAlloc(Size: LongWord): Pointer;
procedure HeapFree(P: Pointer);
function HeapRealloc(P: Pointer; NewSize: LongWord): Pointer;
function HeapGetUserSize(P: Pointer): LongWord;

{===========================================================================}
{  VALIDATION & DEBUG                                                       }
{===========================================================================}

function Heap_Validate: Boolean;
procedure Heap_Dump;  // Ekrana/Log'a tüm blokları yazar

{===========================================================================}
{  İstatistik                                                               }
{===========================================================================}

function GetTotalMemKB: LongWord;
function GetUsedMemKB: LongWord;
function GetFreeMemKB: LongWord;
function GetTotalMemMB: LongWord;
function GetUsedMemMB: LongWord;
function GetFreeMemMB: LongWord;
function GetMemoryUsagePercent: Integer;


function Heap_GetFirstBlock: PHeapBlock;
function Heap_GetNextBlock(Block: PHeapBlock): PHeapBlock;
function Heap_GetBlockCount: Integer;

{===========================================================================}
{  Geriye Uyumluluk Wrapper'ları                                            }
{===========================================================================}

procedure Memory_Init;
function MemAlloc(Size: Integer): Pointer;
procedure FreeMem(P: Pointer);
procedure GetMem(var P: Pointer; Len: Integer);
function ReallocMem(OldPtr: Pointer; OldSize, NewSize: Integer): Pointer;

implementation

var
  FTotalRAM: Integer;
  FTotalBlocks: Integer;
  FReservedBlocks: Integer;
  FUsedBlocks: Integer;

  // Heap bloklarının çift yönlü linked list başı
  HeapHead: PHeapBlock = nil;
  HeapTail: PHeapBlock = nil;

{---------------------------------------------------------------------------}
{  Yardımcı: Bellek bölgesini bayt ile doldur                               }
{---------------------------------------------------------------------------}
procedure FillByte(var Dest; Count: Integer; Value: Byte);
var
  P: PByte;
begin
  P := @Dest;
  while Count > 0 do
  begin
    P^ := Value;
    Inc(P);
    Dec(Count);
  end;
end;

{---------------------------------------------------------------------------}
{  Yardımcı: Footer pointer'ını hesapla                                     }
{  Footer, kullanıcı verisinin hemen sonuna yazılır.                        }
{  Kullanıcı UserSize'dan fazla yazarsa footer'ı bozar → tespit!           }
{---------------------------------------------------------------------------}
function GetFooterPtr(Header: PHeapBlock): PHeapFooter;
var
  UserPtr: PtrUInt;
begin
  UserPtr := PtrUInt(Header) + SizeOf(THeapBlock);
  Result := PHeapFooter(UserPtr + Header^.UserSize);
end;

function Heap_GetFirstBlock: PHeapBlock;
begin
  Result := HeapHead;
end;

function Heap_GetNextBlock(Block: PHeapBlock): PHeapBlock;
begin
  if Block <> nil then
    Result := Block^.Next
  else
    Result := nil;
end;

function Heap_GetBlockCount: Integer;
var
  Cur: PHeapBlock;
begin
  Result := 0;
  Cur := HeapHead;
  while Cur <> nil do
  begin
    Inc(Result);
    Cur := Cur^.Next;
  end;
end;

{---------------------------------------------------------------------------}
{  Yardımcı: Linked List'e ekle                                             }
{---------------------------------------------------------------------------}
procedure HeapList_Append(Header: PHeapBlock);
begin
  Header^.Next := nil;
  Header^.Prev := HeapTail;

  if HeapTail <> nil then
    HeapTail^.Next := Header;

  HeapTail := Header;

  if HeapHead = nil then
    HeapHead := Header;
end;

{---------------------------------------------------------------------------}
{  Yardımcı: Linked List'ten çıkar                                          }
{---------------------------------------------------------------------------}
procedure HeapList_Remove(Header: PHeapBlock);
begin
  if Header^.Prev <> nil then
    Header^.Prev^.Next := Header^.Next
  else
    HeapHead := Header^.Next;

  if Header^.Next <> nil then
    Header^.Next^.Prev := Header^.Prev
  else
    HeapTail := Header^.Prev;

  Header^.Next := nil;
  Header^.Prev := nil;
end;

{===========================================================================}
{  PMM IMPLEMENTASYONU                                                      }
{===========================================================================}

function PMM_GetTotalMemory: Integer;
var
  TotalMemory: Integer;
begin
  asm
    pushad
    mov   eax, cr0
    and   eax, not($40000000 + $20000000)
    or    eax, $40000000
    mov   cr0, eax
    wbinvd
    xor   edi, edi
    mov   ebx, '1234'
  @repeat:
    add     edi, $100000
    xchg    ebx, dword [edi]
    cmp     dword [edi], '1234'
    xchg    ebx, dword [edi]
    je      @repeat
    and     eax, not($40000000 + $20000000)
    mov   cr0, eax
    mov   TotalMemory, edi
    popad
  end;
  Result := TotalMemory;
end;

function PMM_Init: Boolean;
var
  I: Integer;
  MemoryPtr: PByte;
  TotalMemoryAmount: Integer;
begin
  TotalMemoryAmount := PMM_GetTotalMemory;

  if TotalMemoryAmount <= 0 then
  begin
    Result := False;
    Exit;
  end;

  FTotalRAM := TotalMemoryAmount;
  FTotalBlocks := (FTotalRAM shr 12);

  FReservedBlocks := (SYSTEM_RAM shr 12);
  FUsedBlocks := FReservedBlocks;

  MemoryPtr := MEMORY_ADDRESS;
  for I := 0 to FTotalBlocks - 1 do
  begin
    MemoryPtr^ := 0;
    Inc(MemoryPtr);
  end;

  MemoryPtr := MEMORY_ADDRESS;
  for I := 0 to FReservedBlocks - 1 do
  begin
    MemoryPtr^ := 1;
    Inc(MemoryPtr);
  end;

  Result := True;
end;

function PMM_FindFreePages(PageCount: Integer): Integer;
var
  MemoryPtr: PByte;
  CurrentBlock, Consecutive, StartBlock: Integer;
begin
  Result := -1;
  if (PageCount <= 0) or (FReservedBlocks >= FTotalBlocks) then Exit;

  MemoryPtr := MEMORY_ADDRESS;
  Inc(MemoryPtr, FReservedBlocks);
  CurrentBlock := FReservedBlocks;
  StartBlock := -1;
  Consecutive := 0;

  while CurrentBlock < FTotalBlocks do
  begin
    if MemoryPtr^ = 0 then
    begin
      if Consecutive = 0 then
        StartBlock := CurrentBlock;
      Inc(Consecutive);
      if Consecutive >= PageCount then
      begin
        Result := StartBlock;
        Exit;
      end;
    end
    else
    begin
      Consecutive := 0;
    end;

    Inc(MemoryPtr);
    Inc(CurrentBlock);
  end;
end;

function PMM_AllocPages(PageCount: Integer): Pointer;
var
  FirstBlock, I: Integer;
  MemoryPtr: PByte;
  BaseAddr: PtrUInt;
begin
  Result := nil;
  if PageCount <= 0 then Exit;

  FirstBlock := PMM_FindFreePages(PageCount);
  if FirstBlock = -1 then Exit;

  MemoryPtr := MEMORY_ADDRESS;
  Inc(MemoryPtr, FirstBlock);
  for I := 0 to PageCount - 1 do
  begin
    MemoryPtr^ := 1;
    Inc(MemoryPtr);
  end;

  BaseAddr := PtrUInt(MEMORY_ADDRESS) + PtrUInt(FirstBlock * 4096);
  Result := Pointer(BaseAddr);

  Inc(FUsedBlocks, PageCount);
end;

procedure PMM_FreePages(Addr: Pointer; PageCount: Integer);
var
  FirstBlock, I: Integer;
  MemoryPtr: PByte;
begin
  if (Addr = nil) or (PageCount <= 0) then Exit;
  if PtrUInt(Addr) < PtrUInt(MEMORY_ADDRESS) then Exit;

  FirstBlock := (PtrUInt(Addr) - PtrUInt(MEMORY_ADDRESS)) shr 12;

  if (FirstBlock < 0) or (FirstBlock >= FTotalBlocks) then Exit;

  MemoryPtr := MEMORY_ADDRESS;
  Inc(MemoryPtr, FirstBlock);

  for I := 0 to PageCount - 1 do
  begin
    MemoryPtr^ := 0;
    Inc(MemoryPtr);
  end;

  Dec(FUsedBlocks, PageCount);
end;

function PMM_GetFreePageCount: Integer;
begin
  Result := FTotalBlocks - FUsedBlocks;
end;

function PMM_GetTotalPageCount: Integer;
begin
  Result := FTotalBlocks;
end;

function PMM_GetUsedPageCount: Integer;
begin
  Result := FUsedBlocks;
end;

{===========================================================================}
{  HEAP IMPLEMENTASYONU                                                     }
{===========================================================================}

function HeapAlloc(Size: LongWord): Pointer;
var
  Header: PHeapBlock;
  Footer: PHeapFooter;
  TotalSize, Pages: LongWord;
  BaseAddr: Pointer;
begin
  Result := nil;
  if Size = 0 then Exit;

  // Header + User Data + Footer için toplam boyut
  TotalSize := SizeOf(THeapBlock) + Size + SizeOf(THeapFooter);

  // Gerekli 4K sayfa sayısı (yukarı yuvarla)
  Pages := (TotalSize + 4095) shr 12;
  if Pages = 0 then Pages := 1;

  BaseAddr := PMM_AllocPages(Pages);
  if BaseAddr = nil then Exit;

  Header := PHeapBlock(BaseAddr);
  Header^.Magic := HEAP_MAGIC_USED;
  Header^.UserSize := Size;
  Header^.PageCount := Pages;
  Header^.Next := nil;
  Header^.Prev := nil;

  // Footer'ı kullanıcı verisinin hemen sonuna yaz
  Footer := GetFooterPtr(Header);
  Footer^.Magic := HEAP_FOOTER_MAGIC;

  // Linked list'e ekle
  HeapList_Append(Header);

  // Kullanıcıya header'ın hemen ardındaki adresi ver
  Result := Pointer(PtrUInt(BaseAddr) + SizeOf(THeapBlock));

  // Kullanıcı alanını sıfırla
  FillByte(Result^, Size, 0);
end;

procedure HeapFree(P: Pointer);
var
  Header: PHeapBlock;
  Footer: PHeapFooter;
begin
  if P = nil then Exit;

  Header := PHeapBlock(PtrUInt(P) - SizeOf(THeapBlock));

  // MAGIC kontrolü
  if Header^.Magic <> HEAP_MAGIC_USED then
  begin
    // KernelPanic('HeapFree: Double-free or corruption detected');
    Exit;
  end;

  // Footer kontrolü (taşma var mı?)
  Footer := GetFooterPtr(Header);
  if Footer^.Magic <> HEAP_FOOTER_MAGIC then
  begin
    // KernelPanic('HeapFree: Buffer overflow detected');
    Exit;
  end;

  // Serbest bırakıldığını işaretle
  Header^.Magic := HEAP_MAGIC_FREE;
  Footer^.Magic := $00000000;  // Footer'ı da temizle

  // Linked list'ten çıkar
  HeapList_Remove(Header);

  // PMM'ye iade et
  PMM_FreePages(Header, Header^.PageCount);
end;

function HeapRealloc(P: Pointer; NewSize: LongWord): Pointer;
var
  Header: PHeapBlock;
  OldSize, CopySize: LongWord;
begin
  if P = nil then
  begin
    Result := HeapAlloc(NewSize);
    Exit;
  end;

  if NewSize = 0 then
  begin
    HeapFree(P);
    Result := nil;
    Exit;
  end;

  Header := PHeapBlock(PtrUInt(P) - SizeOf(THeapBlock));

  if Header^.Magic <> HEAP_MAGIC_USED then
  begin
    Result := nil;
    Exit;
  end;

  OldSize := Header^.UserSize;

  Result := HeapAlloc(NewSize);
  if Result = nil then Exit;

  if OldSize < NewSize then
    CopySize := OldSize
  else
    CopySize := NewSize;

  Move(P^, Result^, CopySize);
  HeapFree(P);
end;

function HeapGetUserSize(P: Pointer): LongWord;
var
  Header: PHeapBlock;
begin
  Result := 0;
  if P = nil then Exit;
  Header := PHeapBlock(PtrUInt(P) - SizeOf(THeapBlock));
  if Header^.Magic = HEAP_MAGIC_USED then
    Result := Header^.UserSize;
end;

{===========================================================================}
{  VALIDATION & DEBUG                                                       }
{===========================================================================}

function Heap_Validate: Boolean;
var
  Current: PHeapBlock;
  Footer: PHeapFooter;
  ExpectedAddr: PtrUInt;
  BlockNo: Integer;
  Count: Integer;
begin
  Result := True;
  Count := 0;

  if HeapHead = nil then
  begin
    // Liste boş, bu normal olabilir
    Exit;
  end;

  Current := HeapHead;

  while Current <> nil do
  begin
    Inc(Count);

    // 1. Header Magic kontrolü
    if (Current^.Magic <> HEAP_MAGIC_USED) and 
       (Current^.Magic <> HEAP_MAGIC_FREE) then
    begin
      // KernelPanic('Heap_Validate: Invalid header magic');
      Result := False;
      Exit;
    end;

    // 2. Adres aralığı kontrolü (PMM alanı içinde mi?)
    ExpectedAddr := PtrUInt(MEMORY_ADDRESS);
    if (PtrUInt(Current) < ExpectedAddr) or 
       (PtrUInt(Current) >= ExpectedAddr + PtrUInt(FTotalBlocks * 4096)) then
    begin
      // KernelPanic('Heap_Validate: Block out of range');
      Result := False;
      Exit;
    end;

    // 3. Blok numarası hizalama kontrolü (4K sınırında mı?)
    BlockNo := (PtrUInt(Current) - PtrUInt(MEMORY_ADDRESS)) shr 12;
    if (PtrUInt(Current) - PtrUInt(MEMORY_ADDRESS)) <> PtrUInt(BlockNo * 4096) then
    begin
      // KernelPanic('Heap_Validate: Misaligned block');
      Result := False;
      Exit;
    end;

    // 4. Linked list tutarlılığı (Next/Prev çapraz kontrol)
    if Current^.Prev <> nil then
    begin
      if Current^.Prev^.Next <> Current then
      begin
        // KernelPanic('Heap_Validate: List linkage broken (Prev)');
        Result := False;
        Exit;
      end;
    end
    else
    begin
      if Current <> HeapHead then
      begin
        // KernelPanic('Heap_Validate: Head mismatch');
        Result := False;
        Exit;
      end;
    end;

    if Current^.Next <> nil then
    begin
      if Current^.Next^.Prev <> Current then
      begin
        // KernelPanic('Heap_Validate: List linkage broken (Next)');
        Result := False;
        Exit;
      end;
    end
    else
    begin
      if Current <> HeapTail then
      begin
        // KernelPanic('Heap_Validate: Tail mismatch');
        Result := False;
        Exit;
      end;
    end;

    // 5. Footer kontrolü (sadece aktif bloklar için)
    if Current^.Magic = HEAP_MAGIC_USED then
    begin
      Footer := GetFooterPtr(Current);
      if Footer^.Magic <> HEAP_FOOTER_MAGIC then
      begin
        // KernelPanic('Heap_Validate: Buffer overflow or footer corruption');
        Result := False;
        Exit;
      end;
    end;

    // 6. PageCount tutarlılığı (header + user + footer sığyor mu?)
    if (SizeOf(THeapBlock) + Current^.UserSize + SizeOf(THeapFooter)) > 
       (Current^.PageCount * 4096) then
    begin
      // KernelPanic('Heap_Validate: PageCount too small for data');
      Result := False;
      Exit;
    end;

    Current := Current^.Next;
  end;
end;

procedure Heap_Dump;
var
  Current: PHeapBlock;
  Footer: PHeapFooter;
  Idx: Integer;
begin
  Current := HeapHead;
  Idx := 0;

  // Burada kernel log/eşya mekanizmanıza yazabilirsiniz
  // Örnek: Log('--- HEAP DUMP ---');

  while Current <> nil do
  begin
    Inc(Idx);

    if Current^.Magic = HEAP_MAGIC_USED then
    begin
      Footer := GetFooterPtr(Current);
      // Log(Format('Block #%d: Addr=$%p, Size=%d, Pages=%d, FooterOK=%s',
      //   [Idx, Current, Current^.UserSize, Current^.PageCount,
      //    BoolToStr(Footer^.Magic = HEAP_FOOTER_MAGIC, True)]));
    end
    else if Current^.Magic = HEAP_MAGIC_FREE then
    begin
      // Log(Format('Block #%d: Addr=$%p, STATE=FREED (zombie!)', [Idx, Current]));
    end
    else
    begin
      // Log(Format('Block #%d: Addr=$%p, STATE=CORRUPTED (Magic=$%X)', 
      //   [Idx, Current, Current^.Magic]));
    end;

    Current := Current^.Next;
  end;

  // Log(Format('Total blocks in list: %d', [Idx]));
end;

{===========================================================================}
{  İSTATİSTİK                                                               }
{===========================================================================}

function GetTotalMemKB: LongWord;
begin
  Result := (LongWord(FTotalBlocks) * 4096) div 1024;
end;

function GetUsedMemKB: LongWord;
begin
  Result := (LongWord(FUsedBlocks) * 4096) div 1024;
end;

function GetFreeMemKB: LongWord;
begin
  Result := (LongWord(PMM_GetFreePageCount) * 4096) div 1024;
end;

function GetTotalMemMB: LongWord;
begin
  Result := GetTotalMemKB div 1024;
end;

function GetUsedMemMB: LongWord;
begin
  Result := GetUsedMemKB div 1024;
end;

function GetFreeMemMB: LongWord;
begin
  Result := GetFreeMemKB div 1024;
end;

function GetMemoryUsagePercent: Integer;
begin
  if FTotalBlocks = 0 then
  begin
    Result := 0;
    Exit;
  end;
  Result := (FUsedBlocks * 100) div FTotalBlocks;
end;

{===========================================================================}
{  WRAPPER'LAR                                                              }
{===========================================================================}

procedure Memory_Init;
begin
  PMM_Init;
end;

function MemAlloc(Size: Integer): Pointer;
begin
  Result := HeapAlloc(Size);
end;

procedure FreeMem(P: Pointer);
begin
  HeapFree(P);
end;

procedure GetMem(var P: Pointer; Len: Integer);
begin
  P := HeapAlloc(Len);
end;

function ReallocMem(OldPtr: Pointer; OldSize, NewSize: Integer): Pointer;
begin
  Result := HeapRealloc(OldPtr, NewSize);
end;

end.

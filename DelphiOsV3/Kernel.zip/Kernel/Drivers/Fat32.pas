Unit FAT32;

interface
Uses
   SysUtils,Vesa,Idt,Pit,Ports,Intr32;


const
  MAX_DRIVES       = 8;    
  MAX_OPEN_FILES   = 32;
  MAX_PATH         = 256;
  SECTOR_SIZE      = 512;  // FAT32 sabit
  MAX_SECTOR_SIZE  = 2048; // ISO 9660 / ATAPI
  FAT32_EOC        = $0FFFFFFF;
  FAT32_FREE       = $00000000;
  FAT32_BAD        = $0FFFFFF7;
  INVALID_HANDLE   = -1;
  
  // Dosya sistem tipleri
  FS_NONE          = 0;
  FS_FAT32         = 1;
  FS_ISO9660       = 2;
  
  // File attributes
  ATTR_READ_ONLY   = $01;
  ATTR_HIDDEN      = $02;
  ATTR_SYSTEM      = $04;
  ATTR_VOLUME_ID   = $08;
  ATTR_DIRECTORY   = $10;
  ATTR_ARCHIVE     = $20;
  ATTR_LFN         = $0F;
  
  // File open mode
  FILE_READ        = $01;
  FILE_WRITE       = $02;
  FILE_CREATE      = $04;
  FILE_APPEND      = $08;
  
  // Seek mode
  SEEK_SET         = 0;
  SEEK_CUR         = 1;
  SEEK_END         = 2;
  
  // ATA ports (Primary)
  ATA_DATA         = $01F0;
  ATA_ERROR        = $01F1;
  ATA_SECTOR_COUNT = $01F2;
  ATA_LBA_LOW      = $01F3;
  ATA_LBA_MID      = $01F4;
  ATA_LBA_HIGH     = $01F5;
  ATA_DRIVE_HEAD   = $01F6;
  ATA_STATUS       = $01F7;
  ATA_COMMAND      = $01F7;
  
  // ATA commands
  ATA_CMD_READ     = $20;
  ATA_CMD_WRITE    = $30;
  ATA_CMD_IDENTIFY = $EC;
  ATA_CMD_PACKET   = $A0;  // ATAPI
  ATA_CMD_IDENTIFY_PACKET = $A1; // ATAPI
  
  // ATA status bits
  ATA_SR_BSY       = $80;
  ATA_SR_DRDY      = $40;
  ATA_SR_DRQ       = $08;
  ATA_SR_ERR       = $01;
  
  // Secondary ATA ports
  ATA_DATA2        = $0170;
  ATA_STATUS2      = $0177;
  ATA_DRIVE_HEAD2  = $0176;
  
  // SCSI / ATAPI
  SCSI_READ10      = $28;
  SCSI_READ_CAPACITY = $25;



type
  // BPB - BIOS Parameter Block (FAT32)
  PBPB = ^TBPB;
  TBPB = packed record
    jmpBoot:       array[0..2] of Byte;
    OEMName:       array[0..7] of Char;
    BytesPerSec:   Word;
    SecPerClus:    Byte;
    RsvdSecCnt:    Word;
    NumFATs:       Byte;
    RootEntCnt:    Word;
    TotSec16:      Word;
    Media:         Byte;
    FATSz16:       Word;
    SecPerTrk:     Word;
    NumHeads:      Word;
    HiddSec:       LongWord;
    TotSec32:      LongWord;
    FATSz32:       LongWord;
    ExtFlags:      Word;
    FSVer:         Word;
    RootClus:      LongWord;
    FSInfo:        Word;
    BkBootSec:     Word;
    Reserved:      array[0..11] of Byte;
    DrvNum:        Byte;
    Reserved1:     Byte;
    BootSig:       Byte;
    VolID:         LongWord;
    VolLab:        array[0..10] of Char;
    FilSysType:    array[0..7] of Char;
  end;
  
  // Directory entry (32 bytes)
  PDirEntry = ^TDirEntry;
  TDirEntry = packed record
    Name:       array[0..10] of Char;
    Attr:       Byte;
    NTRes:      Byte;
    CrtTimeTenth: Byte;
    CrtTime:    Word;
    CrtDate:    Word;
    LstAccDate: Word;
    FstClusHI:  Word;
    WrtTime:    Word;
    WrtDate:    Word;
    FstClusLO:  Word;
    FileSize:   LongWord;
  end;
  
  // LFN entry
  PLFNEntry = ^TLFNEntry;
  TLFNEntry = packed record
    Order:      Byte;
    Name1:      array[0..9] of Byte;
    Attr:       Byte;
    LFNType:    Byte;
    Checksum:   Byte;
    Name2:      array[0..11] of Byte;
    FstClusLO:  Word;
    Name3:      array[0..3] of Byte;
  end;
  
  // =========================================================
  // DRIVE INFO - Hem FAT32 hem ISO 9660
  // =========================================================
  PDriveInfo = ^TDriveInfo;
  TDriveInfo = record
    Present:      Boolean;
    ATAPort:      Word;
    DriveNum:     Byte;
    SectorCount:  LongWord;
    Letter:       Char;
    
    FileSystem:   Byte;  // FS_NONE / FS_FAT32 / FS_ISO9660
    
    // --- FAT32 ---
    IsFAT32:      Boolean;
    BPB:          TBPB;
    FATStart:     LongWord;
    DataStart:    LongWord;
    RootClus:     LongWord;
    SecPerClus:   Byte;
    BytesPerClus: LongWord;
    
    // --- ISO 9660 ---
    ISOSectorSize: Word;      // Genelde 2048
    ISORootLBA:    LongWord;
    ISORootSize:   LongWord;
    ISOModel:      array[0..40] of Char;
  end;
  
  // =========================================================
  // FILE HANDLE - Ortak (Buffer 2048'e cikarildi)
  // =========================================================
  PFileHandle = ^TFileHandle;
  TFileHandle = record
    Used:       Boolean;
    DriveIndex: Integer;
    Mode:       Byte;
    FileSize:   LongWord;
    FilePos:    LongWord;
    SectorSize: Word;                    // 512 (FAT32) veya 2048 (ISO)
    Buffer:     array[0..MAX_SECTOR_SIZE-1] of Byte;
    BufferDirty: Boolean;
    
    // FAT32
    StartCluster: LongWord;
    CurrentCluster: LongWord;
    CurrentSector: LongWord;
    SectorOffset: LongWord;
    DirSector:  LongWord;
    DirOffset:  Integer;
    
    // ISO 9660
    ISOLBA:     LongWord;   // Dosyanin baslangic LBA
    ISOFlags:   Byte;
    
    Name:       array[0..MAX_PATH-1] of Char;
  end;
  
  // =========================================================
  // FIND HANDLE - Ortak
  // =========================================================
  PFindHandle = ^TFindHandle;
  TFindHandle = record
    Used:       Boolean;
    DriveIndex: Integer;
    SearchPath: array[0..MAX_PATH-1] of Char;
    SearchAttr: Byte;
    
    // FAT32
    DirCluster: LongWord;
    DirSector:  LongWord;
    DirIndex:   Integer;
    
    // ISO 9660
    ISODirLBA:    LongWord;
    ISODirSize:   LongWord;
    ISOCurrentLBA: LongWord;
    ISOOffset:    LongWord;   // Directory icindeki byte offset
    ISOSectorBuf: array[0..MAX_SECTOR_SIZE-1] of Byte;
  end;
  
  // Find data
  PSearchRec = ^TSearchRec;
  TSearchRec = record
    Name:       array[0..MAX_PATH-1] of Char;
    ShortName:  array[0..12] of Char;
    Attr:       Byte;
    FileSize:   LongWord;
    StartCluster: LongWord;
    IsDir:      Boolean;
    ImageFile:  PChar;
  end;

  // Disk Kapasite
  PDriveSpaceInfo = ^TDriveSpaceInfo;
  TDriveSpaceInfo = record
    DriveLetter   : Char;
    IsFAT32       : Boolean;
    TotalClusters : LongWord;
    FreeClusters  : LongWord;
    UsedClusters  : LongWord;
    BytesPerClus  : LongWord;
    TotalKB       : LongWord;
    FreeKB        : LongWord;
    UsedKB        : LongWord;
    TotalMB       : LongWord;
    FreeMB        : LongWord;
    UsedMB        : LongWord;
  end;

// --- Fonksiyonlar ---
function FAT32_GetDriveSpace(DriveIndex: Integer; var Info: TDriveSpaceInfo): Boolean;

var
  Drives:      array[0..MAX_DRIVES-1] of TDriveInfo;
  DriveCount:  Integer;
  OpenFiles:   array[0..MAX_OPEN_FILES-1] of TFileHandle;
  SectorBuf:   array[0..MAX_SECTOR_SIZE-1] of Byte;  // 2048'e cikarildi

// Init & Scan
procedure FAT32_Init;
procedure FAT32_ScanDrives;

// File operations (Ortak - otomatik FS secimi yapar)
function OpenFile(Path: PChar; Mode: Byte): Integer;
function ReadFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
function WriteFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
procedure CloseFile(Handle: Integer); overload;
function SeekFile(Handle: Integer; Offset: LongInt; Origin: Byte): LongWord;
function FilePos(Handle: Integer): LongWord;
function FileSize(Handle: Integer): LongWord;

function FAT32_GetDriveFromPath(Path: PChar): Integer;
function FAT32_ExtensionMatch(Name: PChar; Pattern: PChar): Boolean;
function FAT32_ResolvePath(DriveIndex: Integer; Path: PChar; Entry: PDirEntry): Boolean;

// Directory operations
function MakeDir(Path: PChar): Boolean;
function DeleteFile(Path: PChar): Boolean;
function FileExists(Path: PChar): Boolean;
function DirectoryExists(Path: PChar): Boolean;
function FindFirst(Path, Pattern: PChar; Attr: Byte; SearchRec: PSearchRec): Integer;
function FindNext(FindHandle: Integer; SearchRec: PSearchRec): Boolean;
procedure FindClose(FindHandle: Integer);

procedure MountDrive(DriveIndex: Integer);

function ATA_ReadSector(Port: Word; DriveNum: Byte; LBA: LongWord; Buffer: Pointer): Boolean;
function ATA_WriteSector(Port: Word; DriveNum: Byte; LBA: LongWord; Buffer: Pointer): Boolean;

implementation

Uses Messages;

//=============================================================================
// String Helpers
//=============================================================================

function StrCmpN(s1, s2: PChar; n: Integer): Boolean;
var i: Integer;
begin
  Result := False; i := 0;
  while i < n do
  begin
    if s1[i] <> s2[i] then Exit;
    if s1[i] = #0 then Break;
    Inc(i);
  end;
  Result := True;
end;

function StrLen(s: PChar): Integer;
begin
  Result := 0;
  while s[Result] <> #0 do Inc(Result);
end;

function StrCopy(dest, src: PChar): PChar;
var i: Integer;
begin
  i := 0;
  while src[i] <> #0 do begin dest[i] := src[i]; Inc(i); end;
  dest[i] := #0;
  Result := dest;
end;

function ToUpper(c: Char): Char;
begin
  if (c >= 'a') and (c <= 'z') then Result := Char(Ord(c) - 32) else Result := c;
end;

function StrUpChar(c: Char): Char;
begin
  Result := ToUpper(c);
end;

function StrCmp(s1, s2: PChar): Integer;
var i: Integer;
begin
  i := 0;
  while (s1[i] <> #0) and (s2[i] <> #0) and (s1[i] = s2[i]) do Inc(i);
  Result := Ord(s1[i]) - Ord(s2[i]);
end;

procedure MemSet(p: Pointer; value: Integer; size: LongWord);
var i: LongWord; b: PByte;
begin
  b := PByte(p);
  for i := 0 to size-1 do begin b^ := Byte(value); Inc(b); end;
end;

procedure MemCopy(dest, src: Pointer; size: LongWord);
var i: LongWord; d, s: PByte;
begin
  d := PByte(dest); s := PByte(src);
  for i := 0 to size-1 do begin d^ := s^; Inc(d); Inc(s); end;
end;

function IntToPChar(Value: LongWord; Buf: PChar): PChar;
var temp: array[0..15] of Char; i, j: Integer;
begin
  if Value = 0 then begin Buf[0] := '0'; Buf[1] := #0; Result := Buf; Exit; end;
  i := 0;
  while Value > 0 do
  begin
    temp[i] := Char(Ord('0') + (Value mod 10));
    Value := Value div 10;
    Inc(i);
  end;
  for j := 0 to i-1 do Buf[j] := temp[i-1-j];
  Buf[i] := #0;
  Result := Buf;
end;

//=============================================================================
// Port I/O
//=============================================================================

function InByte(Port: Word): Byte;
begin asm mov dx, Port; in al, dx; mov Result, al; end; end;

procedure OutByte(Port: Word; Value: Byte);
begin asm mov dx, Port; mov al, Value; out dx, al; end; end;

function InWord(Port: Word): Word;
begin asm mov dx, Port; in ax, dx; mov Result, ax; end; end;

procedure OutWord(Port: Word; Value: Word);
begin asm mov dx, Port; mov ax, Value; out dx, ax; end; end;

//=============================================================================
// ATA (HDD) Driver
//=============================================================================

procedure ATA_Delay(Port: Word);
var i: Integer;
begin for i := 0 to 3 do InByte(Port + 7); end;

function ATA_WaitBSY(Port: Word): Boolean;
var timeout: Integer; status: Byte;
begin
  Result := False; timeout := 100000;
  while timeout > 0 do
  begin
    status := InByte(Port + 7);
    if (status and ATA_SR_BSY) = 0 then begin Result := True; Exit; end;
    Dec(timeout);
  end;
end;

function ATA_WaitDRQ(Port: Word): Boolean;
var timeout: Integer; status: Byte;
begin
  Result := False; timeout := 100000;
  while timeout > 0 do
  begin
    status := InByte(Port + 7);
    if (status and ATA_SR_ERR) <> 0 then Exit;
    if (status and ATA_SR_DRQ) <> 0 then begin Result := True; Exit; end;
    Dec(timeout);
  end;
end;

function ATA_ReadSector(Port: Word; DriveNum: Byte; LBA: LongWord; Buffer: Pointer): Boolean;
var i: Integer; P: PWord;
begin
  Result := False;
  if not ATA_WaitBSY(Port) then Exit;
  OutByte(Port + 6, $E0 or (DriveNum shl 4) or Byte((LBA shr 24) and $0F));
  OutByte(Port + 1, 0);
  OutByte(Port + 2, 1);
  OutByte(Port + 3, Byte(LBA));
  OutByte(Port + 4, Byte(LBA shr 8));
  OutByte(Port + 5, Byte(LBA shr 16));
  OutByte(Port + 7, ATA_CMD_READ);
  ATA_Delay(Port);
  if not ATA_WaitDRQ(Port) then Exit;
  P := PWord(Buffer);
  for i := 0 to 255 do begin P^ := InWord(Port); Inc(P); end;
  Result := True;
end;

function ATA_WriteSector(Port: Word; DriveNum: Byte; LBA: LongWord; Buffer: Pointer): Boolean;
var i: Integer; P: PWord;
begin
  Result := False;
  if not ATA_WaitBSY(Port) then Exit;
  OutByte(Port + 6, $E0 or (DriveNum shl 4) or Byte((LBA shr 24) and $0F));
  OutByte(Port + 1, 0);
  OutByte(Port + 2, 1);
  OutByte(Port + 3, Byte(LBA));
  OutByte(Port + 4, Byte(LBA shr 8));
  OutByte(Port + 5, Byte(LBA shr 16));
  OutByte(Port + 7, ATA_CMD_WRITE);
  ATA_Delay(Port);
  if not ATA_WaitDRQ(Port) then Exit;
  P := PWord(Buffer);
  for i := 0 to 255 do begin OutWord(Port, P^); Inc(P); end;
  Result := True;
end;

function ATA_Identify(Port: Word; DriveNum: Byte; SectorCount: PLongWord): Boolean;
var IdentBuf: array[0..255] of Word; i: Integer; status: Byte;
begin
  Result := False;
  OutByte(Port + 6, $A0 or (DriveNum shl 4));
  ATA_Delay(Port);
  status := InByte(Port + 7);
  if status = 0 then Exit;
  OutByte(Port + 2, 0); OutByte(Port + 3, 0); OutByte(Port + 4, 0); OutByte(Port + 5, 0);
  OutByte(Port + 7, ATA_CMD_IDENTIFY);
  ATA_Delay(Port);
  status := InByte(Port + 7);
  if status = 0 then Exit;
  if not ATA_WaitBSY(Port) then Exit;
  if (InByte(Port + 4) <> 0) or (InByte(Port + 5) <> 0) then Exit;
  if not ATA_WaitDRQ(Port) then Exit;
  for i := 0 to 255 do IdentBuf[i] := InWord(Port);
  SectorCount^ := LongWord(IdentBuf[60]) or (LongWord(IdentBuf[61]) shl 16);
  Result := (SectorCount^ > 0);
end;

//=============================================================================
// ATAPI (CD-ROM) Low Level
//=============================================================================

function ATAPI_WaitBSY(Port: Word): Boolean;
var timeout: Integer; status: Byte;
begin
  Result := False; timeout := 100000;
  while timeout > 0 do
  begin
    status := InByte(Port + 7);
    if (status and ATA_SR_BSY) = 0 then begin Result := True; Exit; end;
    Dec(timeout);
  end;
end;

function ATAPI_WaitDRQ(Port: Word): Boolean;
var timeout: Integer; status: Byte;
begin
  Result := False; timeout := 100000;
  while timeout > 0 do
  begin
    status := InByte(Port + 7);
    if (status and ATA_SR_ERR) <> 0 then Exit;
    if (status and ATA_SR_DRQ) <> 0 then begin Result := True; Exit; end;
    Dec(timeout);
  end;
end;

function ATAPI_SendPacket(Port: Word; DriveNum: Byte; var CDB; BufSize: Word;
                          Buffer: Pointer; Direction: Byte): Boolean;
{
  Direction: 0=None, 1=Out, 2=In

  ATAPI PIO data transferi burada ger�ek byte-count ile yap�l�r.
  Baz� ATAPI cihazlar� 2048 byte'l�k READ(10) verisini tek DRQ faz�nda,
  baz�lar� ise birden fazla DRQ faz�nda g�nderebilir. Bu nedenle LBA_MID /
  LBA_HIGH registerlar�ndaki ger�ek transfer miktar�n� her fazda okuyoruz.
}
var
  devSelect: Byte;
  i: Integer;
  P: PByte;
  status: Byte;
  phaseBytes: Word;
  phaseWords: Word;
  transferred: LongWord;
  wanted: LongWord;
  timeout: LongWord;
  phaseWord: Word;
begin
  Result := False;
  wanted := BufSize;
  transferred := 0;

  if not ATAPI_WaitBSY(Port) then Exit;

  devSelect := $A0 or (DriveNum shl 4);
  OutByte(Port + 6, devSelect);
  ATA_Delay(Port);

  { ATAPI PACKET command: PIO, interrupt reason normal }
  OutByte(Port + 1, 0);                 // Features
  OutByte(Port + 2, 0);                 // Sector Count / tag
  OutByte(Port + 3, Byte(BufSize));     // Byte count low
  OutByte(Port + 4, Byte(BufSize shr 8)); // Byte count high
  OutByte(Port + 5, 0);
  OutByte(Port + 7, ATA_CMD_PACKET);

  { Device must request the 12-byte packet with DRQ. }
  if not ATAPI_WaitDRQ(Port) then Exit;

  { Send 12-byte CDB as six 16-bit words. }
  P := PByte(@CDB);
  for i := 0 to 5 do
  begin
    OutWord(Port, PWord(P)^);
    Inc(P, 2);
  end;

  if Direction = 0 then
  begin
    if not ATAPI_WaitBSY(Port) then Exit;
    status := InByte(Port + 7);
    Result := (status and ATA_SR_ERR) = 0;
    Exit;
  end;

  if Buffer = nil then Exit;

  P := PByte(Buffer);

  { Read all ATAPI data phases. }
  while transferred < wanted do
  begin
    timeout := 100000;

    { Wait until BSY clears or an error appears. }
    repeat
      status := InByte(Port + 7);
      if (status and ATA_SR_ERR) <> 0 then Exit;
      if (status and ATA_SR_BSY) = 0 then Break;
      Dec(timeout);
    until timeout = 0;

    if timeout = 0 then Exit;

    { No DRQ yet: wait for the next data phase. }
    if (status and ATA_SR_DRQ) = 0 then
    begin
      timeout := 100000;
      repeat
        status := InByte(Port + 7);
        if (status and ATA_SR_ERR) <> 0 then Exit;
        if (status and ATA_SR_DRQ) <> 0 then Break;
        if (status and ATA_SR_BSY) <> 0 then
        begin
          Dec(timeout);
          Continue;
        end;
        Dec(timeout);
      until timeout = 0;

      if timeout = 0 then Exit;
      if (status and ATA_SR_ERR) <> 0 then Exit;
    end;

    { ATAPI reports the exact byte count for this data phase in
      LBA_MID/LBA_HIGH (ports +4/+5). }
    phaseBytes := Word(InByte(Port + 4)) or
                  (Word(InByte(Port + 5)) shl 8);

    if phaseBytes = 0 then Exit;

    { Do not write beyond the caller's requested buffer. }
    if LongWord(phaseBytes) > (wanted - transferred) then
      phaseBytes := Word(wanted - transferred);

    phaseWords := (phaseBytes + 1) div 2;

    if Direction = 2 then
    begin
      for i := 0 to phaseWords - 1 do
      begin
        { ATA data register is a 16-bit PIO register. Always consume one
          complete word, even when the requested phase has an odd byte count. }
        phaseWord := InWord(Port);

        if transferred < wanted then
        begin
          P^ := Byte(phaseWord and $FF);
          Inc(P);
          Inc(transferred);
        end;

        if (2 * LongWord(i) + 1 < phaseBytes) and
           (transferred < wanted) then
        begin
          P^ := Byte(phaseWord shr 8);
          Inc(P);
          Inc(transferred);
        end;
      end;
    end
    else if Direction = 1 then
    begin
      { Currently unused by ISO 9660. Keep PIO OUT support. }
      for i := 0 to phaseWords - 1 do
      begin
        if transferred < wanted then
        begin
          if (transferred + 1 < wanted) and
             (2 * LongWord(i) + 1 < phaseBytes) then
            OutWord(Port, PWord(P)^)
          else
            OutWord(Port, Word(P^));
        end;
        Inc(P, 2);
        Inc(transferred, 2);
        if transferred > wanted then transferred := wanted;
      end;
    end;
  end;

  { Wait for final command completion. }
  if not ATAPI_WaitBSY(Port) then Exit;
  status := InByte(Port + 7);
  if (status and ATA_SR_ERR) <> 0 then Exit;
  if (status and ATA_SR_DRQ) <> 0 then Exit;

  Result := transferred = wanted;
end;



  //===========================================================================
  // ATAPI Read Sector (2048 bytes)
  //===========================================================================
function ATAPI_ReadSector(CDIndex: Integer; LBA: LongWord;
  Buffer: Pointer): Boolean;
var
  cd: PDriveInfo;
  CDB: array[0..11] of Byte;
begin
  Result := False;

  if (CDIndex < 0) or (CDIndex >= MAX_DRIVES) then
    Exit;

  cd := @Drives[CDIndex];

  if not cd^.Present then
    Exit;

  FillChar(CDB, SizeOf(CDB), 0);

  { SCSI READ(10) }
  CDB[0] := SCSI_READ10;

  { 32-bit LBA, big endian }
  CDB[2] := Byte((LBA shr 24) and $FF);
  CDB[3] := Byte((LBA shr 16) and $FF);
  CDB[4] := Byte((LBA shr 8) and $FF);
  CDB[5] := Byte(LBA and $FF);

  { Transfer Length = 1 sector }
  CDB[7] := 0;
  CDB[8] := 1;

  { CD-ROM sector = 2048 bytes }
  Result := ATAPI_SendPacket(
    cd^.ATAPort,
    cd^.DriveNum,
    CDB,
    2048,
    Buffer,
    2
  );
end;
  //===========================================================================
  // ISO 9660 Helper Types & Functions
  //===========================================================================
  type
    PISODirRec = ^TISODirRec;
    TISODirRec = packed record
      Len: Byte;
      ExtAttrLen: Byte;
      ExtentLBA: LongWord;   // LE @ offset 2
      ExtentLBA_BE: LongWord;// BE @ offset 6
      DataLen: LongWord;     // LE @ offset 10
      DataLen_BE: LongWord;  // BE @ offset 14
      Date: array[0..6] of Byte;
      Flags: Byte;           // bit 1 = Directory
      FileUnitSize: Byte;
      Interleave: Byte;
      VolSeqNum: Word;
      VolSeqNum_BE: Word;
      FileIdLen: Byte;
      // FileId[FileIdLen] follows, then padding
    end;

  // Parse ISO 9660 filename: "FILENAME.TXT;1" -> "FILENAME.TXT"
procedure ISO_ParseName(Rec: PISODirRec; Buf: PChar);
var
  src: PChar;
  i, len: Integer;
  c: Char;
begin
  src := PChar(PtrUInt(Rec) + 33);  // FileId balangc
  len := Rec^.FileIdLen;
  
  i := 0;
  while (i < len) and (i < MAX_PATH - 1) do
  begin
    c := src[i];
    
    // Srm suffix'ini atla (;1)
    if c = ';' then Break;
    
    // Byk harfe dntr
    if (c >= 'a') and (c <= 'z') then
      Buf[i] := Char(Ord(c) - 32)
    else
      Buf[i] := c;
    
    Inc(i);
  end;
  
  // Son boluklar atla
  while (i > 0) and (Buf[i-1] = ' ') do Dec(i);
  
  Buf[i] := #0;
end;

function ISO_IsDir(Rec: PISODirRec): Boolean;
begin
  Result := (Rec^.Flags and $02) <> 0;
end;

function ISO_NextDirRec(SectorBuf: Pointer; SectorSize: Word; var Offset: LongWord): PISODirRec;
var
  rec: PISODirRec;
  sectorOffset: LongWord;
begin
  Result := nil;
  
  // Sektr iindeki offset'i hesapla
  sectorOffset := Offset mod SectorSize;
  
  rec := PISODirRec(PtrUInt(SectorBuf) + sectorOffset);
  if rec^.Len = 0 then
  begin
    // Padding (boluk) ile karlatk, bir sonraki sektr bana atla
    Offset := ((Offset div SectorSize) + 1) * SectorSize;
    Exit;  // nil dndr, dardaki loop yeni sektr okusun
  end;
  Result := rec;
end;

  //===========================================================================
  // ISO 9660 Mount
  //===========================================================================

//===========================================================================
// ISO_Mount  D?ZELTME: FileSystem'i hemen set et
//===========================================================================
function ISO_Mount(DriveIndex: Integer): Boolean;
var
  drv: PDriveInfo;
  rootRec: PISODirRec;
begin
    Result := False;
    drv := @Drives[DriveIndex];
    
    // HEN?z FS_NONE olarak ayarland?, ISO_Mount ba??nda FS_ISO9660 olarak i?aretle
    // (b?ylece ATAPI_ReadCapacity ?al??abilir)
    drv^.FileSystem := FS_ISO9660;  // <-- BU ?NEML?!
    drv^.IsFAT32 := False;
    drv^.ISOSectorSize := 0;
    drv^.ISORootLBA := 0;
    drv^.ISORootSize := 0;

    // Read LBA 16 (Primary Volume Descriptor)
    if not ATAPI_ReadSector(DriveIndex, 16, @SectorBuf[0]) then
    begin
      drv^.FileSystem := FS_NONE;  // Ba?ar?s?z, geri al
      Exit;
    end;

    // Check ISO 9660 signature
    if (SectorBuf[1] <> Byte('C')) or (SectorBuf[2] <> Byte('D')) or
       (SectorBuf[3] <> Byte('0')) or (SectorBuf[4] <> Byte('0')) or
       (SectorBuf[5] <> Byte('1')) then 
    begin
      drv^.FileSystem := FS_NONE;
      Exit;
    end;

    // Root directory record starts at offset 156 in PVD
    rootRec := PISODirRec(@SectorBuf[156]);
    if rootRec^.Len < 34 then 
    begin
      drv^.FileSystem := FS_NONE;
      Exit;
    end;
    
    if (rootRec^.Flags and $02) = 0 then 
    begin
      drv^.FileSystem := FS_NONE;
      Exit;
    end;
    
    if rootRec^.ExtentLBA = 0 then 
    begin
      drv^.FileSystem := FS_NONE;
      Exit;
    end;

    // Ba?ar?l?
    drv^.FileSystem := FS_ISO9660;
    drv^.ISOSectorSize := 2048;
    drv^.ISORootLBA := rootRec^.ExtentLBA;
    drv^.ISORootSize := rootRec^.DataLen;
    
    Result := True;
end;



  //===========================================================================
  // ISO 9660 Resolve Path
  //===========================================================================
 //===========================================================================
// ISO 9660 - DZELTME 2: String karlatrmas
//===========================================================================
function ISO_StrMatch(s1, s2: PChar): Boolean;
var
  i: Integer;
begin
  Result := False;
  i := 0;
  while (s1[i] <> #0) and (s2[i] <> #0) do
  begin
    if StrUpChar(s1[i]) <> StrUpChar(s2[i]) then Exit;
    Inc(i);
  end;
  Result := (s1[i] = #0) and (s2[i] = #0);
end;

//===========================================================================
// ISO 9660 - DZELTME 3: ResolvePath tamamen yeniden yazld
//===========================================================================
//===========================================================================
// ISO_ResolvePath  --  . ve .. tamamen atlan?r
//===========================================================================
function ISO_ResolvePath(DriveIndex: Integer; Path: PChar; out FileLBA: LongWord;
                           out FileSize: LongWord; out IsDir: Boolean): Boolean;
  var
    drv: PDriveInfo;
    dirLBA: LongWord;
    dirSize: LongWord;
    offset: LongWord;
    rec: PISODirRec;
    nameBuf: array[0..MAX_PATH-1] of Char;
    comp: array[0..MAX_PATH-1] of Char;
    p: PChar;
    i: Integer;
    found: Boolean;
  begin
    Result := False;
    FileLBA := 0;
    FileSize := 0;
    IsDir := False;

    drv := @Drives[DriveIndex];
    dirLBA := drv^.ISORootLBA;
    dirSize := drv^.ISORootSize;

    // Skip drive letter "X:\"
    p := Path;
    if (StrLen(p) >= 2) and (p[1] = ':') then Inc(p, 2);
    if (p^ = '\') or (p^ = '/') then Inc(p);

    // If root path
    if p^ = #0 then
    begin
      FileLBA := dirLBA;
      FileSize := dirSize;
      IsDir := True;
      Result := True;
      Exit;
    end;

    // Walk path components
    while p^ <> #0 do
    begin
      // Extract component
      i := 0;
      while (p^ <> #0) and (p^ <> '\') and (p^ <> '/') do
      begin
        comp[i] := ToUpper(p^);
        Inc(i);
        Inc(p);
      end;
      comp[i] := #0;

      if i = 0 then
      begin
        if (p^ = '\') or (p^ = '/') then Inc(p);
        Continue;
      end;

      // Search in current directory
      found := False;
      offset := 0;

      while offset < dirSize do
      begin
        // Read directory sector if needed
        if (offset mod 2048) = 0 then
        begin
          if not ATAPI_ReadSector(DriveIndex, dirLBA + (offset div 2048), @SectorBuf[0]) then Exit;
        end;

        rec := ISO_NextDirRec(@SectorBuf[0], 2048, offset);
        if rec = nil then
        begin
          // Move to next sector
          offset := ((offset div 2048) + 1) * 2048;
          Continue;
        end;

        { ============================================
          D?ZELTME: . ve .. giri?lerini ATLA
          ISO 9660'da:
            '.'  = FileIdLen=1, FileId[0]=$00
            '..' = FileIdLen=1, FileId[0]=$01
          ============================================ }
        if rec^.FileIdLen = 1 then
        begin
          case PByte(PtrUInt(rec) + 33)^ of
            $00, $01:  // . veya ..
              begin
                offset := offset + rec^.Len;
                Continue;
              end;
          end;
        end;

        ISO_ParseName(rec, @nameBuf[0]);

        if StrCmpN(@nameBuf[0], @comp[0], StrLen(@nameBuf[0])) and
           (StrLen(@nameBuf[0]) = StrLen(@comp[0])) then
        begin
          found := True;
          FileLBA := rec^.ExtentLBA;
          FileSize := rec^.DataLen;
          IsDir := ISO_IsDir(rec);

          if (p^ = '\') or (p^ = '/') then
          begin
            // Need to go deeper
            if not IsDir then Exit; // Not a directory but path continues
            dirLBA := FileLBA;
            dirSize := FileSize;
          end;
          Break;
        end;

        offset := offset + rec^.Len;
      end;

      if not found then Exit;

      if (p^ = '\') or (p^ = '/') then Inc(p);
    end;

    Result := True;
end;





  //===========================================================================
  // Updated MountDrive (FAT32 only, ISO handled separately)
  //===========================================================================
procedure MountDrive(DriveIndex: Integer);
var
    drv: PDriveInfo;
    bpb: PBPB;
    fatType: array[0..7] of Char;
    i: Integer;
begin
    drv := @Drives[DriveIndex];

    // Try FAT32 first
    if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, 0, @SectorBuf[0]) then
    begin
      // If ATA identify succeeded but read fails, might be ATAPI
      Exit;
    end;

    if (SectorBuf[510] <> $55) or (SectorBuf[511] <> $AA) then Exit;

    bpb := PBPB(@SectorBuf[0]);
    for i := 0 to 7 do fatType[i] := bpb^.FilSysType[i];

    if StrCmpN(@fatType[0], 'FAT32   ', 8) then
    begin
      MemCopy(@drv^.BPB, bpb, SizeOf(TBPB));
      drv^.FileSystem := FS_FAT32;
      drv^.IsFAT32 := True;
      drv^.SecPerClus := bpb^.SecPerClus;
      drv^.BytesPerClus := bpb^.SecPerClus * bpb^.BytesPerSec;
      drv^.RootClus := bpb^.RootClus;
      drv^.FATStart := bpb^.RsvdSecCnt;
      drv^.DataStart := bpb^.RsvdSecCnt + (bpb^.NumFATs * bpb^.FATSz32);
    end;
end;

  //===========================================================================
  // FAT32_ScanDrives  now scans both HDD and CD-ROM
  //===========================================================================
procedure FAT32_ScanDrives;
var
  ports: array[0..1] of Word;
  driveNums: array[0..1] of Byte;
  portCount: Integer;
  i, j: Integer;
  port: Word;
  driveNum: Byte;
  driveInfo: PDriveInfo;
  letters: array[0..7] of Char;
  isATAPI: Boolean;
  identBuf: array[0..255] of Word;
  status: Byte;
  k: Integer;  // <-- i dngler iin ayr deiken
begin
  DriveCount := 0;
  ports[0] := ATA_DATA;
  ports[1] := ATA_DATA2;
  portCount := 2;
  driveNums[0] := 0;
  driveNums[1] := 1;

  letters[0] := 'C';
  letters[1] := 'D';
  letters[2] := 'E';
  letters[3] := 'F';
  letters[4] := 'G';
  letters[5] := 'H';
  letters[6] := 'I';
  letters[7] := 'J';

  for i := 0 to portCount - 1 do
  begin
    port := ports[i];
    for j := 0 to 1 do
    begin
      driveNum := driveNums[j];
      if DriveCount >= MAX_DRIVES then Break;

      // Select drive
      OutByte(port + 6, $A0 or (driveNum shl 4));
      ATA_Delay(port);
      status := InByte(port + 7);

      if status = 0 then Continue; // No device

      // Try ATA IDENTIFY first
      OutByte(port + 2, 0); OutByte(port + 3, 0);
      OutByte(port + 4, 0); OutByte(port + 5, 0);
      OutByte(port + 7, ATA_CMD_IDENTIFY);
      ATA_Delay(port);
      status := InByte(port + 7);
      if status = 0 then Continue;

      isATAPI := False;
      if not ATA_WaitBSY(port) then Continue;

      // Check if ATAPI: error + ABRT often means ATAPI
      if (InByte(port + 4) <> 0) or (InByte(port + 5) <> 0) then
      begin
        // Could be ATAPI, try PACKET IDENTIFY
        OutByte(port + 6, $A0 or (driveNum shl 4));
        ATA_Delay(port);
        OutByte(port + 7, ATA_CMD_IDENTIFY_PACKET);
        ATA_Delay(port);
        if InByte(port + 7) = 0 then Continue;
        if not ATA_WaitBSY(port) then Continue;
        if not ATA_WaitDRQ(port) then Continue;

        // Read identify data
        for k := 0 to 255 do identBuf[k] := InWord(port);
        isATAPI := True;
      end
      else
      begin
        // ATA device, read identify data
        if not ATA_WaitDRQ(port) then Continue;
        for k := 0 to 255 do identBuf[k] := InWord(port);
      end;

      driveInfo := @Drives[DriveCount];
      MemSet(driveInfo, 0, SizeOf(TDriveInfo));
      driveInfo^.Present := True;
      driveInfo^.ATAPort := port;
      driveInfo^.DriveNum := driveNum;
      driveInfo^.Letter := letters[DriveCount];

      if isATAPI then
      begin
        // Check word 0: ATAPI signature
        if ((identBuf[0] and $C000) = $8000) then
        begin
          // Save model name
          for k := 0 to 19 do
          begin
            driveInfo^.ISOModel[k*2]   := Char(identBuf[27+k] and $FF);
            driveInfo^.ISOModel[k*2+1] := Char((identBuf[27+k] shr 8) and $FF);
          end;
          driveInfo^.ISOModel[40] := #0;

         // driveInfo^.FileSystem := FS_ISO9660;
          ISO_Mount(DriveCount);
          Inc(DriveCount);
          
        end;
      end
      else
      begin
        // ATA HDD
        driveInfo^.SectorCount := LongWord(identBuf[60]) or (LongWord(identBuf[61]) shl 16);
        MountDrive(DriveCount);
        Inc(DriveCount);
      end;
    end;
  end;
end;

  //===========================================================================
  // FAT32 Cluster Operations (unchanged from original)
  //===========================================================================
function FAT32_ClusterToLBA(DriveIndex: Integer; Cluster: LongWord): LongWord;
begin
    Result := Drives[DriveIndex].DataStart +
              (Cluster - 2) * Drives[DriveIndex].SecPerClus;
end;

function FAT32_ReadFAT(DriveIndex: Integer; Cluster: LongWord): LongWord;
var
    drv: PDriveInfo;
    fatSector: LongWord;
    fatOffset: LongWord;
    P: PLongWord;
begin
    Result := FAT32_EOC;
    drv := @Drives[DriveIndex];
    fatOffset := Cluster * 4;
    fatSector := drv^.FATStart + (fatOffset div SECTOR_SIZE);
    fatOffset := fatOffset mod SECTOR_SIZE;
    if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then Exit;
    P := PLongWord(@SectorBuf[fatOffset]);
    Result := P^ and $0FFFFFFF;
end;

function FAT32_WriteFAT(DriveIndex: Integer; Cluster, Value: LongWord): Boolean;
var
    drv: PDriveInfo;
    fatSector: LongWord;
    fatOffset: LongWord;
    P: PLongWord;
begin
    Result := False;
    drv := @Drives[DriveIndex];
    fatOffset := Cluster * 4;
    fatSector := drv^.FATStart + (fatOffset div SECTOR_SIZE);
    fatOffset := fatOffset mod SECTOR_SIZE;
    if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then Exit;
    P := PLongWord(@SectorBuf[fatOffset]);
    P^ := (P^ and $F0000000) or (Value and $0FFFFFFF);
    if not ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then Exit;
    fatSector := fatSector + drv^.BPB.FATSz32;
    ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]);
    Result := True;
end;

function FAT32_AllocCluster(DriveIndex: Integer): LongWord;
var
    drv: PDriveInfo;
    fatSector: LongWord;
    i: Integer;
    P: PLongWord;
    cluster: LongWord;
    entriesPerSec: Integer;
begin
    Result := 0;
    drv := @Drives[DriveIndex];
    entriesPerSec := SECTOR_SIZE div 4;
    fatSector := drv^.FATStart;
    cluster := 2;
    while fatSector < drv^.FATStart + drv^.BPB.FATSz32 do
    begin
      if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then Exit;
      i := 0;
      while i < entriesPerSec do
      begin
        P := PLongWord(@SectorBuf[i * 4]);
        if (P^ and $0FFFFFFF) = FAT32_FREE then
        begin
          P^ := (P^ and $F0000000) or FAT32_EOC;
          ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]);
          Result := cluster;
          Exit;
        end;
        Inc(cluster);
        Inc(i);
      end;
      Inc(fatSector);
    end;
end;

  //===========================================================================
  // FAT32 Directory Operations (original code, kept intact)
  //===========================================================================
function FAT32_MatchPattern(Name: PChar; Pattern: PChar): Boolean;
var
    nIdx, pIdx: Integer;
    n, p: Char;
begin
    nIdx := 0; pIdx := 0;
    while True do
    begin
      n := Name[nIdx]; p := Pattern[pIdx];
      if p = #0 then begin Result := (n = #0); Exit; end;
      if p = '*' then
      begin
        Inc(pIdx);
        if Pattern[pIdx] = #0 then begin Result := True; Exit; end;
        while n <> #0 do
        begin
          if FAT32_MatchPattern(@Name[nIdx], @Pattern[pIdx]) then
          begin
            Result := True;
            Exit;
          end;
          Inc(nIdx);
          n := Name[nIdx];
        end;
        Result := False;
        Exit;
      end;
      if p = '?' then
      begin
        if n = #0 then begin Result := False; Exit; end;
        Inc(nIdx); Inc(pIdx);
        Continue;
      end;
      if StrUpChar(n) <> StrUpChar(p) then begin Result := False; Exit; end;
      Inc(nIdx); Inc(pIdx);
    end;
end;

procedure FAT32_ParseName83(Entry: PDirEntry; Buffer: PChar);
var
    i, j: Integer;
begin
    i := 0; j := 0;
    while (i < 8) and (Entry^.Name[i] <> ' ') do
    begin
      Buffer[j] := Entry^.Name[i];
      Inc(i); Inc(j);
    end;
    if Entry^.Name[8] <> ' ' then
    begin
      Buffer[j] := '.'; Inc(j);
      i := 8;
      while (i < 11) and (Entry^.Name[i] <> ' ') do
      begin
        Buffer[j] := Entry^.Name[i];
        Inc(i); Inc(j);
      end;
    end;
    Buffer[j] := #0;
end;

function FAT32_ShortNameMatch(e: PDirEntry; Pattern: PChar): Boolean;
var
    name: array[0..12] of Char;
begin
    FAT32_ParseName83(e, @name[0]);
    Result := FAT32_MatchPattern(@name[0], Pattern);
end;

function FAT32_FindInDir(DriveIndex: Integer; DirCluster: LongWord;
                           Name: PChar; Entry: PDirEntry;
                           DirSector: PLongWord; DirOffset: PInteger): Boolean;
var
    drv: PDriveInfo;
    cluster: LongWord;
    sector: LongWord;
    secIdx: Integer;
    entryIdx: Integer;
    lba: LongWord;
    e: PDirEntry;
    eName: array[0..12] of Char;
begin
    Result := False;
    drv := @Drives[DriveIndex];
    cluster := DirCluster;
    while (cluster < FAT32_EOC) and (cluster <> FAT32_BAD) and (cluster >= 2) do
    begin
      lba := FAT32_ClusterToLBA(DriveIndex, cluster);
      secIdx := 0;
      while secIdx < drv^.SecPerClus do
      begin
        sector := lba + secIdx;
        if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, sector, @SectorBuf[0]) then
        begin
          Inc(secIdx);
          Continue;
        end;
        entryIdx := 0;
        while entryIdx < (SECTOR_SIZE div 32) do
        begin
          e := PDirEntry(@SectorBuf[entryIdx * 32]);
          if Byte(e^.Name[0]) = 0 then Exit;
          if Byte(e^.Name[0]) = $E5 then
          begin
            Inc(entryIdx);
            Continue;
          end;
          if e^.Attr = ATTR_LFN then
          begin
            Inc(entryIdx);
            Continue;
          end;
          FAT32_ParseName83(e, @eName[0]);
          if FAT32_ShortNameMatch(e, Name) then
          begin
            MemCopy(Entry, e, SizeOf(TDirEntry));
            if DirSector <> nil then DirSector^ := sector;
            if DirOffset <> nil then DirOffset^ := entryIdx * 32;
            Result := True;
            Exit;
          end;
          Inc(entryIdx);
        end;
        Inc(secIdx);
      end;
      cluster := FAT32_ReadFAT(DriveIndex, cluster);
    end;
end;

function FAT32_ResolvePath(DriveIndex: Integer; Path: PChar;
                             Entry: PDirEntry): Boolean;
var
    drv: PDriveInfo;
    currentCluster: LongWord;
    component: array[0..255] of Char;
    p: PChar;
    i: Integer;
    tempEntry: TDirEntry;
begin
    Result := False;
    drv := @Drives[DriveIndex];
    currentCluster := drv^.RootClus;
    p := Path;
    if (StrLen(p) >= 2) and (p[1] = ':') then Inc(p, 2);
    if (p^ = '\') or (p^ = '/') then Inc(p);
    while p^ <> #0 do
    begin
      i := 0;
      while (p^ <> #0) and (p^ <> '\') and (p^ <> '/') do
      begin
        component[i] := p^;
        Inc(i);
        Inc(p);
      end;
      component[i] := #0;
      if i = 0 then
      begin
        if (p^ = '\') or (p^ = '/') then Inc(p);
        Continue;
      end;
      if p^ = #0 then
      begin
        if FAT32_FindInDir(DriveIndex, currentCluster, @component[0],
                           Entry, nil, nil) then
        begin
          Result := True;
          Exit;
        end
        else
          Exit;
      end
      else
      begin
        if FAT32_FindInDir(DriveIndex, currentCluster, @component[0],
                           @tempEntry, nil, nil) then
        begin
          if (tempEntry.Attr and ATTR_DIRECTORY) <> 0 then
          begin
            currentCluster := LongWord(tempEntry.FstClusHI) shl 16 or
                              LongWord(tempEntry.FstClusLO);
            if currentCluster = 0 then currentCluster := drv^.RootClus;
          end
          else
            Exit;
        end
        else
          Exit;
        if (p^ = '\') or (p^ = '/') then Inc(p);
      end;
    end;
    Entry^.FstClusHI := Word(currentCluster shr 16);
    Entry^.FstClusLO := Word(currentCluster);
    Entry^.Attr := ATTR_DIRECTORY;
    Entry^.FileSize := 0;
    Result := True;
end;

  //===========================================================================
  // FAT32_GetDriveFromPath (unchanged)
  //===========================================================================
function FAT32_GetDriveFromPath(Path: PChar): Integer;
var
    i: Integer;
begin
    Result := -1;
    if Path = nil then Exit;
    if (StrLen(Path) >= 3) and (Path[1] = ':') then
    begin                             // ToUpper
      for i := 0 to DriveCount - 1 do
        if ToUpper(Drives[i].Letter) = ToUpper(Path[0]) then
        begin
          Result := i;
          Exit;
        end;
    end
    else
    begin
      if DriveCount > 0 then Result := 0;
    end;
end;

  //===========================================================================
  // FAT32_GetDirCluster (unchanged)
  //===========================================================================
function FAT32_GetDirCluster(DriveIndex: Integer; Path: PChar): LongWord;
var
    entry: TDirEntry;
    drv: PDriveInfo;
    lastSlash: PChar;
    dirPath: array[0..MAX_PATH-1] of Char;
    i: Integer;
  begin
    Result := 0;
    drv := @Drives[DriveIndex];
    lastSlash := nil;
    i := 0;
    while Path[i] <> #0 do
    begin
      if (Path[i] = '\') or (Path[i] = '/') then lastSlash := @Path[i];
      Inc(i);
    end;
    if lastSlash = nil then
    begin
      Result := drv^.RootClus;
      Exit;
    end;
    i := 0;
    while @Path[i] <> lastSlash do
    begin
      dirPath[i] := Path[i];
      Inc(i);
    end;
    dirPath[i] := #0;
    if FAT32_ResolvePath(DriveIndex, @dirPath[0], @entry) then
      Result := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);
    if Result = 0 then Result := drv^.RootClus;
end;

  //===========================================================================
  // FAT32_AllocHandle (unchanged)
  //===========================================================================
function FAT32_AllocHandle: Integer;
var
    i: Integer;
begin
    Result := -1;
    for i := 0 to MAX_OPEN_FILES - 1 do
      if not OpenFiles[i].Used then
      begin
        Result := i;
        Exit;
      end;
end;

  //===========================================================================
  // Hybrid OpenFile  works for both FAT32 and ISO 9660
  //===========================================================================
function OpenFile(Path: PChar; Mode: Byte): Integer;
var
    driveIndex: Integer;
    entry: TDirEntry;
    handle: Integer;
    fh: PFileHandle;
    drv: PDriveInfo;
    cluster: LongWord;
    dirSec: LongWord;
    dirOff: Integer;
    dirClus: LongWord;
    newCluster: LongWord;
    newEntry: TDirEntry;
    fileName: PChar;
    i, j: Integer;
    lba: LongWord;
    isoLBA: LongWord;
    isoSize: LongWord;
    isoIsDir: Boolean;
begin
    Result := -1;
    driveIndex := FAT32_GetDriveFromPath(Path);
    if driveIndex < 0 then Exit;
    drv := @Drives[driveIndex];
    if not drv^.Present then Exit;

    handle := FAT32_AllocHandle;
    if handle < 0 then Exit;
    fh := @OpenFiles[handle];
    MemSet(fh, 0, SizeOf(TFileHandle));

    // ==================== ISO 9660 ====================
    if drv^.FileSystem = FS_ISO9660 then
    begin



      // ISO is read-only
      if (Mode and FILE_WRITE) <> 0 then Exit;
      if (Mode and FILE_CREATE) <> 0 then Exit;
      
      if not ISO_ResolvePath(driveIndex, Path, isoLBA, isoSize, isoIsDir) then Exit;
      if isoIsDir then Exit; // Cannot open directory as file



      fh^.Used := True;
      fh^.DriveIndex := driveIndex;
      fh^.Mode := FILE_READ;
      fh^.FileSize := isoSize;
      fh^.FilePos := 0;
      fh^.SectorSize := 2048;
      fh^.ISOLBA := isoLBA;
      fh^.CurrentSector := isoLBA;
      fh^.SectorOffset := 0;
      fh^.BufferDirty := False;
      StrCopy(@fh^.Name[0], Path);


     

      // Read first sector. Do not return a valid handle if the media read fails.
      if not ATAPI_ReadSector(driveIndex, isoLBA, @fh^.Buffer[0]) then
      begin
        fh^.Used := False;
        Result := INVALID_HANDLE;
        Exit;
      end;
      Result := handle;
      Exit;
    end;

    // ==================== FAT32 ====================
    if not drv^.IsFAT32 then Exit;

    if FAT32_ResolvePath(driveIndex, Path, @entry) then
    begin
      if (Mode and FILE_CREATE) <> 0 then
      begin
        cluster := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);
        // TODO: Free cluster chain for truncate
      end;
      cluster := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);
      fh^.Used := True;
      fh^.DriveIndex := driveIndex;
      fh^.Mode := Mode;
      fh^.FileSize := entry.FileSize;
      fh^.FilePos := 0;
      fh^.SectorSize := SECTOR_SIZE;
      fh^.StartCluster := cluster;
      fh^.CurrentCluster := cluster;
      fh^.CurrentSector := FAT32_ClusterToLBA(driveIndex, cluster);
      fh^.SectorOffset := 0;
      fh^.BufferDirty := False;
      StrCopy(@fh^.Name[0], Path);
      if (Mode and FILE_APPEND) <> 0 then SeekFile(handle, 0, SEEK_END);
      ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
      Result := handle;
    end
    else if (Mode and FILE_CREATE) <> 0 then
    begin
      newCluster := FAT32_AllocCluster(driveIndex);
      if newCluster = 0 then Exit;
      dirClus := FAT32_GetDirCluster(driveIndex, Path);
      fileName := Path;
      i := 0;
      while Path[i] <> #0 do
      begin
        if (Path[i] = '\') or (Path[i] = '/') then fileName := @Path[i + 1];
        Inc(i);
      end;
      MemSet(@newEntry, 0, SizeOf(TDirEntry));
      i := 0; j := 0;
      while (fileName[i] <> #0) and (fileName[i] <> '.') and (j < 8) do
      begin
        newEntry.Name[j] := ToUpper(fileName[i]);
        Inc(i); Inc(j);
      end;
      while j < 8 do begin newEntry.Name[j] := ' '; Inc(j); end;
      if fileName[i] = '.' then
      begin
        Inc(i); j := 8;
        while (fileName[i] <> #0) and (j < 11) do
        begin
          newEntry.Name[j] := ToUpper(fileName[i]);
          Inc(i); Inc(j);
        end;
      end;
      while j < 11 do begin newEntry.Name[j] := ' '; Inc(j); end;
      newEntry.Attr := ATTR_ARCHIVE;
      newEntry.FstClusHI := Word(newCluster shr 16);
      newEntry.FstClusLO := Word(newCluster);
      newEntry.FileSize := 0;
      lba := FAT32_ClusterToLBA(driveIndex, dirClus);
      if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]) then
      begin
        i := 0;
        while i < (SECTOR_SIZE div 32) do
        begin
          if (Byte(SectorBuf[i * 32]) = 0) or (Byte(SectorBuf[i * 32]) = $E5) then
          begin
            MemCopy(@SectorBuf[i * 32], @newEntry, SizeOf(TDirEntry));
            ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]);
            Break;
          end;
          Inc(i);
        end;
      end;
      fh^.Used := True;
      fh^.DriveIndex := driveIndex;
      fh^.Mode := Mode;
      fh^.FileSize := 0;
      fh^.FilePos := 0;
      fh^.SectorSize := SECTOR_SIZE;
      fh^.StartCluster := newCluster;
      fh^.CurrentCluster := newCluster;
      fh^.CurrentSector := FAT32_ClusterToLBA(driveIndex, newCluster);
      fh^.SectorOffset := 0;
      fh^.BufferDirty := False;
      fh^.DirSector := lba;
      fh^.DirOffset := i * 32;
      StrCopy(@fh^.Name[0], Path);
      MemSet(@fh^.Buffer[0], 0, SECTOR_SIZE);
      Result := handle;
    end;
end;

  //===========================================================================
  // Hybrid ReadFile  FAT32 and ISO 9660
//===========================================================================
function ReadFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
var
    fh: PFileHandle;
    drv: PDriveInfo;
    bytesRead: LongWord;
    toRead: LongWord;
    bufP: PByte;
    remaining: LongWord;
    nextCluster: LongWord;
    nextSector: LongWord;
    isoOffset: LongWord;
begin
    Result := 0;
    if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
    fh := @OpenFiles[Handle];
    if not fh^.Used then Exit;
    if (fh^.Mode and FILE_READ) = 0 then Exit;

    drv := @Drives[fh^.DriveIndex];
    bufP := PByte(Buffer);
    bytesRead := 0;
    remaining := Size;

    if fh^.FilePos + remaining > fh^.FileSize then
      remaining := fh^.FileSize - fh^.FilePos;

    // ==================== ISO 9660 ====================
    if drv^.FileSystem = FS_ISO9660 then
    begin
      while remaining > 0 do
      begin
        toRead := fh^.SectorSize - fh^.SectorOffset;
        if toRead > remaining then toRead := remaining;

        MemCopy(bufP, @fh^.Buffer[fh^.SectorOffset], toRead);
        Inc(bufP, toRead);
        Inc(bytesRead, toRead);
        Inc(fh^.FilePos, toRead);
        Inc(fh^.SectorOffset, toRead);
        Dec(remaining, toRead);

        if fh^.SectorOffset >= fh^.SectorSize then
        begin
          fh^.SectorOffset := 0;
          Inc(fh^.CurrentSector);
          if remaining > 0 then
          begin
            if not ATAPI_ReadSector(fh^.DriveIndex, fh^.CurrentSector, @fh^.Buffer[0]) then
              Break;
          end;
        end;
      end;
      Result := bytesRead;
      Exit;
    end;

    // ==================== FAT32 ====================
    while remaining > 0 do
    begin
      toRead := SECTOR_SIZE - fh^.SectorOffset;
      if toRead > remaining then toRead := remaining;

      MemCopy(bufP, @fh^.Buffer[fh^.SectorOffset], toRead);
      Inc(bufP, toRead);
      Inc(bytesRead, toRead);
      Inc(fh^.FilePos, toRead);
      Inc(fh^.SectorOffset, toRead);
      Dec(remaining, toRead);

      if fh^.SectorOffset >= SECTOR_SIZE then
      begin
        fh^.SectorOffset := 0;
        Inc(fh^.CurrentSector);
        if fh^.CurrentSector >= FAT32_ClusterToLBA(fh^.DriveIndex, fh^.CurrentCluster) + drv^.SecPerClus then
        begin
          nextCluster := FAT32_ReadFAT(fh^.DriveIndex, fh^.CurrentCluster);
          if (nextCluster >= FAT32_EOC) or (nextCluster < 2) then Break;
          fh^.CurrentCluster := nextCluster;
          fh^.CurrentSector := FAT32_ClusterToLBA(fh^.DriveIndex, nextCluster);
        end;
        if remaining > 0 then
          ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
      end;
    end;
    Result := bytesRead;
end;

  //===========================================================================
  // WriteFile (FAT32 only  ISO is read-only)
  //===========================================================================
function WriteFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
var
    fh: PFileHandle;
    drv: PDriveInfo;
    bytesWritten: LongWord;
    toWrite: LongWord;
    bufP: PByte;
    remaining: LongWord;
    nextCluster: LongWord;
begin
    Result := 0;
    if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
    fh := @OpenFiles[Handle];
    if not fh^.Used then Exit;
    if (fh^.Mode and FILE_WRITE) = 0 then Exit;

    drv := @Drives[fh^.DriveIndex];
    if drv^.FileSystem = FS_ISO9660 then Exit; // Read-only

    bufP := PByte(Buffer);
    bytesWritten := 0;
    remaining := Size;

    while remaining > 0 do
    begin
      toWrite := SECTOR_SIZE - fh^.SectorOffset;
      if toWrite > remaining then toWrite := remaining;

      MemCopy(@fh^.Buffer[fh^.SectorOffset], bufP, toWrite);
      fh^.BufferDirty := True;

      Inc(bufP, toWrite);
      Inc(bytesWritten, toWrite);
      Inc(fh^.FilePos, toWrite);
      Inc(fh^.SectorOffset, toWrite);
      Dec(remaining, toWrite);

      if fh^.FilePos > fh^.FileSize then fh^.FileSize := fh^.FilePos;

      if fh^.SectorOffset >= SECTOR_SIZE then
      begin
        ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
        fh^.BufferDirty := False;
        fh^.SectorOffset := 0;
        Inc(fh^.CurrentSector);

        if fh^.CurrentSector >= FAT32_ClusterToLBA(fh^.DriveIndex, fh^.CurrentCluster) + drv^.SecPerClus then
        begin
          nextCluster := FAT32_ReadFAT(fh^.DriveIndex, fh^.CurrentCluster);
          if (nextCluster >= FAT32_EOC) or (nextCluster < 2) then
          begin
            nextCluster := FAT32_AllocCluster(fh^.DriveIndex);
            if nextCluster = 0 then Break;
            FAT32_WriteFAT(fh^.DriveIndex, fh^.CurrentCluster, nextCluster);
          end;
          fh^.CurrentCluster := nextCluster;
          fh^.CurrentSector := FAT32_ClusterToLBA(fh^.DriveIndex, nextCluster);
          MemSet(@fh^.Buffer[0], 0, SECTOR_SIZE);
        end;
      end;
    end;
    Result := bytesWritten;
end;

  //===========================================================================
  // Hybrid SeekFile
  //===========================================================================
function SeekFile(Handle: Integer; Offset: LongInt; Origin: Byte): LongWord;
var
    fh: PFileHandle;
    drv: PDriveInfo;
    newPos: LongInt;
    targetCluster: LongWord;
    clusterIndex: LongWord;
    i: LongWord;
    lba: LongWord;
    sectorSize: Word;
begin
    Result := $FFFFFFFF;
    if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
    fh := @OpenFiles[Handle];
    if not fh^.Used then Exit;

    drv := @Drives[fh^.DriveIndex];
    sectorSize := fh^.SectorSize;

    case Origin of
      SEEK_SET: newPos := Offset;
      SEEK_CUR: newPos := LongInt(fh^.FilePos) + Offset;
      SEEK_END: newPos := LongInt(fh^.FileSize) + Offset;
    else
      newPos := Offset;
    end;

    if newPos < 0 then newPos := 0;
    if LongWord(newPos) > fh^.FileSize then newPos := LongInt(fh^.FileSize);

    // Flush if dirty
    if fh^.BufferDirty then
    begin
      if drv^.FileSystem = FS_FAT32 then
        ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
      fh^.BufferDirty := False;
    end;

    // ==================== ISO 9660 ====================
    if drv^.FileSystem = FS_ISO9660 then
    begin
      fh^.FilePos := LongWord(newPos);
      fh^.CurrentSector := fh^.ISOLBA + (LongWord(newPos) div 2048);
      fh^.SectorOffset := LongWord(newPos) mod 2048;
      if not ATAPI_ReadSector(fh^.DriveIndex, fh^.CurrentSector, @fh^.Buffer[0]) then
      begin
        Result := $FFFFFFFF;
        Exit;
      end;
      Result := LongWord(newPos);
      Exit;
    end;

    // ==================== FAT32 ====================
    clusterIndex := LongWord(newPos) div drv^.BytesPerClus;
    targetCluster := fh^.StartCluster;
    i := 0;
    while i < clusterIndex do
    begin
      targetCluster := FAT32_ReadFAT(fh^.DriveIndex, targetCluster);
      if (targetCluster >= FAT32_EOC) or (targetCluster < 2) then
      begin
        targetCluster := fh^.StartCluster;
        Break;
      end;
      Inc(i);
    end;

    fh^.FilePos := LongWord(newPos);
    fh^.CurrentCluster := targetCluster;
    lba := FAT32_ClusterToLBA(fh^.DriveIndex, targetCluster);
    fh^.CurrentSector := lba + ((LongWord(newPos) mod drv^.BytesPerClus) div SECTOR_SIZE);
    fh^.SectorOffset := LongWord(newPos) mod SECTOR_SIZE;

    ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
    Result := LongWord(newPos);
end;

  //===========================================================================
  // FilePos / FileSize (unchanged logic)
  //===========================================================================
function FilePos(Handle: Integer): LongWord;
begin
    Result := 0;
    if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
    if not OpenFiles[Handle].Used then Exit;
    Result := OpenFiles[Handle].FilePos;
end;

function FileSize(Handle: Integer): LongWord;
begin
    Result := 0;
    if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
    if not OpenFiles[Handle].Used then Exit;
    Result := OpenFiles[Handle].FileSize;
end;

  //===========================================================================
  // CloseFile (Hybrid)
  //===========================================================================
procedure CloseFile(Handle: Integer);
var
    fh: PFileHandle;
    drv: PDriveInfo;
    dirEntry: PDirEntry;
begin
    if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
    fh := @OpenFiles[Handle];
    if not fh^.Used then Exit;

    drv := @Drives[fh^.DriveIndex];

    if fh^.BufferDirty then
    begin
      if drv^.FileSystem = FS_FAT32 then
        ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
      fh^.BufferDirty := False;
    end;

    if (drv^.FileSystem = FS_FAT32) and ((fh^.Mode and FILE_WRITE) <> 0) then
    begin
      if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.DirSector, @SectorBuf[0]) then
      begin
        dirEntry := PDirEntry(@SectorBuf[fh^.DirOffset]);
        dirEntry^.FileSize := fh^.FileSize;
        ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fh^.DirSector, @SectorBuf[0]);
      end;
    end;

    fh^.Used := False;
end;


  //===========================================================================
// FileExists  --  hem FAT32 hem ISO 9660 icin calisir
//
// Verilen yol var mi VE bir dizin degil (dosya) mi diye bakar.
// FAT32_ResolvePath / ISO_ResolvePath zaten root ("C:\") ve arada
// kalan alt dizinleri de dogru sekilde cozdugu icin ayrica ozel bir
// "sadece surucu koku" durumu ele almaya gerek yok.
//===========================================================================
function FileExists(Path: PChar): Boolean;
var
  driveIndex: Integer;
  drv: PDriveInfo;
  entry: TDirEntry;
  isoLBA: LongWord;
  isoSize: LongWord;
  isoIsDir: Boolean;
begin
  Result := False;

  if Path = nil then Exit;
  if Path[0] = #0 then Exit;

  driveIndex := FAT32_GetDriveFromPath(Path);
  if (driveIndex < 0) or (driveIndex >= DriveCount) then Exit;

  drv := @Drives[driveIndex];
  if not drv^.Present then Exit;

  if drv^.FileSystem = FS_ISO9660 then
  begin
    if not ISO_ResolvePath(driveIndex, Path, isoLBA, isoSize, isoIsDir) then
      Exit;

    Result := not isoIsDir;
    Exit;
  end;

  if drv^.FileSystem = FS_FAT32 then
  begin
    if not FAT32_ResolvePath(driveIndex, Path, @entry) then
      Exit;

    Result := (entry.Attr and ATTR_DIRECTORY) = 0;
    Exit;
  end;
end;

//===========================================================================
// DirectoryExists  --  hem FAT32 hem ISO 9660 icin calisir
//
// Verilen yol var mi VE bir dizin mi diye bakar.
//===========================================================================
function DirectoryExists(Path: PChar): Boolean;
var
  driveIndex: Integer;
  drv: PDriveInfo;
  entry: TDirEntry;
  isoLBA: LongWord;
  isoSize: LongWord;
  isoIsDir: Boolean;
begin
  Result := False;

  if Path = nil then Exit;
  if Path[0] = #0 then Exit;

  driveIndex := FAT32_GetDriveFromPath(Path);
  if (driveIndex < 0) or (driveIndex >= DriveCount) then Exit;

  drv := @Drives[driveIndex];
  if not drv^.Present then Exit;

  if drv^.FileSystem = FS_ISO9660 then
  begin
    if not ISO_ResolvePath(driveIndex, Path, isoLBA, isoSize, isoIsDir) then
      Exit;

    Result := isoIsDir;
    Exit;
  end;

  if drv^.FileSystem = FS_FAT32 then
  begin
    if not FAT32_ResolvePath(driveIndex, Path, @entry) then
      Exit;

    Result := (entry.Attr and ATTR_DIRECTORY) <> 0;
    Exit;
  end;
end;


  //===========================================================================
  // MakeDir / DeleteFile (FAT32 only)
  //===========================================================================
function MakeDir(Path: PChar): Boolean;
var
    driveIndex: Integer;
    dirCluster: LongWord;
    newCluster: LongWord;
    drv: PDriveInfo;
    entry: TDirEntry;
    lba: LongWord;
    dirName: PChar;
    i, j: Integer;
begin
    Result := False;
    driveIndex := FAT32_GetDriveFromPath(Path);
    if driveIndex < 0 then Exit;
    drv := @Drives[driveIndex];
    if drv^.FileSystem <> FS_FAT32 then Exit;
    if FAT32_ResolvePath(driveIndex, Path, @entry) then Exit;

    dirName := Path;
    i := 0;
    while Path[i] <> #0 do
    begin
      if (Path[i] = '\') or (Path[i] = '/') then dirName := @Path[i + 1];
      Inc(i);
    end;

    dirCluster := FAT32_GetDirCluster(driveIndex, Path);
    newCluster := FAT32_AllocCluster(driveIndex);
    if newCluster = 0 then Exit;

    MemSet(@SectorBuf[0], 0, SECTOR_SIZE);
    lba := FAT32_ClusterToLBA(driveIndex, newCluster);
    for i := 0 to drv^.SecPerClus - 1 do
    begin
      ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, lba + i, @SectorBuf[0]);
    end;

    lba := FAT32_ClusterToLBA(driveIndex, newCluster);
    if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]) then
    begin
      MemSet(@SectorBuf[0], 32, 0);
      SectorBuf[0] := Byte('.');
      for i := 1 to 10 do SectorBuf[i] := Byte(' ');
      SectorBuf[11] := ATTR_DIRECTORY;
      SectorBuf[26] := Byte(newCluster);
      SectorBuf[27] := Byte(newCluster shr 8);
      SectorBuf[20] := Byte(newCluster shr 16);
      SectorBuf[21] := Byte(newCluster shr 24);

      SectorBuf[32] := Byte('.');
      SectorBuf[33] := Byte('.');
      for i := 34 to 42 do SectorBuf[i] := Byte(' ');
      SectorBuf[43] := ATTR_DIRECTORY;
      SectorBuf[58] := Byte(dirCluster);
      SectorBuf[59] := Byte(dirCluster shr 8);
      SectorBuf[52] := Byte(dirCluster shr 16);
      SectorBuf[53] := Byte(dirCluster shr 24);

      ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]);
    end;

    MemSet(@entry, 0, SizeOf(TDirEntry));
    j := 0; i := 0;
    while (dirName[i] <> #0) and (j < 8) do
    begin
      entry.Name[j] := ToUpper(dirName[i]);
      Inc(i); Inc(j);
    end;
    while j < 11 do begin entry.Name[j] := ' '; Inc(j); end;
    entry.Attr := ATTR_DIRECTORY;
    entry.FstClusHI := Word(newCluster shr 16);
    entry.FstClusLO := Word(newCluster);
    entry.FileSize := 0;

    lba := FAT32_ClusterToLBA(driveIndex, dirCluster);
    if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]) then
    begin
      i := 0;
      while i < (SECTOR_SIZE div 32) do
      begin
        if (Byte(SectorBuf[i * 32]) = 0) or (Byte(SectorBuf[i * 32]) = $E5) then
        begin
          MemCopy(@SectorBuf[i * 32], @entry, SizeOf(TDirEntry));
          ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]);
          Result := True;
          Exit;
        end;
        Inc(i);
      end;
    end;
end;

function DeleteFile(Path: PChar): Boolean;
var
    driveIndex: Integer;
    entry: TDirEntry;
    dirSec: LongWord;
    dirOff: Integer;
    drv: PDriveInfo;
    cluster: LongWord;
    nextCluster: LongWord;
    dirCluster: LongWord;
    fileName: PChar;
    i: Integer;
begin
    Result := False;
    driveIndex := FAT32_GetDriveFromPath(Path);
    if driveIndex < 0 then Exit;
    drv := @Drives[driveIndex];
    if drv^.FileSystem <> FS_FAT32 then Exit;

    dirCluster := FAT32_GetDirCluster(driveIndex, Path);
    fileName := Path;
    i := 0;
    while Path[i] <> #0 do
    begin
      if (Path[i] = '\') or (Path[i] = '/') then fileName := @Path[i + 1];
      Inc(i);
    end;

    if not FAT32_FindInDir(driveIndex, dirCluster, fileName, @entry, @dirSec, @dirOff) then Exit;
    if (entry.Attr and ATTR_DIRECTORY) <> 0 then Exit;

    cluster := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);
    while (cluster >= 2) and (cluster < FAT32_EOC) do
    begin
      nextCluster := FAT32_ReadFAT(driveIndex, cluster);
      FAT32_WriteFAT(driveIndex, cluster, FAT32_FREE);
      cluster := nextCluster;
    end;

    if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, dirSec, @SectorBuf[0]) then
    begin
      SectorBuf[dirOff] := $E5;
      ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, dirSec, @SectorBuf[0]);
      Result := True;
    end;
end;

  //===========================================================================
  // Hybrid FindFirst / FindNext / FindClose
  //===========================================================================
  var
    FindHandles: array[0..7] of TFindHandle;

function FAT32_GetExtension(Name: PChar): PChar;
var
    i: Integer;
begin
    i := 0;
    while Name[i] <> #0 do Inc(i);
    while (i > 0) and (Name[i] <> '.') do Dec(i);
    if (i > 0) and (Name[i] = '.') then
      Result := @Name[i]
    else
      Result := @Name[i];
end;

function FAT32_ExtensionMatch(Name: PChar; Pattern: PChar): Boolean;
var
    ext: PChar;
begin
    ext := FAT32_GetExtension(Name);
    Result := FAT32_MatchPattern(ext, Pattern);
end;

  //===========================================================================
  // ISO Find Helpers
  //===========================================================================
procedure ISO_FindInit(var fh: TFindHandle; dirLBA: LongWord; dirSize: LongWord);
begin
    fh.ISODirLBA := dirLBA;
    fh.ISODirSize := dirSize;
    fh.ISOCurrentLBA := dirLBA;
    fh.ISOOffset := 0;
end;

  //===========================================================================
  // FindFirst  Hybrid FAT32 + ISO 9660
  //===========================================================================
function FindFirst(Path, Pattern: PChar; Attr: Byte;
                           SearchRec: PSearchRec): Integer;
var
    driveIndex: Integer;
    entry: TDirEntry;
    drv: PDriveInfo;
    fh: PFindHandle;
    i: Integer;
    dirCluster: LongWord;
    isoLBA: LongWord;
    isoSize: LongWord;
    isoIsDir: Boolean;
begin
    Result := -1;
    driveIndex := FAT32_GetDriveFromPath(Path);
    if driveIndex < 0 then Exit;
    drv := @Drives[driveIndex];

    // Find free handle
    for i := 0 to 7 do
      if not FindHandles[i].Used then Break;
    if i >= 8 then Exit;

    fh := @FindHandles[i];
    MemSet(fh, 0, SizeOf(TFindHandle));
    fh^.Used := True;
    fh^.DriveIndex := driveIndex;
    fh^.SearchAttr := Attr;

    if Pattern = nil then
      StrCopy(@fh^.SearchPath[0], '*')
    else
      StrCopy(@fh^.SearchPath[0], Pattern);

    // ==================== ISO 9660 ====================
    if drv^.FileSystem = FS_ISO9660 then
    begin
      if ISO_ResolvePath(driveIndex, Path, isoLBA, isoSize, isoIsDir) then
      begin
        if not isoIsDir then
        begin
          // Path is a file, cannot enumerate
          fh^.Used := False;
          Exit;
        end;
        ISO_FindInit(fh^, isoLBA, isoSize);
      end
      else
      begin
        // Root if path not resolved
        ISO_FindInit(fh^, drv^.ISORootLBA, drv^.ISORootSize);
      end;

      Result := i;
      if not FindNext(i, SearchRec) then
      begin
        FindHandles[i].Used := False;
        Result := -1;
      end;
      Exit;
    end;

    // ==================== FAT32 ====================
    if FAT32_ResolvePath(driveIndex, Path, @entry) then
    begin
      fh^.DirCluster := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);
      if fh^.DirCluster = 0 then fh^.DirCluster := drv^.RootClus;
    end
    else
      fh^.DirCluster := drv^.RootClus;

    fh^.DirSector := FAT32_ClusterToLBA(driveIndex, fh^.DirCluster);
    fh^.DirIndex := 0;

    Result := i;
    if not FindNext(i, SearchRec) then
    begin
      FindHandles[i].Used := False;
      Result := -1;
    end;
end;

  //===========================================================================
  // FindNext  Hybrid FAT32 + ISO 9660
  //===========================================================================
function FindNext(FindHandle: Integer; SearchRec: PSearchRec): Boolean;
var
  fh: PFindHandle;
  drv: PDriveInfo;
  e: PDirEntry;
  cluster: LongWord;
  secInClus: Integer;
  name: array[0..MAX_PATH-1] of Char;
  matched: Boolean;
  isDirectory: Boolean;
  rec: PISODirRec;
  isoBufOffset: LongWord;
  recName: array[0..MAX_PATH-1] of Char;
  currentLBA: LongWord;
begin
  Result := False;
  if (FindHandle < 0) or (FindHandle >= 8) then Exit;
  fh := @FindHandles[FindHandle];
  if not fh^.Used then Exit;

  drv := @Drives[fh^.DriveIndex];

  // ==================== ISO 9660 ====================
  if drv^.FileSystem = FS_ISO9660 then
  begin
    while fh^.ISOOffset < fh^.ISODirSize do
    begin
      // Sektor snrn kontrol et
      currentLBA := fh^.ISODirLBA + (fh^.ISOOffset div 2048);
      
      // Sektor oku
      if (fh^.ISOOffset mod 2048) = 0 then
      begin
        fh^.ISOCurrentLBA := currentLBA;
        if not ATAPI_ReadSector(fh^.DriveIndex, currentLBA, @fh^.ISOSectorBuf[0]) then
          Exit;
      end;

      isoBufOffset := fh^.ISOOffset mod 2048;
      
      // Sektor snrn a m?
      if isoBufOffset >= 2048 then
      begin
        fh^.ISOOffset := ((fh^.ISOOffset div 2048) + 1) * 2048;
        Continue;
      end;

      rec := PISODirRec(@fh^.ISOSectorBuf[isoBufOffset]);

      if rec^.Len = 0 then
      begin
        // Padding, sonraki sektre git
        fh^.ISOOffset := ((fh^.ISOOffset div 2048) + 1) * 2048;
        Continue;
      end;


         // Skip . and ..  (ISO 9660: $00 = . , $01 = ..)
      if rec^.FileIdLen = 1 then
      begin
        case PByte(PtrUInt(rec) + 33)^ of
          $00, $01:
            begin
              fh^.ISOOffset := fh^.ISOOffset + rec^.Len;
              Continue;
            end;
        end;
      end;

   
      if rec^.FileIdLen = 2 then
      begin
        if (PByte(PtrUInt(rec) + 33)^ = Byte('.')) and
           (PByte(PtrUInt(rec) + 34)^ = Byte('.')) then
        begin
          fh^.ISOOffset := fh^.ISOOffset + rec^.Len;
          Continue;
        end;
      end;

      // Dosya adn parse et
      ISO_ParseName(rec, @recName[0]);
      isDirectory := ISO_IsDir(rec);

      matched := False;

      if isDirectory then
      begin
        if (fh^.SearchAttr and ATTR_DIRECTORY) <> 0 then
          matched := True;
      end
      else
      begin
        if StrCmp(@fh^.SearchPath[0], '*') = 0 then
          matched := True
        else if FAT32_MatchPattern(@recName[0], @fh^.SearchPath[0]) then
          matched := True;
      end;

      if matched then
      begin
        StrCopy(@SearchRec^.Name[0], @recName[0]);
        StrCopy(@SearchRec^.ShortName[0], @recName[0]);
        SearchRec^.Attr := 0;
        if isDirectory then
          SearchRec^.Attr := ATTR_DIRECTORY
        else
          SearchRec^.Attr := ATTR_ARCHIVE;
        SearchRec^.FileSize := rec^.DataLen;
        SearchRec^.StartCluster := rec^.ExtentLBA;
        SearchRec^.IsDir := isDirectory;
        fh^.ISOOffset := fh^.ISOOffset + rec^.Len;
        Result := True;
        Exit;
      end;

      fh^.ISOOffset := fh^.ISOOffset + rec^.Len;
    end;
    Exit;
  end;

  // ==================== FAT32 ====================
  { FAT32 kodu ayn kalyor }
  cluster := fh^.DirCluster;
  while True do
  begin
    if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.DirSector, @SectorBuf[0]) then Exit;

    while fh^.DirIndex < (SECTOR_SIZE div 32) do
    begin
      e := PDirEntry(@SectorBuf[fh^.DirIndex * 32]);
      if Byte(e^.Name[0]) = 0 then Exit;
      Inc(fh^.DirIndex);

      if Byte(e^.Name[0]) = $E5 then Continue;
      if e^.Attr = ATTR_LFN then Continue;
      if (e^.Attr and ATTR_VOLUME_ID) <> 0 then Continue;

      isDirectory := (e^.Attr and ATTR_DIRECTORY) <> 0;

      if isDirectory then
      begin
        if (e^.Name[0] = '.') then Continue;
      end;

      FAT32_ParseName83(e, @name[0]);
      matched := False;

      if isDirectory then
      begin
        if (fh^.SearchAttr and ATTR_DIRECTORY) <> 0 then
          matched := True;
      end
      else
      begin
        if StrCmp(@fh^.SearchPath[0], '*') = 0 then
          matched := True
        else if FAT32_MatchPattern(@name[0], @fh^.SearchPath[0]) then
          matched := True;
      end;

      if matched then
      begin
        FAT32_ParseName83(e, @SearchRec^.Name[0]);
        FAT32_ParseName83(e, @SearchRec^.ShortName[0]);
        SearchRec^.Attr := e^.Attr;
        SearchRec^.IsDir := isDirectory;
        SearchRec^.FileSize := e^.FileSize;
        SearchRec^.StartCluster := LongWord(e^.FstClusHI) shl 16 or LongWord(e^.FstClusLO);
        Result := True;
        Exit;
      end;
    end;

    fh^.DirIndex := 0;
    Inc(fh^.DirSector);
    
    if fh^.DirSector >= FAT32_ClusterToLBA(fh^.DriveIndex, fh^.DirCluster) + drv^.SecPerClus then
    begin
      cluster := FAT32_ReadFAT(fh^.DriveIndex, fh^.DirCluster);
      if (cluster >= FAT32_EOC) or (cluster < 2) then Exit;
      fh^.DirCluster := cluster;
      fh^.DirSector := FAT32_ClusterToLBA(fh^.DriveIndex, cluster);
    end;
  end;
end;


//===========================================================================
// FindClose
//===========================================================================
procedure FindClose(FindHandle: Integer);
begin
  if (FindHandle < 0) or (FindHandle >= 8) then Exit;
  FindHandles[FindHandle].Used := False;
end;

//===========================================================================
// FAT32_Init
//===========================================================================
procedure FAT32_Init;
var
  i: Integer;
begin
  DriveCount := 0;
  for i := 0 to MAX_DRIVES - 1 do
  begin
    Drives[i].Present := False;
    Drives[i].FileSystem := FS_NONE;
  end;
  for i := 0 to MAX_OPEN_FILES - 1 do
    OpenFiles[i].Used := False;
  for i := 0 to 7 do
    FindHandles[i].Used := False;
  FAT32_ScanDrives;
end;

//===========================================================================
// FAT32_GetDriveSpace
//===========================================================================

//===========================================================================
// ATAPI Read Capacity (CD-ROM toplam kapasite)
//===========================================================================
//===========================================================================
// ATAPI_ReadCapacity  FIX: Zaten FS_ISO9660 olarak ayarlanm?? olmal?
//===========================================================================
function ATAPI_ReadCapacity(DriveIndex: Integer; out LastLBA: LongWord; 
                            out BlockSize: LongWord): Boolean;
var
  cd: PDriveInfo;
  CDB: array[0..11] of Byte;
  Buf: array[0..7] of Byte;
begin
  Result := False;
  LastLBA := 0;
  BlockSize := 0;
  
  if (DriveIndex < 0) or (DriveIndex >= MAX_DRIVES) then Exit;

  cd := @Drives[DriveIndex];
  if not cd^.Present then Exit;
  
  // D?ZELTME: FS_ISO9660 kontrol? kald?r?ld?, ??nk? ISO_Mount'da zaten ayarlanm??
  // ama emin olmak i?in kontrol edelim
  if cd^.FileSystem <> FS_ISO9660 then Exit;

  FillChar(CDB, SizeOf(CDB), 0);
  CDB[0] := SCSI_READ_CAPACITY;  // $25
  CDB[1] := 0;
  CDB[2] := 0;
  CDB[3] := 0;
  CDB[4] := 0;
  CDB[5] := 0;
  CDB[6] := 0;
  CDB[7] := 0;
  CDB[8] := 0;
  CDB[9] := 0;
  CDB[10] := 0;
  CDB[11] := 0;

  FillChar(Buf, SizeOf(Buf), 0);
  
  if ATAPI_SendPacket(cd^.ATAPort, cd^.DriveNum, CDB, 8, @Buf[0], 2) then
  begin
    // Big-endian d?n???m
    LastLBA   := (LongWord(Buf[0]) shl 24) or (LongWord(Buf[1]) shl 16) or
                 (LongWord(Buf[2]) shl 8)  or  LongWord(Buf[3]);
    BlockSize := (LongWord(Buf[4]) shl 24) or (LongWord(Buf[5]) shl 16) or
                 (LongWord(Buf[6]) shl 8)  or  LongWord(Buf[7]);
    Result := True;
  end;
end;

//===========================================================================
// ATAPI_GetProductInfo  Yeni: Model ve Manufacturer bilgisi al
//===========================================================================
procedure ATAPI_GetProductInfo(DriveIndex: Integer; Model: PChar; Manufacturer: PChar);
var
  cd: PDriveInfo;
  i: Integer;
  src: PByte;
begin
  cd := @Drives[DriveIndex];
  
  if Model <> nil then
  begin
    StrCopy(Model, 'Unknown ATAPI Device');
    if cd^.ISOModel[0] <> #0 then
      StrCopy(Model, @cd^.ISOModel[0]);
  end;
  
  if Manufacturer <> nil then
  begin
    // CD-ROM i?in "ISO 9660" yazabiliriz
    if cd^.FileSystem = FS_ISO9660 then
      StrCopy(Manufacturer, 'CD-ROM (ISO 9660)')
    else
      StrCopy(Manufacturer, 'ATAPI Device');
  end;
end;

//===========================================================================
// FAT32_GetDriveSpace  D?ZELTME: CD-ROM ve HDD bilgisi tam olarak
//===========================================================================
function FAT32_GetDriveSpace(DriveIndex: Integer; var Info: TDriveSpaceInfo): Boolean;
var
  drv: PDriveInfo;
  fatSector: LongWord;
  i: Integer;
  P: PLongWord;
  totalClusters: LongWord;
  freeClusters: LongWord;
  entriesPerSec: Integer;
  lastLBA: LongWord;
  blockSize: LongWord;
  totalSectors: LongWord;
begin
  Result := False;
  if (DriveIndex < 0) or (DriveIndex >= DriveCount) then Exit;

  drv := @Drives[DriveIndex];
  Info.DriveLetter := drv^.Letter;

  // ==================== ISO 9660 (CD-ROM) ====================
  if drv^.FileSystem = FS_ISO9660 then
  begin
    // Kapasite bilgisi al (sorun burada olabilir)
    if ATAPI_ReadCapacity(DriveIndex, lastLBA, blockSize) then
    begin
      if blockSize = 0 then blockSize := 2048;
      totalSectors := lastLBA + 1;
      
      Info.IsFAT32       := False;
      Info.BytesPerClus  := blockSize;
      Info.TotalClusters := totalSectors;
      Info.FreeClusters  := 0;                    // Read-only
      Info.UsedClusters  := totalSectors;
      Info.TotalKB       := (totalSectors * blockSize) div 1024;
      Info.FreeKB        := 0;
      Info.UsedKB        := Info.TotalKB;
      Info.TotalMB       := Info.TotalKB div 1024;
      Info.FreeMB        := 0;
      Info.UsedMB        := Info.TotalMB;
      Result := True;
    end
    else
    begin
      // READ CAPACITY ba?ar?s?z oldu, ISORootSize'? kullan
      Info.IsFAT32       := False;
      Info.BytesPerClus  := 2048;
      Info.TotalClusters := (drv^.ISORootSize + 2047) div 2048;
      Info.FreeClusters  := 0;
      Info.UsedClusters  := Info.TotalClusters;
      Info.TotalKB       := (drv^.ISORootSize) div 1024;
      Info.FreeKB        := 0;
      Info.UsedKB        := Info.TotalKB;
      Info.TotalMB       := Info.TotalKB div 1024;
      Info.FreeMB        := 0;
      Info.UsedMB        := Info.TotalMB;
      Result := True;
    end;
    Exit;
  end;

  // ==================== FAT32 (HDD) ====================
  if drv^.FileSystem <> FS_FAT32 then Exit;

  Info.IsFAT32     := True;
  Info.BytesPerClus := drv^.BytesPerClus;

  totalClusters := (drv^.BPB.TotSec32 - drv^.DataStart) div drv^.SecPerClus;
  freeClusters := 0;
  entriesPerSec := SECTOR_SIZE div 4;

  fatSector := drv^.FATStart;
  while fatSector < drv^.FATStart + drv^.BPB.FATSz32 do
  begin
    if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then 
      Break;
    
    for i := 0 to entriesPerSec - 1 do
    begin
      P := PLongWord(@SectorBuf[i * 4]);
      if (P^ and $0FFFFFFF) = FAT32_FREE then
        Inc(freeClusters);
    end;
    Inc(fatSector);
  end;

  Info.TotalClusters := totalClusters;
  Info.FreeClusters  := freeClusters;
  Info.UsedClusters  := totalClusters - freeClusters;
  Info.TotalKB       := (totalClusters * drv^.BytesPerClus) div 1024;
  Info.FreeKB        := (freeClusters * drv^.BytesPerClus) div 1024;
  Info.UsedKB        := Info.TotalKB - Info.FreeKB;
  Info.TotalMB       := Info.TotalKB div 1024;
  Info.FreeMB        := Info.FreeKB div 1024;
  Info.UsedMB        := Info.UsedKB div 1024;
  Result := True;
end;

//===========================================================================
// Model ve Manufacturer bilgisini g?stermek i?in utility function
//===========================================================================
procedure GetDriveInfo(DriveIndex: Integer; Model: PChar; Manufacturer: PChar; 
                       FileSystemType: PChar);
var
  drv: PDriveInfo;
begin
  if (DriveIndex < 0) or (DriveIndex >= DriveCount) then Exit;
  
  drv := @Drives[DriveIndex];
  
  if Model <> nil then
  begin
    if drv^.FileSystem = FS_ISO9660 then
      StrCopy(Model, @drv^.ISOModel[0])
    else if drv^.FileSystem = FS_FAT32 then
      StrCopy(Model, @drv^.BPB.OEMName[0])
    else
      StrCopy(Model, 'Unknown');
  end;
  
  if Manufacturer <> nil then
  begin
    case drv^.FileSystem of
      FS_FAT32:
        StrCopy(Manufacturer, 'HDD (FAT32)');
      FS_ISO9660:
        StrCopy(Manufacturer, 'CD-ROM (ISO 9660)');
    else
      StrCopy(Manufacturer, 'Unknown');
    end;
  end;
  
  if FileSystemType <> nil then
  begin
    case drv^.FileSystem of
      FS_FAT32:
        StrCopy(FileSystemType, 'FAT32');
      FS_ISO9660:
        StrCopy(FileSystemType, 'ISO 9660');
    else
      StrCopy(FileSystemType, 'Unknown');
    end;
  end;
end;



end.

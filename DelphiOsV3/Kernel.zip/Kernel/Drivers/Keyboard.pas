Unit KeyBoard;

interface
Uses
   SysUtils, Vesa, Idt, Pit, Ports, Intr32;

const
  // Sanal kodlar (Windows uyumlu)
  VK_LBUTTON        = $01; VK_RBUTTON        = $02; VK_CANCEL         = $03;
  VK_MBUTTON        = $04; VK_BACK           = $08; VK_TAB            = $09;
  VK_CLEAR          = $0C; VK_RETURN         = $0D; VK_SHIFT          = $10;
  VK_CONTROL        = $11; VK_MENU           = $12; VK_PAUSE          = $13;
  VK_CAPITAL        = $14; VK_ESCAPE         = $1B; VK_SPACE          = $20;
  VK_PRIOR          = $21; VK_NEXT           = $22; VK_END            = $23;
  VK_HOME           = $24; VK_LEFT           = $25; VK_UP             = $26;
  VK_RIGHT          = $27; VK_DOWN           = $28; VK_SELECT         = $29;
  VK_PRINT          = $2A; VK_EXECUTE        = $2B; VK_SNAPSHOT       = $2C;
  VK_INSERT         = $2D; VK_DELETE         = $2E; VK_HELP           = $2F;
  VK_0 = $30; VK_1 = $31; VK_2 = $32; VK_3 = $33; VK_4 = $34;
  VK_5 = $35; VK_6 = $36; VK_7 = $37; VK_8 = $38; VK_9 = $39;
  VK_A = $41; // ... VK_Z = $5A
  VK_LWIN           = $5B; VK_RWIN           = $5C; VK_APPS           = $5D;
  VK_NUMPAD0        = $60; VK_NUMPAD1        = $61; VK_NUMPAD2        = $62;
  VK_NUMPAD3        = $63; VK_NUMPAD4        = $64; VK_NUMPAD5        = $65;
  VK_NUMPAD6        = $66; VK_NUMPAD7        = $67; VK_NUMPAD8        = $68;
  VK_NUMPAD9        = $69; VK_MULTIPLY       = $6A; VK_ADD            = $6B;
  VK_SEPARATOR      = $6C; VK_SUBTRACT       = $6D; VK_DECIMAL        = $6E;
  VK_DIVIDE         = $6F; VK_F1             = $70; VK_F2             = $71;
  VK_F3             = $72; VK_F4             = $73; VK_F5             = $74;
  VK_F6             = $75; VK_F7             = $76; VK_F8             = $77;
  VK_F9             = $78; VK_F10            = $79; VK_F11            = $7A;
  VK_F12            = $7B; VK_NUMLOCK        = $90; VK_SCROLL         = $91;
  VK_LSHIFT         = $A0; VK_RSHIFT         = $A1; VK_LCONTROL       = $A2;
  VK_RCONTROL       = $A3; VK_LMENU          = $A4; VK_RMENU          = $A5;

  // Scan code'lar
  SC_LSHIFT  = $2A;
  SC_RSHIFT  = $36;
  SC_CAPS    = $3A;
  SC_CTRL    = $1D;
  SC_ALT     = $38;
  SC_RELEASE = $80;

keyboard_base: array[0..57] of Char = (   // harf olmayanlar
  #0, #27,'1','2','3','4','5','6','7','8','9','0','-','=',#8,
  #9,#0,#0,#0,#0,#0,#0,#0,#0,#0,#0,'[',']',#13,#0,
  #0,#0,#0,#0,#0,#0,#0,#0,#0,';','''','`',#0,'\',
  #0,#0,#0,#0,#0,#0,#0,',','.','/',#0,'*',#0,' '
);

keyboard_shift: array[0..57] of Char = (  // shift bas l 
  #0, #27,'!','@','#','$','%','^','&','*','(',')','_','+',#8,
  #9,#0,#0,#0,#0,#0,#0,#0,#0,#0,#0,'{','}',#13,#0,
  #0,#0,#0,#0,#0,#0,#0,#0,#0,':','"','~',#0,'|',
  #0,#0,#0,#0,#0,#0,#0,'<','>','?',#0,'*',#0,' '
);

keyboard_letter: array[0..57] of Char = ( // k   k harf
  #0,#0,#0,#0,#0,#0,#0,#0,#0,#0,#0,#0,#0,#0,#0,
  #0,'q','w','e','r','t','y','u','i','o','p',#0,#0,#0,#0,
  'a','s','d','f','g','h','j','k','l',#0,#0,#0,#0,#0,
  'z','x','c','v','b','n','m',#0,#0,#0,#0,#0,#0,#0
);


var
  ShiftDown:    Boolean = False;   // Herhangi bir Shift basili mi?
  LShiftDown:   Boolean = False;   // Sol Shift
  RShiftDown:   Boolean = False;   // Sag Shift
  CtrlDown:     Boolean = False;   // Herhangi bir Ctrl
  AltDown:      Boolean = False;   // Herhangi bir Alt
  CapsOn:       Boolean = False;
  LastWasE0:    Boolean = False;   // Bir onceki scan code $E0 miydi?
  KeyReady:     Word;              // Son basilan tus (VK veya ASCII)

  procedure Keyboard_Init();

implementation
Uses GUI;

{-----------------------------------------------------------------------------}
{ Scan code -> Virtual Key donusumu }
{-----------------------------------------------------------------------------}
function ScanCodeToVK(ScanCode: Byte; Extended: Boolean): Word;
begin
  Result := 0;
  if Extended then
  begin
    case ScanCode of
      $1D: Result := VK_RCONTROL;
      $38: Result := VK_RMENU;
      $47: Result := VK_HOME;
      $48: Result := VK_UP;
      $49: Result := VK_PRIOR;
      $4B: Result := VK_LEFT;
      $4D: Result := VK_RIGHT;
      $4F: Result := VK_END;
      $50: Result := VK_DOWN;
      $51: Result := VK_NEXT;
      $52: Result := VK_INSERT;
      $53: Result := VK_DELETE;
      $5B: Result := VK_LWIN;
      $5C: Result := VK_RWIN;
      $5D: Result := VK_APPS;
    end;
  end
  else
  begin
    case ScanCode of
      $01: Result := VK_ESCAPE;
      $0E: Result := VK_BACK;
      $0F: Result := VK_TAB;
      $1C: Result := VK_RETURN;
      $1D: Result := VK_CONTROL;   // Sol Ctrl
      $38: Result := VK_MENU;      // Sol Alt
      $3B: Result := VK_F1;
      $3C: Result := VK_F2;
      $3D: Result := VK_F3;
      $3E: Result := VK_F4;
      $3F: Result := VK_F5;
      $40: Result := VK_F6;
      $41: Result := VK_F7;
      $42: Result := VK_F8;
      $43: Result := VK_F9;
      $44: Result := VK_F10;
      $47: Result := VK_HOME;      // Numpad (NumLock off)
      $48: Result := VK_UP;
      $49: Result := VK_PRIOR;
      $4A: Result := VK_SUBTRACT;  // Numpad -
      $4B: Result := VK_LEFT;
      $4C: Result := VK_CLEAR;     // Numpad 5
      $4D: Result := VK_RIGHT;
      $4E: Result := VK_ADD;       // Numpad +
      $4F: Result := VK_END;
      $50: Result := VK_DOWN;
      $51: Result := VK_NEXT;
      $52: Result := VK_INSERT;
      $53: Result := VK_DELETE;
      $57: Result := VK_F11;
      $58: Result := VK_F12;
    end;
  end;
end;

{-----------------------------------------------------------------------------}
{ Event yoneticileri }
{-----------------------------------------------------------------------------}
procedure KeyDownEvent(Key: Word);
begin
  KeyReady := Key;
  WinManager.KeyDown(Key);
end;

procedure KeyUpEvent(Key: Word);
begin
  // Ileride KeyUp destegi eklenirse buraya
   WinManager.KeyUp(Key);
end;

{-----------------------------------------------------------------------------}
{ IRQ Handler }
{-----------------------------------------------------------------------------}
procedure KeyboardIRQ;
var
  sc: Byte;
  released: Boolean;
  base: Byte;
  vk: Word;
  ch: Char;
begin
  sc := ReadPortB($60);

  // ---- Extended prefix ($E0) ----
  if sc = $E0 then
  begin
    LastWasE0 := True;
    WritePortB($20, $20);
    Exit;
  end;

  released := (sc and $80) <> 0;
  base     := sc and $7F;

  // ---- Modifier tuslar (Shift, Ctrl, Alt, Caps) ----
  case base of
    SC_LSHIFT:
      begin
        LShiftDown := not released;
        ShiftDown  := LShiftDown or RShiftDown;
        LastWasE0 := False;
        WritePortB($20, $20);
        Exit;
      end;
    SC_RSHIFT:
      begin
        RShiftDown := not released;
        ShiftDown  := LShiftDown or RShiftDown;
        LastWasE0 := False;
        WritePortB($20, $20);
        Exit;
      end;
    SC_CTRL:
      begin
        if LastWasE0 then
        begin
          // Extended Ctrl (sag Ctrl) ayri takip edilebilir
        end;
        CtrlDown := not released;
        LastWasE0 := False;
        WritePortB($20, $20);
        Exit;
      end;
    SC_ALT:
      begin
        AltDown := not released;
        LastWasE0 := False;
        WritePortB($20, $20);
        Exit;
      end;
    SC_CAPS:
      begin
        if not released then CapsOn := not CapsOn;
        LastWasE0 := False;
        WritePortB($20, $20);
        Exit;
      end;
  end;

 
 // ---- Release event ----
  if released then
  begin
  vk := ScanCodeToVK(base, LastWasE0);

  if vk <> 0 then
  begin
    // �zel tu� (F1-F12, oklar, Home/End vb.) � direkt VK kodu
    KeyUpEvent(vk);
  end
  else
  begin
    // Normal karakter � KeyDown ile AYNI d�n���m mant���n� kullan
    if base <= High(keyboard_base) then
    begin
      if keyboard_letter[base] <> #0 then
      begin
        ch := keyboard_letter[base];
        // Shift durumu: KeyDown an�ndaki durum ne idiyse ayn�s�
        // (Released an�nda Shift h�l� bas�l� olabilir, tutarl� olsun)
        if ShiftDown xor CapsOn then
          ch := Chr(Ord(ch) - 32);
      end
      else
      begin
        if ShiftDown then
          ch := keyboard_shift[base]
        else
          ch := keyboard_base[base];
      end;

      if ch <> #0 then
        KeyUpEvent($100 + Word(ch));  // KeyDown ile ayn� format
    end;
  end;

    LastWasE0 := False;
    WritePortB($20, $20);
    Exit;
  end;

  // ---- Once VK kodunu dene (F1-F12, Oklar, Home/End/Ins/Del/PgUp/PgDn) ----
  vk := ScanCodeToVK(base, LastWasE0);
  if vk <> 0 then
  begin
    KeyDownEvent(vk);
    LastWasE0 := False;
    WritePortB($20, $20);
    Exit;
  end;

  // ---- Normal karakter donusumu (Harf, Rakam, Sembol) ----
  if base > High(keyboard_base) then
  begin
    LastWasE0 := False;
    WritePortB($20, $20);
    Exit;
  end;

  if keyboard_letter[base] <> #0 then
  begin
    ch := keyboard_letter[base];
    if ShiftDown xor CapsOn then
      ch := Chr(Ord(ch) - 32); // a..z -> A..Z
  end
  else
  begin
    if ShiftDown then
      ch := keyboard_shift[base]
    else
      ch := keyboard_base[base];
  end;

  if ch <> #0 then
    KeyDownEvent($100 + Word(ch));

  LastWasE0 := False;
  WritePortB($20, $20);
end;

{-----------------------------------------------------------------------------}
{ Init }
{-----------------------------------------------------------------------------}
procedure Keyboard_Init;
begin
  RegisterISR(33, @KeyboardIRQ);
  CapsOn := False;
  ShiftDown := False;
  LShiftDown := False;
  RShiftDown := False;
  CtrlDown := False;
  AltDown := False;
  LastWasE0 := False;
end;

end.

unit CDROM;

interface

Uses
  SysUtils, Vesa, Idt, Pit, Ports,Memory, Intr32;

{ =========================================================
  CDROM.pas - ISO 9660 Dosya Sistemi (CD-ROM)
  
  �zellikler:
  - ATAPI protocol (ATA paketli komutlar)
  - ISO 9660 parsing
  - ReadFile, SeekFile (Sadece OKU - CD-ROM salt okunurdur)
  - FindFirst, FindNext (Dosya tarama)
  - Multi-session CD deste�i
  ========================================================= }

const
    // File open mode
  FILE_READ        = $01;
  FILE_WRITE       = $02;
  FILE_CREATE      = $04;
  FILE_APPEND      = $08;
  
  // Seek mode
  SEEK_SET         = 0;
  SEEK_CUR         = 1;
  SEEK_END         = 2;

const
  // ATAPI komutlar�
  ATAPI_CMD_IDENTIFY     = $A1;
  ATAPI_CMD_READ_CAPACITY= $25;
  ATAPI_CMD_READ_SECTORS = $BE;
  ATAPI_CMD_REQUEST_SENSE= $03;
  
  // CD-ROM sektor boyutu
  CDROM_SECTOR_SIZE      = 2048;  // ISO 9660
  
  // ISO 9660 sabitleri
  ISO9660_PRIMARY_VOL    = 1;
  ISO9660_TERMINATOR     = 255;
  MAX_CDROM_DRIVES       = 2;
  
  // CD dosya �zellikleri
  FILE_FLAG_DIRECTORY    = $02;
  FILE_FLAG_FILE         = $00;

type
  // ATAPI Drive bilgileri
  PCDROMDriveInfo = ^TCDROMDriveInfo;
  TCDROMDriveInfo = record
    Present:        Boolean;
    ATAPort:        Word;
    DriveNum:       Byte;      // 0=master, 1=slave
    Letter:         Char;      // Drive letter (G, H...)
    Capacity:       LongWord;  // Toplam sektor say�s�
    
    // ISO 9660 bilgileri
    IsISO9660:      Boolean;
    VolumeLabel:    array[0..31] of Char;
    RootDirLBA:     LongWord;
    RootDirSize:    LongWord;
  end;
  
  // ISO 9660 Primary Volume Descriptor
  PISO9660_PVD = ^TISO9660_PVD;
  TISO9660_PVD = packed record
    DescType:       Byte;           // $01 = Primary
    StdId:          array[0..4] of Char;  // "CD001"
    Version:        Byte;           // $01
    Reserved1:      Byte;
    SystemId:       array[0..31] of Char;
    VolumeId:       array[0..31] of Char;
    Reserved2:      array[0..7] of Byte;
    SpaceSize_LE:   LongWord;       // Little-endian
    SpaceSize_BE:   LongWord;       // Big-endian
    Reserved3:      array[0..32] of Byte;
    VolSetSize_LE:  Word;
    VolSetSize_BE:  Word;
    VolSeqNum_LE:   Word;
    VolSeqNum_BE:   Word;
    LogicalBlkSz_LE: Word;          // Normalde 2048
    LogicalBlkSz_BE: Word;
    PathTableSize_LE: LongWord;
    PathTableSize_BE: LongWord;
    PathTableL:     LongWord;       // Type-L path table LBA
    PathTableOptL:  LongWord;       // Optional Type-L
    PathTableM:     LongWord;       // Type-M (big-endian) LBA
    PathTableOptM:  LongWord;       // Optional Type-M
    RootDirRecord:  array[0..33] of Byte;  // Root directory record
    // ... geri kalan alanlar ...
  end;
  
  // ISO 9660 Dosya/Dizin Kayd�
  PISO9660_DirEntry = ^TISO9660_DirEntry;
  TISO9660_DirEntry = packed record
    DirRecLen:      Byte;           // Kay�t uzunlu�u
    ExtAttrLen:     Byte;
    LocationLBA_LE: LongWord;       // Little-endian LBA
    LocationLBA_BE: LongWord;       // Big-endian LBA
    DataLen_LE:     LongWord;       // Dosya boyutu (LE)
    DataLen_BE:     LongWord;       // Dosya boyutu (BE)
    RecordTime:     array[0..6] of Byte;
    FileFlags:      Byte;           // Bit 1 = directory
    FileUnitSize:   Byte;
    InterleaveSize: Byte;
    VolSeqNum_LE:   Word;
    VolSeqNum_BE:   Word;
    NameLen:        Byte;
    Name:           array[0..255] of Char;
  end;
  
  // CD-ROM dosya handle (FAT32 ile uyumlu)
  PCDFileHandle = ^TCDFileHandle;
  TCDFileHandle = record
    Used:           Boolean;
    DriveIndex:     Integer;
    Mode:           Byte;           // Sadece FILE_READ
    
    FileSize:       LongWord;
    FilePos:        LongWord;
    StartLBA:       LongWord;
    CurrentSector:  LongWord;
    SectorOffset:   LongWord;
    
    Buffer:         array[0..CDROM_SECTOR_SIZE-1] of Byte;
    
    Name:           array[0..MAX_PATH-1] of Char;
  end;
  
  // CDROM Find handle
  PCDFindHandle = ^TCDFindHandle;
  TCDFindHandle = record
    Used:           Boolean;
    DriveIndex:     Integer;
    SearchPattern:  array[0..MAX_PATH-1] of Char;
    
    CurrentDirLBA:  LongWord;
    CurrentDirSize: LongWord;
    BytePos:        LongWord;
  end;
  
  // CDROM Search record (FAT32 TSearchRec ile uyumlu)
  PCDSearchRec = ^TCDSearchRec;
  TCDSearchRec = record
    Name:           array[0..MAX_PATH-1] of Char;
    Attr:           Byte;           // ATTR_DIRECTORY veya ATTR_ARCHIVE
    FileSize:       LongWord;
    StartLBA:       LongWord;
    IsDir:          Boolean;
  end;

var
  CDROMDrives:    array[0..MAX_CDROM_DRIVES-1] of TCDROMDriveInfo;
  CDROMDriveCount: Integer;
  CDOpenFiles:    array[0..15] of TCDFileHandle;
  CDFindHandles:  array[0..7] of TCDFindHandle;
  CDBuf:          array[0..CDROM_SECTOR_SIZE-1] of Byte;

// Procedure/Function tan�mlar�
procedure CDROM_Init;
procedure CDROM_ScanDrives;
procedure CDROM_MountDrive(DriveIndex: Integer);

function CDROM_ReadSector(Port: Word; DriveNum: Byte; LBA: LongWord;
                          Buffer: Pointer; Count: Byte): Boolean;

function CDROM_OpenFile(Path: PChar; Mode: Byte): Integer;
function CDROM_ReadFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
function CDROM_SeekFile(Handle: Integer; Offset: LongInt; Origin: Byte): LongWord;
function CDROM_FilePos(Handle: Integer): LongWord;
function CDROM_FileSize(Handle: Integer): LongWord;
procedure CDROM_CloseFile(Handle: Integer);

function CDROM_FindFirst(Path, Pattern: PChar; Attr: Byte;
                         SearchRec: PCDSearchRec): Integer;
function CDROM_FindNext(FindHandle: Integer; SearchRec: PCDSearchRec): Boolean;
procedure CDROM_FindClose(FindHandle: Integer);

function CDROM_GetDriveFromPath(Path: PChar): Integer;

implementation

//=============================================================================
// Port I/O (ATAPI - FAT32 ile ortakla�t�r�labilir)
//=============================================================================

function InByte(Port: Word): Byte;
begin
  asm
    mov dx, Port
    in  al, dx
    mov Result, al
  end;
end;

procedure OutByte(Port: Word; Value: Byte);
begin
  asm
    mov dx, Port
    mov al, Value
    out dx, al
  end;
end;

function InWord(Port: Word): Word;
begin
  asm
    mov dx, Port
    in  ax, dx
    mov Result, ax
  end;
end;

procedure OutWord(Port: Word; Value: Word);
begin
  asm
    mov dx, Port
    mov ax, Value
    out dx, ax
  end;
end;

//=============================================================================
// ATAPI Driver
//=============================================================================

procedure ATAPI_Delay(Port: Word);
var
  i: Integer;
begin
  i := 0;
  while i < 4 do
  begin
    InByte(Port + 7);
    Inc(i);
  end;
end;

function ATAPI_WaitBSY(Port: Word): Boolean;
var
  timeout: Integer;
  status: Byte;
begin
  Result := False;
  timeout := 100000;
  
  while timeout > 0 do
  begin
    status := InByte(Port + 7);
    if (status and $80) = 0 then  // BSY bit 7
    begin
      Result := True;
      Exit;
    end;
    Dec(timeout);
  end;
end;

function ATAPI_WaitDRQ(Port: Word): Boolean;
var
  timeout: Integer;
  status: Byte;
begin
  Result := False;
  timeout := 100000;
  
  while timeout > 0 do
  begin
    status := InByte(Port + 7);
    
    if (status and $01) <> 0 then Exit;  // ERR
    if (status and $08) <> 0 then        // DRQ
    begin
      Result := True;
      Exit;
    end;
    Dec(timeout);
  end;
end;

//=============================================================================
// ATAPI IDENTIFY
//=============================================================================

function ATAPI_Identify(Port: Word; DriveNum: Byte; var IsATAPI: Boolean): Boolean;
var
  identBuf: array[0..255] of Word;
  i: Integer;
  status: Byte;
begin
  Result := False;
  IsATAPI := False;
  
  // Select drive
  OutByte(Port + 6, $A0 or (DriveNum shl 4));
  ATAPI_Delay(Port);
  
  status := InByte(Port + 7);
  if status = 0 then Exit;  // No drive
  
  // Clear LBA regs
  OutByte(Port + 2, 0);
  OutByte(Port + 3, 0);
  OutByte(Port + 4, 0);
  OutByte(Port + 5, 0);
  
  // IDENTIFY command
  OutByte(Port + 7, $EC);
  
  ATAPI_Delay(Port);
  
  status := InByte(Port + 7);
  if status = 0 then Exit;
  
  if not ATAPI_WaitBSY(Port) then Exit;
  
  // ATAPI CFA code check (word 0, bits 0-7)
  // ATAPI devices report specific signature
  if (InByte(Port + 4) <> 0) or (InByte(Port + 5) <> 0) then
  begin
    IsATAPI := True;  // ATAPI device detected
    Result := True;
    Exit;
  end;
  
  Result := True;  // ATA device
end;

//=============================================================================
// ATAPI READ (CDROM)
//=============================================================================

function CDROM_ReadSector(Port: Word; DriveNum: Byte; LBA: LongWord;
                          Buffer: Pointer; Count: Byte): Boolean;
var
  i: Integer;
  P: PWord;
  status: Byte;
  byteCount: Word;
  packet: array[0..11] of Byte;
begin
  Result := False;
  
  if not ATAPI_WaitBSY(Port) then Exit;
  
  // SET FEATURES - DMA disable
  OutByte(Port + 1, 0);       // Feature
  OutByte(Port + 2, 0);       // Sector count
  OutByte(Port + 4, 0);       // LBA Mid
  OutByte(Port + 5, 0);       // LBA High
  OutByte(Port + 7, $EF);     // SET FEATURES
  
  ATAPI_Delay(Port);
  
  // Setup command packet (12 bytes)
  packet[0] := $BE;           // READ CD command
  packet[1] := 0;             // Reserved
  packet[2] := Byte(LBA shr 24);
  packet[3] := Byte(LBA shr 16);
  packet[4] := Byte(LBA shr 8);
  packet[5] := Byte(LBA);
  packet[6] := 0;             // Transfer length hi
  packet[7] := 0;
  packet[8] := Byte(Count);   // Transfer length lo (sektor say�s�)
  packet[9] := $10;           // Sector type: all
  packet[10] := 0;            // Reserved
  packet[11] := 0;            // Reserved
  
  // Setup drive
  OutByte(Port + 6, $A0 or (DriveNum shl 4));
  OutByte(Port + 4, Byte(CDROM_SECTOR_SIZE));     // Low byte
  OutByte(Port + 5, Byte(CDROM_SECTOR_SIZE shr 8)); // High byte
  
  // Send PACKET command
  OutByte(Port + 7, $A0);     // PACKET command
  
  ATAPI_Delay(Port);
  
  if not ATAPI_WaitDRQ(Port) then Exit;
  
  // Send packet
  P := PWord(@packet[0]);
  i := 0;
  while i < 6 do  // 12 bytes = 6 words
  begin
    OutWord(Port, P^);
    Inc(P);
    Inc(i);
  end;
  
  // Wait for data
  if not ATAPI_WaitDRQ(Port) then Exit;
  
  // Okuma
  P := PWord(Buffer);
  i := 0;
  while i < (Count * CDROM_SECTOR_SIZE div 2) do
  begin
    P^ := InWord(Port);
    Inc(P);
    Inc(i);
  end;
  
  Result := True;
end;

//=============================================================================
// ISO 9660 Parsing
//=============================================================================

function CDROM_ExtractString(Src: PChar; Len: Integer): PChar;
var
  i: Integer;
  P: PChar;
begin
  P:=StrAlloc( Len + 1);
  i := 0;
  while i < Len do
  begin
    P[i] := Src[i];
    Inc(i);
  end;
  P[Len] := #0;
  Result := P;
end;

procedure CDROM_MountDrive(DriveIndex: Integer);
var
  drv: PCDROMDriveInfo;
  pvd: PISO9660_PVD;
  i: Integer;
begin
  drv := @CDROMDrives[DriveIndex];
  
  // Sektor 16'da Primary Volume Descriptor
  if not CDROM_ReadSector(drv^.ATAPort, drv^.DriveNum, 16, @CDBuf[0], 1) then
    Exit;
  
  pvd := PISO9660_PVD(@CDBuf[0]);
  
  // Check signature
  if pvd^.DescType <> 1 then Exit;  // Not Primary
  if (pvd^.StdId[0] <> 'C') or (pvd^.StdId[1] <> 'D') then Exit;
  
  // ISO 9660 detected
  drv^.IsISO9660 := True;
  
  // Volume label
  i := 0;
  while i < 32 do
  begin
    drv^.VolumeLabel[i] := pvd^.VolumeId[i];
    Inc(i);
  end;
  
  // Root directory info
  drv^.RootDirLBA := pvd^.RootDirRecord[2] or
                     (pvd^.RootDirRecord[3] shl 8) or
                     (pvd^.RootDirRecord[4] shl 16) or
                     (pvd^.RootDirRecord[5] shl 24);
  
  drv^.RootDirSize := pvd^.RootDirRecord[10] or
                      (pvd^.RootDirRecord[11] shl 8) or
                      (pvd^.RootDirRecord[12] shl 16) or
                      (pvd^.RootDirRecord[13] shl 24);
end;

//=============================================================================
// CDROM Drive Scan
//=============================================================================

procedure CDROM_ScanDrives;
var
  ports: array[0..1] of Word;
  driveNums: array[0..1] of Byte;
  portCount: Integer;
  driveCount2: Integer;
  i, j: Integer;
  port: Word;
  driveNum: Byte;
  isATAPI: Boolean;
  driveInfo: PCDROMDriveInfo;
  letters: array[0..3] of Char;
begin
  CDROMDriveCount := 0;
  
  ports[0] := $01F0;
  ports[1] := $0170;
  portCount := 2;
  
  driveNums[0] := 0;
  driveNums[1] := 1;
  driveCount2 := 2;
  
  letters[0] := 'G';  // HDD'den sonras�
  letters[1] := 'H';
  letters[2] := 'I';
  letters[3] := 'J';
  
  i := 0;
  while (i < portCount) and (CDROMDriveCount < MAX_CDROM_DRIVES) do
  begin
    port := ports[i];
    
    j := 0;
    while (j < driveCount2) and (CDROMDriveCount < MAX_CDROM_DRIVES) do
    begin
      driveNum := j;
      
      if ATAPI_Identify(port, driveNum, isATAPI) and isATAPI then
      begin
        driveInfo := @CDROMDrives[CDROMDriveCount];
        
        MemSet(driveInfo, 0, SizeOf(TCDROMDriveInfo));
        
        driveInfo^.Present := True;
        driveInfo^.ATAPort := port;
        driveInfo^.DriveNum := driveNum;
        driveInfo^.Letter := letters[CDROMDriveCount];
        
        // Mount ISO 9660
        CDROM_MountDrive(CDROMDriveCount);
        
        Inc(CDROMDriveCount);
      end;
      
      Inc(j);
    end;
    
    Inc(i);
  end;
end;

//=============================================================================
// File Operations
//=============================================================================

function CDROM_GetDriveFromPath(Path: PChar): Integer;
var
  i: Integer;
begin
  Result := -1;
  
  if Path = nil then Exit;
  
  if (StrLen(Path) >= 3) and (Path[1] = ':') then
  begin
    i := 0;
    while i < CDROMDriveCount do
    begin
      if StrUpChar(CDROMDrives[i].Letter) = StrUpChar(Path[0]) then
      begin
        Result := i;
        Exit;
      end;
      Inc(i);
    end;
  end
  else
  begin
    if CDROMDriveCount > 0 then
      Result := 0;
  end;
end;

function CDROM_AllocHandle: Integer;
var
  i: Integer;
begin
  Result := -1;
  i := 0;
  while i < 15 do
  begin
    if not CDOpenFiles[i].Used then
    begin
      Result := i;
      Exit;
    end;
    Inc(i);
  end;
end;

function CDROM_OpenFile(Path: PChar; Mode: Byte): Integer;
begin
  Result := -1;
  // CD-ROM salt okunur - sadece FILE_READ desteklenir
  if (Mode and FILE_READ) = 0 then Exit;
  
  // TODO: Path parsing ve file location bulma
  // �imdilik placeholder
end;

function CDROM_ReadFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
begin
  Result := 0;
  if (Handle < 0) or (Handle >= 15) then Exit;
  
  // TODO: Buffer okuma
end;

function CDROM_SeekFile(Handle: Integer; Offset: LongInt; Origin: Byte): LongWord;
begin
  Result := $FFFFFFFF;
  if (Handle < 0) or (Handle >= 15) then Exit;
  
  // TODO: Seek implement
end;

function CDROM_FilePos(Handle: Integer): LongWord;
begin
  Result := 0;
  if (Handle < 0) or (Handle >= 15) then Exit;
  if not CDOpenFiles[Handle].Used then Exit;
  Result := CDOpenFiles[Handle].FilePos;
end;

function CDROM_FileSize(Handle: Integer): LongWord;
begin
  Result := 0;
  if (Handle < 0) or (Handle >= 15) then Exit;
  if not CDOpenFiles[Handle].Used then Exit;
  Result := CDOpenFiles[Handle].FileSize;
end;

procedure CDROM_CloseFile(Handle: Integer);
begin
  if (Handle < 0) or (Handle >= 15) then Exit;
  CDOpenFiles[Handle].Used := False;
end;

//=============================================================================
// Find Operations
//=============================================================================

function CDROM_FindFirst(Path, Pattern: PChar; Attr: Byte;
                         SearchRec: PCDSearchRec): Integer;
begin
  Result := -1;
  // TODO: Find first implement
end;

function CDROM_FindNext(FindHandle: Integer; SearchRec: PCDSearchRec): Boolean;
begin
  Result := False;
  // TODO: Find next implement
end;

procedure CDROM_FindClose(FindHandle: Integer);
begin
  if (FindHandle < 0) or (FindHandle >= 7) then Exit;
  CDFindHandles[FindHandle].Used := False;
end;

//=============================================================================
// Init
//=============================================================================

procedure CDROM_Init;
var
  i: Integer;
begin
  i := 0;
  while i < MAX_CDROM_DRIVES do
  begin
    MemSet(@CDROMDrives[i], 0, SizeOf(TCDROMDriveInfo));
    Inc(i);
  end;
  
  i := 0;
  while i < 15 do
  begin
    CDOpenFiles[i].Used := False;
    Inc(i);
  end;
  
  i := 0;
  while i < 7 do
  begin
    CDFindHandles[i].Used := False;
    Inc(i);
  end;
  
  CDROMDriveCount := 0;
  
  // Scan for CDROM drives
  CDROM_ScanDrives;
end;

end.


Unit Vesa;

interface

  Uses
   SysUtils,Math,Intr32;


const
  BIOS_CONVENTIONAL_MEMORY = $10000;// $7E00;



  CharSetOrigin = PAnsiChar($F0000 + $FA6E);

  {
const
  BASE10_CHARACTERS: array[0..9] of Char =
    ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
  BASE16_CHARACTERS: array[0..15] of Char =
    ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    'A', 'B', 'C', 'D', 'E', 'F');
 }

 



   const
 // SCREEN_WIDTH = 1024;
  //SCREEN_HEIGHT = 768;

  FONT_WIDTH = 8;
  FONT_HEIGHT = 12;

  SCREEN_WIDTH = 1280;
  SCREEN_HEIGHT = 800;//960;//768;
  SCREEN_BPP = 24;
  SCREEN_DEPTH = 3; // 24-bit (3 byte per pixel)
  SCREEN_PITCH  = SCREEN_WIDTH * (SCREEN_BPP div 8);
  SCREEN_SIZE = SCREEN_WIDTH * SCREEN_HEIGHT * SCREEN_DEPTH;

 type
  TCharBitmap = array[0..7] of ShortInt;
  PCharBitmap = ^TCharBitmap;

  

 type
  PVesaMode = ^TVesaMode;
  TVesaMode = record
    Signature: array[0..3] of Byte;
    Version: Word;
    OEMStringPtr: array[0..1] of Word;
    Capabilities: array[0..3] of Byte;
    VideoModePtr: array[0..1] of Word;
    TotalMemory: Word;
  end;

  PVesaInfo = ^TVesaInfo;
  TVesaInfo = record
    ModeAttributes: Word;
    WinAAttributes: Byte;
    WinBAttributes: Byte;
    WinGranularity: Word;
    WinSize: Word;
    WinASegment: Word;
    WinBSegment: Word;
    WinFuncPtr: Pointer;
    BytesPerScanLine: Word;
    XResolution: Word;
    YResolution: Word;
    XCharSize: Byte;
    YCharSize: Byte;
    NumberOfPlanes: Byte;
    BitsPerPixel: Byte;
    NumberOfBanks: Byte;
    MemoryModel: Byte;
    BankSize: Byte;
    NumberOfImagePages: Byte;
    Reserved: Byte;
    RedMaskSize: Byte;
    RedFieldPosition: Byte;
    GreenMaskSize: Byte;
    GreenFieldPosition: Byte;
    BlueMaskSize: Byte;
    BlueFieldPosition: Byte;
    RsvdMaskSize: Byte;
    RsvdFieldPosition: Byte;
    DirectColorModeInfo: Byte;
    PhysBasePtr: DWord;
    OffScreenMemOffset: DWord;
    OffScreenMemSize: Word;
    Reserved2: array[0..205] of Byte;
  end;

  PScreen_Buffer = ^TScreen_Buffer;
  TScreen_Buffer= array [0..SCREEN_SIZE - 1] of Byte;  //   



var

   Vesa_Mode: TVesaMode;
   Vesa_Info: TVesaInfo;

   

   Screen_Buffer:TScreen_Buffer;
  
  


    PenX, PenY: Integer;


    function GetVesaInfo(): boolean;
    function Vesa_Init(): boolean;
    procedure PutPixel(x, y: Integer; color: integer = clWhite); OverLoad;
    procedure PutPixel(x, y: Integer; R,G,B:Byte); OverLoad;
    function ReadPixel(X, Y: Integer): TColor;
    procedure Cls(C: TColor);


    function RGBToColor(R, G, B: byte): TColor;
    procedure ColorToRGB(const Color: TColor; out R, G, B: Byte);
    procedure DrawRect(X,Y,W,H:Integer; C:TColor);
    procedure WriteStr(x, y: Integer; Text: PChar; Color: Integer = clWhite); 
    procedure WriteInt(X, Y: integer;i: Integer; Color:Integer=clWhite);
    procedure WriteChar(x, y: Integer; ch: Char; Color: Integer = clWhite);

    procedure DrawGradient(X, Y, Width, Height: Integer;
  StartColor, EndColor: TColor; Alpha: Byte; Direction: Boolean=False);

  procedure DrawCenterText(X, Y,W,H: Integer;Text:PChar;Color:TColor; Font: Byte = 0);
  procedure DrawTransparentRect(X, Y, W, H: Integer; C: TColor; Alpha: Byte);
  procedure MoveTo(X, Y: Integer);
  procedure LineTo(X, Y: Integer; Color: TColor);



implementation







function GetRValue(rgb: DWORD): Byte;

begin
 Result := Byte(rgb);
end;
 
function GetGValue(rgb: DWORD): Byte;
begin
 Result := Byte(rgb shr 8);
end;
 
function GetBValue(rgb: DWORD): Byte;
begin
 Result := Byte(rgb shr 16);
end;

function RGBToColor(R, G, B: byte): TColor;
begin
  Result := R + G shl 8 + B shl 16;
end;

procedure ColorToRGB(const Color: TColor; out R, G, B: Byte);
begin
  R := Color and $FF;
  G := (Color shr 8) and $FF;
  B := (Color shr 16) and $FF;
end;

procedure Cls(C: TColor);
var
  X, Y: Integer;
  buffer: PByteArray;
begin
   // Ekran� temizle
  for Y := 0 to SCREEN_HEIGHT - 1 do
  begin
    // Her sat�r i�in buffer adresini ayarla
    buffer := @Screen_Buffer[(Y * SCREEN_WIDTH) * SCREEN_DEPTH];
    // Her pikseli ayarla
    for X := 0 to SCREEN_WIDTH - 1 do
    begin
        buffer[X*SCREEN_DEPTH] := C and $FF;
        buffer[(X*SCREEN_DEPTH) + 1] := (C shr 8) and $FF;
        buffer[(X*SCREEN_DEPTH)+2 ] := (C shr 16) and $FF;
    end;
  end;
end;


procedure PutPixel(x, y: Integer; color: integer = clWhite); OverLoad;
var
  addr: integer;
  R, G, B: Byte;
begin
  if (X >= 0) and (X < SCREEN_WIDTH) and (Y >= 0) and (Y < SCREEN_HEIGHT) then
  begin
    addr := ((Y * SCREEN_WIDTH) + X) * (SCREEN_DEPTH);
    ColorToRGB(Color, R, G, B);
    Screen_Buffer[addr + 2] := R;
    Screen_Buffer[addr + 1] := G;
    Screen_Buffer[addr    ] := B;
  end;
end;

procedure PutPixel(x, y: Integer; R,G,B:Byte); OverLoad;
var
  addr: integer;
begin
  if (X >= 0) and (X < SCREEN_WIDTH) and (Y >= 0) and (Y < SCREEN_HEIGHT) then
  begin
    addr := ((Y * SCREEN_WIDTH) + X) * (SCREEN_DEPTH);
    Screen_Buffer[addr + 2] := R;
    Screen_Buffer[addr + 1] := G;
    Screen_Buffer[addr    ] := B;
  end;
end;


function ReadPixel(X, Y: Integer): TColor;
var
  addr: integer;
begin
   if (X >= 0) and (X < SCREEN_WIDTH) and (Y >= 0) and (Y < SCREEN_HEIGHT) then
   begin
     addr := ((Y * SCREEN_WIDTH) + X) * (SCREEN_DEPTH);
     Result := RGBToColor(Screen_Buffer[addr+2], Screen_Buffer[addr + 1],Screen_Buffer[addr]);
   end;
end;


procedure DrawRect(X,Y,W,H:Integer; C:TColor);
var
 I,J,addr:Integer;
 R, G, B: Byte;
begin
    I := y ;
    while I < (y + h) do
    begin
      J:= x;
      while J < (x + w) do
      begin
           addr:=((I*SCREEN_WIDTH)+J)*(SCREEN_DEPTH) ;
           ColorToRGB(C, R, G, B);
           Screen_Buffer[addr+2]:= R;
           Screen_Buffer[addr+1]:=G;
           Screen_Buffer[addr]:=B;
       inc(J);
      end;
    inc(I);
  end;
end;

procedure DrawTransparentRect(X, Y, W, H: Integer; C: TColor; Alpha: Byte);
var
  I, J, Addr: Integer;
  SrcR, SrcG, SrcB: Byte;  // Alt pikselin RGB bile enleri
  NewR, NewG, NewB: Byte;  // Yeni hesaplanan RGB bile enleri
  DestR, DestG, DestB: Byte;
  InvAlpha: Byte;
begin
  InvAlpha := 255 - Alpha;  // Alpha tersini al yoruz (% saydaml k hesaplamas  i in)

  I := Y;
  while I < (Y + H) do
  begin
    J := X;
    while J < (X + W) do
    begin
      Addr := ((I * SCREEN_WIDTH) + J) * (SCREEN_DEPTH);
      
      // Mevcut pikselin rengini (ekrandaki) al
      SrcB := Screen_Buffer[Addr];
      SrcG := Screen_Buffer[Addr + 1];
      SrcR := Screen_Buffer[Addr + 2];

      //  izece imiz rengin bile enlerini al
      DestR := (C shr 16) and $FF;
      DestG := (C shr 8) and $FF;
      DestB := C and $FF;

      // Yeni rengin bile enlerini hesapla (alfa kar   m )
      NewR := (DestR * Alpha + SrcR * InvAlpha) div 255;
      NewG := (DestG * Alpha + SrcG * InvAlpha) div 255;
      NewB := (DestB * Alpha + SrcB * InvAlpha) div 255;

      // Yeni rengi ekrana  iz
      Screen_Buffer[Addr] := NewB;
      Screen_Buffer[Addr + 1] := NewG;
      Screen_Buffer[Addr + 2] := NewR;

      Inc(J);
    end;
    Inc(I);
  end;
end;





procedure WriteChar(x, y: Integer; ch: Char; Color: Integer = clWhite);
var
  CharBitmap: PCharBitmap;
  i, j: Integer;
  C: TColor;
begin
  CharBitmap := PCharBitmap(CharSetOrigin + Integer(ch) shl 3);

  for i := 0 to 7 do
    for j := 0 to 7 do
      if (CharBitmap^[i] and (1 shl j)) <> 0 then
      begin
        PutPixel(X + 7 - j, Y + i, Color);
      end;

end;





procedure WriteStr(x, y: Integer; Text: PChar; Color: Integer = clWhite);
//
var
  I: Integer;
begin
  i := 0;
  repeat
    WriteChar(x, y, text[i], Color);
    inc(x, 8);
    i := i + 1;
  until text[i] = #$0
end;

procedure WriteInt(X, Y: integer;i: Integer; Color:Integer=clWhite);
var
        buffer: array [0..11] of Char;
        str: PChar;
        digit: cardinal;
        minus: Boolean;
begin
        str := @buffer[11];
        str^ := #0;
        if (i < 0) then begin
                digit := -i;
                minus := True;
        end else begin
                digit := i;
                minus := False;
        end;
        repeat
                Dec(str);
                str^ := Char((digit mod 10) + Byte('0'));
                digit := digit div 10;
        until (digit = 0);
        if (minus) then begin
                Dec(str);
                str^ := '-';
        end;

        WriteStr(X,Y,str,Color);
end;


procedure DrawGradient(X, Y, Width, Height: Integer;
  StartColor, EndColor: TColor; Alpha: Byte; Direction: Boolean=False);
var
  R1, G1, B1: Byte;
  R2, G2, B2: Byte;
  RStep, GStep, BStep: Double;
  I, Size: Integer;
  CurrentR, CurrentG, CurrentB: Byte;
  BlendedColor: TColor;
begin
  // Renkleri ayr  t r
  R1 := (StartColor shr 16) and $FF;
  G1 := (StartColor shr 8) and $FF;
  B1 := StartColor and $FF;

  R2 := (EndColor shr 16) and $FF;
  G2 := (EndColor shr 8) and $FF;
  B2 := EndColor and $FF;

  // Gradyan y n ne g re boyutu belirle
  if Direction then
    Size := Width  // Dikey ge i  i in y kseklik baz al n r
  else
    Size := Height;  // Yatay ge i  i in geni lik baz al n r

  // Renk ge i  ad mlar n  hesapla
  RStep := ((R2 - R1) / Size);
  GStep := ((G2 - G1) / Size);
  BStep := ((B2 - B1) / Size);

  // Gradyan   iz
  for I := 0 to Size - 1 do
  begin
    // Ge erli rengin bile enlerini hesapla
    CurrentR := Round(R1 + RStep * I);
    CurrentG := Round(G1 + GStep * I);
    CurrentB := Round(B1 + BStep * I);

    // Alfa kar   m n  uygula
    CurrentR := Round(CurrentR * (Alpha / 255) + (255 - Alpha));
    CurrentG := Round(CurrentG * (Alpha / 255) + (255 - Alpha));
    CurrentB := Round(CurrentB * (Alpha / 255) + (255 - Alpha));

    // Kar  t r lm   rengi olu tur
    BlendedColor := (CurrentR shl 16) or (CurrentG shl 8) or CurrentB;

    // Se ilen y ne g re  izimi yap
    if Direction then
       DrawRect(X + I, Y, 1, Height, BlendedColor) // Yatay  izgi
    else
       DrawRect(X, Y + I, Width, 1, BlendedColor);   // Dikey  izgi

  end;



end;

procedure DrawCenterText(X, Y,W,H: Integer;Text:PChar;Color:TColor; Font: Byte = 0);
var
  TextWidth, TextHeight: Integer;
  TextX, TextY: Integer;
begin

      if Text <> nil then
      begin
        // Metnin geni li ini ve y ksekli ini hesapla
        TextWidth :=8*StrLen(Text);   // Metin geni li ini hesaplama i levi
        TextHeight :=8;// GetTextHeight(Current^.Caption); // Metin y ksekli ini hesaplama i levi

        // Ortalanm   koordinatlar  belirle
        TextX := X + (W - TextWidth) div 2;
        TextY := Y + (H - TextHeight) div 2;

        // Metni  iz
        WriteStr(TextX, TextY, Text,Color);
      end;


end;

procedure MoveTo(X, Y: Integer);
begin
  PenX := X;
  PenY := Y;
end;


procedure LineTo(X, Y: Integer; Color: TColor);
var
  dx, dy, sx, sy, err, e2: Integer;
  x0, y0: Integer;
begin
  x0 := PenX;
  y0 := PenY;

  dx := abs(X - x0);
  sx := 1;
  if x0 > X then sx := -1;

  dy := -abs(Y - y0);
  sy := 1;
  if y0 > Y then sy := -1;

  err := dx + dy;

  while True do
  begin
    PutPixel(x0, y0, Color);

    if (x0 = X) and (y0 = Y) then Break;

    e2 := 2 * err;
    if e2 >= dy then
    begin
      err := err + dy;
      x0 := x0 + sx;
    end;
    if e2 <= dx then
    begin
      err := err + dx;
      y0 := y0 + sy;
    end;
  end;

  // Kalemin yeni pozisyonu
  PenX := X;
  PenY := Y;
end;





function GetVesaInfo(): boolean;
var
  Regs: TReg16;
  Ptr: LongInt;
begin
  Result :=False ;
  FillChar(Regs, SizeOf(TReg16), #0);
  Ptr := $7E00; // BIOS real mode buffer (576 KB)
  FillChar(Pointer(Ptr)^, SizeOf(TVesaInfo), #0);
  PLongWord(Ptr)^ := $41534556; // 'VESA' Signature
  Regs.ax := $4F00;
  Regs.es := Ptr shr 4;          // Segment
  Regs.di := Ptr and $000F;      // Offset (low nibble)
  Intr16(Regs, $10);
  if (Regs.AX = $004F) then
  begin
    Move(pointer(Ptr)^, Vesa_Mode, SizeOf(TVesaMode));
    Result := True;
  end;


end;

function GetVesaModeInfo(Mode: Word): Boolean;
var
  Regs: TReg16;
  Ptr: LongInt;
begin
  Result := False;
  FillChar(Regs, SizeOf(TReg16), #0);
  Ptr := $7E00 + $200;
  Regs.ax := $4F01;
  Regs.cx := Mode;
  Regs.es := Ptr shr 4;          // Segment
  Regs.di := Ptr and $000F;      // Offset (low nibble)

  Intr16(Regs, $10);

 if (Regs.AX = $004F) then   //1
  begin
     Move(pointer(Ptr)^, Vesa_Info, SizeOf(TVesaInfo));
      Result := True;
  end;
end;



function SetVESAMode(Mode: Word): boolean;
var
  Regs: TReg16;
begin
  FillChar(Regs, SizeOf(TReg16), #0);
  Regs.ax := $4F02;
  Regs.bx := Mode or $4000;

  Intr16(Regs, $10);
  Result := (Regs.AX =$004F);
end;




function Vesa_Find(): Word;
var
  M: ^Word ;
begin
  Result := 0;
  if GetVesaInfo() then
  begin
    M := Pointer(Vesa_Mode.VideoModePtr[1] * 16 + Vesa_Mode.VideoModePtr[0]);
    while (M^ <> $FFFF) do
    begin
      if GetVesaModeInfo(Word(M^)) then
      begin
        if (Vesa_Info.XResolution = SCREEN_WIDTH) and
           (Vesa_Info.YResolution = SCREEN_HEIGHT) and
           (Vesa_Info.BitsPerPixel = SCREEN_DEPTH * 8 ) then
        begin
          Result := M^;
          Break;
        end;
      end;

      Inc(M);
    end;

  end;
end;





function Vesa_Init(): boolean;
var
  Mode: Word;
begin
  Result := False;
  
  Mode:=Vesa_Find();
  if Mode<>0 then
  begin
    if SetVESAMode(Mode) then
    begin
      FillChar(Screen_Buffer,SizeOf(Screen_Buffer),#0);
      Result := True;
     end;
  end;
end;



end.

{ =========================================================
  Mouse.pas � PS/2 Mouse Driver
  
  �zellikler:
  - PS/2 mouse init (8042 controller)
  - IRQ12 handler
  - 3 byte packet parse
  - Left / Right / Middle button
  - X / Y delta � absolute position
  - Scroll wheel (4 byte packet)
  - Screen bounds clamp
  - Double click detection
  - Mouse cursor draw
  ========================================================= }

unit Mouse;

interface
Uses SysUtils,IDT,Fat32,Memory,Vesa;

const
  // 8042 Controller ports
  PS2_DATA    = $60;   // Data port (R/W)
  PS2_STATUS  = $64;   // Status port (R)
  PS2_COMMAND = $64;   // Command port (W)

  // 8042 Status bits
  PS2_SR_OBF  = $01;   // Output buffer full (data ready to read)
  PS2_SR_IBF  = $02;   // Input buffer full  (busy, wait before write)

  // 8042 Commands
  PS2_CMD_READ_CONFIG  = $20;
  PS2_CMD_WRITE_CONFIG = $60;
  PS2_CMD_DISABLE_P2   = $A7;
  PS2_CMD_ENABLE_P2    = $A8;
  PS2_CMD_TEST_P2      = $A9;
  PS2_CMD_SEND_P2      = $D4;  // Next byte goes to mouse

  // Mouse commands
  MOUSE_RESET          = $FF;
  MOUSE_RESEND         = $FE;
  MOUSE_SET_DEFAULTS   = $F6;
  MOUSE_DISABLE        = $F5;
  MOUSE_ENABLE         = $F4;
  MOUSE_SET_SAMPLE     = $F3;
  MOUSE_GET_ID         = $F2;
  MOUSE_SET_REMOTE     = $F0;
  MOUSE_SET_WRAP       = $EE;
  MOUSE_SET_STREAM     = $EA;
  MOUSE_STATUS         = $E9;
  MOUSE_SET_RES        = $E8;
  MOUSE_SET_SCALE21    = $E7;
  MOUSE_SET_SCALE11    = $E6;

  // Mouse ACK / responses
  MOUSE_ACK            = $FA;
  MOUSE_NACK           = $FE;
  MOUSE_BAT_OK         = $AA;
  MOUSE_ID_STANDARD    = $00;
  MOUSE_ID_WHEEL       = $03;
  MOUSE_ID_5BUTTON     = $04;

  // Packet byte 0 bits
  MB_LEFT              = $01;
  MB_RIGHT             = $02;
  MB_MIDDLE            = $04;
  MB_ALWAYS1           = $08;  // Always 1 (sync bit)
  MB_X_SIGN            = $10;
  MB_Y_SIGN            = $20;
  MB_X_OVERFLOW        = $40;
  MB_Y_OVERFLOW        = $80;

  // Double click timing (ms)
  DBLCLICK_TIME        = 50;

  // Screen bounds
  MOUSE_CURSOR_W       = 12;
  MOUSE_CURSOR_H       = 20;

type
  PMouseState = ^TMouseState;
  TMouseState = record
    // Absolute position
    X:          Integer;
    Y:          Integer;

    // Buttons
    Left:       Boolean;
    Right:      Boolean;
    Middle:     Boolean;

    // Previous buttons (edge detection)
    PrevLeft:   Boolean;
    PrevRight:  Boolean;
    PrevMiddle: Boolean;

    // Events
    LeftDown:   Boolean;
    LeftUp:     Boolean;
    RightDown:  Boolean;
    RightUp:    Boolean;
    MiddleDown: Boolean;
    MiddleUp:   Boolean;
    DblClick:   Boolean;
    IsMove:     Boolean;

    // Scroll
    ScrollDelta: Integer;  // +1 up, -1 down

    // Packet buffer
    Packet:     array[0..3] of Byte;
    PacketIdx:  Integer;
    PacketSize: Integer;  // 3 or 4

    // Mouse type
    MouseID:    Byte;
    HasWheel:   Boolean;

    // Double click
    LastClickTime: LongWord;
    LastClickX:    Integer;
    LastClickY:    Integer;

    // Screen bounds
    ScreenW:    Integer;
    ScreenH:    Integer;

    // Sensitivity
    SpeedX:     Integer;  // 1..4
    SpeedY:     Integer;  // 1..4
  end;

var
  MouseState: TMouseState;
  MouseRightDownEvent:Boolean = False;
  MouseLeftDownEvent: Boolean = False;
  MouseLeftUpEvent: Boolean = False;
  MouseDblClickEvent: Boolean = False;
  MouseMiddleDownEvent:Boolean = False;


// API
procedure Mouse_Init(ScreenW, ScreenH: Integer);
procedure Mouse_IRQHandler;
procedure Mouse_GetState(var X, Y: Integer; var Buttons: Byte);
procedure Mouse_SetPos(X, Y: Integer);
procedure Mouse_SetSpeed(SpeedX, SpeedY: Integer);
procedure Mouse_DrawCursor;


// Events (ana loop'ta �a��r)
procedure Mouse_ClearEvents;

procedure SetupIRQ12;

implementation

Uses
  GUI;

//=============================================================================
// Port I/O
//=============================================================================

function InByte(Port: Word): Byte;
begin
  asm
    mov dx, Port
    in  al, dx
    mov Result, al
  end;
end;

procedure OutByte(Port: Word; Value: Byte);
begin
  asm
    mov dx, Port
    mov al, Value
    out dx, al
  end;
end;

//=============================================================================
// GetTickCount � Basit tick sayac�
//=============================================================================

var
  TickCounter: LongWord = 0;

procedure Tick_Inc;
begin
  Inc(TickCounter);
end;

function GetTick: LongWord;
begin
  Result := TickCounter;
end;

//=============================================================================
// 8042 Controller
//=============================================================================

procedure PS2_Wait_Write;
var
  timeout: Integer;
begin
  timeout := 100000;
  while timeout > 0 do
  begin
    if (InByte(PS2_STATUS) and PS2_SR_IBF) = 0 then Exit;
    Dec(timeout);
  end;
end;

procedure PS2_Wait_Read;
var
  timeout: Integer;
begin
  timeout := 100000;
  while timeout > 0 do
  begin
    if (InByte(PS2_STATUS) and PS2_SR_OBF) <> 0 then Exit;
    Dec(timeout);
  end;
end;

procedure PS2_SendCommand(Cmd: Byte);
begin
  PS2_Wait_Write;
  OutByte(PS2_COMMAND, Cmd);
end;

function PS2_ReadData: Byte;
begin
  PS2_Wait_Read;
  Result := InByte(PS2_DATA);
end;

procedure PS2_WriteData(Data: Byte);
begin
  PS2_Wait_Write;
  OutByte(PS2_DATA, Data);
end;

// Mouse'a komut g�nder
procedure Mouse_Send(Cmd: Byte);
var
  ack: Byte;
  retry: Integer;
begin
  retry := 3;
  while retry > 0 do
  begin
    // D4 komutu ile mouse'a yaz
    PS2_SendCommand(PS2_CMD_SEND_P2);
    PS2_WriteData(Cmd);

    // ACK bekle
    ack := PS2_ReadData;

    if ack = MOUSE_ACK then Exit;
    if ack = MOUSE_NACK then
    begin
      Dec(retry);
      Continue;
    end;
    Exit;
  end;
end;

function Mouse_SendGet(Cmd: Byte): Byte;
begin
  Mouse_Send(Cmd);
  Result := PS2_ReadData;
end;

//=============================================================================
// Mouse ID & Wheel detection
// IntelliMouse magic sequence
//=============================================================================

procedure Mouse_DetectType;
var
  id: Byte;
begin
  MouseState.MouseID   := MOUSE_ID_STANDARD;
  MouseState.HasWheel  := False;
  MouseState.PacketSize := 3;

  // IntelliMouse magic:
  // Set sample rate 200, 100, 80 � mouse ID = 03 (wheel)
  Mouse_Send(MOUSE_SET_SAMPLE); Mouse_Send(200);
  Mouse_Send(MOUSE_SET_SAMPLE); Mouse_Send(100);
  Mouse_Send(MOUSE_SET_SAMPLE); Mouse_Send(80);

  Mouse_Send(MOUSE_GET_ID);
  id := PS2_ReadData;

  if id = MOUSE_ID_WHEEL then
  begin
    MouseState.MouseID   := MOUSE_ID_WHEEL;
    MouseState.HasWheel  := True;
    MouseState.PacketSize := 4;

    // 5-button detection:
    // Set sample rate 200, 200, 80 � ID = 04
    Mouse_Send(MOUSE_SET_SAMPLE); Mouse_Send(200);
    Mouse_Send(MOUSE_SET_SAMPLE); Mouse_Send(200);
    Mouse_Send(MOUSE_SET_SAMPLE); Mouse_Send(80);

    Mouse_Send(MOUSE_GET_ID);
    id := PS2_ReadData;

    if id = MOUSE_ID_5BUTTON then
      MouseState.MouseID := MOUSE_ID_5BUTTON;
  end;
end;

//=============================================================================
// Mouse_Init
//=============================================================================

procedure Mouse_Init(ScreenW, ScreenH: Integer);
var
  cfg:  Byte;
  resp: Byte;
begin
  FillChar(MouseState, SizeOf(TMouseState), 0);

  MouseState.ScreenW   := ScreenW;
  MouseState.ScreenH   := ScreenH;
  MouseState.X         := ScreenW div 2;
  MouseState.Y         := ScreenH div 2;
  MouseState.SpeedX    := 4;
  MouseState.SpeedY    := 4;
  MouseState.PacketSize := 3;

  // 1. Flush output buffer
  while (InByte(PS2_STATUS) and PS2_SR_OBF) <> 0 do
    InByte(PS2_DATA);

  // 2. Enable mouse port (disable keyboard first)
  PS2_SendCommand(PS2_CMD_DISABLE_P2);  // Disable mouse temporarily

  // 3. Read config
  PS2_SendCommand(PS2_CMD_READ_CONFIG);
  cfg := PS2_ReadData;

  // 4. Enable mouse IRQ12 + mouse clock
  cfg := cfg or $02;   // Enable IRQ12
  cfg := cfg and $DF;  // Clear mouse disable bit (bit 5)

  PS2_SendCommand(PS2_CMD_WRITE_CONFIG);
  PS2_WriteData(cfg);

  // 5. Enable mouse port
  PS2_SendCommand(PS2_CMD_ENABLE_P2);

  // 6. Reset mouse
  Mouse_Send(MOUSE_RESET);
  resp := PS2_ReadData;  // $AA (BAT OK)
  resp := PS2_ReadData;  // $00 (mouse ID)

  // 7. Detect wheel/5-button
  Mouse_DetectType;

  // 8. Set sample rate (100 samples/sec)
  Mouse_Send(MOUSE_SET_SAMPLE);
  Mouse_Send(200);

  // 9. Set resolution (4 counts/mm)
  Mouse_Send(MOUSE_SET_RES);
  Mouse_Send(2);

  // 10. Enable stream mode
  Mouse_Send(MOUSE_ENABLE);

 // COM1_WriteStr('Mouse: Init OK, ID=');
 // COM1_WriteStr(IntToPChar(MouseState.MouseID));
 // if MouseState.HasWheel then
   // COM1_WriteStr(' (Wheel)');
  //COM1_WriteStr(#13#10);

  SetupIRQ12;
end;

//=============================================================================
// Packet Parse
//=============================================================================

procedure Mouse_ParsePacket;
var
  b0: Byte;
  dx: Integer;
  dy: Integer;
  dz: ShortInt;
  now:Integer;
  dt, ddx ,ddy:Integer;
begin
  b0 := MouseState.Packet[0];

  // Sync bit kontrol� (bit 3 her zaman 1 olmal�)
  if (b0 and MB_ALWAYS1) = 0 then
  begin
    // Desync! Paketi s�f�rla
    MouseState.PacketIdx := 0;
   // COM1_WriteStr('Mouse: Desync!'#13#10);
    Exit;
  end;

  // Delta hesapla (9-bit signed)
  dx := Integer(MouseState.Packet[1]);
  dy := Integer(MouseState.Packet[2]);

  // Sign extension (9-bit � 32-bit)
  if (b0 and MB_X_SIGN) <> 0 then dx := dx - 256;
  if (b0 and MB_Y_SIGN) <> 0 then dy := dy - 256;

  // Overflow kontrol�
  if (b0 and MB_X_OVERFLOW) <> 0 then dx := 0;
  if (b0 and MB_Y_OVERFLOW) <> 0 then dy := 0;

  // Y ekseni ters (PS/2 yukar� = pozitif, ekranda yukar� = negatif)
  dy := -dy;

  // Speed uygula
  dx := dx * MouseState.SpeedX;
  dy := dy * MouseState.SpeedY;

  // Pozisyon g�ncelle
  if (dx <> 0) or (dy <> 0) then
  begin
    MouseState.X := MouseState.X + dx;
    MouseState.Y := MouseState.Y + dy;

    // Screen bounds
    if MouseState.X < 0 then MouseState.X := 0;
    if MouseState.Y < 0 then MouseState.Y := 0;
    if MouseState.X >= MouseState.ScreenW then MouseState.X := MouseState.ScreenW - 1;
    if MouseState.Y >= MouseState.ScreenH then MouseState.Y := MouseState.ScreenH - 1;

    MouseState.IsMove := True;
  end;

  // Buttons � �nceki state kaydet
  MouseState.PrevLeft   := MouseState.Left;
  MouseState.PrevRight  := MouseState.Right;
  MouseState.PrevMiddle := MouseState.Middle;

  // Yeni button state
  MouseState.Left   := (b0 and MB_LEFT)   <> 0;
  MouseState.Right  := (b0 and MB_RIGHT)  <> 0;
  MouseState.Middle := (b0 and MB_MIDDLE) <> 0;

  // Edge detection � Down events
  if MouseState.Left and not MouseState.PrevLeft then
  begin
    MouseState.LeftDown := True;

    // Double click detection
     now := GetTick;
     dt  := now - MouseState.LastClickTime;
     ddx := MouseState.X - MouseState.LastClickX;
     ddy := MouseState.Y - MouseState.LastClickY;
    if ddx < 0 then ddx := -ddx;
    if ddy < 0 then ddy := -ddy;

    if (dt < DBLCLICK_TIME) and (ddx < 8) and (ddy < 8) then
      MouseState.DblClick := True;

    MouseState.LastClickTime := now;
    MouseState.LastClickX    := MouseState.X;
    MouseState.LastClickY    := MouseState.Y;
  end;

  // Up events
  if not MouseState.Left   and MouseState.PrevLeft   then MouseState.LeftUp   := True;
  if MouseState.Right      and not MouseState.PrevRight  then MouseState.RightDown := True;
  if not MouseState.Right  and MouseState.PrevRight  then MouseState.RightUp  := True;
  if MouseState.Middle     and not MouseState.PrevMiddle then MouseState.MiddleDown := True;
  if not MouseState.Middle and MouseState.PrevMiddle then MouseState.MiddleUp := True;

  // Scroll wheel (4. byte)
  MouseState.ScrollDelta := 0;
  if MouseState.HasWheel and (MouseState.PacketSize = 4) then
  begin
    dz := ShortInt(MouseState.Packet[3] and $0F);
    if (MouseState.Packet[3] and $08) <> 0 then
      dz := dz or ShortInt($F0);  // Sign extend 4-bit
    MouseState.ScrollDelta := Integer(dz);
  end;


 // WinManager.ProcessMouse(MouseState);
end;

//=============================================================================
// Mouse_IRQHandler � IRQ12
//=============================================================================

procedure Mouse_IRQHandler;
var
  data: Byte;
begin
  // Veri haz�r m�?
  if (InByte(PS2_STATUS) and PS2_SR_OBF) = 0 then Exit;

  data := InByte(PS2_DATA);

  // Paket buffer'a ekle
  MouseState.Packet[MouseState.PacketIdx] := data;
  Inc(MouseState.PacketIdx);

  // Paket tamamland� m�?
  if MouseState.PacketIdx >= MouseState.PacketSize then
  begin
    MouseState.PacketIdx := 0;
    Mouse_ParsePacket;
  end;

  // PIC EOI (IRQ12 = slave PIC)
  OutByte($A0, $20);  // Slave EOI
  OutByte($20, $20);  // Master EOI
end;

//=============================================================================
// Mouse Cursor Draw
//=============================================================================

// Arrow cursor bitmap (12x20, 1=foreground, 0=background, 2=skip)
const
  CURSOR_AND: array[0..19] of Word = (
    $8000,  // 1000000000000000
    $C000,  // 1100000000000000
    $E000,  // 1110000000000000
    $F000,  // 1111000000000000
    $F800,  // 1111100000000000
    $FC00,  // 1111110000000000
    $FE00,  // 1111111000000000
    $FF00,  // 1111111100000000
    $FF80,  // 1111111110000000
    $FF00,  // 1111111100000000
    $FE00,  // 1111111000000000
    $F600,  // 1111011000000000
    $E600,  // 1110011000000000
    $0600,  // 0000011000000000
    $0300,  // 0000001100000000
    $0300,  // 0000001100000000
    $0000,  // 0000000000000000
    $0000,
    $0000,
    $0000
  );



procedure Mouse_DrawCursor;
var
  cx, cy: Integer;
  px, py: Integer;
  idx:    Integer;
  bit:    Integer;
  mask:   Word;
  color:  LongWord;
  screenX,screenY:Integer;
begin
  cx := MouseState.X;
  cy := MouseState.Y;

 

  // Alt�ndaki pixelleri kaydet ve cursor �iz
  idx := 0;
  py  := 0;
  while py < MOUSE_CURSOR_H do
  begin
    px := 0;
    while px < MOUSE_CURSOR_W do
    begin
       screenX := cx + px;
       screenY := cy + py;

      if (screenX >= 0) and (screenX < MouseState.ScreenW) and
         (screenY >= 0) and (screenY < MouseState.ScreenH) then
      begin
        // Kaydet
     //   CursorSaveBuf[idx] := ReadPixel(screenX, screenY);

        // Cursor bit kontrol� (MSB'den LSB'ye)
        bit  := 15 - px;
        mask := CURSOR_AND[py];

        if (mask and (1 shl bit)) <> 0 then
        begin
          // Dolu alan
          if py < 2 then
            color := $00000000   // Siyah (outline ilk 2 sat�r)
          else if px = 0 then
            color := $00000000   // Sol kenar siyah
          else
            color := $00FFFFFF;  // �� beyaz
          PutPixel(screenX, screenY, color);
        end;
        // S�f�r bit = transparan (ge�me)
      end;

      Inc(idx);
      Inc(px);
    end;
    Inc(py);
  end;
end;

//=============================================================================
// API
//=============================================================================

procedure Mouse_GetState(var X, Y: Integer; var Buttons: Byte);
begin
  X := MouseState.X;
  Y := MouseState.Y;

  Buttons := 0;
  if MouseState.Left   then Buttons := Buttons or $01;
  if MouseState.Right  then Buttons := Buttons or $02;
  if MouseState.Middle then Buttons := Buttons or $04;
end;

procedure Mouse_SetPos(X, Y: Integer);
begin
  MouseState.X := X;
  MouseState.Y := Y;

  if MouseState.X < 0 then MouseState.X := 0;
  if MouseState.Y < 0 then MouseState.Y := 0;
  if MouseState.X >= MouseState.ScreenW then MouseState.X := MouseState.ScreenW - 1;
  if MouseState.Y >= MouseState.ScreenH then MouseState.Y := MouseState.ScreenH - 1;
end;

procedure Mouse_SetSpeed(SpeedX, SpeedY: Integer);
begin
  if SpeedX < 1 then SpeedX := 1;
  if SpeedX > 32 then SpeedX := 32; // S�n�r� 8'den 32'ye ��kard�k
  if SpeedY < 1 then SpeedY := 1;
  if SpeedY > 32 then SpeedY := 32; // S�n�r� 8'den 32'ye ��kard�k

  MouseState.SpeedX := SpeedX;
  MouseState.SpeedY := SpeedY;
end;

procedure Mouse_ClearEvents;
begin
  MouseState.LeftDown   := False;
  MouseState.LeftUp     := False;
  MouseState.RightDown  := False;
  MouseState.RightUp    := False;
  MouseState.MiddleDown := False;
  MouseState.MiddleUp   := False;
  MouseState.DblClick   := False;
  MouseState.IsMove     := False;
  MouseState.ScrollDelta := 0;
end;


procedure SetupIRQ12;
var
  mask:Byte;
begin
  RegisterISR(44, @Mouse_IRQHandler);  // IRQ12 = INT 44

  // PIC'te IRQ12'yi a�
  mask := InByte($A1);  // Slave PIC mask
  mask := mask and not $10; // IRQ12 = bit 4 slave
  OutByte($A1, mask);
end;

end.

{ =========================================================
  ENTEGRASYON
  ========================================================= }

(*
// 1. IDT'ye IRQ12 handler ekle
procedure SetupIRQ12;
begin
  IDT_SetHandler(44, @Mouse_IRQHandler);  // IRQ12 = INT 44

  // PIC'te IRQ12'yi a�
  var mask := InByte($A1);  // Slave PIC mask
  mask := mask and not $10; // IRQ12 = bit 4 slave
  OutByte($A1, mask);
end;

// 2. Kernel init
procedure KernelMain;
begin
  Mouse_Init(800, 600);
  SetupIRQ12;

  while True do
  begin
    // Events ProcessMouseInput'a aktar
    MouseLeftDownEvent   := MouseState.LeftDown;
    MouseLeftUpEvent     := MouseState.LeftUp;
    MouseRightDownEvent  := MouseState.RightDown;
    MouseDblClickEvent   := MouseState.DblClick;
    Mouse_State.X        := MouseState.X;
    Mouse_State.Y        := MouseState.Y;
    Mouse_State.LEFT     := MouseState.Left;
    Mouse_State.IsMouseMove := MouseState.IsMove;

    // Cursor �iz
    Mouse_EraseCursor;
    DrawAllWindows;
    Desktop_Render;
    TaskBar_Render;
    Mouse_DrawCursor;

    ProcessMouseInput;

    // Events temizle
    Mouse_ClearEvents;

    Delay(8);
  end;
end;

// IDT handler (assembly stub):
procedure IRQ12_Stub; assembler;
asm
  pushad
  call Mouse_IRQHandler
  popad
  iretd
end;
*)

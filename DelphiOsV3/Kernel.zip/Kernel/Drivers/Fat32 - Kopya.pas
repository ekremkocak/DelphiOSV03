Unit Fat32;

interface
Uses
   SysUtils,Vesa,Idt,Pit,Ports,Intr32;


{ =========================================================
  FAT32.pas � FAT32 Dosya Sistemi
  
  �zellikler:
  - HDD tarama (ATA/IDE PIO mode)
  - FAT32 BPB parse
  - OpenFile, ReadFile, WriteFile, CloseFile
  - SeekFile, FilePos
  - FindFirst, FindNext
  - MakeDir, DeleteFile
  - Birden fazla s�r�c� deste�i
  ========================================================= }



const
  MAX_DRIVES       = 4;
  MAX_OPEN_FILES   = 32;
  MAX_PATH         = 256;
  SECTOR_SIZE      = 512;
  FAT32_EOC        = $0FFFFFFF;
  FAT32_FREE       = $00000000;
  FAT32_BAD        = $0FFFFFF7;
  INVALID_HANDLE   =-1;
  
  // File attributes
  ATTR_READ_ONLY   = $01;
  ATTR_HIDDEN      = $02;
  ATTR_SYSTEM      = $04;
  ATTR_VOLUME_ID   = $08;
  ATTR_DIRECTORY   = $10;
  ATTR_ARCHIVE     = $20;
  ATTR_LFN         = $0F;
  
  // File open mode
  FILE_READ        = $01;
  FILE_WRITE       = $02;
  FILE_CREATE      = $04;
  FILE_APPEND      = $08;
  
  // Seek mode
  SEEK_SET         = 0;
  SEEK_CUR         = 1;
  SEEK_END         = 2;
  
  // ATA ports (Primary)
  ATA_DATA         = $01F0;
  ATA_ERROR        = $01F1;
  ATA_SECTOR_COUNT = $01F2;
  ATA_LBA_LOW      = $01F3;
  ATA_LBA_MID      = $01F4;
  ATA_LBA_HIGH     = $01F5;
  ATA_DRIVE_HEAD   = $01F6;
  ATA_STATUS       = $01F7;
  ATA_COMMAND      = $01F7;
  
  // ATA commands
  ATA_CMD_READ     = $20;
  ATA_CMD_WRITE    = $30;
  ATA_CMD_IDENTIFY = $EC;
  
  // ATA status bits
  ATA_SR_BSY       = $80;
  ATA_SR_DRDY      = $40;
  ATA_SR_DRQ       = $08;
  ATA_SR_ERR       = $01;
  
  // Secondary ATA ports
  ATA_DATA2        = $0170;
  ATA_STATUS2      = $0177;
  ATA_DRIVE_HEAD2  = $0176;

type
 PInteger=^Integer;

type
  // BPB - BIOS Parameter Block (FAT32)
  PBPB = ^TBPB;
  TBPB = packed record
    jmpBoot:       array[0..2] of Byte;   // $00: Jump boot code
    OEMName:       array[0..7] of Char;   // $03: OEM name
    BytesPerSec:   Word;                   // $0B: Bytes per sector
    SecPerClus:    Byte;                   // $0D: Sectors per cluster
    RsvdSecCnt:    Word;                   // $0E: Reserved sector count
    NumFATs:       Byte;                   // $10: Number of FATs (2)
    RootEntCnt:    Word;                   // $11: Root entry count (0 for FAT32)
    TotSec16:      Word;                   // $13: Total sectors 16 (0 for FAT32)
    Media:         Byte;                   // $15: Media descriptor
    FATSz16:       Word;                   // $16: FAT size 16 (0 for FAT32)
    SecPerTrk:     Word;                   // $18: Sectors per track
    NumHeads:      Word;                   // $1A: Number of heads
    HiddSec:       LongWord;              // $1C: Hidden sectors
    TotSec32:      LongWord;              // $20: Total sectors 32
    // FAT32 extended BPB
    FATSz32:       LongWord;              // $24: FAT size 32
    ExtFlags:      Word;                   // $28: Extended flags
    FSVer:         Word;                   // $2A: File system version
    RootClus:      LongWord;              // $2C: Root cluster
    FSInfo:        Word;                   // $30: FSInfo sector
    BkBootSec:     Word;                   // $32: Backup boot sector
    Reserved:      array[0..11] of Byte;  // $34: Reserved
    DrvNum:        Byte;                   // $40: Drive number
    Reserved1:     Byte;                   // $41: Reserved
    BootSig:       Byte;                   // $42: Boot signature ($29)
    VolID:         LongWord;              // $43: Volume ID
    VolLab:        array[0..10] of Char;  // $47: Volume label
    FilSysType:    array[0..7] of Char;   // $52: File system type
  end;
  
  // Directory entry (32 bytes)
  PDirEntry = ^TDirEntry;
  TDirEntry = packed record
    Name:       array[0..10] of Char;    // 8.3 name
    Attr:       Byte;                     // Attributes
    NTRes:      Byte;                     // Reserved (NT)
    CrtTimeTenth: Byte;                   // Create time tenth
    CrtTime:    Word;                     // Create time
    CrtDate:    Word;                     // Create date
    LstAccDate: Word;                     // Last access date
    FstClusHI:  Word;                     // First cluster high
    WrtTime:    Word;                     // Write time
    WrtDate:    Word;                     // Write date
    FstClusLO:  Word;                     // First cluster low
    FileSize:   LongWord;               // File size
  end;
  
  // LFN entry (Long File Name)
  PLFNEntry = ^TLFNEntry;
  TLFNEntry = packed record
    Order:      Byte;                     // Order
    Name1:      array[0..9] of Byte;     // Name part 1 (5 chars UTF-16)
    Attr:       Byte;                     // Always ATTR_LFN ($0F)
    LFNType:    Byte;                     // Type (0)
    Checksum:   Byte;                     // Checksum
    Name2:      array[0..11] of Byte;    // Name part 2 (6 chars UTF-16)
    FstClusLO:  Word;                     // Always 0
    Name3:      array[0..3] of Byte;     // Name part 3 (2 chars UTF-16)
  end;
  
  // Drive info
  PDriveInfo = ^TDriveInfo;
  TDriveInfo = record
    Present:    Boolean;
    ATAPort:    Word;                     // ATA base port
    DriveNum:   Byte;                     // 0=master, 1=slave
    SectorCount: LongWord;
    
    // FAT32 info
    IsFAT32:    Boolean;
    BPB:        TBPB;
    
    FATStart:   LongWord;                // FAT start sector
    DataStart:  LongWord;                // Data start sector
    RootClus:   LongWord;                // Root cluster
    SecPerClus: Byte;                    // Sectors per cluster
    BytesPerClus: LongWord;
    
    Letter:     Char;                    // Drive letter C, D, E...
  end;
  
  // Open file handle
  PFileHandle = ^TFileHandle;
  TFileHandle = record
    Used:       Boolean;
    DriveIndex: Integer;
    Mode:       Byte;
    
    // Position
    FileSize:   LongWord;
    FilePos:    LongWord;
    
    // Current cluster chain
    StartCluster: LongWord;
    CurrentCluster: LongWord;
    CurrentSector: LongWord;
    SectorOffset: LongWord;
    
    // Buffer
    Buffer:     array[0..SECTOR_SIZE-1] of Byte;
    BufferDirty: Boolean;
    
    // Directory info (for write)
    DirSector:  LongWord;
    DirOffset:  Integer;
    
    Name:       array[0..MAX_PATH-1] of Char;
  end;
  
  // Find handle
  PFindHandle = ^TFindHandle;
  TFindHandle = record
    Used:       Boolean;
    DriveIndex: Integer;
    SearchPath: array[0..MAX_PATH-1] of Char;
    SearchAttr: Byte;
    
    DirCluster: LongWord;
    DirSector:  LongWord;
    DirIndex:   Integer;
  end;
  
  // Find data
  PSearchRec = ^TSearchRec;
  TSearchRec = record
    Name:       array[0..MAX_PATH-1] of Char;
    ShortName:  array[0..12] of Char;
    Attr:       Byte;
    FileSize:   LongWord;
    StartCluster: LongWord;
    IsDir :Boolean;
    ImageFile:PChar;
  end;


  type
  // Disk Kapasite ve Kullan�m Bilgisi Yap�s�
  PDriveSpaceInfo = ^TDriveSpaceInfo;
  TDriveSpaceInfo = record
    DriveLetter   : Char;
    IsFAT32       : Boolean;
    
    // Cluster Bilgileri
    TotalClusters : LongWord;
    FreeClusters  : LongWord;
    UsedClusters  : LongWord;
    BytesPerClus  : LongWord;
    
    // Boyut Bilgileri (Say�sal)
    TotalKB       : LongWord;
    FreeKB        : LongWord;
    UsedKB        : LongWord;
    
    TotalMB       : LongWord;
    FreeMB        : LongWord;
    UsedMB        : LongWord;
  end;

// Fonksiyon Tan�mlar�
function FAT32_GetDriveSpace(DriveIndex: Integer; var Info: TDriveSpaceInfo): Boolean;
//procedure FormatSizeStr(Bytes: LongWord; Buffer: PChar);

var
  Drives:      array[0..MAX_DRIVES-1] of TDriveInfo;
  DriveCount:  Integer;
  OpenFiles:   array[0..MAX_OPEN_FILES-1] of TFileHandle;
  SectorBuf:   array[0..SECTOR_SIZE-1] of Byte;

// Drive management
procedure FAT32_Init;
procedure FAT32_ScanDrives;

// File operations
function OpenFile(Path: PChar; Mode: Byte): Integer;
function ReadFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
function WriteFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
procedure CloseFile(Handle: Integer); overload;
function SeekFile(Handle: Integer; Offset: LongInt; Origin: Byte): LongWord;
function FilePos(Handle: Integer): LongWord;
function FileSize(Handle: Integer): LongWord;

function FAT32_GetDriveFromPath(Path: PChar): Integer;
function FAT32_ExtensionMatch(Name: PChar; Pattern: PChar): Boolean;
function FAT32_ResolvePath(DriveIndex: Integer; Path: PChar;
                           Entry: PDirEntry): Boolean;

// Directory operations
function MakeDir(Path: PChar): Boolean;
function DeleteFile(Path: PChar): Boolean;
function FindFirst(Path, Pattern: PChar; Attr: Byte; 
                         SearchRec: PSearchRec): Integer;
function FindNext(FindHandle: Integer; SearchRec: PSearchRec): Boolean;
procedure FindClose(FindHandle: Integer);

procedure MountDrive(DriveIndex: Integer);

function ATA_ReadSector(Port: Word; DriveNum: Byte; LBA: LongWord;
                        Buffer: Pointer): Boolean;




implementation

//=============================================================================
// String Helpers
//=============================================================================


function StrCmpN(s1, s2: PChar; n: Integer): Boolean;
var
  i: Integer;
begin
  Result := False;
  i := 0;
  while i < n do
  begin
    if s1[i] <> s2[i] then Exit;
    if s1[i] = #0 then Break;
    Inc(i);
  end;
  Result := True;
end;

function ToUpper(c: Char): Char;
begin
  if (c >= 'a') and (c <= 'z') then
    Result := Char(Ord(c) - 32)
  else
    Result := c;
end;





//=============================================================================
// Port I/O (ATA)
//=============================================================================

function InByte(Port: Word): Byte;
begin
  asm
    mov dx, Port
    in  al, dx
    mov Result, al
  end;
end;

procedure OutByte(Port: Word; Value: Byte);
begin
  asm
    mov dx, Port
    mov al, Value
    out dx, al
  end;
end;

function InWord(Port: Word): Word;
begin
  asm
    mov dx, Port
    in  ax, dx
    mov Result, ax
  end;
end;

procedure OutWord(Port: Word; Value: Word);
begin
  asm
    mov dx, Port
    mov ax, Value
    out dx, ax
  end;
end;

//=============================================================================
// ATA Driver
//=============================================================================

procedure ATA_Delay(Port: Word);
var
  i: Integer;
begin
  i := 0;
  while i < 4 do
  begin
    InByte(Port + 7);  // Read status (delay)
    Inc(i);
  end;
end;

function ATA_WaitBSY(Port: Word): Boolean;
var
  timeout: Integer;
  status: Byte;
begin
  Result := False;
  timeout := 100000;
  
  while timeout > 0 do
  begin
    status := InByte(Port + 7);
    
    if (status and ATA_SR_BSY) = 0 then
    begin
      Result := True;
      Exit;
    end;
    
    Dec(timeout);
  end;
end;

function ATA_WaitDRQ(Port: Word): Boolean;
var
  timeout: Integer;
  status: Byte;
begin
  Result := False;
  timeout := 100000;
  
  while timeout > 0 do
  begin
    status := InByte(Port + 7);
    
    if (status and ATA_SR_ERR) <> 0 then Exit;
    
    if (status and ATA_SR_DRQ) <> 0 then
    begin
      Result := True;
      Exit;
    end;
    
    Dec(timeout);
  end;
end;




function ATA_ReadSector(Port: Word; DriveNum: Byte; LBA: LongWord;
                        Buffer: Pointer): Boolean;
var
  i: Integer;
  P: PWord;
  status: Byte;
begin
  Result := False;
  
  // Wait BSY
  if not ATA_WaitBSY(Port) then Exit;
  
  // Setup LBA
  OutByte(Port + 6, $E0 or (DriveNum shl 4) or Byte((LBA shr 24) and $0F));
  OutByte(Port + 1, 0);           // No interrupt
  OutByte(Port + 2, 1);           // 1 sector
  OutByte(Port + 3, Byte(LBA));
  OutByte(Port + 4, Byte(LBA shr 8));
  OutByte(Port + 5, Byte(LBA shr 16));
  
  // Read command
  OutByte(Port + 7, ATA_CMD_READ);
  
  ATA_Delay(Port);
  
  // Wait DRQ
  if not ATA_WaitDRQ(Port) then Exit;


 
  
  // Read 256 words = 512 bytes
  P := PWord(Buffer);
  i := 0;
  while i < 256 do
  begin
    P^ := InWord(Port);
    Inc(P);
    Inc(i);
  end;
  
  Result := True;
end;

function ATA_WriteSector(Port: Word; DriveNum: Byte; LBA: LongWord;
                         Buffer: Pointer): Boolean;
var
  i: Integer;
  P: PWord;
begin
  Result := False;
  
  if not ATA_WaitBSY(Port) then Exit;
  
  OutByte(Port + 6, $E0 or (DriveNum shl 4) or Byte((LBA shr 24) and $0F));
  OutByte(Port + 1, 0);
  OutByte(Port + 2, 1);
  OutByte(Port + 3, Byte(LBA));
  OutByte(Port + 4, Byte(LBA shr 8));
  OutByte(Port + 5, Byte(LBA shr 16));
  
  OutByte(Port + 7, ATA_CMD_WRITE);
  
  ATA_Delay(Port);
  
  if not ATA_WaitDRQ(Port) then Exit;
  
  P := PWord(Buffer);
  i := 0;
  while i < 256 do
  begin
    OutWord(Port, P^);
    Inc(P);
    Inc(i);
  end;
  
  Result := True;
end;

function ATA_Identify(Port: Word; DriveNum: Byte; SectorCount: PLongWord): Boolean;
var
  IdentBuf: array[0..255] of Word;
  i: Integer;
  status: Byte;
begin
  Result := False;
  
  // Select drive
  OutByte(Port + 6, $A0 or (DriveNum shl 4));
  
  ATA_Delay(Port);
  
  status := InByte(Port + 7);
  if status = 0 then Exit;  // No drive
  
  // Clear LBA regs
  OutByte(Port + 2, 0);
  OutByte(Port + 3, 0);
  OutByte(Port + 4, 0);
  OutByte(Port + 5, 0);
  
  // Identify command
  OutByte(Port + 7, ATA_CMD_IDENTIFY);
  
  ATA_Delay(Port);
  
  status := InByte(Port + 7);
  if status = 0 then Exit;  // No drive
  
  if not ATA_WaitBSY(Port) then Exit;
  
  // Not ATA?
  if (InByte(Port + 4) <> 0) or (InByte(Port + 5) <> 0) then Exit;
  
  if not ATA_WaitDRQ(Port) then Exit;
  
  // Read identify data
  i := 0;
  while i < 256 do
  begin
    IdentBuf[i] := InWord(Port);
    Inc(i);
  end;
  
  // LBA28 sector count at word 60-61
  SectorCount^ := LongWord(IdentBuf[60]) or (LongWord(IdentBuf[61]) shl 16);
  
  Result := (SectorCount^ > 0);
end;

//=============================================================================
// Drive Scan
//=============================================================================

procedure FAT32_ScanDrives;
var
  ports: array[0..1] of Word;
  driveNums: array[0..1] of Byte;
  portCount: Integer;
  driveCount2: Integer;
  i: Integer;
  j: Integer;
  port: Word;
  driveNum: Byte;
  sectorCount: LongWord;
  driveInfo: PDriveInfo;
  letters: array[0..3] of Char;
begin
  DriveCount := 0;
  
  // ATA primary/secondary ports
  ports[0] := ATA_DATA;
  ports[1] := ATA_DATA2;
  portCount := 2;
  
  driveNums[0] := 0;  // Master
  driveNums[1] := 1;  // Slave
  driveCount2 := 2;
  
  letters[0] := 'C';
  letters[1] := 'D';
  letters[2] := 'E';
  letters[3] := 'F';
  
  i := 0;
  while (i < portCount) and (DriveCount < MAX_DRIVES) do
  begin
    port := ports[i];
    
    j := 0;
    while (j < driveCount2) and (DriveCount < MAX_DRIVES) do
    begin
      driveNum := j;
      sectorCount := 0;
      
      if ATA_Identify(port, driveNum, @sectorCount) then
      begin
        driveInfo := @Drives[DriveCount];
        
        MemSet(driveInfo, 0, SizeOf(TDriveInfo));
        
        driveInfo^.Present := True;
        driveInfo^.ATAPort := port;
        driveInfo^.DriveNum := driveNum;
        driveInfo^.SectorCount := sectorCount;
        driveInfo^.Letter := letters[DriveCount];
        
        
        // Try to mount FAT32
        MountDrive(DriveCount);
        
        Inc(DriveCount);
      end;
      
      Inc(j);
    end;
    
    Inc(i);
  end;
end;

//=============================================================================
// FAT32 Mount
//=============================================================================

procedure MountDrive(DriveIndex: Integer);
var
  drv: PDriveInfo;
  bpb: PBPB;
  fatType: array[0..7] of Char;
  i: Integer;
begin
  drv := @Drives[DriveIndex];
  
  // Read boot sector (LBA 0)
  if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, 0, @SectorBuf[0]) then
    Exit;
  
  bpb := PBPB(@SectorBuf[0]);
  
  // Check signature
  if (SectorBuf[510] <> $55) or (SectorBuf[511] <> $AA) then
    Exit;
  
  // Check FAT32
  i := 0;
  while i < 8 do
  begin
    fatType[i] := bpb^.FilSysType[i];
    Inc(i);
  end;
  
  if not (StrCmpN(@fatType[0], 'FAT32   ', 8)) then
    Exit;
  
  // Copy BPB
  MemCopy(@drv^.BPB, bpb, SizeOf(TBPB));
  
  drv^.IsFAT32 := True;
  drv^.SecPerClus := bpb^.SecPerClus;
  drv^.BytesPerClus := bpb^.SecPerClus * bpb^.BytesPerSec;
  drv^.RootClus := bpb^.RootClus;
  
  // FAT start
  drv^.FATStart := bpb^.RsvdSecCnt;
  
  // Data start
  drv^.DataStart := bpb^.RsvdSecCnt +
                    (bpb^.NumFATs * bpb^.FATSz32);
end;

//=============================================================================
// FAT32 Cluster Operations
//=============================================================================

function FAT32_GetDriveFromPath(Path: PChar): Integer;
var
  i: Integer;
begin
  Result := -1;
  
  if Path = nil then Exit;
  
  // "C:\..." ? letter = Path[0]
  if (StrLen(Path) >= 3) and (Path[1] = ':') then
  begin
    i := 0;
    while i < DriveCount do
    begin
      if ToUpper(Drives[i].Letter) = ToUpper(Path[0]) then
      begin
        Result := i;
        Exit;
      end;
      Inc(i);
    end;
  end
  else
  begin
    // No letter, use first drive
    if DriveCount > 0 then
      Result := 0;
  end;
end;

function FAT32_ClusterToLBA(DriveIndex: Integer; Cluster: LongWord): LongWord;
begin
  Result := Drives[DriveIndex].DataStart +
            (Cluster - 2) * Drives[DriveIndex].SecPerClus;
end;

function FAT32_ReadFAT(DriveIndex: Integer; Cluster: LongWord): LongWord;
var
  drv: PDriveInfo;
  fatSector: LongWord;
  fatOffset: LongWord;
  P: PLongWord;
begin
  Result := FAT32_EOC;
  
  drv := @Drives[DriveIndex];
  
  fatOffset := Cluster * 4;
  fatSector := drv^.FATStart + (fatOffset div SECTOR_SIZE);
  fatOffset := fatOffset mod SECTOR_SIZE;
  
  if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then
    Exit;
  
  P := PLongWord(@SectorBuf[fatOffset]);
  Result := P^ and $0FFFFFFF;
end;

function FAT32_WriteFAT(DriveIndex: Integer; Cluster, Value: LongWord): Boolean;
var
  drv: PDriveInfo;
  fatSector: LongWord;
  fatOffset: LongWord;
  P: PLongWord;
  i: Integer;
begin
  Result := False;
  
  drv := @Drives[DriveIndex];
  
  fatOffset := Cluster * 4;
  fatSector := drv^.FATStart + (fatOffset div SECTOR_SIZE);
  fatOffset := fatOffset mod SECTOR_SIZE;
  
  // Read current sector
  if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then
    Exit;
  
  // Update
  P := PLongWord(@SectorBuf[fatOffset]);
  P^ := (P^ and $F0000000) or (Value and $0FFFFFFF);
  
  // Write back (both FATs)
  if not ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then
    Exit;
  
  // Second FAT
  fatSector := fatSector + drv^.BPB.FATSz32;
  ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]);
  
  Result := True;
end;

function FAT32_AllocCluster(DriveIndex: Integer): LongWord;
var
  drv: PDriveInfo;
  fatSector: LongWord;
  i: Integer;
  P: PLongWord;
  cluster: LongWord;
  entriesPerSec: Integer;
begin
  Result := 0;
  
  drv := @Drives[DriveIndex];
  entriesPerSec := SECTOR_SIZE div 4;
  
  fatSector := drv^.FATStart;
  cluster := 2;
  
  // Scan FAT for free cluster
  while fatSector < drv^.FATStart + drv^.BPB.FATSz32 do
  begin
    if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then
      Exit;
    
    i := 0;
    while i < entriesPerSec do
    begin
      P := PLongWord(@SectorBuf[i * 4]);
      
      if (P^ and $0FFFFFFF) = FAT32_FREE then
      begin
        // Found free cluster
        P^ := (P^ and $F0000000) or FAT32_EOC;
        
        // Write FAT
        ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]);
        
        Result := cluster;
        Exit;
      end;
      
      Inc(cluster);
      Inc(i);
    end;
    
    Inc(fatSector);
  end;
end;

//=============================================================================
// Directory Operations
//=============================================================================


function FAT32_MatchPattern(Name: PChar; Pattern: PChar): Boolean;
var
  nIdx, pIdx: Integer;
  n, p: Char;
begin
  nIdx := 0;
  pIdx := 0;

  while True do
  begin
    n := Name[nIdx];
    p := Pattern[pIdx];

    if p = #0 then
    begin
      Result := (n = #0);
      Exit;
    end;

    if p = '*' then
    begin
      Inc(pIdx);
      if Pattern[pIdx] = #0 then
      begin
        Result := True;  // '*' sonunda - t m n  kabul et
        Exit;
      end;

      // *XX pattern - recursive match
      while n <> #0 do
      begin
        if FAT32_MatchPattern(@Name[nIdx], @Pattern[pIdx]) then
        begin
          Result := True;
          Exit;
        end;
        Inc(nIdx);
        n := Name[nIdx];
      end;
      Result := False;
      Exit;
    end;

    if p = '?' then
    begin
      if n = #0 then
      begin
        Result := False;
        Exit;
      end;
      Inc(nIdx);
      Inc(pIdx);
      Continue;
    end;

    // Normal karakter - case-insensitive
    if StrUpChar(n) <> StrUpChar(p) then
    begin
      Result := False;
      Exit;
    end;

    Inc(nIdx);
    Inc(pIdx);
  end;
end;

procedure FAT32_ParseName83(Entry: PDirEntry; Buffer: PChar);
var
  i: Integer;
  j: Integer;
begin
  i := 0;
  j := 0;
  
  while (i < 8) and (Entry^.Name[i] <> ' ') do
  begin
    Buffer[j] := Entry^.Name[i];
    Inc(i);
    Inc(j);
  end;
  
  if Entry^.Name[8] <> ' ' then
  begin
    Buffer[j] := '.';
    Inc(j);
    i := 8;
    while (i < 11) and (Entry^.Name[i] <> ' ') do
    begin
      Buffer[j] := Entry^.Name[i];
      Inc(i);
      Inc(j);
    end;
  end;
  
  Buffer[j] := #0;
end;

function FAT32_ShortNameMatch(e: PDirEntry; Pattern: PChar): Boolean;
var
  name: array[0..12] of Char;
begin
  FAT32_ParseName83(e, @name[0]);
  Result := FAT32_MatchPattern(@name[0], Pattern);
end;

function FAT32_ShortNameMatch1(Entry: PDirEntry; Pattern: PChar): Boolean;
var
  entryName: array[0..12] of Char;
  i: Integer;
  j: Integer;
begin
  Result := False;
  
  // Convert 8.3 to string
  i := 0;
  j := 0;
  while (i < 8) and (Entry^.Name[i] <> ' ') do
  begin
    entryName[j] := ToUpper(Entry^.Name[i]);
    Inc(i);
    Inc(j);
  end;
  
  // Extension
  if Entry^.Name[8] <> ' ' then
  begin
    entryName[j] := '.';
    Inc(j);
    i := 8;
    while (i < 11) and (Entry^.Name[i] <> ' ') do
    begin
      entryName[j] := ToUpper(Entry^.Name[i]);
      Inc(i);
      Inc(j);
    end;
  end;
  
  entryName[j] := #0;
  
  // Wildcard match
  i := 0;
  j := 0;
  while (Pattern[i] <> #0) and (entryName[j] <> #0) do
  begin
    if Pattern[i] = '*' then
    begin
      // Skip to next dot or end
      while (entryName[j] <> #0) and (entryName[j] <> '.') do
        Inc(j);
      while (Pattern[i] <> #0) and (Pattern[i] <> '.') do
        Inc(i);
    end
    else if Pattern[i] = '?' then
    begin
      Inc(i);
      Inc(j);
    end
    else if ToUpper(Pattern[i]) = ToUpper(entryName[j]) then
    begin
      Inc(i);
      Inc(j);
    end
    else
    begin
      Exit;
    end;
  end;
  
  if Pattern[i] = #0 then
    Result := (entryName[j] = #0)
  else if Pattern[i] = '*' then
    Result := True;
end;



function FAT32_FindInDir(DriveIndex: Integer; DirCluster: LongWord;
                         Name: PChar; Entry: PDirEntry;
                         DirSector: PLongWord; DirOffset: PInteger): Boolean;
var
  drv: PDriveInfo;
  cluster: LongWord;
  sector: LongWord;
  secIdx: Integer;
  entryIdx: Integer;
  lba: LongWord;
  e: PDirEntry;
  eName: array[0..12] of Char;
begin
  Result := False;
  
  drv := @Drives[DriveIndex];
  cluster := DirCluster;
  
  while (cluster < FAT32_EOC) and (cluster <> FAT32_BAD) and (cluster >= 2) do
  begin
    lba := FAT32_ClusterToLBA(DriveIndex, cluster);
    
    secIdx := 0;
    while secIdx < drv^.SecPerClus do
    begin
      sector := lba + secIdx;
      
      if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, sector, @SectorBuf[0]) then
      begin
        Inc(secIdx);
        Continue;
      end;
      
      entryIdx := 0;
      while entryIdx < (SECTOR_SIZE div 32) do
      begin
        e := PDirEntry(@SectorBuf[entryIdx * 32]);
        
        // End of directory
        if Byte(e^.Name[0]) = 0 then Exit;
        
        // Skip deleted
        if Byte(e^.Name[0]) = $E5 then
        begin
          Inc(entryIdx);
          Continue;
        end;
        
        // Skip LFN
        if e^.Attr = ATTR_LFN then
        begin
          Inc(entryIdx);
          Continue;
        end;
        
        // Compare name
        FAT32_ParseName83(e, @eName[0]);
        
        if FAT32_ShortNameMatch(e, Name) then
        begin
          MemCopy(Entry, e, SizeOf(TDirEntry));
          
          if DirSector <> nil then
            DirSector^ := sector;
          
          if DirOffset <> nil then
            DirOffset^ := entryIdx * 32;
          
          Result := True;
          Exit;
        end;
        
        Inc(entryIdx);
      end;
      
      Inc(secIdx);
    end;
    
    cluster := FAT32_ReadFAT(DriveIndex, cluster);
  end;
end;

function FAT32_ResolvePath(DriveIndex: Integer; Path: PChar;
                           Entry: PDirEntry): Boolean;
var
  drv: PDriveInfo;
  currentCluster: LongWord;
  component: array[0..255] of Char;
  p: PChar;
  i: Integer;
  found: PDirEntry;
  tempEntry: TDirEntry;
begin
  Result := False;
  
  drv := @Drives[DriveIndex];
  currentCluster := drv^.RootClus;
  
  // Skip drive letter
  p := Path;
  if (StrLen(p) >= 2) and (p[1] = ':') then
    Inc(p, 2);
  
  // Skip leading slash
  if (p^ = '\') or (p^ = '/') then
    Inc(p);
  
  // Parse path components
  while p^ <> #0 do
  begin
    // Extract component
    i := 0;
    while (p^ <> #0) and (p^ <> '\') and (p^ <> '/') do
    begin
      component[i] := p^;
      Inc(i);
      Inc(p);
    end;
    component[i] := #0;
    
    if i = 0 then
    begin
      if (p^ = '\') or (p^ = '/') then
        Inc(p);
      Continue;
    end;
    
    // Last component?
    if p^ = #0 then
    begin
      // Find in current dir
      if FAT32_FindInDir(DriveIndex, currentCluster, @component[0], 
                         Entry, nil, nil) then
      begin
        Result := True;
        Exit;
      end
      else
        Exit;
    end
    else
    begin
      // Navigate into directory
      if FAT32_FindInDir(DriveIndex, currentCluster, @component[0],
                         @tempEntry, nil, nil) then
      begin
        if (tempEntry.Attr and ATTR_DIRECTORY) <> 0 then
        begin
          currentCluster := LongWord(tempEntry.FstClusHI) shl 16 or
                            LongWord(tempEntry.FstClusLO);
          if currentCluster = 0 then
            currentCluster := drv^.RootClus;
        end
        else
          Exit;  // Not a directory
      end
      else
        Exit;  // Not found
      
      // Skip slash
      if (p^ = '\') or (p^ = '/') then
        Inc(p);
    end;
  end;
  
  // Path was just directory
  Entry^.FstClusHI := Word(currentCluster shr 16);
  Entry^.FstClusLO := Word(currentCluster);
  Entry^.Attr := ATTR_DIRECTORY;
  Entry^.FileSize := 0;
  Result := True;
end;

//=============================================================================
// OpenFile / CloseFile
//=============================================================================

function FAT32_AllocHandle: Integer;
var
  i: Integer;
begin
  Result := -1;
  i := 0;
  while i < MAX_OPEN_FILES do
  begin
    if not OpenFiles[i].Used then
    begin
      Result := i;
      Exit;
    end;
    Inc(i);
  end;
end;

function FAT32_GetDirCluster(DriveIndex: Integer; Path: PChar): LongWord;
var
  entry: TDirEntry;
  drv: PDriveInfo;
  lastSlash: PChar;
  dirPath: array[0..MAX_PATH-1] of Char;
  i: Integer;
begin
  Result := 0;
  drv := @Drives[DriveIndex];
  
  // Find last slash
  lastSlash := nil;
  i := 0;
  while Path[i] <> #0 do
  begin
    if (Path[i] = '\') or (Path[i] = '/') then
      lastSlash := @Path[i];
    Inc(i);
  end;
  
  if lastSlash = nil then
  begin
    Result := drv^.RootClus;
    Exit;
  end;
  
  // Copy dir part
  i := 0;
  while @Path[i] <> lastSlash do
  begin
    dirPath[i] := Path[i];
    Inc(i);
  end;
  dirPath[i] := #0;
  
  if FAT32_ResolvePath(DriveIndex, @dirPath[0], @entry) then
    Result := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);
  
  if Result = 0 then
    Result := drv^.RootClus;
end;

function OpenFile(Path: PChar; Mode: Byte): Integer;
var
  driveIndex: Integer;
  entry: TDirEntry;
  handle: Integer;
  fh: PFileHandle;
  drv: PDriveInfo;
  cluster: LongWord;
  dirSec: LongWord;
  dirOff: Integer;
  dirClus: LongWord;
  newCluster: LongWord;
  newEntry: TDirEntry;
  fileName: PChar;
  i: Integer;
  j: Integer;
  lba: LongWord;
begin
  Result := -1;
  
  driveIndex := FAT32_GetDriveFromPath(Path);
  if driveIndex < 0 then Exit;
  
  drv := @Drives[driveIndex];
  if not drv^.IsFAT32 then Exit;
  
  handle := FAT32_AllocHandle;
  if handle < 0 then Exit;
  
  fh := @OpenFiles[handle];
  MemSet(fh, 0, SizeOf(TFileHandle));
  
  // Try to find the file
  if FAT32_ResolvePath(driveIndex, Path, @entry) then
  begin
    // File exists
    if (Mode and FILE_CREATE) <> 0 then
    begin
      // Truncate?
      cluster := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);
      // TODO: Free cluster chain for truncate
    end;
    
    cluster := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);
    
    fh^.Used := True;
    fh^.DriveIndex := driveIndex;
    fh^.Mode := Mode;
    fh^.FileSize := entry.FileSize;
    fh^.FilePos := 0;
    fh^.StartCluster := cluster;
    fh^.CurrentCluster := cluster;
    fh^.CurrentSector := FAT32_ClusterToLBA(driveIndex, cluster);
    fh^.SectorOffset := 0;
    fh^.BufferDirty := False;
    
    StrCopy(@fh^.Name[0], Path);
    
    // APPEND mode
    if (Mode and FILE_APPEND) <> 0 then
      SeekFile(handle, 0, SEEK_END);
    
    // Read first sector
    ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
    
    Result := handle;
  end
  else if (Mode and FILE_CREATE) <> 0 then
  begin
    // Create new file
    newCluster := FAT32_AllocCluster(driveIndex);
    if newCluster = 0 then Exit;
    
    // Get directory cluster
    dirClus := FAT32_GetDirCluster(driveIndex, Path);
    
    // Find filename part
    fileName := Path;
    i := 0;
    while Path[i] <> #0 do
    begin
      if (Path[i] = '\') or (Path[i] = '/') then
        fileName := @Path[i + 1];
      Inc(i);
    end;
    
    // Create directory entry
    MemSet(@newEntry, 0, SizeOf(TDirEntry));
    
    // 8.3 name
    i := 0;
    j := 0;
    while (fileName[i] <> #0) and (fileName[i] <> '.') and (j < 8) do
    begin
      newEntry.Name[j] := ToUpper(fileName[i]);
      Inc(i);
      Inc(j);
    end;
    while j < 8 do
    begin
      newEntry.Name[j] := ' ';
      Inc(j);
    end;
    
    // Extension
    if fileName[i] = '.' then
    begin
      Inc(i);
      j := 8;
      while (fileName[i] <> #0) and (j < 11) do
      begin
        newEntry.Name[j] := ToUpper(fileName[i]);
        Inc(i);
        Inc(j);
      end;
    end;
    while j < 11 do
    begin
      newEntry.Name[j] := ' ';
      Inc(j);
    end;
    
    newEntry.Attr := ATTR_ARCHIVE;
    newEntry.FstClusHI := Word(newCluster shr 16);
    newEntry.FstClusLO := Word(newCluster);
    newEntry.FileSize := 0;
    
    // Write dir entry to directory cluster
    lba := FAT32_ClusterToLBA(driveIndex, dirClus);
    
    if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]) then
    begin
      i := 0;
      while i < (SECTOR_SIZE div 32) do
      begin
        if (Byte(SectorBuf[i * 32]) = 0) or (Byte(SectorBuf[i * 32]) = $E5) then
        begin
          MemCopy(@SectorBuf[i * 32], @newEntry, SizeOf(TDirEntry));
          ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]);
          Break;
        end;
        Inc(i);
      end;
    end;
    
    fh^.Used := True;
    fh^.DriveIndex := driveIndex;
    fh^.Mode := Mode;
    fh^.FileSize := 0;
    fh^.FilePos := 0;
    fh^.StartCluster := newCluster;
    fh^.CurrentCluster := newCluster;
    fh^.CurrentSector := FAT32_ClusterToLBA(driveIndex, newCluster);
    fh^.SectorOffset := 0;
    fh^.BufferDirty := False;
    fh^.DirSector := lba;
    fh^.DirOffset := i * 32;
    
    StrCopy(@fh^.Name[0], Path);
    
    MemSet(@fh^.Buffer[0], 0, SECTOR_SIZE);
    
    Result := handle;
  end;
end;

//=============================================================================
// ReadFile
//=============================================================================

function ReadFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
var
  fh: PFileHandle;
  drv: PDriveInfo;
  bytesRead: LongWord;
  toRead: LongWord;
  bufP: PByte;
  remaining: LongWord;
  nextCluster: LongWord;
  nextSector: LongWord;
begin
  Result := 0;
  
  if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
  
  fh := @OpenFiles[Handle];
  if not fh^.Used then Exit;
  if (fh^.Mode and FILE_READ) = 0 then Exit;
  
  drv := @Drives[fh^.DriveIndex];
  
  bufP := PByte(Buffer);
  bytesRead := 0;
  remaining := Size;
  
  if fh^.FilePos + remaining > fh^.FileSize then
    remaining := fh^.FileSize - fh^.FilePos;
  
  while remaining > 0 do
  begin
    // How much can we read from current sector?
    toRead := SECTOR_SIZE - fh^.SectorOffset;
    if toRead > remaining then
      toRead := remaining;
    
    // Copy from buffer
    MemCopy(bufP, @fh^.Buffer[fh^.SectorOffset], toRead);
    
    Inc(bufP, toRead);
    Inc(bytesRead, toRead);
    Inc(fh^.FilePos, toRead);
    Inc(fh^.SectorOffset, toRead);
    Dec(remaining, toRead);
    
    // Advance sector
    if fh^.SectorOffset >= SECTOR_SIZE then
    begin
      fh^.SectorOffset := 0;
      Inc(fh^.CurrentSector);
      
      // Need next cluster?
      if fh^.CurrentSector >= FAT32_ClusterToLBA(fh^.DriveIndex, fh^.CurrentCluster) + drv^.SecPerClus then
      begin
        nextCluster := FAT32_ReadFAT(fh^.DriveIndex, fh^.CurrentCluster);
        
        if (nextCluster >= FAT32_EOC) or (nextCluster < 2) then
          Break;  // End of file
        
        fh^.CurrentCluster := nextCluster;
        fh^.CurrentSector := FAT32_ClusterToLBA(fh^.DriveIndex, nextCluster);
      end;
      
      // Read new sector
      if remaining > 0 then
        ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
    end;
  end;
  
  Result := bytesRead;
end;

//=============================================================================
// WriteFile
//=============================================================================

function WriteFile(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;
var
  fh: PFileHandle;
  drv: PDriveInfo;
  bytesWritten: LongWord;
  toWrite: LongWord;
  bufP: PByte;
  remaining: LongWord;
  nextCluster: LongWord;
  dirEntry: PDirEntry;
  lba: LongWord;
begin
  Result := 0;
  
  if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
  
  fh := @OpenFiles[Handle];
  if not fh^.Used then Exit;
  if (fh^.Mode and FILE_WRITE) = 0 then Exit;
  
  drv := @Drives[fh^.DriveIndex];
  
  bufP := PByte(Buffer);
  bytesWritten := 0;
  remaining := Size;
  
  while remaining > 0 do
  begin
    toWrite := SECTOR_SIZE - fh^.SectorOffset;
    if toWrite > remaining then
      toWrite := remaining;
    
    MemCopy(@fh^.Buffer[fh^.SectorOffset], bufP, toWrite);
    fh^.BufferDirty := True;
    
    Inc(bufP, toWrite);
    Inc(bytesWritten, toWrite);
    Inc(fh^.FilePos, toWrite);
    Inc(fh^.SectorOffset, toWrite);
    Dec(remaining, toWrite);
    
    if fh^.FilePos > fh^.FileSize then
      fh^.FileSize := fh^.FilePos;
    
    if fh^.SectorOffset >= SECTOR_SIZE then
    begin
      // Flush current sector
      ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
      fh^.BufferDirty := False;
      fh^.SectorOffset := 0;
      Inc(fh^.CurrentSector);
      
      // Need new cluster?
      if fh^.CurrentSector >= FAT32_ClusterToLBA(fh^.DriveIndex, fh^.CurrentCluster) + drv^.SecPerClus then
      begin
        // Check if FAT has next cluster
        nextCluster := FAT32_ReadFAT(fh^.DriveIndex, fh^.CurrentCluster);
        
        if (nextCluster >= FAT32_EOC) or (nextCluster < 2) then
        begin
          // Allocate new cluster
          nextCluster := FAT32_AllocCluster(fh^.DriveIndex);
          if nextCluster = 0 then Break;  // No space
          
          // Link current ? new
          FAT32_WriteFAT(fh^.DriveIndex, fh^.CurrentCluster, nextCluster);
        end;
        
        fh^.CurrentCluster := nextCluster;
        fh^.CurrentSector := FAT32_ClusterToLBA(fh^.DriveIndex, nextCluster);
        
        MemSet(@fh^.Buffer[0], 0, SECTOR_SIZE);
      end;
    end;
  end;
  
  Result := bytesWritten;
end;

//=============================================================================
// SeekFile
//=============================================================================

function SeekFile(Handle: Integer; Offset: LongInt; Origin: Byte): LongWord;
var
  fh: PFileHandle;
  drv: PDriveInfo;
  newPos: LongInt;
  targetCluster: LongWord;
  clusterIndex: LongWord;
  i: LongWord;
  lba: LongWord;
begin
  Result := $FFFFFFFF;
  
  if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
  
  fh := @OpenFiles[Handle];
  if not fh^.Used then Exit;
  
  drv := @Drives[fh^.DriveIndex];
  
  // Calculate new position
  case Origin of
    SEEK_SET: newPos := Offset;
    SEEK_CUR: newPos := LongInt(fh^.FilePos) + Offset;
    SEEK_END: newPos := LongInt(fh^.FileSize) + Offset;
  else
    newPos := Offset;
  end;
  
  if newPos < 0 then newPos := 0;
  if LongWord(newPos) > fh^.FileSize then newPos := LongInt(fh^.FileSize);
  
  // Flush buffer if dirty
  if fh^.BufferDirty then
  begin
    ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
    fh^.BufferDirty := False;
  end;
  
  // Navigate to new cluster
  clusterIndex := LongWord(newPos) div drv^.BytesPerClus;
  
  // Walk cluster chain from start
  targetCluster := fh^.StartCluster;
  i := 0;
  while i < clusterIndex do
  begin
    targetCluster := FAT32_ReadFAT(fh^.DriveIndex, targetCluster);
    if (targetCluster >= FAT32_EOC) or (targetCluster < 2) then
    begin
      targetCluster := fh^.StartCluster;
      Break;
    end;
    Inc(i);
  end;
  
  fh^.FilePos := LongWord(newPos);
  fh^.CurrentCluster := targetCluster;
  
  lba := FAT32_ClusterToLBA(fh^.DriveIndex, targetCluster);
  fh^.CurrentSector := lba + ((LongWord(newPos) mod drv^.BytesPerClus) div SECTOR_SIZE);
  fh^.SectorOffset := LongWord(newPos) mod SECTOR_SIZE;
  
  // Read new sector
  ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
  
  Result := LongWord(newPos);
end;

//=============================================================================
// FilePos / FileSize
//=============================================================================

function FilePos(Handle: Integer): LongWord;
begin
  Result := 0;
  if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
  if not OpenFiles[Handle].Used then Exit;
  Result := OpenFiles[Handle].FilePos;
end;

function FileSize(Handle: Integer): LongWord;
begin
  Result := 0;
  if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
  if not OpenFiles[Handle].Used then Exit;
  Result := OpenFiles[Handle].FileSize;
end;

//=============================================================================
// CloseFile
//=============================================================================

procedure CloseFile(Handle: Integer); Overload;
var
  fh: PFileHandle;
  drv: PDriveInfo;
  dirEntry: PDirEntry;
begin
  if (Handle < 0) or (Handle >= MAX_OPEN_FILES) then Exit;
  
  fh := @OpenFiles[Handle];
  if not fh^.Used then Exit;
  
  drv := @Drives[fh^.DriveIndex];
  
  // Flush dirty buffer
  if fh^.BufferDirty then
  begin
    ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fh^.CurrentSector, @fh^.Buffer[0]);
    fh^.BufferDirty := False;
  end;
  
  // Update dir entry file size
  if (fh^.Mode and FILE_WRITE) <> 0 then
  begin
    if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.DirSector, @SectorBuf[0]) then
    begin
      dirEntry := PDirEntry(@SectorBuf[fh^.DirOffset]);
      dirEntry^.FileSize := fh^.FileSize;
      ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, fh^.DirSector, @SectorBuf[0]);
    end;
  end;
  
  fh^.Used := False;
end;

//=============================================================================
// MakeDir
//=============================================================================

function MakeDir(Path: PChar): Boolean;
var
  driveIndex: Integer;
  dirCluster: LongWord;
  newCluster: LongWord;
  drv: PDriveInfo;
  entry: TDirEntry;
  lba: LongWord;
  dirName: PChar;
  i: Integer;
  j: Integer;
begin
  Result := False;
  
  driveIndex := FAT32_GetDriveFromPath(Path);
  if driveIndex < 0 then Exit;
  
  drv := @Drives[driveIndex];
  if not drv^.IsFAT32 then Exit;
  
  // Check if already exists
  if FAT32_ResolvePath(driveIndex, Path, @entry) then Exit;
  
  // Get dir name
  dirName := Path;
  i := 0;
  while Path[i] <> #0 do
  begin
    if (Path[i] = '\') or (Path[i] = '/') then
      dirName := @Path[i + 1];
    Inc(i);
  end;
  
  // Get parent dir cluster
  dirCluster := FAT32_GetDirCluster(driveIndex, Path);
  
  // Allocate cluster for new dir
  newCluster := FAT32_AllocCluster(driveIndex);
  if newCluster = 0 then Exit;
  
  // Clear new cluster
  MemSet(@SectorBuf[0], 0, SECTOR_SIZE);
  lba := FAT32_ClusterToLBA(driveIndex, newCluster);
  i := 0;
  while i < drv^.SecPerClus do
  begin
    ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, lba + i, @SectorBuf[0]);
    Inc(i);
  end;
  
  // Create . and .. entries
  lba := FAT32_ClusterToLBA(driveIndex, newCluster);
  if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]) then
  begin
    // . entry (self)
    MemSet(@SectorBuf[0], 32, 0);
    SectorBuf[0] := Byte('.');
    i := 1;
    while i < 11 do begin SectorBuf[i] := Byte(' '); Inc(i); end;
    SectorBuf[11] := ATTR_DIRECTORY;
    SectorBuf[26] := Byte(newCluster);
    SectorBuf[27] := Byte(newCluster shr 8);
    SectorBuf[20] := Byte(newCluster shr 16);
    SectorBuf[21] := Byte(newCluster shr 24);
    
    // .. entry (parent)
    SectorBuf[32] := Byte('.');
    SectorBuf[33] := Byte('.');
    i := 34;
    while i < 43 do begin SectorBuf[i] := Byte(' '); Inc(i); end;
    SectorBuf[43] := ATTR_DIRECTORY;
    SectorBuf[58] := Byte(dirCluster);
    SectorBuf[59] := Byte(dirCluster shr 8);
    SectorBuf[52] := Byte(dirCluster shr 16);
    SectorBuf[53] := Byte(dirCluster shr 24);
    
    ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]);
  end;
  
  // Create dir entry in parent
  MemSet(@entry, 0, SizeOf(TDirEntry));
  
  // 8.3 name
  j := 0;
  i := 0;
  while (dirName[i] <> #0) and (j < 8) do
  begin
    entry.Name[j] := ToUpper(dirName[i]);
    Inc(i);
    Inc(j);
  end;
  while j < 11 do
  begin
    entry.Name[j] := ' ';
    Inc(j);
  end;
  
  entry.Attr := ATTR_DIRECTORY;
  entry.FstClusHI := Word(newCluster shr 16);
  entry.FstClusLO := Word(newCluster);
  entry.FileSize := 0;
  
  // Write entry to parent
  lba := FAT32_ClusterToLBA(driveIndex, dirCluster);
  if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]) then
  begin
    i := 0;
    while i < (SECTOR_SIZE div 32) do
    begin
      if (Byte(SectorBuf[i * 32]) = 0) or (Byte(SectorBuf[i * 32]) = $E5) then
      begin
        MemCopy(@SectorBuf[i * 32], @entry, SizeOf(TDirEntry));
        ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, lba, @SectorBuf[0]);
        Result := True;
        Exit;
      end;
      Inc(i);
    end;
  end;
end;

//=============================================================================
// DeleteFile
//=============================================================================

function DeleteFile(Path: PChar): Boolean;
var
  driveIndex: Integer;
  entry: TDirEntry;
  dirSec: LongWord;
  dirOff: Integer;
  drv: PDriveInfo;
  cluster: LongWord;
  nextCluster: LongWord;
  dirCluster: LongWord;
  fileName: PChar;
  i: Integer;
begin
  Result := False;

  driveIndex := FAT32_GetDriveFromPath(Path);
  if driveIndex < 0 then Exit;

  drv := @Drives[driveIndex];

  // Get parent dir cluster
  dirCluster := FAT32_GetDirCluster(driveIndex, Path);

  // *** D�ZELTME: sadece dosya ad� k�sm�n� ��kar ***
  fileName := Path;
  i := 0;
  while Path[i] <> #0 do
  begin
    if (Path[i] = '\') or (Path[i] = '/') then
      fileName := @Path[i + 1];
    Inc(i);
  end;

  // Find entry � art�k sadece "TEST.TXT" ge�iyoruz
  if not FAT32_FindInDir(driveIndex, dirCluster, fileName, @entry, @dirSec, @dirOff) then
    Exit;

  // Can't delete directory this way
  if (entry.Attr and ATTR_DIRECTORY) <> 0 then Exit;

  // Free cluster chain
  cluster := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);

  while (cluster >= 2) and (cluster < FAT32_EOC) do
  begin
    nextCluster := FAT32_ReadFAT(driveIndex, cluster);
    FAT32_WriteFAT(driveIndex, cluster, FAT32_FREE);
    cluster := nextCluster;
  end;

  // Mark dir entry as deleted ($E5)
  if ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, dirSec, @SectorBuf[0]) then
  begin
    SectorBuf[dirOff] := $E5;
    ATA_WriteSector(drv^.ATAPort, drv^.DriveNum, dirSec, @SectorBuf[0]);
    Result := True;
  end;
end;
//=============================================================================
// FindFirst / FindNext / FindClose
//=============================================================================

var
  FindHandles: array[0..7] of TFindHandle;



function FAT32_GetExtension(Name: PChar): PChar;
var
  i: Integer;
begin
  i := 0;
  while Name[i] <> #0 do Inc(i);

  while (i > 0) and (Name[i] <> '.') do Dec(i);
  
  if (i > 0) and (Name[i] = '.') then
    Result := @Name[i]
  else
    Result := @Name[i];
end;

function FAT32_ExtensionMatch(Name: PChar; Pattern: PChar): Boolean;
var
  ext: PChar;
begin
  ext := FAT32_GetExtension(Name);
  Result := FAT32_MatchPattern(ext, Pattern);
end;

function FindFirst(Path, Pattern: PChar; Attr: Byte;
                         SearchRec: PSearchRec): Integer;
var
  driveIndex: Integer;
  entry: TDirEntry;
  drv: PDriveInfo;
  fh: PFindHandle;
  i: Integer;
  dirCluster: LongWord;
begin
  Result := -1;

  driveIndex := FAT32_GetDriveFromPath(Path);
  if driveIndex < 0 then Exit;

  drv := @Drives[driveIndex];

  // Find free handle
  i := 0;
  while i < 8 do
  begin
    if not FindHandles[i].Used then Break;
    Inc(i);
  end;
  
  if i >= 8 then Exit;
  
  fh := @FindHandles[i];
  MemSet(fh, 0, SizeOf(TFindHandle));
  
  fh^.Used := True;
  fh^.DriveIndex := driveIndex;
  fh^.SearchAttr := Attr;
  
  // Pattern bo  ise '*' kullan (t m dosyalar)
  if Pattern = nil then
    StrCopy(@fh^.SearchPath[0], '*')
  else
    StrCopy(@fh^.SearchPath[0], Pattern);
  
  // Get dir cluster
  if FAT32_ResolvePath(driveIndex, Path, @entry) then
  begin
    fh^.DirCluster := LongWord(entry.FstClusHI) shl 16 or LongWord(entry.FstClusLO);
    if fh^.DirCluster = 0 then
      fh^.DirCluster := drv^.RootClus;
  end
  else
    fh^.DirCluster := drv^.RootClus;
  
  fh^.DirSector := FAT32_ClusterToLBA(driveIndex, fh^.DirCluster);
  fh^.DirIndex := 0;

  Result := i;
  
  // Find first match
  if not FindNext(i, SearchRec) then
  begin
    FindHandles[i].Used := False;
    Result := -1;
  end;
end;

function FindNext(FindHandle: Integer; SearchRec: PSearchRec): Boolean;
var
  fh: PFindHandle;
  drv: PDriveInfo;
  e: PDirEntry;
  cluster: LongWord;
  secInClus: Integer;
  lba: LongWord;
  name: array[0..12] of Char;
  matched: Boolean;
  isDirectory: Boolean;
begin
  Result := False;
 
  if (FindHandle < 0) or (FindHandle >= 8) then Exit;
 
  fh := @FindHandles[FindHandle];
  if not fh^.Used then Exit;
 
  drv := @Drives[fh^.DriveIndex];
  cluster := fh^.DirCluster;
 
  while True do
  begin
    if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fh^.DirSector, @SectorBuf[0]) then
      Exit;
 
    while fh^.DirIndex < (SECTOR_SIZE div 32) do
    begin
      e := PDirEntry(@SectorBuf[fh^.DirIndex * 32]);
      if Byte(e^.Name[0]) = 0 then Exit;
      Inc(fh^.DirIndex);
 
      if Byte(e^.Name[0]) = $E5 then Continue;
      if e^.Attr = ATTR_LFN then Continue;
      if (e^.Attr and ATTR_VOLUME_ID) <> 0 then Continue;
 
      isDirectory := (e^.Attr and ATTR_DIRECTORY) <> 0;
 
      //-----------------------------------------------------------
      // DUZELTME 1: "." ve ".." girdilerini atla
      //-----------------------------------------------------------
      if isDirectory then
      begin
        if (e^.Name[0] = '.') then
        begin
          if (e^.Name[1] = ' ') or
             ((e^.Name[1] = '.') and (e^.Name[2] = ' ')) then
            Continue;
        end;
      end;
 
      FAT32_ParseName83(e, @name[0]);
 
      matched := False;
 
      //-----------------------------------------------------------
      // DUZELTME 2: Klasorler pattern'den BAGIMSIZ kabul edilir
      // (SearchAttr klasorleri istiyorsa)
      //-----------------------------------------------------------
      if isDirectory then
      begin
        if (fh^.SearchAttr and ATTR_DIRECTORY) <> 0 then
          matched := True   // Klasor isteniyor -> isim/uzanti ONEMSIZ
        else
          matched := False; // Klasor istenmiyor -> atla
      end
      else
      begin
        //---------------------------------------------------------
        // Normal dosya -> pattern match UYGULANIR (eski mantik)
        //---------------------------------------------------------
        if StrCmp(@fh^.SearchPath[0], '*') = 0 then
          matched := True
        else if (fh^.SearchPath[0] <> #0) and (fh^.SearchPath[1] = '*') then
          matched := FAT32_ExtensionMatch(@name[0], @fh^.SearchPath[0])
        else
          matched := FAT32_MatchPattern(@name[0], @fh^.SearchPath[0]);
      end;
 
      if matched then
      begin
        FAT32_ParseName83(e, @SearchRec^.Name[0]);
        FAT32_ParseName83(e, @SearchRec^.ShortName[0]);
        SearchRec^.Attr := e^.Attr;
        SearchRec^.IsDir:=(e^.Attr and ATTR_DIRECTORY) <> 0;
        SearchRec^.FileSize := e^.FileSize;
        SearchRec^.StartCluster := LongWord(e^.FstClusHI) shl 16 or
                                  LongWord(e^.FstClusLO);
        Result := True;
        Exit;
      end;
    end;
 
    // Next sector
    fh^.DirIndex := 0;
    Inc(fh^.DirSector);
 
    secInClus := Integer((fh^.DirSector - FAT32_ClusterToLBA(fh^.DriveIndex, cluster))
                          mod drv^.SecPerClus);
 
    if secInClus = 0 then
    begin
      cluster := FAT32_ReadFAT(fh^.DriveIndex, cluster);
      if (cluster >= FAT32_EOC) or (cluster < 2) then Exit;
 
      fh^.DirCluster := cluster;
      fh^.DirSector := FAT32_ClusterToLBA(fh^.DriveIndex, cluster);
    end;
  end;
end;



procedure FindClose(FindHandle: Integer);
begin
  if (FindHandle < 0) or (FindHandle >= 8) then Exit;
  FindHandles[FindHandle].Used := False;
end;

//=============================================================================
// Init
//=============================================================================

procedure FAT32_Init;
var
  i: Integer;
begin
  i := 0;
  while i < MAX_DRIVES do
  begin
    MemSet(@Drives[i], 0, SizeOf(TDriveInfo));
    Inc(i);
  end;
  
  i := 0;
  while i < MAX_OPEN_FILES do
  begin
    OpenFiles[i].Used := False;
    Inc(i);
  end;
  
  i := 0;
  while i < 8 do
  begin
    FindHandles[i].Used := False;
    Inc(i);
  end;
  
  DriveCount := 0;
  
  // Scan for drives
  FAT32_ScanDrives;
end;



//=============================================================================
// HDD Kapasite ve Alan Hesaplama (FAT32 Taramas�)
//=============================================================================

function FAT32_GetDriveSpace(DriveIndex: Integer; var Info: TDriveSpaceInfo): Boolean;
var
  drv: PDriveInfo;
  fatSector: LongWord;
  totalDataSectors: LongWord;
  clustersCount: LongWord;
  freeClus: LongWord;
  currentCluster: LongWord;
  entriesPerSec: Integer;
  i: Integer;
  p: PLongWord;
  clusterVal: LongWord;
begin
  Result := False;

  if (DriveIndex < 0) or (DriveIndex >= DriveCount) then Exit;

  drv := @Drives[DriveIndex];
  if not drv^.Present or not drv^.IsFAT32 then Exit;

  // 1. Toplam Veri Cluster Say�s�n� Hesapla
  totalDataSectors := drv^.BPB.TotSec32 - drv^.DataStart;
  clustersCount := totalDataSectors div drv^.SecPerClus;

  freeClus := 0;
  currentCluster := 2; // FAT32 ilk veri cluster'� 2'dir
  fatSector := drv^.FATStart;
  entriesPerSec := SECTOR_SIZE div 4; // 512 / 4 = 128 entry per sector

  // 2. FAT Tablosunu Tarafarak Bo� Cluster'lar� Say ($00000000 = FAT32_FREE)
  while (currentCluster < clustersCount + 2) and (fatSector < drv^.FATStart + drv^.BPB.FATSz32) do
  begin
    if not ATA_ReadSector(drv^.ATAPort, drv^.DriveNum, fatSector, @SectorBuf[0]) then Break;

    i := 0;
    while (i < entriesPerSec) and (currentCluster < clustersCount + 2) do
    begin
      p := PLongWord(@SectorBuf[i * 4]);
      clusterVal := p^ and $0FFFFFFF;

      if clusterVal = FAT32_FREE then
        Inc(freeClus);

      Inc(currentCluster);
      Inc(i);
    end;

    Inc(fatSector);
  end;

  // 3. Bilgileri Doldur
  Info.DriveLetter   := drv^.Letter;
  Info.IsFAT32       := drv^.IsFAT32;
  Info.BytesPerClus  := drv^.BytesPerClus;
  Info.TotalClusters := clustersCount;
  Info.FreeClusters  := freeClus;
  Info.UsedClusters  := clustersCount - freeClus;

  // 4. KB ve MB D�n���mleri (32-bit ta�ma ya�amamak i�in hesaplama s�ras�)
  // BytesPerClus genelde 4096, 8192, 16384, 32768 baytt�r.
  Info.TotalKB := (clustersCount * (drv^.BytesPerClus div 1024));
  Info.FreeKB  := (freeClus * (drv^.BytesPerClus div 1024));
  Info.UsedKB  := Info.TotalKB - Info.FreeKB;

  Info.TotalMB := Info.TotalKB div 1024;
  Info.FreeMB  := Info.FreeKB div 1024;
  Info.UsedMB  := Info.UsedKB div 1024;

  Result := True;
end;


{
// Bayt De�erini "1024 MB" veya "512 KB" �eklinde Metne �evirir
procedure FormatSizeStr(KBValue: LongWord; Buffer: PChar);
var
  MBVal: LongWord;
  StrTmp: PChar;
begin
  if KBValue >= 1024 then
  begin
    MBVal := KBValue div 1024;
    StrTmp := IntToStr(MBVal) + ' MB';
  end
  else
  begin
    StrTmp := IntToStr(KBValue) + ' KB';
  end;
  StrCopy(Buffer, PChar(StrTmp));
end; }


procedure DrawHDDInfoWindow;
var
  spaceInfo: TDriveSpaceInfo;
  i: Integer;
  szBuf: array[0..31] of Char;
begin
  // T�m S�r�c�leri Tara ve Bilgileri Yazd�r
  i := 0;
  while i < DriveCount do
  begin
    if FAT32_GetDriveSpace(i, spaceInfo) then
    begin
      // Konsola veya MemoryWindow �zerine �izim
      // �rnek Formatl� ��kt�lar:
      
      // S�r�c� Harfi
      // Drive: C:\

      // Toplam Boyut
      // Total Size : 2048 MB (2097152 KB)
      IntToPChar(spaceInfo.TotalKB, @szBuf[0]);

      
      
      // Bo� Alan
      // Free Space : 1500 MB
      IntToPChar(spaceInfo.FreeKB, @szBuf[0]);

      // Kullan�lan Alan
      // Used Space : 548 MB
      IntToPChar(spaceInfo.UsedKB, @szBuf[0]);

      // Doluluk Y�zdesi (Hesaplama)
      // Usage: %26
      // PercentUsed := (spaceInfo.UsedMB * 100) div spaceInfo.TotalMB;
    end;
    Inc(i);
  end;
end;


end.
{ =========================================================
  KULLANIM �RNE��
  ========================================================= }

(*
procedure TestFAT32;
var
  handle: Integer;
  findHandle: Integer;
  findData: TSearchRec;
  buffer: array[0..1023] of Byte;
  bytesRead: LongWord;
  pos: LongWord;
begin
  // Initialize
  FAT32_Init;

  // WRITE FILE
  handle := FAT32_OpenFile('C:\TEST.TXT', FILE_WRITE or FILE_CREATE);
  if handle >= 0 then
  begin
    FAT32_WriteFile(handle, 'Hello, Kernel World!'#13#10, 22);
    FAT32_WriteFile(handle, 'Second line.'#13#10, 14);
    FAT32_CloseFile(handle);
  end;

  // READ FILE
  handle := FAT32_OpenFile('C:\TEST.TXT', FILE_READ);
  if handle >= 0 then
  begin
    bytesRead := FAT32_ReadFile(handle, @buffer[0], SizeOf(buffer));
    buffer[bytesRead] := 0;
    ShowMessage(@buffer[0]);
    FAT32_CloseFile(handle);
  end;

  // SEEK FILE
  handle := FAT32_OpenFile('C:\TEST.TXT', FILE_READ);
  if handle >= 0 then
  begin
    FAT32_SeekFile(handle, 7, SEEK_SET);  // Seek to pos 7
    pos := FAT32_FilePos(handle);         // Get position
    bytesRead := FAT32_ReadFile(handle, @buffer[0], 5);
    FAT32_CloseFile(handle);
  end;

  // MAKE DIR
  FAT32_MakeDir('C:\MYDIR');
  FAT32_MakeDir('C:\MYDIR\SUBDIR');

  // DELETE FILE
  FAT32_DeleteFile('C:\TEST.TXT');

  // FIND FILES
  findHandle := FAT32_FindFirst('C:\', '*.TXT', 0, @findData);
  if findHandle >= 0 then
  begin
    repeat
      ShowMessage(findData.Name);
    until not FAT32_FindNext(findHandle, @findData);

    FAT32_FindClose(findHandle);
  end;
end;
*)


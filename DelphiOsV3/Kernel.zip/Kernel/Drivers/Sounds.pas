unit Sounds;
{===========================================================
   SB16 16-bit PCM WAV Player (Delphi 7 + QEMU)
   Author: ChatGPT + Ekrem
===========================================================}

interface

uses
  SysUtils, GUI, GUIControls, Ports, Pit,Messages, Memory, Draw32, Fat32, Math;


const
  SB_BASE   = $220;
  SB_RESET  = $226;
  SB_READ   = $22A;
  SB_WRITE  = $22C;
  SB_STATUS = $22E;


type
  PLongWord=^LongWord;


type
  TMidiEvent = record
    delta: LongWord;
    status: Byte;
    data1: Byte;
    data2: Byte;
  end;


//----------------------
// DMA TABLES
//----------------------
var
  DmaChannel: array [0..7, 1..3] of Byte =
  ( ($87, $00, $01),
    ($83, $02, $03),
    ($81, $04, $05),
    ($82, $06, $07),
    ($8F, $C0, $C2),
    ($8B, $C4, $C6),   // channel 5 = 16-bit SB16
    ($89, $C8, $CA),
    ($8A, $CC, $CE) );

  DmaPort: array [0..7, 1..3] of Byte =
  ( ($0A, $0B, $0C), ($0A, $0B, $0C),
    ($0A, $0B, $0C), ($0A, $0B, $0C),
    ($D4, $D6, $D8), ($D4, $D6, $D8),
    ($D4, $D6, $D8), ($D4, $D6, $D8) );



    procedure PlayWav(FileName: PChar);

implementation
//----------------------
// DSP LOW-LEVEL
//----------------------
function dspready: Boolean;
begin
  Result := (ReadPortB(SB_STATUS) and $80) = 0;
end;

procedure dspwrite(b: Byte);
begin
  while not dspready do ;
  WritePortB(SB_WRITE, b);
end;

function dspread: Byte;
begin
  while (ReadPortB(SB_STATUS) and $80) = 0 do ;
  Result := ReadPortB(SB_READ);
end;

procedure dspreset;
begin
  WritePortB(SB_RESET, 1);
  Delay(5);
  WritePortB(SB_RESET, 0);
  Delay(5);
  dspread;   // 0xAA
end;



procedure SB16_DMA_Start(Channel: Byte; buf: Pointer; len: LongWord);
var
  phys: LongWord;
  offset, count: Word;
begin
  // 1) DMA Kanal�n� Mask'la
  WritePortB(DmaPort[Channel,1], 4 + (Channel and 3));

  // 2) Flip-Flop reset
  WritePortB(DmaPort[Channel,3], 0);

  // 3) DMA Mod
  //    16-bit, auto-init, write, incr
  WritePortB(DmaPort[Channel,2], (Channel and 3) or $58);

  // 4) Fiziksel adres
  phys := LongWord(buf);

  // 16-bit DMA i�in adres word cinsinden b�l�n�r
  offset := (phys shr 1) and $FFFF;

  // Adres yaz
  WritePortB(DmaChannel[Channel,2], Lo(offset));
  WritePortB(DmaChannel[Channel,2], Hi(offset));

  // Count (word say�s� - 1)
  count := (len div 2) - 1;

  WritePortB(DmaChannel[Channel,3], Lo(count));
  WritePortB(DmaChannel[Channel,3], Hi(count));

  // Page register
  WritePortB(DmaChannel[Channel,1], (phys shr 16) and $FF);

  // 5) DMA Kanal�n� a�
  WritePortB(DmaPort[Channel,1], Channel and 3);
end;


procedure SB16_Play16(DATA:pointer ;len: LongWord; rate: Word);
var
  sampleCount: Word;
begin
   dspreset;


  // DSP sample rate
  dspwrite($41);            // set sample rate
  dspwrite(Hi(rate));
  dspwrite(Lo(rate));

  // DMA ba�lat
  SB16_DMA_Start(5, DATA, len);

  // 16-bit signed mono
  dspwrite($B0);            // 16-bit playback
  dspwrite($10);            // signed mono

  sampleCount := (len div 2) - 1;

  dspwrite(Lo(sampleCount));
  dspwrite(Hi(sampleCount));

  dspwrite($D1);            // speaker ON
  dspwrite($D6);            // 16-bit ON
end;


procedure SB16_Play8(Buffer: Pointer; Len: LongWord; Rate: Word);
var
  Addr: LongWord;
  LenWords: Word;
  TimeConst: Byte;
begin
  if Len = 0 then Exit;

  // Max uzunluk kontrol� (DMA 16-bit auto-init i�in)
  if Len > 65535 then Len := 65535;
  LenWords := Len - 1;
  Addr := LongWord(Buffer);

  // DSP reset ve speaker a�
  dspreset;
  dspwrite($D1); // Speaker ON

  // DMA setup: Channel 1, 8-bit, auto-init
  // 1. Mask DMA channel 1
  WritePortB($0A, 5); 
  // 2. Clear flip-flop
  WritePortB($0C, 0);
  // 3. Mode: single, increment, write
  WritePortB($0B, $49);
  // 4. Address
  WritePortB($02, Lo(Addr));
  WritePortB($02, Hi(Addr));
  WritePortB($83, Addr shr 16); // page
  // 5. Length
  WritePortB($03, Lo(LenWords));
  WritePortB($03, Hi(LenWords));
  // 6. Unmask
  WritePortB($0A, 1);

  // DSP: Time constant hesapla (sample rate)
  if Rate = 0 then Rate := 22050;
  TimeConst := 256 - (1000000 div Rate);
  dspwrite($40);       // Set time constant
  dspwrite(TimeConst);

  // DSP: 8-bit playback
  dspwrite($14);       // Play 8-bit mono
  dspwrite(Lo(LenWords));
  dspwrite(Hi(LenWords));

  // Art�k DMA ve DSP 8-bit �al�yor, bekleme/interrupt gerekebilir
end;



procedure PlayWav(FileName: PChar);
var
  FileHandle: Integer;
  buf: Pointer;
  arr: PByteArray;
  Size, pos, dataSize: LongWord;
  dataPtr: PByte;
  sampleRate: LongWord;
  channels, bits: Word;
begin


  FileHandle := OpenFile(FileName, FILE_READ);
  if FileHandle < 0 then Exit;

  Size := FileSize(FileHandle);


  buf := MemAlloc(Size);
  if buf = nil then begin CloseFile(FileHandle); Exit; end;

  ReadFile(FileHandle, buf,Size);
  CloseFile(FileHandle);

  arr := PByteArray(buf);

  // Basit RIFF+WAVE kontrol
  if (arr^[0] <> Ord('R')) or (arr^[1] <> Ord('I')) or
     (arr^[2] <> Ord('F')) or (arr^[3] <> Ord('F')) or
     (arr^[8] <> Ord('W')) or (arr^[9] <> Ord('A')) or
     (arr^[10] <> Ord('V')) or (arr^[11] <> Ord('E')) then
  begin
    ShowMessage('Not a WAV file!');
    FreeMem(buf);
    Exit;
  end;

  // Header�dan de�erleri al
  channels := PWord(@arr^[22])^;       // NumChannels
  sampleRate := PLongWord(@arr^[24])^; // SampleRate
  bits := PWord(@arr^[34])^;           // BitsPerSample

  // data chunk bul
  pos := 12;
  dataPtr := nil;
  while pos + 8 <= Size do
  begin
    if (arr^[pos] = Ord('d')) and (arr^[pos+1] = Ord('a')) and
       (arr^[pos+2] = Ord('t')) and (arr^[pos+3] = Ord('a')) then
    begin
      dataSize := PLongWord(@arr^[pos + 4])^;
      dataPtr := @arr^[pos + 8];
      Break;
    end;
    pos := pos + 8 + PLongWord(@arr^[pos + 4])^;
  end;

  if dataPtr = nil then
  begin
    ShowMessage('No data chunk!');
    FreeMem(buf);
    Exit;
  end;

  // Bit�e g�re uygun SB16 �alma
  case bits of
    8: SB16_Play8(dataPtr, dataSize, sampleRate);
    16: SB16_Play16(dataPtr, dataSize, sampleRate);
  else
    ShowMessage('Unsupported bit depth: ');
  end;

  FreeMem(buf);
end;

end.






Unit ExeFile;

interface

Uses
   SysUtils,Fat32,Memory,Bitmaps,Vesa,Mouse;



const
  IMAGE_NUMBEROF_DIRECTORY_ENTRIES        = 16;
  IMAGE_DIRECTORY_ENTRY_EXPORT     = 0;
  IMAGE_DIRECTORY_ENTRY_BASERELOC = 5;
  IMAGE_REL_BASED_HIGHLOW = 3;
  IMAGE_DIRECTORY_ENTRY_RESOURCE  =2;

 type
    PInitExe=^TInitExe;
    TInitExe= procedure(Params1,Params2:PChar);stdcall;

    type
  TEntryProc = procedure; stdcall;

 var
    RT_BITMAP :PChar = PChar(2 and $FFFF);
    RT_ICON   :PChar = PChar(3 and $FFFF);
    RT_RCDATA :PChar = PChar(10 and $FFFF);


{
const
  RT_CURSOR       = MAKEINTRESOURCE(1);
  RT_BITMAP       = MAKEINTRESOURCE(2);
  RT_ICON         = MAKEINTRESOURCE(3);
  RT_MENU         = MAKEINTRESOURCE(4);
  RT_DIALOG       = MAKEINTRESOURCE(5);
  RT_STRING       = MAKEINTRESOURCE(6);
  RT_FONTDIR      = MAKEINTRESOURCE(7);
  RT_FONT         = MAKEINTRESOURCE(8);
  RT_ACCELERATOR  = MAKEINTRESOURCE(9);
  RT_RCDATA       = MAKEINTRESOURCE(10);
  RT_GROUP_CURSOR = MAKEINTRESOURCE(12);
  RT_VERSION      = MAKEINTRESOURCE(16);
  RT_MANIFEST     = MAKEINTRESOURCE(24);

}
  
 type
 PImageDosHeader = ^TImageDosHeader;
  TImageDosHeader = packed record      { DOS .EXE header                  }
     e_magic: Word;                     { Magic number                     }
      e_cblp: Word;                      { Bytes on last page of file       }
      e_cp: Word;                        { Pages in file                    }
      e_crlc: Word;                      { Relocations                      }
      e_cparhdr: Word;                   { Size of header in paragraphs     }
      e_minalloc: Word;                  { Minimum extra paragraphs needed  }
      e_maxalloc: Word;                  { Maximum extra paragraphs needed  }
      e_ss: Word;                        { Initial (relative) SS value      }
      e_sp: Word;                        { Initial SP value                 }
      e_csum: Word;                      { Checksum                         }
      e_ip: Word;                        { Initial IP value                 }
      e_cs: Word;                        { Initial (relative) CS value      }
      e_lfarlc: Word;                    { File address of relocation table }
      e_ovno: Word;                      { Overlay number                   }
      e_res: array [0..3] of Word;       { Reserved words                   }
      e_oemid: Word;                     { OEM identifier (for e_oeminfo)   }
      e_oeminfo: Word;                   { OEM information; e_oemid specific}
      e_res2: array [0..9] of Word;      { Reserved words                   }
      _lfanew: LongInt;                  { File address of new exe header   }
  end;



type
  PImageFileHeader = ^TImageFileHeader;
  TImageFileHeader = packed record
   Machine: Word;
    NumberOfSections: Word;
    TimeDateStamp: DWORD;
    PointerToSymbolTable: DWORD;
    NumberOfSymbols: DWORD;
    SizeOfOptionalHeader: Word;
    Characteristics: Word;
  end;

  PImageDataDirectory=^TImageDataDirectory;
  TImageDataDirectory = packed record
    VirtualAddress: LongInt;
    Size: LongInt;
  end;

  TImageOptionalHeader = packed record
    { Standard fields. }
    Magic: Word;
    MajorLinkerVersion: Byte;
    MinorLinkerVersion: Byte;
    SizeOfCode: DWORD;
    SizeOfInitializedData: DWORD;
    SizeOfUninitializedData: DWORD;
    AddressOfEntryPoint: DWORD;
    BaseOfCode: DWORD;
    BaseOfData: DWORD;
    { NT additional fields. }
    ImageBase: DWORD;
    SectionAlignment: DWORD;
    FileAlignment: DWORD;
    MajorOperatingSystemVersion: Word;
    MinorOperatingSystemVersion: Word;
    MajorImageVersion: Word;
    MinorImageVersion: Word;
    MajorSubsystemVersion: Word;
    MinorSubsystemVersion: Word;
    Win32VersionValue: DWORD;
    SizeOfImage: DWORD;
    SizeOfHeaders: DWORD;
    CheckSum: DWORD;
    Subsystem: Word;
    DllCharacteristics: Word;
    SizeOfStackReserve: DWORD;
    SizeOfStackCommit: DWORD;
    SizeOfHeapReserve: DWORD;
    SizeOfHeapCommit: DWORD;
    LoaderFlags: DWORD;
    NumberOfRvaAndSizes: DWORD;
    DataDirectory: packed array[0..IMAGE_NUMBEROF_DIRECTORY_ENTRIES-1] of TImageDataDirectory;
  end;

  TImageNtHeaders = packed record
     Signature: DWORD;
    FileHeader: TImageFileHeader;
    OptionalHeader: TImageOptionalHeader;
  end;
  PImageNtHeaders = ^TImageNtHeaders;


   TISHMisc = packed record
    case Integer of
      0: (PhysicalAddress: DWORD);
      1: (VirtualSize: DWORD);
  end;

   PImageExportDirectory         =^TImageExportDirectory;
  TImageExportDirectory         = PACKED RECORD
    Characteristics: DWord;
      TimeDateStamp: DWord;
      MajorVersion: Word;
      MinorVersion: Word;
      Name: DWord;
      Base: DWord;
      NumberOfFunctions: DWord;
      NumberOfNames: DWord;
      AddressOfFunctions: ^PDWORD;
      AddressOfNames: ^PDWORD;
      AddressOfNameOrdinals: ^PWord;
  END;


  PImageSectionHeader = ^TImageSectionHeader;
  TImageSectionHeader = packed record
    Name: packed array[0..8-1] of Byte;
    Misc: TISHMisc;
    VirtualAddress: DWORD;
    SizeOfRawData: DWORD;
    PointerToRawData: DWORD;
    PointerToRelocations: DWORD;
    PointerToLinenumbers: DWORD;
    NumberOfRelocations: Word;
    NumberOfLinenumbers: Word;
    Characteristics: DWORD;
  end;

  type
  TImageBaseRelocation = packed record
    VirtualAddress: DWORD;
    SizeOfBlock: DWORD;
  end;
  PImageBaseRelocation = ^TImageBaseRelocation;



 { Resources }

  PImageResourceDirectory = ^TImageResourceDirectory;
  TImageResourceDirectory = packed record
    Characteristics : DWORD;
    TimeDateStamp   : DWORD;
    MajorVersion    : WORD;
    MinorVersion    : WORD;
    NumberOfNamedEntries : WORD;
    NumberOfIdEntries : WORD;
  end;

  PImageResourceDirectoryEntry = ^TImageResourceDirectoryEntry;
  TImageResourceDirectoryEntry = packed record
    Name: DWORD;        // Or ID: Word (Union)
    OffsetToData: DWORD;
  end;

  PImageResourceDataEntry = ^TImageResourceDataEntry;
  TImageResourceDataEntry = packed record
    OffsetToData    : DWORD;
    Size            : DWORD;
    CodePage        : DWORD;
    Reserved        : DWORD;
  end;

 type
  PIMAGE_RESOURCE_DIR_STRING_U = ^IMAGE_RESOURCE_DIR_STRING_U;
  IMAGE_RESOURCE_DIR_STRING_U = packed record
    Length: Word;              // Karakter say�s� (byte de�il!)
    NameString: array[0..0] of WideChar;  // Dinamik boyutlu Unicode karakter dizisi
  end;

  type
  PImageBase = ^TImageBase;
  TImageBase = record
    FileName: array[0..39] of Char;
    Base: Pointer;
    Size: DWORD;
    Next: PImageBase;
    Prev: PImageBase;
  end;
var
  ImageBaseHead: PImageBase = nil;
   NewImageBasePtr: Pointer=nil;
  NewImageBaseSize:Integer;



    procedure OpenExeFile(const FileName: PChar; Params:PChar);
    procedure GetResource(FileName: PChar; ResType, ResName: PChar; var Data: PByteArray; var Size:Integer);
    procedure AddImageBase(FileName: Pchar; Base: Pointer; Size: DWORD);
    function FindImageBase(Base: Pointer): PImageBase; overload;
    function FindImage(FileName: PChar): PImageBase; overload;
    function CountImages: Integer;
    procedure UnloadImage(Address: Pointer);

implementation

function MAKEINTRESOURCE(ID: Word): PChar;
begin
  Result := PChar(ID and $FFFF);
end;


procedure AddImageBase(FileName: Pchar; Base: Pointer; Size: DWORD);
var
  NodeBase: PImageBase;
begin
  NodeBase := PImageBase(MemAlloc(SizeOf(TImageBase)));
  Move(FileName[0], NodeBase^.FileName[0], StrLen(FileName));
  NodeBase^.Base := Base;
  NodeBase^.Size := Size;
  NodeBase^.Next := ImageBaseHead;
  NodeBase^.Prev := nil;
  if ImageBaseHead <> nil then
    ImageBaseHead^.Prev := NodeBase;
  ImageBaseHead := NodeBase;
end;

function FindImageBase(Base: Pointer): PImageBase; overload;
begin
  Result := ImageBaseHead;
  while (Result <> nil) and (Result^.Base <> Base) do
    Result := Result^.Next;
end;

function FindImage(FileName: PChar): PImageBase; overload;
begin
  Result := ImageBaseHead;
  while (Result <> nil) and (StrComp(Result^.FileName, FileName) = 0) do
    Result := Result^.Next;
end;

function CountImages: Integer;
var
  Count: Integer;
  NodeBase: PImageBase;
begin
  Count := 0;
  NodeBase := ImageBaseHead;
  while NodeBase <> nil do
  begin
    Inc(Count);
    NodeBase := NodeBase^.Next;
  end;
  Result := Count;
end;

procedure UnloadImage(Address: Pointer);
var
  NodeBase: PImageBase;
begin
  NodeBase := ImageBaseHead;
  while NodeBase <> nil do
  begin
    if NodeBase^.Base = Address then
    begin
      // Liste ba lant lar n  d zelt
      if NodeBase^.Prev <> nil then
        NodeBase^.Prev^.Next := NodeBase^.Next
      else
        ImageBaseHead := NodeBase^.Next;

      if NodeBase^.Next <> nil then
        NodeBase^.Next^.Prev := NodeBase^.Prev;

      // Belle i serbest b rak
      FreeMem(NodeBase^.Base, NodeBase^.Size);
      FreeMem(NodeBase, SizeOf(TImageBase));
      NodeBase := nil;

      Exit; // bulundu ve silindi,   kabiliriz
    end;
    NodeBase := NodeBase^.Next;
  end;
end;

procedure UnloadAllImages;
var
  NodeBase, NextNodeBase: PImageBase;
begin
  NodeBase := ImageBaseHead;
  while NodeBase <> nil do
  begin
    NextNodeBase := NodeBase^.Next;
    FreeMem(NodeBase^.Base, NodeBase^.Size);
    FreeMem(NodeBase, SizeOf(TImageBase));
    NodeBase := nil;
    NodeBase := NextNodeBase;
  end;
  ImageBaseHead := nil;
end;




function IsIntResource(Str: PChar): Boolean;
begin
  Result := DWORD(Str) shr 16 = 0;
end;






procedure SafeJump(Address: DWORD;Line:PChar);
asm

  mov eax, [Line]
  call Address
end;


procedure ParseCommandLine(Src: PChar; out FileName, CmdLine: PChar);
var
  I, Len: Integer;
begin
  FileName := nil;
  CmdLine := nil;

  Len := StrLen(Src);
  for I := 0 to Len - 1 do
  begin
    if Src[I] = '%' then
    begin
      Src[I] := #0;  // ay�r
      FileName := Src;
      CmdLine := @Src[I + 1];
      Exit;
    end;
  end;

  // E�er '&' bulunamad�ysa sadece dosya ad� var
  FileName := Src;
  CmdLine := nil;
end;






procedure RunExe(Entry: Pointer; HInst:Cardinal; CmdLine: PChar);
asm
    push CmdLine    // �kinci parametre �nce push
    push HInst      // Birinci parametre sonra push
    call Entry
    // stdcall ise add esp, 8; ekleyin (temizleme i�in), cdecl ise callee temizler
end;


procedure OpenExeFile(const FileName: PChar; Params:PChar);
var
  ExeFile: TFile;
  BytesRead: DWORD;
  DosHeader: PImageDosHeader;
  NTHeaders: PImageNtHeaders;
  Sections: PImageSectionHeader;
  Reloc: PImageBaseRelocation;
  EntryW: PWord;
  FileBuf: PByteArray;
  ImageBuf: PByteArray;
  i, SecNo, NumEntries: Integer;
  secoff, secsize, rawoff, lastoff: DWORD;
  RelocRVA, RelocSize, RelocOffset: DWORD;
  OriginalImageBase, Offset, RelocType: DWORD;

  EntryPoint: Pointer;
  FileSize: Integer;
  InitExe:TInitExe;
  // helper
  function RVAToOffset(RVA: DWORD): DWORD;
  var
    j: Integer;
    Sec: PImageSectionHeader;
  begin
    Sec := Sections;
    for j := 0 to NTHeaders^.FileHeader.NumberOfSections - 1 do
    begin
      if (RVA >= Sec^.VirtualAddress) and
         (RVA < Sec^.VirtualAddress + Sec^.Misc.VirtualSize) then
      begin
        Result := RVA - Sec^.VirtualAddress + Sec^.PointerToRawData;
        Exit;
      end;
      Inc(Sec);
    end;
    Result := 0;
  end;
begin
  if not OpenFile(ExeFile, FileName) then Exit;
  FileSize := ExeFile.FileSize;

  // 1) Diskten oku -> FileBuf (MemAlloc ile)
  FileBuf := MemAlloc(FileSize);
  if FileBuf = nil then
  begin
    FileClose(ExeFile);
    Exit;
  end;

  BytesRead := ReadFile(ExeFile, FileBuf, FileSize);
  if BytesRead = 0 then
  begin
    FreeMem(FileBuf, FileSize);
    FileClose(ExeFile);
    Exit;
  end;

  DosHeader := PImageDosHeader(FileBuf);
  if DosHeader^.e_magic <> $5A4D then
  begin
    FreeMem(FileBuf, FileSize);
    FileClose(ExeFile);
    Exit;
  end;

  NTHeaders := PImageNtHeaders(NativeUInt(FileBuf) + DosHeader^._lfanew);
  if NTHeaders^.Signature <> $00004550 then
  begin
    FreeMem(FileBuf, FileSize);
    FileClose(ExeFile);
    Exit;
  end;

  // 2) Image i�in bellek ay�r (ayn� MemAlloc kullan)
  NewImageBasePtr := MemAlloc(NTHeaders^.OptionalHeader.SizeOfImage);
  if NewImageBasePtr = nil then
  begin
    FreeMem(FileBuf, FileSize);
    FileClose(ExeFile);
    Exit;
  end;
  ImageBuf := PByteArray(NewImageBasePtr);

  // 3) B�l�mleri kopyala (pointer aritmeti�inde NativeUInt kullan)
  Sections := PImageSectionHeader(NativeUInt(FileBuf) + DosHeader^._lfanew +
    SizeOf(TImageNtHeaders) - SizeOf(TImageOptionalHeader) +
    NTHeaders^.FileHeader.SizeOfOptionalHeader);

  OriginalImageBase := NTHeaders^.OptionalHeader.ImageBase;
  lastoff := 0;

  for SecNo := 0 to NTHeaders^.FileHeader.NumberOfSections - 1 do
  begin
    secoff := Sections^.VirtualAddress;
    secsize := Sections^.SizeOfRawData;
    rawoff := Sections^.PointerToRawData;
    if secsize > 0 then
    begin
      if secoff > lastoff then
        FillChar(ImageBuf[lastoff], secoff - lastoff, 0);
      // raw data -> imagebuf
      Move(FileBuf[rawoff], ImageBuf[secoff], secsize);
      lastoff := secoff + secsize;
    end;
    Inc(Sections);
  end;

  // 4) Relocations d�zelt
  Sections := PImageSectionHeader(NativeUInt(FileBuf) + DosHeader^._lfanew +
    SizeOf(TImageNtHeaders) - SizeOf(TImageOptionalHeader) +
    NTHeaders^.FileHeader.SizeOfOptionalHeader);
  RelocRVA := NTHeaders^.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress;
  RelocSize := NTHeaders^.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size;
  RelocOffset := RVAToOffset(RelocRVA);

  if (RelocRVA <> 0) and (RelocSize <> 0) then
  begin
    Reloc := PImageBaseRelocation(NativeUInt(FileBuf) + RelocOffset);
    while (NativeUInt(Reloc) < NativeUInt(FileBuf) + RelocOffset + RelocSize)
      and (Reloc^.SizeOfBlock > 0) do
    begin
      NumEntries := (Reloc^.SizeOfBlock - SizeOf(TImageBaseRelocation)) div 2;
      EntryW := PWord(NativeUInt(Reloc) + SizeOf(TImageBaseRelocation));
      for i := 0 to NumEntries - 1 do
      begin
        Offset := EntryW^ and $0FFF;
        RelocType := EntryW^ shr 12;
        if RelocType = IMAGE_REL_BASED_HIGHLOW then
        begin
          // ImageBuf + reloc.VirtualAddress + Offset bir DWORD
          PCardinal(@ImageBuf[Reloc^.VirtualAddress + Offset])^ :=
            PCardinal(@ImageBuf[Reloc^.VirtualAddress + Offset])^
            + (NativeUInt(NewImageBasePtr) - NativeUInt(OriginalImageBase));
        end;
        Inc(EntryW);
      end;
      Reloc := PImageBaseRelocation(NativeUInt(Reloc) + Reloc^.SizeOfBlock);
    end;
  end;

  // 5) Import table resolve **(�NEML�)**: e�er exe IAT kullan�yorsa burada LoadLibrary/GetProcAddress i�ini yapmal�s�n.
  //    Bu �rnekte atl�yoruz -> baz� exe'ler statik olabilir.

  // 6) Disk buffer'� serbest b�rak (ImageBuf art�k kopyalanm�� durumda)
  FreeMem(FileBuf, FileSize);
 

  // 7) EntryPoint hesapla ve �al��t�r
  EntryPoint := Pointer(NativeUInt(NewImageBasePtr) + NTHeaders^.OptionalHeader.AddressOfEntryPoint);

   NewImageBaseSize:=NTHeaders^.OptionalHeader.SizeOfImage;

  // *** �NEML� *** : E�er EntryPoint do�rudan geri d�necekse, FreeMem(ImageBuf,..) �a�r�labilir.
  // Ancak EXE kendi thread/process yarat�yor veya uzun s�reli kaynak a��yorsa, belle�i hemen serbest
  // b�rakmak istenmeyen davran��a yol a�ar.
  //
  // Bu nedenle:
  // - E�er �a�r�lan EXE k�sa s�reli ve geri d�n�yorsa -> �a�r� sonras� FreeMem(ImageBuf, SizeOfImage).
  // - E�er EXE arka plan threadleri ba�lat�yorsa -> bellek serbest b�rak�lmamal�d�r (veya EXE sonlanana kadar beklenmelidir).
  //

   AddImageBase(ExeFile.Name, Pointer(NewImageBasePtr),NTHeaders^.OptionalHeader.SizeOfImage);


   RunExe(EntryPoint, Cardinal(NewImageBasePtr),Params);
   FileClose(ExeFile);

  // EntryPoint geri d�nd�yse g�venle temizle
 // FreeMem(NewImageBasePtr, NTHeaders^.OptionalHeader.SizeOfImage); // +28672


end;



function LoadDLLToMemory(FileName: PChar): DWORD;
var
  ExeFile: TFile;
  BytesRead: DWORD;
  DosHeader: PImageDosHeader;
  NTHeaders: PImageNtHeaders;
  Sections: PImageSectionHeader;
  ExportDir: PImageExportDirectory;
  ImageBase, ExportDirRVA, FuncRVA, EntryPoint: DWORD;
  SecNo, secoff, secsize, rawoff, lastoff: DWORD;
  Buffer: PByteArray;
  i: Integer;

begin
 if not OpenFile(ExeFile, FileName) then Exit;

  Buffer := PByteArray(MemAlloc(ExeFile.FileSize));
  BytesRead := ReadFile(ExeFile, Buffer, ExeFile.FileSize);
  if BytesRead = 0 then Exit;

  DosHeader := PImageDosHeader(@Buffer[0]);
  if DosHeader^.e_magic <> $5A4D then Exit;

  NTHeaders := PImageNtHeaders(@Buffer[DosHeader^._lfanew]);
  if NTHeaders^.Signature <> $00004550 then Exit;

  ImageBase := NTHeaders^.OptionalHeader.ImageBase;

  // Messages.Showmessage(IntToStr(ImageBase));



  // ImageBase'a y�kle
  lastoff := 0;
  for SecNo := 0 to NTHeaders^.FileHeader.NumberOfSections - 1 do
  begin
    Sections := PImageSectionHeader(
      @Buffer[DosHeader^._lfanew +
              SizeOf(TImageNtHeaders) - SizeOf(TImageOptionalHeader) +
              NTHeaders^.FileHeader.SizeOfOptionalHeader +
              SecNo * SizeOf(TImageSectionHeader)]
    );

    secoff := Sections^.VirtualAddress;
    secsize := Sections^.SizeOfRawData;
    rawoff := Sections^.PointerToRawData;

    if secsize = 0 then Continue;
    if (rawoff + secsize > ExeFile.FileSize) then Continue;
    if (secoff + secsize > NTHeaders^.OptionalHeader.SizeOfImage) then Continue;

    if secoff > lastoff then
      FillChar(Pointer(ImageBase + lastoff)^, secoff - lastoff, #0);

    Move(Buffer[rawoff], Pointer(ImageBase + secoff)^, secsize);
    lastoff := secoff + secsize;
  end;

  Move(Buffer^, Pointer(ImageBase)^, NTHeaders^.OptionalHeader.SizeOfHeaders);

  FreeMem(Buffer, ExeFile.FileSize);


 Result := (ImageBase);
end;

function GetProcAddressEx(ImageBase: DWORD; FunctionName: PChar): Pointer;
var
  ExportDir: PImageExportDirectory;
  NameTable: PDWORD;
  OrdTable: PWORD;
  AddrTable: PDWORD;
  i: Integer;
  FuncNamePtr: PChar;
  FuncOrdinal: Word;
  NTHeaders: PImageNtHeaders;
  ExportDirRVA: DWORD;
begin
  Result := nil;

  NTHeaders := PImageNtHeaders(ImageBase + PImageDosHeader(ImageBase)^._lfanew);

  ExportDirRVA := NTHeaders^.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
   

if ExportDirRVA = 0 then Exit;



   ExportDir := PImageExportDirectory(Pointer(ImageBase + ExportDirRVA));
  NameTable := pointer(cardinal(ExportDir^.AddressOfNames) + cardinal(ImageBase));
  OrdTable  :=  pointer(cardinal(ExportDir^.AddressOfNameOrdinals) + cardinal(ImageBase));
  AddrTable :=  pointer(cardinal(ExportDir^.AddressOfFunctions) + cardinal(ImageBase));

  for i := 0 to ExportDir^.NumberOfNames - 1 do
  begin
    FuncNamePtr := PChar(PDWORD(NameTable)^ + Cardinal(ImageBase));
    if StrComp(FuncNamePtr, FunctionName) = 0 then
    begin
      FuncOrdinal := PWORD(OrdTable)^;
      Result := Pointer(Cardinal(ImageBase) + PDWORD(Cardinal(AddrTable) + FuncOrdinal * 4)^);
      Exit;
    end;
    Inc(NameTable);
    Inc(OrdTable);
  end;

  Result := nil;
end;







function ReadDWORD(Buffer: PByteArray; Offset: DWORD): DWORD;
begin
  Result := Buffer[Offset] or
            (Buffer[Offset + 1] shl 8) or
            (Buffer[Offset + 2] shl 16) or
            (Buffer[Offset + 3] shl 24);
end;

function ReadWORD(Buffer: PByteArray; Offset: DWORD): WORD;
begin
  Result := Buffer[Offset] or
            (Buffer[Offset + 1] shl 8);
end;




function GetProcAddress(FileName: PChar; FunctionName: PChar):Pointer;
var
  ExeFile: TFile;
  BytesRead: DWORD;
  DosHeader: PImageDosHeader;
  NTHeaders: PImageNtHeaders;
  Sections: PImageSectionHeader;
  ExportDir: PImageExportDirectory;
  ImageBase, ExportDirRVA, FuncRVA, EntryPoint: DWORD;
  SecNo, secoff, secsize, rawoff, lastoff: DWORD;
  Buffer: PByteArray;
  i: Integer;
  NameTable: PDWORD;    // DWORD = Cardinal
  OrdTable: PWORD;
  AddrTable: PDWORD;
  FuncNamePtr: PChar;

  ExportName: pchar;
  ExportFunction: DWORD;
  ExportedAddress: DWORD;
  FuncOrdinal:DWord;

begin
  if not OpenFile(ExeFile, FileName) then Exit;

  Buffer := PByteArray(MemAlloc(ExeFile.FileSize));
  BytesRead := ReadFile(ExeFile, Buffer, ExeFile.FileSize);
  if BytesRead = 0 then Exit;

  DosHeader := PImageDosHeader(@Buffer[0]);
  if DosHeader^.e_magic <> $5A4D then Exit;

  NTHeaders := PImageNtHeaders(@Buffer[DosHeader^._lfanew]);
  if NTHeaders^.Signature <> $00004550 then Exit;

  ImageBase := NTHeaders^.OptionalHeader.ImageBase;

  // ImageBase'a y�kle
  lastoff := 0;
  for SecNo := 0 to NTHeaders^.FileHeader.NumberOfSections - 1 do
  begin
    Sections := PImageSectionHeader(
      @Buffer[DosHeader^._lfanew +
              SizeOf(TImageNtHeaders) - SizeOf(TImageOptionalHeader) +
              NTHeaders^.FileHeader.SizeOfOptionalHeader +
              SecNo * SizeOf(TImageSectionHeader)]
    );

    secoff := Sections^.VirtualAddress;
    secsize := Sections^.SizeOfRawData;
    rawoff := Sections^.PointerToRawData;

    if secsize = 0 then Continue;
    if (rawoff + secsize > ExeFile.FileSize) then Continue;
    if (secoff + secsize > NTHeaders^.OptionalHeader.SizeOfImage) then Continue;

    if secoff > lastoff then
      FillChar(Pointer(ImageBase + lastoff)^, secoff - lastoff, #0);

    Move(Buffer[rawoff], Pointer(ImageBase + secoff)^, secsize);
    lastoff := secoff + secsize;
  end;

  FreeMem(Buffer, ExeFile.FileSize);

  // Export Tablosunu bul
  ExportDirRVA := NTHeaders^.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
  if ExportDirRVA = 0 then Exit;

  ExportDir := PImageExportDirectory(Pointer(ImageBase + ExportDirRVA));
  NameTable := pointer(cardinal(ExportDir^.AddressOfNames) + cardinal(ImageBase));
  OrdTable  :=  pointer(cardinal(ExportDir^.AddressOfNameOrdinals) + cardinal(ImageBase));
  AddrTable :=  pointer(cardinal(ExportDir^.AddressOfFunctions) + cardinal(ImageBase));
  // Fonksiyonu ara
  ExportFunction := 0;
  for i := 0 to ExportDir^.NumberOfNames - 1 do
  begin
      FuncNamePtr := PChar(PDWORD(NameTable)^ + Cardinal(ImageBase));
      FuncOrdinal := PWORD(OrdTable)^; // ORDINAL INDEX al�n�r!
      ExportFunction := PDWORD(Cardinal(AddrTable) + FuncOrdinal * 4)^ + Cardinal(ImageBase);
      if StrComp(FuncNamePtr, FunctionName) = 0 then
      begin
        ExportedAddress := ExportFunction;
       // Messages.ShowMessage(IntToStr(DWORD(ExportFunction)));
        Break;
      end;

     Inc(PDWORD(NameTable));
     Inc(PWORD(OrdTable));
  end;

  if ExportedAddress = 0 then
  begin
   // ShowMessage('Fonksiyon bulunamad�!');
    Exit;
  end;

 // Messages.ShowMessage(IntToStr(DWORD(ExportFunction)));

 Result := Pointer(ExportedAddress);
end;


{
var
  Data: PByteArray;
  Size: Integer;
begin
  if GetResource(ImageBase, RT_RCDATA, MAKEINTRESOURCE(101), Data, Size) then
    TImage.LoadFromMemory(Data, Size);
}



function RVAToOffset(RVA: DWORD; Sections: PImageSectionHeader; NtHdr: PImageNtHeaders): DWORD;
var
  j: Integer;
  Sec: PImageSectionHeader;
begin
  Result := 0;
  for j := 0 to NtHdr^.FileHeader.NumberOfSections - 1 do
  begin
    Sec := PImageSectionHeader(Cardinal(Sections) + j * SizeOf(TImageSectionHeader));

    if (RVA >= Sec^.VirtualAddress) and
       (RVA < Sec^.VirtualAddress + Sec^.Misc.VirtualSize) then
    begin
      Result := RVA - Sec^.VirtualAddress + Sec^.PointerToRawData;
      Exit;
    end;
  end;
end;

 function FindEntry(Dir: PImageResourceDirectory; Name: PChar): PImageResourceDirectoryEntry;
  var
    Entry: PImageResourceDirectoryEntry;
    Count, j: Integer;
    ID: Word;
  begin
    Result := nil;
    Count := Dir^.NumberOfNamedEntries + Dir^.NumberOfIdEntries;
    
     Entry := PImageResourceDirectoryEntry(DWord(Dir) + SizeOf(TImageResourceDirectory));
  //

    for j := 0 to Count - 1 do
    begin


      if IsIntResource(Name) then
      begin
        ID := Word(Name);
        if (Entry^.Name and $FFFF) = ID then
        begin


          Result := Entry;
          Exit;
        end;
      end;
      Inc(Entry);
    end;
  end;


procedure GetResource1(FileName: PChar; ResType, ResName: PChar;var Data: PByteArray; var Size:LongWord);
var
  ExeFile: TFile;
  BytesRead: DWORD;

  DosHdr: PImageDosHeader;
  NtHdr: PImageNtHeaders;
  Sections: PImageSectionHeader;
  ResBase: PByteArray;
  TypeDir, NameDir,LangDir: PImageResourceDirectory;
  TypeEntry: PImageResourceDirectoryEntry;
  Entry: PImageResourceDirectoryEntry;
  NameEntry, LangEntry: PImageResourceDirectoryEntry;
  DataEntry: PImageResourceDataEntry;
  Count, i,j: Integer;
  ResDirOffset: DWORD;
  Buffer: PByteArray;
  ResDirRVA: DWORD;

  Offset:Dword;
  Length: Word;
  WidePtr: PWideChar;
  EntryName: array[0..255] of Char;
begin
  if not OpenFile(ExeFile, FileName) then Exit;

  Buffer := PByteArray(MemAlloc(ExeFile.FileSize));
  BytesRead := ReadFile(ExeFile, Buffer, ExeFile.FileSize);
  if BytesRead = 0 then Exit;

  // �imdi t�m RCDATA isimlerini listele
  DosHdr := PImageDosHeader(@Buffer[0]);
  NtHdr := PImageNtHeaders(@Buffer[DosHdr^._lfanew]);

  Sections := PImageSectionHeader(@Buffer[DosHdr^._lfanew +
    SizeOf(TImageNtHeaders) - SizeOf(TImageOptionalHeader) +
    NtHdr^.FileHeader.SizeOfOptionalHeader]);

  ResDirRVA := NtHdr^.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_RESOURCE].VirtualAddress;
  ResDirOffset := RVAtoOffset(ResDirRVA, Sections, NtHdr);

  ResBase := @Buffer[ResDirOffset];
  TypeDir := PImageResourceDirectory(ResBase);

  // 1. Seviye: RCDATA giri�ini bul
  TypeEntry := FindEntry(TypeDir, ResType);
  if TypeEntry = nil then
  begin
   // ShowMessage('RCDATA giri�ine ula��lamad�!');
    Exit;
  end;

  NameDir := PImageResourceDirectory(@ResBase[TypeEntry^.OffsetToData and $7FFFFFFF]);

  Count := NameDir^.NumberOfNamedEntries + NameDir^.NumberOfIdEntries;
  Entry := PImageResourceDirectoryEntry(DWORD(NameDir) + SizeOf(TImageResourceDirectory));


  // 2. seviye
  for i := 0 to Count - 1 do
  begin
    if (Entry^.Name and $80000000) <> 0 then
    begin
     Offset := Entry^.Name and $7FFFFFFF;
     Length := PWord(@ResBase[Offset])^;  // �lk 2 byte uzunluk (karakter say�s�)
     WidePtr := PWideChar(@ResBase[Offset + 2]);  // Length'ten sonra gelen Unicode karakterler

    // Unicode'u ANSI'ye �evir (�ok basit�e ASCII gibi i�liyoruz)
    for J := 0 to Length - 1 do
      EntryName[J] := AnsiChar(WidePtr[J]);

    EntryName[Length] := #0;

      if StrComp(EntryName,ResName) = 0 then
      begin
        break;
      end;
    end
    else
    begin
      // Integer ID
     // ShowMessage( IntToStr(Entry^.Name and $FFFF));
    end;

    Inc(Entry);
  end;

  LangDir := PImageResourceDirectory(@ResBase[Entry^.OffsetToData and $7FFFFFFF]);
  // 3. seviye
  LangEntry := PImageResourceDirectoryEntry(DWORD(LangDir) + SizeOf(TImageResourceDirectory));
  if LangEntry = nil then Exit;

  DataEntry := PImageResourceDataEntry(@ResBase[LangEntry^.OffsetToData and $7FFFFFFF]);
  Size := DataEntry^.Size;


  Data:=nil;

  if Size >0 then
  begin
  Data := PByteArray(MemAlloc(Size));

   Move(Buffer[RVAtoOffset(DataEntry^.OffsetToData,Sections,NtHdr)], Data[0], Size);
 end;
   FreeMem(Buffer, ExeFile.FileSize);

   FileClose(ExeFile);
end;




procedure GetResource(FileName: PChar; ResType, ResName: PChar; var Data: PByteArray; var Size:Integer);
var
  ExeFile: TFile;
  BytesRead: DWORD;

  DosHdr: PImageDosHeader;
  NtHdr: PImageNtHeaders;
  Sections: PImageSectionHeader;
  ResBase: PByteArray;
  TypeDir, NameDir,LangDir: PImageResourceDirectory;
  TypeEntry: PImageResourceDirectoryEntry;
  Entry: PImageResourceDirectoryEntry;
  NameEntry, LangEntry: PImageResourceDirectoryEntry;
  DataEntry: PImageResourceDataEntry;
  Count, i,j: Integer;
  ResDirOffset: DWORD;
  Buffer: PByteArray;
  ResDirRVA: DWORD;

  Offset:Dword;
  Length: Word;
  WidePtr: PWideChar;
  EntryName: array[0..255] of Char;
begin
  if not OpenFile(ExeFile, FileName) then Exit;

  Buffer := PByteArray(MemAlloc(ExeFile.FileSize));
  BytesRead := ReadFile(ExeFile, Buffer, ExeFile.FileSize);
  if BytesRead = 0 then Exit;

  // �imdi t�m RCDATA isimlerini listele
  DosHdr := PImageDosHeader(@Buffer[0]);
  NtHdr := PImageNtHeaders(@Buffer[DosHdr^._lfanew]);

  Sections := PImageSectionHeader(@Buffer[DosHdr^._lfanew +
    SizeOf(TImageNtHeaders) - SizeOf(TImageOptionalHeader) +
    NtHdr^.FileHeader.SizeOfOptionalHeader]);

  ResDirRVA := NtHdr^.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_RESOURCE].VirtualAddress;
  ResDirOffset := RVAtoOffset(ResDirRVA, Sections, NtHdr);

  ResBase := @Buffer[ResDirOffset];
  TypeDir := PImageResourceDirectory(ResBase);

  // 1. Seviye: RCDATA giri�ini bul
  TypeEntry := FindEntry(TypeDir, ResType);
  if TypeEntry = nil then
  begin
   // ShowMessage('RCDATA giri�ine ula��lamad�!');
    Exit;
  end;

  NameDir := PImageResourceDirectory(@ResBase[TypeEntry^.OffsetToData and $7FFFFFFF]);

  Count := NameDir^.NumberOfNamedEntries + NameDir^.NumberOfIdEntries;
  Entry := PImageResourceDirectoryEntry(DWORD(NameDir) + SizeOf(TImageResourceDirectory));


  // 2. seviye
  for i := 0 to Count - 1 do
  begin
    if (Entry^.Name and $80000000) <> 0 then
    begin
     Offset := Entry^.Name and $7FFFFFFF;
     Length := PWord(@ResBase[Offset])^;  // �lk 2 byte uzunluk (karakter say�s�)
     WidePtr := PWideChar(@ResBase[Offset + 2]);  // Length'ten sonra gelen Unicode karakterler

    // Unicode'u ANSI'ye �evir (�ok basit�e ASCII gibi i�liyoruz)
    for J := 0 to Length - 1 do
      EntryName[J] := AnsiChar(WidePtr[J]);

    EntryName[Length] := #0;

      if StrComp(EntryName,ResName) = 0 then
      begin
        break;
      end;
    end
    else
    begin
      // Integer ID
     // ShowMessage( IntToStr(Entry^.Name and $FFFF));
    end;

    Inc(Entry);
  end;

  LangDir := PImageResourceDirectory(@ResBase[Entry^.OffsetToData and $7FFFFFFF]);
  // 3. seviye
  LangEntry := PImageResourceDirectoryEntry(DWORD(LangDir) + SizeOf(TImageResourceDirectory));
  if LangEntry = nil then Exit;

  DataEntry := PImageResourceDataEntry(@ResBase[LangEntry^.OffsetToData and $7FFFFFFF]);
  Size := DataEntry^.Size;


   Data:= PByteArray(MemAlloc(Size));
   move(Buffer[RVAtoOffset(DataEntry^.OffsetToData,Sections,NtHdr)],Data[0],Size);

   FreeMem(Buffer, ExeFile.FileSize);

   FileClose(ExeFile);
end;


end.

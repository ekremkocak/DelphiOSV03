{ =========================================================
  Task.pas — x86 Multitasking + Thread Sistemi
  
  Donanım uyumluluğu:
  - QEMU, VirtualBox, VMware, Bochs, Gerçek PC
  
  Özellikler:
  - TSS tabanlı hardware task switch
  - Software context switch (timer IRQ ile)
  - Ring 0 kernel thread
  - Thread oluştur / sil / beklet / uyandır
  - Priority scheduler (round-robin + priority)
  - Thread sleep / yield
  - Mutex / spinlock
  - Zombie cleanup
  
  Dikkatler:
  - Her task için ayrı TSS ve stack
  - GDT'de TSS descriptor'ları önceden hazır
  - Timer IRQ0 (INT 32) → context switch
  - TR (Task Register) yüklü olmalı
  ========================================================= }

unit Task;

interface

uses
  SysUtils,GDT, IDT, Memory, Ports,Vesa,GUI;

//=============================================================================
// Sabitler
//=============================================================================

const
  MAX_TASKS        = 64;
  TASK_STACK_SIZE  = 8192;     // 8KB per task
  TASK_GDT_START   = 8;        // GDT'de TSS'ler kaçıncı index'ten başlar
  KERNEL_CS        = $08;      // Kernel code segment
  KERNEL_DS        = $10;      // Kernel data segment
  USER_CS          = $1B;      // User code segment  (ring3)
  USER_DS          = $23;      // User data segment  (ring3)

  // Task durumları
  TS_FREE          = 0;
  TS_READY         = 1;
  TS_RUNNING       = 2;
  TS_SLEEPING      = 3;
  TS_BLOCKED       = 4;
  TS_ZOMBIE        = 5;

  // Priority seviyeleri
  PRIO_IDLE        = 0;
  PRIO_LOW         = 1;
  PRIO_NORMAL      = 2;
  PRIO_HIGH        = 3;
  PRIO_REALTIME    = 4;

  // Thread flag'leri
  TF_KERNEL        = $01;      // Kernel thread
  TF_USER          = $02;      // User thread
  TF_DETACHED      = $04;      // Join beklenmiyor

  // Özel handle değerleri
  INVALID_HANDLE   = -1;
  CURRENT_THREAD   = 0;

//=============================================================================
// Tip tanımları
//=============================================================================

type
  TThreadEntry    = procedure(Param: Pointer);
  TThreadEntryStd = procedure(Param: Pointer); stdcall;

  // TSS32 — x86 Task State Segment
  PTSS32 = ^TTSS32;
  TTSS32 = packed record
    Backlink : Word; Backlink_H: Word;
    ESP0     : LongWord;
    SS0      : Word;  SS0_H: Word;
    ESP1     : LongWord;
    SS1      : Word;  SS1_H: Word;
    ESP2     : LongWord;
    SS2      : Word;  SS2_H: Word;
    CR3      : LongWord;
    EIP      : LongWord;
    EFlags   : LongWord;
    EAX      : LongWord;
    ECX      : LongWord;
    EDX      : LongWord;
    EBX      : LongWord;
    ESP      : LongWord;
    EBP      : LongWord;
    ESI      : LongWord;
    EDI      : LongWord;
    ES       : Word;  ES_H: Word;
    CS       : Word;  CS_H: Word;
    SS       : Word;  SS_H: Word;
    DS       : Word;  DS_H: Word;
    FS       : Word;  FS_H: Word;
    GS       : Word;  GS_H: Word;
    LDT      : Word;  LDT_H: Word;
    Trap     : Word;
    IOMap    : Word;
  end;

  // Task descriptor
  PTask = ^TTask;
  TTask = record
    TID      : Integer;         // Thread ID
    State    : Byte;            // TS_*
    Priority : Byte;            // PRIO_*
    Flags    : Byte;            // TF_*
    Selector : Word;            // GDT selector (TSS)

    TSS      : TTSS32;          // Task State Segment

    StackBase: LongWord;        // Stack başlangıç adresi
    StackSize: LongWord;        // Stack boyutu (byte)

    SleepTick: LongWord;        // Kaç tick sonra uyanacak
    WaitMutex: Pointer;         // Beklediği mutex

    Name     : array[0..31] of Char;

    ExitCode : Integer;
    JoinTask : PTask;           // Bu task'ı bekleyen task

    // Zaman dilimi yönetimi
    TimeSlice   : Integer;      // Kalan tik sayısı
    TimeSliceMax: Integer;      // Toplam tik hakkı

    // İstatistik
    SwitchCount : LongWord;
    TotalTicks  : LongWord;
  end;

  // Scheduler
  PScheduler = ^TScheduler;
  TScheduler = record
    Tasks    : array[0..MAX_TASKS-1] of TTask;
    RunQueue : array[0..MAX_TASKS-1] of PTask;
    RunCount : Integer;
    Current  : Integer;         // RunQueue index
    IdleTask : PTask;
    TickCount: LongWord;
    NextTID  : Integer;
    Enabled  : Boolean;
  end;

  // Mutex
  PMutex = ^TMutex;
  TMutex = record
    Locked : Boolean;
    Owner  : PTask;
    Waiters: array[0..7] of PTask;
    WaitCount: Integer;
  end;

  // Spinlock
  PSpinlock = ^TSpinlock;
  TSpinlock = record
    Lock: LongWord;  // 0=free, 1=locked
  end;


  var
  FarJumpBuf: packed record
    Offset:   LongWord;
    Selector: Word;
  end;

//=============================================================================
// Global değişkenler
//=============================================================================

var
  Scheduler: TScheduler;

//=============================================================================
// API
//=============================================================================

// Başlatma
procedure Task_Init;

// Thread yönetimi
function  BeginThread(Entry: Pointer; Param: Pointer;
                        Name: PChar; Priority: Byte;
                        Flags: Byte): Integer;
procedure Thread_Exit(ExitCode: Integer);
procedure Thread_Kill(TID: Integer);
function  Thread_GetCurrent: PTask;
function  Thread_GetByTID(TID: Integer): PTask;

// Zamanlama
procedure Thread_Sleep(Ticks: LongWord);
procedure Thread_Yield;
procedure Thread_SetPriority(TID: Integer; Priority: Byte);

// Mutex
procedure Mutex_Init(M: PMutex);
procedure Mutex_Lock(M: PMutex);
procedure Mutex_Unlock(M: PMutex);
function  Mutex_TryLock(M: PMutex): Boolean;

// Spinlock
procedure Spin_Init(S: PSpinlock);
procedure Spin_Lock(S: PSpinlock);
procedure Spin_Unlock(S: PSpinlock);

// Dahili
procedure Task_Switch;
procedure Task_TimerISR;

procedure TSS_Init(T: PTSS32; Entry: Pointer; Param: Pointer;
                   StackBase: LongWord; StackSize: LongWord);

implementation







//=============================================================================
// Yardımcı — string kopyala
//=============================================================================

procedure CopyName(Dest: PChar; Src: PChar; Max: Integer);
var
  i: Integer;
begin
  i := 0;
  if Src <> nil then
    while (Src[i] <> #0) and (i < Max - 1) do
    begin
      Dest[i] := Src[i];
      Inc(i);
    end;
  Dest[i] := #0;
end;

//=============================================================================
// Port I/O
//=============================================================================

procedure OutB(Port: Word; Val: Byte);
begin
  asm
    mov dx, Port
    mov al, Val
    out dx, al
  end;
end;

function InB(Port: Word): Byte;
begin
  asm
    mov dx, Port
    in  al, dx
    mov Result, al
  end;
end;

//=============================================================================
// GDT TSS Descriptor yaz
//=============================================================================

//=============================================================================
// TR (Task Register) yükle
//=============================================================================

procedure Load_TR(Selector: Word);
begin
  asm
    mov ax, Selector
    ltr ax
  end;
end;

//=============================================================================
// Far JMP — TSS task switch
// JMP FAR [selector:0] → hardware task switch
//=============================================================================

procedure FarJump(Selector: Word);
var
  FarPtr: array[0..5] of Byte;
begin

  FarJumpBuf.Offset   := 0;
  FarJumpBuf.Selector := Selector;
  asm
    db $FF, $2D         // JMP FAR [mem32]
    dd FarJumpBuf
  end;
end;

//=============================================================================
// Interrupt disable/enable
//=============================================================================

procedure CLI; begin asm cli end; end;
procedure STI; begin asm sti end; end;

//=============================================================================
// PIC EOI gönder
//=============================================================================

procedure PIC_SendEOI;
begin
  OutB($20, $20);  // Master PIC EOI
end;

//=============================================================================
// Idle task — CPU'yu beklet
//=============================================================================

procedure IdleTask(Param: Pointer);
begin
  while True do
  begin
    asm hlt end;
    Thread_Yield;
  end;
end;

//=============================================================================
// Task_Init
//=============================================================================
procedure Task_Init;
var
  i:    Integer;
  idle: PTask;
  mask:byte;
begin
  CLI;

  FillChar(Scheduler, SizeOf(TScheduler), 0);
  Scheduler.Enabled := False;
  Scheduler.NextTID := 1;

  // Tüm slot'ları temizle
  i := 0;
  while i < MAX_TASKS do
  begin
    Scheduler.Tasks[i].State := TS_FREE;
    Scheduler.Tasks[i].TID   := -1;
    Inc(i);
  end;

  // GDT TSS descriptor'larını hazırla
  i := 0;
  while i < MAX_TASKS do
  begin
    // Önce sıfırla
    FillChar(Scheduler.Tasks[i].TSS, SizeOf(TTSS32), 0);



     SetGate(TASK_GDT_START + i,
               LongWord(@Scheduler.Tasks[i].TSS),
               SizeOf(TTSS32) - 1, $89, $00); // type 0x89 = 32-bit available TSS


    // Selector ata
    Scheduler.Tasks[i].Selector := Word((TASK_GDT_START + i) * 8);
    Inc(i);
  end;

  //-----------------------------------------------------------
  // Idle task — slot 0 (mevcut çalışan task olarak başlatılır)
  //-----------------------------------------------------------
  idle := @Scheduler.Tasks[0];

  idle^.TID          := 0;
  idle^.State        := TS_RUNNING;
  idle^.Priority     := PRIO_IDLE;
  idle^.Flags        := TF_KERNEL;
  idle^.TimeSlice    := 1;
  idle^.TimeSliceMax := 1;
  CopyName(@idle^.Name[0], 'idle', 32);

  // Idle stack
  idle^.StackBase := LongWord(MemAlloc(TASK_STACK_SIZE));
  idle^.StackSize := TASK_STACK_SIZE;
  FillChar(Pointer(idle^.StackBase)^, TASK_STACK_SIZE, 0);

  // Idle TSS
  TSS_Init(@idle^.TSS, @IdleTask, nil, idle^.StackBase, TASK_STACK_SIZE);

  // *** TR'yi idle task'a yükle ***
  // Mevcut çalışan görev olarak işaretle
  Load_TR(idle^.Selector);

  // RunQueue
  Scheduler.RunQueue[0] := idle;
  Scheduler.RunCount    := 1;
  Scheduler.Current     := 0;
  Scheduler.IdleTask    := idle;

  // PIT → ~100Hz
  // Divisor = 1193180 / 100 = 11931
  OutB($43, $36);
  OutB($40, Byte(11931 and $FF));
  OutB($40, Byte(11931 shr 8));

  // Timer ISR kayıt
  RegisterISR(32, @Task_TimerISR);

  // IRQ0 unmask
  mask := InB($21);
  mask := mask and not $01;  // bit0 = IRQ0
  OutB($21, mask);

  Scheduler.Enabled := True;

  STI;
end;


//=============================================================================
// Boş task slot bul
//=============================================================================

function AllocTaskSlot: PTask;
var
  i: Integer;
begin
  Result := nil;
  i := 1;  // 0 = idle, dokunma
  while i < MAX_TASKS do
  begin
    if Scheduler.Tasks[i].State = TS_FREE then
    begin
      Result := @Scheduler.Tasks[i];
      FillChar(Result^.TSS, SizeOf(TTSS32), 0);
      Result^.State := TS_READY;
      Result^.TID   := Scheduler.NextTID;
      Inc(Scheduler.NextTID);
      Exit;
    end;
    Inc(i);
  end;
end;


procedure TSS_Init(T: PTSS32; Entry: Pointer; Param: Pointer;
                   StackBase: LongWord; StackSize: LongWord);
begin
  FillChar(T^, SizeOf(TTSS32), 0);

  // *** Backlink = 0 (başka task'tan gelmiyoruz) ***
  T^.Backlink := 0;

  // *** Kernel stack (ring0 için ESP0:SS0) ***
  // IRQ geldiğinde kullanılır
  T^.ESP0 := StackBase + StackSize - 16;
  T^.SS0  := KERNEL_DS;

  // *** ESP1, ESP2 — Ring1/2 kullanmıyoruz, 0 bırak ***
  T^.ESP1 := 0; T^.SS1 := 0;
  T^.ESP2 := 0; T^.SS2 := 0;

  // *** CR3 — Paging kapalıysa 0, açıksa page directory adresi ***
  T^.CR3 := 0;

  // *** Entry point ***
  T^.EIP := LongWord(Entry);

  // *** EFlags: IF=1 (interrupt enable), IOPL=0, reserved bit 1=1 ***
  T^.EFlags := $00000202;

  // *** Genel register'lar ***
  T^.EAX := LongWord(Param);  // İlk parametre
  T^.EBX := 0;
  T^.ECX := 0;
  T^.EDX := 0;
  T^.ESI := 0;
  T^.EDI := 0;

  // *** Stack pointer — 16 byte hizalı ***
  T^.ESP := (StackBase + StackSize - 16) and not 15;
  T^.EBP := T^.ESP;

  // *** Segment register'lar ***
  T^.CS := KERNEL_CS;
  T^.SS := KERNEL_DS;
  T^.DS := KERNEL_DS;
  T^.ES := KERNEL_DS;
  T^.FS := KERNEL_DS;
  T^.GS := KERNEL_DS;

  // *** LDT — kullanmıyoruz ***
  T^.LDT := 0;

  // *** Trap flag — 0 (debug trap yok) ***
  T^.Trap := 0;

  // *** IOMap offset — TSS sonuna işaret et (no IO permission map) ***
  // SizeOf(TTSS32) değerinde olursa IO map yok sayılır
  T^.IOMap := SizeOf(TTSS32);
end;

//=============================================================================
// Thread wrapper — thread bitince temizle
//=============================================================================
procedure ThreadWrapper;
begin
  asm
    // Stack 16-byte hizala
    and esp, $FFFFFFF0

    // Param push (entry'nin ilk parametresi)
    push ebx        // param

    // Entry çağır
    call eax        // entry(param)

    add esp, 4

    // Thread_Exit(0)
    push 0
    call Thread_Exit
    add esp, 4

    // Buraya gelmemeli ama gelse bile hlt
  @@loop:
    hlt
    jmp @@loop
  end;
end;


//=============================================================================
// Thread_Create
//=============================================================================
function BeginThread(Entry: Pointer; Param: Pointer;
                             Name: PChar; Priority: Byte;
                             Flags: Byte): Integer;
var
  t:     PTask;
  stack: LongWord;
begin
  Result := INVALID_HANDLE;
  if Entry = nil then Exit;

  CLI;

  t := AllocTaskSlot;
  if t = nil then begin STI; Exit; end;

  // 16KB stack (8KB yeterli olabilir ama güvenli taraf)
  stack := LongWord(MemAlloc(TASK_STACK_SIZE));
  if stack = 0 then
  begin
    t^.State := TS_FREE;
    STI;
    Exit;
  end;

  // Stack belleği sıfırla
  FillChar(Pointer(stack)^, TASK_STACK_SIZE, 0);

  t^.StackBase    := stack;
  t^.StackSize    := TASK_STACK_SIZE;
  t^.Priority     := Priority;
  t^.Flags        := Flags;
  t^.TimeSliceMax := Priority + 2;
  t^.TimeSlice    := t^.TimeSliceMax;

  CopyName(@t^.Name[0], Name, 32);

  // TSS hazırla (wrapper üzerinden çalışacak)
  TSS_Init(@t^.TSS, @ThreadWrapper, nil, stack, TASK_STACK_SIZE);

  // EAX = Entry, EBX = Param (ThreadWrapper okuyacak)
  t^.TSS.EAX := LongWord(Entry);
  t^.TSS.EBX := LongWord(Param);

  // RunQueue'ya ekle
  CLI;  // Zaten CLI içindeyiz ama garanti için
  if Scheduler.RunCount < MAX_TASKS then
  begin
    t^.State := TS_READY;
    Scheduler.RunQueue[Scheduler.RunCount] := t;
    Inc(Scheduler.RunCount);
  end
  else
  begin
    // Queue dolu
    FreeMem(Pointer(stack));
    t^.State := TS_FREE;
    STI;
    Exit;
  end;

  Result := t^.TID;

  STI;
end;



//=============================================================================
// Thread_GetCurrent
//=============================================================================

function Thread_GetCurrent: PTask;
begin
  if Scheduler.RunCount = 0 then
    Result := nil
  else
    Result := Scheduler.RunQueue[Scheduler.Current];
end;

//=============================================================================
// Thread_GetByTID
//=============================================================================

function Thread_GetByTID(TID: Integer): PTask;
var
  i: Integer;
begin
  Result := nil;
  i := 0;
  while i < MAX_TASKS do
  begin
    if (Scheduler.Tasks[i].State <> TS_FREE) and
       (Scheduler.Tasks[i].TID = TID) then
    begin
      Result := @Scheduler.Tasks[i];
      Exit;
    end;
    Inc(i);
  end;
end;

//=============================================================================
// Thread_Exit — mevcut thread'i sonlandır
//=============================================================================

procedure Thread_Exit(ExitCode: Integer);
var
  t: PTask;
begin
  CLI;

  t := Thread_GetCurrent;
  if t = nil then begin STI; Exit; end;

  t^.ExitCode := ExitCode;
  t^.State    := TS_ZOMBIE;

  // Join bekleyen varsa uyandır
  if t^.JoinTask <> nil then
  begin
    t^.JoinTask^.State := TS_READY;
    t^.JoinTask := nil;
  end;

  STI;

  // Bir daha bu thread çalışmayacak, switch yap
  Task_Switch;

  // Buraya gelmemeli
  while True do asm hlt end;
end;

//=============================================================================
// Thread_Kill — başka bir thread'i öldür
//=============================================================================

procedure Thread_Kill(TID: Integer);
var
  t: PTask;
  i: Integer;
begin
  CLI;

  t := Thread_GetByTID(TID);
  if t = nil then begin STI; Exit; end;

  t^.State := TS_ZOMBIE;

  // Stack serbest bırak
  if t^.StackBase <> 0 then
  begin
    FreeMem(Pointer(t^.StackBase));
    t^.StackBase := 0;
  end;

  // RunQueue'dan çıkar
  i := 0;
  while i < Scheduler.RunCount do
  begin
    if Scheduler.RunQueue[i] = t then
    begin
      // Son elemanı buraya taşı
      Scheduler.RunQueue[i] :=
        Scheduler.RunQueue[Scheduler.RunCount - 1];
      Dec(Scheduler.RunCount);

      // Current index taşma kontrolü
      if Scheduler.Current >= Scheduler.RunCount then
        Scheduler.Current := 0;

      Break;
    end;
    Inc(i);
  end;

  t^.State := TS_FREE;

  STI;
end;

//=============================================================================
// Thread_Sleep — tik sayısı kadar bekle
//=============================================================================

procedure Thread_Sleep(Ticks: LongWord);
var
  t: PTask;
begin
  CLI;

  t := Thread_GetCurrent;
  if t = nil then begin STI; Exit; end;

  t^.State     := TS_SLEEPING;
  t^.SleepTick := Scheduler.TickCount + Ticks;

  STI;

  // Scheduler bizi uyandırana kadar switch yap
  Task_Switch;
end;

//=============================================================================
// Thread_Yield — gönüllü CPU bırak
//=============================================================================

procedure Thread_Yield;
begin
  Task_Switch;
end;

//=============================================================================
// Thread_SetPriority
//=============================================================================

procedure Thread_SetPriority(TID: Integer; Priority: Byte);
var
  t: PTask;
begin
  t := Thread_GetByTID(TID);
  if t = nil then Exit;
  t^.Priority     := Priority;
  t^.TimeSliceMax := Priority + 1;
end;

//=============================================================================
// Scheduler — sonraki çalışacak task'ı bul
//=============================================================================

function Scheduler_Next: PTask;
var
  i:    Integer;
  best: PTask;
  bestPrio: Integer;
  count:    Integer;
  t:        PTask;
begin
  // Sleeping task'ları uyandır
  i := 0;
  while i < Scheduler.RunCount do
  begin
    t := Scheduler.RunQueue[i];
    if (t^.State = TS_SLEEPING) and
       (Scheduler.TickCount >= t^.SleepTick) then
      t^.State := TS_READY;
    Inc(i);
  end;

  // Round-robin + Priority
  // Önce mevcut index'ten sonraki READY task
  count    := Scheduler.RunCount;
  best     := nil;
  bestPrio := -1;

  // Tüm READY task'ları tara, en yüksek priority'li seç
  i := 0;
  while i < count do
  begin
    t := Scheduler.RunQueue[i];
    if (t <> nil) and (t^.State = TS_READY) and
       (Integer(t^.Priority) > bestPrio) then
    begin
      best     := t;
      bestPrio := t^.Priority;
    end;
    Inc(i);
  end;

  // Eğer kimse READY değilse idle'a geç
  if best = nil then
    best := Scheduler.IdleTask;

  Result := best;
end;

//=============================================================================
// Task_Switch — ana context switch
//=============================================================================
procedure Task_Switch;
var
  cur,t:  PTask;
  next: PTask;
  i,startIdx,Idx,checked:    Integer;
begin
  if not Scheduler.Enabled then Exit;
  if Scheduler.RunCount < 2 then Exit;

  cur := Thread_GetCurrent;

  // Sleeping task'ları uyandır
  i := 0;
  while i < Scheduler.RunCount do
  begin
    if (Scheduler.RunQueue[i]^.State = TS_SLEEPING) and
       (Scheduler.TickCount >= Scheduler.RunQueue[i]^.SleepTick) then
      Scheduler.RunQueue[i]^.State := TS_READY;
    Inc(i);
  end;

  // Sonraki READY task'ı bul (current'dan sonraki)
  next := nil;
   startIdx := (Scheduler.Current + 1) mod Scheduler.RunCount;
   idx := startIdx;

  // Round-robin: current'dan sonra başla, dön
   checked := 0;
  while checked < Scheduler.RunCount do
  begin
     t := Scheduler.RunQueue[idx];
    if (t <> nil) and (t^.State = TS_READY) then
    begin
      next := t;
      Scheduler.Current := idx;
      Break;
    end;
    idx := (idx + 1) mod Scheduler.RunCount;
    Inc(checked);
  end;

  // Hiç READY yoksa idle
  if next = nil then
  begin
    next := Scheduler.IdleTask;
    // Idle'ı bul
    i := 0;
    while i < Scheduler.RunCount do
    begin
      if Scheduler.RunQueue[i] = next then
      begin
        Scheduler.Current := i;
        Break;
      end;
      Inc(i);
    end;
  end;

  if next = cur then Exit;  // Değişiklik yok

  // Mevcut task state güncelle
  if (cur <> nil) and (cur^.State = TS_RUNNING) then
    cur^.State := TS_READY;

  // Yeni task RUNNING
  next^.State := TS_RUNNING;
  Inc(next^.SwitchCount);

  // *** FarJump ile switch ***
  FarJump(next^.Selector);

  // *** Buraya döndüğümüzde biz tekrar çalışıyoruz ***
  // TS (Task Switched) flag'ini temizle
  asm clts end;
end;


//=============================================================================
// Zombie cleanup
//=============================================================================

procedure Cleanup_Zombies;
var
  i,j: Integer;
  t: PTask;
begin
  i := 1;  // 0 = idle
  while i < MAX_TASKS do
  begin
    t := @Scheduler.Tasks[i];
    if t^.State = TS_ZOMBIE then
    begin
      // Stack serbest bırak
      if t^.StackBase <> 0 then
      begin
        FreeMem(Pointer(t^.StackBase));
        t^.StackBase := 0;
        t^.StackSize := 0;
      end;

      // RunQueue'dan çıkar
      j := 0;
      while j < Scheduler.RunCount do
      begin
        if Scheduler.RunQueue[j] = t then
        begin
          Scheduler.RunQueue[j] :=
            Scheduler.RunQueue[Scheduler.RunCount - 1];
          Dec(Scheduler.RunCount);
          if Scheduler.Current >= Scheduler.RunCount then
            Scheduler.Current := 0;
          Break;
        end;
        Inc(j);
      end;

      t^.State := TS_FREE;
    end;
    Inc(i);
  end;
end;

//=============================================================================
// Task_TimerISR — Timer IRQ0 handler (INT 32)
//=============================================================================
procedure Task_TimerISR;
var
  cur: PTask;
begin
  // *** EOI ÖNCE gönder — aksi halde diğer IRQ'lar bloklanır ***
  OutB($20, $20);

  Inc(Scheduler.TickCount);

  if not Scheduler.Enabled then Exit;

  // Zombie temizle
  Cleanup_Zombies;

  // Time slice
  cur := Thread_GetCurrent;
  if cur <> nil then
  begin
    Inc(cur^.TotalTicks);

    if cur^.State = TS_SLEEPING then
    begin
      // Uyuyan task: switch yap
      Task_Switch;
      Exit;
    end;

    Dec(cur^.TimeSlice);
    if cur^.TimeSlice > 0 then Exit;
    cur^.TimeSlice := cur^.TimeSliceMax;
  end;

  Task_Switch;
end;



//=============================================================================
// Mutex
//=============================================================================

procedure Mutex_Init(M: PMutex);
begin
  if M = nil then Exit;
  M^.Locked    := False;
  M^.Owner     := nil;
  M^.WaitCount := 0;
end;

procedure Mutex_Lock(M: PMutex);
var
  cur: PTask;
begin
  if M = nil then Exit;

  while True do
  begin
    CLI;

    if not M^.Locked then
    begin
      M^.Locked := True;
      M^.Owner  := Thread_GetCurrent;
      STI;
      Exit;
    end;

    // Zaten kilitli — bekleme listesine gir
    cur := Thread_GetCurrent;
    if (cur <> nil) and (M^.WaitCount < 8) then
    begin
      M^.Waiters[M^.WaitCount] := cur;
      Inc(M^.WaitCount);
      cur^.State     := TS_BLOCKED;
      cur^.WaitMutex := M;
    end;

    STI;
    Thread_Yield;  // Başka task çalışsın
  end;
end;

function Mutex_TryLock(M: PMutex): Boolean;
begin
  Result := False;
  if M = nil then Exit;

  CLI;
  if not M^.Locked then
  begin
    M^.Locked := True;
    M^.Owner  := Thread_GetCurrent;
    Result    := True;
  end;
  STI;
end;

procedure Mutex_Unlock(M: PMutex);
var
  i:    Integer;
  w:    PTask;
begin
  if M = nil then Exit;

  CLI;

  M^.Locked := False;
  M^.Owner  := nil;

  // Bekleyenleri uyandır
  if M^.WaitCount > 0 then
  begin
    w := M^.Waiters[0];

    // Listeyi kaydır
    i := 0;
    while i < M^.WaitCount - 1 do
    begin
      M^.Waiters[i] := M^.Waiters[i + 1];
      Inc(i);
    end;
    Dec(M^.WaitCount);

    // Uyandır
    if w <> nil then
    begin
      w^.State     := TS_READY;
      w^.WaitMutex := nil;
    end;
  end;

  STI;
end;

//=============================================================================
// Spinlock
//=============================================================================

procedure Spin_Init(S: PSpinlock);
begin
  if S <> nil then S^.Lock := 0;
end;

procedure Spin_Lock(S: PSpinlock);
begin
  if S = nil then Exit;
  asm
    @retry:
    mov eax, 1
    xchg eax, [S]     // Atomic swap
    test eax, eax
    jnz  @retry       // Kilitliyse tekrar dene
  end;
end;

procedure Spin_Unlock(S: PSpinlock);
begin
  if S = nil then Exit;
  asm
    mov dword ptr [S], 0
  end;
end;

end.

{ =========================================================
  KULLANIM ÖRNEĞİ
  ========================================================= }

(*
uses Task;

// Basit thread
procedure MyThread(Param: Pointer);
var
  i: Integer;
begin
  i := 0;
  while True do
  begin
    // İş yap...
    Inc(i);
    Thread_Sleep(10);  // 10 tick bekle (~100ms @ 100Hz)
  end;
end;

// Thread oluştur
var
  tid: Integer;
begin
  Task_Init;

  tid := Thread_Create(@MyThread, nil, 'worker', PRIO_NORMAL, TF_KERNEL);
  // tid = thread ID (>0 başarılı, -1 hata)
end;

// Mutex kullanımı
var
  M: TMutex;
begin
  Mutex_Init(@M);

  // Thread 1:
  Mutex_Lock(@M);
  // ... kritik bölge ...
  Mutex_Unlock(@M);

  // Thread 2 (aynı anda):
  if Mutex_TryLock(@M) then
  begin
    // ... kritik bölge ...
    Mutex_Unlock(@M);
  end;
end;

// Thread öldür
Thread_Kill(tid);

// Mevcut thread bilgisi
var t := Thread_GetCurrent;
// t^.Name, t^.TID, t^.SwitchCount, t^.TotalTicks
*)

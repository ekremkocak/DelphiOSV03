Unit Intr32;

interface



const

  REAL16_SIZE = 134;
  REAL16_DATA: array[0..REAL16_SIZE-1] of Byte = (
    $0F, $20, $C0, $24, $FE, $0F, $22, $C0, $EA, $0D, $7D, $00, $00, $31, $C0, $8E, 
    $D8, $8E, $C0, $66, $B8, $FF, $FF, $00, $00, $66, $89, $C4, $B8, $00, $20, $8E, 
    $D0, $0F, $01, $1E, $80, $7D, $FB, $A1, $0A, $7C, $8E, $C0, $A1, $02, $7C, $8B, 
    $1E, $04, $7C, $8B, $0E, $06, $7C, $8B, $16, $08, $7C, $8B, $36, $0E, $7C, $8B, 
    $3E, $10, $7C, $EB, $04, $00, $00, $00, $00, $CD, $13, $A3, $02, $7C, $89, $1E,
    $04, $7C, $89, $0E, $06, $7C, $89, $16, $08, $7C, $8C, $06, $0A, $7C, $89, $36, 
    $0E, $7C, $89, $3E, $10, $7C, $FA, $0F, $01, $16, $00, $7F, $66, $8B, $0E, $FC,
    $7C, $0F, $20, $C0, $0C, $01, $0F, $22, $C0, $EA, $7E, $7D, $08, $00, $FF, $E1, 
    $FF, $03, $00, $00, $00, $00
  );

 const
  REAL32_SIZE = 330;  REAL32_DATA: array[0..REAL32_SIZE-1] of Byte = (    $66, $B8, $10, $00, $00, $00, $8E, $D8, $8E, $C0, $8E, $E8, $8E, $E0, $8E, $E8,     $8E, $D0, $0F, $20, $C0, $66, $25, $FE, $FF, $FF, $FF, $0F, $22, $C0, $EA, $23,     $7C, $00, $00, $60, $B8, $00, $00, $8E, $D8, $8E, $C0, $8E, $E0, $8E, $E8, $8E,     $D0, $0F, $01, $1E, $0D, $7D, $66, $BE, $2C, $00, $01, $00, $67, $8A, $06, $A2,     $91, $7C, $66, $BE, $00, $00, $01, $00, $67, $66, $8B, $06, $66, $BE, $04, $00,     $01, $00, $67, $66, $8B, $1E, $66, $BE, $08, $00, $01, $00, $67, $66, $8B, $0E,     $66, $BE, $0C, $00, $01, $00, $67, $66, $8B, $16, $66, $BE, $14, $00, $01, $00,     $67, $66, $8B, $3E, $66, $BE, $24, $00, $01, $00, $67, $8E, $06, $66, $BE, $28,     $00, $01, $00, $67, $8E, $1E, $66, $BE, $10, $00, $01, $00, $67, $66, $8B, $36,     $CD, $00, $66, $56, $66, $BE, $14, $00, $01, $00, $67, $66, $89, $3E, $66, $5E,     $66, $BF, $10, $00, $01, $00, $67, $66, $89, $37, $66, $BE, $0C, $00, $01, $00,     $67, $66, $89, $16, $66, $BE, $08, $00, $01, $00, $67, $66, $89, $0E, $66, $BE,     $04, $00, $01, $00, $67, $66, $89, $1E, $66, $BE, $00, $00, $01, $00, $67, $66,     $89, $06, $66, $BE, $24, $00, $01, $00, $67, $8C, $06, $66, $BE, $28, $00, $01,     $00, $67, $8C, $1E, $61, $90, $90, $FA, $0F, $01, $16, $44, $7D, $0F, $20, $C0,     $66, $0D, $01, $00, $00, $00, $0F, $22, $C0, $EA, $FE, $7C, $08, $00, $66, $B8,     $10, $00, $8E, $D8, $8E, $D0, $8E, $C0, $8E, $E0, $8E, $E8, $C3, $FF, $03, $00,     $00, $00, $00, $FA, $66, $31, $C0, $8E, $D8, $0F, $01, $15, $44, $7D, $00, $00,     $0F, $20, $C0, $0D, $01, $00, $00, $00, $0F, $22, $C0, $C3, $00, $00, $00, $00,     $00, $00, $00, $00, $FF, $FF, $00, $00, $00, $9A, $CF, $00, $FF, $FF, $00, $00,     $00, $92, $CF, $00, $17, $00, $2C, $7D, $00, $00  );

type
   TReg16 = packed record
    ax,bx,cx,dx,es,si,di: Word;
  end;

type
  PReg32=^TReg32;
  TReg32 = packed  record
    eax, ebx, ecx, edx,
    esi, edi, ebp, esp,
    eflags,
    es, ds: DWORD;
    interrupt_no: DWORD;
  end;


var


  Reg32:PReg32=pointer($10000);

  procedure Intr16(var Regs: TReg16; const AInt: Byte);
  procedure Intr_32(var Regs: TReg32; const AInt: Integer);

implementation
 Uses
   SysUtils,Idt,Ports;


Procedure ClearRegs(Var Regs : TReg16);
begin
  FillChar(Regs,Sizeof(TReg16),#0);
end;


procedure JumpToRM16();
asm
    pusha
    pushf
    call  RemapIRQRM
    mov   al,$FF
    out   $A1,al
    out   $21,al

    mov   ax,ss
    mov   word ptr[@save_ss],ax
    mov   eax,esp
    mov   dword ptr[@save_esp],eax
    mov   eax,cr3
    mov   dword ptr[@save_cr3],eax
    mov   eax,cr0
    mov   dword ptr[@save_cr0],eax
    and   eax,$7FFFFFFF
    mov   cr0,eax
    mov   esi,$7CFC

    mov   [esi],OFFSET @ReturnToPM

    mov   ax,$30
    mov   ds,ax
    mov   es,ax
    mov   fs,ax
    mov   gs,ax
    db $EA
    dd $7D00
    dw $0028


 @ReturnToPM:
    mov   ax,$10
    mov   ds,ax
    mov   es,ax

    mov   ax,word ptr[@save_ss]
    mov   ss,ax
    mov   eax,dword ptr[@save_esp]
    mov   esp,eax
    mov	  eax,dword ptr[@save_cr3]
    mov   cr3,eax
    mov	  eax,dword ptr [@save_cr0 ]
    mov   cr0,eax

    call  RemapIRQPM
    call  RestoreIRQs
    mov   al,$20
    out   $A0,al
    out   $20,al

    popf
    popa
    ret

 @save_cr0:
    dd 0
 @save_ss:
    dw 0
 @save_esp:
    dd 0
 @save_cr3:
    dd 0
end;


procedure Intr16(var Regs: TReg16; const AInt: Byte);
begin
  Move(REAL16_DATA,pointer($7D00)^,REAL16_SIZE);
  Byte(pointer($7D00+74)^):= AInt;

  word(pointer($7C00+2)^) :=Regs.ax;
  word(pointer($7C00+4)^) :=Regs.bx;
  word(pointer($7C00+6)^) :=Regs.cx;
  word(pointer($7C00+8)^) :=Regs.dx;
  word(pointer($7C00+10)^):=Regs.es;
  word(pointer($7C00+14)^):=Regs.si;
  word(pointer($7C00+16)^):=Regs.di;


 // IRQ_CLI();
  JumpToRM16;
 // IRQ_STI();



  Regs.ax := word(pointer($7C00+2)^) ;
  Regs.bx := word(pointer($7C00+4)^) ;
  Regs.cx := word(pointer($7C00+6)^) ;
  Regs.dx := word(pointer($7C00+8)^) ;
  Regs.es := word(pointer($7C00+10)^) ;
  Regs.si := word(pointer($7C00+14)^) ;
  Regs.di := word(pointer($7C00+16)^) ; 


end;

procedure JumpToRM32();
asm
  cli
  lgdt [$7F00]
  db $EA
  dd $7C00, $28
end;

procedure Intr_32(var Regs: TReg32; const AInt: Integer);
begin
  Move(REAL32_DATA,pointer($7C00)^,REAL32_SIZE);

   Reg32^.eax := Regs.eax;
   Reg32^.ebx := Regs.ebx;
   Reg32^.ecx := Regs.ecx;
   Reg32^.edx := Regs.edx;
   Reg32^.esi := Regs.esi;
   Reg32^.edi := Regs.edi;
   Reg32^.ebp := Regs.ebp;
   Reg32^.ds := Regs.ds;
   Reg32^.es := Regs.es;
   Reg32^.interrupt_no := AInt;
 asm
   push es
   push ds
 end;
   JumpToRM32();
 asm
   pop ds
   pop es
 end;

 move(Pointer($10000)^,Regs,SizeOf(TReg32));

 

 {
   Regs.eax := Reg32^.eax;
   Regs.ebx := Reg32^.ebx;
   Regs.ecx := Reg32^.ecx;
   Regs.edx := Reg32^.edx;
   Regs.esi := Reg32^.esi;
   Regs.edi := Reg32^.edi;
   Regs.ebp := Reg32^.ebp; }
  // Regs.eflag := Reg32^.eflag;

     RemapIRQPM();
    RestoreIRQs();

end;

{

 Regs.Eax:=$4F01;
  Regs.Ecx:=$4118;
  regs.es :=  (LongWord(Vesa_Info1) shr 4);
  regs.edi := (LongWord(Vesa_Info1) and $F) ;
  Int32(Regs,$10);

 }




end.


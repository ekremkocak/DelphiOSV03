Unit Pci;

interface

uses
  SysUtils,IDT,Ports,WinSocket, Memory, Fat32;



type
  TPciIdEntry = record
    VendorID: Word;
    DeviceID: Word;
    VendorName: PChar;
    DeviceName: PChar;
  end;

const
  KnownDevices1: array[0..12] of TPciIdEntry = (
    (VendorID: $10EC; DeviceID: $8139; VendorName: 'Realtek'; DeviceName: 'RTL8139 LAN'),
    (VendorID: $10EC; DeviceID: $8029; VendorName: 'Realtek'; DeviceName: 'Ne2000 LAN'),
    (VendorID: $8086; DeviceID: $1237; VendorName: 'Intel'; DeviceName: 'PCI Bridge'),
    (VendorID: $8086; DeviceID: $100E; VendorName: 'Intel'; DeviceName: '82540EM Gigabit Ethernet'),
    (VendorID: $1050; DeviceID: $0940; VendorName: 'Winbond'; DeviceName: 'NE2000 Compatible LAN'),
    (VendorID: $10DE; DeviceID: $1C82; VendorName: 'NVIDIA'; DeviceName: 'GeForce GTX 1050'),
    (VendorID: $1002; DeviceID: $67DF; VendorName: 'AMD'; DeviceName: 'Radeon RX 580'),
    (VendorID: $8086; DeviceID: $2668; VendorName: 'Intel'; DeviceName: 'High Definition Audio Controller'),
    (VendorID: $14F1; DeviceID: $2F00; VendorName: 'Conexant'; DeviceName: 'HDA D330 MDC Modem'),
    (VendorID: $8086; DeviceID: $29C0; VendorName: 'Intel'; DeviceName: 'ICH9 Family LPC Interface'),
    (VendorID: $104C; DeviceID: $AC10; VendorName: 'Texas Instruments'; DeviceName: 'OHCI Compliant FireWire Controller'),
    (VendorID: $8086; DeviceID: $2415; VendorName: 'Intel'; DeviceName: 'AC 97 Audio Controller'),
    (VendorID: $1106; DeviceID: $3059; VendorName: 'VIA'; DeviceName: 'AC 97 Enhanced Audio Controller')
  );

  const
  KnownDevices: array[0..10] of TPciIdEntry = (
    // A� Kartlar�
    (VendorID: $10EC; DeviceID: $8139; VendorName: 'Realtek'; DeviceName: 'RTL8139 LAN'),
    (VendorID: $8086; DeviceID: $100E; VendorName: 'Intel'; DeviceName: 'PRO/1000 MT (e1000)'),
    (VendorID: $1AF4; DeviceID: $1000; VendorName: 'Red Hat'; DeviceName: 'Virtio Network'),
    (VendorID: $10EC; DeviceID: $8029; VendorName: 'Realtek'; DeviceName: 'Ne2000 LAN'),
    // Disk Denetleyicileri
    (VendorID: $8086; DeviceID: $7010; VendorName: 'Intel'; DeviceName: 'PIIX3 IDE Controller'),
    (VendorID: $1AF4; DeviceID: $1001; VendorName: 'Red Hat'; DeviceName: 'Virtio Block Device'),

    // VGA / G�r�nt� Ayg�tlar�
    (VendorID: $1234; DeviceID: $1111; VendorName: 'QEMU'; DeviceName: 'Standard VGA'),
    (VendorID: $1AF4; DeviceID: $1050; VendorName: 'Red Hat'; DeviceName: 'Virtio VGA'),
    (VendorID: $1B36; DeviceID: $0100; VendorName: 'QXL'; DeviceName: 'QXL VGA'),
    (VendorID: $1013; DeviceID: $00B8; VendorName: 'Cirrus Logic'; DeviceName: 'Cirrus SVGA'),

    (VendorID: $8086; DeviceID: $2415; VendorName: 'Intel'; DeviceName: 'AC 97 Audio Controller')
  );





type
  PPciDevice = ^TPciDevice;
  TPciDevice = record
    Bus, Dev, Func: Byte;
    VendorID, DeviceID: Word;
    ClassCode, SubClass, ProgIF, Revision: Byte;
    Bars: array[0..5] of DWord; // BAR0..BAR5
    IRQ: Byte;
    Next: PPciDevice;
  end;




 


var
  PciDeviceList: PPciDevice = nil;


  procedure pci_init();
  function ReadPCIConfigDword(Bus, Device, Func, Offset: Byte): DWord;
  function WritePCIConfigDword(Bus, Device, Func, Offset: Byte; Data: LongWord): DWord;
  function GetPCIDeviceVendorID(Bus, Device, Func: Byte): Word;
  function GetPCIDeviceID(Bus, Device, Func: Byte): Word;
  function GetPCIInterruptLine(Bus, Device, Func: Byte): Byte;
  function GetPCIBaseAddress(Bus, Device, Func: Byte; BarIndex: Byte): DWord;
  function GetPCIMemAddress(Bus, Device, Func: Byte): DWord;
  function GetPCIBarType(Bus, Device, Func: Byte; BarIndex: Byte): Byte;
  procedure ScanPCIDevices;
  function GetDeviceType(ClassCode, SubClass: Byte): PChar;
  function GetPciDeviceByIndex(Index: Integer): PPciDevice;

implementation

function ReadPCIConfigDword(Bus, Device, Func, Offset: Byte): DWord;
var
  Address: LongWord;
begin
  Address := (LongWord(Bus) shl 16) or (LongWord(Device) shl 11) or (LongWord(Func) shl 8) or (Offset and $FC) or $80000000;
  WritePortD($CF8, Address);
  Result := readPortD($CFC);
end;

function WritePCIConfigDword(Bus, Device, Func, Offset: Byte; Data: LongWord): DWord;
var
  Address: LongWord;
begin

  Address := (LongWord(Bus) shl 16) or (LongWord(Device) shl 11) or (LongWord(Func) shl 8) or (Offset and $FC) or $80000000;
  WritePortD($CF8, Address);
  WritePortD($CFC, Data);

  Result := 0; // ��lem ba�ar�yla tamamland�ysa 0 d�nd�r�lebilir
end;


function GetPCIDeviceVendorID(Bus, Device, Func: Byte): Word;
var
  Data: LongWord;
begin
  Data := ReadPCIConfigDword(Bus, Device, Func, 0);
  Result := Word(Data);
end;

function GetPCIDeviceID(Bus, Device, Func: Byte): Word;
var
  Data: LongWord;
begin
  Data := ReadPCIConfigDword(Bus, Device, Func, 0);
  Result := Word(Data shr 16);
end;





function GetPCIInterruptLine(Bus, Device, Func: Byte): Byte;
var
  Address: DWord;
begin
  // PCI Configuration Address
  Address := $80000000 or (Bus shl 16) or (Device shl 11) or (Func shl 8) or ($3C and $FC);

  // Yazma i�lemi: PCI Configuration Address Register
  WritePortD($CF8, Address);

  // Okuma i�lemi: PCI Configuration Data Register
  Result := ReadPortB($CFC);
end;



function GetPCIBaseAddress(Bus, Device, Func: Byte; BarIndex: Byte): DWord;
var
  Address: LongWord;
begin
  // PCI Configuration Address ayarlar�
  Address := $80000000 or (Bus shl 16) or (Device shl 11) or (Func shl 8) or ($10 + (BarIndex * 4));
  
  // PCI Configuration Address Register'a yazma i�lemi
  WritePortD($CF8, Address);

  // PCI Configuration Data Register'dan okuma i�lemi
  Result := ReadPortD($CFC);
end;


function GetPCIMemAddress(Bus, Device, Func: Byte): DWord;
var
  Address: LongWord;
begin
  // PCI Configuration Address ayarlar�
  Address := $80000000 or (Bus shl 16) or (Device shl 11) or (Func shl 8) or $14;

  // PCI Configuration Address Register'a yazma i�lemi
  WritePortD($CF8, Address);
  
  // PCI Configuration Data Register'dan okuma i�lemi
  Result := ReadPortD($CFC);
end;


function GetPCIBarType(Bus, Device, Func: Byte; BarIndex: Byte): Byte;
var
  Address: DWord;
  BarValue: DWord;
begin
  // PCI Configuration Address Register ayarlamas�
  Address := $80000000 or (Bus shl 16) or (Device shl 11) or (Func shl 8) or $10;

  // PCI Configuration Address Register'�na yazma i�lemi
  WritePortD($CF8, Address);

  // PCI Configuration Data Register'�n� okuyun (BAR'� okuma i�lemi i�in)
  // BAR'lar� $10 offsetten ba�layarak 4-byte'l�k bloklar halinde yerle�tirilir.
  Address := $80000000 or (Bus shl 16) or (Device shl 11) or (Func shl 8) or ($10 + (BarIndex * 4));
  WritePortD($CF8, Address);
  BarValue := ReadPortD($CFC);

  // BAR t�r�n� belirleyin (I/O port veya bellek adresi)
  if (BarValue and $1) = 0 then
    Result := 0 // Bellek tabanl� (Memory-mapped)
  else
    Result := 1; // Port tabanl� (I/O port-mapped)
end;


procedure ScanPCIDevices;
var
  Bus, Dev, Func, BarIndex: Byte;
  VendorID, DeviceID: Word;
  HeaderType: Byte;
  Config: DWord;
  NewDevice: PPciDevice;
  Tail: PPciDevice;
begin
  PciDeviceList := nil;
  Tail := nil;

  for Bus := 0 to 255 do
    for Dev := 0 to 31 do
      for Func := 0 to 7 do
      begin
        Config := ReadPCIConfigDword(Bus, Dev, Func, 0);
        VendorID := Word(Config and $FFFF);
        DeviceID := Word((Config shr 16) and $FFFF);

        if VendorID = $FFFF then Continue;

        // Yeni cihaz nesnesi olu�tur
        NewDevice := MemAlloc(SizeOf(TPciDevice));
        FillChar(NewDevice^, SizeOf(TPciDevice), #0);

        NewDevice^.Bus := Bus;
        NewDevice^.Dev := Dev;
        NewDevice^.Func := Func;
        NewDevice^.VendorID := VendorID;
        NewDevice^.DeviceID := DeviceID;

        Config := ReadPCIConfigDword(Bus, Dev, Func, $08);
        NewDevice^.Revision := Byte(Config and $FF);
        NewDevice^.ProgIF := Byte((Config shr 8) and $FF);
        NewDevice^.SubClass := Byte((Config shr 16) and $FF);
        NewDevice^.ClassCode := Byte((Config shr 24) and $FF);

        // BAR'lar� oku
        for BarIndex := 0 to 5 do
          NewDevice^.Bars[BarIndex] := ReadPCIConfigDword(Bus, Dev, Func, $10 + (BarIndex * 4));

        // IRQ oku
        Config := ReadPCIConfigDword(Bus, Dev, Func, $3C);
        NewDevice^.IRQ := Byte(Config and $FF);

        // Listeye ekle
        if PciDeviceList = nil then
        begin
          PciDeviceList := NewDevice;
          Tail := NewDevice;
        end
        else
        begin
          Tail^.Next := NewDevice;
          Tail := NewDevice;
        end;

        // Tek fonksiyonlu cihazsa di�er fonksiyonlara ge�me
        HeaderType := ReadPCIConfigDword(Bus, Dev, Func, $0C) shr 16 and $FF;
        if (Func = 0) and ((HeaderType and $80) = 0) then Break;
      end;
end;


function GetDeviceType(ClassCode, SubClass: Byte): PChar;
begin
  case ClassCode of
    $01: // Mass Storage
      case SubClass of
        $00: Result := 'SCSI Controller';
        $01: Result := 'IDE Controller';
        $06: Result := 'SATA Controller';
      else
        Result := 'Storage Controller';
      end;

    $02: // Network
      case SubClass of
        $00: Result := 'Ethernet Controller';
      else
        Result := 'Network Controller';
      end;

    $03: // Display
      case SubClass of
        $00: Result := 'VGA Controller';
      else
        Result := 'Display Controller';
      end;

    $0C: // Serial Bus
      case SubClass of
        $03: Result := 'USB Controller';
      else
        Result := 'Serial Bus Controller';
      end;

    else
      Result := 'Unknown Device';
  end;
end;

function GetPciDeviceByIndex(Index: Integer): PPciDevice;
var
  Current: PPciDevice;
  I: Integer;
begin
  Current := PciDeviceList;
  I := 0;
  while (Current <> nil) and (I < Index) do
  begin
    Current := Current^.Next;
    Inc(I);
  end;
  Result := Current;
end;

function LookupDeviceName(VendorID, DeviceID: Word): PChar;
var
  i: Integer;
begin
  for i := 0 to High(KnownDevices) do
  begin
    if (KnownDevices[i].VendorID = VendorID) and
       (KnownDevices[i].DeviceID = DeviceID) then
       begin
        Result:= KnownDevices[i].DeviceName;
      Exit ;

      end;
  end;
  Result := 'Unknown Device';
end;

function LookupVendorName(VendorID: Word): PChar;
var
  i: Integer;
begin
  for i := 0 to High(KnownDevices) do
  begin
    if KnownDevices[i].VendorID = VendorID then
    begin
      Result:=KnownDevices[i].VendorName;
      Exit;
    end;
  end;
  Result := 'Unknown Vendor';
end;




procedure ShowAllDevices;
var
  I: Integer;
  DeviceName: PChar;

   Dev: PPciDevice;
begin
  Dev := PciDeviceList;
  while Dev <> nil do
  begin
      DeviceName := GetDeviceType(Dev^.ClassCode, Dev^.Subclass);

    {  Systems.ShowMessage('PCI Device #' + IntToStr(I) + #13#10 +
                          'VendorID: ' + HexStr(VendorID, 4) + #13#10 +
                          'DeviceID: ' + HexStr(DeviceID, 4) + #13#10 +
                          'Type: ' + DeviceName);
      }

    Dev := Dev^.Next;
  end;
end;


{

procedure ShowPCIDevices;
var
  Dev: PPciDevice;
begin
  Dev := PciDeviceList;
  while Dev <> nil do
  begin
    Messages.ShowMessage(
      'Bus=' + IntToStr(Dev^.Bus) +
      ' Dev=' + IntToStr(Dev^.Dev) +
      ' Func=' + IntToStr(Dev^.Func) +
      ' Vendor=$' + HexStr(Dev^.VendorID, 4) +
      ' Device=$' + HexStr(Dev^.DeviceID, 4) +
      ' Class=$' + HexStr(Dev^.ClassCode, 2) +
      ' Sub=$' + HexStr(Dev^.SubClass, 2)
    );
    Dev := Dev^.Next;
  end;
end;

}



procedure pci_init();
begin
  // Initialize size map
  ScanPCIDevices;
end;

end.

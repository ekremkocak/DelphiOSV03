Unit  Pit;

interface

  Uses
   SysUtils,Idt,Ports;



const
  ClockHz: LongWord = 1193180;

var
  TimerTicks: LongWord = 0;
  tick: LongWord = 0;

  procedure Pid_init();
  function GetTickCount(): LongWord;
  procedure Delay(Ticks: LongWord);

implementation

procedure init_timer(Hz: LongWord);
begin
  WritePortB($43, $36);
  WritePortB($40, (ClockHz div Hz) and $FF);
  WritePortB($40, (ClockHz div Hz) shr 8);
end;

procedure Timer_callback();
begin
  Inc(TimerTicks);
  Inc(tick);
end;

function GetTickCount():  LongWord;
begin
  Result := TimerTicks;
end;

procedure Delay(Ticks: LongWord);
begin
  Ticks := Ticks + TimerTicks;
  while Ticks > TimerTicks do
    ;
end;

procedure Pid_init();
begin

  RegisterISR(32, @Timer_callback);


  init_timer(100);  // Timer'� 100 Hz'e ayarla
end;


end.



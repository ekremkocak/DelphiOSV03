{ =========================================================
  Draw32.pas — Grafik Kütüphanesi
  
  İçerik:
  - Temel: Pixel, Line, Rect, Fill, Circle, Arc
  - Metin: Char, String, Centered, Clipped
  - 3D: Rect3D, Button3D, Panel3D, Groove
  - Gradient: H/V/Diagonal, Rainbow
  - Efekt: Granite, Marble, Wood, Metal, Glass
  - Clip: Region set/get, clipped draw
  - Alpha: Blend, Transparent fill
  - Image: BitBlt, StretchBlt, FlipH, FlipV, Rotate90
  - Shapes: Ellipse, Triangle, Polygon, RoundRect
  - Special: Shadow, Glow, Emboss, Blur
  ========================================================= }

Unit Draw32;

interface

 Uses
   SysUtils,Fat32,Memory,Vesa;


const
  SinTable: array[0..90] of Integer = (
    0,  174, 348, 523, 697, 871, 1045, 1218, 1391, 1564,
    1736, 1908, 2079, 2249, 2419, 2588, 2756, 2923, 3090, 3255,
    3420, 3583, 3746, 3907, 4067, 4226, 4383, 4539, 4694, 4848,
    5000, 5150, 5299, 5446, 5591, 5735, 5877, 6018, 6156, 6293,
    6427, 6560, 6691, 6819, 6946, 7071, 7193, 7313, 7431, 7547,
    7660, 7771, 7880, 7986, 8090, 8191, 8290, 8386, 8480, 8571,
    8660, 8746, 8829, 8910, 8987, 9063, 9135, 9205, 9271, 9335,
    9396, 9455, 9510, 9562, 9612, 9659, 9702, 9743, 9781, 9816,
    9848, 9876, 9902, 9925, 9945, 9961, 9975, 9986, 9993, 9998,
    10000
  );




const
  // Renkler (BGR format)
  clBlack   = $00000000;
  clWhite   = $00FFFFFF;
  clRed     = $000000FF;
  clGreen   = $0000FF00;
  clBlue    = $00FF0000;
  clYellow  = $0000FFFF;
  clCyan    = $00FFFF00;
  clMagenta = $00FF00FF;
  clGray    = $00808080;
  clSilver  = $00C0C0C0;
  clDkGray  = $00404040;
  clLtGray  = $00D0D0D0;
  clNavy    = $00800000;
  clMaroon  = $000000800;
  clOlive   = $00008080;
  clTeal    = $00808000;
  clBtnFace = $FFF0F0F0;

  // 3D Renkler
  cl3DLight    = $00E8E8E8;
  cl3DHighLight= $00FFFFFF;
  cl3DShadow   = $00808080;
  cl3DDkShadow = $00404040;
  cl3DFace     = $00D4D0C8;

//type
// PLongWord =^TLongWord;
// TLongWord = array[0..0] of LongWord;
 
 // PByteArray = ^TByteArray;
 // TByteArray = array[0..$FFFFFF] of Byte;


type
  TClipRect = record
    X1, Y1, X2, Y2: Integer;
    Active: Boolean;
  end;
  

  TPoint = record
    X, Y: Integer;
  end;
  PPoint = array[0..0] of TPoint;
  

 type
  TDrawSurface = record
    Buffer:       PByteArray;       // PLongWordArray yerine PByte (Byte bazl� adresleme i�in)
    Width:        Integer;
    Height:       Integer;
    Pitch:        Integer;     // Byte �ok k���kt�, sat�r geni�li�i i�in Integer olmal�
    BitsPerPixel: Integer;     // 24 veya 32 de�erini tutacak
    Clip:         TClipRect;
  end;


var
  // Global çizim yüzeyi (screen buffer)
  Surface:   TDrawSurface;
  ClipRegion: TClipRect;
  ClipSaveX1, ClipSaveY1, ClipSaveX2, ClipSaveY2: Integer;
  ClipSaved: Boolean = False;

//=============================================================================
// Temel API
//=============================================================================

// Init
procedure Draw32_Init(ABuffer: Pointer; W, H: Integer; ABitsPerPixel: Integer); stdcall; 

// Clip
//procedure Clip_SetWindow(W: PWindow);
procedure Clip_Set(X1, Y1, X2, Y2: Integer); stdcall; 
procedure Clip_Clear;stdcall;  
function  Clip_Check(X, Y: Integer): Boolean;  stdcall; 

// Pixel
procedure PutPixel(X, Y: Integer; Color: LongWord);  stdcall; 
function  GetPixel(X, Y: Integer): LongWord; stdcall;  

// Line
procedure KLine(X1, Y1, X2, Y2: Integer; Color: LongWord);  stdcall; 
procedure KLineH(X, Y, W: Integer; Color: LongWord);  stdcall; 
procedure KLineV(X, Y, H: Integer; Color: LongWord);  stdcall; 
procedure KLineDashed(X1, Y1, X2, Y2: Integer; Color: LongWord; DashLen: Integer);  stdcall; 





// Rectangle
procedure KRect(X, Y, W, H: Integer; Color: LongWord); stdcall;
procedure KFill(X, Y, W, H: Integer; Color: LongWord);  stdcall; 
procedure KRoundRect(X, Y, W, H, Radius: Integer; BorderColor, FillColor: LongWord); stdcall;
procedure K3D(x, y, w, h: Integer; pressed: Boolean); stdcall; 

// Circle / Ellipse / Arc
procedure KCircle(CX, CY, R: Integer; Color: LongWord);  stdcall;
procedure KFillCircle(CX, CY, R: Integer; Color: LongWord);  stdcall; 
procedure KEllipse(CX, CY, RX, RY: Integer; Color: LongWord);  stdcall; 
procedure KFillEllipse(CX, CY, RX, RY: Integer; Color: LongWord);  stdcall; 
procedure KArc(CX, CY, R, StartAngle, EndAngle: Integer; Color: LongWord);  stdcall; overload;
procedure KArc(cx, cy, r: Integer; c: LongWord);  stdcall;   overload;
procedure KPie(CX, CY, R, StartAngle, EndAngle: Integer; Color: LongWord);  stdcall; 

// Triangle / Polygon
procedure KTriangle(X1, Y1, X2, Y2, X3, Y3: Integer; Color: LongWord);  stdcall; 
procedure KFillTriangle(X1, Y1, X2, Y2, X3, Y3: Integer; Color: LongWord);  stdcall; 
procedure KPolygon(Points: PPoint; Count: Integer; Color: LongWord);  stdcall; 

// Text
procedure KChar(X, Y: Integer; Ch: Char; Color: LongWord);  stdcall; 
procedure KStr(X, Y: Integer; S: PChar; Color: LongWord);  stdcall;
procedure KStrClip(x, y: Integer; s: PChar; c: LongWord;
                   ClipX, ClipY, ClipW, ClipH: Integer);  stdcall;
procedure KStrClipped(X, Y, MaxW: Integer; S: PChar; Color: LongWord);  stdcall; 
procedure KStrCentered(X, Y, W: Integer; S: PChar; Color: LongWord);  stdcall; 
procedure KStrRight(X, Y, W: Integer; S: PChar; Color: LongWord);  stdcall; 
procedure KStrShadow(X, Y: Integer; S: PChar; Color, ShadowColor: LongWord);  stdcall; 
procedure KStrOutlined(X, Y: Integer; S: PChar; Color, OutlineColor: LongWord);  stdcall; 

// 3D Effects
procedure KRect3D(X, Y, W, H: Integer; Raised: Boolean);stdcall;
procedure KButton3DEx(X, Y, W, H: Integer; Pressed, Hover: Boolean; FillColor: LongWord); stdcall;
procedure KButton3D(X, Y, W, H: Integer; Pressed: Boolean; FillColor: LongWord);  stdcall;
procedure KButton3DDisabled(X, Y, W, H: Integer; FillColor: LongWord); stdcall;
procedure KPanel3D(X, Y, W, H: Integer; Raised: Boolean; FillColor: LongWord);  stdcall;  
procedure KGroove(X, Y, W, H: Integer);  stdcall;  
procedure KBevel(X, Y, W, H, BevelW: Integer; Raised: Boolean);  stdcall;  
procedure KEdge(X, Y, W, H: Integer; EdgeType: Integer);  stdcall;  
procedure KTitleBar(X, Y, W, H: Integer; Active: Boolean; Title: PChar);  stdcall;  
procedure KSunken(X, Y, W, H: Integer; FillColor: LongWord);  stdcall;

// Gradient
procedure KGradientH(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall; 
procedure KGradientV(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall; 
procedure KGradientD(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall; 
procedure KGradientRadial(CX, CY, R: Integer; InnerColor, OuterColor: LongWord);  stdcall; 
procedure KRainbow(X, Y, W, H: Integer); stdcall; 

// Texture / Pattern
procedure KGranite(X, Y, W, H: Integer; BaseColor: LongWord; Density: Integer); stdcall; 
procedure KMarble(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall; 
procedure KWood(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall; 
procedure KMetal(X, Y, W, H: Integer; BaseColor: LongWord);  stdcall; 
procedure KChecker(X, Y, W, H, TileSize: Integer; Color1, Color2: LongWord);  stdcall; 
procedure KDots(X, Y, W, H, Spacing: Integer; Color: LongWord);  stdcall;
procedure KHatch(X, Y, W, H, Spacing: Integer; Color: LongWord);  stdcall; 
procedure KCrossHatch(X, Y, W, H, Spacing: Integer; Color: LongWord);  stdcall;

// Alpha / Blend
procedure KFillAlpha(X, Y, W, H: Integer; Color: LongWord; Alpha: Byte);stdcall; 
procedure KBlendPixel(X, Y: Integer; Color: LongWord; Alpha: Byte);  stdcall; 
procedure KLineAlpha(X1, Y1, X2, Y2: Integer; Color: LongWord; Alpha: Byte);stdcall;

// Special Effects
procedure KShadowRect(X, Y, W, H, ShadowSize: Integer; FillColor: LongWord);  stdcall; 
procedure KGlowRect(X, Y, W, H, GlowSize: Integer; GlowColor: LongWord);  stdcall; 
procedure KEmboss(X, Y, W, H: Integer); stdcall;
procedure KBlurRect(X, Y, W, H: Integer; Passes: Integer); stdcall;  
procedure KInvert(X, Y, W, H: Integer); stdcall; 
procedure KGrayscale(X, Y, W, H: Integer); stdcall; 

// Image ops
procedure KBitBlt(DstX, DstY, W, H: Integer; Src: PLongWordArray; SrcW, SrcX, SrcY: Integer); stdcall;  
procedure KStretchBlt(DstX, DstY, DstW, DstH: Integer;
                      Src: PLongWordArray; SrcW, SrcH: Integer); stdcall; 
procedure KTransBlt(DstX, DstY, W, H: Integer; Src: PLongWordArray;
                    SrcW, SrcX, SrcY: Integer; TransColor: LongWord);  stdcall; 
procedure KFlipH(X, Y, W, H: Integer); stdcall; 
procedure KFlipV(X, Y, W, H: Integer); stdcall; 

// Color helpers
function  RGB(R, G, B: Byte): LongWord;stdcall; 
function  RGBA(R, G, B, A: Byte): LongWord; stdcall;
function  ColorR(C: LongWord): Byte;stdcall; 
function  ColorG(C: LongWord): Byte; stdcall; 
function  ColorB(C: LongWord): Byte; stdcall; 
function  ColorBlend(C1, C2: LongWord; T: Byte): LongWord; stdcall;
function  ColorDarken(C: LongWord; Pct: Integer): LongWord; stdcall; 
function  ColorLighten(C: LongWord; Pct: Integer): LongWord; stdcall;  
function  ColorToGray(C: LongWord): LongWord; stdcall;

function Sin_Int(Deg: Integer): Integer;
function Cos_Int(Deg: Integer): Integer;

procedure Clip_Save;
procedure Clip_Restore;

implementation

//Uses KernelUI;

//=============================================================================
// Init
//=============================================================================

procedure Draw32_Init(ABuffer: Pointer; W, H: Integer; ABitsPerPixel: Integer); stdcall;
begin
  Surface.Buffer       := PByteArray(ABuffer); // Gelen adresi byte i�aret�isine d�n��t�r
  Surface.Width        := W;
  Surface.Height       := H;
  Surface.BitsPerPixel := ABitsPerPixel;  // 24 veya 32

  // Pitch (Stride) Hesaplama: 
  // E�er sistem otomatik hizalama yapm�yorsa: Geni�lik * Piksel Ba��na Byte Say�s�
  // �rn: 800 px geni�lik ve 24-bit i�in -> 800 * 3 = 2400 byte (Art�k Byte tipine s��mazd�)
  Surface.Pitch        := W * (ABitsPerPixel div 8);
  
  Clip_Clear;
end;


procedure Clip_Save;
begin
  // Mevcut clip de�erlerini sakla
  ClipSaveX1 := ClipRegion.X1;
  ClipSaveY1 := ClipRegion.Y1;
  ClipSaveX2 := ClipRegion.X2;
  ClipSaveY2 := ClipRegion.Y2;
  ClipSaved  := True;
end;

procedure Clip_Restore;
begin
  if ClipSaved then
    Clip_Set(ClipSaveX1, ClipSaveY1, ClipSaveX2, ClipSaveY2)
  else
    Clip_Clear;
  ClipSaved := False;
end;


function Sin_Int(Deg: Integer): Integer;
begin
  Deg := Deg mod 360;
  if Deg < 0 then Inc(Deg, 360);
  if Deg <= 90  then Result :=  SinTable[Deg]
  else if Deg <= 180 then Result :=  SinTable[180 - Deg]
  else if Deg <= 270 then Result := -SinTable[Deg - 180]
  else                    Result := -SinTable[360 - Deg];
end;

function Cos_Int(Deg: Integer): Integer;
begin
  Result := Sin_Int(Deg + 90);
end;

function Round(const x: Single): LongInt; assembler;
asm
    fld x
    fistp Result
end;


//=============================================================================
// Color Helpers
//=============================================================================

function RGB(R, G, B: Byte): LongWord; stdcall;
begin
  Result := LongWord(B) or (LongWord(G) shl 8) or (LongWord(R) shl 16);
end;

function RGBA(R, G, B, A: Byte): LongWord; stdcall;
begin
  Result := LongWord(B) or (LongWord(G) shl 8) or
            (LongWord(R) shl 16) or (LongWord(A) shl 24);
end;

function ColorR(C: LongWord): Byte; stdcall;
begin
  Result := Byte((C shr 16) and $FF);
end;

function ColorG(C: LongWord): Byte; stdcall;
begin
  Result := Byte((C shr 8) and $FF);
end;

function ColorB(C: LongWord): Byte; stdcall;
begin
  Result := Byte(C and $FF);
end;

function ColorBlend(C1, C2: LongWord; T: Byte): LongWord; stdcall;
var
  r1, g1, b1: Byte;
  r2, g2, b2: Byte;
  r,  g,  b:  Byte;
begin
  r1 := ColorR(C1); g1 := ColorG(C1); b1 := ColorB(C1);
  r2 := ColorR(C2); g2 := ColorG(C2); b2 := ColorB(C2);
  r  := Byte((Word(r1) * (255 - T) + Word(r2) * T) div 255);
  g  := Byte((Word(g1) * (255 - T) + Word(g2) * T) div 255);
  b  := Byte((Word(b1) * (255 - T) + Word(b2) * T) div 255);
  Result := RGB(r, g, b);
end;

function ColorDarken(C: LongWord; Pct: Integer): LongWord; stdcall;
var
  r, g, b: Byte;
begin
  r := ColorR(C); g := ColorG(C); b := ColorB(C);
  r := Byte(Integer(r) * (100 - Pct) div 100);
  g := Byte(Integer(g) * (100 - Pct) div 100);
  b := Byte(Integer(b) * (100 - Pct) div 100);
  Result := RGB(r, g, b);
end;

function ColorLighten(C: LongWord; Pct: Integer): LongWord; stdcall;
var
  r, g, b: Word;
begin
  r := ColorR(C); g := ColorG(C); b := ColorB(C);
  r := r + Word((255 - r) * Pct div 100);
  g := g + Word((255 - g) * Pct div 100);
  b := b + Word((255 - b) * Pct div 100);
  if r > 255 then r := 255;
  if g > 255 then g := 255;
  if b > 255 then b := 255;
  Result := RGB(Byte(r), Byte(g), Byte(b));
end;

function ColorToGray(C: LongWord): LongWord; stdcall;
var
  gray: Byte;
begin
  gray := Byte((Integer(ColorR(C)) * 30 +
                Integer(ColorG(C)) * 59 +
                Integer(ColorB(C)) * 11) div 100);
  Result := RGB(gray, gray, gray);
end;

//=============================================================================
// Clip
//=============================================================================



procedure Clip_Set(X1, Y1, X2, Y2: Integer); stdcall;
begin
  ClipRegion.X1     := X1;
  ClipRegion.Y1     := Y1;
  ClipRegion.X2     := X2;
  ClipRegion.Y2     := Y2;
  ClipRegion.Active := True;
end;

procedure Clip_Clear;
begin
  ClipRegion.X1     := 0;
  ClipRegion.Y1     := 0;
  ClipRegion.X2     := Surface.Width  - 1;
  ClipRegion.Y2     := Surface.Height - 1;
  ClipRegion.Active := False;
end;

function Clip_Check(X, Y: Integer): Boolean; stdcall;
begin
  if ClipRegion.Active then
    Result := (X >= ClipRegion.X1) and (X <= ClipRegion.X2) and
              (Y >= ClipRegion.Y1) and (Y <= ClipRegion.Y2)
  else
    Result := (X >= 0) and (X < Surface.Width) and
              (Y >= 0) and (Y < Surface.Height);
end;

//=============================================================================
// Pixel
//=============================================================================

procedure PutPixel(X, Y: Integer; Color: LongWord); stdcall;
var
  PixelOffset: Integer;
  BytePtr: PByteArray;
begin
  if not Clip_Check(X, Y) then Exit;

  // Yeni Integer olan Pitch ve BitsPerPixel de�erlerini kullan�yoruz
  PixelOffset := (Y * Surface.Pitch) + (X * (Surface.BitsPerPixel div 8));
  BytePtr := PByteArray(@Surface.Buffer[PixelOffset]);

  case Surface.BitsPerPixel of
    24: 
      begin
        BytePtr[0] := Color and $FF;
        BytePtr[1] := (Color shr 8) and $FF;
        BytePtr[2] := (Color shr 16) and $FF;
      end;
    32: 
      begin
       // PLongWordArray(BytePtr)^ := Color;
      end;
  end;
end;


function GetPixel(X, Y: Integer): LongWord; stdcall;
var
  PixelOffset: Integer;
  BytePtr: PByteArray;
begin
  // 1. S�n�r kontrol� (K�rpma)
  if not Clip_Check(X, Y) then
  begin
    Result := 0; // E�er koordinat d���ndaysa siyah/saydam d�nd�r
    Exit;
  end;

  // 2. Pikselin ba�lang�� byte adresini hesapla
  PixelOffset := (Y * Surface.Pitch) + (X * (Surface.BitsPerPixel div 8));
  BytePtr := PByteArray(@Surface.Buffer[PixelOffset]);

  // 3. Bit derinli�ine g�re haf�zadan rengi oku
  case Surface.BitsPerPixel of
    24: // 3 Byte okuyup 32-bit LongWord i�ine birle�tiriyoruz
      begin
        // Haf�zadaki s�rayla (�rn: B, G, R) byte'lar� sola kayd�rarak (Shift) birle�tir
        Result := BytePtr[0] or          // 1. Byte (En d���k anlaml�)
                  (BytePtr[1] shl 8) or  // 2. Byte
                  (BytePtr[2] shl 16);   // 3. Byte
        
        // �stteki 4. byte (Alpha) otomatik olarak 0 ($00) olur.
      end;

    32: // 4 Byte (Do�rudan adresteki LongWord de�erini oku)
      begin
       // Result := PLongWordArray(BytePtr)^;
      end;
  else
    Result := 0; // Bilinmeyen bit derinli�i korumas�
  end;
end;
//=============================================================================
// Line (Bresenham)
//=============================================================================

procedure KLine(X1, Y1, X2, Y2: Integer; Color: LongWord);  stdcall;
var
  dx, dy: Integer;
  sx, sy: Integer;
  err:    Integer;
  e2:     Integer;
begin
  dx  := X2 - X1;  if dx < 0 then dx := -dx;
  dy  := Y2 - Y1;  if dy < 0 then dy := -dy;
  sx  := 1; if X1 > X2 then sx := -1;
  sy  := 1; if Y1 > Y2 then sy := -1;
  err := dx - dy;

  while True do
  begin
    PutPixel(X1, Y1, Color);
    if (X1 = X2) and (Y1 = Y2) then Break;
    e2 := 2 * err;
    if e2 > -dy then begin err := err - dy; X1 := X1 + sx; end;
    if e2 <  dx then begin err := err + dx; Y1 := Y1 + sy; end;
  end;
end;

procedure KLineH(X, Y, W: Integer; Color: LongWord);  stdcall;
var
  i: Integer;
begin
  i := 0;
  while i < W do
  begin
    PutPixel(X + i, Y, Color);
    Inc(i);
  end;
end;

procedure KLineV(X, Y, H: Integer; Color: LongWord);  stdcall;
var
  i: Integer;
begin
  i := 0;
  while i < H do
  begin
    PutPixel(X, Y + i, Color);
    Inc(i);
  end;
end;

procedure KLineDashed(X1, Y1, X2, Y2: Integer; Color: LongWord; DashLen: Integer); stdcall;
var
  dx, dy: Integer;
  sx, sy: Integer;
  err:    Integer;
  e2:     Integer;
  cnt:    Integer;
  draw:   Boolean;
begin
  dx  := X2 - X1;  if dx < 0 then dx := -dx;
  dy  := Y2 - Y1;  if dy < 0 then dy := -dy;
  sx  := 1; if X1 > X2 then sx := -1;
  sy  := 1; if Y1 > Y2 then sy := -1;
  err := dx - dy;
  cnt := 0;
  draw := True;

  while True do
  begin
    if draw then PutPixel(X1, Y1, Color);
    Inc(cnt);
    if cnt >= DashLen then begin cnt := 0; draw := not draw; end;
    if (X1 = X2) and (Y1 = Y2) then Break;
    e2 := 2 * err;
    if e2 > -dy then begin err := err - dy; X1 := X1 + sx; end;
    if e2 <  dx then begin err := err + dx; Y1 := Y1 + sy; end;
  end;
end;

//=============================================================================
// Rectangle
//=============================================================================

procedure K3D(x, y, w, h: Integer; pressed: Boolean); stdcall;
var c1, c2: LongWord;
begin
  if pressed then begin c1 := $00404040; c2 := $00FFFFFF; end
  else            begin c1 := $00FFFFFF; c2 := $00404040; end;

  KFill(x, y, w-1, 1, c1);
  KFill(x, y, 1, h-1, c1);
  KFill(x+w-1, y, 1, h, c2);
  KFill(x, y+h-1, w, 1, c2);
end;



procedure KRect(X, Y, W, H: Integer; Color: LongWord);  stdcall;
begin
  KLineH(X, Y,         W, Color);
  KLineH(X, Y + H - 1, W, Color);
  KLineV(X,         Y, H, Color);
  KLineV(X + W - 1, Y, H, Color);
end;




procedure KFill(X, Y, W, H: Integer; Color: LongWord);  stdcall; 
var
  row: Integer;
begin
  row := 0;
  while row < H do
  begin
    KLineH(X, Y + row, W, Color);
    Inc(row);
  end;
end;

procedure KRoundRect(X, Y, W, H, Radius: Integer; BorderColor, FillColor: LongWord);  stdcall;
var
  cx, cy: Integer;
  i:      Integer;
  r:      Integer;
  x0:     Integer;
  y0:     Integer;
begin
  r := Radius;
  if r > W div 2 then r := W div 2;
  if r > H div 2 then r := H div 2;

  // Fill
  if FillColor <> 0 then
  begin
    KFill(X + r, Y,     W - r*2, H,     FillColor);
    KFill(X,     Y + r, r,       H-r*2, FillColor);
    KFill(X+W-r, Y + r, r,       H-r*2, FillColor);
  end;

  // Edges
  KLineH(X+r, Y,         W-r*2, BorderColor);
  KLineH(X+r, Y + H - 1, W-r*2, BorderColor);
  KLineV(X,         Y+r, H-r*2, BorderColor);
  KLineV(X + W - 1, Y+r, H-r*2, BorderColor);

  // Corners (Midpoint circle)
  cx := X + r;       cy := Y + r;
  i := 0;
  while i <= r do
  begin
    x0 := Round(Sqrt(r*r - i*i));
    PutPixel(cx - x0, cy - i, BorderColor);
    PutPixel(cx + x0 - 1, cy - i, BorderColor);
    PutPixel(cx - x0, cy + i + H - r*2 - 1, BorderColor);
    PutPixel(cx + x0 - 1, cy + i + H - r*2 - 1, BorderColor);
    Inc(i);
  end;
end;

//=============================================================================
// Circle / Ellipse
//=============================================================================

procedure KCircle(CX, CY, R: Integer; Color: LongWord);  stdcall;
var
  x, y:  Integer;
  err:   Integer;
begin
  x   := R;
  y   := 0;
  err := 0;
  while x >= y do
  begin
    PutPixel(CX + x, CY + y, Color);
    PutPixel(CX + y, CY + x, Color);
    PutPixel(CX - y, CY + x, Color);
    PutPixel(CX - x, CY + y, Color);
    PutPixel(CX - x, CY - y, Color);
    PutPixel(CX - y, CY - x, Color);
    PutPixel(CX + y, CY - x, Color);
    PutPixel(CX + x, CY - y, Color);
    Inc(y);
    if err <= 0 then
      Inc(err, 2*y + 1)
    else
    begin
      Dec(x);
      Inc(err, 2*(y - x) + 1);
    end;
  end;
end;

procedure KFillCircle(CX, CY, R: Integer; Color: LongWord);  stdcall;
var
  x, y:  Integer;
  err:   Integer;
begin
  x   := R;
  y   := 0;
  err := 0;
  while x >= y do
  begin
    KLineH(CX - x, CY + y, x*2, Color);
    KLineH(CX - x, CY - y, x*2, Color);
    KLineH(CX - y, CY + x, y*2, Color);
    KLineH(CX - y, CY - x, y*2, Color);
    Inc(y);
    if err <= 0 then
      Inc(err, 2*y + 1)
    else
    begin
      Dec(x);
      Inc(err, 2*(y - x) + 1);
    end;
  end;
end;

procedure KEllipse(CX, CY, RX, RY: Integer; Color: LongWord);  stdcall;
var
  x, y:   Integer;
  rx2:    LongInt;
  ry2:    LongInt;
  fx2:    LongInt;
  fy2:    LongInt;
  err:    LongInt;
begin
  x   := -RX;
  y   := 0;
  rx2 := LongInt(RX) * RX;
  ry2 := LongInt(RY) * RY;
  err := LongInt(2) * rx2 + ry2 * (1 - 2*RX);
  while True do
  begin
    PutPixel(CX - x, CY + y, Color);
    PutPixel(CX + x, CY + y, Color);
    PutPixel(CX + x, CY - y, Color);
    PutPixel(CX - x, CY - y, Color);
    fx2 := LongInt(2) * x * ry2;
    fy2 := LongInt(2) * y * rx2;
    if err < 0 then
    begin
      Inc(y);
      Inc(err, fy2 + rx2);
    end
    else if err > 0 then
    begin
      Inc(x);
      Inc(err, fx2 + ry2);
    end
    else
    begin
      Inc(y); Inc(x);
      Inc(err, fx2 + fy2);
    end;
    if x > 0 then Break;
  end;
  // Fill top/bottom
  while y < RY do
  begin
    Inc(y);
    PutPixel(CX, CY + y, Color);
    PutPixel(CX, CY - y, Color);
  end;
end;

procedure KFillEllipse(CX, CY, RX, RY: Integer; Color: LongWord);  stdcall;
var
  y:   Integer;
  xw:  Integer;
begin
  y := -RY;
  while y <= RY do
  begin
    xw := Integer(Round(Sqrt(LongInt(RX)*RX - LongInt(RX)*RX*y*y div (LongInt(RY)*RY + 1))));
    KLineH(CX - xw, CY + y, xw*2, Color);
    Inc(y);
  end;
end;


procedure KArc(cx, cy, r: Integer; c: LongWord);  stdcall;   overload;
var
  x, y: Integer;
  d: Integer;
begin
  x := 0;
  y := r;
  d := 3 - 2 * r;
  
  while x <= y do
  begin
    // 8-point symmetry
    if (cx + x >= 0) and (cx + x < SCREEN_WIDTH) and
       (cy + y >= 0) and (cy + y < SCREEN_HEIGHT) then
      PutPixel(cx + x, cy + y, c);
    
    if (cx - x >= 0) and (cx - x < SCREEN_WIDTH) and
       (cy + y >= 0) and (cy + y < SCREEN_HEIGHT) then
      PutPixel(cx - x, cy + y, c);
    
    if (cx + x >= 0) and (cx + x < SCREEN_WIDTH) and
       (cy - y >= 0) and (cy - y < SCREEN_HEIGHT) then
      PutPixel(cx + x, cy - y, c);
    
    if (cx - x >= 0) and (cx - x < SCREEN_WIDTH) and
       (cy - y >= 0) and (cy - y < SCREEN_HEIGHT) then
      PutPixel(cx - x, cy - y, c);
    
    if (cx + y >= 0) and (cx + y < SCREEN_WIDTH) and
       (cy + x >= 0) and (cy + x < SCREEN_HEIGHT) then
      PutPixel(cx + y, cy + x, c);
    
    if (cx - y >= 0) and (cx - y < SCREEN_WIDTH) and
       (cy + x >= 0) and (cy + x < SCREEN_HEIGHT) then
      PutPixel(cx - y, cy + x, c);
    
    if (cx + y >= 0) and (cx + y < SCREEN_WIDTH) and
       (cy - x >= 0) and (cy - x < SCREEN_HEIGHT) then
      PutPixel(cx + y, cy - x, c);
    
    if (cx - y >= 0) and (cx - y < SCREEN_WIDTH) and
       (cy - x >= 0) and (cy - x < SCREEN_HEIGHT) then
      PutPixel(cx - y, cy - x, c);
    
    if d < 0 then
      d := d + 4 * x + 6
    else
    begin
      d := d + 4 * (x - y) + 10;
      Dec(y);
    end;
    
    Inc(x);
  end;
end;

procedure KArc(CX, CY, R, StartAngle, EndAngle: Integer; Color: LongWord); stdcall;   overload;
var
  a:    Integer;
  x, y: Integer;
  sa, ea: Integer;
begin
  sa := StartAngle;
  ea := EndAngle;
  if ea < sa then Inc(ea, 360);
  a := sa;
  while a <= ea do
  begin
    x := CX + Integer(Round(R * Cos_Int(a)));
    y := CY + Integer(Round(R * Sin_Int(a)));
    PutPixel(x, y, Color);
    Inc(a);
  end;
end;

procedure KPie(CX, CY, R, StartAngle, EndAngle: Integer; Color: LongWord);  stdcall;
var
  a:    Integer;
  x, y: Integer;
  sa, ea: Integer;
begin
  sa := StartAngle;
  ea := EndAngle;
  if ea < sa then Inc(ea, 360);
  a := sa;
  while a <= ea do
  begin
    x := CX + Integer(Round(R * Cos_Int(a)));
    y := CY + Integer(Round(R * Sin_Int(a)));
    KLine(CX, CY, x, y, Color);
    Inc(a);
  end;
end;

//=============================================================================
// Triangle / Polygon
//=============================================================================

procedure KTriangle(X1, Y1, X2, Y2, X3, Y3: Integer; Color: LongWord);  stdcall;
begin
  KLine(X1, Y1, X2, Y2, Color);
  KLine(X2, Y2, X3, Y3, Color);
  KLine(X3, Y3, X1, Y1, Color);
end;

procedure KFillTriangle(X1, Y1, X2, Y2, X3, Y3: Integer; Color: LongWord);  stdcall;
var
  minY, maxY: Integer;
  y:          Integer;
  xA, xB:     Integer;
  tmp:        Integer;
begin
  // Sort by Y
  if Y1 > Y2 then begin tmp:=X1;X1:=X2;X2:=tmp; tmp:=Y1;Y1:=Y2;Y2:=tmp; end;
  if Y1 > Y3 then begin tmp:=X1;X1:=X3;X3:=tmp; tmp:=Y1;Y1:=Y3;Y3:=tmp; end;
  if Y2 > Y3 then begin tmp:=X2;X2:=X3;X3:=tmp; tmp:=Y2;Y2:=Y3;Y3:=tmp; end;

  minY := Y1;
  maxY := Y3;

  y := minY;
  while y <= maxY do
  begin
    // Scanline intersection
    if y < Y2 then
    begin
      if Y2 > Y1 then xA := X1 + (X2 - X1) * (y - Y1) div (Y2 - Y1) else xA := X1;
      if Y3 > Y1 then xB := X1 + (X3 - X1) * (y - Y1) div (Y3 - Y1) else xB := X1;
    end
    else
    begin
      if Y3 > Y2 then xA := X2 + (X3 - X2) * (y - Y2) div (Y3 - Y2) else xA := X2;
      if Y3 > Y1 then xB := X1 + (X3 - X1) * (y - Y1) div (Y3 - Y1) else xB := X1;
    end;

    if xA > xB then begin tmp := xA; xA := xB; xB := tmp; end;
    KLineH(xA, y, xB - xA + 1, Color);
    Inc(y);
  end;
end;

procedure KPolygon(Points: PPoint; Count: Integer; Color: LongWord);  stdcall;
var
  i: Integer;
begin
  if Count < 2 then Exit;
  i := 0;
  while i < Count - 1 do
  begin
    KLine(Points[i].X, Points[i].Y, Points[i+1].X, Points[i+1].Y, Color);
    Inc(i);
  end;
  KLine(Points[Count-1].X, Points[Count-1].Y, Points[0].X, Points[0].Y, Color);
end;

//=============================================================================
// Text (8x16 bitmap font placeholder)
//=============================================================================

procedure KChar(X, Y: Integer; Ch: Char; Color: LongWord);  stdcall;
var
  I:   Integer;
  J:   Integer;
  CharBitmap: PCharBitmap;
begin


  CharBitmap := PCharBitmap(CharSetOrigin + Integer(ch) shl 3);

  for i := 0 to 7 do
    for j := 0 to 7 do
      if (CharBitmap^[i] and (1 shl j)) <> 0 then
      begin
        PutPixel(X + 7 - j, Y + i, Color);
      end;

end;

procedure KStr(X, Y: Integer; S: PChar; Color: LongWord);  stdcall;
var
  i: Integer;
begin
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    KChar(X + i * 8, Y, S[i], Color);
    Inc(i);
  end;
end;

procedure KStrClip(x, y: Integer; s: PChar; c: LongWord;
                   ClipX, ClipY, ClipW, ClipH: Integer);  stdcall;
var i, cx: Integer;
begin
  i := 0;
  while s[i] <> #0 do
  begin
    cx := x + i*8;
    // Karakter clip içinde mi?
    if (cx + 8 > ClipX) and (cx < ClipX + ClipW) and
       (y + 8 > ClipY) and (y < ClipY + ClipH) then
      KChar(cx, y, (s[i]), c);
    Inc(i);
  end;
end;


procedure KStrClipped(X, Y, MaxW: Integer; S: PChar; Color: LongWord);  stdcall;
var
  i:    Integer;
  dots: Boolean;
  buf:  array[0..63] of Char;
  len:  Integer;
  maxC: Integer;
begin
  if S = nil then Exit;

  len  := 0;
  while S[len] <> #0 do Inc(len);

  maxC := MaxW div 8;
  dots := (len > maxC) and (maxC > 3);

  i := 0;
  while (S[i] <> #0) and (i < maxC - (3 * Ord(dots))) do
  begin
    buf[i] := S[i];
    Inc(i);
  end;

  if dots then
  begin
    buf[i] := '.'; Inc(i);
    buf[i] := '.'; Inc(i);
    buf[i] := '.'; Inc(i);
  end;
  buf[i] := #0;

  KStr(X, Y, @buf[0], Color);
end;

procedure KStrCentered(X, Y, W: Integer; S: PChar; Color: LongWord);  stdcall;
var
  len: Integer;
  tx:  Integer;
begin
  if S = nil then Exit;
  len := 0;
  while S[len] <> #0 do Inc(len);
  tx := X + (W - len * 8) div 2;
  KStr(tx, Y, S, Color);
end;

procedure KStrRight(X, Y, W: Integer; S: PChar; Color: LongWord);  stdcall;
var
  len: Integer;
  tx:  Integer;
begin
  if S = nil then Exit;
  len := 0;
  while S[len] <> #0 do Inc(len);
  tx := X + W - len * 8;
  KStr(tx, Y, S, Color);
end;

procedure KStrShadow(X, Y: Integer; S: PChar; Color, ShadowColor: LongWord);  stdcall;
begin
  KStr(X + 1, Y + 1, S, ShadowColor);
  KStr(X,     Y,     S, Color);
end;

procedure KStrOutlined(X, Y: Integer; S: PChar; Color, OutlineColor: LongWord);  stdcall;
begin
  KStr(X-1, Y-1, S, OutlineColor);
  KStr(X+1, Y-1, S, OutlineColor);
  KStr(X-1, Y+1, S, OutlineColor);
  KStr(X+1, Y+1, S, OutlineColor);
  KStr(X,   Y,   S, Color);
end;

//=============================================================================
// 3D Effects
//=============================================================================

procedure KRect3D(X, Y, W, H: Integer; Raised: Boolean); stdcall;
var
  topLeft:     LongWord;
  bottomRight: LongWord;
begin
  if Raised then
  begin
    topLeft     := cl3DHighLight;
    bottomRight := cl3DDkShadow;
  end
  else
  begin
    topLeft     := cl3DDkShadow;
    bottomRight := cl3DHighLight;
  end;

  KLineH(X,     Y,         W,     topLeft);
  KLineH(X,     Y + H - 1, W,     bottomRight);
  KLineV(X,     Y,         H,     topLeft);
  KLineV(X+W-1, Y,         H,     bottomRight);
end;


{ Yeni: Hover'li versiyon }
procedure KButton3DEx(X, Y, W, H: Integer; Pressed, Hover: Boolean; FillColor: LongWord); stdcall;
begin
  KFill(X, Y, W, H, FillColor);

  if Pressed then
  begin
    { Basili (sunken) }
    KLineH(X,     Y,         W, cl3DDkShadow);
    KLineH(X,     Y + H - 1, W, cl3DHighLight);
    KLineV(X,     Y,         H, cl3DDkShadow);
    KLineV(X+W-1, Y,         H, cl3DHighLight);
    KLineH(X+1,   Y+1,     W-2, cl3DShadow);
    KLineV(X+1,   Y+1,     H-2, cl3DShadow);
  end
  else
  begin
    { Normal (raised) }
    KLineH(X,     Y,         W, cl3DHighLight);
    KLineH(X,     Y + H - 1, W, cl3DDkShadow);
    KLineV(X,     Y,         H, cl3DHighLight);
    KLineV(X+W-1, Y,         H, cl3DDkShadow);
    KLineH(X+1,   Y+1,     W-2, cl3DLight);
    KLineV(X+1,   Y+1,     H-2, cl3DLight);
    KLineH(X+1,   Y+H-2,   W-2, cl3DShadow);
    KLineV(X+W-2, Y+1,     H-2, cl3DShadow);

    { === HOVER EFEKTI === }
    if Hover and (W > 4) and (H > 4) then
    begin
      { Ic kisimda hafif mavi parlama � "hot tracking" }
      KLineH(X+2, Y+2,     W-4, $00D0E8FF);
      KLineV(X+2, Y+2,     H-4, $00D0E8FF);
      KLineH(X+2, Y+H-3,   W-4, $00A0C8F0);
      KLineV(X+W-3, Y+2,   H-4, $00A0C8F0);
    end;
  end;
end;



procedure KButton3D(X, Y, W, H: Integer; Pressed: Boolean; FillColor: LongWord);  stdcall;
begin
  KFill(X, Y, W, H, FillColor);

  if Pressed then
  begin
    KLineH(X,     Y,         W, cl3DDkShadow);
    KLineH(X,     Y + H - 1, W, cl3DHighLight);
    KLineV(X,     Y,         H, cl3DDkShadow);
    KLineV(X+W-1, Y,         H, cl3DHighLight);
    KLineH(X+1,   Y+1,     W-2, cl3DShadow);
    KLineV(X+1,   Y+1,     H-2, cl3DShadow);
  end
  else
  begin
    KLineH(X,     Y,         W, cl3DHighLight);
    KLineH(X,     Y + H - 1, W, cl3DDkShadow);
    KLineV(X,     Y,         H, cl3DHighLight);
    KLineV(X+W-1, Y,         H, cl3DDkShadow);
    KLineH(X+1,   Y+1,     W-2, cl3DLight);
    KLineV(X+1,   Y+1,     H-2, cl3DLight);
    KLineH(X+1,   Y+H-2,   W-2, cl3DShadow);
    KLineV(X+W-2, Y+1,     H-2, cl3DShadow);
  end;
end;

procedure KButton3DDisabled(X, Y, W, H: Integer; FillColor: LongWord);
begin
  // Solgun arka plan (orijinal rengi solukla�t�r veya sabit soluk renk)
  KFill(X, Y, W, H, $00E8E8E8);
  
  // Soluk 3D efekt - bas�k/kapal� g�r�n�m
  KLineH(X,     Y,         W, $00C0C0C0); // �st g�lge
  KLineH(X,     Y + H - 1, W, $00C0C0C0); // Alt g�lge
  KLineV(X,     Y,         H, $00C0C0C0); // Sol g�lge
  KLineV(X+W-1, Y,         H, $00C0C0C0); // Sa� g�lge
  
  // �� �er�eve
  KLineH(X+1,   Y+1,     W-2, $00D4D4D4);
  KLineV(X+1,   Y+1,     H-2, $00D4D4D4);
end;

procedure KButton3DDisabled1(X, Y, W, H: Integer; FillColor: LongWord);
begin
  { Solgun arka plan � orijinal rengi kullanmak istersen 
    FillColor'u %50 gri ile karistirabilirsin, burada sabit soluk ton kullandim }
  KFill(X, Y, W, H, $00E8E8E8);

  { Duz, soluk tek-ton kenarlik � 3D highlight/shadow yok, 
    buton "devre disi" hissiyatli }
  KRect(X, Y, W, H, $00B0B0B0);

  { Hafif ic basiklik (etkisiz ama derinlik hissi) }
  KLineH(X + 1, Y + 1,     W - 2, $00D0D0D0);
  KLineV(X + 1, Y + 1,     H - 2, $00D0D0D0);
  KLineH(X + 1, Y + H - 2, W - 2, $00D0D0D0);
  KLineV(X + W - 2, Y + 1, H - 2, $00D0D0D0);
end;

procedure KPanel3D(X, Y, W, H: Integer; Raised: Boolean; FillColor: LongWord);  stdcall;
begin
  KFill(X+2, Y+2, W-4, H-4, FillColor);
  KRect3D(X,   Y,   W,   H,   Raised);
  KRect3D(X+1, Y+1, W-2, H-2, not Raised);
end;

procedure KGroove(X, Y, W, H: Integer); stdcall;
begin
  KLineH(X, Y,     W, cl3DShadow);
  KLineH(X, Y + 1, W, cl3DHighLight);
  KLineV(X,     Y, H, cl3DShadow);
  KLineV(X + 1, Y, H, cl3DHighLight);
  KLineH(X, Y + H - 2, W, cl3DShadow);
  KLineH(X, Y + H - 1, W, cl3DHighLight);
  KLineV(X + W - 2, Y, H, cl3DShadow);
  KLineV(X + W - 1, Y, H, cl3DHighLight);
end;

procedure KBevel(X, Y, W, H, BevelW: Integer; Raised: Boolean); stdcall;
var
  i:  Integer;
  c1: LongWord;
  c2: LongWord;
begin
  i := 0;
  while i < BevelW do
  begin
    if Raised then begin c1 := cl3DHighLight; c2 := cl3DDkShadow; end
    else           begin c1 := cl3DDkShadow;  c2 := cl3DHighLight; end;

    KLineH(X+i,   Y+i,       W-i*2, c1);
    KLineH(X+i,   Y+H-1-i,   W-i*2, c2);
    KLineV(X+i,   Y+i,       H-i*2, c1);
    KLineV(X+W-1-i, Y+i,     H-i*2, c2);
    Inc(i);
  end;
end;

procedure KEdge(X, Y, W, H: Integer; EdgeType: Integer); stdcall;
begin
  case EdgeType of
    0: KBevel(X, Y, W, H, 1, True);   // Raised
    1: KBevel(X, Y, W, H, 1, False);  // Sunken
    2: KGroove(X, Y, W, H);           // Groove
    3:                                 // Flat border
    begin
      KRect(X, Y, W, H, cl3DShadow);
    end;
  end;
end;

procedure KTitleBar(X, Y, W, H: Integer; Active: Boolean; Title: PChar); stdcall;
var
  c1, c2: LongWord;
begin
  if Active then
  begin
    c1 := $00800000;   // Dark blue
    c2 := $00A86000;   // Mid blue
  end
  else
  begin
    c1 := $00808080;
    c2 := $00A0A0A0;
  end;

  KGradientH(X, Y, W, H, c1, c2);
  KStrShadow(X + 4, Y + (H - 16) div 2, Title,
             clWhite, ColorDarken(c1, 50));
end;

procedure KSunken(X, Y, W, H: Integer; FillColor: LongWord);  stdcall;
begin
  KFill(X+1, Y+1, W-2, H-2, FillColor);
  KLineH(X, Y,     W, cl3DDkShadow);
  KLineV(X, Y,     H, cl3DDkShadow);
  KLineH(X, Y+H-1, W, cl3DHighLight);
  KLineV(X+W-1, Y, H, cl3DHighLight);
end;

//=============================================================================
// Gradient
//=============================================================================

procedure KGradientH(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall;
var
  col: Integer;
  c:   LongWord;
  t:   Byte;
begin
  col := 0;
  while col < W do
  begin
    t := Byte(col * 255 div (W - 1));
    c := ColorBlend(Color1, Color2, t);
    KLineV(X + col, Y, H, c);
    Inc(col);
  end;
end;

procedure KGradientV(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall;
var
  row: Integer;
  c:   LongWord;
  t:   Byte;
begin
  row := 0;
  while row < H do
  begin
    t := Byte(row * 255 div (H - 1));
    c := ColorBlend(Color1, Color2, t);
    KLineH(X, Y + row, W, c);
    Inc(row);
  end;
end;

procedure KGradientD(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall;
var
  row: Integer;
  col: Integer;
  t:   Byte;
  c:   LongWord;
begin
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      t := Byte((row + col) * 255 div (W + H - 2));
      c := ColorBlend(Color1, Color2, t);
      PutPixel(X + col, Y + row, c);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KGradientRadial(CX, CY, R: Integer; InnerColor, OuterColor: LongWord);  stdcall;
var
  row: Integer;
  col: Integer;
  dx:  Integer;
  dy:  Integer;
  dist: Integer;
  t:   Byte;
  c:   LongWord;
begin
  row := CY - R;
  while row <= CY + R do
  begin
    col := CX - R;
    while col <= CX + R do
    begin
      dx   := col - CX;
      dy   := row - CY;
      dist := Integer(Round(Sqrt(dx*dx + dy*dy)));
      if dist <= R then
      begin
        t := Byte(dist * 255 div R);
        c := ColorBlend(InnerColor, OuterColor, t);
        PutPixel(col, row, c);
      end;
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KRainbow(X, Y, W, H: Integer); stdcall;
var
  col: Integer;
  t:   Integer;
  r:   Byte;
  g:   Byte;
  b:   Byte;
begin
  col := 0;
  while col < W do
  begin
    t := col * 360 div W;  // 0..359 derece

    if t < 60 then
    begin r := 255; g := Byte(t * 255 div 60); b := 0; end
    else if t < 120 then
    begin r := Byte((120 - t) * 255 div 60); g := 255; b := 0; end
    else if t < 180 then
    begin r := 0; g := 255; b := Byte((t - 120) * 255 div 60); end
    else if t < 240 then
    begin r := 0; g := Byte((240 - t) * 255 div 60); b := 255; end
    else if t < 300 then
    begin r := Byte((t - 240) * 255 div 60); g := 0; b := 255; end
    else
    begin r := 255; g := 0; b := Byte((360 - t) * 255 div 60); end;

    KLineV(X + col, Y, H, RGB(r, g, b));
    Inc(col);
  end;
end;

//=============================================================================
// Texture / Pattern
//=============================================================================

// Basit pseudo-random (LCG)
var
  RandSeed: LongWord = 12345;

function FastRand: LongWord;
begin
  RandSeed := RandSeed * 1664525 + 1013904223;
  Result   := RandSeed;
end;

function FastRandN(N: Integer): Integer;
begin
  Result := Integer(FastRand mod LongWord(N));
end;

procedure KGranite(X, Y, W, H: Integer; BaseColor: LongWord; Density: Integer); stdcall;
var
  row:   Integer;
  col:   Integer;
  noise: Integer;
  c:     LongWord;
  r, g, b: Byte;
begin
  RandSeed := 9999;
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      noise := FastRandN(Density * 2) - Density;
      r := ColorR(BaseColor);
      g := ColorG(BaseColor);
      b := ColorB(BaseColor);

      // Noise ekle, sınırla
      if Integer(r) + noise > 255 then r := 255
      else if Integer(r) + noise < 0 then r := 0
      else r := Byte(Integer(r) + noise);

      if Integer(g) + noise > 255 then g := 255
      else if Integer(g) + noise < 0 then g := 0
      else g := Byte(Integer(g) + noise);

      if Integer(b) + noise > 255 then b := 255
      else if Integer(b) + noise < 0 then b := 0
      else b := Byte(Integer(b) + noise);

      PutPixel(X + col, Y + row, RGB(r, g, b));
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KMarble(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall;
var
  row: Integer;
  col: Integer;
  v:   Integer;
  t:   Byte;
  c:   LongWord;
begin
  RandSeed := 42;
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      v := ((col + row) * 3 + FastRandN(20)) mod 64;
      if v > 32 then v := 64 - v;
      t := Byte(v * 8);
      c := ColorBlend(Color1, Color2, t);
      PutPixel(X + col, Y + row, c);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KWood(X, Y, W, H: Integer; Color1, Color2: LongWord);  stdcall;
var
  row: Integer;
  col: Integer;
  ring: Integer;
  t:   Byte;
  c:   LongWord;
  cx:  Integer;
  cy:  Integer;
  dx:  Integer;
  dy:  Integer;
begin
  cx := X + W div 2;
  cy := Y + H div 2;
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      dx   := (X + col - cx);
      dy   := (Y + row - cy) * 2;
      ring := (Integer(Round(Sqrt(dx*dx + dy*dy))) + FastRandN(3)) mod 12;
      if ring > 6 then ring := 12 - ring;
      t := Byte(ring * 42);
      c := ColorBlend(Color1, Color2, t);
      PutPixel(X + col, Y + row, c);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KMetal(X, Y, W, H: Integer; BaseColor: LongWord);  stdcall;
var
  row: Integer;
  t:   Byte;
  c:   LongWord;
  bright: LongWord;
begin
  bright := ColorLighten(BaseColor, 60);
  row    := 0;
  while row < H do
  begin
    t := Byte(Abs(row * 511 div H - 255));
    c := ColorBlend(BaseColor, bright, t);
    KLineH(X, Y + row, W, c);
    Inc(row);
  end;
end;

procedure KChecker(X, Y, W, H, TileSize: Integer; Color1, Color2: LongWord);  stdcall;
var
  row: Integer;
  col: Integer;
  c:   LongWord;
begin
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      if ((col div TileSize) + (row div TileSize)) mod 2 = 0 then
        c := Color1
      else
        c := Color2;
      PutPixel(X + col, Y + row, c);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KDots(X, Y, W, H, Spacing: Integer; Color: LongWord);  stdcall;
var
  row: Integer;
  col: Integer;
begin
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      PutPixel(X + col, Y + row, Color);
      Inc(col, Spacing);
    end;
    Inc(row, Spacing);
  end;
end;

procedure KHatch(X, Y, W, H, Spacing: Integer; Color: LongWord);  stdcall;
var
  i: Integer;
begin
  i := 0;
  while i < H do
  begin
    KLineH(X, Y + i, W, Color);
    Inc(i, Spacing);
  end;
end;

procedure KCrossHatch(X, Y, W, H, Spacing: Integer; Color: LongWord);  stdcall;
var
  i: Integer;
begin
  i := 0;
  while i < H do
  begin
    KLineH(X, Y + i, W, Color);
    Inc(i, Spacing);
  end;
  i := 0;
  while i < W do
  begin
    KLineV(X + i, Y, H, Color);
    Inc(i, Spacing);
  end;
end;

//=============================================================================
// Alpha Blend
//=============================================================================

procedure KBlendPixel(X, Y: Integer; Color: LongWord; Alpha: Byte); stdcall;
var
  dst: LongWord;
begin
  if Alpha = 255 then begin PutPixel(X, Y, Color); Exit; end;
  if Alpha = 0   then Exit;
  dst := GetPixel(X, Y);
  PutPixel(X, Y, ColorBlend(dst, Color, Alpha));
end;

procedure KFillAlpha(X, Y, W, H: Integer; Color: LongWord; Alpha: Byte); stdcall;
var
  row: Integer;
  col: Integer;
begin
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      KBlendPixel(X + col, Y + row, Color, Alpha);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KLineAlpha(X1, Y1, X2, Y2: Integer; Color: LongWord; Alpha: Byte); stdcall;
var
  dx, dy: Integer;
  sx, sy: Integer;
  err:    Integer;
  e2:     Integer;
begin
  dx  := X2 - X1;  if dx < 0 then dx := -dx;
  dy  := Y2 - Y1;  if dy < 0 then dy := -dy;
  sx  := 1; if X1 > X2 then sx := -1;
  sy  := 1; if Y1 > Y2 then sy := -1;
  err := dx - dy;
  while True do
  begin
    KBlendPixel(X1, Y1, Color, Alpha);
    if (X1 = X2) and (Y1 = Y2) then Break;
    e2 := 2 * err;
    if e2 > -dy then begin err := err - dy; X1 := X1 + sx; end;
    if e2 <  dx then begin err := err + dx; Y1 := Y1 + sy; end;
  end;
end;

//=============================================================================
// Special Effects
//=============================================================================

procedure KShadowRect(X, Y, W, H, ShadowSize: Integer; FillColor: LongWord);  stdcall;
var
  i: Integer;
begin
  // Shadow
  i := ShadowSize;
  while i > 0 do
  begin
    KFillAlpha(X + i, Y + i, W, H,
               clBlack, Byte(128 - i * (128 div ShadowSize)));
    Dec(i);
  end;
  KFill(X, Y, W, H, FillColor);
end;

procedure KGlowRect(X, Y, W, H, GlowSize: Integer; GlowColor: LongWord);  stdcall;
var
  i: Integer;
begin
  i := GlowSize;
  while i > 0 do
  begin
    KFillAlpha(X - i, Y - i, W + i*2, H + i*2,
               GlowColor, Byte(80 - i * (80 div GlowSize)));
    Dec(i);
  end;
end;

procedure KEmboss(X, Y, W, H: Integer); stdcall;
var
  row: Integer;
  col: Integer;
  c1:  LongWord;
  c2:  LongWord;
  gray1: Byte;
  gray2: Byte;
  diff:  Integer;
  out:   Byte;
begin
  row := 1;
  while row < H - 1 do
  begin
    col := 1;
    while col < W - 1 do
    begin
      c1 := GetPixel(X + col - 1, Y + row - 1);
      c2 := GetPixel(X + col + 1, Y + row + 1);
      gray1 := Byte((Integer(ColorR(c1)) + ColorG(c1) + ColorB(c1)) div 3);
      gray2 := Byte((Integer(ColorR(c2)) + ColorG(c2) + ColorB(c2)) div 3);
      diff := Integer(gray1) - Integer(gray2);
      if diff + 128 > 255 then out := 255
      else if diff + 128 < 0 then out := 0
      else out := Byte(diff + 128);
      PutPixel(X + col, Y + row, RGB(out, out, out));
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KBlurRect(X, Y, W, H: Integer; Passes: Integer); stdcall;
var
  pass: Integer;
  row:  Integer;
  col:  Integer;
  r, g, b: Integer;
  c:    LongWord;
begin
  pass := 0;
  while pass < Passes do
  begin
    row := Y + 1;
    while row < Y + H - 1 do
    begin
      col := X + 1;
      while col < X + W - 1 do
      begin
        r := 0; g := 0; b := 0;
        c := GetPixel(col-1, row-1); Inc(r, ColorR(c)); Inc(g, ColorG(c)); Inc(b, ColorB(c));
        c := GetPixel(col,   row-1); Inc(r, ColorR(c)); Inc(g, ColorG(c)); Inc(b, ColorB(c));
        c := GetPixel(col+1, row-1); Inc(r, ColorR(c)); Inc(g, ColorG(c)); Inc(b, ColorB(c));
        c := GetPixel(col-1, row);   Inc(r, ColorR(c)); Inc(g, ColorG(c)); Inc(b, ColorB(c));
        c := GetPixel(col,   row);   Inc(r, ColorR(c)); Inc(g, ColorG(c)); Inc(b, ColorB(c));
        c := GetPixel(col+1, row);   Inc(r, ColorR(c)); Inc(g, ColorG(c)); Inc(b, ColorB(c));
        c := GetPixel(col-1, row+1); Inc(r, ColorR(c)); Inc(g, ColorG(c)); Inc(b, ColorB(c));
        c := GetPixel(col,   row+1); Inc(r, ColorR(c)); Inc(g, ColorG(c)); Inc(b, ColorB(c));
        c := GetPixel(col+1, row+1); Inc(r, ColorR(c)); Inc(g, ColorG(c)); Inc(b, ColorB(c));
        PutPixel(col, row, RGB(Byte(r div 9), Byte(g div 9), Byte(b div 9)));
        Inc(col);
      end;
      Inc(row);
    end;
    Inc(pass);
  end;
end;

procedure KInvert(X, Y, W, H: Integer); stdcall;
var
  row: Integer;
  col: Integer;
  c:   LongWord;
begin
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      c := GetPixel(X + col, Y + row);
      PutPixel(X + col, Y + row, c xor $00FFFFFF);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KGrayscale(X, Y, W, H: Integer); stdcall;
var
  row: Integer;
  col: Integer;
begin
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      PutPixel(X + col, Y + row,
               ColorToGray(GetPixel(X + col, Y + row)));
      Inc(col);
    end;
    Inc(row);
  end;
end;

//=============================================================================
// Image Operations
//=============================================================================

procedure KBitBlt(DstX, DstY, W, H: Integer;
                  Src: PLongWordArray; SrcW, SrcX, SrcY: Integer); stdcall;
var
  row: Integer;
  col: Integer;
begin
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      PutPixel(DstX + col, DstY + row,
               Src[(SrcY + row) * SrcW + (SrcX + col)]);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KStretchBlt(DstX, DstY, DstW, DstH: Integer;
                      Src: PLongWordArray; SrcW, SrcH: Integer); stdcall;
var
  row: Integer;
  col: Integer;
  srcX: Integer;
  srcY: Integer;
begin
  row := 0;
  while row < DstH do
  begin
    srcY := row * SrcH div DstH;
    col  := 0;
    while col < DstW do
    begin
      srcX := col * SrcW div DstW;
      PutPixel(DstX + col, DstY + row,
               Src[srcY * SrcW + srcX]);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KTransBlt(DstX, DstY, W, H: Integer;
                    Src: PLongWordArray; SrcW, SrcX, SrcY: Integer;
                    TransColor: LongWord);  stdcall;
var
  row: Integer;
  col: Integer;
  c:   LongWord;
begin
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W do
    begin
      c := Src[(SrcY + row) * SrcW + (SrcX + col)];
      if c <> TransColor then
        PutPixel(DstX + col, DstY + row, c);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KFlipH(X, Y, W, H: Integer); stdcall;
var
  row: Integer;
  col: Integer;
  c1:  LongWord;
  c2:  LongWord;
begin
  row := 0;
  while row < H do
  begin
    col := 0;
    while col < W div 2 do
    begin
      c1 := GetPixel(X + col,         Y + row);
      c2 := GetPixel(X + W - 1 - col, Y + row);
      PutPixel(X + col,         Y + row, c2);
      PutPixel(X + W - 1 - col, Y + row, c1);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure KFlipV(X, Y, W, H: Integer); stdcall;
var
  row: Integer;
  col: Integer;
  c1:  LongWord;
  c2:  LongWord;
begin
  col := 0;
  while col < W do
  begin
    row := 0;
    while row < H div 2 do
    begin
      c1 := GetPixel(X + col, Y + row);
      c2 := GetPixel(X + col, Y + H - 1 - row);
      PutPixel(X + col, Y + row,         c2);
      PutPixel(X + col, Y + H - 1 - row, c1);
      Inc(row);
    end;
    Inc(col);
  end;
end;

//=============================================================================
// Trig helpers (integer, no FPU)
// Derece × 10 hassasiyeti
//=============================================================================







end.

{ =========================================================
  KULLANIM ÖRNEĞİ
  ========================================================= }

(*
// Init
Draw32_Init(ScreenBuffer, 800, 600);

// Clip belirle
Clip_Set(10, 10, 790, 590);

// Temel çizimler
PutPixel(100, 100, clRed);
KLineH(10, 20, 200, clBlue);
KFill(50, 50, 100, 80, cl3DFace);
KRect(50, 50, 100, 80, clBlack);

// 3D buton
KButton3D(100, 100, 120, 30, False, cl3DFace);
KStrCentered(100, 100+7, 120, 'Tamam', clBlack);

// Gradient title bar
KTitleBar(0, 0, 400, 22, True, 'My Window');

// Granit arka plan
KGranite(0, 0, 800, 600, $00A0A0A0, 30);

// Mermer doku
KMarble(0, 0, 200, 200, $00F0E0D0, $00A08070);

// Ahşap doku
KWood(0, 0, 200, 200, $008040A0, $0040208060);

// Metal
KMetal(0, 0, 200, 30, $00808080);

// Rainbow
KRainbow(0, 580, 800, 20);

// Glow efekti
KGlowRect(100, 100, 200, 100, 8, $000080FF);

// Shadow
KShadowRect(100, 100, 200, 100, 6, clWhite);

// Blur
KBlurRect(50, 50, 300, 200, 3);

// Grayscale
KGrayscale(0, 0, 200, 200);

// Emboss
KEmboss(0, 0, 200, 200);

// Checker pattern
KChecker(0, 0, 400, 400, 20, clWhite, clLtGray);

// Clip temizle
Clip_Clear;
*)

Unit DrawIcon;

interface

uses
  SysUtils, Draw32;

type
  TIconType = (
    itFolder,       // Klas�r
    itPictures,     // Resimlerim
    itMusic,        // M�ziklerim
    itHDD,          // Sabit Disk
    itRAM,          // RAM Bellek
    itPaint,        // Paint / �izim
    itMyComputer,   // Bilgisayar�m
    itFiles,        // Dosyalar�m
    itSettings,     // Ayarlar
    itTxt,          // Metin Belgesi
    itWav,          // Ses Dosyas�
    itBmp,          // Resim Dosyas�
    itExe,          // �al��t�r�labilir Dosya
    itBin,          // Binary / Veri Dosyas�
    // Eklenen �konlar
    itRecycleBin,   // ��p Kutusu
    itNetwork,      // A�
    itZip,          // S�k��t�r�lm�� Ar�iv
    itTerminal,     // Komut Sat�r� / Terminal
    itDoc           // Genel Dok�man / PDF
  );

// Ana �kon �izim Prosed�r� (�l�eklenebilir)
procedure DrawIcon(X, Y, Size: Integer; IconType: TIconType); stdcall;

// Bireysel �kon �izim Fonksiyonlar�
procedure DrawIconFolder(X, Y, Size: Integer); stdcall;
procedure DrawIconPictures(X, Y, Size: Integer); stdcall;
procedure DrawIconMusic(X, Y, Size: Integer); stdcall;
procedure DrawIconHDD(X, Y, Size: Integer); stdcall;
procedure DrawIconRAM(X, Y, Size: Integer); stdcall;
procedure DrawIconPaint(X, Y, Size: Integer); stdcall;
procedure DrawIconMyComputer(X, Y, Size: Integer); stdcall;
procedure DrawIconFiles(X, Y, Size: Integer); stdcall;
procedure DrawIconSettings(X, Y, Size: Integer); stdcall;
procedure DrawIconTxt(X, Y, Size: Integer); stdcall;
procedure DrawIconWav(X, Y, Size: Integer); stdcall;
procedure DrawIconBmp(X, Y, Size: Integer); stdcall;
procedure DrawIconExe(X, Y, Size: Integer); stdcall;
procedure DrawIconBin(X, Y, Size: Integer); stdcall;
procedure DrawIconRecycleBin(X, Y, Size: Integer); stdcall;
procedure DrawIconNetwork(X, Y, Size: Integer); stdcall;
procedure DrawIconZip(X, Y, Size: Integer); stdcall;
procedure DrawIconTerminal(X, Y, Size: Integer); stdcall;
procedure DrawIconDoc(X, Y, Size: Integer); stdcall;

implementation

// 32px tabanl� koordinatlar� dinamik boyuta �l�ekleme yard�mc�s�
function S(Val, Size: Integer): Integer; inline;
begin
  Result := (Val * Size) div 32;
end;

{ =========================================================
  KLAS�R �KONU
  ========================================================= }
procedure DrawIconFolder(X, Y, Size: Integer); stdcall;
var
  TabW, TabH, MainH: Integer;
begin
  // G�lge
  KFillAlpha(X + S(2, Size), Y + S(28, Size), S(28, Size), S(3, Size), clBlack, 80);

  // Arka Sekme
  TabW := S(14, Size);
  TabH := S(6, Size);
  KGradientV(X + S(2, Size), Y + S(4, Size), TabW, TabH, $0000C8FF, $000096C8);
  
  // Ana Klas�r G�vdesi
  MainH := S(20, Size);
  KGradientV(X + S(1, Size), Y + S(8, Size), S(30, Size), MainH, $0046E6FF, $00008CBD);
  
  // Klas�r A�z� / �� Derinlik �izgisi
  KLineH(X + S(2, Size), Y + S(9, Size), S(28, Size), $0080FFFF);
  KRect(X + S(1, Size), Y + S(8, Size), S(30, Size), MainH, $00005A82);
end;

{ =========================================================
  RES�MLER�M �KONU
  ========================================================= }
procedure DrawIconPictures(X, Y, Size: Integer); stdcall;
begin
  // �er�eve / Foto�raf Kart�
  KShadowRect(X + S(2, Size), Y + S(2, Size), S(28, Size), S(28, Size), S(2, Size), clWhite);
  KRect(X + S(2, Size), Y + S(2, Size), S(28, Size), S(28, Size), $00C0C0C0);
  
  // G�ky�z� Gradient
  KGradientV(X + S(4, Size), Y + S(4, Size), S(24, Size), S(16, Size), $00FFF0C0, $00FF8000);
  
  // G�ne�
  KFillCircle(X + S(8, Size), Y + S(8, Size), S(3, Size), $0000FFFF);
  
  // Da�lar
  KFillTriangle(X + S(4, Size), Y + S(20, Size), X + S(12, Size), Y + S(10, Size), X + S(20, Size), Y + S(20, Size), $00008000);
  KFillTriangle(X + S(12, Size), Y + S(20, Size), X + S(20, Size), Y + S(12, Size), X + S(28, Size), Y + S(20, Size), $0000A52A);
  
  // Alt Foto�raf Kenarl��� (Polaroid Hissi)
  KFill(X + S(4, Size), Y + S(21, Size), S(24, Size), S(7, Size), $00FAFAFA);
end;

{ =========================================================
  M�Z�KLER�M �KONU (CD / Vinil)
  ========================================================= }
procedure DrawIconMusic(X, Y, Size: Integer); stdcall;
var
  R, CX, CY: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := S(14, Size);
  
  // Vinil/Plak G�vdesi
  KFillCircle(CX, CY, R, $00202020);
  KCircle(CX, CY, R, $00505050);
  KCircle(CX, CY, S(10, Size), $003A3A3A);
  KCircle(CX, CY, S(7, Size),  $00505050);
  
  // Orta Etiket
  KFillCircle(CX, CY, S(5, Size), $00FF3300);
  KFillCircle(CX, CY, S(2, Size), clWhite); // Delik
  
  // Nota Sembol� Overlay
  KLineV(CX + S(3, Size), CY - S(6, Size), S(10, Size), clYellow);
  KFillCircle(CX + S(1, Size), CY + S(4, Size), S(2, Size), clYellow);
end;

{ =========================================================
  HDD (SAB�T D�SK) �KONU
  ========================================================= }
procedure DrawIconHDD(X, Y, Size: Integer); stdcall;
begin
  // Metal G�vde
  KMetal(X + S(3, Size), Y + S(4, Size), S(26, Size), S(24, Size), $00808080);
  KRect(X + S(3, Size), Y + S(4, Size), S(26, Size), S(24, Size), $00404040);
  
  // �st Kapak Derinli�i
  KBevel(X + S(5, Size), Y + S(6, Size), S(22, Size), S(18, Size), S(1, Size), True);
  
  // Vidalar
  PutPixel(X + S(4, Size), Y + S(5, Size), clBlack);
  PutPixel(X + S(27, Size), Y + S(5, Size), clBlack);
  PutPixel(X + S(4, Size), Y + S(26, Size), clBlack);
  PutPixel(X + S(27, Size), Y + S(26, Size), clBlack);
  
  // �al��ma LED'i (Ye�il Parlama)
  KFillCircle(X + S(7, Size), Y + S(21, Size), S(1, Size), clGreen);
  KGlowRect(X + S(6, Size), Y + S(20, Size), S(3, Size), S(3, Size), S(1, Size), clGreen);
end;

{ =========================================================
  RAM BELLEK �KONU
  ========================================================= }
procedure DrawIconRAM(X, Y, Size: Integer); stdcall;
var
  i, PinCount: Integer;
begin
  // Ye�il PCB Devre Kart�
  KGradientV(X + S(2, Size), Y + S(8, Size), S(28, Size), S(16, Size), $00008800, $00004400);
  KRect(X + S(2, Size), Y + S(8, Size), S(28, Size), S(16, Size), $00002200);
  
  // Siyah SMT �ipler
  KFill(X + S(4, Size),  Y + S(10, Size), S(5, Size), S(8, Size), $001A1A1A);
  KFill(X + S(10, Size), Y + S(10, Size), S(5, Size), S(8, Size), $001A1A1A);
  KFill(X + S(17, Size), Y + S(10, Size), S(5, Size), S(8, Size), $001A1A1A);
  KFill(X + S(23, Size), Y + S(10, Size), S(5, Size), S(8, Size), $001A1A1A);
  
  // Alt Alt�n Konnekt�r Pinleri
  PinCount := S(12, Size);
  for i := 0 to PinCount do
  begin
    KLineV(X + S(3, Size) + (i * S(2, Size)), Y + S(21, Size), S(3, Size), $0000D7FF);
  end;
end;

{ =========================================================
  PAINT / RESSAM PALET� �KONU
  ========================================================= }
procedure DrawIconPaint(X, Y, Size: Integer); stdcall;
var
  CX, CY, RX, RY: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  RX := S(13, Size);
  RY := S(10, Size);
  
  // Ah�ap Palet G�vdesi
  KWood(X + S(2, Size), Y + S(5, Size), S(28, Size), S(22, Size), $002A527A, $001B3550);
  KEllipse(CX, CY, RX, RY, $000F1E2D);
  
  // Ba�parmak Deli�i
  KFillCircle(CX + S(7, Size), CY + S(2, Size), S(2, Size), clWhite);
  
  // Boya Damlalar�
  KFillCircle(CX - S(7, Size), CY - S(3, Size), S(2, Size), clRed);
  KFillCircle(CX - S(3, Size), CY - S(6, Size), S(2, Size), clYellow);
  KFillCircle(CX + S(3, Size), CY - S(6, Size), S(2, Size), clBlue);
  KFillCircle(CX - S(8, Size), CY + S(3, Size), S(2, Size), clGreen);
end;

{ =========================================================
  B�LG�SAYARIM �KONU (Monit�r & Kasa)
  ========================================================= }
procedure DrawIconMyComputer(X, Y, Size: Integer); stdcall;
begin
  // Monit�r D�� �er�eve
  KPanel3D(X + S(2, Size), Y + S(3, Size), S(20, Size), S(16, Size), True, cl3DFace);
  // Ekran (Mavi Gradient)
  KGradientV(X + S(4, Size), Y + S(5, Size), S(16, Size), S(12, Size), $00D06000, $00800000);
  
  // Monit�r Aya��
  KFill(X + S(9, Size), Y + S(19, Size), S(6, Size), S(3, Size), clGray);
  KFill(X + S(6, Size), Y + S(22, Size), S(12, Size), S(2, Size), clDkGray);
  
  // Bilgisayar Kasas� (Dik Tower)
  KPanel3D(X + S(22, Size), Y + S(5, Size), S(8, Size), S(20, Size), True, cl3DFace);
  // CD-ROM S�r�c�
  KLineH(X + S(24, Size), Y + S(8, Size), S(4, Size), clDkGray);
  // G�� D��mesi
  PutPixel(X + S(26, Size), Y + S(18, Size), clRed);
end;

{ =========================================================
  DOSYALARIM �KONU (Ar�iv Dolab�)
  ========================================================= }
procedure DrawIconFiles(X, Y, Size: Integer); stdcall;
begin
  // Metal Dolap G�vdesi
  KMetal(X + S(5, Size), Y + S(2, Size), S(22, Size), S(28, Size), $00B0B0B0);
  KRect(X + S(5, Size), Y + S(2, Size), S(22, Size), S(28, Size), clDkGray);
  
  // �ekmece 1
  KPanel3D(X + S(7, Size), Y + S(4, Size), S(18, Size), S(11, Size), True, cl3DFace);
  KFill(X + S(13, Size), Y + S(9, Size), S(6, Size), S(2, Size), clDkGray); // Kulpa
  
  // �ekmece 2
  KPanel3D(X + S(7, Size), Y + S(17, Size), S(18, Size), S(11, Size), True, cl3DFace);
  KFill(X + S(13, Size), Y + S(22, Size), S(6, Size), S(2, Size), clDkGray); // Kulpa
end;

{ =========================================================
  AYARLAR �KONU (Di�li �ark)
  ========================================================= }
procedure DrawIconSettings(X, Y, Size: Integer); stdcall;
var
  CX, CY, R, i: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := S(9, Size);
  
  // Di�li ��k�nt�lar� (8 Y�nl�)
  for i := 0 to 7 do
  begin
    KFillCircle(CX + Round(R * Cos_Int(i * 45)), CY + Round(R * Sin_Int(i * 45)), S(3, Size), clGray);
  end;
  
  // Ana Di�li G�vdesi
  KGradientRadial(CX, CY, R, clSilver, clDkGray);
  KCircle(CX, CY, R, clBlack);
  
  // �� G�bek Deli�i
  KFillCircle(CX, CY, S(4, Size), clWhite);
  KCircle(CX, CY, S(4, Size), clDkGray);
end;

{ =========================================================
  TXT (MET�N BELGES�) �KONU
  ========================================================= }
procedure DrawIconTxt(X, Y, Size: Integer); stdcall;
var
  i: Integer;
begin
  // Ka��t Yapra��
  KShadowRect(X + S(5, Size), Y + S(2, Size), S(22, Size), S(28, Size), S(2, Size), clWhite);
  KRect(X + S(5, Size), Y + S(2, Size), S(22, Size), S(28, Size), $00D0D0D0);
  
  // K�vr�k K��e (Sa� �st)
  KFillTriangle(X + S(21, Size), Y + S(2, Size), X + S(27, Size), Y + S(8, Size), X + S(21, Size), Y + S(8, Size), $00E0E0E0);
  KLine(X + S(21, Size), Y + S(2, Size), X + S(27, Size), Y + S(8, Size), $00B0B0B0);
  
  // Metin �izgileri
  for i := 0 to 5 do
  begin
    KLineH(X + S(8, Size), Y + S(11, Size) + (i * S(3, Size)), S(15, Size), $00808080);
  end;
end;

{ =========================================================
  WAV (SES DOSYASI) �KONU
  ========================================================= }
procedure DrawIconWav(X, Y, Size: Integer); stdcall;
begin
  // Mor Arka Plan Kart�
  KGradientV(X + S(4, Size), Y + S(3, Size), S(24, Size), S(26, Size), $00800080, $00400040);
  KRect(X + S(4, Size), Y + S(3, Size), S(24, Size), S(26, Size), $00200020);
  
  // Ses Dalgalar� (Equalizer Barlar�)
  KFill(X + S(7, Size),  Y + S(16, Size), S(2, Size), S(8, Size),  clCyan);
  KFill(X + S(11, Size), Y + S(10, Size), S(2, Size), S(14, Size), clCyan);
  KFill(X + S(15, Size), Y + S(6, Size),  S(2, Size), S(18, Size), clCyan);
  KFill(X + S(19, Size), Y + S(12, Size), S(2, Size), S(12, Size), clCyan);
  KFill(X + S(23, Size), Y + S(18, Size), S(2, Size), S(6, Size),  clCyan);
end;

{ =========================================================
  BMP (RES�M DOSYASI) �KONU
  ========================================================= }
procedure DrawIconBmp(X, Y, Size: Integer); stdcall;
begin
  // Temel Dok�man Kart�
  DrawIconTxt(X, Y, Size);
  
  // Alt Taraf�na K���k G�rsel Rozeti
  KGradientV(X + S(8, Size), Y + S(14, Size), S(16, Size), S(12, Size), $000080FF, $00004080);
  KFillCircle(X + S(12, Size), Y + S(17, Size), S(2, Size), clYellow);
  KFillTriangle(X + S(9, Size), Y + S(24, Size), X + S(14, Size), Y + S(19, Size), X + S(18, Size), Y + S(24, Size), clGreen);
end;

{ =========================================================
  EXE (�ALI�TIRILAB�L�R DOSYA) �KONU
  ========================================================= }
procedure DrawIconExe(X, Y, Size: Integer); stdcall;
begin
  // Uygulama Penceresi G�vdesi
  KPanel3D(X + S(3, Size), Y + S(3, Size), S(26, Size), S(26, Size), True, cl3DFace);
  
  // Mavi Ba�l�k �ubu�u (TitleBar)
  KTitleBar(X + S(5, Size), Y + S(5, Size), S(22, Size), S(5, Size), True, '');
  
  // �� �al��ma Alan� (Koyu Gri)
  KSunken(X + S(5, Size), Y + S(11, Size), S(22, Size), S(16, Size), $001A1A1A);
  
  // ��inde Di�li/�al��t�rma Simgesi
  KFillCircle(X + S(16, Size), Y + S(19, Size), S(4, Size), clLtGray);
  KCircle(X + S(16, Size), Y + S(19, Size), S(2, Size), clBlack);
end;

{ =========================================================
  BIN (BINARY / VER� DOSYASI) �KONU
  ========================================================= }
procedure DrawIconBin(X, Y, Size: Integer); stdcall;
begin
  // Siyah Matrix Stili Kart
  KFill(X + S(4, Size), Y + S(3, Size), S(24, Size), S(26, Size), clBlack);
  KRect(X + S(4, Size), Y + S(3, Size), S(24, Size), S(26, Size), clGreen);
  
  // 1 ve 0 Temsili Noktalar (Matrix Ye�ili)
  KDots(X + S(7, Size), Y + S(6, Size), S(18, Size), S(20, Size), S(3, Size), clLime);
end;

{ =========================================================
  ��P KUTUSU (RECYCLE BIN) �KONU
  ========================================================= }
procedure DrawIconRecycleBin(X, Y, Size: Integer); stdcall;
begin
  // Kovas� (Metalik Mesh)
  KGradientV(X + S(6, Size), Y + S(10, Size), S(20, Size), S(18, Size), clSilver, clDkGray);
  KBevel(X + S(6, Size), Y + S(10, Size), S(20, Size), S(18, Size), S(1, Size), True);
  
  // �st Kapak Kenar�
  KFillEllipse(X + S(16, Size), Y + S(10, Size), S(11, Size), S(3, Size), clGray);
  
  // Ye�il Geri D�n���m Oklar� (��gen Temsil)
  KFillTriangle(X + S(16, Size), Y + S(13, Size), X + S(12, Size), Y + S(20, Size), X + S(20, Size), Y + S(20, Size), clLime);
end;

{ =========================================================
  A� (NETWORK) �KONU
  ========================================================= }
procedure DrawIconNetwork(X, Y, Size: Integer); stdcall;
var
  CX, CY: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  
  // D�nya / K�re
  KGradientRadial(CX, CY, S(11, Size), $00FF8000, $00800000);
  KEllipse(CX, CY, S(11, Size), S(4, Size), clWhite); // Enlem
  KLineV(CX, CY - S(11, Size), S(22, Size), clWhite); // Boylam
  KCircle(CX, CY, S(11, Size), clNavy);
end;

{ =========================================================
  ZIP (SIKISTIRILMIS ARSIV) �KONU
  ========================================================= }
procedure DrawIconZip(X, Y, Size: Integer); stdcall;
var
  i: Integer;
begin
  // Klas�r Temeli
  DrawIconFolder(X, Y, Size);
  
  // Ortadaki Fermuar �erit Bant�
  KFill(X + S(13, Size), Y + S(8, Size), S(6, Size), S(20, Size), clDkGray);
  
  // Fermuar Di�leri (Alternatif �izgiler)
  for i := 0 to 6 do
  begin
    KLineH(X + S(13, Size) + ((i mod 2) * S(3, Size)), Y + S(9, Size) + (i * S(2, Size)), S(3, Size), clWhite);
  end;
  
  // Fermuar Elci�i (Metalic Klips)
  KFill(X + S(14, Size), Y + S(22, Size), S(4, Size), S(5, Size), clYellow);
end;

{ =========================================================
  TERMINAL / KOMUT SATIRI �KONU
  ========================================================= }
procedure DrawIconTerminal(X, Y, Size: Integer); stdcall;
begin
  // Siyah Konsol Kutusu
  KFill(X + S(2, Size), Y + S(4, Size), S(28, Size), S(24, Size), clBlack);
  KRect(X + S(2, Size), Y + S(4, Size), S(28, Size), S(24, Size), clGray);
  
  // �st Titre�im �ubu�u
  KFill(X + S(3, Size), Y + S(5, Size), S(26, Size), S(4, Size), clDkGray);
  
  // Ye�ille " >_ " �stemci Sembol�
  KLine(X + S(6, Size), Y + S(13, Size), X + S(10, Size), Y + S(16, Size), clLime);
  KLine(X + S(10, Size), Y + S(16, Size), X + S(6, Size), Y + S(19, Size), clLime);
  KLineH(X + S(12, Size), Y + S(19, Size), S(5, Size), clLime); // Imlec _
end;

{ =========================================================
  DOC / PDF (GENEL BELGE) �KONU
  ========================================================= }
procedure DrawIconDoc(X, Y, Size: Integer); stdcall;
begin
  // Beyaz Belge
  DrawIconTxt(X, Y, Size);
  
  // Sol �st K�rm�z� PDF/DOC �eridi
  KFillTriangle(X + S(5, Size), Y + S(2, Size), X + S(15, Size), Y + S(2, Size), X + S(5, Size), Y + S(12, Size), clRed);
end;

{ =========================================================
  ANA �KON DA�ITICI (DISPATCHER)
  ========================================================= }
procedure DrawIcon(X, Y, Size: Integer; IconType: TIconType); stdcall;
begin
  case IconType of
    itFolder:     DrawIconFolder(X, Y, Size);
    itPictures:   DrawIconPictures(X, Y, Size);
    itMusic:      DrawIconMusic(X, Y, Size);
    itHDD:        DrawIconHDD(X, Y, Size);
    itRAM:        DrawIconRAM(X, Y, Size);
    itPaint:      DrawIconPaint(X, Y, Size);
    itMyComputer: DrawIconMyComputer(X, Y, Size);
    itFiles:      DrawIconFiles(X, Y, Size);
    itSettings:   DrawIconSettings(X, Y, Size);
    itTxt:        DrawIconTxt(X, Y, Size);
    itWav:        DrawIconWav(X, Y, Size);
    itBmp:        DrawIconBmp(X, Y, Size);
    itExe:        DrawIconExe(X, Y, Size);
    itBin:        DrawIconBin(X, Y, Size);
    itRecycleBin: DrawIconRecycleBin(X, Y, Size);
    itNetwork:    DrawIconNetwork(X, Y, Size);
    itZip:        DrawIconZip(X, Y, Size);
    itTerminal:   DrawIconTerminal(X, Y, Size);
    itDoc:        DrawIconDoc(X, Y, Size);
  end;
end;

end.

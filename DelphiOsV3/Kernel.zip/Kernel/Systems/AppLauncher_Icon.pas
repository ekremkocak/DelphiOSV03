{ =========================================================
  AppLauncher_Icon.pas
  EXE'nin PE Resource b�l�m�nden icon �ekip
  Desktop'ta �izme sistemi.

  AKI�:
  1. AppLauncher_Scan: C:\BIN\*.EXE tarar
  2. Her EXE i�in:
     a. FAT32'den dosyay� belle�e y�kle
     b. PE resource'dan RT_ICON (tip 3) �ek
     c. Icon piksellerini BGRA bitmap'e �evir
     d. TAppItem.IconData'ya kaydet
     e. Belle�i serbest b�rak (dosya tamponu)
  3. Desktop_Render s�ras�nda IconData'y� �iz

  PE ICON FORMAT:
  - RT_GROUP_ICON (tip 14): hangi icon boyutlar�n�n
    var oldu�unu listeler (16x16, 32x32, 48x48...)
  - RT_ICON (tip 3): ger�ek piksel verisi (BITMAPINFO)
  - Biz �nce GROUP_ICON'dan "en uygun" ID'yi se�eriz
    (tercihen 32x32), sonra o ID'nin RT_ICON datas�n�
    okuyup BGRA'ya �eviririz.
  ========================================================= }

unit AppLauncher_Icon;

interface

uses SysUtils,FAT32, Memory,Vesa, Draw32,Messages;

const
  ICON_SIZE     = 32;   // Desktop'ta �izilecek icon boyutu
  ICON_BPP      = 4;    // 32-bit BGRA = 4 byte/piksel

  RT_ICON       = 3;
  RT_GROUP_ICON = 14;

type
  // �izime haz�r icon verisi (32x32 BGRA)
  PIconData = ^TIconData;
  TIconData = record
    Width:  Integer;
    Height: Integer;
    Pixels: Pointer;   // Width*Height*4 byte BGRA
    Valid:  Boolean;
  end;

PLongWord  = ^LongWord;

procedure AppLauncher_Icon_Init;
function  ExeIcon_Load(ExeData: Pointer; ExeSize: LongWord;
                       out Icon: TIconData): Boolean;
procedure ExeIcon_Free(var Icon: TIconData);
procedure ExeIcon_Draw(const Icon: TIconData; X, Y: Integer);

Procedure GetExeIcon(FileName:PChar;var  Icon: TIconData);

var
 Icon: TIconData;


implementation

//=============================================================================
// PE yap�lar� (header-only, EXE belle�e map edilmi� hali i�in)
//=============================================================================

type
  PDosHdr = ^TDosHdr;
  TDosHdr = packed record
    e_magic  : Word;                    // MZ
    e_pad    : array[0..57] of Byte;
    e_lfanew : LongWord;
  end;

  PPeHdr = ^TPeHdr;
  TPeHdr = packed record
    Sig     : LongWord;                 // PE\0\0
    Machine : Word;
    NumSec  : Word;
    Pad     : array[0..11] of Byte;
    OptSize : Word;
    Chars   : Word;
  end;

  POptHdr = ^TOptHdr;
  TOptHdr = packed record
    Magic      : Word;
    Pad0       : array[0..25] of Byte;
    ImageBase  : LongWord;
    Pad1       : array[0..15] of Byte;
    ImageSz    : LongWord;
    HdrSz      : LongWord;
    Pad2       : array[0..7]  of Byte;
    NumDirs    : LongWord;
    DataDirs   : array[0..15] of packed record
      VirtualAddr: LongWord;
      Size:        LongWord;
    end;
  end;

  PSecHdr = ^TSecHdr;
  TSecHdr = packed record
    Name    : array[0..7] of Char;
    VirtSz  : LongWord;
    VirtRVA : LongWord;
    RawSz   : LongWord;
    RawPtr  : LongWord;
    Pad     : array[0..11] of Byte;
    Chars   : LongWord;
  end;

  // Resource Directory
  PResDir = ^TResDir;
  TResDir = packed record
    Characteristics: LongWord;
    TimeDateStamp:   LongWord;
    MajorVersion:    Word;
    MinorVersion:    Word;
    NumNamedEntries: Word;
    NumIdEntries:    Word;
  end;

  PResDirEntry = ^TResDirEntry;
  TResDirEntry = packed record
    NameOffsetOrId:     LongWord;   // bit31=1 � isim, 0 � id
    OffsetToDataOrDir:  LongWord;   // bit31=1 � alt directory, 0 � data entry
  end;

  PResDataEntry = ^TResDataEntry;
  TResDataEntry = packed record
    DataRVA:  LongWord;
    Size:     LongWord;
    CodePage: LongWord;
    Reserved: LongWord;
  end;

  // GRPICONDIR: EXE'deki RT_GROUP_ICON format�
  PGrpIconDir = ^TGrpIconDir;
  TGrpIconDir = packed record
    Reserved: Word;
    ResType:  Word;    // 1 = icon
    Count:    Word;
  end;

  PGrpIconDirEntry = ^TGrpIconDirEntry;
  TGrpIconDirEntry = packed record
    Width:       Byte;
    Height:      Byte;
    ColorCount:  Byte;
    Reserved:    Byte;
    Planes:      Word;
    BitCount:    Word;
    BytesInRes:  LongWord;
    ID:          Word;   // RT_ICON i�indeki ID
  end;

  // BITMAPINFOHEADER (DIB icon verisi)
  PBmpInfoHdr = ^TBmpInfoHdr;
  TBmpInfoHdr = packed record
    Size:          LongWord;
    Width:         LongInt;
    Height:        LongInt;   // Genelde 2*ger�ek y�kseklik (AND mask dahil)
    Planes:        Word;
    BitCount:      Word;
    Compression:   LongWord;
    SizeImage:     LongWord;
    XPelsPerMeter: LongInt;
    YPelsPerMeter: LongInt;
    ClrUsed:       LongWord;
    ClrImportant:  LongWord;
  end;

//=============================================================================
// RVA � ham veri pointer �evirisi (flat EXE tamponunda)
//=============================================================================

function RvaToPtr(ExeBase: LongWord; ExeSize: LongWord;
                  Rva: LongWord): Pointer;
var
  dos:     PDosHdr;
  pe:      PPeHdr;
  opt:     POptHdr;
  sec:     PSecHdr;
  i:       Integer;
  secBase: LongWord;
begin
  Result := nil;
  if Rva = 0 then Exit;

  dos := PDosHdr(ExeBase);
  pe  := PPeHdr(ExeBase + dos^.e_lfanew);
  opt := POptHdr(ExeBase + dos^.e_lfanew + SizeOf(TPeHdr));
  sec := PSecHdr(ExeBase + dos^.e_lfanew + SizeOf(TPeHdr) + pe^.OptSize);

  i := 0;
  while i < pe^.NumSec do
  begin
    if (Rva >= sec^.VirtRVA) and
       (Rva <  sec^.VirtRVA + sec^.VirtSz) and
       (sec^.RawPtr <> 0) then
    begin
      secBase := ExeBase + sec^.RawPtr + (Rva - sec^.VirtRVA);
      if secBase < ExeBase + ExeSize then
        Result := Pointer(secBase);
      Exit;
    end;
    Inc(sec);
    Inc(i);
  end;
end;

//=============================================================================
// Resource dizininde belirli tip/id'yi ara
//=============================================================================

function FindResourceData(ExeBase: LongWord; ExeSize: LongWord;
                          ResType: LongWord; ResID: LongWord;
                          out DataPtr: Pointer; out DataSize: LongWord): Boolean;
var
  opt:        POptHdr;
  dos:        PDosHdr;
  pe:         PPeHdr;
  resRva:     LongWord;
  resBase:    LongWord;
  dir1:       PResDir;
  entry1:     PResDirEntry;
  dir2:       PResDir;
  entry2:     PResDirEntry;
  dir3:       PResDir;
  entry3:     PResDirEntry;
  dataEntry:  PResDataEntry;
  i, j, k:   Integer;
  id1, id2, id3: LongWord;
begin
  Result   := False;
  DataPtr  := nil;
  DataSize := 0;

  dos := PDosHdr(ExeBase);
  pe  := PPeHdr(ExeBase + dos^.e_lfanew);
  opt := POptHdr(ExeBase + dos^.e_lfanew + SizeOf(TPeHdr));

  // DataDir[2] = Resource dizini
  resRva := opt^.DataDirs[2].VirtualAddr;
  if resRva = 0 then Exit;

  resBase := LongWord(RvaToPtr(ExeBase, ExeSize, resRva));
  if resBase = 0 then Exit;

  //-----------------------------------------------------------
  // Seviye 1: Tip (RT_ICON, RT_GROUP_ICON...)
  //-----------------------------------------------------------
  dir1 := PResDir(resBase);
  entry1 := PResDirEntry(resBase + SizeOf(TResDir));

  i := 0;
  while i < Integer(dir1^.NumNamedEntries + dir1^.NumIdEntries) do
  begin
    id1 := entry1^.NameOffsetOrId and $7FFFFFFF;

    // ID tipli entry ve istedi�imiz tiple e�le�iyor mu?
    if (entry1^.NameOffsetOrId and $80000000 = 0) and (id1 = ResType) then
    begin
      // Alt dizin mi?
      if entry1^.OffsetToDataOrDir and $80000000 = 0 then
      begin
        Inc(entry1);
        Inc(i);
        Continue;
      end;

      //-------------------------------------------------------
      // Seviye 2: ID (istenen icon ID'si)
      //-------------------------------------------------------
      dir2 := PResDir(resBase + (entry1^.OffsetToDataOrDir and $7FFFFFFF));
      entry2 := PResDirEntry(LongWord(dir2) + SizeOf(TResDir));

      j := 0;
      while j < Integer(dir2^.NumNamedEntries + dir2^.NumIdEntries) do
      begin
        id2 := entry2^.NameOffsetOrId and $7FFFFFFF;

        if (entry2^.NameOffsetOrId and $80000000 = 0) and
           (id2 = ResID) then
        begin
          if entry2^.OffsetToDataOrDir and $80000000 = 0 then
          begin
            Inc(entry2); Inc(j);
            Continue;
          end;

          //---------------------------------------------------
          // Seviye 3: Dil (ilk dili al)
          //---------------------------------------------------
          dir3 := PResDir(resBase + (entry2^.OffsetToDataOrDir and $7FFFFFFF));
          entry3 := PResDirEntry(LongWord(dir3) + SizeOf(TResDir));

          if dir3^.NumIdEntries + dir3^.NumNamedEntries > 0 then
          begin
            // Veri entry (bit31=0 olmal�)
            if entry3^.OffsetToDataOrDir and $80000000 = 0 then
            begin
              dataEntry := PResDataEntry(resBase + entry3^.OffsetToDataOrDir);
              DataPtr   := RvaToPtr(ExeBase, ExeSize, dataEntry^.DataRVA);
              DataSize  := dataEntry^.Size;
              Result    := (DataPtr <> nil) and (DataSize > 0);
              Exit;
            end;
          end;
        end;

        Inc(entry2);
        Inc(j);
      end;
    end;

    Inc(entry1);
    Inc(i);
  end;
end;

//=============================================================================
// RT_GROUP_ICON'dan en uygun RT_ICON ID'sini se�
// Tercih: 32x32 �nce, yoksa en b�y�k mevcut boyut
//=============================================================================

function BestIconID(ExeBase: LongWord; ExeSize: LongWord): Word;
var
  DataPtr:  Pointer;
  DataSize: LongWord;
  grpDir:   PGrpIconDir;
  entry:    PGrpIconDirEntry;
  i:        Integer;
  best32ID: Word;
  bestID:   Word;
  bestW:    Integer;
begin
  Result   := 0;
  best32ID := 0;
  bestID   := 0;
  bestW    := 0;

  // �lk GROUP_ICON resource'unu al (ID=1 genelde)
  if not FindResourceData(ExeBase, ExeSize, RT_GROUP_ICON, 1, DataPtr, DataSize) then
    Exit;

  grpDir := PGrpIconDir(DataPtr);
  if grpDir^.Count = 0 then Exit;

  entry := PGrpIconDirEntry(LongWord(DataPtr) + SizeOf(TGrpIconDir));

  i := 0;
  while i < grpDir^.Count do
  begin
    if entry^.Width = ICON_SIZE then
    begin
      best32ID := entry^.ID;
    end;

    if Integer(entry^.Width) > bestW then
    begin
      bestW  := entry^.Width;
      bestID := entry^.ID;
    end;

    Inc(entry);
    Inc(i);
  end;

  if best32ID <> 0 then
    Result := best32ID
  else
    Result := bestID;
end;

Procedure GetExeIcon(FileName:PChar; var  Icon: TIconData);
var
 Handle: Integer;
 bytesRead: LongWord;
 Size: Integer;
 FileData: PByteArray;

begin

  handle := OpenFile(FileName, FILE_READ);
  if handle >= 0 then
  begin
     Size := FileSize(handle);

    FileData := PByteArray(MemAlloc(Size));
    if FileData = nil then
    begin
        CloseFile(handle);
        Exit;
    end;



   bytesRead := ReadFile(handle, FileData, Size);


   ExeIcon_Load(FileData, Size, Icon);



  // ExeIcon_Draw(Icon,200,50);
  


   FreeMem(FileData, Size);

   CloseFile(handle);

  end;

end;


procedure DIBtoBGRA(DIBPtr: Pointer; DIBSize: LongWord;
                    OutBuf: Pointer; OutW, OutH: Integer);
var
  hdr:        PBmpInfoHdr;
  bpp:        Integer;
  realH:      Integer;
  rowBytes:   Integer;
  palSize:    Integer;
  pal:        PByte;
  pixData:    PByte;
  out32:      PLongWord;
  x, y:       Integer;
  srcByte:    Byte;
  palIdx:     Integer;
  r, g, b:    Byte;
  srcRow:     PByte;
  srcOff:     Integer;
  palEntry:   PByte;
begin
  if (DIBPtr = nil) or (OutBuf = nil) then Exit;
 
  hdr := PBmpInfoHdr(DIBPtr);
  bpp := hdr^.BitCount;
 
  // Icon y�ksekli�i DIB'de 2x olarak saklan�r (XOR + AND mask)
  realH := Abs(hdr^.Height) div 2;
  if realH = 0 then realH := OutH;
 
  // Palet boyutu
  case bpp of
    1:  palSize := 2  * 4;
    4:  palSize := 16 * 4;
    8:  palSize := 256 * 4;
  else
    palSize := 0;
  end;
 
  pal     := PByte(LongWord(hdr) + hdr^.Size);
  pixData := PByte(LongWord(pal) + palSize);
  out32   := PLongWord(OutBuf);
 
  // Sat�r geni�li�i 4-byte hizal�
  rowBytes := ((OutW * bpp + 31) div 32) * 4;
 
  // DIB'de sat�rlar alttan �ste s�ralan�r (flip)
  y := 0;
  while y < OutH do
  begin
    // Kaynak sat�r: DIB alttan �ste, biz yukar�dan a�a��ya �iziyoruz
    srcRow := PByte(LongWord(pixData) + LongWord((realH - 1 - y)) * LongWord(rowBytes));
 
    x := 0;
    while x < OutW do
    begin
      case bpp of
        4:
        begin
          // 4bpp: her byte'da 2 piksel (high nibble=sol)
          srcOff  := x div 2;
          srcByte := PByte(LongWord(srcRow) + srcOff)^;
          if (x and 1) = 0 then
            palIdx := (srcByte shr 4) and $F
          else
            palIdx := srcByte and $F;
 
          palEntry := PByte(LongWord(pal) + palIdx * 4);
          b := palEntry^; Inc(palEntry);
          g := palEntry^; Inc(palEntry);
          r := palEntry^;
          out32^ := $FF000000 or (LongWord(r) shl 16) or
                    (LongWord(g) shl 8) or b;
        end;
 
        8:
        begin
          palIdx   := PByte(LongWord(srcRow) + LongWord(x))^;
          palEntry := PByte(LongWord(pal) + palIdx * 4);
          b := palEntry^; Inc(palEntry);
          g := palEntry^; Inc(palEntry);
          r := palEntry^;
          out32^ := $FF000000 or (LongWord(r) shl 16) or
                    (LongWord(g) shl 8) or b;
        end;
 
        24:
        begin
          srcOff   := x * 3;
          b := PByte(LongWord(srcRow) + LongWord(srcOff))^;
          g := PByte(LongWord(srcRow) + LongWord(srcOff) + 1)^;
          r := PByte(LongWord(srcRow) + LongWord(srcOff) + 2)^;
          out32^ := $FF000000 or (LongWord(r) shl 16) or
                    (LongWord(g) shl 8) or b;
        end;
 
        32:
        begin
          // 32bpp: BGRA do�rudan
          out32^ := PLongWord(LongWord(srcRow) + LongWord(x * 4))^;
          // Alpha 0 ise �effaf � $FF ile de�i�tir (baz� icon'larda alpha yok)
          if (out32^ shr 24) = 0 then
            out32^ := out32^ or $FF000000;
        end;
 
      else
        // Bilinmeyen bpp: gri doldur
        out32^ := $FF808080;
      end;
 
      Inc(out32);
      Inc(x);
    end;
 
    Inc(y);
  end;
end;

//=============================================================================
// ExeIcon_Load � Ana fonksiyon
// ExeData: FAT32'den okunmu� ham EXE tamponu
// ExeSize: dosya boyutu
// Icon:    doldurulacak ��kt� yap�s�
//=============================================================================

function ExeIcon_Load(ExeData: Pointer; ExeSize: LongWord;
                      out Icon: TIconData): Boolean;
var
  exeBase:  LongWord;
  iconID:   Word;
  dib:      Pointer;
  dibSize:  LongWord;
  pixels:   Pointer;
begin
  Result    := False;
  Icon.Valid  := False;
  Icon.Pixels := nil;
  Icon.Width  := ICON_SIZE;
  Icon.Height := ICON_SIZE;

  

  if (ExeData = nil) or (ExeSize < 64) then Exit;
 
  // MZ kontrol�
  if PWord(ExeData)^ <> $5A4D then Exit;

  exeBase := LongWord(ExeData);
  
  // En uygun icon ID'sini bul
  iconID := BestIconID(exeBase, ExeSize);
  if iconID = 0 then Exit;


   Showmessage('data');
 

  // RT_ICON verisini al
  if not FindResourceData(exeBase, ExeSize, RT_ICON, iconID, dib, dibSize) then
    Exit;

  // BGRA tamponu tahsis et
  pixels := MemAlloc(ICON_SIZE * ICON_SIZE * ICON_BPP);
  if pixels = nil then Exit;

  FillChar(pixels^, ICON_SIZE * ICON_SIZE * ICON_BPP, 0);

  // DIB � BGRA �evir
  DIBtoBGRA(dib, dibSize, pixels, ICON_SIZE, ICON_SIZE);

 

  Icon.Pixels := pixels;
  Icon.Width  := ICON_SIZE;
  Icon.Height := ICON_SIZE;
  Icon.Valid  := True;
  Result      := True;
end;

procedure ExeIcon_Free(var Icon: TIconData);
begin
  if Icon.Pixels <> nil then
  begin
    FreeMem(Icon.Pixels, ICON_SIZE * ICON_SIZE * ICON_BPP);
    Icon.Pixels := nil;
  end;
  Icon.Valid := False;
end;

//=============================================================================
// ExeIcon_Draw � BGRA piksellerini Draw32 ile ekrana �iz
//=============================================================================

procedure ExeIcon_Draw(const Icon: TIconData; X, Y: Integer);
var
  px, py:   Integer;
  src:      PLongWord;
  bgra:     LongWord;
 SrcR, SrcG, SrcB: Byte;
  alpha:    Byte;
  color:integer;
  bg:LongWord;
  R,G,B:Byte;
 DestR, DestG, DestB: Byte;
  InvAlpha: Byte;
begin
  if not Icon.Valid or (Icon.Pixels = nil) then
  begin
    // Fallback: gri kutu �iz
   // KFill(X, Y, ICON_SIZE, ICON_SIZE, $00808080);
   // KRect(X, Y, ICON_SIZE, ICON_SIZE, $00404040);
    Exit;
  end;
 
  src := PLongWord(Icon.Pixels);
 
  py := 0;
  while py < Icon.Height do
  begin
    px := 0;
    while px < Icon.Width do
    begin
      bgra  := src^;
      alpha := Byte(bgra shr 24);
      Srcb     := Byte(bgra);
      Srcg     := Byte(bgra shr 8);
      Srcr     := Byte(bgra shr 16);

      InvAlpha := 255 - Alpha;


      
      // Tam �effaf pikselleri atla (desktop arka plan� g�r�ns�n)
      if alpha > 16 then
      begin
        // Alpha blending (basit: alpha 128'in �st�ndeyse tam �iz)
        if alpha >= 128 then
         Vesa.PutPixel(X + px, Y + py, SrcR,SrcG,SrcB)
       
        else
        begin
          // Yar� �effaf: mevcut piksel ile blend
           bg := GetPixel(X + px, Y + py);
           Destr := Byte(bg shr 16);
           Destg := Byte(bg shr 8);
           Destb  := Byte(bg);


          R := (DestR * Alpha + SrcR * InvAlpha) div 255;
          G := (DestG * Alpha + SrcG * InvAlpha) div 255;
          B := (DestB * Alpha + SrcB * InvAlpha) div 255;






          Vesa.PutPixel(X + px, Y + py, R,G,B);


        end;
 
       //PutPixel(X + px, Y + py, color);
      end;
 
      Inc(src);
      Inc(px);
    end;
    Inc(py);
  end;
end;

procedure AppLauncher_Icon_Init;
begin
  // �u an ekstra init gerekmez
end;

end.

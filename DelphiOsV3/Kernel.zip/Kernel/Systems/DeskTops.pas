Unit Desktops;

interface
 Uses
   SysUtils, Draw32, Task, Fat32, Pit, Memory, Math, Vesa, Mouse,DrawIcons, DesktopIcons,
   DirectoryView, HDDWindow, MemoryWindow, TaskMgrForm, PaintApp,Terminals,PaintBoxs,Settings,
   HTTPServer,MjpegServer,WebBrowserForm,Calculators,GameChip8,ClockForms,Basic,ExeFile,
   FormNetAdapter;

const
  ICON_WIDTH = 64;
  ICON_HEIGHT = 80;
  ICON_SPACING = 24;
  TASKBAR_HEIGHT = 32;

type
  PDesktopItem = ^TDesktopItem;
  TDesktopItemCallback = procedure(Item: PDesktopItem);


   // Extracted EXE Icon Buffer (32x32 piksel format�nda raw ARGB tamponu)
  PEXEIcon = ^TEXEIcon;
  TEXEIcon = record
    Width   : Integer;
    Height  : Integer;
    Loaded  : Boolean;
    Pixels  : array[0..32 * 32 - 1] of LongWord; // 32x32 ARGB Pikseller
  end;


  TDesktopItem = record
    Next: PDesktopItem;
    Previous: PDesktopItem;
    Mode: Byte;                   // 0 = Daima Solda Sabit, 1 = Ortada Izgara
    Title: array[0..63] of Char;
    IconPath: array[0..127] of Char;
    IconBitmap: Pointer;
    ImageIndex: Integer;
    X, Y: Integer;               // Anl�k �izim Koordinat�
    TargetX, TargetY: Integer;   // Hedef Koordinat (Mode 1 i�in)
    Width, Height: Integer;
    Selected: Boolean;
    Callback: TDesktopItemCallback;
    UserData: LongWord;
    Tag: Integer;
    IsExe:Boolean;
    EXEIcon:TEXEIcon;
  end;

  PDesktopData = ^TDesktopData;
  TDesktopData = record
    FirstItem: PDesktopItem;     // Listenin ba��
    LastItem: PDesktopItem;      // Listenin sonu
    ItemCount: Integer;
    
    IsGridActive: Boolean;
    AnimProgress: Integer;
    IsAnimating: Boolean;
    SelectedItem: PDesktopItem;
    
    LastClickItem: PDesktopItem;
    LastClickTime: LongWord;

    IsDragging: Boolean;
    DragItem: PDesktopItem;
    DragOffsetX: Integer;
    DragOffsetY: Integer;
    
    ScreenWidth: Integer;
    ScreenHeight: Integer;
  end;

var
  Desktop: PDesktopData;

// API
procedure Desktop_Init(Width, Height: Integer);
function Desktop_AddItem(Title, IconPath: PChar; Mode: Byte;
                         ImageIndex: Integer;
                         Callback: TDesktopItemCallback): PDesktopItem;
procedure Desktop_RemoveItem(Item: PDesktopItem);
procedure Desktop_Render;
procedure Desktop_HandleClick(X, Y: Integer);
function Desktop_HandleDoubleClick(X, Y: Integer): Boolean;
procedure Desktop_DrawIcon(Item: PDesktopItem);
procedure Desktop_HandleMouseMove(X, Y: Integer);
procedure Desktop_HandleRightClick(X, Y: Integer);
procedure Desktop_HandleMouseUp(X, Y: Integer);
procedure InitDesktop;
procedure Desktop_ToggleGridMode;

function ExtractIconFromPEBuffer(PEBuffer: PByte; BufferSize: LongWord; var OutIcon: TEXEIcon): Boolean;
procedure DrawExeIcon(X, Y, Size: Integer; const ExeIcon: TEXEIcon); stdcall;
procedure DrawIconEx(X, Y, Size: Integer; IconType: TIconType; CustomExeIcon: PEXEIcon = nil); stdcall;

implementation

Uses GUI;


{ RVA De�erini File Offset'e �evirir }
function RVAToOffset(PEBuffer: PByte; RVA: LongWord): LongWord;
var
  DosHdr: PImageDosHeader;
  NtHeaderOffset: LongWord;
  NumSections: Word;
  SecHeaderOffset: LongWord;
  i: Integer;
  VirtualAddr, SizeOfRawData, PointerToRawData: LongWord;
  BaseAddr: LongWord;
  SecPtr: LongWord;
begin
  Result := 0;
  if PEBuffer = nil then Exit;

  BaseAddr := LongWord(PEBuffer);
  DosHdr := PImageDosHeader(PEBuffer);
  NtHeaderOffset := DosHdr^._lfanew;
  
  // Delphi 7 i�in LongWord d�n���m� ile offset okuma
  NumSections := PWord(BaseAddr + NtHeaderOffset + 6)^;
  SecHeaderOffset := NtHeaderOffset + 24 + PWord(BaseAddr + NtHeaderOffset + 20)^;

  for i := 0 to NumSections - 1 do
  begin
    SecPtr := BaseAddr + SecHeaderOffset + LongWord(i * 40);
    VirtualAddr      := PLongWord(SecPtr + 12)^;
    SizeOfRawData    := PLongWord(SecPtr + 16)^;
    PointerToRawData := PLongWord(SecPtr + 20)^;

    if (RVA >= VirtualAddr) and (RVA < VirtualAddr + SizeOfRawData) then
    begin
      Result := PointerToRawData + (RVA - VirtualAddr);
      Exit;
    end;
  end;
end;

{ PE ���NDEN RT_ICON RESOURE CIKARMA }
function ExtractIconFromPEBuffer(PEBuffer: PByte; BufferSize: LongWord; var OutIcon: TEXEIcon): Boolean;
var
  DosHdr: PImageDosHeader;
  NtHeaderOffset, ResRVA, ResOffset: LongWord;
  ResDir, TypeDir, NameDir, LangDir: PImageResourceDirectory;
  Entry: PImageResourceDirectoryEntry;
  DataEntry: PImageResourceDataEntry;
  GroupDir: PGRPIconDir;
  GroupEntry, BestEntry: PGRPIconDirEntry;
  i, EntriesCount: Integer;
  GroupDataOffset, IconDataOffset: LongWord;
  TargetIconID: Word;
  BestBitCount, BestWidth: Word;
  BmpHdr: PBitmapInfoHeader;
  PixelPtr: PByte;
  x, y, RowBytes: Integer;
  R, G, B: Byte;
  ColorVal, BaseAddr: LongWord;
  Palette: array[0..255] of TRGBQuad;
  PaletteCount, Idx: Integer;
  XorPtr, AndPtr, XorRow, AndRow: PByte;
  AndByte: Byte;
  AndRowBytes: Integer;
begin
  Result := False;
  OutIcon.Loaded := False;

  if (PEBuffer = nil) or (BufferSize < 64) then Exit;
  BaseAddr := LongWord(PEBuffer);

  // MZ ve PE Header Kontrol�
  DosHdr := PImageDosHeader(PEBuffer);
  if DosHdr^.e_magic <> $5A4D then Exit;
  NtHeaderOffset := DosHdr^._lfanew;
  if PLongWord(BaseAddr + NtHeaderOffset)^ <> $00004550 then Exit;

  // Resource Data Directory (Index 2)
  ResRVA := PLongWord(BaseAddr + NtHeaderOffset + 136)^;
  if ResRVA = 0 then Exit;

  ResOffset := RVAToOffset(PEBuffer, ResRVA);
  if ResOffset = 0 then Exit;

  ResDir := PImageResourceDirectory(BaseAddr + ResOffset);
  EntriesCount := ResDir^.NumberOfNamedEntries + ResDir^.NumberOfIdEntries;
  Entry := PImageResourceDirectoryEntry(BaseAddr + ResOffset + SizeOf(TImageResourceDirectory));

  GroupDataOffset := 0;

  // STEP 1: RT_GROUP_ICON (ID = 14) Grubunu Bul
  for i := 0 to EntriesCount - 1 do
  begin
    if ((Entry^.NameOrID and $80000000) = 0) and (Entry^.NameOrID = 14) then
    begin
      TypeDir := PImageResourceDirectory(BaseAddr + ResOffset + (Entry^.OffsetToData and $7FFFFFFF));
      if (TypeDir^.NumberOfNamedEntries + TypeDir^.NumberOfIdEntries) > 0 then
      begin
        NameDir := PImageResourceDirectory(LongWord(TypeDir) + SizeOf(TImageResourceDirectory));
        LangDir := PImageResourceDirectory(BaseAddr + ResOffset + (PImageResourceDirectoryEntry(NameDir)^.OffsetToData and $7FFFFFFF));
        DataEntry := PImageResourceDataEntry(BaseAddr + ResOffset + PImageResourceDirectoryEntry(LongWord(LangDir) + SizeOf(TImageResourceDirectory))^.OffsetToData);

        GroupDataOffset := RVAToOffset(PEBuffer, DataEntry^.OffsetToData);
        Break;
      end;
    end;
    Inc(Entry);
  end;

  if GroupDataOffset = 0 then Exit;

  // STEP 2: Grubun ��inden En Kaliteli (En Y�ksek bitCount ve Boyut) Ordinal Name'i Se�
  GroupDir := PGRPIconDir(BaseAddr + GroupDataOffset);
  if (GroupDir^.idType <> 1) or (GroupDir^.idCount = 0) then Exit;

  TargetIconID := 0;
  BestBitCount := 0;
  BestWidth := 0;

  for i := 0 to GroupDir^.idCount - 1 do
  begin
    GroupEntry := PGRPIconDirEntry(BaseAddr + GroupDataOffset + 6 + LongWord(i * SizeOf(TGRPIconDirEntry)));

    // Kalite kar��la�t�rmas� (Bit kalitesi y�ksek olan veya ��z�n�rl��� b�y�k olan se�ilir)
    if (GroupEntry^.wBitCount > BestBitCount) or
       ((GroupEntry^.wBitCount = BestBitCount) and (GroupEntry^.bWidth > BestWidth)) then
    begin
      BestBitCount := GroupEntry^.wBitCount;
      BestWidth := GroupEntry^.bWidth;
      TargetIconID := GroupEntry^.nID; // �stenen Ordinal Name (1, 2 vb.)
    end;
  end;

  if TargetIconID = 0 then Exit;

  // STEP 3: TargetIconID ile E�le�en RT_ICON (ID = 3) Kayna��n� Bul
  IconDataOffset := 0;
  Entry := PImageResourceDirectoryEntry(BaseAddr + ResOffset + SizeOf(TImageResourceDirectory));

  for i := 0 to EntriesCount - 1 do
  begin
    if ((Entry^.NameOrID and $80000000) = 0) and (Entry^.NameOrID = 3) then // RT_ICON = 3
    begin
      TypeDir := PImageResourceDirectory(BaseAddr + ResOffset + (Entry^.OffsetToData and $7FFFFFFF));

      // Tip dizinindeki Ordinal ID'ler aras�nda TargetIconID'yi ara
      NameDir := PImageResourceDirectory(LongWord(TypeDir) + SizeOf(TImageResourceDirectory));
      EntriesCount := TypeDir^.NumberOfNamedEntries + TypeDir^.NumberOfIdEntries;

      for x := 0 to EntriesCount - 1 do
      begin
        if PImageResourceDirectoryEntry(NameDir)^.NameOrID = TargetIconID then
        begin
          LangDir := PImageResourceDirectory(BaseAddr + ResOffset + (PImageResourceDirectoryEntry(NameDir)^.OffsetToData and $7FFFFFFF));
          DataEntry := PImageResourceDataEntry(BaseAddr + ResOffset + PImageResourceDirectoryEntry(LongWord(LangDir) + SizeOf(TImageResourceDirectory))^.OffsetToData);
          IconDataOffset := RVAToOffset(PEBuffer, DataEntry^.OffsetToData);
          Break;
        end;
        Inc(NameDir);
      end;
      Break;
    end;
    Inc(Entry);
  end;

  if IconDataOffset = 0 then Exit;

  // STEP 4: �kon Piksellerini DIB Header �zerinden Okuma ve ARGB D�n��t�rme
  BmpHdr := PBitmapInfoHeader(BaseAddr + IconDataOffset);
  OutIcon.Width  := BmpHdr^.biWidth;
  OutIcon.Height := BmpHdr^.biHeight div 2;

  if (OutIcon.Width > 32) or (OutIcon.Height > 32) then
  begin
    OutIcon.Width := 32;
    OutIcon.Height := 32;
  end;

  // Her sat�r 4-byte hizal� olmal�
  RowBytes := ((OutIcon.Width * BmpHdr^.biBitCount + 31) div 32) * 4;
  // AND maskesi (1bpp) sat�r boyutu
  AndRowBytes := ((OutIcon.Width + 31) div 32) * 4;

  PixelPtr := PByte(BaseAddr + IconDataOffset + BmpHdr^.biSize);

  // --- Paletli modlar (8, 4, 1 bit) i�in renk tablosu oku ---
  if BmpHdr^.biBitCount <= 8 then
  begin
    PaletteCount := BmpHdr^.biClrUsed;
    if PaletteCount = 0 then
      PaletteCount := 1 shl BmpHdr^.biBitCount;
    
    for i := 0 to PaletteCount - 1 do
    begin
      Palette[i] := PRGBQuad(PixelPtr)^;
      Inc(PixelPtr, SizeOf(TRGBQuad));
    end;
  end;

  // XOR = renk verisi, AND = �effafl�k maskesi
  XorPtr := PixelPtr;
  AndPtr := PByte(LongWord(XorPtr) + LongWord(RowBytes * OutIcon.Height));

  for y := 0 to OutIcon.Height - 1 do
  begin
    XorRow := PByte(LongWord(XorPtr) + LongWord(y * RowBytes));
    AndRow := PByte(LongWord(AndPtr) + LongWord(y * AndRowBytes));

    for x := 0 to OutIcon.Width - 1 do
    begin
      // AND maskesi: bit 1 = �effaf (transparent), bit 0 = g�r�n�r
      AndByte := PByte(LongWord(AndRow) + LongWord(x shr 3))^;
      if ((AndByte shr (7 - (x and 7))) and 1) = 1 then
      begin
        OutIcon.Pixels[(OutIcon.Height - 1 - y) * 32 + x] := $00000000;
        Continue;
      end;

      case BmpHdr^.biBitCount of
        32: begin
              B := PByte(LongWord(XorRow) + LongWord(x * 4))^;
              G := PByte(LongWord(XorRow) + LongWord(x * 4 + 1))^;
              R := PByte(LongWord(XorRow) + LongWord(x * 4 + 2))^;
              ColorVal := (LongWord(B) shl 16) or (LongWord(G) shl 8) or LongWord(R);
            end;
        24: begin
              B := PByte(LongWord(XorRow) + LongWord(x * 3))^;
              G := PByte(LongWord(XorRow) + LongWord(x * 3 + 1))^;
              R := PByte(LongWord(XorRow) + LongWord(x * 3 + 2))^;
              ColorVal := (LongWord(B) shl 16) or (LongWord(G) shl 8) or LongWord(R);
            end;
        8:  begin
              Idx := PByte(LongWord(XorRow) + LongWord(x))^;
              ColorVal := (LongWord(Palette[Idx].rgbBlue) shl 16) or 
                          (LongWord(Palette[Idx].rgbGreen) shl 8) or
                          LongWord(Palette[Idx].rgbRed);
            end;
        4:  begin
              if (x and 1) = 0 then
                Idx := PByte(LongWord(XorRow) + LongWord(x shr 1))^ shr 4
              else
                Idx := PByte(LongWord(XorRow) + LongWord(x shr 1))^ and $0F;
              ColorVal := (LongWord(Palette[Idx].rgbBlue) shl 16) or 
                          (LongWord(Palette[Idx].rgbGreen) shl 8) or 
                          LongWord(Palette[Idx].rgbRed);
            end;
        1:  begin
              Idx := (PByte(LongWord(XorRow) + LongWord(x shr 3))^ shr (7 - (x and 7))) and 1;
              ColorVal := (LongWord(Palette[Idx].rgbBlue) shl 16) or 
                          (LongWord(Palette[Idx].rgbGreen) shl 8) or
                          LongWord(Palette[Idx].rgbRed);
            end;
      else
        ColorVal := 0;
      end;

      OutIcon.Pixels[(OutIcon.Height - 1 - y) * 32 + x] := ColorVal;
    end;
  end;

  OutIcon.Loaded := True;
  Result := True;
end;


{ �IKARILAN EXE �KONUNU EKRANA ��ZER }
procedure DrawExeIcon(X, Y, Size: Integer; const ExeIcon: TEXEIcon); stdcall;
var
  px, py, srcX, srcY: Integer;
  ColorVal: LongWord;
begin
  if not ExeIcon.Loaded then Exit;

  // 32x32 boyutundaki piksel matrisini belirtilen 'Size' boyutuna �l�ekleyerek �iz
  for py := 0 to Size - 1 do
  begin
    srcY := (py * ExeIcon.Height) div Size;
    for px := 0 to Size - 1 do
    begin
      srcX := (px * ExeIcon.Width) div Size;
      ColorVal := ExeIcon.Pixels[srcY * 32 + srcX];

      // �effaf olmayan pikselleri ekrana bas ($00000000 hari�)
      if ColorVal <> 0 then
        PutPixel(X + px, Y + py, ColorVal);
    end;
  end;
end;

{ GEL��M�� �KON ��Z�C� (Varsay�lan Vekt�r veya �zel EXE �konu) }
procedure DrawIconEx(X, Y, Size: Integer; IconType: TIconType; CustomExeIcon: PEXEIcon = nil); stdcall;
begin
  if (IconType = itExe) and (CustomExeIcon <> nil) and (CustomExeIcon^.Loaded) then
  begin
    // EXE i�inden okunmu� bir �zel ikon varsa onu �iz
    DrawExeIcon(X, Y, Size, CustomExeIcon^);
  end
  else
  begin
    // Aksi halde sistem varsay�lan vekt�r ikonunu �iz
    DrawIcon(X, Y, Size, IconType);
  end;
end;





{=============================================================================}
{ Linked List Yardimcilari }
{=============================================================================}

procedure Desktop_LinkAdd(var First, Last: PDesktopItem; NewItem: PDesktopItem);
begin
  NewItem^.Next := nil;
  NewItem^.Previous := Last;
  if Last <> nil then
    Last^.Next := NewItem
  else
    First := NewItem;
  Last := NewItem;
end;

procedure Desktop_LinkRemove(var First, Last: PDesktopItem; Item: PDesktopItem);
begin
  if Item^.Previous <> nil then
    Item^.Previous^.Next := Item^.Next
  else
    First := Item^.Next;
    
  if Item^.Next <> nil then
    Item^.Next^.Previous := Item^.Previous
  else
    Last := Item^.Previous;
    
  Item^.Next := nil;
  Item^.Previous := nil;
end;

{=============================================================================}
{ Pozisyon Hesaplama }
{=============================================================================}

procedure Desktop_RecalculatePositions;
var
  Cur: PDesktopItem;
  totalMode1Count: Integer;
  mode0Count, mode1Index: Integer;
  m0Col, m0Row, itemsPerCol: Integer;
  m1Col, m1Row, maxCols: Integer;
  actualCols, actualRows: Integer;
  totalGridW, totalGridH, startLeft, startTop: Integer;
begin
  if Desktop = nil then Exit;

  { Mode 1 eleman sayisini say }
  totalMode1Count := 0;
  Cur := Desktop^.FirstItem;
  while Cur <> nil do
  begin
    if Cur^.Mode = 1 then Inc(totalMode1Count);
    Cur := Cur^.Next;
  end;

  { Grid boyutlari }
  maxCols := 8;
  if totalMode1Count > 0 then
  begin
    if totalMode1Count <= maxCols then
    begin
      actualCols := totalMode1Count;
      actualRows := 1;
    end
    else
    begin
      actualCols := maxCols;
      actualRows := (totalMode1Count + maxCols - 1) div maxCols;
    end;
    totalGridW := (actualCols * ICON_WIDTH) + ((actualCols - 1) * ICON_SPACING);
    totalGridH := (actualRows * ICON_HEIGHT) + ((actualRows - 1) * ICON_SPACING);
    startLeft := (Desktop^.ScreenWidth - totalGridW) div 2;
    startTop  := (Desktop^.ScreenHeight - TASKBAR_HEIGHT - totalGridH) div 2;
  end;

  { Mode 0 kolon kapasitesi }
  itemsPerCol := (Desktop^.ScreenHeight - ICON_SPACING * 2 - TASKBAR_HEIGHT)
                 div (ICON_HEIGHT + ICON_SPACING);
  if itemsPerCol <= 0 then itemsPerCol := 1;

  { Listeyi gez ve konumlandir }
  mode0Count := 0;
  mode1Index := 0;
  Cur := Desktop^.FirstItem;
  while Cur <> nil do
  begin
    if Cur^.Mode = 0 then
    begin
      m0Col := mode0Count div itemsPerCol;
      m0Row := mode0Count mod itemsPerCol;
      Cur^.X := ICON_SPACING + (m0Col * (ICON_WIDTH + ICON_SPACING));
      Cur^.Y := ICON_SPACING + (m0Row * (ICON_HEIGHT + ICON_SPACING));
      Inc(mode0Count);
    end
    else if Cur^.Mode = 1 then
    begin
      m1Col := mode1Index mod maxCols;
      m1Row := mode1Index div maxCols;
      Cur^.TargetX := startLeft + m1Col * (ICON_WIDTH + ICON_SPACING);
      Cur^.TargetY := startTop  + m1Row * (ICON_HEIGHT + ICON_SPACING);
      Inc(mode1Index);
    end;
    Cur := Cur^.Next;
  end;
end;

procedure Desktop_UpdateAnimation;
var
  Cur: PDesktopItem;
  StartX, StartY: Integer;
  Factor: Single;
begin
  if (Desktop = nil) or (not Desktop^.IsAnimating) then Exit;

  if Desktop^.IsGridActive then
  begin
    Inc(Desktop^.AnimProgress, 10);
    if Desktop^.AnimProgress >= 100 then
    begin
      Desktop^.AnimProgress := 100;
      Desktop^.IsAnimating := False;
    end;
  end
  else
  begin
    Dec(Desktop^.AnimProgress, 10);
    if Desktop^.AnimProgress <= 0 then
    begin
      Desktop^.AnimProgress := 0;
      Desktop^.IsAnimating := False;
    end;
  end;

  Factor := Desktop^.AnimProgress / 100.0;
  StartX := (Desktop^.ScreenWidth div 2) - (ICON_WIDTH div 2);
  StartY := Desktop^.ScreenHeight - TASKBAR_HEIGHT;

  Cur := Desktop^.FirstItem;
  while Cur <> nil do
  begin
    if Cur^.Mode = 1 then
    begin
      Cur^.X := StartX + Trunc((Cur^.TargetX - StartX) * Factor);
      Cur^.Y := StartY + Trunc((Cur^.TargetY - StartY) * Factor);
    end;
    Cur := Cur^.Next;
  end;
end;

{=============================================================================}
{ Init / Add / Remove }
{=============================================================================}

procedure Desktop_Init(Width, Height: Integer);
begin
  if Desktop = nil then
  begin
    Desktop := PDesktopData(MemAlloc(SizeOf(TDesktopData)));
    if Desktop = nil then Exit;
  end;
  
  FillChar(Desktop^, SizeOf(TDesktopData), 0);
  
  Desktop^.ScreenWidth := Width;
  Desktop^.ScreenHeight := Height;
  Desktop^.FirstItem := nil;
  Desktop^.LastItem := nil;
  Desktop^.ItemCount := 0;
  Desktop^.SelectedItem := nil;
  Desktop^.LastClickItem := nil;
  Desktop^.IsDragging := False;
  Desktop^.DragItem := nil;
end;

function Desktop_AddItem(Title, IconPath: PChar; Mode: Byte;
                         ImageIndex: Integer;
                         Callback: TDesktopItemCallback): PDesktopItem;
var
  Item: PDesktopItem;
begin
  Result := nil;
  if Desktop = nil then Exit;

  Item := PDesktopItem(MemAlloc(SizeOf(TDesktopItem)));
  if Item = nil then Exit;
  
  FillChar(Item^, SizeOf(TDesktopItem), 0);
  
  Item^.Mode := Mode;
  StrCopy(@Item^.Title[0], Title);
  
  if IconPath <> nil then
    StrCopy(@Item^.IconPath[0], IconPath);
    
  Item^.ImageIndex := ImageIndex;
  Item^.Width := ICON_WIDTH;
  Item^.Height := ICON_HEIGHT;
  Item^.Callback := Callback;
  Item^.Selected := False;
  
  Desktop_LinkAdd(Desktop^.FirstItem, Desktop^.LastItem, Item);
  Inc(Desktop^.ItemCount);
  
  Desktop_RecalculatePositions;
  
  Result := Item;
end;

procedure Desktop_RemoveItem(Item: PDesktopItem);
begin
  if Desktop = nil then Exit;
  if Item = nil then Exit;

  if Item^.IconBitmap <> nil then
  begin
    // TODO: Free bitmap
  end;
  
  { Referanslari temizle }
  if Desktop^.SelectedItem = Item then Desktop^.SelectedItem := nil;
  if Desktop^.LastClickItem = Item then Desktop^.LastClickItem := nil;
  if Desktop^.DragItem = Item then
  begin
    Desktop^.DragItem := nil;
    Desktop^.IsDragging := False;
  end;
  
  Desktop_LinkRemove(Desktop^.FirstItem, Desktop^.LastItem, Item);
  Dec(Desktop^.ItemCount);
  
  FreeMem(Item);
  
  Desktop_RecalculatePositions;
end;

{=============================================================================}
{ Cizim }
{=============================================================================}

procedure Desktop_DrawIcon(Item: PDesktopItem);
var
  iconX, iconY: Integer;
  textX, textY: Integer;
  textW: Integer;
  bgColor: LongWord;
begin
  if Item = nil then Exit;

  iconX := Item^.X + (ICON_WIDTH - 32) div 2;
  iconY := Item^.Y;

  if Item^.Selected then
  begin
    bgColor := $00800080;
    KFill(Item^.X, Item^.Y, Item^.Width, Item^.Height, bgColor);
  end;

  if Item^.IsExe  then
  begin
     DrawIconEx(iconX, iconY, 48, itExe, @Item^.EXEIcon);
     KStrCentered(iconX - 4, iconY + 48 + 4, 48 + 8,Item^.Title, clWhite);
  end
  else
  begin
    DrawIcon(iconX, iconY, 48, TIconType(Item^.ImageIndex));
    KStrCentered(iconX - 4, iconY + 48 + 4, 48 + 8,Item^.Title, clWhite);
  end;


end;

procedure Desktop_Render;
var
  Cur: PDesktopItem;
begin
  if Desktop = nil then Exit;

  if Desktop^.IsAnimating then
    Desktop_UpdateAnimation;

  if Desktop^.IsGridActive or (Desktop^.AnimProgress > 0) then
    DrawTransparentRect((SCREEN_WIDTH - 640) div 2, (SCREEN_HEIGHT - 480) div 2,
      640, 480, clBlack, 75);

  Cur := Desktop^.FirstItem;
  while Cur <> nil do
  begin
    if Cur^.Mode = 0 then
      Desktop_DrawIcon(Cur)
    else if (Cur^.Mode = 1) and (Desktop^.IsGridActive or (Desktop^.AnimProgress > 0)) then
      Desktop_DrawIcon(Cur);
    Cur := Cur^.Next;
  end;
end;

{=============================================================================}
{ Hit Test & Olaylar }
{=============================================================================}

function Desktop_HitTest(X, Y: Integer): PDesktopItem;
var
  Cur: PDesktopItem;
begin
  Result := nil;
  if Desktop = nil then Exit;

  Cur := Desktop^.FirstItem;
  while Cur <> nil do
  begin
    if (Cur^.Mode = 0) or 
       ((Cur^.Mode = 1) and Desktop^.IsGridActive and (Desktop^.AnimProgress = 100)) then
    begin
      if (X >= Cur^.X) and (X < Cur^.X + Cur^.Width) and
         (Y >= Cur^.Y) and (Y < Cur^.Y + Cur^.Height) then
      begin
        Result := Cur;
        Exit;
      end;
    end;
    Cur := Cur^.Next;
  end;
end;

procedure Desktop_ToggleGridMode;
begin
  if Desktop = nil then Exit;
  Desktop^.IsGridActive := not Desktop^.IsGridActive;
  Desktop^.IsAnimating := True;
end;

procedure Desktop_HandleClick(X, Y: Integer);
var
  Cur, Hit: PDesktopItem;
begin
  if Desktop = nil then Exit;

  Hit := Desktop_HitTest(X, Y);

  { Tumunu deselect et }
  Cur := Desktop^.FirstItem;
  while Cur <> nil do
  begin
    Cur^.Selected := False;
    Cur := Cur^.Next;
  end;
  
  if Hit <> nil then
  begin
    Hit^.Selected := True;
    Desktop^.SelectedItem := Hit;
    
    Desktop^.IsDragging := True;
    Desktop^.DragItem := Hit;
    Desktop^.DragOffsetX := X - Hit^.X;
    Desktop^.DragOffsetY := Y - Hit^.Y;
    
    Desktop^.LastClickItem := Hit;
    Desktop^.LastClickTime := GetTickCount;
  end
  else
  begin
    Desktop^.SelectedItem := nil;
    Desktop^.IsDragging := False;
    Desktop^.DragItem := nil;
  end;
end;

function Desktop_HandleDoubleClick(X, Y: Integer): Boolean;
var
  Hit: PDesktopItem;
begin
  Result := False;
  if Desktop = nil then Exit;

  Hit := Desktop_HitTest(X, Y);
  if Hit = nil then Exit;

  if Assigned(Hit^.Callback) then
  begin
    Hit^.Callback(Hit);
    Result := True;
  end;

  Desktop^.LastClickItem := Hit;
  Desktop^.LastClickTime := GetTickCount;
end;

procedure Desktop_HandleMouseMove(X, Y: Integer);
var
  newX, newY: Integer;
  maxX, maxY: Integer;

  Hit: PDesktopItem;
begin
   if Desktop = nil then Exit;

  Hit := Desktop_HitTest(X, Y);
  if Hit<> nil then Hit^.Selected:=True;

  

  if Desktop^.IsDragging and (Desktop^.DragItem <> nil) then
  begin
    newX := X - Desktop^.DragOffsetX;
    newY := Y - Desktop^.DragOffsetY;
    
    maxX := Desktop^.ScreenWidth - Desktop^.DragItem^.Width;
    maxY := Desktop^.ScreenHeight - Desktop^.DragItem^.Height - TASKBAR_HEIGHT;
    
    if newX < 0 then newX := 0;
    if newX > maxX then newX := maxX;
    if newY < 0 then newY := 0;
    if newY > maxY then newY := maxY;
    
    Desktop^.DragItem^.X := newX;
    Desktop^.DragItem^.Y := newY;
  end;
end;

procedure Desktop_HandleMouseUp(X, Y: Integer);
begin
  if Desktop = nil then Exit;
  Desktop^.IsDragging := False;
  Desktop^.DragItem := nil;
end;

procedure Desktop_HandleRightClick(X, Y: Integer);
begin
  // Desktop sag tik context menu
end;

{=============================================================================}
{ Callback'ler (Yeni imza: procedure(Item: PDesktopItem)) }
{=============================================================================}

procedure OnPaintBoxClick(Item: PDesktopItem);
begin
end;

procedure OnSysInfoClick(Item: PDesktopItem);
begin
end;

procedure OnWebBrowserClick(Item: PDesktopItem);
begin
end;

procedure OnDiskInfoClick(Item: PDesktopItem);
begin
  OpenHDDForm();
end;

procedure OnTaskMgClick(Item: PDesktopItem);
begin
 CreateProcessListForm;
end;


procedure OnMemoryClick(Item: PDesktopItem);
begin
  OpenMemoryForm;
end;

procedure OnMyComputerClick(Item: PDesktopItem);
begin
  CreateDirectoryView(Nil);
end;

procedure OnMyPicturesClick(Item: PDesktopItem);
begin
 // CreateDirectoryView('C:\Images\');
  CreateDirectoryView('D:\');
end;

procedure OnMyMusicClick(Item: PDesktopItem);
begin
  CreateDirectoryView('C:\Sounds\');
end;

procedure OnMyDrectoryClick(Item: PDesktopItem);
begin
  CreateDirectoryView('C:\');
end;



procedure OnPaintApp(Item: PDesktopItem);
begin
 // OpenPaintApp;
 OpenPaintBox();
end;

procedure OnSettingsApp(Item: PDesktopItem);
begin
  OpenSettings;
end;

procedure OnTerminalApp(Item: PDesktopItem);
begin
  OpenTerminal;
end;

procedure OnTHTTPServerApp(Item: PDesktopItem);
begin
 OpenHTTPServerForm;

 
end;

procedure OnWebBrowserApp(Item: PDesktopItem);
begin
 OpenMjpegServerForm;
 // OpenWebBrowserForm;
end;

procedure OnCalculatorApp(Item: PDesktopItem);
begin
  OpenCalculator;
end;


procedure OnClockApp(Item: PDesktopItem);
begin
  OpenClockForm;
end;


procedure OnBasicApp(Item: PDesktopItem);
begin
  OpenBasic();
end;


procedure OnNetAdapterApp(Item: PDesktopItem);
begin
  CreateNetAdapterForm();
end;


{=============================================================================}
{ Desktop Baslangic itMyComputer}
{=============================================================================}

procedure InitDesktop;
begin
  Desktop_AddItem('My Computer',   nil, 0, Ord(itMyComputer), @OnMyComputerClick);
  Desktop_AddItem('Resimler',      nil, 0, Ord(itPictures),   @OnMyPicturesClick);
  Desktop_AddItem('Muzikler',      nil, 0, Ord(itMusic),     @OnMyMusicClick);
  Desktop_AddItem('Belgeler',      nil, 0, Ord(itFiles),  @OnMyDrectoryClick);
  Desktop_AddItem('Sys Ram',       nil, 0, Ord(itRAM),     @OnMemoryClick);
  Desktop_AddItem('Disk Info',     nil, 0, Ord(itHDD),        @OnDiskInfoClick);
  Desktop_AddItem('TaskMgr',       nil, 0, Ord(itZip),    @OnTaskMgClick);
  Desktop_AddItem('Geri Donusum',  nil, 0, Ord(itRecycleBin1), nil);
  Desktop_AddItem('Control Pnl',   nil, 0, Ord(itSettings),   @OnSettingsApp);
  Desktop_AddItem('Paint',         nil, 0, Ord(itPaint),      @OnPaintApp);
  Desktop_AddItem('Terminal',      nil, 0, Ord(itTerminal),      @OnTerminalApp);
  Desktop_AddItem('HttpServer',    nil, 0, Ord(itHttpServer),      @OnTHTTPServerApp);
  Desktop_AddItem('WebBrowser',    nil, 0, Ord(itWebBrowser),      @OnWebBrowserApp);
  Desktop_AddItem('Calculator',    nil, 0, Ord(itCalculator),      @OnCalculatorApp);
  Desktop_AddItem('Basic',    nil, 0, Ord(itTerminal),      @OnBasicApp);
  Desktop_AddItem('Clock',    nil, 0, Ord(itClock),      @OnClockApp);
  Desktop_AddItem('NetAdapter',    nil, 0, Ord(itNetwork),      @OnNetAdapterApp);
 

 { Desktop_AddItem('System HDD',    nil, 1, DI_HDD,      nil);
  Desktop_AddItem('System Memory', nil, 1, DI_MEMORY,   nil);
  Desktop_AddItem('Web Browser',   nil, 1, DI_BROWSER,  @OnWebBrowserClick);
  Desktop_AddItem('PaintBox',      nil, 1, DI_PAINT,    @OnPaintBoxClick);
  Desktop_AddItem('Calculator',    nil, 1, DI_CALC,     nil);
  Desktop_AddItem('Text Editor',   nil, 1, DI_TEXTEDIT, nil);
  Desktop_AddItem('Network',       nil, 1, DI_NETWORK,  nil); }
end;




end.

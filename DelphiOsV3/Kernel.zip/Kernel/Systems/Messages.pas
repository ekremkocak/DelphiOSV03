unit Messages;

interface

uses
  SysUtils, Memory, Draw32, Vesa, GUI, GUIControls, Fat32;

type


  TMsgDlgType = (mtWarning, mtError, mtInformation, mtConfirmation, mtCustom);
  TMsgDlgBtn = (mbYes, mbNo, mbOK, mbCancel, mbAbort, mbRetry, mbIgnore,
                mbAll, mbNoToAll, mbYesToAll, mbHelp, mbClose);
  TMsgDlgButtons = set of TMsgDlgBtn;

  TModalResult = (mrNone, mrOk, mrCancel, mrAbort, mrRetry, mrIgnore,
                  mrYes, mrNo, mrAll, mrNoToAll, mrYesToAll, mrClose);

  PFileDialogData=^TFileDialogData;
   TFileDialogData = record
    CurrentPath: array[0..255] of Char;
    LV: PListView;
    Ed: PEdit;
    IsSave: Boolean;
    LblPath: PLabel;
    BtnBack, BtnForward, BtnUp, BtnRefresh: PButton;
    History: array[0..15] of array[0..255] of Char;
    HistoryPos: Integer;
    HistoryCount: Integer;
    { --- Filtre alanlari --- }
    FilterCombo: PComboBox;
    FilterPattern: array[0..15] of Char;
  end;


procedure ShowMessage(const Msg: PChar);
function MessageDlg(const Msg: PChar; DlgType: TMsgDlgType;
                    Buttons: TMsgDlgButtons): TModalResult;

function InputBox(const ACaption, APrompt, ADefault: PChar): PChar;

function OpenDlg(const Title: PChar; const StartPath: PChar): PForm;
function SaveDlg(const Title: PChar; const StartPath: PChar ): Boolean;

function GetDlgModalResult(Form: PForm): Integer;
function GetInputBoxText(Form: PForm): PChar;
function GetDlgFileName(Form: PForm): PChar;


procedure RefreshFileListFromPath(Data: PFileDialogData);

implementation

var
  ModalResult: TModalResult;
  ModalActive: Boolean;

procedure RunModalLoop;
begin
  ModalActive := True;
  while ModalActive do
    WinManager.ProcessMessages(False);
end;

procedure EndModal(ResultCode: TModalResult);
begin
  ModalResult := ResultCode;
  ModalActive := False;
end;

// -----------------------------------------------------------------------------
// Generic dialog button handler (sets Tag on owner form)
// -----------------------------------------------------------------------------
procedure DlgButtonClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
begin
  F := FindRootForm(Sender);
  if F <> nil then
    F^.Tag := PButton(Sender)^.Tag; // store modal result as integer tag
end;

// -----------------------------------------------------------------------------
// MessageDlg / ShowMessage
// -----------------------------------------------------------------------------

procedure ShowMessageClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
begin
  // determine modal result from button tag
  case PButton(Sender)^.Tag of
    1: EndModal(mrOk);
    2: EndModal(mrCancel);
    3: EndModal(mrAbort);
    4: EndModal(mrRetry);
    5: EndModal(mrIgnore);
    6: EndModal(mrYes);
    7: EndModal(mrNo);
  end;

  // Remove the dialog form (message boxes auto-close)
  F := FindRootForm(Sender);
  if F <> nil then
    WinManager.RemoveForm(F);
end;

function MessageDlg(const Msg: PChar; DlgType: TMsgDlgType;
                    Buttons: TMsgDlgButtons): TModalResult;
var
  F: PForm;
  Lbl: PLabel;
  BtnLeft, BtnTop, BtnW: Integer;
  // temporary buttons
  B: array[0..5] of PButton;
  bi: Integer;

  title: array[0..63] of Char;
begin
  // Title text by type
  case DlgType of
    mtWarning: Move('Warning'#0, title, 8);
    mtError: Move('Error'#0, title, 6);
    mtInformation: Move('Information'#0, title, 12);
    mtConfirmation: Move('Confirm'#0, title, 8);
  else
    Move('Message'#0, title, 8);
  end;

  // Create dialog form centered, modest size based on message length
  F := CreateForm(@title[0],
        (SCREEN_WIDTH - 420) div 2, (SCREEN_HEIGHT - 170) div 2,
        420, 170,bsDialog);
  if F = nil then
  begin
    Result := mrCancel;
    Exit;
  end;

  F^.BorderStyle := bsDialog;
  F^.Modal := True;
  F^.ShowSysButtons := False;
  F^.Tag := 0;
  F^.Color := clBtnFace;

  // Make header visually nicer: gradient done by DrawForm hook already
  // Message label (centered)
  Lbl := CreateLabel(PObject(F), Msg, 16, 40, F^.Width - 32, 64, alNone);
  Lbl^.Transparent := True;
  Lbl^.Alignment := 1;

  // Buttons: align to bottom-right with spacing
  BtnTop := F^.Height - 48-8;
  BtnW := 90;
  BtnLeft := F^.Width - 16 - BtnW-8;

  bi := 0;
  // Use order: OK, Yes, No, Cancel, Retry, Abort, Ignore
  if mbOK in Buttons then
  begin
    B[bi] := CreateButton(PObject(F), 'OK', BtnLeft, BtnTop, BtnW, 30, alNone);
    B[bi]^.Tag := 1; B[bi]^.BindMouseUp(@ShowMessageClick);
    Dec(BtnLeft, BtnW + 8); Inc(bi);
  end;
  if mbYes in Buttons then
  begin
    B[bi] := CreateButton(PObject(F), 'Yes', BtnLeft, BtnTop, BtnW, 30, alNone);
    B[bi]^.Tag := 6; B[bi]^.BindMouseUp(@ShowMessageClick);
    Dec(BtnLeft, BtnW + 8); Inc(bi);
  end;
  if mbNo in Buttons then
  begin
    B[bi] := CreateButton(PObject(F), 'No', BtnLeft, BtnTop, BtnW, 30, alNone);
    B[bi]^.Tag := 7; B[bi]^.BindMouseUp(@ShowMessageClick);
    Dec(BtnLeft, BtnW + 8); Inc(bi);
  end;
  if mbCancel in Buttons then
  begin
    B[bi] := CreateButton(PObject(F), 'Cancel', BtnLeft, BtnTop, BtnW, 30, alNone);
    B[bi]^.Tag := 2; B[bi]^.BindMouseUp(@ShowMessageClick);
    Dec(BtnLeft, BtnW + 8); Inc(bi);
  end;
  if mbRetry in Buttons then
  begin
    B[bi] := CreateButton(PObject(F), 'Retry', BtnLeft, BtnTop, BtnW, 30, alNone);
    B[bi]^.Tag := 4; B[bi]^.BindMouseUp(@ShowMessageClick);
    Dec(BtnLeft, BtnW + 8); Inc(bi);
  end;
  if mbAbort in Buttons then
  begin
    B[bi] := CreateButton(PObject(F), 'Abort', BtnLeft, BtnTop, BtnW, 30, alNone);
    B[bi]^.Tag := 3; B[bi]^.BindMouseUp(@ShowMessageClick);
    Dec(BtnLeft, BtnW + 8); Inc(bi);
  end;

  // Start modal loop
  ModalResult := mrNone;
  RunModalLoop;

  Result := ModalResult;
end;

procedure ShowMessage(const Msg: PChar);
begin
  MessageDlg(Msg, mtInformation, [mbOK]);
end;

// -----------------------------------------------------------------------------
// InputBox
// -----------------------------------------------------------------------------

var
  gInputEdit: PEdit;

procedure InputBoxBtnClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;

  if PButton(Sender)^.Tag = 1 then
  begin
    // OK: copy edit text to returned buffer
    EndModal(mrOk);
  end
  else
  begin
    EndModal(mrCancel);
  end;

  WinManager.RemoveForm(F);
end;

function InputBox(const ACaption, APrompt, ADefault: PChar): PChar;
var
  F: PForm;
  Lbl: PLabel;
  BtnOK, BtnCancel: PButton;
  i: Integer;
  tmp: array[0..255] of Char;
begin
  Result := nil;

  F := CreateForm(ACaption, (SCREEN_WIDTH - 480) div 2, (SCREEN_HEIGHT - 180) div 2, 480, 180);
  if F = nil then Exit;

  F^.BorderStyle := bsDialog;
  F^.Modal := True;
  F^.ShowSysButtons := False;
  F^.Color := clBtnFace;

  Lbl := CreateLabel(PObject(F), APrompt, 12, 22, F^.Width - 24, 20, alNone);
  Lbl^.Transparent := True;
  Lbl^.Alignment := 0;

  gInputEdit := CreateEdit(PObject(F), 12, 50, F^.Width - 64, 24, alNone);
  if ADefault <> nil then EditSetText(gInputEdit, ADefault);

  BtnOK := CreateButton(PObject(F), 'OK', F^.Width - 250, F^.Height - 62, 80, 30, alNone);
  BtnOK^.Tag := 1; BtnOK^.BindMouseUp(@InputBoxBtnClick);
  BtnCancel := CreateButton(PObject(F), 'Cancel', F^.Width - 150, F^.Height - 62, 80, 30, alNone);
  BtnCancel^.Tag := 2; BtnCancel^.BindMouseUp(@InputBoxBtnClick);

  ModalResult := mrNone;
  RunModalLoop;

  if ModalResult = mrOk then
  begin
    // allocate and return copy
    StrCopy(@tmp[0], @gInputEdit^.Text[0]);
    Result := MemAlloc(StrLen(@tmp[0]) + 1);
    StrCopy(Result, @tmp[0]);
  end;
end;

function GetInputBoxText(Form: PForm): PChar;
var
  Ed: PEdit;
begin
  Result := nil;
  if Form = nil then Exit;
  if Form^.ActiveControl <> nil then
  begin
    Ed := PEdit(Form^.ActiveControl);
    Result := @Ed^.Text[0];
  end;
end;

// -----------------------------------------------------------------------------
// OpenDlg / SaveDlg - FAT32 aware
// -----------------------------------------------------------------------------



{=============================================================================}
{ Toolbar Gorsel & Navigasyon Yardimcilari                                    }
{=============================================================================}

procedure FileDlgToolbarDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;

  KGradientV(AbsX, AbsY, W, H, $00F0EEE4, $00C8C4B8);
  KLineH(AbsX, AbsY, W, $00FCFCF8);
  KLineH(AbsX, AbsY + H - 1, W, cl3DShadow);
end;

{ Adres cubugu: gomulu (sunken) kutu + kucuk klasor ikonu (DirectoryView ile
  ayni gorsel dil - tutarlilik icin) }
procedure FileDlgPathBarDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;

  KFill(AbsX, AbsY, W, H, clWhite);
  KRect3D(AbsX, AbsY, W, H, False);

  KFill(AbsX + 5, AbsY + 5, 3, 3, $0060A0F0);
  KFill(AbsX + 4, AbsY + 7, 15, 10, $0060A0F0);
  KRect(AbsX + 4, AbsY + 7, 15, 10, $00305078);
end;

{ Alt panelin ust kenarina ince bir ayirici + hafif gradyan }
procedure FileDlgBottomPanelDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;

  KFill(AbsX, AbsY, W, H, clBtnFace);
  KLineH(AbsX, AbsY, W, clWhite);
  KLineH(AbsX, AbsY + 1, W, cl3DShadow);
end;

{ Dosya adi kutusunun solundaki kucuk "dosya" simgesi }
procedure FileDlgFileIconDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;

  KFill(AbsX + 4, AbsY + 2, W - 8, H - 4, clWhite);
  KRect(AbsX + 4, AbsY + 2, W - 8, H - 4, cl3DShadow);
  KLineH(AbsX + 8, AbsY + 8,  W - 16, cl3DShadow);
  KLineH(AbsX + 8, AbsY + 13, W - 16, cl3DShadow);
end;

procedure FileDlgUpdatePathLabel(Data: PFileDialogData);
begin
  if (Data = nil) or (Data^.LblPath = nil) then Exit;
  Data^.LblPath^.Caption[0] := #0;
  StrAppend(@Data^.LblPath^.Caption[0], @Data^.CurrentPath[0]);
end;

procedure FileDlgUpdateNavButtons(Data: PFileDialogData);
begin
  if Data = nil then Exit;
  if Data^.BtnBack     <> nil then Data^.BtnBack^.Enabled     := Data^.HistoryPos > 0;
  if Data^.BtnForward  <> nil then Data^.BtnForward^.Enabled  := Data^.HistoryPos < Data^.HistoryCount - 1;
  if Data^.BtnUp       <> nil then Data^.BtnUp^.Enabled       :=
    (StrLen(@Data^.CurrentPath[0]) > 1) and (Data^.CurrentPath[0] <> #0);
end;

procedure FileDlgAddToHistory(Data: PFileDialogData; const Path: PChar);
begin
  if Data = nil then Exit;
  { Ileriye dogru gitmissek, aradaki gecmisi sil }
  if Data^.HistoryPos < Data^.HistoryCount - 1 then
    Data^.HistoryCount := Data^.HistoryPos + 1;

  if Data^.HistoryCount < 16 then
  begin
    StrCopy(@Data^.History[Data^.HistoryCount][0], Path);
    Inc(Data^.HistoryCount);
    Inc(Data^.HistoryPos);
  end
  else
  begin
    Move(Data^.History[1], Data^.History[0], 15 * 256);
    StrCopy(@Data^.History[15][0], Path);
    Data^.HistoryPos := 15;
  end;
end;

{ --- Buton Click Handlerlari --- }

procedure FileDlgGoBack(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PFileDialogData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PFileDialogData(F^.Data);
  if Data = nil then Exit;
  if Data^.HistoryPos <= 0 then Exit;

  Dec(Data^.HistoryPos);
  StrCopy(@Data^.CurrentPath[0], @Data^.History[Data^.HistoryPos][0]);
  RefreshFileListFromPath(Data);
end;

procedure FileDlgGoForward(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PFileDialogData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PFileDialogData(F^.Data);
  if Data = nil then Exit;
  if Data^.HistoryPos >= Data^.HistoryCount - 1 then Exit;

  Inc(Data^.HistoryPos);
  StrCopy(@Data^.CurrentPath[0], @Data^.History[Data^.HistoryPos][0]);
  RefreshFileListFromPath(Data);
end;

procedure FileDlgGoUp(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PFileDialogData;
  newPath: array[0..255] of Char;
  len: Integer;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PFileDialogData(F^.Data);
  if Data = nil then Exit;

  StrCopy(@newPath[0], @Data^.CurrentPath[0]);
  len := StrLen(newPath);
  if len > 1 then
  begin
    if newPath[len-1] = '\' then begin newPath[len-1] := #0; Dec(len); end;
    while (len > 1) and (newPath[len-1] <> '\') do
    begin
      newPath[len-1] := #0;
      Dec(len);
    end;
  end;

  if StrCmp(@newPath[0], @Data^.CurrentPath[0]) <> 0 then
  begin
    StrCopy(@Data^.CurrentPath[0], @newPath[0]);
    FileDlgAddToHistory(Data, @Data^.CurrentPath[0]);
    RefreshFileListFromPath(Data);
  end;
end;

procedure FileDlgRefresh(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PFileDialogData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PFileDialogData(F^.Data);
  if Data = nil then Exit;
  RefreshFileListFromPath(Data);
end;

{ Yerlesim sabitleri (DirectoryView ile tutarli) }
const
  FD_TOOLBAR_H = 34;
  FD_MARGIN    = 10;
  FD_BTN_W     = 30;
  FD_BTN_H     = 24;
  FD_BTN_GAP   = 4;

{ Toolbar olusturma (Open/Save ortak) }
procedure FileDlgCreateToolbar(F: PForm; Data: PFileDialogData);
var
  Toolbar, PathBar: PPanel;
  Btn: PButton;
  bx, by: Integer;
begin
  Toolbar := CreatePanel(PObject(F), 0, 0, 0, FD_TOOLBAR_H, alTop);
  Toolbar^.Color := $00D4D0C8;
  Toolbar^.BorderWidth := 0;
  Toolbar^.ShowCaption := False;
  Toolbar^.BindPaint(@FileDlgToolbarDraw);

  by := (FD_TOOLBAR_H - FD_BTN_H) div 2;
  bx := FD_MARGIN;

  { Geri }
  Btn := CreateButton(PObject(Toolbar), '<', bx, by, FD_BTN_W, FD_BTN_H, alNone);
  Btn^.BindMouseUp(@FileDlgGoBack);
  Data^.BtnBack := Btn;
  Inc(bx, FD_BTN_W + FD_BTN_GAP);

  { Ileri }
  Btn := CreateButton(PObject(Toolbar), '>', bx, by, FD_BTN_W, FD_BTN_H, alNone);
  Btn^.BindMouseUp(@FileDlgGoForward);
  Data^.BtnForward := Btn;
  Inc(bx, FD_BTN_W + FD_BTN_GAP + 10);

  { Yukari }
  Btn := CreateButton(PObject(Toolbar), #24, bx, by, FD_BTN_W, FD_BTN_H, alNone);  { ^ oku }
  Btn^.BindMouseUp(@FileDlgGoUp);
  Data^.BtnUp := Btn;
  Inc(bx, FD_BTN_W + FD_BTN_GAP);

  { Yenile }
  Btn := CreateButton(PObject(Toolbar), 'R', bx, by, FD_BTN_W, FD_BTN_H, alNone);
  Btn^.BindMouseUp(@FileDlgRefresh);
  Data^.BtnRefresh := Btn;
  Inc(bx, FD_BTN_W + FD_BTN_GAP + 8);

  { Adres cubugu (gomulu kutu + klasor ikonu), kalan tum genisligi kaplar }
  PathBar := CreatePanel(PObject(Toolbar), bx, (FD_TOOLBAR_H - 22) div 2,
                         Toolbar^.Width - bx - FD_MARGIN, 22, alNone);
  PathBar^.BorderWidth := 0;
  PathBar^.ShowCaption := False;
  PathBar^.BindPaint(@FileDlgPathBarDraw);

  Data^.LblPath := CreateLabel(PObject(PathBar), '', 24, 3,
                               PathBar^.Width - 30, 16, alNone);
  Data^.LblPath^.Transparent := True;
  Data^.LblPath^.Alignment := 0;
end;

{=============================================================================}
{ Filtre Combobox Handleri                                                    }
{=============================================================================}


procedure FileDlgFilterChanged(Sender: PObject);
var
  CB: PComboBox;
  F: PForm;
  Data: PFileDialogData;
begin
  CB := PComboBox(Sender);
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PFileDialogData(F^.Data);
  if Data = nil then Exit;

  case CB^.ItemIndex of
    0: StrCopy(@Data^.FilterPattern[0], '*');
    1: StrCopy(@Data^.FilterPattern[0], '*.TXT');
    2: StrCopy(@Data^.FilterPattern[0], '*.EXE');
    3: StrCopy(@Data^.FilterPattern[0], '*.BMP');
  else
    StrCopy(@Data^.FilterPattern[0], '*');
  end;

  RefreshFileListFromPath(Data);
end;

{=============================================================================}
{ Filtre Combobox Olusturma (Open/Save ortak)                                 }
{=============================================================================}

procedure FileDlgCreateFilterCombo(Parent: PObject; Data: PFileDialogData);
begin
  CreateLabel(Parent, 'Tur:', FD_MARGIN + 28, 50, 50, 20, alNone);
  Data^.FilterCombo := CreateComboBox(Parent, FD_MARGIN + 80, 50, Parent^.Width - (FD_MARGIN + 80) - 110, 22, alNone);
  ComboBoxAddItem(Data^.FilterCombo, 'Tum Dosyalar (*.*)');
  ComboBoxAddItem(Data^.FilterCombo, 'Metin Dosyalari (*.txt)');
  ComboBoxAddItem(Data^.FilterCombo, 'Programlar (*.exe)');
  ComboBoxAddItem(Data^.FilterCombo, 'Pascal Kaynaklari (*.bmp)');
  Data^.FilterCombo^.ItemIndex := 0;
  StrCopy(@Data^.FilterPattern[0], '*');

  { YENI: Artik OnChange ile calisiyor }
  Data^.FilterCombo^.FOnChange := @FileDlgFilterChanged;
end;

procedure RefreshFileListFromPath(Data: PFileDialogData);
var
  hFind: Integer;
  rec: TSearchRec;
  pathBuf: array[0..255] of Char;
  patt: array[0..31] of Char;
begin
  if Data = nil then Exit;
  ListViewClear(Data^.LV);

  { [..] ekle (kok dizinde degilse) }
 // if Data^.CurrentPath[0] <> '\' then
  //  ListViewAddItem(Data^.LV, '[..]');

  { Dizin yolunu hazirla }
  StrCopy(@pathBuf[0], @Data^.CurrentPath[0]);
  if pathBuf[StrLen(pathBuf)-1] <> '\' then
    StrAppend(@pathBuf[0], '\');

  { === 1. Dizinleri listele (her zaman tumu) === }
  StrCopy(@patt[0], '*');
  hFind := FindFirst(@pathBuf[0], @patt[0], ATTR_DIRECTORY or $3F, @rec);
  if hFind >= 0 then
  begin
    repeat
      if rec.IsDir and (rec.Name[0] <> '.') then
        ListViewAddItem(Data^.LV, rec.Name);
    until not FindNext(hFind, @rec);
    FindClose(hFind);
  end;

  { === 2. Dosyalari listele (filtre uygula) === }
  StrCopy(@patt[0], @Data^.FilterPattern[0]);
  hFind := FindFirst(@pathBuf[0], @patt[0], ATTR_DIRECTORY or $3F, @rec);
  if hFind >= 0 then
  begin
    repeat
      if not rec.IsDir then
        ListViewAddItem(Data^.LV, rec.Name);
    until not FindNext(hFind, @rec);
    FindClose(hFind);
  end;

  { Guncelle }
  FileDlgUpdatePathLabel(Data);
  FileDlgUpdateNavButtons(Data);
  RelayoutForm(FindRootForm(PObject(Data^.LV)));
end;


procedure FileListDblClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  LV: PListView;
  F: PForm;
  Data: PFileDialogData;
  Sel: Integer;
  selName: PChar;
  newPath: array[0..255] of Char;
  entry: TDirEntry;
begin
  LV := PListView(Sender);
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PFileDialogData(F^.Data); // we will store dialog data in form^.Control
  if Data = nil then Exit;

  Sel := LV^.ItemIndex;
  if Sel < 0 then Exit;
  selName := LV^.Items^[Sel];
  if selName = nil then Exit;

  // Directory?
  if selName[0] = '[' then
  begin
    // parent directory
    if StrCmp(selName, '[..]') = 0 then
    begin
      // remove last path component
      StrCopy(@newPath[0], @Data^.CurrentPath[0]);
      if StrLen(newPath) > 1 then
      begin
        // strip trailing backslash if present
        if newPath[StrLen(newPath)-1] = '\' then
          newPath[StrLen(newPath)-1] := #0;
        // find previous backslash
        while (StrLen(newPath) > 1) and (newPath[StrLen(newPath)-1] <> '\') do
          newPath[StrLen(newPath)-1] := #0;
        if newPath[StrLen(newPath)-1] <> '\' then
          StrAppend(@newPath[0], '\');
      end;
      StrCopy(@Data^.CurrentPath[0], @newPath[0]);
      RefreshFileListFromPath(Data);
      Exit;
    end;
  end;

  // If selected is directory -> change into it
  // We'll do a conservative check: if name has no dot or FindFirst says it's directory
  // But we know ListView contains both; better to check via FAT32_FindFirst
  // Build candidate path
  StrCopy(@newPath[0], @Data^.CurrentPath[0]);
  if newPath[StrLen(newPath)-1] <> '\' then StrAppend(@newPath[0], '\');
  StrAppend(@newPath[0], selName);

  // Attempt to resolve path via FAT32

  if FAT32_ResolvePath(0, @newPath[0], @entry) then
  begin
    if (entry.Attr and ATTR_DIRECTORY) <> 0 then
    begin
      // change directory
      StrCopy(@Data^.CurrentPath[0], @newPath[0]);
      FileDlgAddToHistory(Data, @Data^.CurrentPath[0]);   { YENI }
      RefreshFileListFromPath(Data);
      Exit;
    end;
  end;

  // Otherwise it's a file: set edit text and finish (double-click opened)
  if Data^.Ed <> nil then
    EditSetText(Data^.Ed, selName);

  EndModal(mrOk);
  WinManager.RemoveForm(F);
end;

procedure FileListClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  LV: PListView;
  F: PForm;
  Data: PFileDialogData;
  Sel: Integer;
  PName: PChar;
begin
  LV := PListView(Sender);
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PFileDialogData(F^.Data);
  if Data = nil then Exit;

  Sel := LV^.ItemIndex;
  if Sel < 0 then Exit;
  PName := LV^.Items^[Sel];
  if PName = nil then Exit;

  // set edit text for file selection
  if PName[0] = '[' then Exit;
  EditSetText(Data^.Ed, PName);
end;

procedure OpenDlgBtnClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PFileDialogData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PFileDialogData(F^.Data);
  if Data = nil then Exit;

  if PButton(Sender)^.Tag = 1 then
  begin
    // OK
    EndModal(mrOk);
  end
  else
    EndModal(mrCancel);

  WinManager.RemoveForm(F);
end;

{=============================================================================}
{ FileDialog Bellek Temizligi (BindDestroy ile)                               }
{=============================================================================}

procedure FileDialogDestroy(Sender: PObject);
var
  F: PForm;
  Data: PFileDialogData;
begin
  F := PForm(Sender);
  if F = nil then Exit;

  Data := PFileDialogData(F^.Data);
  if Data <> nil then
  begin
    { ComboBox item'lari zaten ComboBoxDestroy tarafindan;
      burada sadece harici Data blogunu serbest birak }
    FreeMem(Data);
    F^.Data := 0;
  end;
end;

function OpenDlg(const Title: PChar; const StartPath: PChar): PForm;
var
  F: PForm;
  LV: PListView;
  Ed: PEdit;
  BottomPanel: PPanel;
  IconBox: PPanel;
  BtnOK, BtnCancel: PButton;
  Data: PFileDialogData;
begin
  Result := nil;

  F := CreateForm(Title,
        (SCREEN_WIDTH - 640) div 2, (SCREEN_HEIGHT - 420) div 2,
        640, 420,bsDialog);
  if F = nil then Exit;

  F^.BorderStyle := bsDialog;
  F^.Modal := True;
  F^.ShowSysButtons := False;
  F^.Color := clBtnFace;
  F^.BindDestroy(@FileDialogDestroy);

  { --- Dialog Data --- }
  Data := PFileDialogData(MemAlloc(SizeOf(TFileDialogData)));
  FillChar(Data^, SizeOf(TFileDialogData), #0);
  if StartPath <> nil then
    StrCopy(@Data^.CurrentPath[0], StartPath)
  else
    StrCopy(@Data^.CurrentPath[0], '\');
  Data^.IsSave := False;
  Data^.HistoryPos := 0;
  Data^.HistoryCount := 1;
  StrCopy(@Data^.History[0][0], @Data^.CurrentPath[0]);
  StrCopy(@Data^.FilterPattern[0], '*');

  F^.Data := LongWord(Data);

  { --- Toolbar --- }
  FileDlgCreateToolbar(F, Data);

  { --- ListView --- }
  LV := CreateListView(PObject(F), 0, 0, 0, 0, alClient);
  ListViewSetViewStyle(LV, 1);
  LV^.IconSize := 48;
  LV^.RowHeight := LV^.IconSize + FONT_H + 10;
  LV^.GridLines := False;
  LV^.BorderWidth := 1;
  LV^.BorderColor := cl3DDkShadow;
  Data^.LV := LV;

  { --- Alt Panel (YUKSEKLIK 110 -> filtre icin yer) --- }
  BottomPanel := CreatePanel(PObject(F), 0, 0, 0, 110, alBottom);
  BottomPanel^.Color := clBtnFace;
  BottomPanel^.BorderWidth := 0;
  BottomPanel^.ShowCaption := False;
  BottomPanel^.BindPaint(@FileDlgBottomPanelDraw);

  { Kucuk "dosya" ikonu + Dosya adi Edit }
  IconBox := CreatePanel(PObject(BottomPanel), FD_MARGIN, 8, 22, 22, alNone);
  IconBox^.BorderWidth := 0;
  IconBox^.ShowCaption := False;
  IconBox^.Color := clBtnFace;
  IconBox^.BindPaint(@FileDlgFileIconDraw);

  CreateLabel(PObject(BottomPanel), 'Dosya:', FD_MARGIN + 28, 12, 50, 20, alNone);
  Ed := CreateEdit(PObject(BottomPanel), FD_MARGIN + 80, 10,
                   BottomPanel^.Width - (FD_MARGIN + 80) - 110, 24, alNone);
  EditSetText(Ed, '');
  Data^.Ed := Ed;

  { Butonlar (sag ust kose, tutarli genislik) }
  BtnOK := CreateButton(PObject(BottomPanel), 'Ac',
          BottomPanel^.Width - 100, 8, 90, 26, alNone);
  BtnOK^.Tag := 1;
  BtnOK^.BindMouseUp(@OpenDlgBtnClick);

  BtnCancel := CreateButton(PObject(BottomPanel), 'Iptal',
          BottomPanel^.Width - 100, 40, 90, 26, alNone);
  BtnCancel^.Tag := 2;
  BtnCancel^.BindMouseUp(@OpenDlgBtnClick);

  { === Filtre Combobox === }
  FileDlgCreateFilterCombo(PObject(BottomPanel), Data);

  { --- Events --- }
  LV^.BindDblClick(@FileListDblClick);
  LV^.BindMouseDown(@FileListClick);

  RefreshFileListFromPath(Data);

  ModalResult := mrNone;
  RunModalLoop;

  Result := F;
end;

// Save dialog: similar UI but default filename allowed
function SaveDlg(const Title: PChar; const StartPath: PChar): Boolean;
var
  F: PForm;
  LV: PListView;
  Ed: PEdit;
  BottomPanel: PPanel;
  IconBox: PPanel;
  BtnOK, BtnCancel: PButton;
  Data: PFileDialogData;
begin
  Result := False;

  F := CreateForm(Title,
        (SCREEN_WIDTH - 640) div 2, (SCREEN_HEIGHT - 420) div 2,
        640, 420,bsDialog);
  if F = nil then Exit;

  F^.BorderStyle := bsDialog;
  F^.Modal := True;
  F^.ShowSysButtons := False;
  F^.Color := clBtnFace;
  F^.BindDestroy(@FileDialogDestroy); 

  { --- Dialog Data --- }
  Data := PFileDialogData(MemAlloc(SizeOf(TFileDialogData)));
  FillChar(Data^, SizeOf(TFileDialogData), #0);
  if StartPath <> nil then
    StrCopy(@Data^.CurrentPath[0], StartPath)
  else
    StrCopy(@Data^.CurrentPath[0], '\');
  Data^.IsSave := True;
  Data^.HistoryPos := 0;
  Data^.HistoryCount := 1;
  StrCopy(@Data^.History[0][0], @Data^.CurrentPath[0]);
  StrCopy(@Data^.FilterPattern[0], '*');

  F^.Data := LongWord(Data);

  { --- Toolbar --- }
  FileDlgCreateToolbar(F, Data);

  { --- ListView --- }
  LV := CreateListView(PObject(F), 0, 0, 0, 0, alClient);
  ListViewSetViewStyle(LV, 1);
  LV^.IconSize := 48;
  LV^.RowHeight := LV^.IconSize + FONT_H + 10;
  LV^.GridLines := False;
  LV^.BorderWidth := 1;
  LV^.BorderColor := cl3DDkShadow;
  Data^.LV := LV;

  { --- Alt Panel (YUKSEKLIK 110) --- }
  BottomPanel := CreatePanel(PObject(F), 0, 0, 0, 110, alBottom);
  BottomPanel^.Color := clBtnFace;
  BottomPanel^.BorderWidth := 0;
  BottomPanel^.ShowCaption := False;
  BottomPanel^.BindPaint(@FileDlgBottomPanelDraw);

  { Kucuk "dosya" ikonu + Dosya adi Edit }
  IconBox := CreatePanel(PObject(BottomPanel), FD_MARGIN, 8, 22, 22, alNone);
  IconBox^.BorderWidth := 0;
  IconBox^.ShowCaption := False;
  IconBox^.Color := clBtnFace;
  IconBox^.BindPaint(@FileDlgFileIconDraw);

  CreateLabel(PObject(BottomPanel), 'Ad:', FD_MARGIN + 28, 12, 50, 20, alNone);
  Ed := CreateEdit(PObject(BottomPanel), FD_MARGIN + 80, 10,
                   BottomPanel^.Width - (FD_MARGIN + 80) - 110, 24, alNone);
  EditSetText(Ed, 'YENI.TXT');
  Data^.Ed := Ed;

  BtnOK := CreateButton(PObject(BottomPanel), 'Kaydet',
          BottomPanel^.Width - 100, 8, 90, 26, alNone);
  BtnOK^.Tag := 1;
  BtnOK^.BindMouseUp(@OpenDlgBtnClick);

  BtnCancel := CreateButton(PObject(BottomPanel), 'Iptal',
          BottomPanel^.Width - 100, 40, 90, 26, alNone);
  BtnCancel^.Tag := 2;
  BtnCancel^.BindMouseUp(@OpenDlgBtnClick);

  { === Filtre Combobox === }
  FileDlgCreateFilterCombo(PObject(BottomPanel), Data);

  { --- Events --- }
  LV^.BindDblClick(@FileListDblClick);
  LV^.BindMouseDown(@FileListClick);

  RefreshFileListFromPath(Data);

  ModalResult := mrNone;
  RunModalLoop;

  Result := ModalResult <> mrNone;
end;

// -----------------------------------------------------------------------------
// Helpers to inspect modal results / chosen file
// -----------------------------------------------------------------------------

function GetDlgModalResult(Form: PForm): Integer;
begin
  if Form = nil then Result := Ord(mrNone)
  else Result := Form^.Tag;
end;

function GetDlgFileName(Form: PForm): PChar;
var
  Data: PFileDialogData;
begin
  Result := nil;
  if Form = nil then Exit;
  Data := PFileDialogData(Form^.Data);
  if Data = nil then Exit;
  if Data^.Ed = nil then Exit;
  Result := @Data^.Ed^.Text[0];
end;

// -----------------------------------------------------------------------------

end.

unit KernelFont;

interface

Uses SysUtils,Vesa,Intr32;

const
  FONT_W = 8;
  FONT_H = 16;

  { Font tablosu indeksleri }
  { ASCII 0-127 normal }
  { 128+ T�rk�e }
  FIDX_C_BIG = 128;  { � }
  FIDX_G_BIG = 129;  { � }
  FIDX_I_BIG = 130;  { � }
  FIDX_O_BIG = 131;  { � }
  FIDX_S_BIG = 132;  { � }
  FIDX_U_BIG = 133;  { � }
  FIDX_c_SML = 134;  { � }
  FIDX_g_SML = 135;  { � }
  FIDX_i_SML = 136;  { � }
  FIDX_o_SML = 137;  { � }
  FIDX_s_SML = 138;  { � }
  FIDX_u_SML = 139;  { � }
  FONT_TOTAL  = 140;

var
  FontData    : array[0..FONT_TOTAL-1, 0..FONT_H-1] of Byte;
  FontPhysAddr: LongWord;   { boot'ta set edilir }

procedure Font_Init;
function  CharToIdx(Ch: Char): Integer;

procedure _WriteStr(X,Y: Integer; S: PChar; Color: LongWord);

implementation

{$I Fonts/8x16.inc}

{==============================================================================
  BIOS 8x16 y�kle + T�rk�e ekle
==============================================================================}
procedure Font_LoadBIOS;
var
  Src : PByteArray;
  Ch,R: Integer;
  Regs: TReg16;
begin

 { FillChar(Regs, SizeOf(TReg16), #0);
  Regs.ax := $1130;
  Regs.bx := $0600;

  Intr16(Regs, $10); }


 // if FontPhysAddr = 0 then Exit; FontPhysAddr

  Src := PByteArray(Pointer(@Font_8x16[0]));

  { 0-127 aras� BIOS'tan kopyala }
  for Ch := 0 to 127 do
    for R := 0 to FONT_H-1 do
      FontData[Ch][R] := Src^[Ch * FONT_H + R];
end;

{==============================================================================
  T�rk�e 8x16 glyph'ler � elle �izilmi�
  Bit g�sterimi:  1=dolu  0=bo�   MSB=sol
  
  �rnek: $3C = 0011 1100
                 ..####..
==============================================================================}
procedure Font_InitTurkish;
begin
  {--- � ---------------------------------------------------
    ..####..   $3C
    .##..##.   $66
    .##.....   $60
    .##.....   $60
    .##.....   $60
    .##.....   $60
    .##..##.   $66
    ..####..   $3C
    ...##...   $18  � �engel ba�lar
    ....##..   $0C
    ...###..   $1C
    ........   $00
  ---------------------------------------------------------}
  FontData[FIDX_C_BIG][ 0] := $00;
  FontData[FIDX_C_BIG][ 1] := $00;
  FontData[FIDX_C_BIG][ 2] := $3C;
  FontData[FIDX_C_BIG][ 3] := $66;
  FontData[FIDX_C_BIG][ 4] := $60;
  FontData[FIDX_C_BIG][ 5] := $60;
  FontData[FIDX_C_BIG][ 6] := $60;
  FontData[FIDX_C_BIG][ 7] := $60;
  FontData[FIDX_C_BIG][ 8] := $66;
  FontData[FIDX_C_BIG][ 9] := $3C;
  FontData[FIDX_C_BIG][10] := $18;
  FontData[FIDX_C_BIG][11] := $0C;
  FontData[FIDX_C_BIG][12] := $1C;
  FontData[FIDX_C_BIG][13] := $00;
  FontData[FIDX_C_BIG][14] := $00;
  FontData[FIDX_C_BIG][15] := $00;

  {--- � ---------------------------------------------------
    ...##...   $18  � yay �st
    ..#..#..   $24  � yay
    ........   $00
    ..####..   $3C
    .##..##.   $66
    .##.....   $60
    .##.###.   $6E
    .##..##.   $66
    .##..##.   $66
    ..####..   $3C
  ---------------------------------------------------------}
  FontData[FIDX_G_BIG][ 0] := $00;
  FontData[FIDX_G_BIG][ 1] := $18;
  FontData[FIDX_G_BIG][ 2] := $24;
  FontData[FIDX_G_BIG][ 3] := $00;
  FontData[FIDX_G_BIG][ 4] := $3C;
  FontData[FIDX_G_BIG][ 5] := $66;
  FontData[FIDX_G_BIG][ 6] := $60;
  FontData[FIDX_G_BIG][ 7] := $6E;
  FontData[FIDX_G_BIG][ 8] := $66;
  FontData[FIDX_G_BIG][ 9] := $66;
  FontData[FIDX_G_BIG][10] := $3C;
  FontData[FIDX_G_BIG][11] := $00;
  FontData[FIDX_G_BIG][12] := $00;
  FontData[FIDX_G_BIG][13] := $00;
  FontData[FIDX_G_BIG][14] := $00;
  FontData[FIDX_G_BIG][15] := $00;

  {--- � ---------------------------------------------------
    ...##...   $18  � nokta
    ...##...   $18
    ........   $00
    ..####..   $3C
    ...##...   $18
    ...##...   $18
    ...##...   $18
    ...##...   $18
    ...##...   $18
    ..####..   $3C
  ---------------------------------------------------------}
  FontData[FIDX_I_BIG][ 0] := $00;
  FontData[FIDX_I_BIG][ 1] := $18;
  FontData[FIDX_I_BIG][ 2] := $18;
  FontData[FIDX_I_BIG][ 3] := $00;
  FontData[FIDX_I_BIG][ 4] := $3C;
  FontData[FIDX_I_BIG][ 5] := $18;
  FontData[FIDX_I_BIG][ 6] := $18;
  FontData[FIDX_I_BIG][ 7] := $18;
  FontData[FIDX_I_BIG][ 8] := $18;
  FontData[FIDX_I_BIG][ 9] := $18;
  FontData[FIDX_I_BIG][10] := $3C;
  FontData[FIDX_I_BIG][11] := $00;
  FontData[FIDX_I_BIG][12] := $00;
  FontData[FIDX_I_BIG][13] := $00;
  FontData[FIDX_I_BIG][14] := $00;
  FontData[FIDX_I_BIG][15] := $00;

  {--- � ---------------------------------------------------
    .##..##.   $66  � iki nokta
    ........   $00
    ..####..   $3C
    .##..##.   $66
    .##..##.   $66
    .######.   $7E
    .##..##.   $66
    .##..##.   $66
    ..####..   $3C
  ---------------------------------------------------------}
  FontData[FIDX_O_BIG][ 0] := $00;
  FontData[FIDX_O_BIG][ 1] := $66;
  FontData[FIDX_O_BIG][ 2] := $00;
  FontData[FIDX_O_BIG][ 3] := $3C;
  FontData[FIDX_O_BIG][ 4] := $66;
  FontData[FIDX_O_BIG][ 5] := $66;
  FontData[FIDX_O_BIG][ 6] := $7E;
  FontData[FIDX_O_BIG][ 7] := $66;
  FontData[FIDX_O_BIG][ 8] := $66;
  FontData[FIDX_O_BIG][ 9] := $3C;
  FontData[FIDX_O_BIG][10] := $00;
  FontData[FIDX_O_BIG][11] := $00;
  FontData[FIDX_O_BIG][12] := $00;
  FontData[FIDX_O_BIG][13] := $00;
  FontData[FIDX_O_BIG][14] := $00;
  FontData[FIDX_O_BIG][15] := $00;

  {--- � ---------------------------------------------------
    ..####..   $3C
    .##..##.   $66
    .##.....   $60
    ..####..   $3C
    .....##.   $06
    .....##.   $06
    .##..##.   $66
    ..####..   $3C
    ...##...   $18  � �engel
    ....##..   $0C
    ...###..   $1C
  ---------------------------------------------------------}
  FontData[FIDX_S_BIG][ 0] := $00;
  FontData[FIDX_S_BIG][ 1] := $00;
  FontData[FIDX_S_BIG][ 2] := $3C;
  FontData[FIDX_S_BIG][ 3] := $66;
  FontData[FIDX_S_BIG][ 4] := $60;
  FontData[FIDX_S_BIG][ 5] := $3C;
  FontData[FIDX_S_BIG][ 6] := $06;
  FontData[FIDX_S_BIG][ 7] := $06;
  FontData[FIDX_S_BIG][ 8] := $66;
  FontData[FIDX_S_BIG][ 9] := $3C;
  FontData[FIDX_S_BIG][10] := $18;
  FontData[FIDX_S_BIG][11] := $0C;
  FontData[FIDX_S_BIG][12] := $1C;
  FontData[FIDX_S_BIG][13] := $00;
  FontData[FIDX_S_BIG][14] := $00;
  FontData[FIDX_S_BIG][15] := $00;

  {--- � ---------------------------------------------------
    .##..##.   $66  � iki nokta
    ........   $00
    .##..##.   $66
    .##..##.   $66
    .##..##.   $66
    .##..##.   $66
    .##..##.   $66
    ..#####.   $3E
  ---------------------------------------------------------}
  FontData[FIDX_U_BIG][ 0] := $00;
  FontData[FIDX_U_BIG][ 1] := $66;
  FontData[FIDX_U_BIG][ 2] := $00;
  FontData[FIDX_U_BIG][ 3] := $66;
  FontData[FIDX_U_BIG][ 4] := $66;
  FontData[FIDX_U_BIG][ 5] := $66;
  FontData[FIDX_U_BIG][ 6] := $66;
  FontData[FIDX_U_BIG][ 7] := $66;
  FontData[FIDX_U_BIG][ 8] := $66;
  FontData[FIDX_U_BIG][ 9] := $3E;
  FontData[FIDX_U_BIG][10] := $00;
  FontData[FIDX_U_BIG][11] := $00;
  FontData[FIDX_U_BIG][12] := $00;
  FontData[FIDX_U_BIG][13] := $00;
  FontData[FIDX_U_BIG][14] := $00;
  FontData[FIDX_U_BIG][15] := $00;

  {--- � ---------------------------------------------------
    ........
    ........
    ..####..   $3C
    .##..##.   $66
    .##.....   $60
    .##.....   $60
    .##..##.   $66
    ..####..   $3C
    ...##...   $18  � �engel
    ....##..   $0C
    ...###..   $1C
  ---------------------------------------------------------}
  FontData[FIDX_c_SML][ 0] := $00;
  FontData[FIDX_c_SML][ 1] := $00;
  FontData[FIDX_c_SML][ 2] := $00;
  FontData[FIDX_c_SML][ 3] := $00;
  FontData[FIDX_c_SML][ 4] := $3C;
  FontData[FIDX_c_SML][ 5] := $66;
  FontData[FIDX_c_SML][ 6] := $60;
  FontData[FIDX_c_SML][ 7] := $60;
  FontData[FIDX_c_SML][ 8] := $66;
  FontData[FIDX_c_SML][ 9] := $3C;
  FontData[FIDX_c_SML][10] := $18;
  FontData[FIDX_c_SML][11] := $0C;
  FontData[FIDX_c_SML][12] := $1C;
  FontData[FIDX_c_SML][13] := $00;
  FontData[FIDX_c_SML][14] := $00;
  FontData[FIDX_c_SML][15] := $00;

  {--- � ---------------------------------------------------
    ...##...   $18  � yay
    ..#..#..   $24
    ........   $00
    ..#####.   $3E
    .##..##.   $66
    .##..##.   $66
    ..#####.   $3E
    .....##.   $06
    .##..##.   $66
    ..####..   $3C
  ---------------------------------------------------------}
  FontData[FIDX_g_SML][ 0] := $00;
  FontData[FIDX_g_SML][ 1] := $18;
  FontData[FIDX_g_SML][ 2] := $24;
  FontData[FIDX_g_SML][ 3] := $00;
  FontData[FIDX_g_SML][ 4] := $3E;
  FontData[FIDX_g_SML][ 5] := $66;
  FontData[FIDX_g_SML][ 6] := $66;
  FontData[FIDX_g_SML][ 7] := $3E;
  FontData[FIDX_g_SML][ 8] := $06;
  FontData[FIDX_g_SML][ 9] := $66;
  FontData[FIDX_g_SML][10] := $3C;
  FontData[FIDX_g_SML][11] := $00;
  FontData[FIDX_g_SML][12] := $00;
  FontData[FIDX_g_SML][13] := $00;
  FontData[FIDX_g_SML][14] := $00;
  FontData[FIDX_g_SML][15] := $00;

  {--- �  (noktas�z i) ------------------------------------
    ........
    ........
    ..####..   $3C  � �st �izgi
    ...##...   $18
    ...##...   $18
    ...##...   $18
    ...##...   $18
    ...##...   $18
    ..####..   $3C  � alt �izgi
  ---------------------------------------------------------}
  FontData[FIDX_i_SML][ 0] := $00;
  FontData[FIDX_i_SML][ 1] := $00;
  FontData[FIDX_i_SML][ 2] := $00;
  FontData[FIDX_i_SML][ 3] := $00;
  FontData[FIDX_i_SML][ 4] := $3C;
  FontData[FIDX_i_SML][ 5] := $18;
  FontData[FIDX_i_SML][ 6] := $18;
  FontData[FIDX_i_SML][ 7] := $18;
  FontData[FIDX_i_SML][ 8] := $18;
  FontData[FIDX_i_SML][ 9] := $18;
  FontData[FIDX_i_SML][10] := $3C;
  FontData[FIDX_i_SML][11] := $00;
  FontData[FIDX_i_SML][12] := $00;
  FontData[FIDX_i_SML][13] := $00;
  FontData[FIDX_i_SML][14] := $00;
  FontData[FIDX_i_SML][15] := $00;

  {--- � ---------------------------------------------------
    .##..##.   $66  � iki nokta
    ........   $00
    ..####..   $3C
    .##..##.   $66
    .##..##.   $66
    .##..##.   $66
    .##..##.   $66
    ..####..   $3C
  ---------------------------------------------------------}
  FontData[FIDX_o_SML][ 0] := $00;
  FontData[FIDX_o_SML][ 1] := $00;
  FontData[FIDX_o_SML][ 2] := $00;
  FontData[FIDX_o_SML][ 3] := $66;
  FontData[FIDX_o_SML][ 4] := $00;
  FontData[FIDX_o_SML][ 5] := $3C;
  FontData[FIDX_o_SML][ 6] := $66;
  FontData[FIDX_o_SML][ 7] := $66;
  FontData[FIDX_o_SML][ 8] := $66;
  FontData[FIDX_o_SML][ 9] := $66;
  FontData[FIDX_o_SML][10] := $3C;
  FontData[FIDX_o_SML][11] := $00;
  FontData[FIDX_o_SML][12] := $00;
  FontData[FIDX_o_SML][13] := $00;
  FontData[FIDX_o_SML][14] := $00;
  FontData[FIDX_o_SML][15] := $00;

  {--- � ---------------------------------------------------
    ........
    ........
    ..####..   $3C
    .##..##.   $66
    .##.....   $60
    ..####..   $3C
    .....##.   $06
    .##..##.   $66
    ..####..   $3C
    ...##...   $18  � �engel
    ....##..   $0C
    ...###..   $1C
  ---------------------------------------------------------}
  FontData[FIDX_s_SML][ 0] := $00;
  FontData[FIDX_s_SML][ 1] := $00;
  FontData[FIDX_s_SML][ 2] := $00;
  FontData[FIDX_s_SML][ 3] := $00;
  FontData[FIDX_s_SML][ 4] := $3C;
  FontData[FIDX_s_SML][ 5] := $66;
  FontData[FIDX_s_SML][ 6] := $60;
  FontData[FIDX_s_SML][ 7] := $3C;
  FontData[FIDX_s_SML][ 8] := $06;
  FontData[FIDX_s_SML][ 9] := $66;
  FontData[FIDX_s_SML][10] := $3C;
  FontData[FIDX_s_SML][11] := $18;
  FontData[FIDX_s_SML][12] := $0C;
  FontData[FIDX_s_SML][13] := $1C;
  FontData[FIDX_s_SML][14] := $00;
  FontData[FIDX_s_SML][15] := $00;

  {--- � ---------------------------------------------------
    .##..##.   $66  � iki nokta
    ........   $00
    .##..##.   $66
    .##..##.   $66
    .##..##.   $66
    .##..##.   $66
    .##..##.   $66
    ..#####.   $3E
  ---------------------------------------------------------}
  FontData[FIDX_u_SML][ 0] := $00;
  FontData[FIDX_u_SML][ 1] := $00;
  FontData[FIDX_u_SML][ 2] := $00;
  FontData[FIDX_u_SML][ 3] := $66;
  FontData[FIDX_u_SML][ 4] := $00;
  FontData[FIDX_u_SML][ 5] := $66;
  FontData[FIDX_u_SML][ 6] := $66;
  FontData[FIDX_u_SML][ 7] := $66;
  FontData[FIDX_u_SML][ 8] := $66;
  FontData[FIDX_u_SML][ 9] := $66;
  FontData[FIDX_u_SML][10] := $3E;
  FontData[FIDX_u_SML][11] := $00;
  FontData[FIDX_u_SML][12] := $00;
  FontData[FIDX_u_SML][13] := $00;
  FontData[FIDX_u_SML][14] := $00;
  FontData[FIDX_u_SML][15] := $00;
end;

{==============================================================================
  Font_Init � BIOS y�kle + T�rk�e ekle
==============================================================================}
procedure Font_Init;
begin
  Font_LoadBIOS;       { 0-127 BIOS'tan }
  Font_InitTurkish;    { 128+ T�rk�e    }
end;

{==============================================================================
  Char � font indeksi
  Delphi 7 CP1252 byte de�erleri
==============================================================================}
function CharToIdx(Ch: Char): Integer;
begin
  case Ord(Ch) of
    $C7  : Result := FIDX_C_BIG;   { � }
    $D0  : Result := FIDX_G_BIG;   { � � CP1252'de $011E, .pas'ta $D0 g�r�nebilir }
    $DD  : Result := FIDX_I_BIG;   { � � CP1252'de $130  }
    $D6  : Result := FIDX_O_BIG;   { � }
    $DE  : Result := FIDX_S_BIG;   { � � CP1252'de $15E  }
    $DC  : Result := FIDX_U_BIG;   { � }
    $E7  : Result := FIDX_c_SML;   { � }
    $F0  : Result := FIDX_g_SML;   { � }
    $FD  : Result := FIDX_i_SML;   { � }
    $F6  : Result := FIDX_o_SML;   { � }
    $FE  : Result := FIDX_s_SML;   { � }
    $FC  : Result := FIDX_u_SML;   { � }
  else
    if (Ord(Ch) >= 32) and (Ord(Ch) < 128) then
      Result := Ord(Ch)
    else
      Result := 32;   { bilinmeyen � bo�luk }
  end;
end;

{==============================================================================
  WriteChar + WriteStr
==============================================================================}
procedure WriteChar(X,Y: Integer; Ch: Char; Color: LongWord);
var
  Row,Col  : Integer;
  GRow     : Byte;
  Idx      : Integer;
begin
  Idx := CharToIdx(Ch);
  for Row := 0 to FONT_H-1 do
  begin
    GRow := FontData[Idx][Row];
    if GRow = 0 then Continue;   { bo� sat�r � h�zl� atla }
    for Col := 0 to FONT_W-1 do
      if (GRow and ($80 shr Col)) <> 0 then
        PutPixel(X+Col, Y+Row, Color);
  end;
end;

procedure _WriteStr(X,Y: Integer; S: PChar; Color: LongWord);
var CX: Integer;
begin
  CX:=X;
  while S^<>#0 do
  begin
    WriteChar(CX,Y,S^,Color);
    Inc(CX,FONT_W); Inc(S);
  end;
end;

procedure WriteStrClip(X,Y: Integer; S: PChar; Color: LongWord;
                       CX1,CY1,CX2,CY2: Integer);
var
  CX,Row,Col,PX,PY: Integer;
  GRow: Byte; Idx: Integer;
begin
  CX:=X;
  while S^<>#0 do
  begin
    if CX >= CX2 then Break;
    if CX+FONT_W > CX1 then
    begin
      Idx:=CharToIdx(S^);
      for Row:=0 to FONT_H-1 do
      begin
        PY:=Y+Row;
        if (PY<CY1)or(PY>=CY2) then Continue;
        GRow:=FontData[Idx][Row];
        if GRow=0 then Continue;
        for Col:=0 to FONT_W-1 do
        begin
          PX:=CX+Col;
          if (PX<CX1)or(PX>=CX2) then Continue;
          if (GRow and ($80 shr Col))<>0 then
            PutPixel(PX,PY,Color);
        end;
      end;
    end;
    Inc(CX,FONT_W); Inc(S);
  end;
end;

end.
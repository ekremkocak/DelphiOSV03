unit ProcessMgr;

interface

uses
  SysUtils, GUI, DLLLoader, Console, Draw32, Fat32, Memory, Vesa, Task;

const
  WM_KEYDOWN        = $0100;
  WM_KEYUP          = $0101;
  WM_CHAR           = $0102;
  WM_DEADCHAR       = $0103;
  WM_SYSKEYDOWN     = $0104;
  WM_SYSKEYUP       = $0105;
  WM_SYSCHAR        = $0106;
  WM_SYSDEADCHAR    = $0107;
  WM_KEYLAST        = $0108;

  WM_MOUSEMOVE      = $0200;
  WM_LBUTTONDOWN    = $0201;
  WM_LBUTTONUP      = $0202;
  WM_LBUTTONDBLCLK  = $0203;
  WM_RBUTTONDOWN    = $0204;
  WM_RBUTTONUP      = $0205;
  WM_RBUTTONDBLCLK  = $0206;
  WM_MBUTTONDOWN    = $0207;
  WM_MBUTTONUP      = $0208;
  WM_MBUTTONDBLCLK  = $0209;
  WM_MOUSEWHEEL     = $020A;
  WM_MOUSELEAVE     = $02A3;
  WM_MOUSEENTER     = $02A1;

  WM_PAINT          = $000F;
  WM_DESTROY        = $0002;
  WM_QUIT           = $0012;
  WM_COMMAND        = $0111;

const
  MAX_PROCESS    = 18;
  PROCESS_BASE   = $20000;

  { �� D�ZELT�LD�: Sabit PROCESS_SIZE yok.
    Bunun yerine sadece stack i�in ayr� alan tan�mland�. �� }
  PROCESS_STACK_SIZE = $10000;   { 64KB stack � PE'den ba��ms�z }

  USER_CODE_SEL  = (3 * 8) or 3;
  USER_DATA_SEL  = (4 * 8) or 3;
  MAX_MESSAGES   = 128;

const
  IMAGE_SUBSYSTEM_NATIVE      = 1;
  IMAGE_SUBSYSTEM_WINDOWS_GUI = 2;
  IMAGE_SUBSYSTEM_WINDOWS_CUI = 3;

type
  HWND   = LongWord;
  WPARAM = LongWord;
  LPARAM = LongWord;
  LRESULT= LongWord;

  TMessage = packed record
    hWnd   : LongWord;
    Msg    : LongWord;
    WParam : LongWord;
    LParam : LongWord;
  end;
  PMessage = ^TMessage;

  PProcessParams = ^TProcessParams;
  TProcessParams = packed record
    PID       : LongWord;
    ImageSize : LongWord;
    CmdLine   : PChar;
  end;

  TProcessState = (psEmpty, psLoading, psRunning, psZombie);

  PProcess = ^TProcess;
  TProcess = packed record
    PID          : Integer;
    State        : TProcessState;
    BaseAddr     : LongWord;
    AllocPtr     : Pointer;
    AllocSize    : LongWord;    { HeapAlloc ile ayr�lan TOPLAM boyut }
    ImageSize    : LongWord;    { PE opt^.ImageSz }
    UserStack    : LongWord;    { �� YEN�: Stack'in �st adresi (�nceden hesapl�) }
    EntryPoint   : LongWord;
    ThreadHandle : Integer;
    MainForm     : PForm;
    IsConsole    : Boolean;
    Console      : PConsole;
    Name         : array[0..31]  of Char;
    CmdLine      : array[0..255] of Char;
    Params       : TProcessParams;
    Next         : PProcess;
    Prev         : PProcess;
    DLLInfo      : TDLLInfo;
    MsgHead      : Integer;
    MsgTail      : Integer;
    MsgQueue     : array[0..MAX_MESSAGES-1] of TMessage;
    DirtyForm    : LongWord;
    IsDirty      : Boolean;
  end;

  POptHdrFull = ^TOptHdrFull;
  TOptHdrFull = packed record
    Magic:         Word;
    Pad0:          Word;
    CodeSz:        LongWord;
    InitSz:        LongWord;
    UninitSz:      LongWord;
    EntryRVA:      LongWord;
    CodeBase:      LongWord;
    DataBase:      LongWord;
    ImageBase:     LongWord;
    SecAlign:      LongWord;
    FileAlign:     LongWord;
    OSVerMaj:      Word;
    OSVerMin:      Word;
    ImgVerMaj:     Word;
    ImgVerMin:     Word;
    SSubSysVerMaj: Word;
    SSubSysVerMin: Word;
    Win32Ver:      LongWord;
    ImageSz:       LongWord;
    HdrSz:         LongWord;
    CheckSum:      LongWord;
    Subsystem:     Word;
    DllChars:      Word;
    StackResvSz:   LongWord;
    StackCommSz:   LongWord;
    HeapResvSz:    LongWord;
    HeapCommSz:    LongWord;
    LdrFlags:      LongWord;
    NumDirs:       LongWord;
    DataDirs: array[0..15] of packed record
      VirtualAddress: LongWord;
      Size:           LongWord;
    end;
  end;

  PDosHdr = ^TDosHdr;
  TDosHdr = packed record
    e_magic:  Word;
    e_pad:    array[0..57] of Byte;
    e_lfanew: LongWord;
  end;

  PPeHdr = ^TPeHdr;
  TPeHdr = packed record
    Sig:     LongWord;
    Machine: Word;
    NumSec:  Word;
    Pad1:    LongWord;
    Pad2:    LongWord;
    Pad3:    LongWord;
    OptSize: Word;
    Chars:   Word;
  end;

  PSecHdr = ^TSecHdr;
  TSecHdr = packed record
    Name:    array[0..7] of Char;
    VirtSz:  LongWord;
    VirtRVA: LongWord;
    RawSz:   LongWord;
    RawPtr:  LongWord;
    Pad:     array[0..11] of Byte;
    Chars:   LongWord;
  end;

  PRelocBlock = ^TRelocBlock;
  TRelocBlock = packed record
    PageRVA: LongWord;
    BlockSz: LongWord;
  end;

var
  ProcessListHead : PProcess = nil;
  ProcessListTail : PProcess = nil;
  ProcessCount    : Integer  = 0;
  NextPID         : Integer  = 1;
  DLLInfo1        : PDLLInfo;

procedure ProcessMgr_Init;
function  ProcessCreate(ExeData: Pointer; ExeSize: LongWord;
                        const Name: PChar): PProcess;
procedure ProcessListAdd(P: PProcess);
procedure ProcessKill(Proc: PProcess);
procedure ProcessKillByPID(PID: Integer);
procedure ProcessKillByHWND(Wnd: PForm);
function  ProcessGetCurrent: PProcess;
function  ProcessFindByPID(PID: Integer): PProcess;
function  ProcessFindByHWND(Wnd: PForm): PProcess;

function  GetPEImageSize(ExeData: Pointer): LongWord;
function  LoadPEAt(ExeData: Pointer; ExeSize: LongWord;
                   BaseAddr: LongWord; Proc: PProcess): LongWord;
procedure EXE_ParseResources(BaseAddr: LongWord; DLL: PDLLInfo);

procedure RunExe(Entry: Pointer; HInst: LongWord; HSize: Pointer; CmdLine: PChar);
procedure ProcessWrapper(Proc: PProcess); stdcall;

procedure PostMessage(Proc: PProcess; hWnd, Msg, WParam, LParam: LongWord);
function  PeekMessage(Proc: PProcess; var Msg: TMessage): Boolean;

procedure KernelMouseMove(Form: PForm; X, Y: Integer);
procedure KernelPaint(Proc: PProcess; Form: PForm; X, Y: Integer);
procedure KernelKeyDown(Form: PForm; Key: Word);
procedure KernelKeyUp(Form: PForm; Key: Word);
procedure KernelDESTROY(Form: PForm);
procedure PostCommand(Proc: PProcess; hWnd, Control: LongWord; Code: Word);

implementation

{---------------------------------------------------------------------------}
{  Message Queue                                                            }
{---------------------------------------------------------------------------}
procedure PostMessage(Proc: PProcess; hWnd, Msg, WParam, LParam: LongWord);
var
  Next, i: Integer;
begin
  if Proc = nil then Exit;

  { WM_PAINT coalescing � ayn� form i�in birden fazla paint birle�tir }
  if Msg = WM_PAINT then
  begin
    i := Proc^.MsgHead;
    while i <> Proc^.MsgTail do
    begin
      if (Proc^.MsgQueue[i].hWnd = hWnd) and
         (Proc^.MsgQueue[i].Msg  = WM_PAINT) then
      begin
        Proc^.MsgQueue[i].LParam := 0;
        Exit;
      end;
      i := (i + 1) mod MAX_MESSAGES;
    end;
  end;

  Next := (Proc^.MsgTail + 1) mod MAX_MESSAGES;
  if Next = Proc^.MsgHead then Exit;   { kuyruk dolu }

  Proc^.MsgQueue[Proc^.MsgTail].hWnd   := hWnd;
  Proc^.MsgQueue[Proc^.MsgTail].Msg    := Msg;
  Proc^.MsgQueue[Proc^.MsgTail].WParam := WParam;
  Proc^.MsgQueue[Proc^.MsgTail].LParam := LParam;
  Proc^.MsgTail := Next;
end;

function PeekMessage(Proc: PProcess; var Msg: TMessage): Boolean;
begin
  Result := False;
  if Proc = nil then Exit;
  if Proc^.MsgHead = Proc^.MsgTail then Exit;

  Msg := Proc^.MsgQueue[Proc^.MsgHead];
  Proc^.MsgHead := (Proc^.MsgHead + 1) mod MAX_MESSAGES;
  Result := True;
end;

procedure KernelDESTROY(Form: PForm);
var Proc: PProcess;
begin
  Proc := PProcess(Form^.OwnerProcess);
  if Proc = nil then Exit;
  PostMessage(Proc, LongWord(Form), WM_DESTROY, 0, 0);
end;

procedure PostCommand(Proc: PProcess; hWnd, Control: LongWord; Code: Word);
begin
  if Proc = nil then Exit;
  PostMessage(Proc, hWnd, WM_COMMAND,
    (LongWord(Code) shl 16) or (Control and $FFFF), Control);
end;

procedure KernelMouseMove(Form: PForm; X, Y: Integer);
var Proc: PProcess;
begin
  Proc := PProcess(Form^.OwnerProcess);
  if Proc = nil then Exit;
  PostMessage(Proc, LongWord(Form), WM_MOUSEMOVE, 0,
    LongWord(Word(X)) or (LongWord(Word(Y)) shl 16));
end;

procedure KernelMouseDown(Form: PForm; X, Y: Integer; Btn: Byte);
var Proc: PProcess; Msg: LongWord;
begin
  Proc := PProcess(Form^.OwnerProcess);
  if Proc = nil then Exit;
  case Btn of
    1: Msg := WM_LBUTTONDOWN;
    2: Msg := WM_RBUTTONDOWN;
  else Msg := WM_MBUTTONDOWN;
  end;
  PostMessage(Proc, LongWord(Form), Msg, Btn,
    LongWord(Word(X)) or (LongWord(Word(Y)) shl 16));
end;

procedure KernelKeyDown(Form: PForm; Key: Word);
var Proc: PProcess;
begin
  Proc := PProcess(Form^.OwnerProcess);
  if Proc = nil then Exit;
  PostMessage(Proc, LongWord(Form), WM_KEYDOWN, Key, 0);
end;

procedure KernelKeyUp(Form: PForm; Key: Word);
var Proc: PProcess;
begin
  Proc := PProcess(Form^.OwnerProcess);
  if Proc = nil then Exit;
  PostMessage(Proc, LongWord(Form), WM_KEYUP, Key, 0);
end;

procedure KernelPaint(Proc: PProcess; Form: PForm; X, Y: Integer);
begin
  PostMessage(Proc, LongWord(Form), WM_PAINT, 0,
    LongWord(Word(X)) or (LongWord(Word(Y)) shl 16));
end;

{---------------------------------------------------------------------------}
{  String Helpers                                                           }
{---------------------------------------------------------------------------}
function StrLen(s: PChar): Integer;
begin
  Result := 0;
  if s = nil then Exit;
  while s[Result] <> #0 do Inc(Result);
end;

procedure StrCopy(Dest, Src: PChar);
var i: Integer;
begin
  if (Dest = nil) or (Src = nil) then Exit;
  i := 0;
  while Src[i] <> #0 do begin Dest[i] := Src[i]; Inc(i); end;
  Dest[i] := #0;
end;

{---------------------------------------------------------------------------}
{  PE Header Okuma                                                          }
{---------------------------------------------------------------------------}
function GetPEImageSize(ExeData: Pointer): LongWord;
var
  dos: PDosHdr;
  pe:  PPeHdr;
  opt: POptHdrFull;
begin
  Result := 0;
  if ExeData = nil then Exit;
  dos := PDosHdr(ExeData);
  if dos^.e_magic <> $5A4D then Exit;
  pe := PPeHdr(LongWord(ExeData) + dos^.e_lfanew);
  if pe^.Sig <> $00004550 then Exit;
  opt := POptHdrFull(LongWord(pe) + SizeOf(TPeHdr));
  Result := opt^.ImageSz;
end;

procedure EXE_ParseResources(BaseAddr: LongWord; DLL: PDLLInfo);
var
  dos: PDosHdr; pe: PPeHdr; opt: POptHdrFull;
begin
  if (BaseAddr = 0) or (DLL = nil) then Exit;
  dos := PDosHdr(BaseAddr);
  if dos^.e_magic <> $5A4D then Exit;
  pe := PPeHdr(BaseAddr + dos^.e_lfanew);
  if pe^.Sig <> $00004550 then Exit;
  opt := POptHdrFull(LongWord(pe) + SizeOf(TPeHdr));
  DLL^.ResourceCount := 0;
  DLL^.IconCount     := 0;
  DLL^.BitmapCount   := 0;
  DLL^.TextCount     := 0;
  DLL^.CursorCount   := 0;
  DLL^.BaseAddr      := BaseAddr;
end;

{---------------------------------------------------------------------------}
{  PE Y�kleme                                                               }
{---------------------------------------------------------------------------}
function LoadPEAt(ExeData: Pointer; ExeSize: LongWord;
                  BaseAddr: LongWord; Proc: PProcess): LongWord;
var
  dos:       PDosHdr;
  pe:        PPeHdr;
  opt:       POptHdrFull;
  sec:       PSecHdr;
  i:         Integer;
  src, dst:  LongWord;
  delta:     LongInt;
  relocRVA:  LongWord;
  relocSz:   LongWord;
  blk:       PRelocBlock;
  blkEnd:    LongWord;
  entryOff:  Word;
  entryType: Byte;
  fixup:     PCardinal;
begin
  Result := 0;
  if ExeData = nil then Exit;

  dos := PDosHdr(ExeData);
  if dos^.e_magic <> $5A4D then Exit;
  pe := PPeHdr(LongWord(ExeData) + dos^.e_lfanew);
  if pe^.Sig <> $00004550 then Exit;
  opt := POptHdrFull(LongWord(pe) + SizeOf(TPeHdr));
  if opt^.ImageSz = 0 then Exit;

  delta := LongInt(BaseAddr) - LongInt(opt^.ImageBase);

  { Sadece ImageSz kadar s�f�rla � Stack alan�na DOKUNMA }
  FillChar(Pointer(BaseAddr)^, opt^.ImageSz, 0);
  Move(ExeData^, Pointer(BaseAddr)^, opt^.HdrSz);

  sec := PSecHdr(LongWord(opt) + pe^.OptSize);
  for i := 0 to pe^.NumSec - 1 do
  begin
    if sec^.RawSz > 0 then
    begin
      src := LongWord(ExeData) + sec^.RawPtr;
      dst := BaseAddr + sec^.VirtRVA;
      Move(Pointer(src)^, Pointer(dst)^, sec^.RawSz);
    end;
    Inc(sec);
  end;

  if delta <> 0 then
  begin
    relocRVA := opt^.DataDirs[5].VirtualAddress;
    relocSz  := opt^.DataDirs[5].Size;
    if (relocRVA > 0) and (relocSz > 0) then
    begin
      blk    := PRelocBlock(BaseAddr + relocRVA);
      blkEnd := LongWord(blk) + relocSz;
      while LongWord(blk) < blkEnd do
      begin
        if blk^.BlockSz < 8 then Break;
        for i := 0 to Integer((blk^.BlockSz - 8) div 2) - 1 do
        begin
          entryOff  := PWord(LongWord(blk) + 8 + LongWord(i) * 2)^;
          entryType := entryOff shr 12;
          if entryType = 3 then
          begin
            fixup := PCardinal(BaseAddr + blk^.PageRVA + (entryOff and $FFF));
            Inc(fixup^, delta);
          end;
        end;
        blk := PRelocBlock(LongWord(blk) + blk^.BlockSz);
      end;
    end;
  end;

  { NOT: Proc^'� burada FillChar ile s�f�rlama!
    ProcessCreate zaten ImageSize/AllocSize/UserStack'i ayarlad�.
    Sadece gerekli alanlar� g�ncelle. }
  if Proc <> nil then
  begin
    Proc^.BaseAddr   := BaseAddr;
    Proc^.EntryPoint := BaseAddr + opt^.EntryRVA;
    Proc^.IsConsole  := opt^.Subsystem = IMAGE_SUBSYSTEM_WINDOWS_CUI;
    EXE_ParseResources(BaseAddr, @Proc^.DLLInfo);
  end;

  Result := BaseAddr + opt^.EntryRVA;
end;

{---------------------------------------------------------------------------}
{  Linked List                                                              }
{---------------------------------------------------------------------------}
function ProcessAlloc: PProcess;
var P: PProcess;
begin
  P := PProcess(HeapAlloc(SizeOf(TProcess)));
  if P = nil then begin Result := nil; Exit; end;
  FillChar(P^, SizeOf(TProcess), 0);
  Result := P;
end;

procedure ProcessListAdd(P: PProcess);
begin
  P^.Next := nil;
  P^.Prev := ProcessListTail;
  if ProcessListTail <> nil then ProcessListTail^.Next := P
  else ProcessListHead := P;
  ProcessListTail := P;
  Inc(ProcessCount);
end;

procedure ProcessListRemove(P: PProcess);
begin
  if P^.Prev <> nil then P^.Prev^.Next := P^.Next
  else ProcessListHead := P^.Next;
  if P^.Next <> nil then P^.Next^.Prev := P^.Prev
  else ProcessListTail := P^.Prev;
  Dec(ProcessCount);
end;

function ProcessFindByPID(PID: Integer): PProcess;
var P: PProcess;
begin
  Result := nil; P := ProcessListHead;
  while P <> nil do begin if P^.PID = PID then begin Result := P; Exit; end; P := P^.Next; end;
end;

function ProcessFindByThread(Handle: Integer): PProcess;
var P: PProcess;
begin
  Result := nil; P := ProcessListHead;
  while P <> nil do begin if P^.ThreadHandle = Handle then begin Result := P; Exit; end; P := P^.Next; end;
end;

function ProcessFindByHWND(Wnd: PForm): PProcess;
var P: PProcess;
begin
  Result := nil; P := ProcessListHead;
  while P <> nil do begin if P^.MainForm = Wnd then begin Result := P; Exit; end; P := P^.Next; end;
end;

function ProcessGetCurrent: PProcess;
var T: PTask;
begin
  T := Thread_GetCurrent;
  Result := ProcessFindByThread(T^.TID);
end;

{---------------------------------------------------------------------------}
{  Ring3 �al��t�rma                                                         }
{---------------------------------------------------------------------------}
procedure RunExe(Entry: Pointer; HInst: LongWord; HSize: Pointer; CmdLine: PChar);
asm
  push CmdLine
  push HSize
  push HInst
  call Entry
  add  esp, 12
end;

procedure JumpToRing3(entry, userStack, paramsAddr: LongWord);
var
  flags: LongWord;
begin
  asm
    pushfd
    pop eax
    or  eax, $202
    mov flags, eax
  end;

  asm
    mov ax, USER_DATA_SEL
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    
    // iret frame
    mov eax, USER_DATA_SEL
    push eax                  // SS
    mov eax, userStack        // ESP
    push eax
    mov eax, flags
    push eax                  // EFLAGS
    mov eax, USER_CODE_SEL
    push eax                  // CS
    mov eax, entry
    push eax                  // EIP
    
    // KR�T�K ADIM: iretd �ncesi EAX'e parametre adresini koyuyoruz.
    // iretd komutu EAX yazmac�n�n de�erini DE���T�RMEZ.
    mov eax, paramsAddr


    iretd
  end;
end;


procedure SetupRing3Stack(var UserStackTop: LongWord; Params: PProcessParams);
begin
  Dec(UserStackTop, 4);
  PCardinal(UserStackTop)^ := LongWord(Params);
  Dec(UserStackTop, 4);
  PCardinal(UserStackTop)^ := 0;
end;

procedure ProcessWrapper(Proc: PProcess); stdcall;
var UserTop: LongWord;
begin
  { �� D�ZELT�LD�: UserStack ProcessCreate'te hesapland� ve sakland� ��
    UserStack = BaseAddr + ImageSize + PROCESS_STACK_SIZE - 64
    Bu adres PE image'�n DI�INDA, stack i�in ayr�lm�� b�lgede. }
  UserTop := Proc^.UserStack;

  Proc^.Params.PID       := Proc^.PID;
  Proc^.Params.ImageSize := Proc^.ImageSize;
  Proc^.Params.CmdLine   := @Proc^.CmdLine[0];

  SetupRing3Stack(UserTop, @Proc^.Params);
 // RunExe(Pointer(Proc^.EntryPoint), Proc^.PID, Proc, @Proc^.CmdLine[0]);

  JumpToRing3(Proc^.EntryPoint, UserTop, LongWord(@Proc^.Params));
end;

{===========================================================================}
{  ProcessCreate � D�NAM�K BOYUT + AYRI STACK ALANI                         }
{===========================================================================}
function ProcessCreate(ExeData: Pointer; ExeSize: LongWord;
                       const Name: PChar): PProcess;
var
  Proc      : PProcess;
  BaseAddr  : LongWord;
  RawPtr    : Pointer;
  Entry     : LongWord;
  ImageSize : LongWord;
  AllocSize : LongWord;
  i         : Integer;
  Handle    : Integer;
begin
  Result := nil;

  { �� ADIM 1: PE'den image boyutunu oku �� }
  ImageSize := GetPEImageSize(ExeData);
  if ImageSize = 0 then Exit;

  { �� ADIM 2: ImageSize + AYRI STACK ALANI ay�r ��
    Layout:
      [0 .. ImageSize-1]                  � PE image (kod, data, bss)
      [ImageSize .. ImageSize+STACK-1]    � Stack (PE'den tamamen ayr�)
    Toplam = ImageSize + PROCESS_STACK_SIZE, 4KB hizal� }
  AllocSize := ImageSize + PROCESS_STACK_SIZE + 4095;
  RawPtr    := HeapAlloc(AllocSize);
  if RawPtr = nil then Exit;

  BaseAddr := (LongWord(RawPtr) + 4095) and $FFFFF000;

  { �� ADIM 3: Process node olu�tur ve alanlar� DERHal doldur ��
    NOT: LoadPEAt art�k FillChar(Proc^,...) yapm�yor.
    Bu y�zden s�ra �nemli de�il, ama yine de �nce doldural�m. }
  Proc := ProcessAlloc;
  if Proc = nil then begin HeapFree(RawPtr); Exit; end;

  Proc^.PID       := NextPID;
  Proc^.State     := psLoading;
  Proc^.BaseAddr  := BaseAddr;
  Proc^.AllocPtr  := RawPtr;
  Proc^.AllocSize := AllocSize;
  Proc^.ImageSize := ImageSize;

  { �� KR�T�K: Stack �st�n� hesapla ve sakla ��
    PE image'�n�n hemen �ST�NDE, stack alan�n�n en �st�. }
  Proc^.UserStack := BaseAddr + ImageSize + PROCESS_STACK_SIZE - 64;

  Proc^.MainForm := nil;

  i := 0;
  while (Name[i] <> #0) and (i < 31) do
  begin
    Proc^.Name[i]    := Name[i];
    Proc^.CmdLine[i] := Name[i];
    Inc(i);
  end;

  { �� ADIM 4: PE y�kle �� }
  Entry := LoadPEAt(ExeData, ExeSize, BaseAddr, Proc);
  if Entry = 0 then
  begin
    HeapFree(RawPtr);
    HeapFree(Proc);
    Exit;
  end;

  { �� ADIM 5: Import'lar� ��z �� }
  if not ResolveImports(BaseAddr) then
  begin
    HeapFree(RawPtr);
    HeapFree(Proc);
    Exit;
  end;

  { EntryPoint LoadPEAt i�inde ayarland�, burada da g�ncelle }
  Proc^.EntryPoint := Entry;

  { �� ADIM 6: Listeye ekle �� }
  ProcessListAdd(Proc);
  Inc(NextPID);

  { �� ADIM 7: Console olu�tur (CUI ise) �� }
  if Proc^.IsConsole then
    Proc^.Console := OpenTerminal(Proc^.Name, Proc^.PID);

  { �� ADIM 8: Thread ba�lat �� }
  Handle := BeginThread(@ProcessWrapper, Proc, Proc^.Name, PRIO_HIGH, TF_KERNEL);
  if Handle = -1 then
  begin
    ProcessListRemove(Proc);
    HeapFree(RawPtr);
    HeapFree(Proc);
    Exit;
  end;

  Proc^.ThreadHandle := Handle;
  Proc^.State        := psRunning;
  Result := Proc;
end;

{===========================================================================}
{  ProcessKill                                                               }
{===========================================================================}
procedure ProcessKill(Proc: PProcess);
begin
  if Proc = nil then Exit;
  if Proc^.State = psEmpty then Exit;
  Proc^.State := psZombie;

  if Proc^.MainForm <> nil then
  begin
    WinManager.RemoveForm(Proc^.MainForm);
    Proc^.MainForm := nil;
  end;

  if Proc^.ThreadHandle <> 0 then
    Thread_Kill(Proc^.ThreadHandle);

  if Proc^.AllocPtr <> nil then
  begin
    { T�m ayr�lan alan� s�f�rla (ImageSize + Stack) }
    FillChar(Pointer(Proc^.BaseAddr)^, Proc^.AllocSize, 0);
    HeapFree(Proc^.AllocPtr);
  end;

  ProcessListRemove(Proc);
  HeapFree(Proc);
end;

procedure ProcessKillByPID(PID: Integer);
begin ProcessKill(ProcessFindByPID(PID)); end;

procedure ProcessKillByHWND(Wnd: PForm);
begin ProcessKill(ProcessFindByHWND(Wnd)); end;

{===========================================================================}
{  Init                                                                     }
{===========================================================================}
procedure ProcessMgr_Init;
begin
  ProcessListHead := nil;
  ProcessListTail := nil;
  ProcessCount    := 0;
  NextPID         := 1;
end;

end.

unit Component;

interface

uses
  SysUtils, GUI, Draw32, Memory,Vesa;

{==============================================================================}
{  TEDIT                                                                       }
{==============================================================================}

type
  PEdit = ^TEdit;
  TEdit = object(TObject)
  public
    Text: PChar;
    TextLen: Integer;
    TextCapacity: Integer;
    CursorPos: Integer;
    SelStart: Integer;
    SelLength: Integer;
    ScrollX: Integer;
    BorderColor: LongWord;
    TextColor: LongWord;
    SelColor: LongWord;
    SelTextColor: LongWord;
    PasswordChar: Char;
    ReadOnly: Boolean;
  end;

function  Edit_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PEdit;
procedure Edit_Free(AEdit: PEdit);
procedure Edit_Draw(AEdit: PEdit; ParentX, ParentY: Integer);
procedure Edit_ProcessKey(AEdit: PEdit; Key: Word; Shift: Byte);
procedure Edit_MouseDown(AEdit: PEdit; X, Y: Integer);
procedure Edit_MouseMove(AEdit: PEdit; X, Y: Integer);
procedure Edit_SetText(AEdit: PEdit; const S: PChar);
procedure Edit_GetText(AEdit: PEdit; Dest: PChar; MaxLen: Integer);

{==============================================================================}
{  TMEMO                                                                       }
{==============================================================================}

type
  PMemo = ^TMemo;
  TMemo = object(TObject)
  public
    Lines: array[0..255] of PChar;
    LineCount: Integer;
    CursorX: Integer;
    CursorY: Integer;
    SelStartX, SelStartY: Integer;
    SelEndX, SelEndY: Integer;
    ScrollX, ScrollY: Integer;
    BorderColor: LongWord;
    TextColor: LongWord;
    SelColor: LongWord;
    SelTextColor: LongWord;
    ReadOnly: Boolean;
    WordWrap: Boolean;
    ShowScrollBars: Boolean;
    VScrollRect, VThumbRect: TRect;
    HScrollRect, HThumbRect: TRect;
    VScrollDrag, HScrollDrag: Boolean;
    VScrollDragStart, HScrollDragStart: Integer;
    VScrollDragStartVal, HScrollDragStartVal: Integer;
  end;

function  Memo_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PMemo;
procedure Memo_Free(AMemo: PObject);
procedure Memo_Draw(AMemo: PMemo; ParentX, ParentY: Integer);
procedure Memo_ProcessKey(AMemo: PMemo; Key: Word; Shift: Byte);
procedure Memo_MouseDown(AMemo: PMemo; X, Y: Integer);
procedure Memo_MouseMove(AMemo: PMemo; X, Y: Integer);
procedure Memo_MouseUp(AMemo: PMemo; X, Y: Integer);
procedure Memo_SetText(AMemo: PMemo; const S: PChar);
procedure Memo_DeleteSelection(AMemo: PMemo);
procedure Memo_ClearSelection(AMemo: PMemo);
procedure Memo_SelectAll(AMemo: PMemo);
procedure Memo_Cut(AMemo: PMemo);
procedure Memo_Copy(AMemo: PMemo);
procedure Memo_Paste(AMemo: PMemo);
function  Memo_MaxLineLen(AMemo: PMemo): Integer;
{==============================================================================}
{  CLIPBOARD                                                                   }
{==============================================================================}

procedure Component_ClipboardSet(const S: PChar; Len: Integer);
function  Component_ClipboardGet: PChar;
function  Component_ClipboardLen: Integer;


{==============================================================================}
{  TLISTVIEW                                                                   }
{==============================================================================}

type
  PListItem = ^TListItem;
  TListItem = record
    Caption: PChar;
    SubItems: array[0..7] of PChar;
    SubItemCount: Integer;
    ImageIndex: Integer;
    Tag: Integer;
  end;

  PListView = ^TListView;
  TListView = object(TObject)
  public
    Items: array[0..1023] of PListItem;
    ItemCount: Integer;
    Columns: array[0..7] of record
      Caption: PChar;
      Width: Integer;
    end;
    ColumnCount: Integer;
    ViewStyle: Byte;            { 0 = List, 1 = Report, 2 = Icon }
    RowHeight: Integer;
    ItemWidth: Integer;         { Icon modunda item geni�li�i (varsay�lan 80) }
    ItemHeight: Integer;        { Icon modunda item y�ksekli�i (varsay�lan 52) }
    ItemIndex: Integer;
    ScrollX, ScrollY: Integer;
    HeaderHeight: Integer;
    BorderColor: LongWord;
    TextColor: LongWord;
    SelColor: LongWord;
    SelTextColor: LongWord;
    AltColor: LongWord;
    HeaderColor: LongWord;
    HeaderTextColor: LongWord;
    ShowHeader: Boolean;
    VScrollRect, VThumbRect: TRect;
    HScrollRect, HThumbRect: TRect;
    VScrollDrag, HScrollDrag: Boolean;
    VScrollDragStart, HScrollDragStart: Integer;
    VScrollDragStartVal, HScrollDragStartVal: Integer;
  end;

function  ListItem_Create(const ACaption: PChar): PListItem;
procedure ListItem_Free(AItem: PListItem);
function  ListView_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PListView;
procedure ListView_Free(AListView: PListView);
procedure ListView_Clear(AListView: PListView;Column:Boolean=False);
function  ListView_AddItem(AListView: PListView; const ACaption: PChar): Integer;
procedure ListView_AddSubItem(AListView: PListView; AItemIndex: Integer; const AText: PChar);
procedure ListView_AddColumn(AListView: PListView; const ACaption: PChar; AWidth: Integer);
procedure ListView_Draw(AListView: PListView; ParentX, ParentY: Integer);
procedure ListView_ProcessKey(AListView: PListView; Key: Word; Shift: Byte);
procedure ListView_MouseDown(AListView: PListView; X, Y: Integer);
procedure ListView_MouseMove(AListView: PListView; X, Y: Integer);
procedure ListView_MouseUp(AListView: PListView; X, Y: Integer);


{==============================================================================}
{  TLISTBOX                                                                    }
{==============================================================================}

type
  PListBox = ^TListBox;
  TListBox = object(TObject)
  public
    Items: array[0..1023] of PChar;
    ItemCount: Integer;
    ItemIndex: Integer;
    HoverIndex: Integer;        { Mouse hangi sat�r�n �zerinde }
    RowHeight: Integer;
    ScrollY: Integer;
    BorderColor: LongWord;
    TextColor: LongWord;
    SelColor: LongWord;
    SelTextColor: LongWord;
    AltColor: LongWord;         { Alternatif sat�r rengi }
    HoverColor: LongWord;       { �zerine gelince renk }
    VScrollRect, VThumbRect: TRect;
    VScrollDrag: Boolean;
    VScrollDragStart: Integer;
    VScrollDragStartVal: Integer;
  end;

function  ListBox_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PListBox;
procedure ListBox_Free(AListBox: PListBox);
procedure ListBox_Clear(AListBox: PListBox);
function  ListBox_AddItem(AListBox: PListBox; const S: PChar): Integer;
procedure ListBox_DeleteItem(AListBox: PListBox; Index: Integer);
procedure ListBox_Draw(AListBox: PListBox; ParentX, ParentY: Integer);
procedure ListBox_ProcessKey(AListBox: PListBox; Key: Word; Shift: Byte);
procedure ListBox_MouseDown(AListBox: PListBox; X, Y: Integer);
procedure ListBox_MouseMove(AListBox: PListBox; X, Y: Integer);
procedure ListBox_MouseUp(AListBox: PListBox; X, Y: Integer);
procedure ListBox_UpdateScroll(AListBox: PListBox);
procedure ListBox_EnsureVisible(AListBox: PListBox);


{==============================================================================}
{  TPROGRESSBAR                                                                }
{==============================================================================}

type
  PProgressBar = ^TProgressBar;
  TProgressBar = object(TObject)
  public
    Min: Integer;
    Max: Integer;
    Position: Integer;
    BarColor: LongWord;
    BackColor: LongWord;
    BorderColor: LongWord;
    TextColor: LongWord;
    ShowPercent: Boolean;
    Orientation: Byte; { 0 = Yatay, 1 = Dikey }
  end;

function  ProgressBar_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PProgressBar;
procedure ProgressBar_Draw(AProgressBar: PProgressBar; ParentX, ParentY: Integer);
procedure ProgressBar_SetPosition(AProgressBar: PProgressBar; APos: Integer);

{==============================================================================}
{  TSCROLLBAR                                                                  }
{==============================================================================}

type
  PScrollBar = ^TScrollBar;
  TScrollBar = object(TObject)
  public
    Min: Integer;
    Max: Integer;
    Position: Integer;
    PageSize: Integer;
    SmallChange: Integer;
    Orientation: Byte; { 0 = Yatay, 1 = Dikey }
    TrackRect: TRect;
    ThumbRect: TRect;
    Btn1Rect: TRect;
    Btn2Rect: TRect;
    Dragging: Boolean;
    DragStart: Integer;
    DragStartVal: Integer;
    BorderColor: LongWord;
    ThumbColor: LongWord;
    BtnColor: LongWord;
  end;

function  ScrollBar_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PScrollBar;
procedure ScrollBar_Draw(AScrollBar: PScrollBar; ParentX, ParentY: Integer);
procedure ScrollBar_SetPosition(AScrollBar: PScrollBar; APos: Integer);
procedure ScrollBar_MouseDown(AScrollBar: PScrollBar; X, Y: Integer);
procedure ScrollBar_MouseMove(AScrollBar: PScrollBar; X, Y: Integer);
procedure ScrollBar_MouseUp(AScrollBar: PScrollBar; X, Y: Integer);


{==============================================================================}
{  TCHECKBOX                                                                   }
{==============================================================================}

type
  PCheckBox = ^TCheckBox;
  TCheckBox = object(TObject)
  public
    Checked: Boolean;
    TextColor: LongWord;
    BoxColor: LongWord;
    CheckColor: LongWord;
  end;

function  CheckBox_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; const ACaption: PChar): PCheckBox;
procedure CheckBox_Free(ACheckBox: PCheckBox);
procedure CheckBox_Draw(ACheckBox: PCheckBox; ParentX, ParentY: Integer);
procedure CheckBox_MouseDown(ACheckBox: PCheckBox; X, Y: Integer);

{==============================================================================}
{  TRADIOBUTTON                                                                }
{==============================================================================}

type
  PRadioButton = ^TRadioButton;
  TRadioButton = object(TObject)
  public
    Checked: Boolean;
    TextColor: LongWord;
    CircleColor: LongWord;
    DotColor: LongWord;
  end;

function  RadioButton_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; const ACaption: PChar): PRadioButton;
procedure RadioButton_Free(ARadio: PRadioButton);
procedure RadioButton_Draw(ARadio: PRadioButton; ParentX, ParentY: Integer);
procedure RadioButton_MouseDown(ARadio: PRadioButton; X, Y: Integer);

{==============================================================================}
{  TSTATUSBAR                                                                  }
{==============================================================================}

type
  PStatusPanel=^TStatusPanel;
  TStatusPanel = record
    Caption: PChar;
    Width: Integer;
    Alignment: Byte; { 0 = Sol, 1 = Orta, 2 = Sa� }
  end;

  PStatusBar = ^TStatusBar;
  TStatusBar = object(TObject)
  public
    Panels: array[0..7] of TStatusPanel;
    PanelCount: Integer;
    SimplePanel: Boolean;
    SimpleText: PChar;
    SizeGrip: Boolean;
    TextColor: LongWord;
    BorderColor: LongWord;
  end;

function  StatusBar_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PStatusBar;
procedure StatusBar_Free(AStatusBar: PStatusBar);
procedure StatusBar_AddPanel(AStatusBar: PStatusBar; const ACaption: PChar; AWidth: Integer; AAlign: Byte);
procedure StatusBar_SetSimpleText(AStatusBar: PStatusBar; const S: PChar);
procedure StatusBar_Draw(AStatusBar: PStatusBar; ParentX, ParentY: Integer);


{==============================================================================}
{  TGROUPBOX                                                                   }
{==============================================================================}

type
  PGroupBox = ^TGroupBox;
  TGroupBox = object(TObject)
  public
    BorderColor: LongWord;
    TextColor: LongWord;
  end;

function  GroupBox_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; const ACaption: PChar): PGroupBox;
procedure GroupBox_Free(AGroupBox: PGroupBox);
procedure GroupBox_Draw(AGroupBox: PGroupBox; ParentX, ParentY: Integer);

{==============================================================================}
{  TTOOLBAR                                                                    }
{==============================================================================}

type
  {-- Buton t�klama event'i: Sender=ToolBar, ButtonIndex=t�klanan buton --}
  PToolButton=^TToolButton;
  TToolButton = record
    Caption: PChar;
    IconIndex: Integer;
    Width: Integer;
    Pressed: Boolean;
    Enabled: Boolean;
    Separator: Boolean;
    Tag: Integer;
  end;

  PToolBar = ^TToolBar;
  TToolBarButtonClick = procedure(Sender: PToolBar; ButtonIndex: Integer) of object;


  TToolBar = object(TObject)
  public
    Buttons: array[0..15] of TToolButton;
    ButtonCount: Integer;
    ButtonHeight: Integer;
    ButtonWidth: Integer;
    HotIndex: Integer;
    PressIndex: Integer;
    SelectedIndex: Integer;           { <<< YEN�: Son t�klanan buton (-1 = yok) }
    TextColor: LongWord;
    BtnColor: LongWord;
    BtnPressedColor: LongWord;
    SeparatorColor: LongWord;
    OnButtonClick: TToolBarButtonClick; { <<< YEN�: Hangi butona t�kland���n� bil }
  end;
  

function  ToolBar_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PToolBar;
procedure ToolBar_Free(AToolBar: PToolBar);
function  ToolBar_AddButton(AToolBar: PToolBar; const ACaption: PChar; AIconIndex: Integer): Integer;
function ToolBar_AddSeparator(AToolBar: PToolBar):Integer;
procedure ToolBar_Draw(AToolBar: PToolBar; ParentX, ParentY: Integer);
procedure ToolBar_MouseDown(AToolBar: PToolBar; X, Y: Integer);
procedure ToolBar_MouseMove(AToolBar: PToolBar; X, Y: Integer);
procedure ToolBar_MouseUp(AToolBar: PToolBar; X, Y: Integer);


{  TCOMBOBOX                                                                   }
{==============================================================================}

type
  PComboBox = ^TComboBox;
  TComboBox = object(TObject)
  public
    Items: array[0..255] of PChar;
    ItemCount: Integer;
    ItemIndex: Integer;
    EditHeight: Integer;
    RowHeight: Integer;
    DropHeight: Integer;
    Dropped: Boolean;
    HoverIndex: Integer;
    ScrollY: Integer;
    BorderColor: LongWord;
    TextColor: LongWord;
    SelColor: LongWord;
    SelTextColor: LongWord;
    AltColor: LongWord;
    VScrollRect, VThumbRect: TRect;
    VScrollDrag: Boolean;
    VScrollDragStart: Integer;
    VScrollDragStartVal: Integer;
  end;

function  ComboBox_Create(AParent: PObject; ALeft, ATop, AWidth: Integer): PComboBox;
procedure ComboBox_Free(AComboBox: PComboBox);
procedure ComboBox_Clear(AComboBox: PComboBox);
function  ComboBox_AddItem(AComboBox: PComboBox; const S: PChar): Integer;
procedure ComboBox_Draw(AComboBox: PComboBox; ParentX, ParentY: Integer);
procedure ComboBox_ProcessKey(AComboBox: PComboBox; Key: Word; Shift: Byte);
procedure ComboBox_MouseDown(AComboBox: PComboBox; X, Y: Integer);
procedure ComboBox_MouseMove(AComboBox: PComboBox; X, Y: Integer);
procedure ComboBox_MouseUp(AComboBox: PComboBox; X, Y: Integer);


{==============================================================================}
{  TTREENODE                                                                   }
{==============================================================================}

type
  PTreeNode = ^TTreeNode;
  TTreeNode = record
    Caption: PChar;
    Level: Integer;
    Expanded: Boolean;
    HasChildren: Boolean;
    Parent: PTreeNode;
    FirstChild: PTreeNode;
    NextSibling: PTreeNode;
    PrevSibling: PTreeNode;
    Tag: Integer;
  end;

{==============================================================================}
{  TTREEVIEW                                                                   }
{==============================================================================}

type
  PTreeView = ^TTreeView;
  TTreeView = object(TObject)
  public
    Root: PTreeNode;
    RowHeight: Integer;
    ItemIndex: Integer;
    HoverIndex: Integer;
    ScrollY: Integer;
    BorderColor: LongWord;
    TextColor: LongWord;
    SelColor: LongWord;
    SelTextColor: LongWord;
    AltColor: LongWord;
    HoverColor: LongWord;
    LineColor: LongWord;
    BoxColor: LongWord;
    VisibleNodes: array[0..1023] of PTreeNode;
    VisibleCount: Integer;
    VScrollRect, VThumbRect: TRect;
    VScrollDrag: Boolean;
    VScrollDragStart: Integer;
    VScrollDragStartVal: Integer;
  end;

function  TreeNode_Create(const ACaption: PChar; AParent: PTreeNode): PTreeNode;
procedure TreeNode_Free(ANode: PTreeNode);
function  TreeView_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PTreeView;
procedure TreeView_Free(ATreeView: PTreeView);
procedure TreeView_Clear(ATreeView: PTreeView);
function  TreeView_AddNode(ATreeView: PTreeView; AParent: PTreeNode; const ACaption: PChar): PTreeNode;
procedure TreeView_Expand(ATreeView: PTreeView; ANode: PTreeNode);
procedure TreeView_Collapse(ATreeView: PTreeView; ANode: PTreeNode);
procedure TreeView_Draw(ATreeView: PTreeView; ParentX, ParentY: Integer);
procedure TreeView_ProcessKey(ATreeView: PTreeView; Key: Word; Shift: Byte);
procedure TreeView_MouseDown(ATreeView: PTreeView; X, Y: Integer);
procedure TreeView_MouseMove(ATreeView: PTreeView; X, Y: Integer);
procedure TreeView_MouseUp(ATreeView: PTreeView; X, Y: Integer);

{==============================================================================}
{  TTABCONTROL                                                                 }
{==============================================================================}

type
  TTabItem = record
    Caption: PChar;
    Page: PObject;        { Container for child components }
    CanClose: Boolean;
    CloseRect: TRect;
  end;

  PTabControl = ^TTabControl;
  TTabControl = object(TObject)
  public
    Tabs: array[0..15] of TTabItem;
    TabCount: Integer;
    ActiveTab: Integer;
    TabHeight: Integer;
    TabWidth: Integer;    { 0 = auto }
    ClientColor: LongWord;
    TabColor: LongWord;
    ActiveTabColor: LongWord;
    TextColor: LongWord;
    BorderColor: LongWord;
    ShowClose: Boolean;
    HScrollOffset: Integer;
  end;

function  TabControl_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PTabControl;
procedure TabControl_Free(ATabControl: PTabControl);
function  TabControl_AddTab(ATabControl: PTabControl; const ACaption: PChar): Integer;
procedure TabControl_RemoveTab(ATabControl: PTabControl; Index: Integer);
procedure TabControl_SetActiveTab(ATabControl: PTabControl; Index: Integer);
procedure TabControl_Draw(ATabControl: PTabControl; ParentX, ParentY: Integer);
procedure TabControl_MouseDown(ATabControl: PTabControl; X, Y: Integer);
procedure TabControl_MouseMove(ATabControl: PTabControl; X, Y: Integer);
procedure TabControl_MouseUp(ATabControl: PTabControl; X, Y: Integer);




{==============================================================================}
{  TMAINMENU                                                                   }
{==============================================================================}

{==============================================================================}
{  TMENUITEM                                                                   }
{==============================================================================}

type
  PMenuItem = ^TMenuItem;
  TMenuItem = record
    Caption: PChar;
    Checked: Boolean;
    Enabled: Boolean;
    Separator: Boolean;
    Tag: Integer;
    Parent: PMenuItem;
    Next: PMenuItem;
    Prev: PMenuItem;
    FirstChild: PMenuItem;
    OnClick: procedure(Sender: PMenuItem); 
  end;

function  MenuItem_Create(const ACaption: PChar; AParent: PMenuItem): PMenuItem;
procedure MenuItem_Free(AItem: PMenuItem);
function  MenuItem_Add(AParent: PMenuItem; const ACaption: PChar): PMenuItem;
procedure MenuItem_AddSeparator(AParent: PMenuItem);
function  MenuItem_Count(AItem: PMenuItem): Integer;
function  MenuItem_MaxWidth(AItem: PMenuItem): Integer;
function  MenuItem_FindByIndex(ARoot: PMenuItem; Index: Integer): PMenuItem;
function  MenuItem_IndexOf(ARoot: PMenuItem; AItem: PMenuItem): Integer;

{==============================================================================}
{  TMAINMENU                                                                   }
{==============================================================================}

type
  PMainMenu = ^TMainMenu;
  TMainMenu = object(TObject)
  public
    BarHeight: Integer;
    BarItems: array[0..15] of record
      Caption: PChar;
      Menu: PMenuItem;
    end;
    BarCount: Integer;
    ActiveBar: Integer;
    HoverBar: Integer;
    Dropped: Boolean;
    DropHeight: Integer;
    HoverItem: PMenuItem;
    SelColor: LongWord;
    TextColor: LongWord;
    AltColor: LongWord;
    BorderColor: LongWord;
    BoxColor: LongWord;
    ItemHeight: Integer;
  end;

function  MainMenu_Create(AParent: PObject; ALeft, ATop, AWidth: Integer): PMainMenu;
procedure MainMenu_Free(AMainMenu: PMainMenu);
function  MainMenu_AddMenu(AMainMenu: PMainMenu; const ACaption: PChar): PMenuItem;
procedure MainMenu_Draw(AMainMenu: PMainMenu; ParentX, ParentY: Integer);
procedure MainMenu_ProcessKey(AMainMenu: PMainMenu; Key: Word; Shift: Byte);
procedure MainMenu_MouseDown(AMainMenu: PMainMenu; X, Y: Integer);
procedure MainMenu_MouseMove(AMainMenu: PMainMenu; X, Y: Integer);
procedure MainMenu_MouseUp(AMainMenu: PMainMenu; X, Y: Integer);

{==============================================================================}
{  TPOPUPMENU                                                                  }
{==============================================================================}

type
  PPopupMenu = ^TPopupMenu;
  TPopupMenu = object(TObject)
  public
    Root: PMenuItem;
    ItemHeight: Integer;
    MenuWidth: Integer;
    HoverItem: PMenuItem;
    SelColor: LongWord;
    TextColor: LongWord;
    BorderColor: LongWord;
    BoxColor: LongWord;
  end;

function  PopupMenu_Create(AParent: PObject): PPopupMenu;
procedure PopupMenu_Free(APopup: PPopupMenu);
function  PopupMenu_AddItem(APopup: PPopupMenu; const ACaption: PChar): PMenuItem;
procedure PopupMenu_AddSeparator(APopup: PPopupMenu);
procedure PopupMenu_Show(APopup: PPopupMenu; AX, AY: Integer);
procedure PopupMenu_Hide(APopup: PPopupMenu);
procedure PopupMenu_Draw(APopup: PPopupMenu; ParentX, ParentY: Integer);
procedure PopupMenu_MouseDown(APopup: PPopupMenu; X, Y: Integer);
procedure PopupMenu_MouseMove(APopup: PPopupMenu; X, Y: Integer);
procedure PopupMenu_MouseUp(APopup: PPopupMenu; X, Y: Integer);


{==============================================================================}
{  TSPLITTER                                                                   }
{==============================================================================}





  type
  PSplitter = ^TSplitter;
  TSplitter = object(TObject)
  public
    Orientation: Byte;      { 0 = Dikey, 1 = Yatay }
    MinSize: Integer;
    Dragging: Boolean;
    StartPos: Integer;      { Absolute fare pozisyonu }
    StartSize: Integer;     { Hedefin baslangic boyutu }

    GripColor: LongWord;
  end;

function  Splitter_Create(AParent: PObject; ALeft, ATop, ASize: Integer; AOrientation: Byte): PSplitter;
procedure Splitter_Free(ASplitter: PSplitter);
procedure Splitter_Draw(ASplitter: PSplitter; ParentX, ParentY: Integer);
procedure Splitter_MouseDown(ASplitter: PSplitter; X, Y: Integer);
procedure Splitter_MouseMove(ASplitter: PSplitter; X, Y: Integer);
procedure Splitter_MouseUp(ASplitter: PSplitter; X, Y: Integer);


implementation

var
  ClipBuf: array[0..2047] of Char;
  ClipLen: Integer;

{==============================================================================}
{  STRING HELPERS                                                              }
{==============================================================================}

{==============================================================================}
{  Z-ORDER HELPER                                                              }
{==============================================================================}

procedure MoveObjectToFront(AObj: PObject);
var parent, child: PObject;
begin
  if AObj = nil then Exit;
  if AObj^.Parent = nil then
  begin
    Exit;
  end;
  parent := AObj^.Parent;

  { 1. Listeden ��kar }
  if parent^.Child = AObj then
    parent^.Child := AObj^.Next
  else
  begin
    child := parent^.Child;
    while (child <> nil) and (child^.Next <> AObj) do
      child := child^.Next;
    if child <> nil then
      child^.Next := AObj^.Next;
  end;

  { 2. En sona ekle (en �st z-order) }
  AObj^.Next := nil;
  if parent^.Child = nil then
    parent^.Child := AObj
  else
  begin
    child := parent^.Child;
    while child^.Next <> nil do
      child := child^.Next;
    child^.Next := AObj;
  end;
end;


procedure Component_DrawString(X, Y: Integer; S: PChar; Color: LongWord);
var i: Integer;
begin
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    KChar(X + i * 8, Y, S[i], Color);
    Inc(i);
  end;
end;

function Component_TextWidth(S: PChar): Integer;
begin
  Result := StrLen(S) * 8;
end;


function StrLenP(S: PChar): Integer;
var i: Integer;
begin
  Result := 0; if S = nil then Exit;
  i := 0; while S[i] <> #0 do Inc(i);
  Result := i;
end;

procedure StrCopyP(Dest, Src: PChar);
var i: Integer;
begin
  i := 0;
  while Src[i] <> #0 do begin Dest[i] := Src[i]; Inc(i); end;
  Dest[i] := #0;
end;

procedure StrCopyN(Dest, Src: PChar; N: Integer);
var i: Integer;
begin
  i := 0;
  while (i < N) and (Src[i] <> #0) do begin Dest[i] := Src[i]; Inc(i); end;
  Dest[i] := #0;
end;

{==============================================================================}
{  CLIPBOARD                                                                   }
{==============================================================================}

procedure Component_ClipboardSet(const S: PChar; Len: Integer);
begin
  if Len > 2047 then Len := 2047;
  if Len < 0 then Len := 0;
  MemCopy(@ClipBuf[0], S, Len);
  ClipBuf[Len] := #0;
  ClipLen := Len;
end;

function Component_ClipboardGet: PChar;
begin
  Result := @ClipBuf[0];
end;

function Component_ClipboardLen: Integer;
begin
  Result := ClipLen;
end;

{==============================================================================}
{  TEDIT                                                                       }
{==============================================================================}

procedure Edit_EnsureCapacity(AEdit: PEdit; Needed: Integer);
var newCap: Integer; newText: PChar;
begin
  if AEdit = nil then Exit;
  if Needed < AEdit^.TextCapacity then Exit;
  newCap := Needed + 256;
  newText := MemAlloc(newCap);
  if newText = nil then Exit;
  MemSet(newText, 0, newCap);
  if AEdit^.Text <> nil then
  begin
    MemCopy(newText, AEdit^.Text, AEdit^.TextLen);
    FreeMem(AEdit^.Text);
  end;
  AEdit^.Text := newText;
  AEdit^.TextCapacity := newCap;
end;

function Edit_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PEdit;
var ed: PEdit;
begin
  ed := MemAlloc(SizeOf(TEdit));
  if ed = nil then begin Result := nil; Exit; end;
  MemSet(ed, 0, SizeOf(TEdit));

  ed^.ObjectType := otEdit;
  ed^.Left := ALeft; ed^.Top := ATop;
  ed^.Width := AWidth; ed^.Height := AHeight;
  ed^.Color := $00FFFFFF;
  ed^.Visible := True;
  ed^.BorderColor := $00808080;
  ed^.TextColor := $00000000;
  ed^.SelColor := $000080FF;
  ed^.SelTextColor := $00FFFFFF;
  ed^.PasswordChar := #0;
  ed^.ReadOnly := False;

  ed^.TextCapacity := 256;
  ed^.Text := MemAlloc(ed^.TextCapacity);
  if ed^.Text <> nil then ed^.Text[0] := #0;
  ed^.TextLen := 0;
  ed^.CursorPos := 0;
  ed^.SelStart := 0;
  ed^.SelLength := 0;
  ed^.ScrollX := 0;

  ed^.OnDestroy:=@Edit_Free;

  if AParent <> nil then Object_AddChild(AParent, PObject(ed));
  Result := ed;
end;

procedure Edit_Free(AEdit: PEdit);
begin
  if AEdit = nil then Exit;
  if AEdit^.Text <> nil then FreeMem(AEdit^.Text);

end;

procedure Edit_SetText(AEdit: PEdit; const S: PChar);
var len: Integer;
begin
  if AEdit = nil then Exit;
  len := StrLenP(S);
  Edit_EnsureCapacity(AEdit, len + 1);
  StrCopyP(AEdit^.Text, S);
  AEdit^.TextLen := len;
  AEdit^.CursorPos := len;
  AEdit^.SelStart := 0;
  AEdit^.SelLength := 0;
  AEdit^.ScrollX := 0;
end;

procedure Edit_GetText(AEdit: PEdit; Dest: PChar; MaxLen: Integer);
begin
  if (AEdit = nil) or (Dest = nil) then Exit;
  StrCopyN(Dest, AEdit^.Text, MaxLen);
end;

procedure Edit_DeleteSelection(AEdit: PEdit);
var i, selEnd: Integer;
begin
  if AEdit = nil then Exit;
  if AEdit^.SelLength <= 0 then Exit;
  selEnd := AEdit^.SelStart + AEdit^.SelLength;
  i := AEdit^.SelStart;
  while i < AEdit^.TextLen - AEdit^.SelLength do
  begin
    AEdit^.Text[i] := AEdit^.Text[i + AEdit^.SelLength];
    Inc(i);
  end;
  AEdit^.TextLen := AEdit^.TextLen - AEdit^.SelLength;
  AEdit^.Text[AEdit^.TextLen] := #0;
  AEdit^.CursorPos := AEdit^.SelStart;
  AEdit^.SelLength := 0;
end;

procedure Edit_InsertChar(AEdit: PEdit; Ch: Char);
var i: Integer;
begin
  if AEdit = nil then Exit;
  if AEdit^.ReadOnly then Exit;
  if Ch = #0 then Exit;
  if AEdit^.SelLength > 0 then Edit_DeleteSelection(AEdit);
  Edit_EnsureCapacity(AEdit, AEdit^.TextLen + 2);
  i := AEdit^.TextLen;
  while i > AEdit^.CursorPos do
  begin
    AEdit^.Text[i] := AEdit^.Text[i - 1];
    Dec(i);
  end;
  AEdit^.Text[AEdit^.CursorPos] := Ch;
  Inc(AEdit^.TextLen);
  AEdit^.Text[AEdit^.TextLen] := #0;
  Inc(AEdit^.CursorPos);
end;

procedure Edit_DeleteChar(AEdit: PEdit; Backspace: Boolean);
var i: Integer;
begin
  if AEdit = nil then Exit;
  if AEdit^.ReadOnly then Exit;
  if AEdit^.SelLength > 0 then
  begin
    Edit_DeleteSelection(AEdit);
    Exit;
  end;
  if Backspace then
  begin
    if AEdit^.CursorPos <= 0 then Exit;
    i := AEdit^.CursorPos - 1;
    while i < AEdit^.TextLen - 1 do
    begin
      AEdit^.Text[i] := AEdit^.Text[i + 1];
      Inc(i);
    end;
    Dec(AEdit^.TextLen);
    AEdit^.Text[AEdit^.TextLen] := #0;
    Dec(AEdit^.CursorPos);
  end
  else
  begin
    if AEdit^.CursorPos >= AEdit^.TextLen then Exit;
    i := AEdit^.CursorPos;
    while i < AEdit^.TextLen - 1 do
    begin
      AEdit^.Text[i] := AEdit^.Text[i + 1];
      Inc(i);
    end;
    Dec(AEdit^.TextLen);
    AEdit^.Text[AEdit^.TextLen] := #0;
  end;
end;

procedure Edit_UpdateScroll(AEdit: PEdit);
var i, cursorX: Integer; ch: Char;
begin
  if AEdit = nil then Exit;
  cursorX := 0;
  i := 0;
  while i < AEdit^.CursorPos do
  begin
    if AEdit^.PasswordChar <> #0 then ch := AEdit^.PasswordChar
    else ch := AEdit^.Text[i];
    if ch = #9 then cursorX := cursorX + 32 else cursorX := cursorX + 8;
    Inc(i);
  end;
  if cursorX < AEdit^.ScrollX then
    AEdit^.ScrollX := cursorX
  else if cursorX > AEdit^.ScrollX + (AEdit^.Width - 12) then
    AEdit^.ScrollX := cursorX - (AEdit^.Width - 12);
  if AEdit^.ScrollX < 0 then AEdit^.ScrollX := 0;
end;

procedure Edit_Draw(AEdit: PEdit; ParentX, ParentY: Integer);
var
  absX, absY, i, x, charW: Integer;
  ch: Char;
  inSel: Boolean;
  textY: Integer;
begin
  if AEdit = nil then Exit;
  if not AEdit^.Visible then Exit;

  absX := ParentX + AEdit^.Left;
  absY := ParentY + AEdit^.Top;

  { 3D border + fill }
  KRect3D(absX, absY, AEdit^.Width, AEdit^.Height, False);
  KFill(absX + 2, absY + 2, AEdit^.Width - 4, AEdit^.Height - 4, AEdit^.Color);

  textY := absY + (AEdit^.Height - 8) div 2;

  { Metni �iz }
  x := absX + 4 - AEdit^.ScrollX;
  i := 0;
  while i < AEdit^.TextLen do
  begin
    if AEdit^.PasswordChar <> #0 then ch := AEdit^.PasswordChar
    else ch := AEdit^.Text[i];

    inSel := (AEdit^.SelLength > 0) and
             (i >= AEdit^.SelStart) and
             (i < AEdit^.SelStart + AEdit^.SelLength);

    if ch = #9 then charW := 32 else charW := 8;

    { Se�ili arka plan }
    if inSel then
      KFill(x, textY - 1, charW, 10, AEdit^.SelColor);

    { Karakter (clip i�indeyse) }
    if (x + charW > absX + 2) and (x < absX + AEdit^.Width - 2) then
    begin
      if inSel then KChar(x, textY, ch, AEdit^.SelTextColor)
      else KChar(x, textY, ch, AEdit^.TextColor);
    end;

    x := x + charW;
    Inc(i);
  end;

  { Cursor (dikey �izgi) }
  x := absX + 4 - AEdit^.ScrollX;
  i := 0;
  while i < AEdit^.CursorPos do
  begin
    if AEdit^.PasswordChar <> #0 then ch := AEdit^.PasswordChar
    else ch := AEdit^.Text[i];
    if ch = #9 then x := x + 32 else x := x + 8;
    Inc(i);
  end;
  if (x >= absX + 2) and (x < absX + AEdit^.Width - 2) then
    KLineV(x, textY - 1, 10, AEdit^.TextColor);
end;

procedure Edit_ProcessKey(AEdit: PEdit; Key: Word; Shift: Byte);
var
  ctrl, hasSel, shiftDown: Boolean;
 i:integer;
begin
  if AEdit = nil then Exit;
  ctrl := (Shift and 2) <> 0;
  shiftDown := (Shift and 1) <> 0;
  hasSel := AEdit^.SelLength > 0;

  case Key of
    8:  { Backspace }
      begin Edit_DeleteChar(AEdit, True); Edit_UpdateScroll(AEdit); end;
    46: { Delete }
      begin Edit_DeleteChar(AEdit, False); Edit_UpdateScroll(AEdit); end;
    37: { Left }
      begin
        if hasSel and not shiftDown then
        begin AEdit^.CursorPos := AEdit^.SelStart; AEdit^.SelLength := 0; end
        else
        begin
          if AEdit^.CursorPos > 0 then Dec(AEdit^.CursorPos);
          if shiftDown then
          begin
            if AEdit^.SelLength = 0 then begin AEdit^.SelStart := AEdit^.CursorPos + 1; AEdit^.SelLength := 1; end
            else if AEdit^.CursorPos < AEdit^.SelStart then begin Dec(AEdit^.SelStart); Inc(AEdit^.SelLength); end
            else Dec(AEdit^.SelLength);
          end
          else AEdit^.SelLength := 0;
        end;
        Edit_UpdateScroll(AEdit);
      end;
    39: { Right }
      begin
        if hasSel and not shiftDown then
        begin AEdit^.CursorPos := AEdit^.SelStart + AEdit^.SelLength; AEdit^.SelLength := 0; end
        else
        begin
          if AEdit^.CursorPos < AEdit^.TextLen then Inc(AEdit^.CursorPos);
          if shiftDown then
          begin
            if AEdit^.SelLength = 0 then begin AEdit^.SelStart := AEdit^.CursorPos - 1; AEdit^.SelLength := 1; end
            else if AEdit^.CursorPos > AEdit^.SelStart + AEdit^.SelLength then Inc(AEdit^.SelLength)
            else begin Dec(AEdit^.SelLength); Inc(AEdit^.SelStart); end;
          end
          else AEdit^.SelLength := 0;
        end;
        Edit_UpdateScroll(AEdit);
      end;
    36: { Home }
      begin AEdit^.CursorPos := 0; if not shiftDown then AEdit^.SelLength := 0; Edit_UpdateScroll(AEdit); end;
    35: { End }
      begin AEdit^.CursorPos := AEdit^.TextLen; if not shiftDown then AEdit^.SelLength := 0; Edit_UpdateScroll(AEdit); end;
    65: { A - Ctrl+A }
      if ctrl then begin AEdit^.SelStart := 0; AEdit^.SelLength := AEdit^.TextLen; end
      else begin Edit_InsertChar(AEdit, Char(Key)); Edit_UpdateScroll(AEdit); end;
    67: { C - Ctrl+C }
      if ctrl and hasSel then Component_ClipboardSet(@AEdit^.Text[AEdit^.SelStart], AEdit^.SelLength);
    86: { V - Ctrl+V }
      if ctrl then
      begin
        if hasSel then Edit_DeleteSelection(AEdit);
        for i := 0 to ClipLen - 1 do
          if (ClipBuf[i] <> #13) and (ClipBuf[i] <> #10) then
            Edit_InsertChar(AEdit, ClipBuf[i]);
        Edit_UpdateScroll(AEdit);
      end;
    88: { X - Ctrl+X }
      if ctrl and hasSel then
      begin
        Component_ClipboardSet(@AEdit^.Text[AEdit^.SelStart], AEdit^.SelLength);
        Edit_DeleteSelection(AEdit);
        Edit_UpdateScroll(AEdit);
      end;
  else
    if (Key >= 32) and (Key < 127) then
    begin
      Edit_InsertChar(AEdit, Char(Key));
      Edit_UpdateScroll(AEdit);
    end;
  end;
end;

procedure Edit_MouseDown(AEdit: PEdit; X, Y: Integer);
var relX, i, charW: Integer; ch: Char;
begin
  if AEdit = nil then Exit;
  relX := X - 4 + AEdit^.ScrollX;  { Left ��karma YOK, X zaten local }
  
  AEdit^.CursorPos := 0; i := 0;
  while i < AEdit^.TextLen do
  begin
    if AEdit^.PasswordChar <> #0 then ch := AEdit^.PasswordChar else ch := AEdit^.Text[i];
    if ch = #9 then charW := 32 else charW := 8;
    if relX < charW div 2 then Break;
    relX := relX - charW;
    Inc(AEdit^.CursorPos); Inc(i);
  end;
  AEdit^.SelStart := AEdit^.CursorPos;
  AEdit^.SelLength := 0;
end;



procedure Edit_MouseMove(AEdit: PEdit; X, Y: Integer);
var relX, i, charW, newPos: Integer; ch: Char;
begin
  if AEdit = nil then Exit;
  relX := X - 4 + AEdit^.ScrollX;  { Left ��karma YOK }
  
  newPos := 0; i := 0;
  while i < AEdit^.TextLen do
  begin
    if AEdit^.PasswordChar <> #0 then ch := AEdit^.PasswordChar else ch := AEdit^.Text[i];
    if ch = #9 then charW := 32 else charW := 8;
    if relX < charW div 2 then Break;
    relX := relX - charW;
    Inc(newPos); Inc(i);
  end;
  
  if newPos < AEdit^.SelStart then
  begin 
    AEdit^.CursorPos := newPos; 
    AEdit^.SelLength := AEdit^.SelStart - newPos; 
    AEdit^.SelStart := newPos; 
  end
  else
  begin 
    AEdit^.CursorPos := newPos; 
    AEdit^.SelLength := newPos - AEdit^.SelStart; 
  end;
end;

{==============================================================================}
{  TMEMO                                                                       }
{==============================================================================}

function Memo_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PMemo;
var mm: PMemo;
begin
  mm := MemAlloc(SizeOf(TMemo));
  if mm = nil then begin Result := nil; Exit; end;
  MemSet(mm, 0, SizeOf(TMemo));

  mm^.ObjectType := otMemo;
  mm^.Left := ALeft; mm^.Top := ATop;
  mm^.Width := AWidth; mm^.Height := AHeight;
  mm^.Color := $00FFFFFF;
  mm^.Visible := True;
  mm^.BorderColor := $00808080;
  mm^.TextColor := $00000000;
  mm^.SelColor := $000080FF;
  mm^.SelTextColor := $00FFFFFF;
  mm^.ReadOnly := False;
  mm^.WordWrap := False;
  mm^.ShowScrollBars := True;
  mm^.LineCount := 0;
  mm^.CursorX := 0; mm^.CursorY := 0;
  mm^.SelStartX := 0; mm^.SelStartY := 0;
  mm^.SelEndX := 0; mm^.SelEndY := 0;
  mm^.ScrollX := 0; mm^.ScrollY := 0;
  mm^.VScrollDrag := False; mm^.HScrollDrag := False;
  mm^.OnDestroy:=@Memo_Free;

  if AParent <> nil then Object_AddChild(AParent, PObject(mm));
  Result := mm;
end;

procedure Memo_Free(AMemo: PObject);
var
  i: Integer;
  Memo:PMemo;
begin
  if AMemo = nil then Exit;

  Memo:=PMemo(AMemo);

  for i := 0 to Memo^.LineCount - 1 do
    if Memo^.Lines[i] <> nil then FreeMem(Memo^.Lines[i]);

end;

procedure Memo_EnsureLine(AMemo: PMemo; Index: Integer);
var p: PChar;
begin
  if AMemo = nil then Exit;
  while AMemo^.LineCount <= Index do
  begin
    p := MemAlloc(256);
    if p <> nil then p[0] := #0;
    AMemo^.Lines[AMemo^.LineCount] := p;
    Inc(AMemo^.LineCount);
  end;
end;

function Memo_MaxLineLen(AMemo: PMemo): Integer;
var
  i, len: Integer;
begin
  Result := 0;
  if AMemo = nil then Exit;
  for i := 0 to AMemo^.LineCount - 1 do
  begin
    if AMemo^.Lines[i] <> nil then
    begin
      len := StrLenP(AMemo^.Lines[i]);
      if len > Result then Result := len;
    end;
  end;
end;

function Memo_LineLen(AMemo: PMemo; Y: Integer): Integer;
begin
  Result := 0;
  if AMemo = nil then Exit;
  if (Y < 0) or (Y >= AMemo^.LineCount) then Exit;
  if AMemo^.Lines[Y] = nil then Exit;
  Result := StrLenP(AMemo^.Lines[Y]);
end;

procedure Memo_InsertChar(AMemo: PMemo; Ch: Char);
var
  line: PChar;
  len, i: Integer;
  newLine: PChar;
begin
  if AMemo = nil then Exit;
  if AMemo^.ReadOnly then Exit;
  Memo_EnsureLine(AMemo, AMemo^.CursorY);
  line := AMemo^.Lines[AMemo^.CursorY];
  len := StrLenP(line);

  if Ch = #13 then
  begin
    { Sat�r b�l: Cursor'dan sonraki k�s�m yeni sat�ra }
    newLine := MemAlloc(256);
    if newLine = nil then Exit;
    newLine[0] := #0;
    i := AMemo^.CursorX;
    while i < len do
    begin
      newLine[i - AMemo^.CursorX] := line[i];
      Inc(i);
    end;
    newLine[len - AMemo^.CursorX] := #0;
    line[AMemo^.CursorX] := #0;

    { Sat�rlar� kayd�r (a�a��) }
    if AMemo^.LineCount < 255 then
    begin
      for i := AMemo^.LineCount downto AMemo^.CursorY + 2 do
        AMemo^.Lines[i] := AMemo^.Lines[i - 1];
      AMemo^.Lines[AMemo^.CursorY + 1] := newLine;
      Inc(AMemo^.LineCount);
    end
    else
      FreeMem(newLine);

    AMemo^.CursorX := 0;
    Inc(AMemo^.CursorY);
  end
  else
  begin
    if len >= 255 then Exit;
    i := len;
    while i > AMemo^.CursorX do
    begin
      line[i] := line[i - 1];
      Dec(i);
    end;
    line[AMemo^.CursorX] := Ch;
    line[len + 1] := #0;
    Inc(AMemo^.CursorX);
  end;
end;

procedure Memo_DeleteChar(AMemo: PMemo; Backspace: Boolean);
var
  line, nextLine: PChar;
  len, i, nextLen: Integer;
begin
  if AMemo = nil then Exit;
  if AMemo^.ReadOnly then Exit;
  if AMemo^.LineCount = 0 then Exit;
  if (AMemo^.CursorY < 0) or (AMemo^.CursorY >= AMemo^.LineCount) then Exit;

  line := AMemo^.Lines[AMemo^.CursorY];
  len := StrLenP(line);

  if Backspace then
  begin
    if AMemo^.CursorX > 0 then
    begin
      i := AMemo^.CursorX - 1;
      while i < len - 1 do
      begin
        line[i] := line[i + 1];
        Inc(i);
      end;
      line[len - 1] := #0;
      Dec(AMemo^.CursorX);
    end
    else if AMemo^.CursorY > 0 then
    begin
      { Sat�r birle�tir: mevcut sat�r� �st sat�r�n sonuna ekle }
      nextLine := AMemo^.Lines[AMemo^.CursorY];
      nextLen := StrLenP(AMemo^.Lines[AMemo^.CursorY - 1]);
      i := 0;
      while (i < StrLenP(nextLine)) and (nextLen + i < 255) do
      begin
        AMemo^.Lines[AMemo^.CursorY - 1][nextLen + i] := nextLine[i];
        Inc(i);
      end;
      AMemo^.Lines[AMemo^.CursorY - 1][nextLen + i] := #0;
      FreeMem(nextLine);

      { Sat�rlar� yukar� kayd�r }
      for i := AMemo^.CursorY to AMemo^.LineCount - 2 do
        AMemo^.Lines[i] := AMemo^.Lines[i + 1];
      Dec(AMemo^.LineCount);
      AMemo^.Lines[AMemo^.LineCount] := nil;

      Dec(AMemo^.CursorY);
      AMemo^.CursorX := nextLen;
    end;
  end
  else
  begin
    { Delete (sa�dan sil) }
    if AMemo^.CursorX < len then
    begin
      i := AMemo^.CursorX;
      while i < len - 1 do
      begin
        line[i] := line[i + 1];
        Inc(i);
      end;
      line[len - 1] := #0;
    end
    else if AMemo^.CursorY < AMemo^.LineCount - 1 then
    begin
      { Sonraki sat�r� mevcut sat�r�n sonuna birle�tir }
      nextLine := AMemo^.Lines[AMemo^.CursorY + 1];
      i := 0;
      while (i < StrLenP(nextLine)) and (len + i < 255) do
      begin
        line[len + i] := nextLine[i];
        Inc(i);
      end;
      line[len + i] := #0;
      FreeMem(nextLine);

      for i := AMemo^.CursorY + 1 to AMemo^.LineCount - 2 do
        AMemo^.Lines[i] := AMemo^.Lines[i + 1];
      Dec(AMemo^.LineCount);
      AMemo^.Lines[AMemo^.LineCount] := nil;
    end;
  end;
end;

procedure Memo_SetText(AMemo: PMemo; const S: PChar);
var
  i, lineIdx, pos: Integer;
  ch: Char;
  line: PChar;
begin
  if AMemo = nil then Exit;
  { �nce temizle }
  for i := 0 to AMemo^.LineCount - 1 do
    if AMemo^.Lines[i] <> nil then FreeMem(AMemo^.Lines[i]);
  AMemo^.LineCount := 0;

  { Parse lines }
  lineIdx := 0; pos := 0;
  Memo_EnsureLine(AMemo, 0);
  line := AMemo^.Lines[0];

  i := 0;
  while S[i] <> #0 do
  begin
    ch := S[i];
    if (ch = #13) or (ch = #10) then
    begin
      line[pos] := #0;
      Inc(lineIdx); pos := 0;
      Memo_EnsureLine(AMemo, lineIdx);
      line := AMemo^.Lines[lineIdx];
      if (S[i + 1] <> #0) and ((S[i+1] = #13) or (S[i+1] = #10)) and (S[i+1] <> ch) then
        Inc(i); { CRLF atla }
    end
    else
    begin
      if pos < 255 then
      begin
        line[pos] := ch;
        Inc(pos);
      end;
    end;
    Inc(i);
  end;
  line[pos] := #0;
  AMemo^.CursorX := 0; AMemo^.CursorY := 0;
  AMemo^.ScrollX := 0; AMemo^.ScrollY := 0;
end;

procedure Memo_UpdateScroll(AMemo: PMemo);
var
  cursorPixelX, cursorPixelY: Integer;
  line: PChar;
begin
  if AMemo = nil then Exit;
  if (AMemo^.CursorY >= 0) and (AMemo^.CursorY < AMemo^.LineCount) then
    line := AMemo^.Lines[AMemo^.CursorY]
  else
    line := nil;

  cursorPixelX := AMemo^.CursorX * 8;
  cursorPixelY := AMemo^.CursorY * 14;

  if cursorPixelX < AMemo^.ScrollX then
    AMemo^.ScrollX := cursorPixelX
  else if cursorPixelX > AMemo^.ScrollX + (AMemo^.Width - 24) then
    AMemo^.ScrollX := cursorPixelX - (AMemo^.Width - 24);

  if cursorPixelY < AMemo^.ScrollY then
    AMemo^.ScrollY := cursorPixelY
  else if cursorPixelY > AMemo^.ScrollY + (AMemo^.Height - 24) then
    AMemo^.ScrollY := cursorPixelY - (AMemo^.Height - 24);

  if AMemo^.ScrollX < 0 then AMemo^.ScrollX := 0;
  if AMemo^.ScrollY < 0 then AMemo^.ScrollY := 0;
end;

procedure Memo_SelectAll(AMemo: PMemo);
begin
  if AMemo = nil then Exit;
  if AMemo^.LineCount = 0 then Exit;
  AMemo^.SelStartX := 0; AMemo^.SelStartY := 0;
  AMemo^.SelEndY := AMemo^.LineCount - 1;
  AMemo^.SelEndX := StrLenP(AMemo^.Lines[AMemo^.SelEndY]);
end;

procedure Memo_ClearSelection(AMemo: PMemo);
begin
  if AMemo = nil then Exit;
  AMemo^.SelStartX := 0; AMemo^.SelStartY := 0;
  AMemo^.SelEndX := 0; AMemo^.SelEndY := 0;
end;

procedure Memo_GetSelectedText(AMemo: PMemo; Dest: PChar; MaxLen: Integer);
var
  sx, sy, ex, ey, i, len, di: Integer;
  line: PChar;
begin
  if AMemo = nil then Exit;
  Dest[0] := #0; if MaxLen <= 0 then Exit;

  sx := AMemo^.SelStartX; sy := AMemo^.SelStartY;
  ex := AMemo^.SelEndX;   ey := AMemo^.SelEndY;

  if (sy > ey) or ((sy = ey) and (sx > ex)) then
  begin
    i := sx; sx := ex; ex := i;
    i := sy; sy := ey; ey := i;
  end;

  di := 0;
  while (sy < ey) or ((sy = ey) and (sx < ex)) do
  begin
    if (sy >= 0) and (sy < AMemo^.LineCount) then
    begin
      line := AMemo^.Lines[sy];
      len := StrLenP(line);
      i := sx;
      while (i < len) and (di < MaxLen - 1) do
      begin
        Dest[di] := line[i];
        Inc(di); Inc(i);
      end;
    end;
    if sy < ey then
    begin
      if di < MaxLen - 1 then begin Dest[di] := #13; Inc(di); end;
      sx := 0; Inc(sy);
    end
    else
      Break;
  end;
  Dest[di] := #0;
end;

procedure Memo_DeleteSelection(AMemo: PMemo);
var
  sx, sy, ex, ey, i, j, len: Integer;
  line, nextLine: PChar;
begin
  if AMemo = nil then Exit;
  sx := AMemo^.SelStartX; sy := AMemo^.SelStartY;
  ex := AMemo^.SelEndX;   ey := AMemo^.SelEndY;

  if (sy > ey) or ((sy = ey) and (sx > ex)) then
  begin begin i := sx; sx := ex; ex := i; end; begin i := sy; sy := ey; ey := i; end; end;

  if (sy = ey) and (sx = ex) then Exit;

  { �lk sat�r: sx'den sona kadar sil, son sat�rdan ex'e kadar olan k�sm� ekle }
  line := AMemo^.Lines[sy];
  len := StrLenP(line);
  { Son sat�rdan ex sonras�n� al }
  if ey < AMemo^.LineCount then
  begin
    nextLine := AMemo^.Lines[ey];
    i := sx; j := ex;
    while (j < 255) and (nextLine[j] <> #0) and (i < 255) do
    begin
      line[i] := nextLine[j];
      Inc(i); Inc(j);
    end;
    line[i] := #0;
  end
  else
    line[sx] := #0;

  { Ara sat�rlar� sil (ey'den sy+1'e kadar olanlar) }
  for i := sy + 1 to AMemo^.LineCount - 1 - (ey - sy) do
  begin
    if AMemo^.Lines[i + (ey - sy)] <> nil then
    begin
      if AMemo^.Lines[i] <> nil then FreeMem(AMemo^.Lines[i]);
      AMemo^.Lines[i] := AMemo^.Lines[i + (ey - sy)];
    end;
  end;
  for i := AMemo^.LineCount - (ey - sy) to AMemo^.LineCount - 1 do
    AMemo^.Lines[i] := nil;
  AMemo^.LineCount := AMemo^.LineCount - (ey - sy);

  AMemo^.CursorX := sx;
  AMemo^.CursorY := sy;
  Memo_ClearSelection(AMemo);
end;

procedure Memo_Copy(AMemo: PMemo);
var buf: array[0..2047] of Char;
begin
  if AMemo = nil then Exit;
  Memo_GetSelectedText(AMemo, @buf[0], 2047);
  Component_ClipboardSet(@buf[0], StrLenP(@buf[0]));
end;

procedure Memo_Cut(AMemo: PMemo);
begin
  if AMemo = nil then Exit;
  Memo_Copy(AMemo);
  if not AMemo^.ReadOnly then Memo_DeleteSelection(AMemo);
end;

procedure Memo_Paste(AMemo: PMemo);
var
  i: Integer;
  ch: Char;
begin
  if AMemo = nil then Exit;
  if AMemo^.ReadOnly then Exit;
  if not AMemo^.ReadOnly then Memo_DeleteSelection(AMemo);
  i := 0;
  while (i < ClipLen) and (i < 2047) do
  begin
    ch := ClipBuf[i];
    if ch = #10 then begin Inc(i); Continue; end;
    if ch = #13 then ch := #13;
    Memo_InsertChar(AMemo, ch);
    Inc(i);
  end;
  Memo_UpdateScroll(AMemo);
end;

procedure Memo_Draw(AMemo: PMemo; ParentX, ParentY: Integer);
var
  absX, absY, i,j, x, y, lineLen, charW: Integer;
  line: PChar;
  ch: Char;
  inSel: Boolean;
  selSY, selEY, selSX, selEX: Integer;
  tmp: Integer;
  clientW, clientH: Integer;
  needV, needH: Boolean;
  maxLineLen: Integer;
  thumbSize, trackSize: Integer;
begin
  if AMemo = nil then Exit;
  if not AMemo^.Visible then Exit;

  absX := ParentX + AMemo^.Left;
  absY := ParentY + AMemo^.Top;

  clientW := AMemo^.Width - 4;
  clientH := AMemo^.Height - 4;

  { ScrollBar hesapla }
  needV := False; needH := False;
  maxLineLen := 0;
  for i := 0 to AMemo^.LineCount - 1 do
  begin
    lineLen := StrLenP(AMemo^.Lines[i]);
    if lineLen > maxLineLen then maxLineLen := lineLen;
  end;
  if AMemo^.LineCount * 14 > clientH then needV := True;
  if maxLineLen * 8 > clientW then needH := True;
  if needV and not needH then
    if maxLineLen * 8 > (clientW - 16) then needH := True;
  if needH and not needV then
    if AMemo^.LineCount * 14 > (clientH - 16) then needV := True;

  if needV then Dec(clientW, 16);
  if needH then Dec(clientH, 16);

  { 3D border + fill }
  KRect3D(absX, absY, AMemo^.Width, AMemo^.Height, False);
  KFill(absX + 2, absY + 2, AMemo^.Width - 4, AMemo^.Height - 4, AMemo^.Color);

  Clip_Save;
  Clip_Set(absX + 2, absY + 2, absX + 2 + clientW - 1, absY + 2 + clientH - 1);

  { Se�im s�n�rlar� (normalize) }
  selSY := AMemo^.SelStartY; selSX := AMemo^.SelStartX;
  selEY := AMemo^.SelEndY;   selEX := AMemo^.SelEndX;
  if (selSY > selEY) or ((selSY = selEY) and (selSX > selEX)) then
  begin
    tmp := selSX; selSX := selEX; selEX := tmp;
    tmp := selSY; selSY := selEY; selEY := tmp;
  end;

  { Sat�rlar� �iz }
  i := AMemo^.ScrollY div 14;
  if i < 0 then i := 0;
  while (i < AMemo^.LineCount) and (i * 14 - AMemo^.ScrollY < clientH) do
  begin
    line := AMemo^.Lines[i];
    lineLen := StrLenP(line);
    y := absY + 4 + (i * 14) - AMemo^.ScrollY;
    x := absX + 4 - AMemo^.ScrollX;

    for j := 0 to lineLen - 1 do
    begin
      ch := line[j];
      charW := 8;

      { Se�im kontrol� }
      inSel := False;
      if (i > selSY) and (i < selEY) then inSel := True
      else if (i = selSY) and (i = selEY) then inSel := (j >= selSX) and (j < selEX)
      else if (i = selSY) then inSel := (j >= selSX)
      else if (i = selEY) then inSel := (j < selEX);

      if inSel then
        KFill(x, y - 1, charW, 10, AMemo^.SelColor);

      if (x + charW > absX + 2) and (x < absX + 2 + clientW) then
      begin
        if inSel then KChar(x, y, ch, AMemo^.SelTextColor)
        else KChar(x, y, ch, AMemo^.TextColor);
      end;
      x := x + charW;
    end;
    Inc(i);
  end;

  { Cursor }
  if (AMemo^.CursorY >= 0) and (AMemo^.CursorY < AMemo^.LineCount) then
  begin
    x := absX + 4 + (AMemo^.CursorX * 8) - AMemo^.ScrollX;
    y := absY + 4 + (AMemo^.CursorY * 14) - AMemo^.ScrollY;
    if (x >= absX + 2) and (x < absX + 2 + clientW) and
       (y >= absY + 2) and (y < absY + 2 + clientH) then
      KLineV(x, y - 1, 10, AMemo^.TextColor);
  end;

  Clip_Restore;

  { ScrollBar �izim }
  if needV then
  begin
    AMemo^.VScrollRect.Left := AMemo^.Width - 18;
    AMemo^.VScrollRect.Top := 2;
    AMemo^.VScrollRect.Right := AMemo^.VScrollRect.Left + 16;
    AMemo^.VScrollRect.Bottom := AMemo^.Height - 2;
    if needH then Dec(AMemo^.VScrollRect.Bottom, 16);

    KFill(absX + AMemo^.VScrollRect.Left, absY + AMemo^.VScrollRect.Top,
          16, AMemo^.VScrollRect.Bottom - AMemo^.VScrollRect.Top, $00E0E0E0);
    KRect(absX + AMemo^.VScrollRect.Left, absY + AMemo^.VScrollRect.Top,
          16, AMemo^.VScrollRect.Bottom - AMemo^.VScrollRect.Top, $00808080);

    { Thumb }
    trackSize := AMemo^.VScrollRect.Bottom - AMemo^.VScrollRect.Top - 32;
    if AMemo^.LineCount * 14 > clientH then
    begin
      thumbSize := (clientH * trackSize) div (AMemo^.LineCount * 14);
      if thumbSize < 8 then thumbSize := 8;
      AMemo^.VThumbRect.Left := AMemo^.VScrollRect.Left + 2;
      AMemo^.VThumbRect.Top := AMemo^.VScrollRect.Top + 16 +
        (AMemo^.ScrollY * (trackSize - thumbSize) div (AMemo^.LineCount * 14 - clientH));
      AMemo^.VThumbRect.Right := AMemo^.VScrollRect.Right - 2;
      AMemo^.VThumbRect.Bottom := AMemo^.VThumbRect.Top + thumbSize;
      KButton3D(absX + AMemo^.VThumbRect.Left, absY + AMemo^.VThumbRect.Top,
                AMemo^.VThumbRect.Right - AMemo^.VThumbRect.Left,
                AMemo^.VThumbRect.Bottom - AMemo^.VThumbRect.Top, False, $00D0D0D0);
    end;
  end;

  if needH then
  begin
    AMemo^.HScrollRect.Left := 2;
    AMemo^.HScrollRect.Top := AMemo^.Height - 18;
    AMemo^.HScrollRect.Right := AMemo^.Width - 2;
    if needV then Dec(AMemo^.HScrollRect.Right, 16);
    AMemo^.HScrollRect.Bottom := AMemo^.HScrollRect.Top + 16;

    KFill(absX + AMemo^.HScrollRect.Left, absY + AMemo^.HScrollRect.Top,
          AMemo^.HScrollRect.Right - AMemo^.HScrollRect.Left, 16, $00E0E0E0);
    KRect(absX + AMemo^.HScrollRect.Left, absY + AMemo^.HScrollRect.Top,
          AMemo^.HScrollRect.Right - AMemo^.HScrollRect.Left, 16, $00808080);

    { Thumb }
    trackSize := AMemo^.HScrollRect.Right - AMemo^.HScrollRect.Left - 32;
    if maxLineLen * 8 > clientW then
    begin
      thumbSize := (clientW * trackSize) div (maxLineLen * 8);
      if thumbSize < 8 then thumbSize := 8;
      AMemo^.HThumbRect.Left := AMemo^.HScrollRect.Left + 16 +
        (AMemo^.ScrollX * (trackSize - thumbSize) div (maxLineLen * 8 - clientW));
      AMemo^.HThumbRect.Top := AMemo^.HScrollRect.Top + 2;
      AMemo^.HThumbRect.Right := AMemo^.HThumbRect.Left + thumbSize;
      AMemo^.HThumbRect.Bottom := AMemo^.HScrollRect.Bottom - 2;
      KButton3D(absX + AMemo^.HThumbRect.Left, absY + AMemo^.HThumbRect.Top,
                AMemo^.HThumbRect.Right - AMemo^.HThumbRect.Left,
                AMemo^.HThumbRect.Bottom - AMemo^.HThumbRect.Top, False, $00D0D0D0);
    end;
  end;

  { K��e kesi�imi }
  if needV and needH then
    KFill(absX + AMemo^.Width - 18, absY + AMemo^.Height - 18, 16, 16, $00C0C0C0);
end;

procedure Memo_ProcessKey(AMemo: PMemo; Key: Word; Shift: Byte);
var
  ctrl, shiftDown: Boolean;
  line: PChar;
  len: Integer;
begin
  if AMemo = nil then Exit;
  ctrl := (Shift and 2) <> 0;
  shiftDown := (Shift and 1) <> 0;

  case Key of
    8:begin { Backspace }
     // begin Memo_DeleteChar(AMemo, True); Memo_UpdateScroll(AMemo); end;
       if (AMemo^.SelStartX <> AMemo^.SelEndX) or (AMemo^.SelStartY <> AMemo^.SelEndY) then
      Memo_DeleteSelection(AMemo)
    else
      Memo_DeleteChar(AMemo, False);
    Memo_UpdateScroll(AMemo);
    end;
    46: { Delete }
  begin 
    if (AMemo^.SelStartX <> AMemo^.SelEndX) or (AMemo^.SelStartY <> AMemo^.SelEndY) then
      Memo_DeleteSelection(AMemo)
    else
      Memo_DeleteChar(AMemo, False);
    Memo_UpdateScroll(AMemo);
  end;
   { 46: // Delete
      begin Memo_DeleteChar(AMemo, False); Memo_UpdateScroll(AMemo); end; }
    13: { Enter }
      if not AMemo^.ReadOnly then
      begin Memo_InsertChar(AMemo, #13); Memo_UpdateScroll(AMemo); end;
    37: { Left }
      begin
        if AMemo^.CursorX > 0 then Dec(AMemo^.CursorX)
        else if AMemo^.CursorY > 0 then
        begin Dec(AMemo^.CursorY); AMemo^.CursorX := Memo_LineLen(AMemo, AMemo^.CursorY); end;
        if not shiftDown then Memo_ClearSelection(AMemo);
        Memo_UpdateScroll(AMemo);
      end;
    38: { Up }
      begin
        if AMemo^.CursorY > 0 then
        begin
          Dec(AMemo^.CursorY);
          len := Memo_LineLen(AMemo, AMemo^.CursorY);
          if AMemo^.CursorX > len then AMemo^.CursorX := len;
        end;
        if not shiftDown then Memo_ClearSelection(AMemo);
        Memo_UpdateScroll(AMemo);
      end;
    39: { Right }
      begin
        len := Memo_LineLen(AMemo, AMemo^.CursorY);
        if AMemo^.CursorX < len then Inc(AMemo^.CursorX)
        else if AMemo^.CursorY < AMemo^.LineCount - 1 then
        begin Inc(AMemo^.CursorY); AMemo^.CursorX := 0; end;
        if not shiftDown then Memo_ClearSelection(AMemo);
        Memo_UpdateScroll(AMemo);
      end;
    40: { Down }
      begin
        if AMemo^.CursorY < AMemo^.LineCount - 1 then
        begin
          Inc(AMemo^.CursorY);
          len := Memo_LineLen(AMemo, AMemo^.CursorY);
          if AMemo^.CursorX > len then AMemo^.CursorX := len;
        end;
        if not shiftDown then Memo_ClearSelection(AMemo);
        Memo_UpdateScroll(AMemo);
      end;
    36: { Home }
      begin AMemo^.CursorX := 0; if not shiftDown then Memo_ClearSelection(AMemo); Memo_UpdateScroll(AMemo); end;
    35: { End }
      begin AMemo^.CursorX := Memo_LineLen(AMemo, AMemo^.CursorY); if not shiftDown then Memo_ClearSelection(AMemo); Memo_UpdateScroll(AMemo); end;
    65: { A - Ctrl+A }
      if ctrl then Memo_SelectAll(AMemo)
      else if not AMemo^.ReadOnly then begin Memo_InsertChar(AMemo, Char(Key)); Memo_UpdateScroll(AMemo); end;
    67: { C - Ctrl+C }
      if ctrl then Memo_Copy(AMemo);
    86: { V - Ctrl+V }
      if ctrl then Memo_Paste(AMemo);
    88: { X - Ctrl+X }
      if ctrl then Memo_Cut(AMemo);
  else
    if (Key >= 32) and (Key < 127) and not AMemo^.ReadOnly then
    begin
      Memo_InsertChar(AMemo, Char(Key));
      Memo_UpdateScroll(AMemo);
    end;
  end;

  { Shift ile se�im }
  if shiftDown and ((Key = 37) or (Key = 38) or (Key = 39) or (Key = 40) or
      (Key = 36) or (Key = 35)) then
  begin
    AMemo^.SelEndX := AMemo^.CursorX;
    AMemo^.SelEndY := AMemo^.CursorY;
  end;
end;

procedure Memo_MouseDown(AMemo: PMemo; X, Y: Integer);
var
  relX, relY, lineIdx, colIdx, len, i: Integer;
  needV, needH: Boolean;
  clientW, clientH: Integer;
  maxLineLen, lineLen: Integer;
begin
  if AMemo = nil then Exit;

  { ScrollBar hit test (X,Y art�k local!) }
  needV := AMemo^.LineCount * 14 > (AMemo^.Height - 4);
  needH := False;
  maxLineLen := 0;
  for i := 0 to AMemo^.LineCount - 1 do
  begin
    lineLen := StrLenP(AMemo^.Lines[i]);
    if lineLen > maxLineLen then maxLineLen := lineLen;
  end;
  if maxLineLen * 8 > (AMemo^.Width - 4) then needH := True;
  if needV and not needH then if maxLineLen * 8 > (AMemo^.Width - 20) then needH := True;
  if needH and not needV then if AMemo^.LineCount * 14 > (AMemo^.Height - 20) then needV := True;

  clientW := AMemo^.Width - 4; if needV then Dec(clientW, 16);
  clientH := AMemo^.Height - 4; if needH then Dec(clientH, 16);

  { VScroll t�klama (local X,Y) }
  if needV and (X >= AMemo^.Width - 18) and
     (X < AMemo^.Width - 2) and
     (Y >= 2) and (Y < AMemo^.Height - 2 - (Ord(needH) * 16)) then
  begin
    if (Y >= AMemo^.VThumbRect.Top) and
       (Y < AMemo^.VThumbRect.Bottom) then
    begin
      AMemo^.VScrollDrag := True;
      AMemo^.VScrollDragStart := Y;
      AMemo^.VScrollDragStartVal := AMemo^.ScrollY;
    end
    else if Y < AMemo^.VThumbRect.Top then
    begin
      AMemo^.ScrollY := AMemo^.ScrollY - clientH;
      if AMemo^.ScrollY < 0 then AMemo^.ScrollY := 0;
    end
    else
    begin
      AMemo^.ScrollY := AMemo^.ScrollY + clientH;
      if AMemo^.ScrollY > AMemo^.LineCount * 14 - clientH then
        AMemo^.ScrollY := AMemo^.LineCount * 14 - clientH;
      if AMemo^.ScrollY < 0 then AMemo^.ScrollY := 0;
    end;
    Exit;
  end;

  { HScroll t�klama (local X,Y) }
  if needH and (X >= 2) and
     (X < AMemo^.Width - 2 - (Ord(needV) * 16)) and
     (Y >= AMemo^.Height - 18) and
     (Y < AMemo^.Height - 2) then
  begin
    if (X >= AMemo^.HThumbRect.Left) and
       (X < AMemo^.HThumbRect.Right) then
    begin
      AMemo^.HScrollDrag := True;
      AMemo^.HScrollDragStart := X;
      AMemo^.HScrollDragStartVal := AMemo^.ScrollX;
    end
    else if X < AMemo^.HThumbRect.Left then
    begin
      AMemo^.ScrollX := AMemo^.ScrollX - clientW;
      if AMemo^.ScrollX < 0 then AMemo^.ScrollX := 0;
    end
    else
    begin
      AMemo^.ScrollX := AMemo^.ScrollX + clientW;
      if AMemo^.ScrollX > maxLineLen * 8 - clientW then
        AMemo^.ScrollX := maxLineLen * 8 - clientW;
      if AMemo^.ScrollX < 0 then AMemo^.ScrollX := 0;
    end;
    Exit;
  end;

  { Metin alan� t�klama (local X,Y) }
  relX := X - 4 + AMemo^.ScrollX;   { Left/Top ��karma YOK }
  relY := Y - 4 + AMemo^.ScrollY;

  lineIdx := relY div 14;
  colIdx := relX div 8;

  if lineIdx < 0 then lineIdx := 0;
  if lineIdx >= AMemo^.LineCount then lineIdx := AMemo^.LineCount - 1;
  if lineIdx < 0 then lineIdx := 0;

  len := Memo_LineLen(AMemo, lineIdx);
  if colIdx > len then colIdx := len;
  if colIdx < 0 then colIdx := 0;

  AMemo^.CursorY := lineIdx;
  AMemo^.CursorX := colIdx;
  AMemo^.SelStartX := colIdx; AMemo^.SelStartY := lineIdx;
  AMemo^.SelEndX := colIdx; AMemo^.SelEndY := lineIdx;
  Memo_UpdateScroll(AMemo);
end;


procedure Memo_MouseMove(AMemo: PMemo; X, Y: Integer);
var
  relX, relY, lineIdx, colIdx, len: Integer;
  deltaMouse, trackSize, thumbSize, maxScrollVal: Integer;
  needV, needH: Boolean;
  clientH: Integer;
begin
  if AMemo = nil then Exit;

  needV := AMemo^.LineCount * 14 > (AMemo^.Height - 4);
  needH := False;
  // ... (needH hesaplamas� ayn�, k�sa tutal�m) ...
  
  clientH := AMemo^.Height - 4; if needH then Dec(clientH, 16);

  { VScroll s�r�kleme }
  if AMemo^.VScrollDrag then
  begin
    deltaMouse := Y - AMemo^.VScrollDragStart;
    trackSize := AMemo^.VScrollRect.Bottom - AMemo^.VScrollRect.Top - 32;
    thumbSize := AMemo^.VThumbRect.Bottom - AMemo^.VThumbRect.Top;
    if (trackSize > thumbSize) and (AMemo^.LineCount * 14 > clientH) then
    begin
      maxScrollVal := AMemo^.LineCount * 14 - clientH;
      AMemo^.ScrollY := AMemo^.VScrollDragStartVal + 
                        (deltaMouse * maxScrollVal) div (trackSize - thumbSize);
      if AMemo^.ScrollY < 0 then AMemo^.ScrollY := 0;
      if AMemo^.ScrollY > maxScrollVal then AMemo^.ScrollY := maxScrollVal;
    end;
    Exit;
  end;

  { HScroll s�r�kleme }
  if AMemo^.HScrollDrag then
  begin
    deltaMouse := X - AMemo^.HScrollDragStart;
    trackSize := AMemo^.HScrollRect.Right - AMemo^.HScrollRect.Left - 32;
    thumbSize := AMemo^.HThumbRect.Right - AMemo^.HThumbRect.Left;
    if (trackSize > thumbSize) then
    begin
      maxScrollVal := (Memo_MaxLineLen(AMemo) * 8) - (AMemo^.Width - 4 - Ord(needV)*16);
      if maxScrollVal < 0 then maxScrollVal := 0;
      if maxScrollVal > 0 then
      begin
        AMemo^.ScrollX := AMemo^.HScrollDragStartVal + 
                          (deltaMouse * maxScrollVal) div (trackSize - thumbSize);
        if AMemo^.ScrollX < 0 then AMemo^.ScrollX := 0;
        if AMemo^.ScrollX > maxScrollVal then AMemo^.ScrollX := maxScrollVal;
      end;
    end;
    Exit;
  end;

  { Metin se�imi (local X,Y) }
  relX := X - 4 + AMemo^.ScrollX;
  relY := Y - 4 + AMemo^.ScrollY;

  lineIdx := relY div 14;
  colIdx := relX div 8;

  if lineIdx < 0 then lineIdx := 0;
  if lineIdx >= AMemo^.LineCount then lineIdx := AMemo^.LineCount - 1;
  if lineIdx < 0 then lineIdx := 0;

  len := Memo_LineLen(AMemo, lineIdx);
  if colIdx > len then colIdx := len;
  if colIdx < 0 then colIdx := 0;

  AMemo^.SelEndX := colIdx;
  AMemo^.SelEndY := lineIdx;
end;

procedure Memo_MouseUp(AMemo: PMemo; X, Y: Integer);
begin
  if AMemo = nil then Exit;
  AMemo^.VScrollDrag := False;
  AMemo^.HScrollDrag := False;
end;


{==============================================================================}
{  TLISTVIEW - IMPLEMENTATION                                                  }
{==============================================================================}

procedure LV_DrawString(X, Y: Integer; S: PChar; Color: LongWord);
var i: Integer;
begin
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    KChar(X + i * 8, Y, S[i], Color);
    Inc(i);
  end;
end;

function LV_IconColor(Index: Integer): LongWord;
begin
  case Index mod 8 of
    0: Result := $00FF0000;
    1: Result := $0000FF00;
    2: Result := $000000FF;
    3: Result := $00FFFF00;
    4: Result := $0000FFFF;
    5: Result := $00FF00FF;
    6: Result := $00808080;
  else
    Result := $00804000;
  end;
end;

function LV_TextWidth(S: PChar): Integer;
begin
  Result := StrLenP(S) * 8;
end;

function ListItem_Create(const ACaption: PChar): PListItem;
var it: PListItem; i: Integer;
begin
  it := MemAlloc(SizeOf(TListItem));
  if it = nil then begin Result := nil; Exit; end;
  MemSet(it, 0, SizeOf(TListItem));
  it^.Caption := MemAlloc(StrLenP(ACaption) + 1);
  if it^.Caption <> nil then StrCopyP(it^.Caption, ACaption);
  it^.SubItemCount := 0;
  it^.ImageIndex := 0;
  it^.Tag := 0;
  for i := 0 to 7 do it^.SubItems[i] := nil;
  Result := it;
end;

procedure ListItem_Free(AItem: PListItem);
var i: Integer;
begin
  if AItem = nil then Exit;
  if AItem^.Caption <> nil then FreeMem(AItem^.Caption);
  for i := 0 to 7 do
    if AItem^.SubItems[i] <> nil then
    begin
      FreeMem(AItem^.SubItems[i]);
      AItem^.SubItems[i] := nil;
    end;
  FreeMem(AItem);
end;

function ListView_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PListView;
var lv: PListView;
begin
  lv := MemAlloc(SizeOf(TListView));
  if lv = nil then begin Result := nil; Exit; end;
  MemSet(lv, 0, SizeOf(TListView));

  lv^.ObjectType := otListView;
  lv^.Left := ALeft; lv^.Top := ATop;
  lv^.Width := AWidth; lv^.Height := AHeight;
  lv^.Color := $00FFFFFF;
  lv^.Visible := True;
  lv^.BorderColor := $00808080;
  lv^.TextColor := $00000000;
  lv^.SelColor := $000080FF;
  lv^.SelTextColor := $00FFFFFF;
  lv^.AltColor := $00F0F8FF;
  lv^.HeaderColor := $00E8E8E8;
  lv^.HeaderTextColor := $00000000;
  lv^.RowHeight := 16;
  lv^.ItemWidth := 80;      { Icon modu varsay�lan� }
  lv^.ItemHeight := 52;     { 32 ikon + 4 bo�luk + 2 sat�r caption alan� }
  lv^.HeaderHeight := 16;
  lv^.ItemIndex := -1;
  lv^.ItemCount := 0;
  lv^.ColumnCount := 0;
  lv^.ViewStyle := 1;       { Varsay�lan Report }
  lv^.ShowHeader := True;
  lv^.ScrollX := 0; lv^.ScrollY := 0;
  lv^.VScrollDrag := False; lv^.HScrollDrag := False;

  lv^.OnDestroy := @ListView_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(lv));
  Result := lv;
end;

procedure ListView_Free(AListView: PListView);
begin
  if AListView = nil then Exit;
  ListView_Clear(AListView);
end;

procedure ListView_Clear(AListView: PListView;Column:Boolean=False);
var i: Integer;
begin
  if AListView = nil then Exit;
  for i := 0 to AListView^.ItemCount - 1 do
    if AListView^.Items[i] <> nil then
    begin
      ListItem_Free(AListView^.Items[i]);
      AListView^.Items[i] := nil;
    end;
  AListView^.ItemCount := 0;
  AListView^.ItemIndex := -1;

  if Column then
  begin
  for i := 0 to AListView^.ColumnCount - 1 do
    if AListView^.Columns[i].Caption <> nil then
    begin
      FreeMem(AListView^.Columns[i].Caption);
      AListView^.Columns[i].Caption := nil;
    end;
  AListView^.ColumnCount := 0;
  end;
end;

function ListView_AddItem(AListView: PListView; const ACaption: PChar): Integer;
var it: PListItem;
begin
  Result := -1;
  if AListView = nil then Exit;
  if AListView^.ItemCount >= 1024 then Exit;
  it := ListItem_Create(ACaption);
  if it = nil then Exit;
  AListView^.Items[AListView^.ItemCount] := it;
  Result := AListView^.ItemCount;
  Inc(AListView^.ItemCount);
  if AListView^.ItemIndex < 0 then AListView^.ItemIndex := 0;
end;

procedure ListView_AddSubItem(AListView: PListView; AItemIndex: Integer; const AText: PChar);
var it: PListItem; p: PChar; len: Integer;
begin
  if AListView = nil then Exit;
  if (AItemIndex < 0) or (AItemIndex >= AListView^.ItemCount) then Exit;
  it := AListView^.Items[AItemIndex];
  if it^.SubItemCount >= 8 then Exit;
  len := StrLenP(AText);
  p := MemAlloc(len + 1);
  if p = nil then Exit;
  StrCopyP(p, AText);
  it^.SubItems[it^.SubItemCount] := p;
  Inc(it^.SubItemCount);
end;

procedure ListView_AddColumn(AListView: PListView; const ACaption: PChar; AWidth: Integer);
var p: PChar; len: Integer;
begin
  if AListView = nil then Exit;
  if AListView^.ColumnCount >= 8 then Exit;
  len := StrLenP(ACaption);
  p := MemAlloc(len + 1);
  if p <> nil then StrCopyP(p, ACaption);
  AListView^.Columns[AListView^.ColumnCount].Caption := p;
  AListView^.Columns[AListView^.ColumnCount].Width := AWidth;
  Inc(AListView^.ColumnCount);
end;

{ Icon modunda ka� s�tun s��ar }
function LV_IconColCount(AListView: PListView; ClientW: Integer): Integer;
begin
  if AListView^.ItemWidth <= 0 then AListView^.ItemWidth := 80;
  Result := ClientW div AListView^.ItemWidth;
  if Result < 1 then Result := 1;
end;

{ Icon modunda toplam sat�r say�s� }
function LV_IconRowCount(AListView: PListView; ClientW: Integer): Integer;
var cols: Integer;
begin
  if AListView^.ItemCount = 0 then begin Result := 0; Exit; end;
  cols := LV_IconColCount(AListView, ClientW);
  Result := (AListView^.ItemCount + cols - 1) div cols;
end;

function LV_ContentHeight(AListView: PListView; ClientW: Integer): Integer;
var h: Integer;
begin
  if AListView^.ViewStyle = 2 then
  begin
    { Icon modu }
    h := LV_IconRowCount(AListView, ClientW) * AListView^.ItemHeight;
  end
  else
  begin
    h := AListView^.ItemCount * AListView^.RowHeight;
    if (AListView^.ViewStyle = 1) and AListView^.ShowHeader then
      h := h + AListView^.HeaderHeight;
  end;
  Result := h;
end;

function LV_ContentWidth(AListView: PListView): Integer;
var i, tw: Integer;
begin
  Result := 0;
  if AListView = nil then Exit;

  if AListView^.ViewStyle = 2 then
  begin
    { Icon modunda yatay scroll yok, i�erik geni�li�i = client geni�li�i }
    Result := AListView^.Width - 4;
  end
  else if AListView^.ViewStyle = 1 then
  begin
    for i := 0 to AListView^.ColumnCount - 1 do
      Result := Result + AListView^.Columns[i].Width;
    if Result = 0 then Result := 100;
  end
  else
  begin
    { List modu }
    for i := 0 to AListView^.ItemCount - 1 do
      if AListView^.Items[i] <> nil then
      begin
        tw := LV_TextWidth(AListView^.Items[i].Caption) + 28;
        if tw > Result then Result := tw;
      end;
    if Result = 0 then Result := 100;
  end;
end;

procedure ListView_UpdateScroll(AListView: PListView);
var ch, cw, contentH, contentW: Integer;
    needV, needH: Boolean;
    maxScroll: Integer;
begin
  if AListView = nil then Exit;

  cw := AListView^.Width - 4;
  ch := AListView^.Height - 4;

  { Icon modunda sadece dikey scroll }
  if AListView^.ViewStyle = 2 then
  begin
    contentH := LV_ContentHeight(AListView, cw);
    needV := contentH > ch;
    needH := False;
    AListView^.ScrollX := 0;
  end
  else
  begin
    contentH := LV_ContentHeight(AListView, cw);
    contentW := LV_ContentWidth(AListView);
    needV := contentH > ch;
    needH := contentW > cw;
    if needV then Dec(cw, 16);
    if needH then Dec(ch, 16);
  end;

  if AListView^.ItemIndex < 0 then AListView^.ItemIndex := 0;
  if AListView^.ItemIndex >= AListView^.ItemCount then
    AListView^.ItemIndex := AListView^.ItemCount - 1;

  if AListView^.ItemCount > 0 then
  begin
    contentH := LV_ContentHeight(AListView, cw);
    if AListView^.ScrollY > contentH - ch then AListView^.ScrollY := contentH - ch;
    if AListView^.ScrollY < 0 then AListView^.ScrollY := 0;
  end
  else
    AListView^.ScrollY := 0;

  if AListView^.ViewStyle <> 2 then
  begin
    if AListView^.ScrollX < 0 then AListView^.ScrollX := 0;
    contentW := LV_ContentWidth(AListView);
    if contentW > cw then
    begin
      if AListView^.ScrollX > contentW - cw then AListView^.ScrollX := contentW - cw;
    end
    else
      AListView^.ScrollX := 0;
  end;
end;

{ Yard�mc�: Basit ok �izimi }
procedure LV_DrawArrow(X, Y: Integer; Dir: Byte; Color: LongWord);
begin
  case Dir of
    0: KChar(X + 4, Y + 4, '^', Color);
    1: KChar(X + 4, Y + 4, 'v', Color);
    2: KChar(X + 4, Y + 4, '<', Color);
    3: KChar(X + 4, Y + 4, '>', Color);
  end;
end;

procedure ListView_Draw(AListView: PListView; ParentX, ParentY: Integer);
var
  absX, absY, clientW, clientH: Integer;
  needV, needH, inSel: Boolean;
  contentH, contentW: Integer;
  thumbSize, trackSize: Integer;
  i, j, x, y, rowY, colX, textY: Integer;
  it: PListItem;
  selBack, txtCol: LongWord;
  headerOff: Integer;
  btnX, btnY: Integer;
  iconX, iconY, captionX, captionY: Integer;
  cols, row, col: Integer;
begin
  if AListView = nil then Exit;
  if not AListView^.Visible then Exit;

  absX := ParentX + AListView^.Left;
  absY := ParentY + AListView^.Top;

  clientW := AListView^.Width - 4;
  clientH := AListView^.Height - 4;

  if AListView^.ViewStyle = 2 then
  begin
    { Icon modunda sadece dikey scroll }
    contentH := LV_ContentHeight(AListView, clientW);
    contentW := clientW;
    needV := contentH > clientH;
    needH := False;
  end
  else
  begin
    contentH := LV_ContentHeight(AListView, clientW);
    contentW := LV_ContentWidth(AListView);
    needV := contentH > clientH;
    needH := contentW > clientW;
    if needV and not needH then if contentW > (clientW - 16) then needH := True;
    if needH and not needV then if contentH > (clientH - 16) then needV := True;
    if needV then Dec(clientW, 16);
    if needH then Dec(clientH, 16);
  end;

  { 3D kenarl�k + zemin }
  KRect3D(absX, absY, AListView^.Width, AListView^.Height, False);
  KFill(absX + 2, absY + 2, AListView^.Width - 4, AListView^.Height - 4, AListView^.Color);

  headerOff := 0;
  if (AListView^.ViewStyle = 1) and AListView^.ShowHeader then
    headerOff := AListView^.HeaderHeight;

  Clip_Save;
  Clip_Set(absX + 2, absY + 2, absX + 2 + clientW - 1, absY + 2 + clientH - 1);

  {------------------------------------------------------------------}
  {  HEADER (Report modu)                                            }
  {------------------------------------------------------------------}
  if (AListView^.ViewStyle = 1) and AListView^.ShowHeader then
  begin
    KFill(absX + 2, absY + 2, clientW, AListView^.HeaderHeight, AListView^.HeaderColor);
    KLineH(absX + 2, absY + 2 + AListView^.HeaderHeight - 1, clientW, $00808080);
    colX := absX + 4 - AListView^.ScrollX;
    for i := 0 to AListView^.ColumnCount - 1 do
    begin
      if colX + AListView^.Columns[i].Width > absX + 2 then
      begin
        LV_DrawString(colX + 2, absY + 4, AListView^.Columns[i].Caption, AListView^.HeaderTextColor);
        KLineV(colX + AListView^.Columns[i].Width, absY + 2, AListView^.HeaderHeight, $00808080);
      end;
      colX := colX + AListView^.Columns[i].Width;
    end;
  end;

  {------------------------------------------------------------------}
  {  ICON MODU (ViewStyle = 2)                                       }
  {------------------------------------------------------------------}
  if AListView^.ViewStyle = 2 then
  begin
    cols := LV_IconColCount(AListView, clientW);
    for i := 0 to AListView^.ItemCount - 1 do
    begin
      it := AListView^.Items[i];
      col := i mod cols;
      row := i div cols;

      x := absX + 4 + (col * AListView^.ItemWidth);
      y := absY + 4 + (row * AListView^.ItemHeight) - AListView^.ScrollY;

      { Ekran d���ndaysa atla }
      if y + AListView^.ItemHeight < absY + 2 then Continue;
      if y > absY + 2 + clientH then Break;

      inSel := (i = AListView^.ItemIndex);

      { Se�ili arka plan }
      if inSel then
      begin
        KFill(x, y, AListView^.ItemWidth, AListView^.ItemHeight, AListView^.SelColor);
        txtCol := AListView^.SelTextColor;
      end
      else
      begin
        { Alternatif sat�r rengi (sat�r baz�nda de�il, item baz�nda) }
        if (i mod 2) = 1 then
          KFill(x, y, AListView^.ItemWidth, AListView^.ItemHeight, AListView^.AltColor)
        else
          KFill(x, y, AListView^.ItemWidth, AListView^.ItemHeight, AListView^.Color);
        txtCol := AListView^.TextColor;
      end;

      { 32x32 �kon (ortalanm��) }
      iconX := x + (AListView^.ItemWidth - 32) div 2;
      iconY := y + 4;
      KFill(iconX, iconY, 32, 32, LV_IconColor(it^.ImageIndex));
      KRect(iconX, iconY, 32, 32, $00606060);

      { Caption (ikonun alt�nda, ortalanm��) }
      captionY := iconY + 32 + 2;
      captionX := x + (AListView^.ItemWidth - LV_TextWidth(it^.Caption)) div 2;
      if captionX < x then captionX := x;
      LV_DrawString(captionX, captionY, it^.Caption, txtCol);

      { Se�ili ise ince �er�eve }
      if inSel then
        KRect(x, y, AListView^.ItemWidth, AListView^.ItemHeight, $00A0A0A0);
    end;
  end
  else
  begin
    {----------------------------------------------------------------}
    {  LIST / REPORT MODU SATIR ��Z�M�                               }
    {----------------------------------------------------------------}
    i := 0;
    while i < AListView^.ItemCount do
    begin
      it := AListView^.Items[i];
      rowY := absY + 4 + headerOff + (i * AListView^.RowHeight) - AListView^.ScrollY;

      if rowY + AListView^.RowHeight < absY + 2 then
      begin
        Inc(i);
        Continue;
      end;
      if rowY > absY + 2 + clientH then Break;

      inSel := (i = AListView^.ItemIndex);

      if inSel then
        selBack := AListView^.SelColor
      else if (i mod 2) = 1 then
        selBack := AListView^.AltColor
      else
        selBack := AListView^.Color;

      KFill(absX + 2, rowY, clientW, AListView^.RowHeight, selBack);

      if inSel then txtCol := AListView^.SelTextColor else txtCol := AListView^.TextColor;
      textY := rowY + (AListView^.RowHeight - 10) div 2;

      { �kon }
      if (it <> nil) and (AListView^.ViewStyle = 0) then
      begin
        KFill(absX + 6 - AListView^.ScrollX, textY - 1, 12, 12, LV_IconColor(it^.ImageIndex));
        KRect(absX + 6 - AListView^.ScrollX, textY - 1, 12, 12, $00606060);
        x := absX + 22 - AListView^.ScrollX;
      end
      else if (AListView^.ViewStyle = 1) then
      begin
        KFill(absX + 6, textY + 2, 6, 6, LV_IconColor(it^.ImageIndex));
        x := absX + 16;
      end
      else
        x := absX + 6;

      if it <> nil then
      begin
        if AListView^.ViewStyle = 0 then
        begin
          LV_DrawString(x, textY, it^.Caption, txtCol);
        end
        else
        begin
          colX := x;
          LV_DrawString(colX, textY, it^.Caption, txtCol);
          colX := colX + AListView^.Columns[0].Width;

          for j := 0 to it^.SubItemCount - 1 do
          begin
            if j + 1 >= AListView^.ColumnCount then Break;
            if colX > absX + 2 + clientW then Break;
            LV_DrawString(colX + 4, textY, it^.SubItems[j], txtCol);
            colX := colX + AListView^.Columns[j + 1].Width;
          end;
        end;
      end;

      Inc(i);
    end;

    { Se�ili sat�r ince �er�eve }
    if (AListView^.ItemIndex >= 0) and (AListView^.ItemIndex < AListView^.ItemCount) then
    begin
      rowY := absY + 4 + headerOff + (AListView^.ItemIndex * AListView^.RowHeight) - AListView^.ScrollY;
      if (rowY >= absY + 2) and (rowY + AListView^.RowHeight <= absY + 2 + clientH) then
        KRect(absX + 2, rowY, clientW, AListView^.RowHeight, $00A0A0A0);
    end;
  end;

  Clip_Restore;

  {------------------------------------------------------------------}
  {  D�KEY SCROLLBAR + OK BUTONLARI                                  }
  {------------------------------------------------------------------}
  if needV then
  begin
    AListView^.VScrollRect.Left := AListView^.Width - 18;
    AListView^.VScrollRect.Top := 2;
    AListView^.VScrollRect.Right := AListView^.VScrollRect.Left + 16;
    AListView^.VScrollRect.Bottom := AListView^.Height - 2;
    if needH then Dec(AListView^.VScrollRect.Bottom, 16);

    { Track zemin }
    KFill(absX + AListView^.VScrollRect.Left, absY + AListView^.VScrollRect.Top,
          16, AListView^.VScrollRect.Bottom - AListView^.VScrollRect.Top, $00E0E0E0);
    KRect(absX + AListView^.VScrollRect.Left, absY + AListView^.VScrollRect.Top,
          16, AListView^.VScrollRect.Bottom - AListView^.VScrollRect.Top, $00808080);

    { Yukar� buton }
    btnX := absX + AListView^.VScrollRect.Left;
    btnY := absY + AListView^.VScrollRect.Top;
    KButton3D(btnX, btnY, 16, 16, False, $00DCDCDC);
    LV_DrawArrow(btnX, btnY, 0, $00000000);

    { A�a�� buton }
    btnY := absY + AListView^.VScrollRect.Bottom - 16;
    KButton3D(btnX, btnY, 16, 16, False, $00DCDCDC);
    LV_DrawArrow(btnX, btnY, 1, $00000000);

    { Thumb }
    trackSize := AListView^.VScrollRect.Bottom - AListView^.VScrollRect.Top - 32;
    if (trackSize > 0) and (contentH > clientH) then
    begin
      thumbSize := (clientH * trackSize) div contentH;
      if thumbSize < 8 then thumbSize := 8;
      AListView^.VThumbRect.Left := AListView^.VScrollRect.Left + 2;
      AListView^.VThumbRect.Top := AListView^.VScrollRect.Top + 16 +
        (AListView^.ScrollY * (trackSize - thumbSize) div (contentH - clientH));
      AListView^.VThumbRect.Right := AListView^.VScrollRect.Right - 2;
      AListView^.VThumbRect.Bottom := AListView^.VThumbRect.Top + thumbSize;
      KButton3D(absX + AListView^.VThumbRect.Left, absY + AListView^.VThumbRect.Top,
                AListView^.VThumbRect.Right - AListView^.VThumbRect.Left,
                AListView^.VThumbRect.Bottom - AListView^.VThumbRect.Top, False, $00D0D0D0);
    end;
  end;

  {------------------------------------------------------------------}
  {  YATAY SCROLLBAR + OK BUTONLARI (Icon modunda �izilmez)          }
  {------------------------------------------------------------------}
  if needH and (AListView^.ViewStyle <> 2) then
  begin
    AListView^.HScrollRect.Left := 2;
    AListView^.HScrollRect.Top := AListView^.Height - 18;
    AListView^.HScrollRect.Right := AListView^.Width - 2;
    if needV then Dec(AListView^.HScrollRect.Right, 16);
    AListView^.HScrollRect.Bottom := AListView^.HScrollRect.Top + 16;

    KFill(absX + AListView^.HScrollRect.Left, absY + AListView^.HScrollRect.Top,
          AListView^.HScrollRect.Right - AListView^.HScrollRect.Left, 16, $00E0E0E0);
    KRect(absX + AListView^.HScrollRect.Left, absY + AListView^.HScrollRect.Top,
          AListView^.HScrollRect.Right - AListView^.HScrollRect.Left, 16, $00808080);

    { Sol buton }
    btnX := absX + AListView^.HScrollRect.Left;
    btnY := absY + AListView^.HScrollRect.Top;
    KButton3D(btnX, btnY, 16, 16, False, $00DCDCDC);
    LV_DrawArrow(btnX, btnY, 2, $00000000);

    { Sa� buton }
    btnX := absX + AListView^.HScrollRect.Right - 16;
    KButton3D(btnX, btnY, 16, 16, False, $00DCDCDC);
    LV_DrawArrow(btnX, btnY, 3, $00000000);

    { Thumb }
    trackSize := AListView^.HScrollRect.Right - AListView^.HScrollRect.Left - 32;
    if (trackSize > 0) and (contentW > clientW) then
    begin
      thumbSize := (clientW * trackSize) div contentW;
      if thumbSize < 8 then thumbSize := 8;
      AListView^.HThumbRect.Left := AListView^.HScrollRect.Left + 16 +
        (AListView^.ScrollX * (trackSize - thumbSize) div (contentW - clientW));
      AListView^.HThumbRect.Top := AListView^.HScrollRect.Top + 2;
      AListView^.HThumbRect.Right := AListView^.HThumbRect.Left + thumbSize;
      AListView^.HThumbRect.Bottom := AListView^.HScrollRect.Bottom - 2;
      KButton3D(absX + AListView^.HThumbRect.Left, absY + AListView^.HThumbRect.Top,
                AListView^.HThumbRect.Right - AListView^.HThumbRect.Left,
                AListView^.HThumbRect.Bottom - AListView^.HThumbRect.Top, False, $00D0D0D0);
    end;
  end;

  { K��e kesi�imi }
  if needV and needH and (AListView^.ViewStyle <> 2) then
    KFill(absX + AListView^.Width - 18, absY + AListView^.Height - 18, 16, 16, $00C0C0C0);
end;

procedure ListView_ProcessKey(AListView: PListView; Key: Word; Shift: Byte);
var pageSize, cols: Integer;
begin
  if AListView = nil then Exit;
  if AListView^.ItemCount = 0 then Exit;

  pageSize := (AListView^.Height - 4) div AListView^.RowHeight;
  if pageSize < 1 then pageSize := 1;

  case Key of
    38: { Up }
      if AListView^.ItemIndex > 0 then Dec(AListView^.ItemIndex);
    40: { Down }
      if AListView^.ItemIndex < AListView^.ItemCount - 1 then Inc(AListView^.ItemIndex);
    37: { Left (Icon modunda s�tun sola) }
      if (AListView^.ViewStyle = 2) and (AListView^.ItemIndex > 0) then
        Dec(AListView^.ItemIndex);
    39: { Right (Icon modunda s�tun sa�a) }
      if (AListView^.ViewStyle = 2) and (AListView^.ItemIndex < AListView^.ItemCount - 1) then
        Inc(AListView^.ItemIndex);
    33: { PageUp }
      begin
        if AListView^.ViewStyle = 2 then
        begin
          cols := LV_IconColCount(AListView, AListView^.Width - 4);
          pageSize := ((AListView^.Height - 4) div AListView^.ItemHeight) * cols;
          if pageSize < 1 then pageSize := cols;
        end;
        AListView^.ItemIndex := AListView^.ItemIndex - pageSize;
      end;
    34: { PageDown }
      begin
        if AListView^.ViewStyle = 2 then
        begin
          cols := LV_IconColCount(AListView, AListView^.Width - 4);
          pageSize := ((AListView^.Height - 4) div AListView^.ItemHeight) * cols;
          if pageSize < 1 then pageSize := cols;
        end;
        AListView^.ItemIndex := AListView^.ItemIndex + pageSize;
      end;
    36: { Home }
      AListView^.ItemIndex := 0;
    35: { End }
      AListView^.ItemIndex := AListView^.ItemCount - 1;
  end;

  if AListView^.ItemIndex < 0 then AListView^.ItemIndex := 0;
  if AListView^.ItemIndex >= AListView^.ItemCount then
    AListView^.ItemIndex := AListView^.ItemCount - 1;

  ListView_UpdateScroll(AListView);
end;

procedure ListView_MouseDown(AListView: PListView; X, Y: Integer);
var
  needV, needH: Boolean;
  clientW, clientH, contentH, contentW: Integer;
  headerOff, relY, idx: Integer;
  maxScroll: Integer;
  cols, row, col: Integer;
begin
  if AListView = nil then Exit;

  clientW := AListView^.Width - 4;
  clientH := AListView^.Height - 4;

  if AListView^.ViewStyle = 2 then
  begin
    contentH := LV_ContentHeight(AListView, clientW);
    contentW := clientW;
    needV := contentH > clientH;
    needH := False;
  end
  else
  begin
    contentH := LV_ContentHeight(AListView, clientW);
    contentW := LV_ContentWidth(AListView);
    needV := contentH > clientH;
    needH := contentW > clientW;
    if needV and not needH then if contentW > (clientW - 16) then needH := True;
    if needH and not needV then if contentH > (clientH - 16) then needV := True;
    if needV then Dec(clientW, 16);
    if needH then Dec(clientH, 16);
  end;

  {------------------------------------------------------------------}
  {  D�KEY SCROLLBAR HIT-TEST                                        }
  {------------------------------------------------------------------}
  if needV and (X >= AListView^.Width - 18) and (X < AListView^.Width - 2) and
     (Y >= 2) and (Y < AListView^.Height - 2 - (Ord(needH and (AListView^.ViewStyle <> 2)) * 16)) then
  begin
    { Yukar� ok butonu }
    if (Y >= AListView^.VScrollRect.Top) and (Y < AListView^.VScrollRect.Top + 16) then
    begin
      if AListView^.ViewStyle = 2 then
        AListView^.ScrollY := AListView^.ScrollY - AListView^.ItemHeight
      else
        AListView^.ScrollY := AListView^.ScrollY - AListView^.RowHeight;
      if AListView^.ScrollY < 0 then AListView^.ScrollY := 0;
      Exit;
    end;
    { A�a�� ok butonu }
    if (Y >= AListView^.VScrollRect.Bottom - 16) and (Y < AListView^.VScrollRect.Bottom) then
    begin
      if AListView^.ViewStyle = 2 then
        AListView^.ScrollY := AListView^.ScrollY + AListView^.ItemHeight
      else
        AListView^.ScrollY := AListView^.ScrollY + AListView^.RowHeight;
      maxScroll := contentH - clientH;
      if maxScroll < 0 then maxScroll := 0;
      if AListView^.ScrollY > maxScroll then AListView^.ScrollY := maxScroll;
      Exit;
    end;
    { Thumb s�r�kleme }
    if (Y >= AListView^.VThumbRect.Top) and (Y < AListView^.VThumbRect.Bottom) then
    begin
      AListView^.VScrollDrag := True;
      AListView^.VScrollDragStart := Y;
      AListView^.VScrollDragStartVal := AListView^.ScrollY;
      Exit;
    end;
    { Track - Page Up }
    if Y < AListView^.VThumbRect.Top then
    begin
      AListView^.ScrollY := AListView^.ScrollY - clientH;
      if AListView^.ScrollY < 0 then AListView^.ScrollY := 0;
    end
    { Track - Page Down }
    else
    begin
      AListView^.ScrollY := AListView^.ScrollY + clientH;
      maxScroll := contentH - clientH;
      if maxScroll < 0 then maxScroll := 0;
      if AListView^.ScrollY > maxScroll then AListView^.ScrollY := maxScroll;
    end;
    Exit;
  end;

  {------------------------------------------------------------------}
  {  YATAY SCROLLBAR HIT-TEST (Icon modunda atlan�r)                 }
  {------------------------------------------------------------------}
  if (AListView^.ViewStyle <> 2) and needH and
     (X >= 2) and (X < AListView^.Width - 2 - (Ord(needV) * 16)) and
     (Y >= AListView^.Height - 18) and (Y < AListView^.Height - 2) then
  begin
    { Sol ok butonu }
    if (X >= AListView^.HScrollRect.Left) and (X < AListView^.HScrollRect.Left + 16) then
    begin
      AListView^.ScrollX := AListView^.ScrollX - 16;
      if AListView^.ScrollX < 0 then AListView^.ScrollX := 0;
      Exit;
    end;
    { Sa� ok butonu }
    if (X >= AListView^.HScrollRect.Right - 16) and (X < AListView^.HScrollRect.Right) then
    begin
      AListView^.ScrollX := AListView^.ScrollX + 16;
      maxScroll := contentW - clientW;
      if maxScroll < 0 then maxScroll := 0;
      if AListView^.ScrollX > maxScroll then AListView^.ScrollX := maxScroll;
      Exit;
    end;
    { Thumb s�r�kleme }
    if (X >= AListView^.HThumbRect.Left) and (X < AListView^.HThumbRect.Right) then
    begin
      AListView^.HScrollDrag := True;
      AListView^.HScrollDragStart := X;
      AListView^.HScrollDragStartVal := AListView^.ScrollX;
      Exit;
    end;
    { Track - Page Left }
    if X < AListView^.HThumbRect.Left then
    begin
      AListView^.ScrollX := AListView^.ScrollX - clientW;
      if AListView^.ScrollX < 0 then AListView^.ScrollX := 0;
    end
    { Track - Page Right }
    else
    begin
      AListView^.ScrollX := AListView^.ScrollX + clientW;
      maxScroll := contentW - clientW;
      if maxScroll < 0 then maxScroll := 0;
      if AListView^.ScrollX > maxScroll then AListView^.ScrollX := maxScroll;
    end;
    Exit;
  end;

  {------------------------------------------------------------------}
  {  ITEM SE��M�                                                     }
  {------------------------------------------------------------------}
  if AListView^.ViewStyle = 2 then
  begin
    { Icon modu: grid hit-test }
    cols := LV_IconColCount(AListView, clientW);
    relY := Y - 4 + AListView^.ScrollY;
    row := relY div AListView^.ItemHeight;
    col := (X - 4) div AListView^.ItemWidth;

    if (col >= 0) and (col < cols) and (row >= 0) then
    begin
      idx := row * cols + col;
      if (idx >= 0) and (idx < AListView^.ItemCount) then
      begin
        AListView^.ItemIndex := idx;
        ListView_UpdateScroll(AListView);
      end;
    end;
  end
  else
  begin
    headerOff := 0;
    if (AListView^.ViewStyle = 1) and AListView^.ShowHeader then
      headerOff := AListView^.HeaderHeight;

    if (X >= 2) and (X < 2 + clientW) and
       (Y >= 2 + headerOff) and (Y < 2 + headerOff + clientH) then
    begin
      relY := Y - 4 - headerOff + AListView^.ScrollY;
      idx := relY div AListView^.RowHeight;
      if (idx >= 0) and (idx < AListView^.ItemCount) then
      begin
        AListView^.ItemIndex := idx;
        ListView_UpdateScroll(AListView);
      end;
    end;
  end;
end;

procedure ListView_MouseMove(AListView: PListView; X, Y: Integer);
var
  deltaMouse, trackSize, thumbSize, maxScrollVal: Integer;
  needV, needH: Boolean;
  clientH, clientW: Integer;
begin
  if AListView = nil then Exit;

  clientH := AListView^.Height - 4;
  clientW := AListView^.Width - 4;

  if AListView^.ViewStyle <> 2 then
  begin
    needV := LV_ContentHeight(AListView, clientW) > clientH;
    needH := LV_ContentWidth(AListView) > clientW;
    if needV then Dec(clientH, 16);
    if needH then Dec(clientW, 16);
  end
  else
  begin
    needV := LV_ContentHeight(AListView, clientW) > clientH;
    needH := False;
  end;

  { VScroll s�r�kleme }
  if AListView^.VScrollDrag then
  begin
    deltaMouse := Y - AListView^.VScrollDragStart;
    trackSize := AListView^.VScrollRect.Bottom - AListView^.VScrollRect.Top - 32;
    thumbSize := AListView^.VThumbRect.Bottom - AListView^.VThumbRect.Top;
    if (trackSize > thumbSize) and (LV_ContentHeight(AListView, clientW) > clientH) then
    begin
      maxScrollVal := LV_ContentHeight(AListView, clientW) - clientH;
      AListView^.ScrollY := AListView^.VScrollDragStartVal +
        (deltaMouse * maxScrollVal) div (trackSize - thumbSize);
      if AListView^.ScrollY < 0 then AListView^.ScrollY := 0;
      if AListView^.ScrollY > maxScrollVal then AListView^.ScrollY := maxScrollVal;
    end;
    Exit;
  end;

  { HScroll s�r�kleme (Icon modunda yok) }
  if (AListView^.ViewStyle <> 2) and AListView^.HScrollDrag then
  begin
    deltaMouse := X - AListView^.HScrollDragStart;
    trackSize := AListView^.HScrollRect.Right - AListView^.HScrollRect.Left - 32;
    thumbSize := AListView^.HThumbRect.Right - AListView^.HThumbRect.Left;
    if (trackSize > thumbSize) and (LV_ContentWidth(AListView) > clientW) then
    begin
      maxScrollVal := LV_ContentWidth(AListView) - clientW;
      AListView^.ScrollX := AListView^.HScrollDragStartVal +
        (deltaMouse * maxScrollVal) div (trackSize - thumbSize);
      if AListView^.ScrollX < 0 then AListView^.ScrollX := 0;
      if AListView^.ScrollX > maxScrollVal then AListView^.ScrollX := maxScrollVal;
    end;
    Exit;
  end;
end;

procedure ListView_MouseUp(AListView: PListView; X, Y: Integer);
begin
  if AListView = nil then Exit;
  AListView^.VScrollDrag := False;
  AListView^.HScrollDrag := False;
end;


{==============================================================================}
{  TLISTBOX - IMPLEMENTATION                                                   }
{==============================================================================}

function LB_TextWidth(S: PChar): Integer;
begin
  Result := StrLenP(S) * 8;
end;

procedure LB_DrawString(X, Y: Integer; S: PChar; Color: LongWord);
var i: Integer;
begin
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    KChar(X + i * 8, Y, S[i], Color);
    Inc(i);
  end;
end;

function ListBox_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PListBox;
var lb: PListBox;
begin
  lb := MemAlloc(SizeOf(TListBox));
  if lb = nil then begin Result := nil; Exit; end;
  MemSet(lb, 0, SizeOf(TListBox));

  lb^.ObjectType := otListBox;
  lb^.Left := ALeft; lb^.Top := ATop;
  lb^.Width := AWidth; lb^.Height := AHeight;
  lb^.Color := $00FFFFFF;
  lb^.Visible := True;
  lb^.BorderColor := $00808080;
  lb^.TextColor := $00000000;
  lb^.SelColor := $000080FF;
  lb^.SelTextColor := $00FFFFFF;
  lb^.AltColor := $00F0F8FF;      { A��k mavi-gri }
  lb^.HoverColor := $00E0F0FF;    { Daha a��k mavi (hover) }
  lb^.RowHeight := 16;
  lb^.ItemIndex := -1;
  lb^.HoverIndex := -1;
  lb^.ItemCount := 0;
  lb^.ScrollY := 0;
  lb^.VScrollDrag := False;

  lb^.OnDestroy := @ListBox_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(lb));
  Result := lb;
end;

procedure ListBox_Free(AListBox: PListBox);
begin
  if AListBox = nil then Exit;
  ListBox_Clear(AListBox);
end;

procedure ListBox_Clear(AListBox: PListBox);
var i: Integer;
begin
  if AListBox = nil then Exit;
  for i := 0 to AListBox^.ItemCount - 1 do
    if AListBox^.Items[i] <> nil then
    begin
      FreeMem(AListBox^.Items[i]);
      AListBox^.Items[i] := nil;
    end;
  AListBox^.ItemCount := 0;
  AListBox^.ItemIndex := -1;
  AListBox^.HoverIndex := -1;
end;

function ListBox_AddItem(AListBox: PListBox; const S: PChar): Integer;
var p: PChar; len: Integer;
begin
  Result := -1;
  if AListBox = nil then Exit;
  if AListBox^.ItemCount >= 1024 then Exit;
  len := StrLenP(S);
  p := MemAlloc(len + 1);
  if p = nil then Exit;
  StrCopyP(p, S);
  AListBox^.Items[AListBox^.ItemCount] := p;
  Result := AListBox^.ItemCount;
  Inc(AListBox^.ItemCount);
  if AListBox^.ItemIndex < 0 then AListBox^.ItemIndex := 0;
end;

procedure ListBox_DeleteItem(AListBox: PListBox; Index: Integer);
var i: Integer;
begin
  if AListBox = nil then Exit;
  if (Index < 0) or (Index >= AListBox^.ItemCount) then Exit;
  if AListBox^.Items[Index] <> nil then FreeMem(AListBox^.Items[Index]);
  for i := Index to AListBox^.ItemCount - 2 do
    AListBox^.Items[i] := AListBox^.Items[i + 1];
  AListBox^.Items[AListBox^.ItemCount - 1] := nil;
  Dec(AListBox^.ItemCount);
  if AListBox^.ItemIndex >= AListBox^.ItemCount then
    AListBox^.ItemIndex := AListBox^.ItemCount - 1;
  if AListBox^.ItemIndex < 0 then AListBox^.ItemIndex := -1;
  ListBox_UpdateScroll(AListBox);
end;


procedure ListBox_UpdateScroll(AListBox: PListBox);
begin
  ListBox_EnsureVisible(AListBox);
end;


function LB_ContentHeight(AListBox: PListBox): Integer;
begin
  if AListBox = nil then begin Result := 0; Exit; end;
  Result := AListBox^.ItemCount * AListBox^.RowHeight;
end;

procedure ListBox_EnsureVisible(AListBox: PListBox);
var
  itemTop, itemBottom, clientH: Integer;
  needV: Boolean;
begin
  if AListBox = nil then Exit;
  if AListBox^.ItemIndex < 0 then Exit;

  clientH := AListBox^.Height - 4;
  needV := LB_ContentHeight(AListBox) > clientH;
  if needV then Dec(clientH, 16);

  itemTop := AListBox^.ItemIndex * AListBox^.RowHeight;
  itemBottom := itemTop + AListBox^.RowHeight;

  if itemTop < AListBox^.ScrollY then
    AListBox^.ScrollY := itemTop
  else if itemBottom > AListBox^.ScrollY + clientH then
    AListBox^.ScrollY := itemBottom - clientH;

  if AListBox^.ScrollY < 0 then AListBox^.ScrollY := 0;
  if LB_ContentHeight(AListBox) > clientH then
  begin
    if AListBox^.ScrollY > LB_ContentHeight(AListBox) - clientH then
      AListBox^.ScrollY := LB_ContentHeight(AListBox) - clientH;
  end
  else
    AListBox^.ScrollY := 0;
end;



procedure LB_DrawArrow(X, Y: Integer; Dir: Byte; Color: LongWord);
begin
  case Dir of
    0: KChar(X + 4, Y + 4, '^', Color);
    1: KChar(X + 4, Y + 4, 'v', Color);
  end;
end;

procedure ListBox_Draw(AListBox: PListBox; ParentX, ParentY: Integer);
var
  absX, absY, clientW, clientH: Integer;
  needV: Boolean;
  contentH: Integer;
  thumbSize, trackSize: Integer;
  i, x, y, textY: Integer;
  rowBack, txtCol: LongWord;
  btnX, btnY: Integer;
begin
  if AListBox = nil then Exit;
  if not AListBox^.Visible then Exit;

  absX := ParentX + AListBox^.Left;
  absY := ParentY + AListBox^.Top;

  clientW := AListBox^.Width - 4;
  clientH := AListBox^.Height - 4;
  contentH := LB_ContentHeight(AListBox);
  needV := contentH > clientH;
  if needV then Dec(clientW, 16);

  { 3D kenarl�k + zemin }
  KRect3D(absX, absY, AListBox^.Width, AListBox^.Height, False);
  KFill(absX + 2, absY + 2, AListBox^.Width - 4, AListBox^.Height - 4, AListBox^.Color);

  Clip_Save;
  Clip_Set(absX + 2, absY + 2, absX + 2 + clientW - 1, absY + 2 + clientH - 1);

  { Sat�rlar� �iz }
  i := 0;
  while i < AListBox^.ItemCount do
  begin
    y := absY + 4 + (i * AListBox^.RowHeight) - AListBox^.ScrollY;

    if y + AListBox^.RowHeight < absY + 2 then
    begin
      Inc(i);
      Continue;
    end;
    if y > absY + 2 + clientH then Break;

    { Arka plan rengi belirle: Se�ili > Hover > Alt/Normal }
    if i = AListBox^.ItemIndex then
    begin
      rowBack := AListBox^.SelColor;
      txtCol := AListBox^.SelTextColor;
    end
    else if i = AListBox^.HoverIndex then
    begin
      rowBack := AListBox^.HoverColor;
      txtCol := AListBox^.TextColor;
    end
    else if (i mod 2) = 1 then
    begin
      rowBack := AListBox^.AltColor;
      txtCol := AListBox^.TextColor;
    end
    else
    begin
      rowBack := AListBox^.Color;
      txtCol := AListBox^.TextColor;
    end;

    KFill(absX + 2, y, clientW, AListBox^.RowHeight, rowBack);

    { Metin }
    textY := y + (AListBox^.RowHeight - 10) div 2;
    if AListBox^.Items[i] <> nil then
      LB_DrawString(absX + 6, textY, AListBox^.Items[i], txtCol);

    { Se�ili sat�r ince �er�eve }
    if i = AListBox^.ItemIndex then
      KRect(absX + 2, y, clientW, AListBox^.RowHeight, $00A0A0A0);

    Inc(i);
  end;

  Clip_Restore;

  {------------------------------------------------------------------}
  {  D�KEY SCROLLBAR + OK BUTONLARI                                  }
  {------------------------------------------------------------------}
  if needV then
  begin
    AListBox^.VScrollRect.Left := AListBox^.Width - 18;
    AListBox^.VScrollRect.Top := 2;
    AListBox^.VScrollRect.Right := AListBox^.VScrollRect.Left + 16;
    AListBox^.VScrollRect.Bottom := AListBox^.Height - 2;

    { Track zemin }
    KFill(absX + AListBox^.VScrollRect.Left, absY + AListBox^.VScrollRect.Top,
          16, AListBox^.VScrollRect.Bottom - AListBox^.VScrollRect.Top, $00E0E0E0);
    KRect(absX + AListBox^.VScrollRect.Left, absY + AListBox^.VScrollRect.Top,
          16, AListBox^.VScrollRect.Bottom - AListBox^.VScrollRect.Top, $00808080);

    { Yukar� buton }
    btnX := absX + AListBox^.VScrollRect.Left;
    btnY := absY + AListBox^.VScrollRect.Top;
    KButton3D(btnX, btnY, 16, 16, False, $00DCDCDC);
    LB_DrawArrow(btnX, btnY, 0, $00000000);

    { A�a�� buton }
    btnY := absY + AListBox^.VScrollRect.Bottom - 16;
    KButton3D(btnX, btnY, 16, 16, False, $00DCDCDC);
    LB_DrawArrow(btnX, btnY, 1, $00000000);

    { Thumb }
    trackSize := AListBox^.VScrollRect.Bottom - AListBox^.VScrollRect.Top - 32;
    if (trackSize > 0) and (contentH > clientH) then
    begin
      thumbSize := (clientH * trackSize) div contentH;
      if thumbSize < 8 then thumbSize := 8;
      AListBox^.VThumbRect.Left := AListBox^.VScrollRect.Left + 2;
      AListBox^.VThumbRect.Top := AListBox^.VScrollRect.Top + 16 +
        (AListBox^.ScrollY * (trackSize - thumbSize) div (contentH - clientH));
      AListBox^.VThumbRect.Right := AListBox^.VScrollRect.Right - 2;
      AListBox^.VThumbRect.Bottom := AListBox^.VThumbRect.Top + thumbSize;
      KButton3D(absX + AListBox^.VThumbRect.Left, absY + AListBox^.VThumbRect.Top,
                AListBox^.VThumbRect.Right - AListBox^.VThumbRect.Left,
                AListBox^.VThumbRect.Bottom - AListBox^.VThumbRect.Top, False, $00D0D0D0);
    end;
  end;
end;

procedure ListBox_ProcessKey(AListBox: PListBox; Key: Word; Shift: Byte);
var pageSize: Integer;
begin
  if AListBox = nil then Exit;
  if AListBox^.ItemCount = 0 then Exit;

  pageSize := (AListBox^.Height - 4) div AListBox^.RowHeight;
  if pageSize < 1 then pageSize := 1;

  case Key of
    38: { Up }
      if AListBox^.ItemIndex > 0 then Dec(AListBox^.ItemIndex);
    40: { Down }
      if AListBox^.ItemIndex < AListBox^.ItemCount - 1 then Inc(AListBox^.ItemIndex);
    33: { PageUp }
      AListBox^.ItemIndex := AListBox^.ItemIndex - pageSize;
    34: { PageDown }
      AListBox^.ItemIndex := AListBox^.ItemIndex + pageSize;
    36: { Home }
      AListBox^.ItemIndex := 0;
    35: { End }
      AListBox^.ItemIndex := AListBox^.ItemCount - 1;
  end;

  if AListBox^.ItemIndex < 0 then AListBox^.ItemIndex := 0;
  if AListBox^.ItemIndex >= AListBox^.ItemCount then
    AListBox^.ItemIndex := AListBox^.ItemCount - 1;

  ListBox_EnsureVisible(AListBox);
end;

procedure ListBox_MouseDown(AListBox: PListBox; X, Y: Integer);
var
  needV: Boolean;
  clientH, contentH: Integer;
  relY, idx: Integer;
  maxScroll: Integer;
begin
  if AListBox = nil then Exit;

  clientH := AListBox^.Height - 4;
  contentH := LB_ContentHeight(AListBox);
  needV := contentH > clientH;

  {------------------------------------------------------------------}
  {  D�KEY SCROLLBAR HIT-TEST                                        }
  {------------------------------------------------------------------}
  if needV and (X >= AListBox^.Width - 18) and (X < AListBox^.Width - 2) and
     (Y >= 2) and (Y < AListBox^.Height - 2) then
  begin
    { Yukar� ok butonu }
    if (Y >= AListBox^.VScrollRect.Top) and (Y < AListBox^.VScrollRect.Top + 16) then
    begin
      AListBox^.ScrollY := AListBox^.ScrollY - AListBox^.RowHeight;
      if AListBox^.ScrollY < 0 then AListBox^.ScrollY := 0;
      Exit;
    end;
    { A�a�� ok butonu }
    if (Y >= AListBox^.VScrollRect.Bottom - 16) and (Y < AListBox^.VScrollRect.Bottom) then
    begin
      AListBox^.ScrollY := AListBox^.ScrollY + AListBox^.RowHeight;
      maxScroll := contentH - clientH;
      if maxScroll < 0 then maxScroll := 0;
      if AListBox^.ScrollY > maxScroll then AListBox^.ScrollY := maxScroll;
      Exit;
    end;
    { Thumb s�r�kleme }
    if (Y >= AListBox^.VThumbRect.Top) and (Y < AListBox^.VThumbRect.Bottom) then
    begin
      AListBox^.VScrollDrag := True;
      AListBox^.VScrollDragStart := Y;
      AListBox^.VScrollDragStartVal := AListBox^.ScrollY;
      Exit;
    end;
    { Track - Page Up }
    if Y < AListBox^.VThumbRect.Top then
    begin
      AListBox^.ScrollY := AListBox^.ScrollY - clientH;
      if AListBox^.ScrollY < 0 then AListBox^.ScrollY := 0;
    end
    { Track - Page Down }
    else
    begin
      AListBox^.ScrollY := AListBox^.ScrollY + clientH;
      maxScroll := contentH - clientH;
      if maxScroll < 0 then maxScroll := 0;
      if AListBox^.ScrollY > maxScroll then AListBox^.ScrollY := maxScroll;
    end;
    Exit;
  end;

  {------------------------------------------------------------------}
  {  SATIR SE��M�                                                    }
  {------------------------------------------------------------------}
  if (X >= 2) and (X < AListBox^.Width - 2 - (Ord(needV) * 16)) and
     (Y >= 2) and (Y < AListBox^.Height - 2) then
  begin
    relY := Y - 4 + AListBox^.ScrollY;
    idx := relY div AListBox^.RowHeight;
    if (idx >= 0) and (idx < AListBox^.ItemCount) then
    begin
      AListBox^.ItemIndex := idx;
      ListBox_EnsureVisible(AListBox);
    end;
  end;
end;

procedure ListBox_MouseMove(AListBox: PListBox; X, Y: Integer);
var
  deltaMouse, trackSize, thumbSize, maxScrollVal: Integer;
  needV: Boolean;
  clientH, contentH: Integer;
  relY, idx: Integer;
begin
  if AListBox = nil then Exit;

  clientH := AListBox^.Height - 4;
  contentH := LB_ContentHeight(AListBox);
  needV := contentH > clientH;

  { VScroll s�r�kleme }
  if AListBox^.VScrollDrag then
  begin
    deltaMouse := Y - AListBox^.VScrollDragStart;
    trackSize := AListBox^.VScrollRect.Bottom - AListBox^.VScrollRect.Top - 32;
    thumbSize := AListBox^.VThumbRect.Bottom - AListBox^.VThumbRect.Top;
    if (trackSize > thumbSize) and (contentH > clientH) then
    begin
      maxScrollVal := contentH - clientH;
      AListBox^.ScrollY := AListBox^.VScrollDragStartVal +
        (deltaMouse * maxScrollVal) div (trackSize - thumbSize);
      if AListBox^.ScrollY < 0 then AListBox^.ScrollY := 0;
      if AListBox^.ScrollY > maxScrollVal then AListBox^.ScrollY := maxScrollVal;
    end;
    Exit;
  end;

  { Hover hesaplama (MouseMove ile sat�r renklensin) }
  if (X >= 2) and (X < AListBox^.Width - 2 - (Ord(needV) * 16)) and
     (Y >= 2) and (Y < AListBox^.Height - 2) then
  begin
    relY := Y - 4 + AListBox^.ScrollY;
    idx := relY div AListBox^.RowHeight;
    if (idx >= 0) and (idx < AListBox^.ItemCount) then
      AListBox^.HoverIndex := idx
    else
      AListBox^.HoverIndex := -1;
  end
  else
    AListBox^.HoverIndex := -1;
end;

procedure ListBox_MouseUp(AListBox: PListBox; X, Y: Integer);
begin
  if AListBox = nil then Exit;
  AListBox^.VScrollDrag := False;
end;


{==============================================================================}
{  TPROGRESSBAR - IMPLEMENTATION                                               }
{==============================================================================}

function ProgressBar_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PProgressBar;
var pb: PProgressBar;
begin
  pb := MemAlloc(SizeOf(TProgressBar));
  if pb = nil then begin Result := nil; Exit; end;
  MemSet(pb, 0, SizeOf(TProgressBar));

  pb^.ObjectType := otProgressBar;
  pb^.Left := ALeft; pb^.Top := ATop;
  pb^.Width := AWidth; pb^.Height := AHeight;
  pb^.Visible := True;
  pb^.Min := 0;
  pb^.Max := 100;
  pb^.Position := 0;
  pb^.BarColor := $00008000;      { Ye�il }
  pb^.BackColor := $00C0C0C0;     { Gri }
  pb^.BorderColor := $00808080;
  pb^.TextColor := $00000000;
  pb^.ShowPercent := True;
  pb^.Orientation := 0;           { Yatay }

  pb^.OnDestroy := nil; { ProgressBar bellekte sadece string yok }
  if AParent <> nil then Object_AddChild(AParent, PObject(pb));
  Result := pb;
end;

procedure ProgressBar_SetPosition(AProgressBar: PProgressBar; APos: Integer);
begin
  if AProgressBar = nil then Exit;
  if APos < AProgressBar^.Min then APos := AProgressBar^.Min;
  if APos > AProgressBar^.Max then APos := AProgressBar^.Max;
  AProgressBar^.Position := APos;
end;

procedure ProgressBar_Draw(AProgressBar: PProgressBar; ParentX, ParentY: Integer);
var
  absX, absY, barSize, trackSize: Integer;
  percent: Integer;
  buf: array[0..15] of Char;
  textW, textX, textY: Integer;
begin
  if AProgressBar = nil then Exit;
  if not AProgressBar^.Visible then Exit;

  absX := ParentX + AProgressBar^.Left;
  absY := ParentY + AProgressBar^.Top;

  { 3D �er�eve (�ukur g�r�n�m) }
  KRect3D(absX, absY, AProgressBar^.Width, AProgressBar^.Height, True);
  KFill(absX + 2, absY + 2, AProgressBar^.Width - 4, AProgressBar^.Height - 4, AProgressBar^.BackColor);

  if AProgressBar^.Max <= AProgressBar^.Min then Exit;

  percent := ((AProgressBar^.Position - AProgressBar^.Min) * 100) div
             (AProgressBar^.Max - AProgressBar^.Min);

  if AProgressBar^.Orientation = 0 then
  begin
    { Yatay }
    trackSize := AProgressBar^.Width - 4;
    barSize := (percent * trackSize) div 100;
    if barSize < 0 then barSize := 0;
    if barSize > trackSize then barSize := trackSize;

    if barSize > 0 then
      KFill(absX + 2, absY + 2, barSize, AProgressBar^.Height - 4, AProgressBar^.BarColor);
  end
  else
  begin
    { Dikey (a�a��dan yukar�ya dolu) }
    trackSize := AProgressBar^.Height - 4;
    barSize := (percent * trackSize) div 100;
    if barSize < 0 then barSize := 0;
    if barSize > trackSize then barSize := trackSize;

    if barSize > 0 then
      KFill(absX + 2, absY + AProgressBar^.Height - 2 - barSize,
            AProgressBar^.Width - 4, barSize, AProgressBar^.BarColor);
  end;

  { Y�zde yaz�s� }
  if AProgressBar^.ShowPercent then
  begin
    { Basit say�dan stringe �evir }
    buf[0] := Char(48 + (percent div 100) mod 10);
    buf[1] := Char(48 + (percent div 10) mod 10);
    buf[2] := Char(48 + percent mod 10);
    buf[3] := '%';
    buf[4] := #0;

    textW := 4 * 8;
    textX := absX + (AProgressBar^.Width - textW) div 2;
    textY := absY + (AProgressBar^.Height - 10) div 2;
    LV_DrawString(textX, textY, @buf[0], AProgressBar^.TextColor);
  end;
end;

{==============================================================================}
{  TSCROLLBAR - IMPLEMENTATION                                                 }
{==============================================================================}

function ScrollBar_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PScrollBar;
var sb: PScrollBar;
begin
  sb := MemAlloc(SizeOf(TScrollBar));
  if sb = nil then begin Result := nil; Exit; end;
  MemSet(sb, 0, SizeOf(TScrollBar));

  sb^.ObjectType := otScrollBar;
  sb^.Left := ALeft; sb^.Top := ATop;
  sb^.Width := AWidth; sb^.Height := AHeight;
  sb^.Visible := True;
  sb^.Min := 0;
  sb^.Max := 100;
  sb^.Position := 0;
  sb^.PageSize := 10;
  sb^.SmallChange := 1;
  sb^.BorderColor := $00808080;
  sb^.Color := $00E0E0E0;
  sb^.ThumbColor := $00D0D0D0;
  sb^.BtnColor := $00DCDCDC;
  sb^.Dragging := False;

  { Boyuta g�re otomatik y�n }
  if AWidth > AHeight then
    sb^.Orientation := 0
  else
    sb^.Orientation := 1;

  if AParent <> nil then Object_AddChild(AParent, PObject(sb));
  Result := sb;
end;

procedure ScrollBar_SetPosition(AScrollBar: PScrollBar; APos: Integer);
begin
  if AScrollBar = nil then Exit;
  if APos < AScrollBar^.Min then APos := AScrollBar^.Min;
  if APos > AScrollBar^.Max then APos := AScrollBar^.Max;
  AScrollBar^.Position := APos;
end;

procedure SB_DrawArrow(X, Y: Integer; Dir: Byte; Color: LongWord);
begin
  case Dir of
    0: KChar(X + 4, Y + 4, '<', Color);
    1: KChar(X + 4, Y + 4, '>', Color);
    2: KChar(X + 4, Y + 4, '^', Color);
    3: KChar(X + 4, Y + 4, 'v', Color);
  end;
end;

procedure ScrollBar_Draw(AScrollBar: PScrollBar; ParentX, ParentY: Integer);
var
  absX, absY: Integer;
  trackPixels, thumbSize, thumbPos: Integer;
  btnSize: Integer;
begin
  if AScrollBar = nil then Exit;
  if not AScrollBar^.Visible then Exit;

  absX := ParentX + AScrollBar^.Left;
  absY := ParentY + AScrollBar^.Top;
  btnSize := 16;

  { 3D kenarl�k }
  KRect3D(absX, absY, AScrollBar^.Width, AScrollBar^.Height, False);

  if AScrollBar^.Orientation = 0 then
  begin
    { Yatay ScrollBar }
    AScrollBar^.Btn1Rect.Left := 2;
    AScrollBar^.Btn1Rect.Top := 2;
    AScrollBar^.Btn1Rect.Right := 2 + btnSize;
    AScrollBar^.Btn1Rect.Bottom := AScrollBar^.Height - 2;

    AScrollBar^.Btn2Rect.Left := AScrollBar^.Width - 2 - btnSize;
    AScrollBar^.Btn2Rect.Top := 2;
    AScrollBar^.Btn2Rect.Right := AScrollBar^.Width - 2;
    AScrollBar^.Btn2Rect.Bottom := AScrollBar^.Height - 2;

    AScrollBar^.TrackRect.Left := AScrollBar^.Btn1Rect.Right;
    AScrollBar^.TrackRect.Top := 2;
    AScrollBar^.TrackRect.Right := AScrollBar^.Btn2Rect.Left;
    AScrollBar^.TrackRect.Bottom := AScrollBar^.Height - 2;

    { Track zemin }
    KFill(absX + AScrollBar^.TrackRect.Left, absY + AScrollBar^.TrackRect.Top,
          AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left,
          AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top, AScrollBar^.Color);

    { Butonlar }
    KButton3D(absX + AScrollBar^.Btn1Rect.Left, absY + AScrollBar^.Btn1Rect.Top,
              btnSize, AScrollBar^.Height - 4, False, AScrollBar^.BtnColor);
    KButton3D(absX + AScrollBar^.Btn2Rect.Left, absY + AScrollBar^.Btn2Rect.Top,
              btnSize, AScrollBar^.Height - 4, False, AScrollBar^.BtnColor);
    SB_DrawArrow(absX + AScrollBar^.Btn1Rect.Left, absY + AScrollBar^.Btn1Rect.Top, 0, $00000000);
    SB_DrawArrow(absX + AScrollBar^.Btn2Rect.Left, absY + AScrollBar^.Btn2Rect.Top, 1, $00000000);

    { Thumb }
    trackPixels := AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left;
    if AScrollBar^.Max > AScrollBar^.Min then
    begin
      thumbSize := (AScrollBar^.PageSize * trackPixels) div
                   (AScrollBar^.Max - AScrollBar^.Min + AScrollBar^.PageSize);
      if thumbSize < 8 then thumbSize := 8;
      if thumbSize > trackPixels then thumbSize := trackPixels;

      thumbPos := ((AScrollBar^.Position - AScrollBar^.Min) * (trackPixels - thumbSize)) div
                  (AScrollBar^.Max - AScrollBar^.Min);
      if thumbPos < 0 then thumbPos := 0;
      if thumbPos > trackPixels - thumbSize then thumbPos := trackPixels - thumbSize;
    end
    else
    begin
      thumbSize := trackPixels;
      thumbPos := 0;
    end;

    AScrollBar^.ThumbRect.Left := AScrollBar^.TrackRect.Left + thumbPos;
    AScrollBar^.ThumbRect.Top := 3;
    AScrollBar^.ThumbRect.Right := AScrollBar^.ThumbRect.Left + thumbSize;
    AScrollBar^.ThumbRect.Bottom := AScrollBar^.Height - 3;

    KButton3D(absX + AScrollBar^.ThumbRect.Left, absY + AScrollBar^.ThumbRect.Top,
              AScrollBar^.ThumbRect.Right - AScrollBar^.ThumbRect.Left,
              AScrollBar^.ThumbRect.Bottom - AScrollBar^.ThumbRect.Top, False, AScrollBar^.ThumbColor);
  end
  else
  begin
    { Dikey ScrollBar }
    AScrollBar^.Btn1Rect.Left := 2;
    AScrollBar^.Btn1Rect.Top := 2;
    AScrollBar^.Btn1Rect.Right := AScrollBar^.Width - 2;
    AScrollBar^.Btn1Rect.Bottom := 2 + btnSize;

    AScrollBar^.Btn2Rect.Left := 2;
    AScrollBar^.Btn2Rect.Top := AScrollBar^.Height - 2 - btnSize;
    AScrollBar^.Btn2Rect.Right := AScrollBar^.Width - 2;
    AScrollBar^.Btn2Rect.Bottom := AScrollBar^.Height - 2;

    AScrollBar^.TrackRect.Left := 2;
    AScrollBar^.TrackRect.Top := AScrollBar^.Btn1Rect.Bottom;
    AScrollBar^.TrackRect.Right := AScrollBar^.Width - 2;
    AScrollBar^.TrackRect.Bottom := AScrollBar^.Btn2Rect.Top;

    { Track zemin }
    KFill(absX + AScrollBar^.TrackRect.Left, absY + AScrollBar^.TrackRect.Top,
          AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left,
          AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top, AScrollBar^.Color);

    { Butonlar }
    KButton3D(absX + AScrollBar^.Btn1Rect.Left, absY + AScrollBar^.Btn1Rect.Top,
              AScrollBar^.Width - 4, btnSize, False, AScrollBar^.BtnColor);
    KButton3D(absX + AScrollBar^.Btn2Rect.Left, absY + AScrollBar^.Btn2Rect.Top,
              AScrollBar^.Width - 4, btnSize, False, AScrollBar^.BtnColor);
    SB_DrawArrow(absX + AScrollBar^.Btn1Rect.Left, absY + AScrollBar^.Btn1Rect.Top, 2, $00000000);
    SB_DrawArrow(absX + AScrollBar^.Btn2Rect.Left, absY + AScrollBar^.Btn2Rect.Top, 3, $00000000);

    { Thumb }
    trackPixels := AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top;
    if AScrollBar^.Max > AScrollBar^.Min then
    begin
      thumbSize := (AScrollBar^.PageSize * trackPixels) div
                   (AScrollBar^.Max - AScrollBar^.Min + AScrollBar^.PageSize);
      if thumbSize < 8 then thumbSize := 8;
      if thumbSize > trackPixels then thumbSize := trackPixels;

      thumbPos := ((AScrollBar^.Position - AScrollBar^.Min) * (trackPixels - thumbSize)) div
                  (AScrollBar^.Max - AScrollBar^.Min);
      if thumbPos < 0 then thumbPos := 0;
      if thumbPos > trackPixels - thumbSize then thumbPos := trackPixels - thumbSize;
    end
    else
    begin
      thumbSize := trackPixels;
      thumbPos := 0;
    end;

    AScrollBar^.ThumbRect.Left := 3;
    AScrollBar^.ThumbRect.Top := AScrollBar^.TrackRect.Top + thumbPos;
    AScrollBar^.ThumbRect.Right := AScrollBar^.Width - 3;
    AScrollBar^.ThumbRect.Bottom := AScrollBar^.ThumbRect.Top + thumbSize;

    KButton3D(absX + AScrollBar^.ThumbRect.Left, absY + AScrollBar^.ThumbRect.Top,
              AScrollBar^.ThumbRect.Right - AScrollBar^.ThumbRect.Left,
              AScrollBar^.ThumbRect.Bottom - AScrollBar^.ThumbRect.Top, False, AScrollBar^.ThumbColor);
  end;
end;

procedure ScrollBar_MouseDown(AScrollBar: PScrollBar; X, Y: Integer);
var
  trackPixels, thumbSize: Integer;
  clickPos: Integer;
begin
  if AScrollBar = nil then Exit;

  { Btn1 (sol/yukar�) }
  if (X >= AScrollBar^.Btn1Rect.Left) and (X < AScrollBar^.Btn1Rect.Right) and
     (Y >= AScrollBar^.Btn1Rect.Top) and (Y < AScrollBar^.Btn1Rect.Bottom) then
  begin
    ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position - AScrollBar^.SmallChange);
    Exit;
  end;

  { Btn2 (sa�/a�a��) }
  if (X >= AScrollBar^.Btn2Rect.Left) and (X < AScrollBar^.Btn2Rect.Right) and
     (Y >= AScrollBar^.Btn2Rect.Top) and (Y < AScrollBar^.Btn2Rect.Bottom) then
  begin
    ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position + AScrollBar^.SmallChange);
    Exit;
  end;

  { Thumb }
  if (X >= AScrollBar^.ThumbRect.Left) and (X < AScrollBar^.ThumbRect.Right) and
     (Y >= AScrollBar^.ThumbRect.Top) and (Y < AScrollBar^.ThumbRect.Bottom) then
  begin
    AScrollBar^.Dragging := True;
    if AScrollBar^.Orientation = 0 then
      AScrollBar^.DragStart := X
    else
      AScrollBar^.DragStart := Y;
    AScrollBar^.DragStartVal := AScrollBar^.Position;
    Exit;
  end;

  { Track (bo� alan) - Page Size }
  if (X >= AScrollBar^.TrackRect.Left) and (X < AScrollBar^.TrackRect.Right) and
     (Y >= AScrollBar^.TrackRect.Top) and (Y < AScrollBar^.TrackRect.Bottom) then
  begin
    if AScrollBar^.Orientation = 0 then
    begin
      trackPixels := AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left;
      thumbSize := AScrollBar^.ThumbRect.Right - AScrollBar^.ThumbRect.Left;
      clickPos := X - AScrollBar^.TrackRect.Left;
      if clickPos < (AScrollBar^.ThumbRect.Left - AScrollBar^.TrackRect.Left) then
        ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position - AScrollBar^.PageSize)
      else
        ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position + AScrollBar^.PageSize);
    end
    else
    begin
      trackPixels := AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top;
      thumbSize := AScrollBar^.ThumbRect.Bottom - AScrollBar^.ThumbRect.Top;
      clickPos := Y - AScrollBar^.TrackRect.Top;
      if clickPos < (AScrollBar^.ThumbRect.Top - AScrollBar^.TrackRect.Top) then
        ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position - AScrollBar^.PageSize)
      else
        ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position + AScrollBar^.PageSize);
    end;
  end;
end;

procedure ScrollBar_MouseMove(AScrollBar: PScrollBar; X, Y: Integer);
var
  deltaMouse, trackPixels, thumbSize, maxPos: Integer;
begin
  if AScrollBar = nil then Exit;
  if not AScrollBar^.Dragging then Exit;

  if AScrollBar^.Orientation = 0 then
  begin
    deltaMouse := X - AScrollBar^.DragStart;
    trackPixels := AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left;
    thumbSize := AScrollBar^.ThumbRect.Right - AScrollBar^.ThumbRect.Left;
  end
  else
  begin
    deltaMouse := Y - AScrollBar^.DragStart;
    trackPixels := AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top;
    thumbSize := AScrollBar^.ThumbRect.Bottom - AScrollBar^.ThumbRect.Top;
  end;

  if (trackPixels > thumbSize) and (AScrollBar^.Max > AScrollBar^.Min) then
  begin
    maxPos := AScrollBar^.Max - AScrollBar^.Min;
    AScrollBar^.Position := AScrollBar^.DragStartVal +
      (deltaMouse * maxPos) div (trackPixels - thumbSize);
    if AScrollBar^.Position < AScrollBar^.Min then AScrollBar^.Position := AScrollBar^.Min;
    if AScrollBar^.Position > AScrollBar^.Max then AScrollBar^.Position := AScrollBar^.Max;
  end;
end;

procedure ScrollBar_MouseUp(AScrollBar: PScrollBar; X, Y: Integer);
begin
  if AScrollBar = nil then Exit;
  AScrollBar^.Dragging := False;
end;

{==============================================================================}
{  TCHECKBOX                                                                   }
{==============================================================================}

function CheckBox_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; const ACaption: PChar): PCheckBox;
var cb: PCheckBox; len: Integer;
begin
  cb := MemAlloc(SizeOf(TCheckBox));
  if cb = nil then begin Result := nil; Exit; end;
  MemSet(cb, 0, SizeOf(TCheckBox));

  cb^.ObjectType := otCheckBox;
  cb^.Left := ALeft; cb^.Top := ATop;
  cb^.Width := AWidth; cb^.Height := AHeight;
  cb^.Visible := True;
  cb^.Color := $00FFFFFF;
  cb^.TextColor := $00000000;
  cb^.BoxColor := $00FFFFFF;
  cb^.CheckColor := $00008000;
  cb^.Checked := False;

  len := StrLenP(ACaption);
  StrCopy(cb^.Caption, ACaption);

  cb^.OnDestroy := @CheckBox_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(cb));
  Result := cb;
end;

procedure CheckBox_Free(ACheckBox: PCheckBox);
begin
  if ACheckBox = nil then Exit;
end;

procedure CheckBox_Draw(ACheckBox: PCheckBox; ParentX, ParentY: Integer);
var
  absX, absY, boxY, textY: Integer;
begin
  if ACheckBox = nil then Exit;
  if not ACheckBox^.Visible then Exit;

  absX := ParentX + ACheckBox^.Left;
  absY := ParentY + ACheckBox^.Top;

  boxY := absY + (ACheckBox^.Height - 12) div 2;
  textY := absY + (ACheckBox^.Height - 8) div 2;

  { 3D �ukur kutu }
  KRect3D(absX + 2, boxY, 12, 12, True);
  KFill(absX + 3, boxY + 1, 10, 10, ACheckBox^.BoxColor);

  { Check i�areti (i�i dolu kare) }
  if ACheckBox^.Checked then
    KFill(absX + 4, boxY + 2, 8, 8, ACheckBox^.CheckColor);

  { Caption }
  if ACheckBox^.Caption <> nil then
    Component_DrawString(absX + 18, textY, ACheckBox^.Caption, ACheckBox^.TextColor);
end;

procedure CheckBox_MouseDown(ACheckBox: PCheckBox; X, Y: Integer);
begin
  if ACheckBox = nil then Exit;
  ACheckBox^.Checked := not ACheckBox^.Checked;
end;

{==============================================================================}
{  TRADIOBUTTON                                                                }
{==============================================================================}

function RadioButton_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; const ACaption: PChar): PRadioButton;
var rb: PRadioButton; len: Integer;
begin
  rb := MemAlloc(SizeOf(TRadioButton));
  if rb = nil then begin Result := nil; Exit; end;
  MemSet(rb, 0, SizeOf(TRadioButton));

  rb^.ObjectType := otRadioButton;
  rb^.Left := ALeft; rb^.Top := ATop;
  rb^.Width := AWidth; rb^.Height := AHeight;
  rb^.Visible := True;
  rb^.Color := $00FFFFFF;
  rb^.TextColor := $00000000;
  rb^.CircleColor := $00808080;
  rb^.DotColor := $00000000;
  rb^.Checked := False;

  len := StrLenP(ACaption);

 StrCopy(rb^.Caption, ACaption);

  rb^.OnDestroy := @RadioButton_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(rb));
  Result := rb;
end;

procedure RadioButton_Free(ARadio: PRadioButton);
begin
  if ARadio = nil then Exit;

end;

procedure RadioButton_Draw(ARadio: PRadioButton; ParentX, ParentY: Integer);
var
  absX, absY, circleY, textY: Integer;
begin
  if ARadio = nil then Exit;
  if not ARadio^.Visible then Exit;

  absX := ParentX + ARadio^.Left;
  absY := ParentY + ARadio^.Top;

  circleY := absY + (ARadio^.Height - 12) div 2;
  textY := absY + (ARadio^.Height - 8) div 2;

  { Yuvarlak g�r�n�ml� kutu (3D �ukur) }
  KRect3D(absX + 2, circleY, 12, 12, True);
  KFill(absX + 3, circleY + 1, 10, 10, $00FFFFFF);

  { Se�ili ise ortada dolu daire/kare }
  if ARadio^.Checked then
  begin
    KFill(absX + 5, circleY + 3, 6, 6, ARadio^.DotColor);
    KRect(absX + 5, circleY + 3, 6, 6, $00404040);
  end;

  { Caption }
  if ARadio^.Caption <> nil then
    Component_DrawString(absX + 18, textY, ARadio^.Caption, ARadio^.TextColor);
end;

procedure RadioButton_MouseDown(ARadio: PRadioButton; X, Y: Integer);
var
  sibling: PObject;
begin
  if ARadio = nil then Exit;
  if ARadio^.Checked then Exit;

  ARadio^.Checked := True;

  { Ayn� parent alt�ndaki di�er radio butonlar� uncheck et }
  if ARadio^.Parent <> nil then
  begin
    sibling := ARadio^.Parent^.Child;
    while sibling <> nil do
    begin
      if (sibling <> PObject(ARadio)) and (sibling^.ObjectType = otRadioButton) then
        PRadioButton(sibling)^.Checked := False;
      sibling := sibling^.Next;
    end;
  end;
end;

{==============================================================================}
{  TSTATUSBAR                                                                  }
{==============================================================================}

function StatusBar_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PStatusBar;
var sb: PStatusBar;
begin
  sb := MemAlloc(SizeOf(TStatusBar));
  if sb = nil then begin Result := nil; Exit; end;
  MemSet(sb, 0, SizeOf(TStatusBar));

  sb^.ObjectType := otStatusBar;
  sb^.Left := ALeft; sb^.Top := ATop;
  sb^.Width := AWidth; sb^.Height := AHeight;
  sb^.Visible := True;
  sb^.Color := $00E0E0E0;
  sb^.TextColor := $00000000;
  sb^.BorderColor := $00808080;
  sb^.PanelCount := 0;
  sb^.SimplePanel := False;
  sb^.SimpleText := nil;
  sb^.SizeGrip := True;
  sb^.Align:=alBottom;

  sb^.OnDestroy := @StatusBar_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(sb));
  Result := sb;
end;

procedure StatusBar_Free(AStatusBar: PStatusBar);
var i: Integer;
begin
  if AStatusBar = nil then Exit;
  for i := 0 to AStatusBar^.PanelCount - 1 do
    if AStatusBar^.Panels[i].Caption <> nil then
    begin
      FreeMem(AStatusBar^.Panels[i].Caption);
      AStatusBar^.Panels[i].Caption := nil;
    end;
  if AStatusBar^.SimpleText <> nil then FreeMem(AStatusBar^.SimpleText);
end;

procedure StatusBar_AddPanel(AStatusBar: PStatusBar; const ACaption: PChar; AWidth: Integer; AAlign: Byte);
var len: Integer; p: PChar;
begin
  if AStatusBar = nil then Exit;
  if AStatusBar^.PanelCount >= 8 then Exit;
  len := StrLenP(ACaption);
  p := MemAlloc(len + 1);
  if p <> nil then StrCopyP(p, ACaption);
  AStatusBar^.Panels[AStatusBar^.PanelCount].Caption := p;
  AStatusBar^.Panels[AStatusBar^.PanelCount].Width := AWidth;
  AStatusBar^.Panels[AStatusBar^.PanelCount].Alignment := AAlign;
  Inc(AStatusBar^.PanelCount);
end;

procedure StatusBar_SetSimpleText(AStatusBar: PStatusBar; const S: PChar);
var len: Integer;
begin
  if AStatusBar = nil then Exit;
  if AStatusBar^.SimpleText <> nil then FreeMem(AStatusBar^.SimpleText);
  len := StrLenP(S);
  AStatusBar^.SimpleText := MemAlloc(len + 1);
  if AStatusBar^.SimpleText <> nil then StrCopyP(AStatusBar^.SimpleText, S);
end;

procedure StatusBar_Draw(AStatusBar: PStatusBar; ParentX, ParentY: Integer);
var
  absX, absY, i, x, textY, textX, textW: Integer;
  panel: PStatusPanel;
  remainingW: Integer;
begin
  if AStatusBar = nil then Exit;
  if not AStatusBar^.Visible then Exit;

  absX := ParentX + AStatusBar^.Left;
  absY := ParentY + AStatusBar^.Top;

  { Ana zemin }
  KFill(absX, absY, AStatusBar^.Width, AStatusBar^.Height, AStatusBar^.Color);
  KRect3D(absX, absY, AStatusBar^.Width, AStatusBar^.Height, False);

  textY := absY + (AStatusBar^.Height - 8) div 2;

  if AStatusBar^.SimplePanel then
  begin
    { Basit mod: tek metin }
    if AStatusBar^.SimpleText <> nil then
      Component_DrawString(absX + 4, textY, AStatusBar^.SimpleText, AStatusBar^.TextColor);
  end
  else
  begin
    { Panel modu }
    x := absX + 2;
    for i := 0 to AStatusBar^.PanelCount - 1 do
    begin
      panel := @AStatusBar^.Panels[i];

      { Son panel kalan alan� kaplar }
      if i = AStatusBar^.PanelCount - 1 then
        remainingW := (absX + AStatusBar^.Width - 2) - x
      else
        remainingW := panel^.Width;

      if remainingW < 4 then remainingW := 4;

      { Panel 3D ��k�k �er�eve }
      KRect3D(x, absY + 2, remainingW, AStatusBar^.Height - 4, False);
      KFill(x + 2, absY + 4, remainingW - 4, AStatusBar^.Height - 8, AStatusBar^.Color);

      { Metin hizalama }
      if panel^.Caption <> nil then
      begin
        textW := Component_TextWidth(panel^.Caption);
        case panel^.Alignment of
          1: textX := x + (remainingW - textW) div 2; { Orta }
          2: textX := x + remainingW - textW - 4;     { Sa� }
        else
          textX := x + 4; { Sol }
        end;
        if textX < x + 2 then textX := x + 2;
        Component_DrawString(textX, textY, panel^.Caption, AStatusBar^.TextColor);
      end;

      x := x + remainingW;
      if x >= absX + AStatusBar^.Width - 2 then Break;
    end;
  end;

  { SizeGrip: sa� alt k��e basamaklar� }
  if AStatusBar^.SizeGrip then
  begin
    KLineH(absX + AStatusBar^.Width - 10, absY + AStatusBar^.Height - 4, 6, $00808080);
    KLineH(absX + AStatusBar^.Width - 8, absY + AStatusBar^.Height - 6, 4, $00808080);
    KLineH(absX + AStatusBar^.Width - 6, absY + AStatusBar^.Height - 8, 2, $00808080);
  end;
end;


{==============================================================================}
{  TGROUPBOX - IMPLEMENTATION                                                  }
{==============================================================================}

function GroupBox_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; const ACaption: PChar): PGroupBox;
var gb: PGroupBox; len: Integer;
begin
  gb := MemAlloc(SizeOf(TGroupBox));
  if gb = nil then begin Result := nil; Exit; end;
  MemSet(gb, 0, SizeOf(TGroupBox));

  gb^.ObjectType := otGroupBox;
  gb^.Left := ALeft; gb^.Top := ATop;
  gb^.Width := AWidth; gb^.Height := AHeight;
  gb^.Visible := True;
  gb^.Color := $00F0F0F0;
  gb^.BorderColor := $00808080;
  gb^.TextColor := $00000000;

  len := StrLenP(ACaption);

  StrCopy(gb^.Caption, ACaption);

  gb^.OnDestroy := @GroupBox_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(gb));
  Result := gb;
end;

procedure GroupBox_Free(AGroupBox: PGroupBox);
begin
  if AGroupBox = nil then Exit;

end;

procedure GroupBox_DrawChilds(AGroupBox: PGroupBox; ParentX, ParentY: Integer);
var
  child: PObject;
  absX, absY: Integer;
begin
  if AGroupBox = nil then Exit;
  absX := ParentX + AGroupBox^.Left + 8;
  absY := ParentY + AGroupBox^.Top + 16;

  child := AGroupBox^.Child;
  while child <> nil do
  begin
    if child^.Visible then
    begin
      case child^.ObjectType of
        otEdit:        Edit_Draw(PEdit(child), absX, absY);
        otMemo:        Memo_Draw(PMemo(child), absX, absY);
        otListView:    ListView_Draw(PListView(child), absX, absY);
        otListBox:     ListBox_Draw(PListBox(child), absX, absY);
        otCheckBox:    CheckBox_Draw(PCheckBox(child), absX, absY);
        otRadioButton: RadioButton_Draw(PRadioButton(child), absX, absY);
        otProgressBar: ProgressBar_Draw(PProgressBar(child), absX, absY);
        otScrollBar:   ScrollBar_Draw(PScrollBar(child), absX, absY);
        otStatusBar:   StatusBar_Draw(PStatusBar(child), absX, absY);
        otGroupBox:    GroupBox_Draw(PGroupBox(child), absX, absY);
        otToolBar:     ToolBar_Draw(PToolBar(child), absX, absY);
      end;
    end;
    child := child^.Next;
  end;
end;

procedure GroupBox_Draw(AGroupBox: PGroupBox; ParentX, ParentY: Integer);
var
  absX, absY, textW: Integer;
  capX, capY: Integer;
begin
  if AGroupBox = nil then Exit;
  if not AGroupBox^.Visible then Exit;

  absX := ParentX + AGroupBox^.Left;
  absY := ParentY + AGroupBox^.Top;
  textW := Component_TextWidth(AGroupBox^.Caption);

  { Caption yaz�s�n�n solundaki �izgi bo�lu�u }
  capX := absX + 10;
  capY := absY + 4;

  { �st �izgi: caption'�n solu ve sa�� }
  KLineH(absX + 2, absY + 8, 8, AGroupBox^.BorderColor);
  if AGroupBox^.Caption <> nil then
    KLineH(capX + textW + 2, absY + 8, AGroupBox^.Width - (capX + textW + 2 - absX), AGroupBox^.BorderColor)
  else
    KLineH(absX + 2, absY + 8, AGroupBox^.Width - 4, AGroupBox^.BorderColor);

  { Sol, sa�, alt �izgiler }
  KLineV(absX + 2, absY + 8, AGroupBox^.Height - 10, AGroupBox^.BorderColor);
  KLineV(absX + AGroupBox^.Width - 3, absY + 8, AGroupBox^.Height - 10, AGroupBox^.BorderColor);
  KLineH(absX + 2, absY + AGroupBox^.Height - 3, AGroupBox^.Width - 4, AGroupBox^.BorderColor);

  { 3D efekt: sol-�st a��k, sa�-alt koyu }
  KLineH(absX + 3, absY + 9, AGroupBox^.Width - 6, $00FFFFFF);
  KLineV(absX + 3, absY + 9, AGroupBox^.Height - 12, $00FFFFFF);
  KLineH(absX + 3, absY + AGroupBox^.Height - 4, AGroupBox^.Width - 6, $00404040);
  KLineV(absX + AGroupBox^.Width - 4, absY + 9, AGroupBox^.Height - 12, $00404040);

  { Zemin }
  KFill(absX + 4, absY + 10, AGroupBox^.Width - 8, AGroupBox^.Height - 14, AGroupBox^.Color);

  { Caption }
  if AGroupBox^.Caption <> nil then
    Component_DrawString(capX, capY, AGroupBox^.Caption, AGroupBox^.TextColor);

  { Child nesneleri �iz }
  GroupBox_DrawChilds(AGroupBox, ParentX, ParentY);
end;

{==============================================================================}
{  TTOOLBAR - IMPLEMENTATION                                                   }
{==============================================================================}

function ToolBar_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PToolBar;
var tb: PToolBar;
begin
  tb := MemAlloc(SizeOf(TToolBar));
  if tb = nil then begin Result := nil; Exit; end;
  MemSet(tb, 0, SizeOf(TToolBar));

  tb^.ObjectType := otToolBar;
  tb^.Left := ALeft; tb^.Top := ATop;
  tb^.Width := AWidth; tb^.Height := AHeight;
  tb^.Visible := True;
  tb^.Color := $00E0E0E0;
  tb^.TextColor := $00000000;
  tb^.BtnColor := $00DCDCDC;
  tb^.BtnPressedColor := $00B0B0B0;
  tb^.SeparatorColor := $00808080;
  tb^.ButtonHeight := 22;
  tb^.ButtonWidth := 60;
  tb^.ButtonCount := 0;
  tb^.HotIndex := -1;
  tb^.PressIndex := -1;
  tb^.SelectedIndex := -1;        { <<< YEN� }
  tb^.OnButtonClick := nil;       { <<< YEN� }

  tb^.OnDestroy := @ToolBar_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(tb));
  Result := tb;
end;

procedure ToolBar_Free(AToolBar: PToolBar);
var i: Integer;
begin
  if AToolBar = nil then Exit;
  for i := 0 to AToolBar^.ButtonCount - 1 do
    if AToolBar^.Buttons[i].Caption <> nil then
    begin
      FreeMem(AToolBar^.Buttons[i].Caption);
      AToolBar^.Buttons[i].Caption := nil;
    end;
end;

function ToolBar_AddButton(AToolBar: PToolBar; const ACaption: PChar; AIconIndex: Integer): Integer;
var len: Integer; p: PChar;
begin
  Result := -1;
  if AToolBar = nil then Exit;
  if AToolBar^.ButtonCount >= 16 then Exit;
  len := StrLenP(ACaption);
  p := MemAlloc(len + 1);
  if p <> nil then StrCopyP(p, ACaption);
  AToolBar^.Buttons[AToolBar^.ButtonCount].Caption := p;
  AToolBar^.Buttons[AToolBar^.ButtonCount].IconIndex := AIconIndex;
  AToolBar^.Buttons[AToolBar^.ButtonCount].Width := AToolBar^.ButtonWidth;
  AToolBar^.Buttons[AToolBar^.ButtonCount].Pressed := False;
  AToolBar^.Buttons[AToolBar^.ButtonCount].Enabled := True;
  AToolBar^.Buttons[AToolBar^.ButtonCount].Separator := False;
  AToolBar^.Buttons[AToolBar^.ButtonCount].Tag := 0;
  Result := AToolBar^.ButtonCount;
  Inc(AToolBar^.ButtonCount);
end;

function ToolBar_AddSeparator(AToolBar: PToolBar):Integer;
begin
  if AToolBar = nil then Exit;
  if AToolBar^.ButtonCount >= 16 then Exit;
  AToolBar^.Buttons[AToolBar^.ButtonCount].Caption := nil;
  AToolBar^.Buttons[AToolBar^.ButtonCount].Separator := True;
  AToolBar^.Buttons[AToolBar^.ButtonCount].Width := 8;
  AToolBar^.Buttons[AToolBar^.ButtonCount].Enabled := False;
  AToolBar^.Buttons[AToolBar^.ButtonCount].IconIndex := -1;
  Result := AToolBar^.ButtonCount;
  Inc(AToolBar^.ButtonCount);
end;


{------------------------------------------------------------------}
{  ��Z�M � SelectedIndex'e g�re hafif vurgu eklendi               }
{------------------------------------------------------------------}
procedure ToolBar_Draw(AToolBar: PToolBar; ParentX, ParentY: Integer);
var
  absX, absY, i, x, y, btnH, textW, textX, textY: Integer;
  btn: PToolButton;
  btnColor: LongWord;
  isHot, isPressed, isSelected: Boolean;
begin
  if AToolBar = nil then Exit;
  if not AToolBar^.Visible then Exit;

  absX := ParentX + AToolBar^.Left;
  absY := ParentY + AToolBar^.Top;

  { Bar zemin }
  KFill(absX, absY, AToolBar^.Width, AToolBar^.Height, AToolBar^.Color);
  KRect3D(absX, absY, AToolBar^.Width, AToolBar^.Height, False);

  btnH := AToolBar^.ButtonHeight;
  y := absY + (AToolBar^.Height - btnH) div 2;
  if y < absY + 2 then y := absY + 2;

  x := absX + 4;

  for i := 0 to AToolBar^.ButtonCount - 1 do
  begin
    btn := @AToolBar^.Buttons[i];

    if btn^.Separator then
    begin
      KLineV(x + 3, y + 2, btnH - 4, AToolBar^.SeparatorColor);
      KLineV(x + 4, y + 2, btnH - 4, $00FFFFFF);
      x := x + btn^.Width;
      Continue;
    end;

    isHot := (i = AToolBar^.HotIndex) and btn^.Enabled;
    isPressed := (i = AToolBar^.PressIndex) and btn^.Pressed;
    isSelected := (i = AToolBar^.SelectedIndex);   { <<< YEN� }

    { Buton arka plan }
    if isPressed then
      btnColor := AToolBar^.BtnPressedColor
    else if isSelected then
      btnColor := $00D0E8FF                        { <<< Se�ili buton: a��k mavi }
    else if isHot then
      btnColor := $00E8E8E8
    else
      btnColor := AToolBar^.BtnColor;

    if isPressed then
      KButton3D(x, y, btn^.Width, btnH, True, btnColor)
    else
      KButton3D(x, y, btn^.Width, btnH, False, btnColor);

    { �kon }
    if btn^.IconIndex >= 0 then
    begin
      KFill(x + 4, y + 4, 12, 12, LV_IconColor(btn^.IconIndex));
      KRect(x + 4, y + 4, 12, 12, $00606060);
    end;

    { Caption }
    if btn^.Caption <> nil then
    begin
      textW := Component_TextWidth(btn^.Caption);
      textX := x + (btn^.Width - textW) div 2;
      if btn^.IconIndex >= 0 then textX := x + 20;
      if textX < x + 2 then textX := x + 2;

      textY := y + (btnH - 8) div 2;
      if not btn^.Enabled then
        Component_DrawString(textX, textY, btn^.Caption, $00808080)
      else
        Component_DrawString(textX, textY, btn^.Caption, AToolBar^.TextColor);
    end;

    x := x + btn^.Width + 2;
    if x > absX + AToolBar^.Width - 4 then Break;
  end;
end;

{------------------------------------------------------------------}
{  MOUSE DOWN � SelectedIndex g�ncellenir, event ate�lenir        }
{------------------------------------------------------------------}
procedure ToolBar_MouseDown(AToolBar: PToolBar; X, Y: Integer);
var
  i, x1, btnH, yOff: Integer;
begin
  if AToolBar = nil then Exit;

  btnH := AToolBar^.ButtonHeight;
  yOff := (AToolBar^.Height - btnH) div 2;
  if yOff < 2 then yOff := 2;

  if (Y < yOff) or (Y > yOff + btnH) then Exit;

  x1 := 4;
  for i := 0 to AToolBar^.ButtonCount - 1 do
  begin
    if (X >= x1) and (X < x1 + AToolBar^.Buttons[i].Width) then
    begin
      if not AToolBar^.Buttons[i].Separator and AToolBar^.Buttons[i].Enabled then
      begin
        AToolBar^.Buttons[i].Pressed := True;
        AToolBar^.PressIndex := i;
        AToolBar^.SelectedIndex := i;   { <<< YEN�: Hangi buton t�kland� }

        { YEN�: Buton bazl� event }
        if Assigned(AToolBar^.OnButtonClick) then
          AToolBar^.OnButtonClick(AToolBar, i);
      end;
      Exit;
    end;
    x1 := x1 + AToolBar^.Buttons[i].Width + 2;
  end;
end;

procedure ToolBar_MouseMove(AToolBar: PToolBar; X, Y: Integer);
var
  i, x1, btnH, yOff: Integer;
begin
  if AToolBar = nil then Exit;

  btnH := AToolBar^.ButtonHeight;
  yOff := (AToolBar^.Height - btnH) div 2;
  if yOff < 2 then yOff := 2;

  if (Y < yOff) or (Y > yOff + btnH) then
  begin
    AToolBar^.HotIndex := -1;
    Exit;
  end;

  x1 := 4;
  for i := 0 to AToolBar^.ButtonCount - 1 do
  begin
    if (X >= x1) and (X < x1 + AToolBar^.Buttons[i].Width) then
    begin
      if not AToolBar^.Buttons[i].Separator then
        AToolBar^.HotIndex := i
      else
        AToolBar^.HotIndex := -1;
      Exit;
    end;
    x1 := x1 + AToolBar^.Buttons[i].Width + 2;
  end;
  AToolBar^.HotIndex := -1;
end;

{------------------------------------------------------------------}
{  MOUSE UP � T�M bas�l� durumlar� temizle (asla kal�c� olmaz)    }
{------------------------------------------------------------------}
procedure ToolBar_MouseUp(AToolBar: PToolBar; X, Y: Integer);
var i: Integer;
begin
  if AToolBar = nil then Exit;

  { <<< D�ZELTME: Hi�bir buton bas�l� kalmas�n (flat/sticky yok) }
  for i := 0 to AToolBar^.ButtonCount - 1 do
    AToolBar^.Buttons[i].Pressed := False;

  AToolBar^.PressIndex := -1;
end;
{==============================================================================}
{  TCOMBOBOX - IMPLEMENTATION                                                  }
{==============================================================================}

{==============================================================================}
{  TCOMBOBOX - IMPLEMENTATION                                                  }
{==============================================================================}

function ComboBox_Create(AParent: PObject; ALeft, ATop, AWidth: Integer): PComboBox;
var cb: PComboBox;
begin
  cb := MemAlloc(SizeOf(TComboBox));
  if cb = nil then begin Result := nil; Exit; end;
  MemSet(cb, 0, SizeOf(TComboBox));

  cb^.ObjectType := otComboBox;
  cb^.Left := ALeft; cb^.Top := ATop;
  cb^.Width := AWidth; cb^.Height := 22;
  cb^.Visible := True;
  cb^.Color := $00FFFFFF;
  cb^.BorderColor := $00808080;
  cb^.TextColor := $00000000;
  cb^.SelColor := $000080FF;
  cb^.SelTextColor := $00FFFFFF;
  cb^.AltColor := $00F0F8FF;
  cb^.EditHeight := 22;
  cb^.RowHeight := 16;
  cb^.DropHeight := 120;
  cb^.ItemIndex := -1;
  cb^.HoverIndex := -1;
  cb^.ItemCount := 0;
  cb^.ScrollY := 0;
  cb^.Dropped := False;
  cb^.VScrollDrag := False;

  cb^.OnDestroy := @ComboBox_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(cb));
  Result := cb;
end;

procedure ComboBox_Free(AComboBox: PComboBox);
begin
  if AComboBox = nil then Exit;
  ComboBox_Clear(AComboBox);
end;

procedure ComboBox_Clear(AComboBox: PComboBox);
var i: Integer;
begin
  if AComboBox = nil then Exit;
  for i := 0 to AComboBox^.ItemCount - 1 do
    if AComboBox^.Items[i] <> nil then
    begin
      FreeMem(AComboBox^.Items[i]);
      AComboBox^.Items[i] := nil;
    end;
  AComboBox^.ItemCount := 0;
  AComboBox^.ItemIndex := -1;
  AComboBox^.Dropped := False;
  AComboBox^.Height := AComboBox^.EditHeight;
end;

function ComboBox_AddItem(AComboBox: PComboBox; const S: PChar): Integer;
var p: PChar; len: Integer;
begin
  Result := -1;
  if AComboBox = nil then Exit;
  if AComboBox^.ItemCount >= 256 then Exit;
  len := StrLenP(S);
  p := MemAlloc(len + 1);
  if p = nil then Exit;
  StrCopyP(p, S);
  AComboBox^.Items[AComboBox^.ItemCount] := p;
  Result := AComboBox^.ItemCount;
  Inc(AComboBox^.ItemCount);
  if AComboBox^.ItemIndex < 0 then AComboBox^.ItemIndex := 0;
end;

function CB_DropHeight(AComboBox: PComboBox): Integer;
begin
  if AComboBox = nil then begin Result := 0; Exit; end;
  Result := AComboBox^.ItemCount * AComboBox^.RowHeight + 4;
  if Result > AComboBox^.DropHeight then Result := AComboBox^.DropHeight;
  if Result < AComboBox^.RowHeight + 4 then Result := AComboBox^.RowHeight + 4;
end;

function CB_DropNeedScroll(AComboBox: PComboBox; var ClientH: Integer): Boolean;
var dropH: Integer;
begin
  Result := False;
  if AComboBox = nil then Exit;
  dropH := CB_DropHeight(AComboBox);
  ClientH := dropH - 4;
  if AComboBox^.ItemCount * AComboBox^.RowHeight > ClientH then
    Result := True;
end;

procedure CB_UpdateDropScroll(AComboBox: PComboBox);
var clientH, contentH: Integer;
begin
  if AComboBox = nil then Exit;
  contentH := AComboBox^.ItemCount * AComboBox^.RowHeight;
  clientH := CB_DropHeight(AComboBox) - 4;
  if contentH <= clientH then
  begin
    AComboBox^.ScrollY := 0;
    Exit;
  end;
  if AComboBox^.ScrollY > contentH - clientH then
    AComboBox^.ScrollY := contentH - clientH;
  if AComboBox^.ScrollY < 0 then AComboBox^.ScrollY := 0;
end;

procedure CB_SetDropState(AComboBox: PComboBox; Dropped: Boolean);
var dropH: Integer;
begin
  if AComboBox = nil then Exit;
  AComboBox^.Dropped := Dropped;
  if Dropped then
  begin
    dropH := CB_DropHeight(AComboBox);
    AComboBox^.Height := AComboBox^.EditHeight + dropH;
  end
  else
  begin
    AComboBox^.Height := AComboBox^.EditHeight;
    AComboBox^.ScrollY := 0;
    AComboBox^.HoverIndex := -1;
  end;
end;

procedure ComboBox_Draw(AComboBox: PComboBox; ParentX, ParentY: Integer);
var
  absX, absY, dropH, clientW, clientH: Integer;
  needV: Boolean;
  contentH, thumbSize, trackSize: Integer;
  i, x, y, textY, btnX, btnY: Integer;
  rowBack, txtCol: LongWord;
begin
  if AComboBox = nil then Exit;
  if not AComboBox^.Visible then Exit;

  absX := ParentX + AComboBox^.Left;
  absY := ParentY + AComboBox^.Top;

  { --- EDIT ALANI --- }
  KRect3D(absX, absY, AComboBox^.Width, AComboBox^.EditHeight, False);
  KFill(absX + 2, absY + 2, AComboBox^.Width - 4, AComboBox^.EditHeight - 4, AComboBox^.Color);

  textY := absY + (AComboBox^.EditHeight - 8) div 2;
  if (AComboBox^.ItemIndex >= 0) and (AComboBox^.ItemIndex < AComboBox^.ItemCount) then
    Component_DrawString(absX + 4, textY, AComboBox^.Items[AComboBox^.ItemIndex], AComboBox^.TextColor);

  { Asagi ok butonu }
  btnX := absX + AComboBox^.Width - 18;
  btnY := absY + 2;
  KButton3D(btnX, btnY, 16, AComboBox^.EditHeight - 4, AComboBox^.Dropped, $00DCDCDC);
  KChar(btnX + 5, btnY + (AComboBox^.EditHeight - 12) div 2, 'v', $00000000);

  if not AComboBox^.Dropped then Exit;

  { --- DROPDOWN LISTE --- }
  dropH := CB_DropHeight(AComboBox);
  clientW := AComboBox^.Width - 4;
  clientH := dropH - 4;
  contentH := AComboBox^.ItemCount * AComboBox^.RowHeight;
  needV := contentH > clientH;
  if needV then Dec(clientW, 16);

  KFill(absX, absY + AComboBox^.EditHeight, AComboBox^.Width, dropH, AComboBox^.Color);
  KRect(absX, absY + AComboBox^.EditHeight, AComboBox^.Width, dropH, AComboBox^.BorderColor);

  KLineH(absX + 1, absY + AComboBox^.EditHeight + 1, AComboBox^.Width - 2, $00FFFFFF);
  KLineV(absX + 1, absY + AComboBox^.EditHeight + 1, dropH - 2, $00FFFFFF);
  KLineH(absX + 1, absY + AComboBox^.EditHeight + dropH - 2, AComboBox^.Width - 2, $00404040);
  KLineV(absX + AComboBox^.Width - 2, absY + AComboBox^.EditHeight + 1, dropH - 2, $00404040);

  Clip_Save;
  Clip_Set(absX + 2, absY + AComboBox^.EditHeight + 2,
           absX + 2 + clientW - 1, absY + AComboBox^.EditHeight + 2 + clientH - 1);

  i := 0;
  while i < AComboBox^.ItemCount do
  begin
    y := absY + AComboBox^.EditHeight + 2 + (i * AComboBox^.RowHeight) - AComboBox^.ScrollY;

    if y + AComboBox^.RowHeight < absY + AComboBox^.EditHeight + 2 then
    begin
      Inc(i);
      Continue;
    end;
    if y > absY + AComboBox^.EditHeight + 2 + clientH then Break;

    if i = AComboBox^.ItemIndex then
    begin
      rowBack := AComboBox^.SelColor;
      txtCol := AComboBox^.SelTextColor;
    end
    else if i = AComboBox^.HoverIndex then
    begin
      rowBack := $00E0F0FF;
      txtCol := AComboBox^.TextColor;
    end
    else if (i mod 2) = 1 then
    begin
      rowBack := AComboBox^.AltColor;
      txtCol := AComboBox^.TextColor;
    end
    else
    begin
      rowBack := AComboBox^.Color;
      txtCol := AComboBox^.TextColor;
    end;

    KFill(absX + 2, y, clientW, AComboBox^.RowHeight, rowBack);
    if AComboBox^.Items[i] <> nil then
      Component_DrawString(absX + 6, y + (AComboBox^.RowHeight - 8) div 2,
                           AComboBox^.Items[i], txtCol);

    Inc(i);
  end;

  Clip_Restore;

  { --- DROPDOWN SCROLLBAR --- }
  if needV then
  begin
    AComboBox^.VScrollRect.Left := AComboBox^.Width - 18;
    AComboBox^.VScrollRect.Top := AComboBox^.EditHeight + 2;
    AComboBox^.VScrollRect.Right := AComboBox^.Width - 2;
    AComboBox^.VScrollRect.Bottom := AComboBox^.EditHeight + 2 + clientH;

    KFill(absX + AComboBox^.VScrollRect.Left, absY + AComboBox^.VScrollRect.Top,
          16, AComboBox^.VScrollRect.Bottom - AComboBox^.VScrollRect.Top, $00E0E0E0);
    KRect(absX + AComboBox^.VScrollRect.Left, absY + AComboBox^.VScrollRect.Top,
          16, AComboBox^.VScrollRect.Bottom - AComboBox^.VScrollRect.Top, $00808080);

    KButton3D(absX + AComboBox^.VScrollRect.Left, absY + AComboBox^.VScrollRect.Top,
              16, 16, False, $00DCDCDC);
    KChar(absX + AComboBox^.VScrollRect.Left + 5, absY + AComboBox^.VScrollRect.Top + 4, '^', $00000000);

    KButton3D(absX + AComboBox^.VScrollRect.Left,
              absY + AComboBox^.VScrollRect.Bottom - 16, 16, 16, False, $00DCDCDC);
    KChar(absX + AComboBox^.VScrollRect.Left + 5,
          absY + AComboBox^.VScrollRect.Bottom - 12, 'v', $00000000);

    trackSize := AComboBox^.VScrollRect.Bottom - AComboBox^.VScrollRect.Top - 32;
    if (trackSize > 0) and (contentH > clientH) then
    begin
      thumbSize := (clientH * trackSize) div contentH;
      if thumbSize < 8 then thumbSize := 8;
      AComboBox^.VThumbRect.Left := AComboBox^.VScrollRect.Left + 2;
      AComboBox^.VThumbRect.Top := AComboBox^.VScrollRect.Top + 16 +
        (AComboBox^.ScrollY * (trackSize - thumbSize) div (contentH - clientH));
      AComboBox^.VThumbRect.Right := AComboBox^.VScrollRect.Right - 2;
      AComboBox^.VThumbRect.Bottom := AComboBox^.VThumbRect.Top + thumbSize;
      KButton3D(absX + AComboBox^.VThumbRect.Left, absY + AComboBox^.VThumbRect.Top,
                AComboBox^.VThumbRect.Right - AComboBox^.VThumbRect.Left,
                AComboBox^.VThumbRect.Bottom - AComboBox^.VThumbRect.Top, False, $00D0D0D0);
    end;
  end;
end;

procedure ComboBox_ProcessKey(AComboBox: PComboBox; Key: Word; Shift: Byte);
begin
  if AComboBox = nil then Exit;
  if AComboBox^.ItemCount = 0 then Exit;

  case Key of
    40: { Down }
      begin
        if not AComboBox^.Dropped then
        begin
          CB_SetDropState(AComboBox, True);
          CB_UpdateDropScroll(AComboBox);
        end
        else
        begin
          if AComboBox^.ItemIndex < AComboBox^.ItemCount - 1 then
            Inc(AComboBox^.ItemIndex)
          else
            AComboBox^.ItemIndex := 0;
          CB_UpdateDropScroll(AComboBox);
        end;
      end;
    38: { Up }
      begin
        if AComboBox^.Dropped then
        begin
          if AComboBox^.ItemIndex > 0 then
            Dec(AComboBox^.ItemIndex)
          else
            AComboBox^.ItemIndex := AComboBox^.ItemCount - 1;
          CB_UpdateDropScroll(AComboBox);
        end;
      end;
    13: { Enter }
      CB_SetDropState(AComboBox, not AComboBox^.Dropped);
    27: { Escape }
      CB_SetDropState(AComboBox, False);
    33: { PageUp }
      begin
        if AComboBox^.Dropped then
        begin
          AComboBox^.ItemIndex := AComboBox^.ItemIndex - (AComboBox^.DropHeight div AComboBox^.RowHeight);
          if AComboBox^.ItemIndex < 0 then AComboBox^.ItemIndex := 0;
          CB_UpdateDropScroll(AComboBox);
        end;
      end;
    34: { PageDown }
      begin
        if AComboBox^.Dropped then
        begin
          AComboBox^.ItemIndex := AComboBox^.ItemIndex + (AComboBox^.DropHeight div AComboBox^.RowHeight);
          if AComboBox^.ItemIndex >= AComboBox^.ItemCount then
            AComboBox^.ItemIndex := AComboBox^.ItemCount - 1;
          CB_UpdateDropScroll(AComboBox);
        end;
      end;
    36: { Home }
      begin
        if AComboBox^.Dropped then
        begin
          AComboBox^.ItemIndex := 0;
          CB_UpdateDropScroll(AComboBox);
        end;
      end;
    35: { End }
      begin
        if AComboBox^.Dropped then
        begin
          AComboBox^.ItemIndex := AComboBox^.ItemCount - 1;
          CB_UpdateDropScroll(AComboBox);
        end;
      end;
  end;
end;

procedure ComboBox_MouseDown(AComboBox: PComboBox; X, Y: Integer);
var
  dropH, clientH, contentH: Integer;
  needV: Boolean;
  relY, idx: Integer;
  maxScroll: Integer;
  vScrollTop, vScrollBottom: Integer;
  vThumbTop, vThumbBottom: Integer;
  trackSize, thumbSize: Integer;
begin
  if AComboBox = nil then Exit;

  { Ok butonu toggle }
  if (X >= AComboBox^.Width - 18) and (X < AComboBox^.Width - 2) and
     (Y >= 2) and (Y < AComboBox^.EditHeight - 2) then
  begin
    CB_SetDropState(AComboBox, not AComboBox^.Dropped);
    Exit;
  end;

  { Edit alanina tiklama -> dropdown kapat }
  if Y < AComboBox^.EditHeight then
  begin
    CB_SetDropState(AComboBox, False);
    Exit;
  end;

  if not AComboBox^.Dropped then Exit;

  { --- DROPDOWN HIT-TEST --- }
  dropH := CB_DropHeight(AComboBox);
  if Y > AComboBox^.EditHeight + dropH then
  begin
    CB_SetDropState(AComboBox, False);
    Exit;
  end;

  clientH := dropH - 4;
  contentH := AComboBox^.ItemCount * AComboBox^.RowHeight;
  needV := contentH > clientH;

  vScrollTop := AComboBox^.EditHeight + 2;
  vScrollBottom := AComboBox^.EditHeight + 2 + clientH;

  { Scrollbar hit-test (kendi hesaplamamiz) }
  if needV and (X >= AComboBox^.Width - 18) and (X < AComboBox^.Width - 2) and
     (Y >= vScrollTop) and (Y < vScrollBottom) then
  begin
    { Yukari ok }
    if (Y >= vScrollTop) and (Y < vScrollTop + 16) then
    begin
      AComboBox^.ScrollY := AComboBox^.ScrollY - AComboBox^.RowHeight;
      if AComboBox^.ScrollY < 0 then AComboBox^.ScrollY := 0;
      Exit;
    end;
    { Asagi ok }
    if (Y >= vScrollBottom - 16) and (Y < vScrollBottom) then
    begin
      AComboBox^.ScrollY := AComboBox^.ScrollY + AComboBox^.RowHeight;
      maxScroll := contentH - clientH;
      if maxScroll < 0 then maxScroll := 0;
      if AComboBox^.ScrollY > maxScroll then AComboBox^.ScrollY := maxScroll;
      Exit;
    end;

    { Thumb pozisyonunu hesapla }
    trackSize := vScrollBottom - vScrollTop - 32;
    if (trackSize > 0) and (contentH > clientH) then
    begin
      thumbSize := (clientH * trackSize) div contentH;
      if thumbSize < 8 then thumbSize := 8;
      vThumbTop := vScrollTop + 16 +
        (AComboBox^.ScrollY * (trackSize - thumbSize) div (contentH - clientH));
      vThumbBottom := vThumbTop + thumbSize;

      { Thumb s�r�kleme }
      if (Y >= vThumbTop) and (Y < vThumbBottom) then
      begin
        AComboBox^.VScrollDrag := True;
        AComboBox^.VScrollDragStart := Y;
        AComboBox^.VScrollDragStartVal := AComboBox^.ScrollY;
        Exit;
      end;
    end;

    { Track - Page Up/Down }
    if Y < vThumbTop then
    begin
      AComboBox^.ScrollY := AComboBox^.ScrollY - clientH;
      if AComboBox^.ScrollY < 0 then AComboBox^.ScrollY := 0;
    end
    else
    begin
      AComboBox^.ScrollY := AComboBox^.ScrollY + clientH;
      maxScroll := contentH - clientH;
      if maxScroll < 0 then maxScroll := 0;
      if AComboBox^.ScrollY > maxScroll then AComboBox^.ScrollY := maxScroll;
    end;
    Exit;
  end;

  { Item secimi }
  relY := Y - (AComboBox^.EditHeight + 2) + AComboBox^.ScrollY;
  idx := relY div AComboBox^.RowHeight;
  if (idx >= 0) and (idx < AComboBox^.ItemCount) then
  begin
    AComboBox^.ItemIndex := idx;
    CB_SetDropState(AComboBox, False);
  end;
end;

procedure ComboBox_MouseMove(AComboBox: PComboBox; X, Y: Integer);
var
  dropH, clientH, contentH: Integer;
  needV: Boolean;
  deltaMouse, trackSize, thumbSize, maxScrollVal: Integer;
  relY, idx: Integer;
  vScrollTop, vScrollBottom: Integer;
begin
  if AComboBox = nil then Exit;

  if not AComboBox^.Dropped then
  begin
    AComboBox^.HoverIndex := -1;
    Exit;
  end;

  dropH := CB_DropHeight(AComboBox);

  { Dropdown disina cikildi mi? }
  if (Y < AComboBox^.EditHeight) or (Y > AComboBox^.EditHeight + dropH) or
     (X < 0) or (X > AComboBox^.Width) then
  begin
    AComboBox^.HoverIndex := -1;
    Exit;
  end;

  clientH := dropH - 4;
  contentH := AComboBox^.ItemCount * AComboBox^.RowHeight;
  needV := contentH > clientH;
  vScrollTop := AComboBox^.EditHeight + 2;
  vScrollBottom := AComboBox^.EditHeight + 2 + clientH;

  { Scroll drag }
  if AComboBox^.VScrollDrag then
  begin
    deltaMouse := Y - AComboBox^.VScrollDragStart;
    trackSize := vScrollBottom - vScrollTop - 32;
    thumbSize := (clientH * trackSize) div contentH;
    if thumbSize < 8 then thumbSize := 8;
    if (trackSize > thumbSize) and (contentH > clientH) then
    begin
      maxScrollVal := contentH - clientH;
      AComboBox^.ScrollY := AComboBox^.VScrollDragStartVal +
        (deltaMouse * maxScrollVal) div (trackSize - thumbSize);
      if AComboBox^.ScrollY < 0 then AComboBox^.ScrollY := 0;
      if AComboBox^.ScrollY > maxScrollVal then AComboBox^.ScrollY := maxScrollVal;
    end;
    Exit;
  end;

  { Hover hesaplama (scroll alani disinda) }
  if not (needV and (X >= AComboBox^.Width - 18)) then
  begin
    relY := Y - (AComboBox^.EditHeight + 2) + AComboBox^.ScrollY;
    idx := relY div AComboBox^.RowHeight;
    if (idx >= 0) and (idx < AComboBox^.ItemCount) then
      AComboBox^.HoverIndex := idx
    else
      AComboBox^.HoverIndex := -1;
  end
  else
    AComboBox^.HoverIndex := -1;
end;

procedure ComboBox_MouseUp(AComboBox: PComboBox; X, Y: Integer);
begin
  if AComboBox = nil then Exit;
  AComboBox^.VScrollDrag := False;
end;


{==============================================================================}
{  TTREEVIEW - IMPLEMENTATION                                                  }
{==============================================================================}

function TreeNode_Create(const ACaption: PChar; AParent: PTreeNode): PTreeNode;
var node: PTreeNode; len: Integer; sibling: PTreeNode;
begin
  node := MemAlloc(SizeOf(TTreeNode));
  if node = nil then begin Result := nil; Exit; end;
  MemSet(node, 0, SizeOf(TTreeNode));

  len := StrLenP(ACaption);
  node^.Caption := MemAlloc(len + 1);
  if node^.Caption <> nil then StrCopyP(node^.Caption, ACaption);

  node^.Expanded := True;
  node^.HasChildren := False;
  node^.Parent := AParent;
  node^.FirstChild := nil;
  node^.NextSibling := nil;
  node^.PrevSibling := nil;
  node^.Tag := 0;

  if AParent <> nil then
  begin
    node^.Level := AParent^.Level + 1;
    if AParent^.FirstChild = nil then
    begin
      AParent^.FirstChild := node;
      AParent^.HasChildren := True;
    end
    else
    begin
      sibling := AParent^.FirstChild;
      while sibling^.NextSibling <> nil do
        sibling := sibling^.NextSibling;
      sibling^.NextSibling := node;
      node^.PrevSibling := sibling;
    end;
  end
  else
    node^.Level := 0;

  Result := node;
end;

procedure TV_FreeNodeRecursive(ANode: PTreeNode);
var child, next: PTreeNode;
begin
  if ANode = nil then Exit;
  child := ANode^.FirstChild;
  while child <> nil do
  begin
    next := child^.NextSibling;
    TV_FreeNodeRecursive(child);
    child := next;
  end;
  if ANode^.Caption <> nil then FreeMem(ANode^.Caption);
  FreeMem(ANode);
end;

procedure TreeNode_Free(ANode: PTreeNode);
begin
  TV_FreeNodeRecursive(ANode);
end;

function TreeView_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PTreeView;
var tv: PTreeView;
begin
  tv := MemAlloc(SizeOf(TTreeView));
  if tv = nil then begin Result := nil; Exit; end;
  MemSet(tv, 0, SizeOf(TTreeView));

  tv^.ObjectType := otTreeView;
  tv^.Left := ALeft; tv^.Top := ATop;
  tv^.Width := AWidth; tv^.Height := AHeight;
  tv^.Visible := True;
  tv^.Color := $00FFFFFF;
  tv^.BorderColor := $00808080;
  tv^.TextColor := $00000000;
  tv^.SelColor := $000080FF;
  tv^.SelTextColor := $00FFFFFF;
  tv^.AltColor := $00F0F8FF;
  tv^.HoverColor := $00E0F0FF;
  tv^.LineColor := $00808080;
  tv^.BoxColor := $00FFFFFF;
  tv^.RowHeight := 16;
  tv^.ItemIndex := -1;
  tv^.HoverIndex := -1;
  tv^.ScrollY := 0;
  tv^.VScrollDrag := False;

  tv^.Root := TreeNode_Create('', nil);
  tv^.Root^.Level := -1;
  tv^.Root^.Expanded := True;

  tv^.OnDestroy := @TreeView_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(tv));
  Result := tv;
end;

procedure TreeView_Free(ATreeView: PTreeView);
begin
  if ATreeView = nil then Exit;
  TreeNode_Free(ATreeView^.Root);
end;

procedure TreeView_Clear(ATreeView: PTreeView);
begin
  if ATreeView = nil then Exit;
  TreeNode_Free(ATreeView^.Root);
  ATreeView^.Root := TreeNode_Create('', nil);
  ATreeView^.Root^.Level := -1;
  ATreeView^.Root^.Expanded := True;
  ATreeView^.ItemIndex := -1;
  ATreeView^.HoverIndex := -1;
  ATreeView^.ScrollY := 0;
end;

function TreeView_AddNode(ATreeView: PTreeView; AParent: PTreeNode; const ACaption: PChar): PTreeNode;
begin
  Result := nil;
  if ATreeView = nil then Exit;
  if AParent = nil then AParent := ATreeView^.Root;
  Result := TreeNode_Create(ACaption, AParent);
end;

procedure TV_BuildVisible(ATreeView: PTreeView);

  procedure AddNode(ANode: PTreeNode);
  var c: PTreeNode;
  begin
    if ATreeView^.VisibleCount >= 1024 then Exit;
    ATreeView^.VisibleNodes[ATreeView^.VisibleCount] := ANode;
    Inc(ATreeView^.VisibleCount);
    if ANode^.Expanded then
    begin
      c := ANode^.FirstChild;
      while c <> nil do
      begin
        AddNode(c);
        c := c^.NextSibling;
      end;
    end;
  end;
var child: PTreeNode;
begin
  if ATreeView = nil then Exit;
  ATreeView^.VisibleCount := 0;
  child := ATreeView^.Root^.FirstChild;
  while child <> nil do
  begin
    AddNode(child);
    child := child^.NextSibling;
  end;
end;

function TV_ContentHeight(ATreeView: PTreeView): Integer;
begin
  if ATreeView = nil then begin Result := 0; Exit; end;
  Result := ATreeView^.VisibleCount * ATreeView^.RowHeight;
end;

procedure TreeView_Expand(ATreeView: PTreeView; ANode: PTreeNode);
begin
  if ATreeView = nil then Exit;
  if ANode = nil then Exit;
  if not ANode^.HasChildren then Exit;
  ANode^.Expanded := True;
end;

procedure TreeView_Collapse(ATreeView: PTreeView; ANode: PTreeNode);
begin
  if ATreeView = nil then Exit;
  if ANode = nil then Exit;
  ANode^.Expanded := False;
end;

procedure TV_EnsureVisible(ATreeView: PTreeView);
var clientH, contentH: Integer;
    needV: Boolean;
    itemTop, itemBottom: Integer;
begin
  if ATreeView = nil then Exit;
  if ATreeView^.ItemIndex < 0 then Exit;

  clientH := ATreeView^.Height - 4;
  contentH := TV_ContentHeight(ATreeView);
  needV := contentH > clientH;
  if needV then Dec(clientH, 16);

  itemTop := ATreeView^.ItemIndex * ATreeView^.RowHeight;
  itemBottom := itemTop + ATreeView^.RowHeight;

  if itemTop < ATreeView^.ScrollY then
    ATreeView^.ScrollY := itemTop
  else if itemBottom > ATreeView^.ScrollY + clientH then
    ATreeView^.ScrollY := itemBottom - clientH;

  if ATreeView^.ScrollY < 0 then ATreeView^.ScrollY := 0;
  if contentH > clientH then
  begin
    if ATreeView^.ScrollY > contentH - clientH then
      ATreeView^.ScrollY := contentH - clientH;
  end
  else
    ATreeView^.ScrollY := 0;
end;

function TV_GetAncestorAtLevel(ANode: PTreeNode; ALevel: Integer): PTreeNode;
begin
  Result := ANode;
  while (Result <> nil) and (Result^.Level > ALevel) do
    Result := Result^.Parent;
end;

procedure TV_DrawArrow(X, Y: Integer; Dir: Byte; Color: LongWord);
begin
  case Dir of
    0: KChar(X + 2, Y + 1, '+', Color);
    1: KChar(X + 2, Y + 1, '-', Color);
  end;
end;

procedure TreeView_Draw(ATreeView: PTreeView; ParentX, ParentY: Integer);
var
  absX, absY, clientW, clientH: Integer;
  needV: Boolean;
  contentH, thumbSize, trackSize: Integer;
  i, y, lvl: Integer;
  node, anc: PTreeNode;
  rowBack, txtCol: LongWord;
  lineX, boxX, boxY, capX: Integer;
  btnX, btnY: Integer;
begin
  if ATreeView = nil then Exit;
  if not ATreeView^.Visible then Exit;

  absX :=ParentX + ATreeView^.Left;
  absY :=ParentY + ATreeView^.Top;

  TV_BuildVisible(ATreeView);

  clientW := ATreeView^.Width - 4;
  clientH := ATreeView^.Height - 4;
  contentH := TV_ContentHeight(ATreeView);
  needV := contentH > clientH;
  if needV then Dec(clientW, 16);

  { 3D kenarlik + zemin }
  KRect3D(absX, absY, ATreeView^.Width, ATreeView^.Height, False);
  KFill(absX + 2, absY + 2, ATreeView^.Width - 4, ATreeView^.Height - 4, ATreeView^.Color);

 // Clip_Save;
 // Clip_Set(absX + 2, absY + 2, absX + 2 + clientW - 1, absY + 2 + clientH - 1);

  

  { Satirlari ciz }
  i := 0;
  while i < ATreeView^.VisibleCount do
  begin
    node := ATreeView^.VisibleNodes[i];
    y := absY + 4 + (i * ATreeView^.RowHeight) - ATreeView^.ScrollY;

    if y + ATreeView^.RowHeight < absY + 2 then
    begin
      Inc(i);
      Continue;
    end;
    if y > absY + 2 + clientH then Break;

    { Arka plan }
    if i = ATreeView^.ItemIndex then
    begin
      rowBack := ATreeView^.SelColor;
      txtCol := ATreeView^.SelTextColor;
    end
    else if i = ATreeView^.HoverIndex then
    begin
      rowBack := ATreeView^.HoverColor;
      txtCol := ATreeView^.TextColor;
    end
    else if (i mod 2) = 1 then
    begin
      rowBack := ATreeView^.AltColor;
      txtCol := ATreeView^.TextColor;
    end
    else
    begin
      rowBack := ATreeView^.Color;
      txtCol := ATreeView^.TextColor;
    end;

    KFill(absX + 2, y, clientW, ATreeView^.RowHeight, rowBack);

    { --- AGA� ��ZG�LER� --- }
    for lvl := 0 to node^.Level - 1 do
    begin
      anc := TV_GetAncestorAtLevel(node, lvl);
      if (anc <> nil) and (anc^.NextSibling <> nil) then
      begin
        lineX := absX + 4 + lvl * 16 + 4;
        KLineV(lineX, y, ATreeView^.RowHeight, ATreeView^.LineColor);
      end;
    end;

    { Yatay �izgi (parent'tan gelen) }
    if node^.Level > 0 then
    begin
      lineX := absX + 4 + (node^.Level - 1) * 16 + 4;
      KLineH(lineX, y + 7, 12, ATreeView^.LineColor);
    end;

    { Kutu veya yaprak noktasi }
    boxX := absX + 4 + node^.Level * 16;
    boxY := y + 3;

    if node^.HasChildren then
    begin
      { +/- kutusu }
      KRect3D(boxX, boxY, 9, 9, True);
      KFill(boxX + 1, boxY + 1, 7, 7, ATreeView^.BoxColor);
      if node^.Expanded then
        TV_DrawArrow(boxX, boxY, 1, $00000000)
      else
        TV_DrawArrow(boxX, boxY, 0, $00000000);
      capX := boxX + 14;
    end
    else
    begin
      { Yaprak: kucuk kare }
      KFill(boxX + 3, y + 6, 3, 3, ATreeView^.LineColor);
      capX := boxX + 14;
    end;

    { Caption }
    if node^.Caption <> nil then
      Component_DrawString(capX, y + 4, node^.Caption, txtCol);

    { Secili satir ince cerceve }
    if i = ATreeView^.ItemIndex then
      KRect(absX + 2, y, clientW, ATreeView^.RowHeight, $00A0A0A0);

    Inc(i);
  end;

 // Clip_Restore;

  {------------------------------------------------------------------}
  {  D�KEY SCROLLBAR                                                 }
  {------------------------------------------------------------------}
  if needV then
  begin
    ATreeView^.VScrollRect.Left := ATreeView^.Width - 18;
    ATreeView^.VScrollRect.Top := 2;
    ATreeView^.VScrollRect.Right := ATreeView^.Width - 2;
    ATreeView^.VScrollRect.Bottom := ATreeView^.Height - 2;

    KFill(absX + ATreeView^.VScrollRect.Left, absY + ATreeView^.VScrollRect.Top,
          16, ATreeView^.VScrollRect.Bottom - ATreeView^.VScrollRect.Top, $00E0E0E0);
    KRect(absX + ATreeView^.VScrollRect.Left, absY + ATreeView^.VScrollRect.Top,
          16, ATreeView^.VScrollRect.Bottom - ATreeView^.VScrollRect.Top, $00808080);

    { Yukari ok }
    btnX := absX + ATreeView^.VScrollRect.Left;
    btnY := absY + ATreeView^.VScrollRect.Top;
    KButton3D(btnX, btnY, 16, 16, False, $00DCDCDC);
    TV_DrawArrow(btnX, btnY, 2, $00000000); { ^ }

    { Asagi ok }
    btnY := absY + ATreeView^.VScrollRect.Bottom - 16;
    KButton3D(btnX, btnY, 16, 16, False, $00DCDCDC);
    TV_DrawArrow(btnX, btnY, 3, $00000000); { v }

    { Thumb }
    trackSize := ATreeView^.VScrollRect.Bottom - ATreeView^.VScrollRect.Top - 32;
    if (trackSize > 0) and (contentH > clientH) then
    begin
      thumbSize := (clientH * trackSize) div contentH;
      if thumbSize < 8 then thumbSize := 8;
      ATreeView^.VThumbRect.Left := ATreeView^.VScrollRect.Left + 2;
      ATreeView^.VThumbRect.Top := ATreeView^.VScrollRect.Top + 16 +
        (ATreeView^.ScrollY * (trackSize - thumbSize) div (contentH - clientH));
      ATreeView^.VThumbRect.Right := ATreeView^.VScrollRect.Right - 2;
      ATreeView^.VThumbRect.Bottom := ATreeView^.VThumbRect.Top + thumbSize;
      KButton3D(absX + ATreeView^.VThumbRect.Left, absY + ATreeView^.VThumbRect.Top,
                ATreeView^.VThumbRect.Right - ATreeView^.VThumbRect.Left,
                ATreeView^.VThumbRect.Bottom - ATreeView^.VThumbRect.Top, False, $00D0D0D0);
    end;
  end;
end;

procedure TreeView_ProcessKey(ATreeView: PTreeView; Key: Word; Shift: Byte);
var node: PTreeNode;
begin
  if ATreeView = nil then Exit;
  if ATreeView^.VisibleCount = 0 then Exit;

  case Key of
    38: { Up }
      if ATreeView^.ItemIndex > 0 then Dec(ATreeView^.ItemIndex);
    40: { Down }
      if ATreeView^.ItemIndex < ATreeView^.VisibleCount - 1 then Inc(ATreeView^.ItemIndex);
    37: { Left - Collapse }
      begin
        if (ATreeView^.ItemIndex >= 0) and (ATreeView^.ItemIndex < ATreeView^.VisibleCount) then
        begin
          node := ATreeView^.VisibleNodes[ATreeView^.ItemIndex];
          if node^.Expanded and node^.HasChildren then
            TreeView_Collapse(ATreeView, node)
          else if node^.Parent <> ATreeView^.Root then
          begin
            { Parent'a git ve onu sec }
            node := node^.Parent;
            { Parent'in visible index'ini bul }
            ATreeView^.ItemIndex := 0; { Basit yaklasim, optimize edilebilir }
            TV_EnsureVisible(ATreeView);
          end;
        end;
      end;
    39: { Right - Expand }
      begin
        if (ATreeView^.ItemIndex >= 0) and (ATreeView^.ItemIndex < ATreeView^.VisibleCount) then
        begin
          node := ATreeView^.VisibleNodes[ATreeView^.ItemIndex];
          if not node^.Expanded and node^.HasChildren then
            TreeView_Expand(ATreeView, node);
        end;
      end;
    13: { Enter - Toggle }
      begin
        if (ATreeView^.ItemIndex >= 0) and (ATreeView^.ItemIndex < ATreeView^.VisibleCount) then
        begin
          node := ATreeView^.VisibleNodes[ATreeView^.ItemIndex];
          if node^.HasChildren then
          begin
            if node^.Expanded then
              TreeView_Collapse(ATreeView, node)
            else
              TreeView_Expand(ATreeView, node);
          end;
        end;
      end;
    33: { PageUp }
      begin
        ATreeView^.ItemIndex := ATreeView^.ItemIndex - (ATreeView^.Height div ATreeView^.RowHeight);
        if ATreeView^.ItemIndex < 0 then ATreeView^.ItemIndex := 0;
      end;
    34: { PageDown }
      begin
        ATreeView^.ItemIndex := ATreeView^.ItemIndex + (ATreeView^.Height div ATreeView^.RowHeight);
        if ATreeView^.ItemIndex >= ATreeView^.VisibleCount then
          ATreeView^.ItemIndex := ATreeView^.VisibleCount - 1;
      end;
    36: { Home }
      ATreeView^.ItemIndex := 0;
    35: { End }
      ATreeView^.ItemIndex := ATreeView^.VisibleCount - 1;
  end;

  TV_EnsureVisible(ATreeView);
end;

procedure TreeView_MouseDown(ATreeView: PTreeView; X, Y: Integer);
var
  needV: Boolean;
  clientH, contentH: Integer;
  relY, idx: Integer;
  maxScroll: Integer;
  node: PTreeNode;
  boxX: Integer;
begin
  if ATreeView = nil then Exit;

  TV_BuildVisible(ATreeView);

  clientH := ATreeView^.Height - 4;
  contentH := TV_ContentHeight(ATreeView);
  needV := contentH > clientH;

  {------------------------------------------------------------------}
  {  SCROLLBAR HIT-TEST                                              }
  {------------------------------------------------------------------}
  if needV and (X >= ATreeView^.Width - 18) and (X < ATreeView^.Width - 2) and
     (Y >= 2) and (Y < ATreeView^.Height - 2) then
  begin
    { Yukari ok }
    if (Y >= ATreeView^.VScrollRect.Top) and (Y < ATreeView^.VScrollRect.Top + 16) then
    begin
      ATreeView^.ScrollY := ATreeView^.ScrollY - ATreeView^.RowHeight;
      if ATreeView^.ScrollY < 0 then ATreeView^.ScrollY := 0;
      Exit;
    end;
    { Asagi ok }
    if (Y >= ATreeView^.VScrollRect.Bottom - 16) and (Y < ATreeView^.VScrollRect.Bottom) then
    begin
      ATreeView^.ScrollY := ATreeView^.ScrollY + ATreeView^.RowHeight;
      maxScroll := contentH - clientH;
      if maxScroll < 0 then maxScroll := 0;
      if ATreeView^.ScrollY > maxScroll then ATreeView^.ScrollY := maxScroll;
      Exit;
    end;
    { Thumb }
    if (Y >= ATreeView^.VThumbRect.Top) and (Y < ATreeView^.VThumbRect.Bottom) then
    begin
      ATreeView^.VScrollDrag := True;
      ATreeView^.VScrollDragStart := Y;
      ATreeView^.VScrollDragStartVal := ATreeView^.ScrollY;
      Exit;
    end;
    { Track }
    if Y < ATreeView^.VThumbRect.Top then
    begin
      ATreeView^.ScrollY := ATreeView^.ScrollY - clientH;
      if ATreeView^.ScrollY < 0 then ATreeView^.ScrollY := 0;
    end
    else
    begin
      ATreeView^.ScrollY := ATreeView^.ScrollY + clientH;
      maxScroll := contentH - clientH;
      if maxScroll < 0 then maxScroll := 0;
      if ATreeView^.ScrollY > maxScroll then ATreeView^.ScrollY := maxScroll;
    end;
    Exit;
  end;

  {------------------------------------------------------------------}
  {  D���M HIT-TEST                                                  }
  {------------------------------------------------------------------}
  if (X >= 2) and (X < 2 + ATreeView^.Width - 4 - (Ord(needV) * 16)) and
     (Y >= 2) and (Y < 2 + clientH) then
  begin
    relY := Y - 4 + ATreeView^.ScrollY;
    idx := relY div ATreeView^.RowHeight;
    if (idx >= 0) and (idx < ATreeView^.VisibleCount) then
    begin
      node := ATreeView^.VisibleNodes[idx];
      boxX := 4 + node^.Level * 16;

      { +/- kutusuna tiklandi mi? }
      if node^.HasChildren and (X >= boxX) and (X < boxX + 9) then
      begin
        if node^.Expanded then
          TreeView_Collapse(ATreeView, node)
        else
          TreeView_Expand(ATreeView, node);
        { Expand/Collapse sonrasi ItemIndex gecersiz olabilir, 
          ama node hala ayni referanstir. Visible list yeniden 
          build edilecek. Index'i korumaya calisalim. }
      end
      else
      begin
        ATreeView^.ItemIndex := idx;
      end;
      TV_EnsureVisible(ATreeView);
    end;
  end;
end;

procedure TreeView_MouseMove(ATreeView: PTreeView; X, Y: Integer);
var
  deltaMouse, trackSize, thumbSize, maxScrollVal: Integer;
  needV: Boolean;
  clientH, contentH: Integer;
  relY, idx: Integer;
begin
  if ATreeView = nil then Exit;

  clientH := ATreeView^.Height - 4;
  contentH := TV_ContentHeight(ATreeView);
  needV := contentH > clientH;
  if needV then Dec(clientH, 16);

  { VScroll surukleme }
  if ATreeView^.VScrollDrag then
  begin
    deltaMouse := Y - ATreeView^.VScrollDragStart;
    trackSize := ATreeView^.VScrollRect.Bottom - ATreeView^.VScrollRect.Top - 32;
    thumbSize := ATreeView^.VThumbRect.Bottom - ATreeView^.VThumbRect.Top;
    if (trackSize > thumbSize) and (contentH > clientH) then
    begin
      maxScrollVal := contentH - clientH;
      ATreeView^.ScrollY := ATreeView^.VScrollDragStartVal +
        (deltaMouse * maxScrollVal) div (trackSize - thumbSize);
      if ATreeView^.ScrollY < 0 then ATreeView^.ScrollY := 0;
      if ATreeView^.ScrollY > maxScrollVal then ATreeView^.ScrollY := maxScrollVal;
    end;
    Exit;
  end;

  { Hover hesaplama }
  if (X >= 2) and (X < 2 + ATreeView^.Width - 4 - (Ord(needV) * 16)) and
     (Y >= 2) and (Y < 2 + clientH) then
  begin
    relY := Y - 4 + ATreeView^.ScrollY;
    idx := relY div ATreeView^.RowHeight;
    if (idx >= 0) and (idx < ATreeView^.VisibleCount) then
      ATreeView^.HoverIndex := idx
    else
      ATreeView^.HoverIndex := -1;
  end
  else
    ATreeView^.HoverIndex := -1;
end;

procedure TreeView_MouseUp(ATreeView: PTreeView; X, Y: Integer);
begin
  if ATreeView = nil then Exit;
  ATreeView^.VScrollDrag := False;
end;

{==============================================================================}
{  TTABCONTROL - IMPLEMENTATION                                                }
{==============================================================================}

procedure TC_FreeObjectRecursive(AObj: PObject);
var child, next: PObject;
begin
  if AObj = nil then Exit;
  child := AObj^.Child;
  while child <> nil do
  begin
    next := child^.Next;
    TC_FreeObjectRecursive(child);
    child := next;
  end;
  if  Assigned(AObj^.OnDestroy) then
  begin
    { Call specific destructor based on type }
    case AObj^.ObjectType of
      otEdit:        Edit_Free(PEdit(AObj));
      otMemo:        Memo_Free(PMemo(AObj));
      otListView:    ListView_Free(PListView(AObj));
      otListBox:     ListBox_Free(PListBox(AObj));
      otCheckBox:    CheckBox_Free(PCheckBox(AObj));
      otRadioButton: RadioButton_Free(PRadioButton(AObj));
      otProgressBar: FreeMem(AObj); { No string alloc }
      otScrollBar:   FreeMem(AObj);
      otStatusBar:   StatusBar_Free(PStatusBar(AObj));
      otGroupBox:    GroupBox_Free(PGroupBox(AObj));
      otToolBar:     ToolBar_Free(PToolBar(AObj));
      otComboBox:    ComboBox_Free(PComboBox(AObj));
      otTreeView:    TreeView_Free(PTreeView(AObj));
    else
      FreeMem(AObj);
    end;
  end
  else
    FreeMem(AObj);
end;

function TC_TextWidth(S: PChar): Integer;
begin
  Result := StrLenP(S) * 8;
end;

procedure TC_DrawString(X, Y: Integer; S: PChar; Color: LongWord);
var i: Integer;
begin
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    KChar(X + i * 8, Y, S[i], Color);
    Inc(i);
  end;
end;

function TC_TabWidth(ATabControl: PTabControl; Index: Integer): Integer;
var w: Integer;
begin
  if ATabControl^.TabWidth > 0 then
    Result := ATabControl^.TabWidth
  else
  begin
    w := TC_TextWidth(ATabControl^.Tabs[Index].Caption) + 16;
    if ATabControl^.ShowClose then w := w + 12;
    if w < 60 then w := 60;
    if w > 120 then w := 120;
    Result := w;
  end;
end;

function TabControl_Create(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer): PTabControl;
var tc: PTabControl;
begin
  tc := MemAlloc(SizeOf(TTabControl));
  if tc = nil then begin Result := nil; Exit; end;
  MemSet(tc, 0, SizeOf(TTabControl));

  tc^.ObjectType := otTabControl;
  tc^.Left := ALeft; tc^.Top := ATop;
  tc^.Width := AWidth; tc^.Height := AHeight;
  tc^.Visible := True;
  tc^.Color := $00C0C0C0;
  tc^.ClientColor := $00FFFFFF;
  tc^.TabColor := $00D0D0D0;
  tc^.ActiveTabColor := $00E8E8E8;
  tc^.TextColor := $00000000;
  tc^.BorderColor := $00808080;
  tc^.TabHeight := 24;
  tc^.TabWidth := 0;
  tc^.TabCount := 0;
  tc^.ActiveTab := -1;
  tc^.ShowClose := True;
  tc^.HScrollOffset := 0;

  tc^.OnDestroy := @TabControl_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(tc));
  Result := tc;
end;

procedure TabControl_Free(ATabControl: PTabControl);
var i: Integer;
begin
  if ATabControl = nil then Exit;
  for i := 0 to ATabControl^.TabCount - 1 do
  begin
    if ATabControl^.Tabs[i].Caption <> nil then FreeMem(ATabControl^.Tabs[i].Caption);
    if ATabControl^.Tabs[i].Page <> nil then
      TC_FreeObjectRecursive(ATabControl^.Tabs[i].Page);
  end;
end;

function TabControl_AddTab(ATabControl: PTabControl; const ACaption: PChar): Integer;
var page: PObject; len: Integer; p: PChar;
begin
  Result := -1;
  if ATabControl = nil then Exit;
  if ATabControl^.TabCount >= 16 then Exit;

  { Caption }
  len := StrLenP(ACaption);
  p := MemAlloc(len + 1);
  if p <> nil then StrCopyP(p, ACaption);

  { Page container }
  page := MemAlloc(SizeOf(TObject));
  if page = nil then
  begin
    if p <> nil then FreeMem(p);
    Exit;
  end;
  MemSet(page, 0, SizeOf(TObject));
  page^.ObjectType := otContainer;
  page^.Visible := False; { Kendisi �izilmez, child'lar� �izilir }
  page^.Left := 2;
  page^.Top := ATabControl^.TabHeight + 2;
  page^.Width := ATabControl^.Width - 4;
  page^.Height := ATabControl^.Height - ATabControl^.TabHeight - 4;
  page^.Color := ATabControl^.ClientColor;

  ATabControl^.Tabs[ATabControl^.TabCount].Caption := p;
  ATabControl^.Tabs[ATabControl^.TabCount].Page := page;
  ATabControl^.Tabs[ATabControl^.TabCount].CanClose := True;
  Result := ATabControl^.TabCount;
  Inc(ATabControl^.TabCount);

  if ATabControl^.ActiveTab < 0 then
    TabControl_SetActiveTab(ATabControl, 0);
end;

procedure TabControl_RemoveTab(ATabControl: PTabControl; Index: Integer);
var i: Integer;
begin
  if ATabControl = nil then Exit;
  if (Index < 0) or (Index >= ATabControl^.TabCount) then Exit;

  if ATabControl^.Tabs[Index].Caption <> nil then
    FreeMem(ATabControl^.Tabs[Index].Caption);
  if ATabControl^.Tabs[Index].Page <> nil then
    TC_FreeObjectRecursive(ATabControl^.Tabs[Index].Page);

  for i := Index to ATabControl^.TabCount - 2 do
    ATabControl^.Tabs[i] := ATabControl^.Tabs[i + 1];

  Dec(ATabControl^.TabCount);

  if ATabControl^.TabCount = 0 then
    ATabControl^.ActiveTab := -1
  else if ATabControl^.ActiveTab >= ATabControl^.TabCount then
    ATabControl^.ActiveTab := ATabControl^.TabCount - 1
  else if ATabControl^.ActiveTab = Index then
    { Aktif tab kapat�ld�, yeni aktif tab zaten Index veya Index-1 oldu }
    if ATabControl^.ActiveTab >= ATabControl^.TabCount then
      ATabControl^.ActiveTab := ATabControl^.TabCount - 1;
end;

procedure TabControl_SetActiveTab(ATabControl: PTabControl; Index: Integer);
begin
  if ATabControl = nil then Exit;
  if (Index < 0) or (Index >= ATabControl^.TabCount) then Exit;
  ATabControl^.ActiveTab := Index;
end;

procedure TC_DrawPageChilds(ATabControl: PTabControl; Page: PObject; ParentX, ParentY: Integer);
var child: PObject; offX, offY: Integer;
begin
  if (ATabControl = nil) or (Page = nil) then Exit;
  child := Page^.Child;
  offX := ParentX + Page^.Left;
  offY := ParentY + Page^.Top;

  while child <> nil do
  begin
    if child^.Visible then
    begin
      case child^.ObjectType of
        otEdit:        Edit_Draw(PEdit(child), offX, offY);
        otMemo:        Memo_Draw(PMemo(child), offX, offY);
        otListView:    ListView_Draw(PListView(child), offX, offY);
        otListBox:     ListBox_Draw(PListBox(child), offX, offY);
        otCheckBox:    CheckBox_Draw(PCheckBox(child), offX, offY);
        otRadioButton: RadioButton_Draw(PRadioButton(child), offX, offY);
        otProgressBar: ProgressBar_Draw(PProgressBar(child), offX, offY);
        otScrollBar:   ScrollBar_Draw(PScrollBar(child), offX, offY);
        otStatusBar:   StatusBar_Draw(PStatusBar(child), offX, offY);
        otGroupBox:    GroupBox_Draw(PGroupBox(child), offX, offY);
        otToolBar:     ToolBar_Draw(PToolBar(child), offX, offY);
        otComboBox:    ComboBox_Draw(PComboBox(child), offX, offY);
        otTreeView:    TreeView_Draw(PTreeView(child), offX, offY);
      end;
    end;
    child := child^.Next;
  end;
end;

procedure TC_SendMouseToPageChilds(ATabControl: PTabControl; Page: PObject; X, Y: Integer; IsDown, IsMove, IsUp: Boolean);
var child: PObject; offX, offY, localX, localY: Integer;
begin
  if (ATabControl = nil) or (Page = nil) then Exit;
  child := Page^.Child;
  offX := Page^.Left;
  offY := Page^.Top;

  while child <> nil do
  begin
    if child^.Visible and
       (X >= offX + child^.Left) and (X < offX + child^.Left + child^.Width) and
       (Y >= offY + child^.Top) and (Y < offY + child^.Top + child^.Height) then
    begin
      localX := X - (offX + child^.Left);
      localY := Y - (offY + child^.Top);

      if IsDown then
      begin
        case child^.ObjectType of
          otEdit:        Edit_MouseDown(PEdit(child), localX, localY);
          otCheckBox:    CheckBox_MouseDown(PCheckBox(child), localX, localY);
          otRadioButton: RadioButton_MouseDown(PRadioButton(child), localX, localY);
          otListBox:     ListBox_MouseDown(PListBox(child), localX, localY);
          otListView:    ListView_MouseDown(PListView(child), localX, localY);
          otScrollBar:   ScrollBar_MouseDown(PScrollBar(child), localX, localY);
          otToolBar:     ToolBar_MouseDown(PToolBar(child), localX, localY);
          otComboBox:    ComboBox_MouseDown(PComboBox(child), localX, localY);
          otTreeView:    TreeView_MouseDown(PTreeView(child), localX, localY);
        end;
      end
      else if IsMove then
      begin
        case child^.ObjectType of
          otListBox:     ListBox_MouseMove(PListBox(child), localX, localY);
          otListView:    ListView_MouseMove(PListView(child), localX, localY);
          otScrollBar:   ScrollBar_MouseMove(PScrollBar(child), localX, localY);
          otToolBar:     ToolBar_MouseMove(PToolBar(child), localX, localY);
          otComboBox:    ComboBox_MouseMove(PComboBox(child), localX, localY);
          otTreeView:    TreeView_MouseMove(PTreeView(child), localX, localY);
        end;
      end
      else if IsUp then
      begin
        case child^.ObjectType of
          otListBox:     ListBox_MouseUp(PListBox(child), localX, localY);
          otListView:    ListView_MouseUp(PListView(child), localX, localY);
          otScrollBar:   ScrollBar_MouseUp(PScrollBar(child), localX, localY);
          otToolBar:     ToolBar_MouseUp(PToolBar(child), localX, localY);
          otComboBox:    ComboBox_MouseUp(PComboBox(child), localX, localY);
          otTreeView:    TreeView_MouseUp(PTreeView(child), localX, localY);
        end;
      end;
      Exit; { Sadece ilk hit olan child'a g�nder }
    end;
    child := child^.Next;
  end;
end;

procedure TabControl_Draw(ATabControl: PTabControl; ParentX, ParentY: Integer);
var
  absX, absY, i, x, tabW, textX, textY: Integer;
  isActive: Boolean;
  pageY: Integer;
begin
  if ATabControl = nil then Exit;
  if not ATabControl^.Visible then Exit;

  absX := ParentX + ATabControl^.Left;
  absY := ParentY + ATabControl^.Top;

  { Tab bar zemin }
  KFill(absX, absY, ATabControl^.Width, ATabControl^.TabHeight, ATabControl^.TabColor);
  KRect3D(absX, absY, ATabControl^.Width, ATabControl^.TabHeight, False);

  { Tab'lar� �iz }
  x := absX + 4 - ATabControl^.HScrollOffset;

  for i := 0 to ATabControl^.TabCount - 1 do
  begin
    tabW := TC_TabWidth(ATabControl, i);

    { Clip }
    if x + tabW < absX + 2 then
    begin
      x := x + tabW + 2;
      Continue;
    end;
    if x > absX + ATabControl^.Width - 2 then Break;

    isActive := (i = ATabControl^.ActiveTab);

    { Aktif tab: ��k�k, pasif: bas�k }
    if isActive then
    begin
      KButton3D(x, absY + 2, tabW, ATabControl^.TabHeight - 2, False, ATabControl^.ActiveTabColor);
      { Aktif tab'�n alt �izgisini kapat (page ile birle�ik) }
      KFill(x + 2, absY + ATabControl^.TabHeight - 2, tabW - 4, 3, ATabControl^.ActiveTabColor);
    end
    else
    begin
      KButton3D(x, absY + 2, tabW, ATabControl^.TabHeight - 4, True, ATabControl^.TabColor);
    end;

    { Caption }
    textY := absY + (ATabControl^.TabHeight - 8) div 2;
    textX := x + (tabW - TC_TextWidth(ATabControl^.Tabs[i].Caption)) div 2;
    if ATabControl^.ShowClose then textX := textX - 6;
    if textX < x + 4 then textX := x + 4;
    TC_DrawString(textX, textY, ATabControl^.Tabs[i].Caption, ATabControl^.TextColor);

    { Close butonu }
    if ATabControl^.ShowClose and ATabControl^.Tabs[i].CanClose then
    begin
      ATabControl^.Tabs[i].CloseRect.Left := x + tabW - 14;
      ATabControl^.Tabs[i].CloseRect.Top := absY + 6;
      ATabControl^.Tabs[i].CloseRect.Right := x + tabW - 4;
      ATabControl^.Tabs[i].CloseRect.Bottom := absY + 16;
      KChar(x + tabW - 12, absY + 6, 'x', $00800000);
    end;

    x := x + tabW + 2;
  end;

  { Page alan� }
  pageY := absY + ATabControl^.TabHeight;
  KRect3D(absX, pageY, ATabControl^.Width, ATabControl^.Height - ATabControl^.TabHeight, True);
  KFill(absX + 2, pageY + 2, ATabControl^.Width - 4, ATabControl^.Height - ATabControl^.TabHeight - 4, ATabControl^.ClientColor);

  { Aktif tab'�n child'lar�n� �iz }
  if (ATabControl^.ActiveTab >= 0) and (ATabControl^.ActiveTab < ATabControl^.TabCount) then
    TC_DrawPageChilds(ATabControl, ATabControl^.Tabs[ATabControl^.ActiveTab].Page, absX, absY);
end;

procedure TabControl_MouseDown(ATabControl: PTabControl; X, Y: Integer);
var
  i, x1, tabW: Integer;
  page: PObject;
begin
  if ATabControl = nil then Exit;

  { Tab bar }
  if Y < ATabControl^.TabHeight then
  begin
    x1 := 4 - ATabControl^.HScrollOffset;

    for i := 0 to ATabControl^.TabCount - 1 do
    begin
      tabW := TC_TabWidth(ATabControl, i);

      { Close butonu hit-test }
      if ATabControl^.ShowClose and ATabControl^.Tabs[i].CanClose and
         (X >= ATabControl^.Tabs[i].CloseRect.Left - ATabControl^.Left) and
         (X < ATabControl^.Tabs[i].CloseRect.Right - ATabControl^.Left) and
         (Y >= ATabControl^.Tabs[i].CloseRect.Top - ATabControl^.Top) and
         (Y < ATabControl^.Tabs[i].CloseRect.Bottom - ATabControl^.Top) then
      begin
        TabControl_RemoveTab(ATabControl, i);
        Exit;
      end;

      if (X >= x1) and (X < x1 + tabW) then
      begin
        TabControl_SetActiveTab(ATabControl, i);
        Exit;
      end;
      x1 := x1 + tabW + 2;
    end;
    Exit;
  end;

  { Page alan� - aktif tab'�n child'lar�na ilet }
  if (ATabControl^.ActiveTab >= 0) and (ATabControl^.ActiveTab < ATabControl^.TabCount) then
  begin
    page := ATabControl^.Tabs[ATabControl^.ActiveTab].Page;
    TC_SendMouseToPageChilds(ATabControl, page, X, Y, True, False, False);
  end;
end;

procedure TabControl_MouseMove(ATabControl: PTabControl; X, Y: Integer);
var page: PObject;
begin
  if ATabControl = nil then Exit;
  if Y < ATabControl^.TabHeight then Exit;

  if (ATabControl^.ActiveTab >= 0) and (ATabControl^.ActiveTab < ATabControl^.TabCount) then
  begin
    page := ATabControl^.Tabs[ATabControl^.ActiveTab].Page;
    TC_SendMouseToPageChilds(ATabControl, page, X, Y, False, True, False);
  end;
end;

procedure TabControl_MouseUp(ATabControl: PTabControl; X, Y: Integer);
var page: PObject;
begin
  if ATabControl = nil then Exit;
  if Y < ATabControl^.TabHeight then Exit;

  if (ATabControl^.ActiveTab >= 0) and (ATabControl^.ActiveTab < ATabControl^.TabCount) then
  begin
    page := ATabControl^.Tabs[ATabControl^.ActiveTab].Page;
    TC_SendMouseToPageChilds(ATabControl, page, X, Y, False, False, True);
  end;
end;

{==============================================================================}
{  TMENU - IMPLEMENTATION                                                      }
{==============================================================================}

{==============================================================================}
{  TMENU - IMPLEMENTATION                                                      }
{==============================================================================}

function MenuItem_Create(const ACaption: PChar; AParent: PMenuItem): PMenuItem;
var
  it: PMenuItem;
  len: Integer;
  last: PMenuItem;
begin
  it := MemAlloc(SizeOf(TMenuItem));
  if it = nil then begin Result := nil; Exit; end;
  MemSet(it, 0, SizeOf(TMenuItem));

  len := StrLenP(ACaption);
  it^.Caption := MemAlloc(len + 1);
  if it^.Caption <> nil then StrCopyP(it^.Caption, ACaption);

  it^.Checked := False;
  it^.Enabled := True;
  it^.Separator := False;
  it^.Tag := 0;
  it^.Parent := AParent;
  it^.Next := nil;
  it^.Prev := nil;
  it^.FirstChild := nil;
  it^.OnClick := nil;       

  if AParent <> nil then
  begin
    if AParent^.FirstChild = nil then
      AParent^.FirstChild := it
    else
    begin
      last := AParent^.FirstChild;
      while last^.Next <> nil do last := last^.Next;
      last^.Next := it;
      it^.Prev := last;
    end;
  end;

  Result := it;
end;

procedure MenuItem_Free(AItem: PMenuItem);
var
  child, next: PMenuItem;
begin
  if AItem = nil then Exit;
  child := AItem^.FirstChild;
  while child <> nil do
  begin
    next := child^.Next;
    MenuItem_Free(child);
    child := next;
  end;
  if AItem^.Caption <> nil then FreeMem(AItem^.Caption);
  FreeMem(AItem);
end;

function MenuItem_Add(AParent: PMenuItem; const ACaption: PChar): PMenuItem;
begin
  Result := MenuItem_Create(ACaption, AParent);
end;

procedure MenuItem_AddSeparator(AParent: PMenuItem);
var
  it: PMenuItem;
begin
  it := MenuItem_Add(AParent, '');
  if it <> nil then it^.Separator := True;
end;

function MenuItem_Count(AItem: PMenuItem): Integer;
var
  c: PMenuItem;
begin
  Result := 0;
  if AItem = nil then Exit;
  c := AItem^.FirstChild;
  while c <> nil do
  begin
    Inc(Result);
    c := c^.Next;
  end;
end;

function MenuItem_MaxWidth(AItem: PMenuItem): Integer;
var
  c: PMenuItem;
  w: Integer;
begin
  Result := 0;
  if AItem = nil then Exit;
  c := AItem^.FirstChild;
  while c <> nil do
  begin
    if not c^.Separator then
    begin
      w := StrLenP(c^.Caption) * 8;
      if c^.Checked then w := w + 12;
      if w > Result then Result := w;
    end;
    c := c^.Next;
  end;
  if Result < 60 then Result := 60;
end;

function MenuItem_FindByIndex(ARoot: PMenuItem; Index: Integer): PMenuItem;
var
  c: PMenuItem;
  i: Integer;
begin
  Result := nil;
  if ARoot = nil then Exit;
  c := ARoot^.FirstChild; i := 0;
  while c <> nil do
  begin
    if i = Index then begin Result := c; Exit; end;
    Inc(i);
    c := c^.Next;
  end;
end;

function MenuItem_IndexOf(ARoot: PMenuItem; AItem: PMenuItem): Integer;
var
  c: PMenuItem;
begin
  Result := -1;
  if (ARoot = nil) or (AItem = nil) then Exit;
  c := ARoot^.FirstChild; Result := 0;
  while c <> nil do
  begin
    if c = AItem then Exit;
    Inc(Result);
    c := c^.Next;
  end;
  Result := -1;
end;

procedure Menu_DrawString(X, Y: Integer; S: PChar; Color: LongWord);
var
  i, dx: Integer;
  hot: Boolean;
begin
  if S = nil then Exit;
  i := 0; dx := X; hot := False;
  while S[i] <> #0 do
  begin
    if S[i] = '&' then
    begin
      hot := True;
      Inc(i);
      Continue;
    end;
    KChar(dx, Y, S[i], Color);
    if hot then
    begin
      KLineH(dx, Y + 9, 8, Color);
      hot := False;
    end;
    dx := dx + 8;
    Inc(i);
  end;
end;

function Menu_TextWidth(S: PChar): Integer;
var
  i: Integer;
begin
  Result := 0;
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    if S[i] <> '&' then Inc(Result, 8);
    Inc(i);
  end;
end;

{==============================================================================}
{  TMAINMENU                                                                   }
{==============================================================================}

function MainMenu_Create(AParent: PObject; ALeft, ATop, AWidth: Integer): PMainMenu;
var
  mm: PMainMenu;
begin
  mm := MemAlloc(SizeOf(TMainMenu));
  if mm = nil then begin Result := nil; Exit; end;
  MemSet(mm, 0, SizeOf(TMainMenu));

  mm^.ObjectType := otMainMenu;
  mm^.Left := ALeft; mm^.Top := ATop;
  mm^.Width := AWidth; mm^.Height := 24;
  mm^.Visible := True;
  mm^.BarHeight := 24;
  mm^.ItemHeight := 18;
  mm^.Color := $00D0D0D0;
  mm^.SelColor := $000080FF;
  mm^.TextColor := $00000000;
  mm^.AltColor := $00E8E8E8;
  mm^.BorderColor := $00808080;
  mm^.BoxColor := $00FFFFFF;
  mm^.BarCount := 0;
  mm^.ActiveBar := -1;
  mm^.HoverBar := -1;
  mm^.Dropped := False;
  mm^.HoverItem := nil;

  mm^.OnDestroy := @MainMenu_Free;
  if AParent <> nil then Object_AddChild(AParent, PObject(mm));
  Result := mm;
end;

procedure MainMenu_Free(AMainMenu: PMainMenu);
var
  i: Integer;
begin
  if AMainMenu = nil then Exit;
  for i := 0 to AMainMenu^.BarCount - 1 do
  begin
    if AMainMenu^.BarItems[i].Caption <> nil then FreeMem(AMainMenu^.BarItems[i].Caption);
    if AMainMenu^.BarItems[i].Menu <> nil then MenuItem_Free(AMainMenu^.BarItems[i].Menu);
  end;
end;

function MainMenu_AddMenu(AMainMenu: PMainMenu; const ACaption: PChar): PMenuItem;
var
  len: Integer;
  p: PChar;
begin
  Result := nil;
  if AMainMenu = nil then Exit;
  if AMainMenu^.BarCount >= 16 then Exit;

  len := StrLenP(ACaption);
  p := MemAlloc(len + 1);
  if p <> nil then StrCopyP(p, ACaption);
  AMainMenu^.BarItems[AMainMenu^.BarCount].Caption := p;

  Result := MenuItem_Create('', nil);
  AMainMenu^.BarItems[AMainMenu^.BarCount].Menu := Result;
  Inc(AMainMenu^.BarCount);
end;

procedure MM_SetDropState(AMainMenu: PMainMenu; Dropped: Boolean; ABarIndex: Integer);
var dropH: Integer;
begin
  if AMainMenu = nil then Exit;
  AMainMenu^.Dropped := Dropped;
  AMainMenu^.ActiveBar := ABarIndex;

  if Dropped and (ABarIndex >= 0) and (ABarIndex < AMainMenu^.BarCount) then
  begin
    dropH := MenuItem_Count(AMainMenu^.BarItems[ABarIndex].Menu) * AMainMenu^.ItemHeight + 4;
    if dropH < 4 then dropH := 4;
    AMainMenu^.DropHeight := dropH;
    AMainMenu^.Height := AMainMenu^.BarHeight + dropH;

    { Z-order'� en �ste ��kar � BUNU EKLE }
    MoveObjectToFront(PObject(AMainMenu));
  end
  else
  begin
    AMainMenu^.DropHeight := 0;
    AMainMenu^.Height := AMainMenu^.BarHeight;
    AMainMenu^.HoverItem := nil;
  end;
end;


function MM_BarItemWidth(AMainMenu: PMainMenu; Index: Integer): Integer;
var
  w: Integer;
begin
  w := Menu_TextWidth(AMainMenu^.BarItems[Index].Caption) + 16;
  if w < 40 then w := 40;
  Result := w;
end;

procedure MM_DrawDropdown(AMainMenu: PMainMenu; AMenuRoot: PMenuItem; absX, absY: Integer);
var
  dropW, dropH, clientH: Integer;
  c: PMenuItem;
  i, y: Integer;
  rowBack, txtCol: LongWord;
begin
  if (AMenuRoot = nil) or (AMenuRoot^.FirstChild = nil) then Exit;

  dropW := MenuItem_MaxWidth(AMenuRoot) + 24;
  dropH := AMainMenu^.DropHeight;
  clientH := dropH - 4;

  KRect3D(absX, absY, dropW, dropH, False);
  KFill(absX + 2, absY + 2, dropW - 4, dropH - 4, AMainMenu^.BoxColor);

  Clip_Save;
  Clip_Set(absX + 2, absY + 2, absX + dropW - 3, absY + dropH - 3);

  c := AMenuRoot^.FirstChild;
  i := 0;
  while c <> nil do
  begin
    y := absY + 2 + (i * AMainMenu^.ItemHeight);

    if c^.Separator then
    begin
      KLineH(absX + 4, y + 8, dropW - 8, AMainMenu^.BorderColor);
      KLineH(absX + 4, y + 9, dropW - 8, $00FFFFFF);
    end
    else
    begin
      if c = AMainMenu^.HoverItem then
      begin
        rowBack := AMainMenu^.SelColor;
        txtCol := $00FFFFFF;
      end
      else
      begin
        rowBack := AMainMenu^.BoxColor;
        txtCol := AMainMenu^.TextColor;
        if not c^.Enabled then txtCol := $00808080;
      end;

      KFill(absX + 2, y, dropW - 4, AMainMenu^.ItemHeight, rowBack);

      if c^.Checked then
        KChar(absX + 6, y + 4, 'v', txtCol);

      Menu_DrawString(absX + 18, y + 4, c^.Caption, txtCol);

      if c^.FirstChild <> nil then
        KChar(absX + dropW - 14, y + 4, '>', txtCol);
    end;

    Inc(i);
    c := c^.Next;
  end;

  Clip_Restore;
end;

procedure MainMenu_Draw(AMainMenu: PMainMenu; ParentX, ParentY: Integer);
var
  absX, absY, i, x, barW, textX, textY: Integer;
  isActive, isHover: Boolean;
begin
  if AMainMenu = nil then Exit;
  if not AMainMenu^.Visible then Exit;

  absX := ParentX + AMainMenu^.Left;
  absY := ParentY + AMainMenu^.Top;

  KFill(absX, absY, AMainMenu^.Width, AMainMenu^.BarHeight, AMainMenu^.Color);
  KRect3D(absX, absY, AMainMenu^.Width, AMainMenu^.BarHeight, False);

  textY := absY + (AMainMenu^.BarHeight - 8) div 2;
  x := absX + 4;

  for i := 0 to AMainMenu^.BarCount - 1 do
  begin
    barW := MM_BarItemWidth(AMainMenu, i);
    isActive := (i = AMainMenu^.ActiveBar) and AMainMenu^.Dropped;
    isHover := (i = AMainMenu^.HoverBar);

    if isActive then
    begin
      { Aktif tab: basik (icine gomulu) }
      KButton3D(x, absY + 2, barW, AMainMenu^.BarHeight - 4, True, AMainMenu^.AltColor);
      Menu_DrawString(x + 8, textY, AMainMenu^.BarItems[i].Caption, AMainMenu^.TextColor);
    end
    else if isHover then
    begin
      { Hover: SelColor ile dolgu, belirgin }
      KFill(x + 1, absY + 3, barW - 2, AMainMenu^.BarHeight - 6, AMainMenu^.SelColor);
      KRect(x + 1, absY + 3, barW - 2, AMainMenu^.BarHeight - 6, $00404040);
      Menu_DrawString(x + 8, textY, AMainMenu^.BarItems[i].Caption, $00FFFFFF);
    end
    else
    begin
      Menu_DrawString(x + 8, textY, AMainMenu^.BarItems[i].Caption, AMainMenu^.TextColor);
    end;

    x := x + barW;
  end;

  if AMainMenu^.Dropped and (AMainMenu^.ActiveBar >= 0) then
  begin
    x := absX + 4;
    for i := 0 to AMainMenu^.ActiveBar - 1 do
      x := x + MM_BarItemWidth(AMainMenu, i);
    MM_DrawDropdown(AMainMenu, AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu,
                    x, absY + AMainMenu^.BarHeight);
  end;
end;

procedure MainMenu_ProcessKey(AMainMenu: PMainMenu; Key: Word; Shift: Byte);
var
  c: PMenuItem;
  idx: Integer;
begin
  if AMainMenu = nil then Exit;

  if not AMainMenu^.Dropped then
  begin
    if Key = 18 then { Alt }
    begin
      if AMainMenu^.ActiveBar < 0 then
        MM_SetDropState(AMainMenu, True, 0)
      else
        MM_SetDropState(AMainMenu, False, -1);
    end;
    Exit;
  end;

  case Key of
    37: { Left }
      begin
        if AMainMenu^.ActiveBar > 0 then
          MM_SetDropState(AMainMenu, True, AMainMenu^.ActiveBar - 1)
        else
          MM_SetDropState(AMainMenu, True, AMainMenu^.BarCount - 1);
      end;
    39: { Right }
      begin
        if AMainMenu^.ActiveBar < AMainMenu^.BarCount - 1 then
          MM_SetDropState(AMainMenu, True, AMainMenu^.ActiveBar + 1)
        else
          MM_SetDropState(AMainMenu, True, 0);
      end;
    38: { Up }
      begin
        if AMainMenu^.HoverItem = nil then
        begin
          c := AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu^.FirstChild;
          while (c <> nil) and (c^.Separator or not c^.Enabled) do c := c^.Next;
          AMainMenu^.HoverItem := c;
        end
        else
        begin
          idx := MenuItem_IndexOf(AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu, AMainMenu^.HoverItem);
          if idx > 0 then
          begin
            c := MenuItem_FindByIndex(AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu, idx - 1);
            while (c <> nil) and (c^.Separator or not c^.Enabled) do c := c^.Prev;
            AMainMenu^.HoverItem := c;
          end;
        end;
      end;
    40: { Down }
      begin
        if AMainMenu^.HoverItem = nil then
        begin
          c := AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu^.FirstChild;
          while (c <> nil) and (c^.Separator or not c^.Enabled) do c := c^.Next;
          AMainMenu^.HoverItem := c;
        end
        else
        begin
          idx := MenuItem_IndexOf(AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu, AMainMenu^.HoverItem);
          c := MenuItem_FindByIndex(AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu, idx + 1);
          while (c <> nil) and (c^.Separator or not c^.Enabled) do c := c^.Next;
          AMainMenu^.HoverItem := c;
        end;
      end;
    13: { Enter }
      begin
        if AMainMenu^.HoverItem <> nil then
          MM_SetDropState(AMainMenu, False, -1);
      end;
    27: { Escape }
      MM_SetDropState(AMainMenu, False, -1);
  end;
end;

procedure MainMenu_MouseDown(AMainMenu: PMainMenu; X, Y: Integer);
var
  i, x1, barW: Integer;
  relX, relY, idx: Integer;
  c: PMenuItem;
  dropW: Integer;
begin
  if AMainMenu = nil then Exit;

  if Y < AMainMenu^.BarHeight then
  begin
    x1 := 4;
    for i := 0 to AMainMenu^.BarCount - 1 do
    begin
      barW := MM_BarItemWidth(AMainMenu, i);
      if (X >= x1) and (X < x1 + barW) then
      begin
        if AMainMenu^.Dropped and (AMainMenu^.ActiveBar = i) then
          MM_SetDropState(AMainMenu, False, -1)
        else
          MM_SetDropState(AMainMenu, True, i);
        Exit;
      end;
      x1 := x1 + barW;
    end;
    MM_SetDropState(AMainMenu, False, -1);
    Exit;
  end;

  if not AMainMenu^.Dropped then Exit;

  x1 := 4;
  for i := 0 to AMainMenu^.ActiveBar - 1 do
    x1 := x1 + MM_BarItemWidth(AMainMenu, i);

  dropW := MenuItem_MaxWidth(AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu) + 24;

  if (X >= x1) and (X < x1 + dropW) and
     (Y >= AMainMenu^.BarHeight) and (Y < AMainMenu^.BarHeight + AMainMenu^.DropHeight) then
  begin
    relX := X - x1;
    relY := Y - AMainMenu^.BarHeight - 2;
    idx := relY div AMainMenu^.ItemHeight;

    c := MenuItem_FindByIndex(AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu, idx);
    if (c <> nil) and not c^.Separator and c^.Enabled then
    begin
      AMainMenu^.HoverItem := c;
      MM_SetDropState(AMainMenu, False, -1);
      if Assigned(c^.OnClick) then c^.OnClick(c);
    end;
  end
  else
    MM_SetDropState(AMainMenu, False, -1);
end;

procedure MainMenu_MouseMove(AMainMenu: PMainMenu; X, Y: Integer);
var
  i, x1, barW: Integer;
  relY, idx: Integer;
  c: PMenuItem;
  dropW: Integer;
begin
  if AMainMenu = nil then Exit;

  if Y < AMainMenu^.BarHeight then
  begin
    AMainMenu^.HoverBar := -1;
    x1 := 4;
    for i := 0 to AMainMenu^.BarCount - 1 do
    begin
      barW := MM_BarItemWidth(AMainMenu, i);
      if (X >= x1) and (X < x1 + barW) then
      begin
        AMainMenu^.HoverBar := i;
        if AMainMenu^.Dropped and (AMainMenu^.ActiveBar <> i) then
          MM_SetDropState(AMainMenu, True, i);
        Exit;
      end;
      x1 := x1 + barW;
    end;
    Exit;
  end;

  if not AMainMenu^.Dropped then Exit;

  x1 := 4;
  for i := 0 to AMainMenu^.ActiveBar - 1 do
    x1 := x1 + MM_BarItemWidth(AMainMenu, i);

  dropW := MenuItem_MaxWidth(AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu) + 24;

  if (X >= x1) and (X < x1 + dropW) and
     (Y >= AMainMenu^.BarHeight) and (Y < AMainMenu^.BarHeight + AMainMenu^.DropHeight) then
  begin
    relY := Y - AMainMenu^.BarHeight - 2;
    idx := relY div AMainMenu^.ItemHeight;
    c := MenuItem_FindByIndex(AMainMenu^.BarItems[AMainMenu^.ActiveBar].Menu, idx);
    if (c <> nil) and not c^.Separator and c^.Enabled then
      AMainMenu^.HoverItem := c
    else
      AMainMenu^.HoverItem := nil;
  end
  else
    AMainMenu^.HoverItem := nil;
end;

procedure MainMenu_MouseUp(AMainMenu: PMainMenu; X, Y: Integer);
begin
end;

{==============================================================================}
{  TPOPUPMENU                                                                  }
{==============================================================================}

function PopupMenu_Create(AParent: PObject): PPopupMenu;
var
  pm: PPopupMenu;
begin
  pm := MemAlloc(SizeOf(TPopupMenu));
  if pm = nil then begin Result := nil; Exit; end;
  MemSet(pm, 0, SizeOf(TPopupMenu));

  pm^.ObjectType :=otPopupMenu;
  pm^.Left := 0; pm^.Top := 0;
  pm^.Width := 120; pm^.Height := 4;
  pm^.Visible :=False;
  pm^.ItemHeight := 18;
  pm^.MenuWidth := 120;
  pm^.SelColor := $000080FF;
  pm^.TextColor := $00000000;
  pm^.BorderColor := $00808080;
  pm^.BoxColor := $00FFFFFF;
  pm^.HoverItem := nil;

  pm^.Root := MenuItem_Create('', nil);
  pm^.OnDestroy := @PopupMenu_Free;

  { PARENT EKLEME - framework cizim dongusune girsin }
 // if AParent <> nil then Object_AddChild(AParent, PObject(pm));
  Result := pm;
end;

procedure PopupMenu_Free(APopup: PPopupMenu);
begin
  if APopup = nil then Exit;
  if APopup^.Root <> nil then MenuItem_Free(APopup^.Root);
end;

function PopupMenu_AddItem(APopup: PPopupMenu; const ACaption: PChar): PMenuItem;
begin
  Result := nil;
  if APopup = nil then Exit;
  Result := MenuItem_Add(APopup^.Root, ACaption);
end;

procedure PopupMenu_AddSeparator(APopup: PPopupMenu);
begin
  if APopup = nil then Exit;
  MenuItem_AddSeparator(APopup^.Root);
end;



procedure PopupMenu_Show(APopup: PPopupMenu; AX, AY: Integer);
var h: Integer;
begin
  if APopup = nil then Exit;
  APopup^.Left := AX;
  APopup^.Top := AY;
  APopup^.MenuWidth := MenuItem_MaxWidth(APopup^.Root) + 24;
  h := MenuItem_Count(APopup^.Root) * APopup^.ItemHeight + 4;
  if h < 4 then h := 4;
  APopup^.Height := h;
  APopup^.Width := APopup^.MenuWidth;
  APopup^.Visible := True;
  APopup^.HoverItem := nil;

  { Z-order'� en �ste ��kar � BUNU EKLE }
 // MoveObjectToFront(PObject(APopup));
end;



procedure PopupMenu_Hide(APopup: PPopupMenu);
begin
  if APopup = nil then Exit;
  APopup^.Visible := False;
  APopup^.HoverItem := nil;
end;

procedure PopupMenu_Draw(APopup: PPopupMenu; ParentX, ParentY: Integer);
var
  absX, absY, dropW, dropH: Integer;
  c: PMenuItem;
  i, y: Integer;
  rowBack, txtCol: LongWord;
begin
  if APopup = nil then Exit;
  if not APopup^.Visible then Exit;

  absX := ParentX + APopup^.Left;
  absY := ParentY + APopup^.Top;
  dropW := APopup^.MenuWidth;
  dropH := APopup^.Height;

  { 3D cerceve }
  KRect3D(absX, absY, dropW, dropH, False);
  KFill(absX + 2, absY + 2, dropW - 4, dropH - 4, APopup^.BoxColor);

  { Dis cizgiler (3D efekt) }
  KLineH(absX + 1, absY + 1, dropW - 2, $00FFFFFF);
  KLineV(absX + 1, absY + 1, dropH - 2, $00FFFFFF);
  KLineH(absX + 1, absY + dropH - 2, dropW - 2, $00404040);
  KLineV(absX + dropW - 2, absY + 1, dropH - 2, $00404040);

  Clip_Save;
  Clip_Set(absX + 2, absY + 2, absX + dropW - 3, absY + dropH - 3);

  c := APopup^.Root^.FirstChild;
  i := 0;
  while c <> nil do
  begin
    y := absY + 2 + (i * APopup^.ItemHeight);

    if c^.Separator then
    begin
      KLineH(absX + 4, y + 8, dropW - 8, APopup^.BorderColor);
      KLineH(absX + 4, y + 9, dropW - 8, $00FFFFFF);
    end
    else
    begin
      if c = APopup^.HoverItem then
      begin
        rowBack := APopup^.SelColor;
        txtCol := $00FFFFFF;
      end
      else
      begin
        rowBack := APopup^.BoxColor;
        txtCol := APopup^.TextColor;
        if not c^.Enabled then txtCol := $00808080;
      end;

      KFill(absX + 2, y, dropW - 4, APopup^.ItemHeight, rowBack);

      if c^.Checked then
        KChar(absX + 6, y + 4, 'v', txtCol);

      Menu_DrawString(absX + 18, y + 4, c^.Caption, txtCol);

      if c^.FirstChild <> nil then
        KChar(absX + dropW - 14, y + 4, '>', txtCol);
    end;

    Inc(i);
    c := c^.Next;
  end;

  Clip_Restore;
end;

procedure PopupMenu_MouseDown(APopup: PPopupMenu; X, Y: Integer);
var
  idx: Integer;
  c: PMenuItem;
begin
  if APopup = nil then Exit;
  if not APopup^.Visible then Exit;

  if (X < 0) or (X > APopup^.Width) or (Y < 0) or (Y > APopup^.Height) then
  begin
    PopupMenu_Hide(APopup);
    Exit;
  end;

  idx := (Y - 2) div APopup^.ItemHeight;
  c := MenuItem_FindByIndex(APopup^.Root, idx);
  if (c <> nil) and not c^.Separator and c^.Enabled then
  begin
    APopup^.HoverItem := c;
    PopupMenu_Hide(APopup);
    if Assigned(c^.OnClick) then c^.OnClick(c);
  end
  else
    PopupMenu_Hide(APopup);
end;

procedure PopupMenu_MouseMove(APopup: PPopupMenu; X, Y: Integer);
var
  idx: Integer;
  c: PMenuItem;
begin
  if APopup = nil then Exit;
  if not APopup^.Visible then Exit;

  if (X < 0) or (X > APopup^.Width) or (Y < 0) or (Y > APopup^.Height) then
  begin
    APopup^.HoverItem := nil;
    Exit;
  end;

  idx := (Y - 2) div APopup^.ItemHeight;
  c := MenuItem_FindByIndex(APopup^.Root, idx);
  if (c <> nil) and not c^.Separator and c^.Enabled then
    APopup^.HoverItem := c
  else
    APopup^.HoverItem := nil;
end;

procedure PopupMenu_MouseUp(APopup: PPopupMenu; X, Y: Integer);
begin
end;



{==============================================================================}
{  TSPLITTER - IMPLEMENTATION                                                  }
{==============================================================================}


{==============================================================================}
{  TSPLITTER - IMPLEMENTATION                                                  }
{==============================================================================}

function Splitter_Create(AParent: PObject; ALeft, ATop, ASize: Integer; AOrientation: Byte): PSplitter;
var
  sp: PSplitter;
begin
  sp := MemAlloc(SizeOf(TSplitter));
  if sp = nil then begin Result := nil; Exit; end;
  MemSet(sp, 0, SizeOf(TSplitter));

  sp^.ObjectType  := otSplitter;
  sp^.Left        := ALeft;
  sp^.Top         := ATop;
  sp^.Orientation := AOrientation;
  sp^.MinSize     := 20;
  sp^.Dragging    := False;
  sp^.Visible     := True;
  sp^.Color       := $00D4D0C8;
  sp^.GripColor   := $00808080;

  if AOrientation = 1 then
  begin
    { Yatay splitter: yukari/asagi suruklenir, ince kenar Height'tir.
      Genislik (Width), Align=alTop tarafindan cross-axis olarak
      otomatik doldurulacaktir (bkz. Object_Realign). }
    sp^.Width  := 100;
    sp^.Height := ASize;
    sp^.Align  := alTop;
  end
  else
  begin
    { Dikey splitter: sola/saga suruklenir, ince kenar Width'tir.
      Yukseklik (Height), Align=alLeft tarafindan cross-axis olarak
      otomatik doldurulacaktir. }
    sp^.Width  := ASize;
    sp^.Height := 100;
    sp^.Align  := alLeft;
  end;

  sp^.OnDestroy := @Splitter_Free;

  if AParent <> nil then
  begin
    Object_AddChild(AParent, PObject(sp));
    { Yeni eklenen bu align'li nesne yuzunden komsu (ozellikle alClient
      olan) kontrollerin de hemen yeniden dizilmesi gerekir. }
    Object_Realign(AParent);
  end;

  Result := sp;
end;

procedure Splitter_Free(ASplitter: PSplitter);
begin
  { TSplitter ekstra heap tahsisi icermez (Root/liste vb. yok);
    Object_Free zaten kendi bellegini (FreeMem) serbest birakir.
    Bu yalnizca OnDestroy kancasi icin saglanmistir - MainMenu_Free /
    PopupMenu_Free ile ayni desen. }
  if ASplitter = nil then Exit;
end;

procedure Splitter_Draw(ASplitter: PSplitter; ParentX, ParentY: Integer);
var
  absX, absY, cx, cy, i: Integer;
begin
  if ASplitter = nil then Exit;
  if not ASplitter^.Visible then Exit;

  absX := ParentX + ASplitter^.Left;
  absY := ParentY + ASplitter^.Top;

  { Govde }
  KFill(absX, absY, ASplitter^.Width, ASplitter^.Height, ASplitter^.Color);

  { Hafif 3D kenar (kabartma efekti) }
  if ASplitter^.Orientation = 1 then
  begin
    KLineH(absX, absY, ASplitter^.Width, $00FFFFFF);
    KLineH(absX, absY + ASplitter^.Height - 1, ASplitter^.Width, $00808080);
  end
  else
  begin
    KLineV(absX, absY, ASplitter^.Height, $00FFFFFF);
    KLineV(absX + ASplitter^.Width - 1, absY, ASplitter^.Height, $00808080);
  end;

  { Ortadaki tutamak (grip) noktalari - suruklenebilir oldugunu belli eder }
  cx := absX + (ASplitter^.Width  div 2);
  cy := absY + (ASplitter^.Height div 2);

  if ASplitter^.Orientation = 1 then
  begin
    { Yatay splitter: yan yana 3 nokta }
    for i := -1 to 1 do
      KFill(cx + (i * 5) - 1, cy - 1, 2, 2, ASplitter^.GripColor);
  end
  else
  begin
    { Dikey splitter: alt alta 3 nokta }
    for i := -1 to 1 do
      KFill(cx - 1, cy + (i * 5) - 1, 2, 2, ASplitter^.GripColor);
  end;
end;

{ Splitter'in hangi komsuyu boyutlandiracagini bulur: kendisinden HEMEN
  ONCE eklenmis (Previous) kardes nesne - tipik kullanimda bu, splitter'dan
  once olusturulan (alLeft/alTop/alRight/alBottom ile hizalanmis) paneldir. }
function Splitter_GetTarget(ASplitter: PSplitter): PObject;
begin
  Result := nil;
  if ASplitter = nil then Exit;
  Result := ASplitter^.Next;
end;

procedure Splitter_MouseDown(ASplitter: PSplitter; X, Y: Integer);
var
  target: PObject;
begin
  if ASplitter = nil then Exit;
  target := Splitter_GetTarget(ASplitter);
  if target = nil then Exit; { bolunecek komsu nesne yoksa surukleme yapma }

  ASplitter^.Dragging := True;

  if ASplitter^.Orientation = 1 then
  begin
    ASplitter^.StartPos  := Y;              { MUTLAK fare Y'si }
    ASplitter^.StartSize := target^.Height;
  end
  else
  begin
    ASplitter^.StartPos  := X;              { MUTLAK fare X'i }
    ASplitter^.StartSize := target^.Width;
  end;
end;

procedure Splitter_MouseMove(ASplitter: PSplitter; X, Y: Integer);
var
  target: PObject;
  delta, newSize, maxSize, parentW, parentH: Integer;
begin
  if (ASplitter = nil) or (not ASplitter^.Dragging) then Exit;

  target := Splitter_GetTarget(ASplitter);
  if target = nil then Exit;

  { Ust sinir hesabi icin parent'in mevcut client alanini al }
  if ASplitter^.Parent = nil then
  begin
    parentW := target^.Width  + ASplitter^.Width  + 99999;
    parentH := target^.Height + ASplitter^.Height + 99999;
  end
  else if ASplitter^.Parent^.ObjectType = otForm then
  begin
    parentW := PForm(ASplitter^.Parent)^.ClientWidth;
    parentH := PForm(ASplitter^.Parent)^.ClientHeight;
  end
  else
  begin
    parentW := ASplitter^.Parent^.Width;
    parentH := ASplitter^.Parent^.Height;
  end;

  if ASplitter^.Orientation = 1 then
  begin
    delta := Y - ASplitter^.StartPos;

    { Hedef alBottom ile hizaliysa asagi surukleme kucultur (ters yon),
      aksi halde (alTop / varsayilan) asagi surukleme buyutur. }
    if target^.Align = alBottom then
      newSize := ASplitter^.StartSize - delta
    else
      newSize := ASplitter^.StartSize + delta;

    maxSize := parentH - ASplitter^.Height - ASplitter^.MinSize;
    if maxSize < ASplitter^.MinSize then maxSize := ASplitter^.MinSize;

    if newSize < ASplitter^.MinSize then newSize := ASplitter^.MinSize;
    if newSize > maxSize then newSize := maxSize;

    target^.Height := newSize;
  end
  else
  begin
    delta := X - ASplitter^.StartPos;

    { Hedef alRight ile hizaliysa saga surukleme kucultur (ters yon),
      aksi halde (alLeft / varsayilan) saga surukleme buyutur. }
    if target^.Align = alRight then
      newSize := ASplitter^.StartSize - delta
    else
      newSize := ASplitter^.StartSize + delta;

    maxSize := parentW - ASplitter^.Width - ASplitter^.MinSize;
    if maxSize < ASplitter^.MinSize then maxSize := ASplitter^.MinSize;

    if newSize < ASplitter^.MinSize then newSize := ASplitter^.MinSize;
    if newSize > maxSize then newSize := maxSize;

    target^.Width := newSize;
  end;

  { Komsu nesnenin boyutu degisti -> tum kardesleri (ozellikle alClient
    olani) yeniden diz }
  if ASplitter^.Parent <> nil then
    Object_Realign(ASplitter^.Parent);
end;

procedure Splitter_MouseUp(ASplitter: PSplitter; X, Y: Integer);
begin
  if ASplitter = nil then Exit;
  ASplitter^.Dragging := False;
end;

end.

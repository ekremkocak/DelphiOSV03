unit Console;

interface

uses
  SysUtils, Memory, Draw32, Vesa, GUI,GUIControls, Messages;

const
  STD_INPUT_HANDLE   = LongWord(-10);
  STD_OUTPUT_HANDLE  = LongWord(-11);
  STD_ERROR_HANDLE   = LongWord(-12);

  TERM_COLS = 80;
  TERM_ROWS = 25;

type
  PConsole = ^TConsole;
  TConsole = record
    Chars:  array[0..TERM_ROWS-1, 0..TERM_COLS-1] of Char;
    Attrs:  array[0..TERM_ROWS-1, 0..TERM_COLS-1] of Byte;
    CursorX, CursorY: Integer;
    TextColor, BackColor: Byte;
    Form:   PForm;
    Panel:  PPanel;
    ProcID: Integer;
    Active: Boolean;
    { >>> YEN�: Line Editing Buffer <<< }
    LineBuf:   array[0..255] of Char;
    LineLen:   Integer;
    LineReady: Boolean;   // Enter bas�ld� m�?

    { Eski ring buffer (art�k kullan�lm�yor ama kals�n) }
    InBuf:   array[0..255] of Char;
    InHead:  Integer;
    InTail:  Integer;
    InCount: Integer;
  end;

{ --- Kernel API --- }
procedure ConsoleInit;
function  ConsoleCreate(ProcID: Integer): PConsole;
procedure ConsoleFree(C: PConsole);
procedure ConsoleWrite(C: PConsole; const S: PChar);
procedure ConsolePutChar(C: PConsole; Ch: Char);
procedure ConsoleRender(Console: PConsole; AbsX, AbsY: Integer);
procedure ConsoleClear(Console: PConsole);

{ --- Terminal formu --- }
function OpenTerminal(const Title: PChar; ProcID: Integer): PConsole;
procedure TerminalPanelDraw(Sender: PObject; AbsX, AbsY: Integer);

{ --- Syscall icin kernel tarafi --- }
function  ConsoleGetStdHandle(C: PConsole; nStdHandle: LongWord): LongWord;
procedure ConsoleWriteBuf(C: PConsole; Buf: PChar; Count: LongWord);
function  ConsoleWriteHandle(Handle: LongWord; Buf: PChar; Count: LongWord): LongWord;

procedure ConsoleInputPut(C: PConsole; Ch: Char);
function ConsoleInputGet(C: PConsole): Char;
procedure ConsoleInputClear(C: PConsole);

implementation

Uses
  ProcessMgr;

var
  Consoles: array[0..15] of PConsole;
  ConsoleCount: Integer;

{-----------------------------------------------------------------------------}
{ VGA 16 renk -> 32-bit BGR }
{-----------------------------------------------------------------------------}
function VGAColor(c: Byte): LongWord;
begin
  case (c and $0F) of
    0:  Result := $00000000;
    1:  Result := $00AA0000;  // blue
    2:  Result := $0000AA00;  // green
    3:  Result := $00AAAA00;  // cyan
    4:  Result := $000000AA;  // red
    5:  Result := $00AA00AA;  // magenta
    6:  Result := $000055AA;  // brown
    7:  Result := $00AAAAAA;  // light gray
    8:  Result := $00555555;  // dark gray
    9:  Result := $00FF5555;  // light blue
    10: Result := $0000FF00;  // light green
    11: Result := $00FFFF00;  // light cyan
    12: Result := $000000FF;  // light red
    13: Result := $00FF00FF;  // light magenta
    14: Result := $0000FFFF;  // yellow
    15: Result := $00FFFFFF;  // white
  end;
end;

procedure ConsoleInit;
begin
  ConsoleCount := 0;
end;

function ConsoleCreate(ProcID: Integer): PConsole;
var
  C: PConsole;
begin
  Result := nil;
  if ConsoleCount >= 16 then Exit;
  C := PConsole(MemAlloc(SizeOf(TConsole)));
  MemSet(C, 0, SizeOf(TConsole));
  C^.ProcID    := ProcID;
  C^.TextColor := 7;
  C^.BackColor := 0;
  C^.Active    := True;
  C^.InHead  := 0;
  C^.InTail  := 0;
  C^.InCount := 0;
  C^.LineLen   := 0;
  C^.LineReady := False;
  Consoles[ConsoleCount] := C;
  Inc(ConsoleCount);
  Result := C;
end;

procedure ConsoleInputPut(C: PConsole; Ch: Char);
begin
  if C = nil then Exit;
  if C^.InCount >= 256 then Exit;  // Buffer dolu
  C^.InBuf[C^.InHead and 255] := Ch;
  Inc(C^.InHead);
  Inc(C^.InCount);
end;

function ConsoleInputGet(C: PConsole): Char;
begin
  Result := #0;
  if C = nil then Exit;
  if C^.InCount <= 0 then Exit;     // Buffer bo�
  Result := C^.InBuf[C^.InTail and 255];
  Inc(C^.InTail);
  Dec(C^.InCount);
end;

procedure ConsoleInputClear(C: PConsole);
begin
  if C = nil then Exit;
  C^.InHead  := 0;
  C^.InTail  := 0;
  C^.InCount := 0;
end;

procedure ConsoleFree(C: PConsole);
var
  i: Integer;
begin
  if C = nil then Exit;
  if C^.Form <> nil then C^.Form^.Control := nil;
  for i := 0 to ConsoleCount-1 do
    if Consoles[i] = C then
    begin
      Consoles[i] := Consoles[ConsoleCount-1];
      Dec(ConsoleCount);
      Break;
    end;

  ProcessKillByPID(C^.ProcID);
  FreeMem(C);
end;


procedure ConsoleClear(Console: PConsole);
var
  r, c: Integer;
begin
  if Console = nil then Exit;
  for r := 0 to TERM_ROWS-1 do
    for c := 0 to TERM_COLS-1 do
    begin
      Console^.Chars[r, c] := ' ';
      Console^.Attrs[r, c] := (Console^.BackColor shl 4) or Console^.TextColor;
    end;
  Console^.CursorX := 0;
  Console^.CursorY := 0;
  if Console^.Form <> nil then RelayoutForm(Console^.Form);
end;


procedure ConsoleScroll(Console: PConsole);
var
  r, c: Integer;
begin
  for r := 0 to TERM_ROWS-2 do
    for c := 0 to TERM_COLS-1 do
    begin
      Console^.Chars[r, c] := Console^.Chars[r+1, c];
      Console^.Attrs[r, c] := Console^.Attrs[r+1, c];
    end;
  for c := 0 to TERM_COLS-1 do
  begin
    Console^.Chars[TERM_ROWS-1, c] := ' ';
    Console^.Attrs[TERM_ROWS-1, c] := (Console^.BackColor shl 4) or Console^.TextColor;
  end;
  Console^.CursorY := TERM_ROWS-1;
end;

procedure ConsolePutChar(C: PConsole; Ch: Char);
begin
  if C = nil then Exit;
  case Ch of
    #10: begin C^.CursorX := 0; Inc(C^.CursorY); end;
    #13: begin C^.CursorX := 0; end;
    #8:  begin if C^.CursorX > 0 then Dec(C^.CursorX); C^.Chars[C^.CursorY, C^.CursorX] := ' '; end;
  else
    if C^.CursorX >= TERM_COLS then
    begin
      C^.CursorX := 0;
      Inc(C^.CursorY);
    end;
    if C^.CursorY >= TERM_ROWS then
      ConsoleScroll(C);
    C^.Chars[C^.CursorY, C^.CursorX] := Ch;
    C^.Attrs[C^.CursorY, C^.CursorX] := (C^.BackColor shl 4) or C^.TextColor;
    Inc(C^.CursorX);
  end;
end;

procedure ConsoleWrite(C: PConsole; const S: PChar);
var
  i: Integer;
begin
  if (C = nil) or (S = nil) then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    ConsolePutChar(C, S[i]);
    Inc(i);
  end;
  if C^.Form <> nil then RelayoutForm(C^.Form);
end;

{-----------------------------------------------------------------------------}
{ Terminal cizimi - Draw32 karakter fonksiyonunuzu kullanin                   }
{ FONT_W ve FONT_H sabitleriniz olmali (ornegin 8x16)                        }
{-----------------------------------------------------------------------------}
procedure ConsoleRender(Console: PConsole; AbsX, AbsY: Integer);
var
  r, c: Integer;
  ch: Char;
  s: array[0..1] of Char;
  fg, bg: LongWord;
begin
  if Console = nil then Exit;
  KFill(AbsX, AbsY, TERM_COLS * FONT_W, TERM_ROWS * FONT_H, VGAColor(Console^.BackColor));

  s[1] := #0;
  for r := 0 to TERM_ROWS-1 do
    for c := 0 to TERM_COLS-1 do
    begin
      ch := Console^.Chars[r, c];
      if ch = #0 then ch := ' ';
      s[0] := ch;
      fg := VGAColor(Console^.Attrs[r, c] and $0F);
      bg := VGAColor(Console^.Attrs[r, c] shr 4);
      { Arka plan karakteri }
      KFill(AbsX + c * FONT_W, AbsY + r * FONT_H, FONT_W, FONT_H, bg);
      { Karakter - KStr varsayiliyor (Draw32'de tek satir string cizen) }
      KStr(AbsX + c * FONT_W, AbsY + r * FONT_H, @s[0], fg);
    end;

  { Cursor (basit blok) }
  KFill(AbsX + Console^.CursorX * FONT_W, AbsY + Console^.CursorY * FONT_H,
        FONT_W, FONT_H, $00FFFFFF);
end;

{-----------------------------------------------------------------------------}
{ Terminal Formu                                                              }
{-----------------------------------------------------------------------------}
procedure TerminalPanelDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  F: PForm;
  C: PConsole;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  C := PConsole(F^.Control);
  if C <> nil then ConsoleRender(C, AbsX, AbsY);
end;

procedure TerminalDestroy(Sender: PObject);
var
  F: PForm;
begin
  F := PForm(Sender);
  if F <> nil then ConsoleFree(PConsole(F^.Control));
end;


procedure TerminalKeyDown(Sender: PForm; Key: Word);
var
  C: PConsole;
begin
  C := PConsole(Sender^.Control);
  if C = nil then Exit;

  case Key of
    8:  { Backspace }
    begin
      if C^.LineLen > 0 then
      begin
        Dec(C^.LineLen);
        { Ekrandan da sil (echo geri al) }
        if C^.CursorX > 0 then
          Dec(C^.CursorX)
        else if C^.CursorY > 0 then
        begin
          Dec(C^.CursorY);
          C^.CursorX := TERM_COLS - 1;
        end;
        C^.Chars[C^.CursorY, C^.CursorX] := ' ';
        C^.Attrs[C^.CursorY, C^.CursorX] := (C^.BackColor shl 4) or C^.TextColor;
        if C^.Form <> nil then RelayoutForm(C^.Form);
      end;
    end;

    13: { Enter }
    begin
      if C^.LineLen < 255 then
      begin
        C^.LineBuf[C^.LineLen] := #13;   // CR koy
        Inc(C^.LineLen);
      end;
      C^.LineReady := True;               // SATIR HAZIR!
      ConsolePutChar(C, #10);             // Ekrana LF (yeni sat�r)
    end;

    27: { Escape � sat�r� iptal et }
    begin
      C^.LineLen := 0;
      C^.LineReady := False;
      ConsoleWrite(C, '^C'#13#10'>');
    end;

  else
    { Printable ASCII (32..126) }
    if ((Key >= $100 + 32) and (Key <= $100 + 126)) and (C^.LineLen < 255) then
    begin
      C^.LineBuf[C^.LineLen] := Char(Key);
      Inc(C^.LineLen);
      ConsolePutChar(C, Char(Key));      // Echo
    end;
  end;
end;


function OpenTerminal(const Title: PChar; ProcID: Integer): PConsole;  // <-- void � PConsole
var
  F: PForm;
  C: PConsole;
begin
  C := ConsoleCreate(ProcID);
  if C = nil then begin Result := nil; Exit; end;

  F := CreateForm(Title, 120, 80, 660, 420);
  F^.BorderStyle := bsWindow;
  F^.ShowSysButtons := True;
  F^.Color := clBtnFace;
  F^.Control := PObject(C);
  F^.BindDestroy(@TerminalDestroy);
  F^.BindKeyDown(@TerminalKeyDown);
  C^.Form := F;

  C^.Panel := CreatePanel(PObject(F), 0, 0, 0, 0, alClient);
  C^.Panel^.Color := $00000000;
  C^.Panel^.BorderWidth := 1;
  C^.Panel^.BindPaint(@TerminalPanelDraw);

  ConsoleWrite(C, 'Kernel OS Console'#13#10'>' );

  Result := C;
end;


{-----------------------------------------------------------------------------}
{ StdHandle API (Syscall tarafindan cagr�l�r)                                 }
{-----------------------------------------------------------------------------}
function ConsoleGetStdHandle(C: PConsole; nStdHandle: LongWord): LongWord;
begin
  Result := 0;
  if C = nil then Exit;
  case nStdHandle of
    STD_INPUT_HANDLE:  Result := 1;
    STD_OUTPUT_HANDLE: Result := 2;
    STD_ERROR_HANDLE:  Result := 3;
  end;
end;


procedure ConsoleWriteBuf(C: PConsole; Buf: PChar; Count: LongWord);
var
  i: Integer;
begin
  if (C = nil) or (Buf = nil) then Exit;
  for i := 0 to Integer(Count) - 1 do
    ConsolePutChar(C, Buf[i]);
  if C^.Form <> nil then RelayoutForm(C^.Form);
end;

function ConsoleWriteHandle(Handle: LongWord; Buf: PChar;
                            Count: LongWord): LongWord;
var
  i: Integer;
  C: PConsole;
begin
  Result := 0;
  if Buf = nil then Exit;

  { Handle değeri yerine şimdilik ilk aktif console'u kullan.
    İleride: Handle → PProcess → PConsole eşlemesi yapılabilir. }
  C := nil;

  { 1. Önce ConsoleCount > 0 kontrolü }
  if ConsoleCount = 0 then Exit;

  { 2. Handle'a göre console bul (ilerisi için hazır) }
  { Handle: STD_OUTPUT_HANDLE = LongWord(-11),
             STD_ERROR_HANDLE  = LongWord(-12)
    Şimdilik ilk console'u kullan }
  C := Consoles[0];

  if C = nil then Exit;

  { 3. Karakterleri yaz }
  for i := 0 to Integer(Count) - 1 do
    ConsolePutChar(C, Buf[i]);

  Result := Count;

  { 4. Ekranı güncelle }
  if C^.Form <> nil then
    RelayoutForm(C^.Form);
end;

end.
{ =========================================================
  DLLLoader.pas — DLL Loader & Import Resolution
  
  Özellikler:
  - DLL yükleme (FAT32'den)
  - Export table parse
  - Import table resolution (EXE → DLL)
  - Shared DLL (birden fazla process kullanabilir)
  - GetProcAddress
  - LoadLibrary / FreeLibrary
  ========================================================= }
Unit DLLLoader;
 interface

 Uses
   SysUtils,Fat32,Memory,Vesa,Console,Messages;

const
  MAX_DLLS        = 8;


const
  MAX_EXPORTS   = 256;
  MAX_RESOURCES = 128;
  MAX_ICONS     = 32;
  MAX_BITMAPS   = 32;
  MAX_TEXTS     = 64;
  MAX_CURSORS   = 16;

  // Resource types
  RT_CURSOR       = 1;
  RT_BITMAP       = 2;
  RT_ICON         = 3;
  RT_MENU         = 4;
  RT_DIALOG       = 5;
  RT_STRING       = 6;
  RT_FONTDIR      = 7;
  RT_FONT         = 8;
  RT_ACCELERATOR  = 9;
  RT_RCDATA       = 10;
  RT_MESSAGETABLE = 11;
  RT_GROUP_CURSOR = 12;
  RT_GROUP_ICON   = 14;
  RT_VERSION      = 16;
  RT_MANIFEST     = 24;


type
  PExportEntry = ^TExportEntry;
  TExportEntry = record
    Name:     array[0..63] of Char;
    Ordinal:  Word;
    Address:  LongWord;          // DLL içindeki gerçek adres
  end;

 type
  // IMAGE_RESOURCE_DIRECTORY
  PResDir = ^TResDir;
  TResDir = packed record
    Characteristics:  LongWord;
    TimeDateStamp:    LongWord;
    MajorVersion:     Word;
    MinorVersion:     Word;
    NumberOfNamedEntries: Word;
    NumberOfIdEntries:    Word;
    // Followed by entries
  end;

  // IMAGE_RESOURCE_DIRECTORY_ENTRY
  PResDirEntry = ^TResDirEntry;
  TResDirEntry = packed record
    NameOrID:    LongWord;   // High bit=1 → name RVA, else ID
    OffsetOrDir: LongWord;   // High bit=1 → subdirectory, else data leaf
  end;

  // IMAGE_RESOURCE_DATA_ENTRY
  PResDataEntry = ^TResDataEntry;
  TResDataEntry = packed record
    DataRVA:  LongWord;
    Size:     LongWord;
    CodePage: LongWord;
    Reserved: LongWord;
  end;

  // Icon data
  PIconData = ^TIconData;
  TIconData = record
    ID:        Integer;
    Width:     Integer;
    Height:    Integer;
    BitCount:  Integer;
    DataPtr:   LongWord;
    DataSize:  LongWord;
  end;

  // Bitmap data
  PBitmapData = ^TBitmapData;
  TBitmapData = record
    ID:        Integer;
    Width:     Integer;
    Height:    Integer;
    BitCount:  Integer;
    DataPtr:   LongWord;
    DataSize:  LongWord;
    Pixels:    Pointer;    // Decoded pixel data
  end;

  // String/Text data
  PTextData = ^TTextData;
  TTextData = record
    ID:        Integer;
    BlockID:   Integer;    // String table block (ID div 16 + 1)
    Text:      array[0..255] of Char;
  end;

  // Cursor data
  PCursorData = ^TCursorData;
  TCursorData = record
    ID:        Integer;
    Width:     Integer;
    Height:    Integer;
    HotspotX:  Integer;
    HotspotY:  Integer;
    DataPtr:   LongWord;
    DataSize:  LongWord;
  end;


  
  PResourceEntry = ^TResourceEntry;
  TResourceEntry = record
    ResType:   Integer;
    ResID:     Integer;
    ResName:   array[0..31] of Char;
    LangID:    Word;
    DataPtr:   LongWord;   // Pointer to raw data in memory
    DataSize:  LongWord;
  end;

  PDLLInfo = ^TDLLInfo;
  TDLLInfo = record
    Loaded:      Boolean;
    Name:        array[0..63] of Char;
    BaseAddr:    LongWord;
    ImageSize:   LongWord;
    RefCount:    Integer;
    RawFileAddr: LongWord;
    RawFileSize: LongWord;

    FnExports:     array[0..MAX_EXPORTS-1] of TExportEntry;
    ExportCount:   Integer;

    // Resources
    Resources:    array[0..MAX_RESOURCES-1] of TResourceEntry;
    ResourceCount: Integer;

    // Parsed resources
    Icons:        array[0..MAX_ICONS-1] of TIconData;
    IconCount:    Integer;

    Bitmaps:      array[0..MAX_BITMAPS-1] of TBitmapData;
    BitmapCount:  Integer;

    Texts:        array[0..MAX_TEXTS-1] of TTextData;
    TextCount:    Integer;

    Cursors:      array[0..MAX_CURSORS-1] of TCursorData;
    CursorCount:  Integer;


  end;

var
  DLLList:   array[0..MAX_DLLS-1] of TDLLInfo;
  DLLCount:  Integer;

// API
function LoadLibrary(DLLName: PChar): Integer; forward;
procedure FreeLibrary(DLLIndex: Integer);
function GetProcAddress(DLLIndex: Integer; ProcName: PChar): LongWord; forward;
function ResolveImports(ExeBase: LongWord): Boolean;

procedure DrawIcon(DLL: PDLLInfo; ID, X, Y: Integer);

procedure WalkResDir(BaseAddr: LongWord;
                     ResSecRVA: LongWord;
                     DirOffset: LongWord;
                     Level: Integer;
                     ResType: Integer;
                     ResID: Integer;
                     LangID: Word;
                     ResName: PChar;
                     DLL: PDLLInfo);

procedure DLLLoader_Init;

implementation





//=============================================================================
// PE Structures
//=============================================================================

type
  // IMAGE_DOS_HEADER
  PDosHeader = ^TDosHeader;
  TDosHeader = packed record
    e_magic: Word;                     { Magic number                     }
      e_cblp: Word;                      { Bytes on last page of file       }
      e_cp: Word;                        { Pages in file                    }
      e_crlc: Word;                      { Relocations                      }
      e_cparhdr: Word;                   { Size of header in paragraphs     }
      e_minalloc: Word;                  { Minimum extra paragraphs needed  }
      e_maxalloc: Word;                  { Maximum extra paragraphs needed  }
      e_ss: Word;                        { Initial (relative) SS value      }
      e_sp: Word;                        { Initial SP value                 }
      e_csum: Word;                      { Checksum                         }
      e_ip: Word;                        { Initial IP value                 }
      e_cs: Word;                        { Initial (relative) CS value      }
      e_lfarlc: Word;                    { File address of relocation table }
      e_ovno: Word;                      { Overlay number                   }
      e_res: array [0..3] of Word;       { Reserved words                   }
      e_oemid: Word;                     { OEM identifier (for e_oeminfo)   }
      e_oeminfo: Word;                   { OEM information; e_oemid specific}
      e_res2: array [0..9] of Word;      { Reserved words                   }
      e_lfanew: LongInt;                  { File address of new exe header   }
  end;

  // IMAGE_FILE_HEADER
  PFileHeader = ^TFileHeader;
  TFileHeader = packed record
    Signature:       LongWord;   // PE\0\0
    Machine:         Word;
    NumberOfSections: Word;
    TimeDateStamp:   LongWord;
    PointerToSymbolTable: LongWord;
    NumberOfSymbols: LongWord;
    SizeOfOptionalHeader: Word;
    Characteristics: Word;
  end;

  // IMAGE_OPTIONAL_HEADER32
  POptHeader = ^TOptHeader;
  TOptHeader = packed record
    Magic: Word;
    MajorLinkerVersion: Byte;
    MinorLinkerVersion: Byte;
    SizeOfCode: LongWord;
    SizeOfInitializedData: LongWord;
    SizeOfUninitializedData: LongWord;
    AddressOfEntryPoint: LongWord;
    BaseOfCode: LongWord;
    BaseOfData: LongWord;
    ImageBase: LongWord;
    SectionAlignment: LongWord;
    FileAlignment: LongWord;
    MajorOperatingSystemVersion: Word;
    MinorOperatingSystemVersion: Word;
    MajorImageVersion: Word;
    MinorImageVersion: Word;
    MajorSubsystemVersion: Word;
    MinorSubsystemVersion: Word;
    Win32VersionValue: LongWord;
    SizeOfImage: LongWord;
    SizeOfHeaders: LongWord;
    CheckSum: LongWord;
    Subsystem: Word;
    DllCharacteristics: Word;
    SizeOfStackReserve: LongWord;
    SizeOfStackCommit: LongWord;
    SizeOfHeapReserve: LongWord;
    SizeOfHeapCommit: LongWord;
    LoaderFlags: LongWord;
    NumberOfRvaAndSizes: LongWord;

    DataDirs: array[0..15] of packed record
      VirtualAddress: LongWord;
      Size: LongWord;
    end;
  end;

  // IMAGE_SECTION_HEADER
  PSectionHeader = ^TSectionHeader;
  TSectionHeader = packed record
    Name:             array[0..7] of Char;
    VirtualSize:      LongWord;
    VirtualAddress:   LongWord;
    SizeOfRawData:    LongWord;
    PointerToRawData: LongWord;
    Pad:              array[0..11] of Byte;
    Characteristics:  LongWord;
  end;

  // IMAGE_EXPORT_DIRECTORY
  PExportDir = ^TExportDir;
  TExportDir = packed record
    Characteristics:  LongWord;
    TimeDateStamp:    LongWord;
    MajorVersion:     Word;
    MinorVersion:     Word;
    Name:             LongWord;  // RVA to DLL name
    Base:             LongWord;  // Ordinal base
    NumberOfFunctions: LongWord;
    NumberOfNames:    LongWord;
    AddressOfFunctions: LongWord;  // RVA to function addresses
    AddressOfNames:   LongWord;    // RVA to function names
    AddressOfNameOrdinals: LongWord; // RVA to ordinals
  end;

  // IMAGE_IMPORT_DESCRIPTOR
  PImportDesc = ^TImportDesc;
  TImportDesc = packed record
    OriginalFirstThunk: LongWord;  // RVA to INT (Import Name Table)
    TimeDateStamp:      LongWord;
    ForwarderChain:     LongWord;
    Name:               LongWord;  // RVA to DLL name
    FirstThunk:         LongWord;  // RVA to IAT (Import Address Table)
  end;

   // BITMAPINFOHEADER
  PBmpInfoHdr = ^TBmpInfoHdr;
  TBmpInfoHdr = packed record
    biSize:          LongWord;
    biWidth:         LongInt;
    biHeight:        LongInt;
    biPlanes:        Word;
    biBitCount:      Word;
    biCompression:   LongWord;
    biSizeImage:     LongWord;
    biXPelsPerMeter: LongInt;
    biYPelsPerMeter: LongInt;
    biClrUsed:       LongWord;
    biClrImportant:  LongWord;
  end;

  // GRPICONDIR (RT_GROUP_ICON)
  PGrpIconDir = ^TGrpIconDir;
  TGrpIconDir = packed record
    Reserved: Word;
    ResType:  Word;   // 1 = icon
    Count:    Word;
  end;

  PGrpIconDirEntry = ^TGrpIconDirEntry;
  TGrpIconDirEntry = packed record
    Width:      Byte;
    Height:     Byte;
    ColorCount: Byte;
    Reserved:   Byte;
    Planes:     Word;
    BitCount:   Word;
    BytesInRes: LongWord;
    ID:         Word;   // RT_ICON resource ID
  end;


//=============================================================================
// DLL PE Loader
//=============================================================================

function StrCmpI(s1, s2: PChar): Boolean;
var i: Integer; c1, c2: Char;
begin
  Result := False;
  if (s1 = nil) or (s2 = nil) then Exit;
  i := 0;
  while (s1[i] <> #0) and (s2[i] <> #0) do
  begin
    c1 := s1[i];
    c2 := s2[i];
    
    // To uppercase
    if (c1 >= 'a') and (c1 <= 'z') then
      c1 := Chr(Ord(c1) - 32);
    if (c2 >= 'a') and (c2 <= 'z') then
      c2 := Chr(Ord(c2) - 32);
    
    if c1 <> c2 then Exit;
    Inc(i);
  end;
  Result := (s1[i] = s2[i]);
end;

function AllocDLLSlot: Integer;
var
  i: Integer;
begin
  Result := -1;
  i := 0;
  while i < MAX_DLLS do
  begin
    if not DLLList[i].Loaded then
    begin
      Result := i;
      Exit;
    end;
    Inc(i);
  end;
end;

function StrEqual(S1, S2: PChar): Boolean;
var
  i: Integer;
begin
  Result := False;
  if (S1 = nil) or (S2 = nil) then Exit;
  
  i := 0;
  while (S1[i] <> #0) or (S2[i] <> #0) do
  begin
    if S1[i] <> S2[i] then Exit;
    Inc(i);
  end;
  
  Result := True;
end;

function FindDLL(Name: PChar): Integer;
var
  i: Integer;
begin
  Result := -1;
  i := 0;
  while i < MAX_DLLS do
  begin
    if DLLList[i].Loaded and StrEqual(@DLLList[i].Name[0], Name) then
    begin
      Result := i;
      Exit;
    end;
    Inc(i);
  end;
end;


procedure ParseIconResource(DLL: PDLLInfo; Res: PResourceEntry);
var
  bmpHdr: PBmpInfoHdr;
  icon:   PIconData;
begin
  if DLL^.IconCount >= MAX_ICONS then Exit;
  if Res^.DataSize < SizeOf(TBmpInfoHdr) then Exit;

  icon   := @DLL^.Icons[DLL^.IconCount];
  bmpHdr := PBmpInfoHdr(Res^.DataPtr);

  icon^.ID       := Res^.ResID;
  icon^.Width    := bmpHdr^.biWidth;
  icon^.Height   := Abs(bmpHdr^.biHeight) div 2;  // Icon = bitmap + mask
  icon^.BitCount := bmpHdr^.biBitCount;
  icon^.DataPtr  := Res^.DataPtr;
  icon^.DataSize := Res^.DataSize;

  Inc(DLL^.IconCount);
end;

//=============================================================================
// Bitmap Parse
//=============================================================================

procedure ParseBitmapResource(DLL: PDLLInfo; Res: PResourceEntry);
var
  bmpHdr: PBmpInfoHdr;
  bmp:    PBitmapData;
begin
  if DLL^.BitmapCount >= MAX_BITMAPS then Exit;
  if Res^.DataSize < SizeOf(TBmpInfoHdr) then Exit;

  bmp    := @DLL^.Bitmaps[DLL^.BitmapCount];
  bmpHdr := PBmpInfoHdr(Res^.DataPtr);

  bmp^.ID       := Res^.ResID;
  bmp^.Width    := bmpHdr^.biWidth;
  bmp^.Height   := Abs(bmpHdr^.biHeight);
  bmp^.BitCount := bmpHdr^.biBitCount;
  bmp^.DataPtr  := Res^.DataPtr;
  bmp^.DataSize := Res^.DataSize;
  bmp^.Pixels   := nil;   // Lazy decode

  Inc(DLL^.BitmapCount);
end;

//=============================================================================
// String Table Parse
//=============================================================================

procedure ParseStringResource(DLL: PDLLInfo; Res: PResourceEntry);
var
  p:       PWord;
  strLen:  Word;
  blockID: Integer;
  strID:   Integer;
  idx:     Integer;
  j:       Integer;
  txt:     PTextData;
begin
  if DLL^.TextCount >= MAX_TEXTS then Exit;

  // String block: ResID = (StringID div 16) + 1
  // Block içinde 16 string var
  blockID := Res^.ResID;
  strID   := (blockID - 1) * 16;

  p := PWord(Res^.DataPtr);

  idx := 0;
  while idx < 16 do
  begin
    if DLL^.TextCount >= MAX_TEXTS then Break;

    strLen := p^;
    Inc(p);

    if strLen > 0 then
    begin
      txt := @DLL^.Texts[DLL^.TextCount];
      MemSet(txt, 0, SizeOf(TTextData));

      txt^.ID      := strID + idx;
      txt^.BlockID := blockID;

      // UTF-16 → ASCII (basit)
      j := 0;
      while (j < Integer(strLen)) and (j < 255) do
      begin
        txt^.Text[j] := Char(PWord(LongWord(p) + LongWord(j) * 2)^);
        Inc(j);
      end;
      txt^.Text[j] := #0;

      Inc(DLL^.TextCount);

      // p'yi strLen word ilerlet
      p := PWord(LongWord(p) + LongWord(strLen) * 2);
    end;

    Inc(idx);
  end;
end;

//=============================================================================
// Cursor Parse
//=============================================================================

procedure ParseCursorResource(DLL: PDLLInfo; Res: PResourceEntry);
var
  cur:    PCursorData;
  bmpHdr: PBmpInfoHdr;
begin
  if DLL^.CursorCount >= MAX_CURSORS then Exit;
  if Res^.DataSize < 4 then Exit;

  cur := @DLL^.Cursors[DLL^.CursorCount];

  // Cursor resource starts with hotspot
  cur^.ID       := Res^.ResID;
  cur^.HotspotX := PWord(Res^.DataPtr)^;
  cur^.HotspotY := PWord(Res^.DataPtr + 2)^;
  cur^.DataPtr  := Res^.DataPtr + 4;
  cur^.DataSize := Res^.DataSize - 4;

  // Bitmap header
  bmpHdr := PBmpInfoHdr(cur^.DataPtr);
  if Res^.DataSize >= SizeOf(TBmpInfoHdr) + 4 then
  begin
    cur^.Width  := bmpHdr^.biWidth;
    cur^.Height := Abs(bmpHdr^.biHeight) div 2;
  end;

  Inc(DLL^.CursorCount);
end;


procedure WalkResDir(BaseAddr: LongWord;
                     ResSecRVA: LongWord;
                     DirOffset: LongWord;
                     Level: Integer;
                     ResType: Integer;
                     ResID: Integer;
                     LangID: Word;
                     ResName: PChar;
                     DLL: PDLLInfo);
var
  dir:       PResDir;
  entry:     PResDirEntry;
  i:         Integer;
  total:     Integer;
  nameOrID:  LongWord;
  subOffset: LongWord;
  isDir:     Boolean;
  curType:   Integer;
  curID:     Integer;
  curLang:   Word;
  curName:   array[0..31] of Char;
  dataEntry: PResDataEntry;
  resEntry:  PResourceEntry;
  namePtr:   PWord;
  nameLen:   Integer;
  j:         Integer;
  nameAddr:  LongWord;
  wchar:     Word;
begin
  dir := PResDir(BaseAddr + ResSecRVA + DirOffset);

  total := dir^.NumberOfNamedEntries + dir^.NumberOfIdEntries;

  entry := PResDirEntry(LongWord(dir) + SizeOf(TResDir));

  i := 0;
  while i < total do
  begin
    nameOrID  := entry^.NameOrID;
    subOffset := entry^.OffsetOrDir;
    isDir     := (subOffset and $80000000) <> 0;
    subOffset := subOffset and $7FFFFFFF;

    // Level 0: type, Level 1: ID, Level 2: language
    curType := ResType;
    curID   := ResID;
    curLang := LangID;
    
    // ResName'i initialize et
    MemSet(@curName[0], 0, SizeOf(curName));
    if ResName <> nil then
      StrCopy(@curName[0], ResName);

    if Level = 0 then
    begin
      // Type level
      if (nameOrID and $80000000) <> 0 then
      begin
        // Named type (named bitir)
        curType := -1;
        
        // Type ad�n� oku (UTF-16)
        nameAddr := BaseAddr + ResSecRVA + (nameOrID and $7FFFFFFF);
        namePtr := PWord(nameAddr);
        nameLen := namePtr^;  // Character count
        
        j := 0;
        Inc(namePtr);  // Skip length word
        while (j < nameLen) and (j < 31) do
        begin
          wchar := namePtr^;
          if wchar = 0 then Break;
          curName[j] := Char(wchar and $FF);  // UTF-16 -> ASCII
          Inc(namePtr);
          Inc(j);
        end;
        curName[j] := #0;
      end
      else
      begin
        // Numeric type
        curType := Integer(nameOrID and $FFFF);
      end;
    end
    else if Level = 1 then
    begin
      // ID/Name level
      if (nameOrID and $80000000) <> 0 then
      begin
        // Named resource - resName ��k
        nameAddr := BaseAddr + ResSecRVA + (nameOrID and $7FFFFFFF);
        namePtr := PWord(nameAddr);
        nameLen := namePtr^;
        
        // UTF-16 string'i ASCII'ye �evir
        j := 0;
        Inc(namePtr);
        while (j < nameLen) and (j < 31) do
        begin
          wchar := namePtr^;
          if wchar = 0 then Break;
          curName[j] := Char(wchar and $FF);
          Inc(namePtr);
          Inc(j);
        end;
        curName[j] := #0;
        
        curID := -1;  // Named olarak i�aretle
      end
      else
      begin
        // Numeric ID
        curID := Integer(nameOrID and $FFFF);
      end;
    end
    else if Level = 2 then
    begin
      // Language level
      curLang := Word(nameOrID and $FFFF);
    end;

    if isDir then
    begin
      // Recurse into subdirectory
      WalkResDir(BaseAddr, ResSecRVA, subOffset,
                 Level + 1, curType, curID, curLang, 
                 @curName[0], DLL);
    end
    else
    begin
      // Data leaf - resource burada kaydediliyor
      if DLL^.ResourceCount < MAX_RESOURCES then
      begin
        dataEntry := PResDataEntry(BaseAddr + ResSecRVA + subOffset);

        resEntry := @DLL^.Resources[DLL^.ResourceCount];
        MemSet(resEntry, 0, SizeOf(TResourceEntry));

        resEntry^.ResType  := curType;
        resEntry^.ResID    := curID;
        resEntry^.LangID   := curLang;
        resEntry^.DataPtr  := BaseAddr + dataEntry^.DataRVA;
        resEntry^.DataSize := dataEntry^.Size;
        
        // ? ResName'i set et
        StrCopy(@resEntry^.ResName[0], @curName[0]);

        Inc(DLL^.ResourceCount);

        // Type'a g�re parse et
        case curType of
          RT_ICON:begin
              DebugPrint(@resEntry^.ResName[0]);
              DebugPrint('�con');
             ParseIconResource(DLL, resEntry);
          end;
          RT_BITMAP:  ParseBitmapResource(DLL, resEntry);
          RT_STRING:  ParseStringResource(DLL, resEntry);
          RT_CURSOR:  ParseCursorResource(DLL, resEntry);
          RT_RCDATA:  begin
              DebugPrint('RT_RCDATA found:');
              DebugPrint(@resEntry^.ResName[0]);
             // DebugPrint(IntToPchar(resEntry^.ResID));
             // DebugPrint('  ResID: %d', resEntry^.ResID);
             // DebugPrint('  DataSize: %d bytes', resEntry^.DataSize);
              
              // DFM resource ise parse et
              if StrCmpI(@curName[0], 'TFORM1') or
                 StrCmpI(@curName[0], 'MAINFORM') or
                 StrCmpI(@curName[0], 'FORM1') then
              begin
                DebugPrint('  � DFM Form detected!');
              end;
          end;
        end;
      end;
    end;

    Inc(entry);
    Inc(i);
  end;
end;

// ParseResources g�ncelleme
procedure ParseResources(DLL: PDLLInfo; BaseAddr: LongWord);
var
  dos:       PDosHeader;
  fh:        PFileHeader;
  opt:       POptHeader;
  sec:       PSectionHeader;
  i:         Integer;
  rsrcRVA:   LongWord;
  rsrcSize:  LongWord;
  rsrcOffset: LongWord;
begin
  if DLL = nil then Exit;

  DLL^.ResourceCount := 0;
  DLL^.IconCount     := 0;
  DLL^.BitmapCount   := 0;
  DLL^.TextCount     := 0;
  DLL^.CursorCount   := 0;

  dos := PDosHeader(BaseAddr);
  if dos^.e_magic <> $5A4D then Exit;

  fh := PFileHeader(BaseAddr + dos^.e_lfanew);
  if fh^.Signature <> $00004550 then Exit;

  opt := POptHeader(LongWord(fh) + SizeOf(TFileHeader));

  // Resource directory (DataDir index 2)
  rsrcRVA  := opt^.DataDirs[2].VirtualAddress;
  rsrcSize := opt^.DataDirs[2].Size;

  if (rsrcRVA = 0) or (rsrcSize = 0) then Exit;

  rsrcOffset := 0;
  sec := PSectionHeader(LongWord(opt) + fh^.SizeOfOptionalHeader);

  i := 0;
  while i < fh^.NumberOfSections do
  begin
    if (rsrcRVA >= sec^.VirtualAddress) and
       (rsrcRVA < sec^.VirtualAddress + sec^.VirtualSize) then
    begin
      rsrcOffset := rsrcRVA - sec^.VirtualAddress;
      Break;
    end;
    Inc(sec);
    Inc(i);
  end;

  if rsrcOffset = 0 then
    rsrcOffset := rsrcRVA;

  // ? ResName parametresi ekle
  WalkResDir(BaseAddr, rsrcRVA, 0, 0, 0, 0, 0, nil, DLL);
end;






function LoadPEDLL(ExeData: Pointer; ExeSize: LongWord;
                   BaseAddr: LongWord; DLL: PDLLInfo): Boolean;
var
  dos:       PDosHeader;
  fh:        PFileHeader;
  opt:       POptHeader;
  sec:       PSectionHeader;
  expDir:    PExportDir;
  i:         Integer;
  delta:     LongInt;
  src:       LongWord;
  dst:       LongWord;
  expRVA:    LongWord;
  expSize:   LongWord;
  funcTable: PLongWord;
  nameTable: PLongWord;
  ordTable:  PWord;
  funcAddr:  LongWord;
  nameRVA:   LongWord;
  funcName:  PChar;
  ordinal:   Word;
  blk:       Pointer;
  blkSz:     LongWord;
  entryOff:  Word;
  entryType: Byte;
  fixup:     PLongWord;
  relocRVA:  LongWord;
  relocSz:   LongWord;
  dataDirPtr: PLongWord;
  resRVA:    LongWord;
  resSize:   LongWord;
begin
  Result := False;

  if ExeData = nil then Exit;
  if ExeSize < 64 then Exit;

  dos := PDosHeader(ExeData);
  if dos^.e_magic <> $5A4D then Exit;

  fh := PFileHeader(LongWord(ExeData) + dos^.e_lfanew);
  if fh^.Signature <> $00004550 then Exit;

  opt := POptHeader(LongWord(fh) + SizeOf(TFileHeader));

  delta := LongInt(BaseAddr) - LongInt(opt^.ImageBase);

  // Memory setup
  MemSet(Pointer(BaseAddr), 0, opt^.SizeOfImage);
  MemCopy(Pointer(BaseAddr), ExeData, opt^.SizeOfHeaders);

  // Load sections
  sec := PSectionHeader(LongWord(opt) + fh^.SizeOfOptionalHeader);
  i := 0;
  while i < fh^.NumberOfSections do
  begin
    if sec^.SizeOfRawData > 0 then
    begin
      src := LongWord(ExeData) + sec^.PointerToRawData;
      dst := BaseAddr + sec^.VirtualAddress;
      MemCopy(Pointer(dst), Pointer(src), sec^.SizeOfRawData);
    end;
    Inc(sec);
    Inc(i);
  end;

  // Relocation
  if delta <> 0 then
  begin
    dataDirPtr := PLongWord(LongWord(opt) + 96 + 5 * 8);
    relocRVA := dataDirPtr^;
    relocSz  := PLongWord(LongWord(dataDirPtr) + 4)^;

    if (relocRVA > 0) and (relocSz > 0) then
    begin
      blk := Pointer(BaseAddr + relocRVA);
      while LongWord(blk) < BaseAddr + relocRVA + relocSz do
      begin
        blkSz := PLongWord(LongWord(blk) + 4)^;
        if blkSz < 8 then Break;

        i := 0;
        while i < Integer((blkSz - 8) div 2) do
        begin
          entryOff  := PWord(LongWord(blk) + 8 + LongWord(i) * 2)^;
          entryType := entryOff shr 12;

          if entryType = 3 then
          begin
            fixup := PLongWord(BaseAddr + PLongWord(blk)^ + (entryOff and $FFF));
            Inc(fixup^, delta);
          end;

          Inc(i);
        end;

        blk := Pointer(LongWord(blk) + blkSz);
      end;
    end;
  end;

  // *** Export Table Parse ***
  expRVA  := opt^.DataDirs[0].VirtualAddress;
  expSize := opt^.DataDirs[0].Size;

  if (expRVA > 0) and (expSize > 0) then
  begin
    expDir := PExportDir(BaseAddr + expRVA);
    funcTable := PLongWord(BaseAddr + expDir^.AddressOfFunctions);
    nameTable := PLongWord(BaseAddr + expDir^.AddressOfNames);
    ordTable  := PWord(BaseAddr + expDir^.AddressOfNameOrdinals);

    DLL^.ExportCount := 0;

    i := 0;
    while i < Integer(expDir^.NumberOfNames) do
    begin
      if DLL^.ExportCount >= MAX_EXPORTS then Break;

      nameRVA  := PLongWord(LongWord(nameTable) + LongWord(i) * 4)^;
      funcName := PChar(BaseAddr + nameRVA);
      ordinal  := PWord(LongWord(ordTable) + LongWord(i) * 2)^;
      funcAddr := PLongWord(LongWord(funcTable) + LongWord(ordinal) * 4)^;

      if (funcAddr >= expRVA) and (funcAddr < expRVA + expSize) then
      begin
        Inc(i);
        Continue;
      end;

      StrCopy(@DLL^.FnExports[DLL^.ExportCount].Name[0], funcName);
      DLL^.FnExports[DLL^.ExportCount].Ordinal := ordinal;
      DLL^.FnExports[DLL^.ExportCount].Address := BaseAddr + funcAddr;

      Inc(DLL^.ExportCount);
      Inc(i);
    end;
  end;




  ParseResources(DLL, BaseAddr);

 


  DLL^.ImageSize := opt^.SizeOfImage;
  Result := True;
end;



//=============================================================================
// LoadLibrary
//=============================================================================

function LoadLibrary(DLLName: PChar): Integer;
var
  existing: Integer;
  Slot,I       : Integer;
  FileHandle : Integer;
  FileSize_  : LongWord;
  BytesRead  : LongWord;

  FileBuf    : Pointer;

  Dos        : PDosHeader;
  FH         : PFileHeader;
  Opt        : POptHeader;

  ImageBase  : LongWord;

  DLLInfo    : PDLLInfo;

  dllPath:  array[0..127] of Char;
begin
  Result := -1;


   // Zaten yüklü mü?
  existing := FindDLL(DLLName);
  if existing >= 0 then
  begin
    Inc(DLLList[existing].RefCount);
    Result := existing;
    Exit;
  end;

  Slot := AllocDLLSlot;
  if Slot < 0 then Exit;



   // DLL dosyasını yükle
  // Önce C:\SYSTEM\DLL\ klasörüne bak
  StrCopy(@dllPath[0], 'C:\SYSTEM\');
  i := 0;
  while DLLName[i] <> #0 do
  begin
    dllPath[10 + i] := DLLName[i];
    Inc(i);
  end;
  dllPath[10 + i] := #0;

  fileHandle := OpenFile(@dllPath[0], FILE_READ);

  if fileHandle < 0 then
  begin
    // Root'ta ara
    fileHandle := OpenFile(DLLName, FILE_READ);
    if fileHandle < 0 then Exit;
  end
  else
  begin
     StrCopy(@DLLInfo^.Name[0], @dllPath[0]);
  end;

  FileSize_ := FileSize(FileHandle);

  FileBuf := MemAlloc(FileSize_);

  BytesRead := ReadFile(FileHandle, FileBuf, FileSize_);

  CloseFile(FileHandle);

  if BytesRead <> FileSize_ then
  begin
    FreeMem(FileBuf);
    Exit;
  end;

  Dos := PDosHeader(FileBuf);

  FH :=
    PFileHeader(
      LongWord(FileBuf) +
      Dos^.e_lfanew
    );

  Opt :=
    POptHeader(
      LongWord(FH) +
      SizeOf(TFileHeader)
    );

  ImageBase := LongWord(MemAlloc(Opt^.SizeOfImage));

  if ImageBase = 0 then
  begin
    FreeMem(FileBuf);
    Exit;
  end;

  DLLInfo := @DLLList[Slot];

  MemSet(DLLInfo,0,SizeOf(TDLLInfo));

  DLLInfo^.Loaded := True;

  DLLInfo^.RawFileAddr := LongWord(FileBuf);
  DLLInfo^.RawFileSize := FileSize_;

  DLLInfo^.BaseAddr := ImageBase;
  DLLInfo^.ImageSize := Opt^.SizeOfImage;

  DLLInfo^.RefCount := 1;

  StrCopy(@DLLInfo^.Name[0], DLLName);

  if not LoadPEDLL(
         FileBuf,
         FileSize_,
         ImageBase,
         DLLInfo) then
  begin
    FreeMem(FileBuf);
    FreeMem(Pointer(ImageBase));

    MemSet(DLLInfo,0,SizeOf(TDLLInfo));

    Exit;
  end;
  
  Inc(DLLCount);
  Result := Slot;
end;


//=============================================================================
// FreeLibrary
//=============================================================================

procedure FreeLibrary(DLLIndex: Integer);
begin
  if (DLLIndex < 0) or (DLLIndex >= MAX_DLLS) then Exit;

  if not DLLList[DLLIndex].Loaded then Exit;

  Dec(DLLList[DLLIndex].RefCount);

  if DLLList[DLLIndex].RefCount > 0 then Exit;

  if DLLList[DLLIndex].RawFileAddr <> 0 then
    FreeMem(Pointer(DLLList[DLLIndex].RawFileAddr));

  if DLLList[DLLIndex].BaseAddr <> 0 then
    FreeMem(Pointer(DLLList[DLLIndex].BaseAddr));

  MemSet(
    @DLLList[DLLIndex],
    0,
    SizeOf(TDLLInfo)
  );

  Dec(DLLCount);
end;

//=============================================================================
// GetProcAddress
//=============================================================================

function GetProcAddress(DLLIndex: Integer; ProcName: PChar): LongWord;
var
  i: Integer;
begin
  Result := 0;
  if (DLLIndex < 0) or (DLLIndex >= MAX_DLLS) then Exit;
  if not DLLList[DLLIndex].Loaded then Exit;

  i := 0;
  while i < DLLList[DLLIndex].ExportCount do
  begin
    if StrCmpI(@DLLList[DLLIndex].FnExports[i].Name[0], ProcName) then
    begin
      Result := DLLList[DLLIndex].FnExports[i].Address;  // ? Do�ru adres
      Exit;
    end;
    Inc(i);
  end;
end;

function GetProcAddressByOrdinal(DLLIndex: Integer; Ordinal: Word): LongWord;
var
  i: Integer;
begin
  Result := 0;

  if (DLLIndex < 0) or (DLLIndex >= MAX_DLLS) then Exit;
  if not DLLList[DLLIndex].Loaded then Exit;

  i := 0;
  while i < DLLList[DLLIndex].ExportCount do
  begin
    if DLLList[DLLIndex].FnExports[i].Ordinal = Ordinal then
    begin
      Result := DLLList[DLLIndex].FnExports[i].Address;
      Exit;
    end;
    Inc(i);
  end;
end;

//=============================================================================
// ResolveImports — EXE'nin import table'ını çöz
//=============================================================================




function ResolveImports(ExeBase: LongWord): Boolean;
var
  dos:         PDosHeader;
  fh:          PFileHeader;
  opt:         POptHeader;
  importRVA:   LongWord;
  importSize:  LongWord;
  impDesc:     PImportDesc;
  dllName:     PChar;
  dllIndex:    Integer;
  thunk:       PLongWord;
  iatEntry:    PLongWord;
  importByName: Boolean;
  nameRVA:     LongWord;
  procName:    PChar;
  ordinal:     Word;
  procAddr:    LongWord;
  hint:        Word;
begin
  Result := False;

  dos := PDosHeader(ExeBase);
  if dos^.e_magic <> $5A4D then Exit;

  fh  := PFileHeader(ExeBase + dos^.e_lfanew);
  if fh^.Signature <> $00004550 then Exit;

  opt := POptHeader(LongWord(fh) + SizeOf(TFileHeader));

  // Import directory (index 1)
  importRVA  := opt^.DataDirs[1].VirtualAddress;
  importSize := opt^.DataDirs[1].Size;

  if (importRVA = 0) or (importSize = 0) then
  begin
    Result := True;  // Import yok, sorun değil
    Exit;
  end;

  // Her import descriptor = 1 DLL
  impDesc := PImportDesc(ExeBase + importRVA);

  while impDesc^.Name <> 0 do
  begin
    // DLL adını al
    dllName := PChar(ExeBase + impDesc^.Name);

    // DLL'i yükle
    dllIndex := LoadLibrary(dllName);

    if dllIndex < 0 then
    begin
      // DLL bulunamadı - kritik hata
      // TODO: Kernel DLL stub'ları için kontrol et
      Inc(impDesc);
      Continue;
    end;

    // INT (Import Name Table) veya IAT walk
    if impDesc^.OriginalFirstThunk <> 0 then
      thunk := PLongWord(ExeBase + impDesc^.OriginalFirstThunk)
    else
      thunk := PLongWord(ExeBase + impDesc^.FirstThunk);

    // IAT (Import Address Table)
    iatEntry := PLongWord(ExeBase + impDesc^.FirstThunk);

    // Her import edilen fonksiyon
    while thunk^ <> 0 do
    begin
      // Import by ordinal? (bit 31 set)
      if (thunk^ and $80000000) <> 0 then
      begin
        ordinal := Word(thunk^ and $FFFF);
        procAddr := GetProcAddressByOrdinal(dllIndex, ordinal);
      end
      else
      begin
        // Import by name
        // thunk^ = RVA to IMAGE_IMPORT_BY_NAME
        // [0..1] = hint, [2..] = name
        nameRVA  := thunk^;
        hint     := PWord(ExeBase + nameRVA)^;
        procName := PChar(ExeBase + nameRVA + 2);

        procAddr := GetProcAddress(dllIndex, procName);

       // Showmessage(procName);

        // Hint ile de dene
        if (procAddr = 0) and (hint > 0) then
          procAddr := GetProcAddressByOrdinal(dllIndex, hint);
      end;

      // IAT'a yaz
      iatEntry^ := procAddr;

      Inc(thunk);
      Inc(iatEntry);
    end;

    Inc(impDesc);
  end;

  Result := True;
end;




function FindResource(DLL: PDLLInfo; ResType, ResID: Integer): PResourceEntry;
var
  i: Integer;
begin
  Result := nil;
  if DLL = nil then Exit;

  i := 0;
  while i < DLL^.ResourceCount do
  begin
    if (DLL^.Resources[i].ResType = ResType) and
       (DLL^.Resources[i].ResID = ResID) then
    begin
      Result := @DLL^.Resources[i];
      Exit;
    end;
    Inc(i);
  end;
end;

function FindResourceByName(DLL: PDLLInfo; ResType: Integer;
                            Name: PChar): PResourceEntry;
var
  i: Integer;
begin
  Result := nil;
  if DLL = nil then Exit;

  i := 0;
  while i < DLL^.ResourceCount do
  begin
    if (DLL^.Resources[i].ResType = ResType) and
       StrCmpI(@DLL^.Resources[i].ResName[0], Name) then
    begin
      Result := @DLL^.Resources[i];
      Exit;
    end;
    Inc(i);
  end;
end;

function LoadResource(DLL: PDLLInfo; ResType, ResID: Integer;
                      Size: PLongWord): Pointer;
var
  res: PResourceEntry;
begin
  Result := nil;
  if Size <> nil then Size^ := 0;

  res := FindResource(DLL, ResType, ResID);
  if res = nil then Exit;

  if Size <> nil then
    Size^ := res^.DataSize;

  Result := Pointer(res^.DataPtr);
end;

function SizeofResource(DLL: PDLLInfo; ResType, ResID: Integer): LongWord;
var
  res: PResourceEntry;
begin
  Result := 0;
  res := FindResource(DLL, ResType, ResID);
  if res <> nil then
    Result := res^.DataSize;
end;

//=============================================================================
// Icon API
//=============================================================================

function GetIcon(DLL: PDLLInfo; ID: Integer): PIconData;
var
  i: Integer;
begin
  Result := nil;
  if DLL = nil then Exit;

  i := 0;
  while i < DLL^.IconCount do
  begin
    if DLL^.Icons[i].ID = ID then
    begin
      Result := @DLL^.Icons[i];
      Exit;
    end;
    Inc(i);
  end;
end;

procedure DrawIcon(DLL: PDLLInfo; ID, X, Y: Integer);
var
  icon:    PIconData;
  bmpHdr:  PBmpInfoHdr;
  pixData: LongWord;
  row:     Integer;
  col:     Integer;
  pixel:   LongWord;
  stride:  Integer;
  pix:     PByteArray;
  r, g, b: Byte;
  colorTbl: PLongWord;
  colorCount: Integer;
  palIdx:  Byte;
begin
  icon := GetIcon(DLL, ID);
  if icon = nil then Exit;
  if icon^.DataPtr = 0 then Exit;

  bmpHdr := PBmpInfoHdr(icon^.DataPtr);

  // Pixel data başlangıcı
  colorCount := 0;
  if bmpHdr^.biBitCount <= 8 then
    colorCount := 1 shl bmpHdr^.biBitCount;

  colorTbl := PLongWord(LongWord(bmpHdr) + SizeOf(TBmpInfoHdr));
  pixData  := LongWord(bmpHdr) + SizeOf(TBmpInfoHdr) +
              LongWord(colorCount) * 4;

  // Bottom-up bitmap
  stride := ((icon^.Width * bmpHdr^.biBitCount + 31) div 32) * 4;

   

  row := 0;
  while row < icon^.Height do
  begin
    col := 0;
    while col < icon^.Width do
    begin
      pix := PByteArray(pixData + LongWord(icon^.Height - 1 - row) * LongWord(stride));

      case bmpHdr^.biBitCount of
        1:
        begin
          palIdx := (pix[col div 8] shr (7 - (col mod 8))) and 1;
          pixel  := PLongWord(LongWord(colorTbl) + palIdx * 4)^;
        end;
        4:
        begin
          if (col mod 2) = 0 then
            palIdx := pix[col div 2] shr 4
          else
            palIdx := pix[col div 2] and $0F;
          pixel := PLongWord(LongWord(colorTbl) + palIdx * 4)^;
        end;
        8:
        begin
          palIdx := pix[col];
          pixel  := PLongWord(LongWord(colorTbl) + palIdx * 4)^;
        end;
        24:
        begin
          b := pix[col * 3];
          g := pix[col * 3 + 1];
          r := pix[col * 3 + 2];
          pixel := LongWord(b) or (LongWord(g) shl 8) or (LongWord(r) shl 16);
        end;
        32:
        begin
          pixel := PLongWord(LongWord(pix) + LongWord(col) * 4)^;
        end;
      else
        pixel := $00FF00FF;  // Magenta = hata
      end;

      PutPixel(X + col, Y + row, pixel);

      Inc(col);
    end;
    Inc(row);
  end;
end;

//=============================================================================
// Bitmap API
//=============================================================================

function GetBitmap(DLL: PDLLInfo; ID: Integer): PBitmapData;
var
  i: Integer;
begin
  Result := nil;
  if DLL = nil then Exit;

  i := 0;
  while i < DLL^.BitmapCount do
  begin
    if DLL^.Bitmaps[i].ID = ID then
    begin
      Result := @DLL^.Bitmaps[i];
      Exit;
    end;
    Inc(i);
  end;
end;

procedure ResDrawBitmap(DLL: PDLLInfo; ID, X, Y: Integer);
var
  bmp:     PBitmapData;
  bmpHdr:  PBmpInfoHdr;
  pixData: LongWord;
  row:     Integer;
  col:     Integer;
  pixel:   LongWord;
  stride:  Integer;
  pix:     PByteArray;
  r, g, b: Byte;
  colorTbl: PLongWord;
  colorCount: Integer;
  palIdx:  Byte;
begin
  bmp := GetBitmap(DLL, ID);
  if bmp = nil then Exit;
  if bmp^.DataPtr = 0 then Exit;

  bmpHdr := PBmpInfoHdr(bmp^.DataPtr);

  colorCount := 0;
  if bmpHdr^.biBitCount <= 8 then
    colorCount := 1 shl bmpHdr^.biBitCount;

  colorTbl := PLongWord(LongWord(bmpHdr) + SizeOf(TBmpInfoHdr));
  pixData  := LongWord(bmpHdr) + SizeOf(TBmpInfoHdr) +
              LongWord(colorCount) * 4;

  stride := ((bmp^.Width * bmpHdr^.biBitCount + 31) div 32) * 4;

  row := 0;
  while row < bmp^.Height do
  begin
    col := 0;
    while col < bmp^.Width do
    begin
      pix := PByteArray(pixData + LongWord(bmp^.Height - 1 - row) * LongWord(stride));

      case bmpHdr^.biBitCount of
        4:
        begin
          if (col mod 2) = 0 then
            palIdx := pix[col div 2] shr 4
          else
            palIdx := pix[col div 2] and $0F;
          pixel := PLongWord(LongWord(colorTbl) + palIdx * 4)^;
        end;
        8:
        begin
          palIdx := pix[col];
          pixel  := PLongWord(LongWord(colorTbl) + palIdx * 4)^;
        end;
        24:
        begin
          b := pix[col * 3];
          g := pix[col * 3 + 1];
          r := pix[col * 3 + 2];
          pixel := LongWord(b) or (LongWord(g) shl 8) or (LongWord(r) shl 16);
        end;
        32:
        begin
          pixel := PLongWord(LongWord(pix) + LongWord(col) * 4)^;
        end;
      else
        pixel := $00808080;
      end;

      PutPixel(X + col, Y + row, pixel);
      Inc(col);
    end;
    Inc(row);
  end;
end;

procedure DrawBitmapStretched(DLL: PDLLInfo; ID, X, Y, W, H: Integer);
var
  bmp:    PBitmapData;
  row:    Integer;
  col:    Integer;
  srcX:   Integer;
  srcY:   Integer;
  bmpHdr: PBmpInfoHdr;
  pixData: LongWord;
  stride: Integer;
  pix:    PByteArray;
  pixel:  LongWord;
  r, g, b: Byte;
begin
  bmp := GetBitmap(DLL, ID);
  if bmp = nil then Exit;
  if bmp^.DataPtr = 0 then Exit;

  bmpHdr := PBmpInfoHdr(bmp^.DataPtr);

  stride  := ((bmp^.Width * bmpHdr^.biBitCount + 31) div 32) * 4;
  pixData := LongWord(bmp^.DataPtr) + SizeOf(TBmpInfoHdr) +
             LongWord(1 shl bmpHdr^.biBitCount) * 4;

  if bmpHdr^.biBitCount > 8 then
    pixData := LongWord(bmp^.DataPtr) + SizeOf(TBmpInfoHdr);

  row := 0;
  while row < H do
  begin
    srcY := (row * bmp^.Height) div H;

    col := 0;
    while col < W do
    begin
      srcX := (col * bmp^.Width) div W;

      pix := PByteArray(pixData +
                   LongWord(bmp^.Height - 1 - srcY) * LongWord(stride));

      case bmpHdr^.biBitCount of
        24:
        begin
          b := pix[srcX * 3];
          g := pix[srcX * 3 + 1];
          r := pix[srcX * 3 + 2];
          pixel := LongWord(b) or (LongWord(g) shl 8) or (LongWord(r) shl 16);
        end;
        32:
          pixel := PLongWord(LongWord(pix) + LongWord(srcX) * 4)^;
      else
        pixel := $00808080;
      end;

      PutPixel(X + col, Y + row, pixel);
      Inc(col);
    end;
    Inc(row);
  end;
end;

//=============================================================================
// String API
//=============================================================================

function LoadString(DLL: PDLLInfo; ID: Integer; Buffer: PChar;
                    MaxLen: Integer): Integer;
var
  i: Integer;
  j: Integer;
begin
  Result := 0;
  if (DLL = nil) or (Buffer = nil) or (MaxLen <= 0) then Exit;

  i := 0;
  while i < DLL^.TextCount do
  begin
    if DLL^.Texts[i].ID = ID then
    begin
      j := 0;
      while (DLL^.Texts[i].Text[j] <> #0) and (j < MaxLen - 1) do
      begin
        Buffer[j] := DLL^.Texts[i].Text[j];
        Inc(j);
      end;
      Buffer[j] := #0;
      Result := j;
      Exit;
    end;
    Inc(i);
  end;
end;



{ =========================================================
  KULLANIM ÖRNEĞİ
  ========================================================= }

(*
// 1. DLL yükle ve resource parse et
procedure LoadDLLWithResources;
var
  dllIdx: Integer;
  dllInfo: PDLLInfo;
  buf: array[0..255] of Char;
  size: LongWord;
  rawData: Pointer;
begin
  dllIdx := LoadLibrary('TEST.DLL');
  if dllIdx < 0 then Exit;

  dllInfo := @DLLList[dllIdx];

  // ParseResources otomatik çağrılır LoadPEDLL içinde
  // Ama manuel de çağırılabilir:
  // ParseResources(dllInfo, dllInfo^.BaseAddr);

  // 2. Icon çiz
  DrawIcon(dllInfo, 1, 10, 10);   // ID=1 icon'u (10,10)'a çiz

  // 3. Bitmap çiz
  DrawBitmap(dllInfo, 101, 50, 50);

  // 4. Bitmap stretched
  DrawBitmapStretched(dllInfo, 101, 100, 100, 200, 150);

  // 5. String yükle
  FillChar(buf, SizeOf(buf), 0);
  LoadString(dllInfo, 1001, @buf[0], 255);
  ShowMessage(@buf[0]);

  // 6. Ham resource
  rawData := LoadResource(dllInfo, RT_RCDATA, 200, @size);
  if rawData <> nil then
    ShowMessage('Raw data loaded');

  // 7. FindResource
  var res := FindResource(dllInfo, RT_BITMAP, 101);
  if res <> nil then
    ShowMessage('Bitmap found');

  // 8. Tüm iconları listele
  var i := 0;
  while i < dllInfo^.IconCount do
  begin
    // dllInfo^.Icons[i].ID
    // dllInfo^.Icons[i].Width
    // dllInfo^.Icons[i].Height
    Inc(i);
  end;
end;

// DLL RESOURCE TANIMLAMA (Delphi/RC dosyası):
//
// test.rc:
//   1 ICON "myicon.ico"
//   101 BITMAP "mybmp.bmp"
//   STRINGTABLE
//   BEGIN
//     1001 "Hello World"
//     1002 "Kernel OS"
//   END
//
// Derleme: brcc32 test.rc
*)







//=============================================================================
// ProcessCreate entegrasyonu
//=============================================================================


//=============================================================================
// Kernel DLL Stub — Syscall wrapper
//=============================================================================

// kernel.dll gibi davranır, EXE'ler kernel fonksiyonlarına bu şekilde erişir


function Add(A,B:Integer):Integer; stdcall;
begin
  Result := A + B;
end;



procedure KernelDLL_Register;
var
  slot:    Integer;
  dllInfo: PDLLInfo;
begin
  slot := AllocDLLSlot;
  if slot < 0 then Exit;

  dllInfo := @DLLList[slot];
  MemSet(dllInfo, 0, SizeOf(TDLLInfo));

  dllInfo^.Loaded   := True;
  dllInfo^.BaseAddr := 0;  // Kernel space
  dllInfo^.RefCount := $7FFFFFFF;  // Hiç silinmez

  StrCopy(@dllInfo^.Name[0], 'Kernel32.dll');

  // Kernel fonksiyonlarını kaydet
  dllInfo^.FnExports[0].Address := LongWord(@Add);
  StrCopy(@dllInfo^.FnExports[0].Name[0], 'Add');

  dllInfo^.ExportCount := 1;
  Inc(DLLCount)



 { with dllInfo^.FnExports[0] do begin Address := LongWord(@_GetStdHandle);    StrCopy(@Name[0], 'GetStdHandle');     Ordinal := 1; end;
  with dllInfo^.FnExports[1] do begin Address := LongWord(@_WriteConsole);   StrCopy(@Name[0], 'WriteConsole');  Ordinal := 2; end;
  with dllInfo^.FnExports[2] do begin Address := LongWord(@_ReadConsole);      StrCopy(@Name[0], 'ReadConsole');     Ordinal := 3; end;
  with dllInfo^.FnExports[3] do begin Address := LongWord(@_PutChar);         StrCopy(@Name[0], 'PutChar');          Ordinal := 4; end;
  with dllInfo^.FnExports[4] do begin Address := LongWord(@_ClearScreen);     StrCopy(@Name[0], 'ClearScreen');      Ordinal := 5; end;

  with dllInfo^.FnExports[5] do begin Address := LongWord(@Add);     StrCopy(@Name[0], 'Add');      Ordinal := 6; end;

  dllInfo^.ExportCount := 6;
  Inc(DLLCount); }

  
end;

//=============================================================================
// Init
//=============================================================================

procedure DLLLoader_Init;
var
  i: Integer;
begin
  i := 0;
  while i < MAX_DLLS do
  begin
    FillChar(DLLList[i],SizeOf(TDLLInfo),#0);

  //  MemSet(@DLLList[i], 0, SizeOf(TDLLInfo));
    Inc(i);
  end;

  DLLCount := 0;

  // Kernel DLL'i kaydet
  KernelDLL_Register;
end;



{ =========================================================
  DLL YAZIMI ÖRNEĞİ (Delphi 7)
  
  test.dll → C:\SYSTEM\DLL\TEST.DLL
  ========================================================= }

(*
library test;                    // ← "library" kullan

// Export edilen fonksiyon
function AddNumbers(A, B: Integer): Integer; stdcall;
begin
  Result := A + B;
end;

function MulNumbers(A, B: Integer): Integer; stdcall;
begin
  Result := A * B;
end;

exports
  AddNumbers,
  MulNumbers;

begin
end.
*)

{ =========================================================
  EXE KULLANIMI (Ring 3)
  ========================================================= }

(*
// EXE içinde DLL import etmek:

// 1. Static import (Delphi linker halleder)
function AddNumbers(A, B: Integer): Integer; stdcall;
  external 'test.dll';

procedure Main;
var
  result: Integer;
begin
  result := AddNumbers(10, 20);  // → 30
end;

// 2. Dynamic import (Runtime)
var
  dllIdx: Integer;
  addProc: function(A, B: Integer): Integer; stdcall;
begin
  dllIdx := LoadLibrary('TEST.DLL');
  if dllIdx >= 0 then
  begin
    addProc := Pointer(GetProcAddress(dllIdx, 'AddNumbers'));
    if Assigned(addProc) then
    begin
      var r := addProc(10, 20);  // → 30
    end;
    FreeLibrary(dllIdx);
  end;
end;
*)

end.

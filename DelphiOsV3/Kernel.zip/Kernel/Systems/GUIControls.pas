unit GUIControls;

interface

uses
  SysUtils,Pit,KeyBoard, Memory, Draw32, Math,GUI,Mouse,Vesa,DrawIcons,FileIcons;

const
  { Virtual Key Codes }
  VK_LEFT    = 37;
  VK_RIGHT   = 39;
  VK_UP      = 38;
  VK_DOWN    = 40;
  VK_HOME    = 36;
  VK_END     = 35;
  VK_DELETE  = 46;
  VK_BACK    = 8;
  VK_RETURN  = 13;
  VK_TAB     = 9;
  VK_ESCAPE  = 27;
  VK_PGUP    = 33;
  VK_PGDOWN  = 34;

  MENU_BAR_HEIGHT = 20;
  MAX_STR        = 256;
  MAX_TOOLBAR_BUTTONS = 32;

type



  PPopupItem = ^TPopupItem;
  TPopupClickProc = procedure(Item: PPopupItem);

  TPopupItem = record
    Caption:      array[0..127] of Char;
    Enabled:      Boolean;
    Checked:      Boolean;
    Separator:    Boolean;
    Tag:          Integer;
    OnClick:      TPopupClickProc;
  end;



  PPopup = ^TPopup;
  TPopup = Object(TObject)
  public
    Items:         PPCharArray;   { PPopupMenuItem dizisi }
    ItemCount:     Integer;
    ItemCapacity:  Integer;
    X, Y:          Integer;
    ItemHeight:    Integer;

    SelectedIndex: Integer;

    procedure AddItem(const ACaption: PChar; AOnClick: TPopupClickProc; AEnabled: Boolean = True);
    procedure AddSeparator;
    procedure Show(AX, AY: Integer);
    procedure Hide;
    procedure Draw;
    function  HitTest(MX, MY: Integer): Integer;  { -1 = d��ar� }
    procedure MouseDown(MX, MY: Integer; Btn: Byte);
    procedure MouseMove(MX, MY: Integer);
  end;





  { TPanel }
  PPanel = ^TPanel;
  TPanel = Object(TObject)
  public
  end;


  { TButton }
  PButton = ^TButton;
  TButton = Object(TObject)
  public
    FPressed, FHover: Boolean;
  end;

  { TLabel }
  PLabel = ^TLabel;
  TLabel = object(TObject)
  public
    Alignment: Byte;      // 0=Left, 1=Center, 2=Right
    Transparent: Boolean;
    Shadow: Boolean;
    ShadowColor: LongWord;
  end;

  { TEdit }
  PEdit = ^TEdit;
  TEdit = object(TObject)
  public
    Text:          array[0..255] of Char;
    CaretPos:      Integer;
    SelStart:      Integer;
    SelLength:     Integer;
    ReadOnly:      Boolean;
    PasswordChar:  Char;
    MaxLength:     Integer;
    BorderStyle:   Byte;
  end;

  { TMemo }
  PMemo = ^TMemo;
  TMemo = object(TObject)
  public
    Lines:         PPCharArray;
    LineCount:     Integer;
    LineCapacity:  Integer;
    CaretX:        Integer;
    CaretY:        Integer;
    ScrollX:       Integer;
    ScrollY:       Integer;
    SelStartX:     Integer;
    SelStartY:     Integer;
    SelActive:     Boolean;
    ReadOnly:      Boolean;
    ShowCaret:     Boolean;
    MouseDownFlag: Boolean;
    { --- Yeni: Scrollbar durumlari --- }
    VScrollVisible: Boolean;
    HScrollVisible: Boolean;
    VScrollMax:     Integer;
    HScrollMax:     Integer;
    VThumbSize:     Integer;
    VThumbPos:      Integer;
    HThumbSize:     Integer;
    HThumbPos:      Integer;
    VDragging:      Boolean;
    HDragging:      Boolean;
    VDragStart:     Integer;
    HDragStart:     Integer;
    VArrow1Pressed: Boolean;
    VArrow2Pressed: Boolean;
    HArrow1Pressed: Boolean;
    HArrow2Pressed: Boolean;
  end;
  
  { TComboBox }
   { ---------- TComboBox ---------- }
  PComboBox = ^TComboBox;
  TComboBox = object(TObject)
  public
    Items:         PPCharArray;
    ItemCount:     Integer;
    ItemCapacity:  Integer;
    ItemIndex:     Integer;
    HoverIndex:    Integer;
    DroppedDown:   Boolean;
    FNormalHeight: Integer;   // Edit kisminin orijinal yuksekligi
    FOnChange: TNotifyEvent;   { YENI }
  end;

  { TListBox }
  PListBox = ^TListBox;
  TListBox = object(TObject)
  public
     Items:         PPCharArray;
    ItemCount:     Integer;
    ItemCapacity:  Integer;
    ItemIndex:     Integer;
    HoverIndex:    Integer;
    ScrollIndex:   Integer;
    ThumbSize:     Integer;
    ThumbPos:      Integer;   { Relative Y (2 = ust kenar) }
    Dragging:      Boolean;
    DragStartY:    Integer;   { YENI: surukleme baslangici }
  end;

  { TCheckBox }
  PCheckBox = ^TCheckBox;
  TCheckBox = object(TObject)
  public
    Checked:       Boolean;
  end;

  { TRadioButton }
  PRadioButton = ^TRadioButton;
  TRadioButton = object(TObject)
  public
    Checked:       Boolean;
  end;

  { TGroupBox }
  PGroupBox = ^TGroupBox;
  TGroupBox = object(TObject)
  public
  end;

  { TProgressBar }
  PProgressBar = ^TProgressBar;
  TProgressBar = object(TObject)
  public
    Min:           Integer;
    Max:           Integer;
    Position:      Integer;
    Smooth:        Boolean;
    ShowPercent:   Boolean;
  end;

  { TTrackBar }
  PTrackBar = ^TTrackBar;
  TTrackBar = object(TObject)
  public
    Min:           Integer;
    Max:           Integer;
    Position:      Integer;
    ThumbX:        Integer;
    Dragging:      Boolean;
    DragOffset:    Integer;
  end;

  { TImage }
  PImage = ^TImage;
  TImage = object(TObject)
  public
    Bitmap:        Pointer;
    BitmapWidth:   Integer;
    BitmapHeight:  Integer;
  end;

  { TSplitter }

  TSplitterOrientation = (soHorizontal, soVertical);
  PSplitter = ^TSplitter;
  TSplitter = object(TObject)
  public
    FControl:PObject;
    FDragging: Boolean;
    FStartPos: Integer;     // S?r?kleme ba?lang?c?ndaki koordinat (X veya Y)
    FStartSize: Integer;    // S?r?kleme ba?lang?c?ndaki hedef bile?en boyutu
    FOrientation: TSplitterOrientation;
    FMinSize: Integer;      // Yeniden boyutland?r?labilecek minimum s?n?r
    function FindControlToResize: PObject;
  end;


  { TStatusBar }

  const
  MAX_STATUS_PANELS = 16;
  PANEL_TEXT_LEN    = 64; // Her b?lme i?in maksimum 64 karakter


  type
  TStatusPanel = record
    Text: array[0..PANEL_TEXT_LEN - 1] of Char; // Sabit boyutlu karakter dizisi
    Width: Integer;
  end;

  PStatusBar = ^TStatusBar;
  TStatusBar = object(TObject)
  private
    FPanels: array[0..MAX_STATUS_PANELS - 1] of TStatusPanel;
    FPanelCount: Integer;
    FSimplePanel: Boolean;
    FSimpleText: array[0..PANEL_TEXT_LEN - 1] of Char;
  public
    // String yerine PChar kabul eden metotlar
    function AddPanel(AText: PChar; AWidth: Integer): Integer;
    procedure SetPanelText(Index: Integer; AText: PChar);
    procedure SetSimpleText(AText: PChar);
    procedure SetSimplePanel(Value: Boolean);
  end;




  { TMenuItem }
  PMenuItem = ^TMenuItem;
  TMenuItem = object(TObject)
  public
    Shortcut:      array[0..31] of Char;
    SubItems:      PPCharArray;
    SubCount:      Integer;
    SubCapacity:   Integer;
    SubHoverIndex: Integer;
    SubMenuVisible:Boolean;
    OnClick:       TNotifyEvent;
    ItemLeft:      Integer;
    ItemTop:       Integer;
    ItemWidth:     Integer;
    ItemHeight:    Integer;
  end;

  { TMenuBar }
  PMenuBar = ^TMenuBar;
  TMenuBar = object(TObject)
  public
    Items:         PPCharArray;
    ItemCount:     Integer;
    ItemCapacity:  Integer;
    ActiveIndex:   Integer;
    HoverIndex:    Integer;
    PopupAbsX:     Integer;   { YENI }
    PopupAbsY:     Integer;   { YENI }
  end;

{=============================================================================}
{ TListView - Coklu G?r?n?m Listesi                                           }
{=============================================================================}

type
  PListColumn = ^TListColumn;
  TListColumn = record
    Caption: array[0..63] of Char;
    Width:   Integer;
  end;

  PListViewItem = ^TListViewItem;
  TListViewItem = record
    Caption:   array[0..255] of Char;
    SubItems:  PPCharArray;
    SubCount:  Integer;
    SubCap:    Integer;
    Tag:       Integer;
    ImageIndex:Integer;
  end;

  PListView = ^TListView;
  TListView = object(TObject)
  public
    ViewStyle:      Byte;      // 0=List, 1=Icon, 2=Details
    { S?tunlar }
    Columns:        PPCharArray;  // PListColumn dizisi
    ColumnCount:    Integer;
    ColumnCap:      Integer;
    { ??eler }
    Items:          PPCharArray;  // PListViewItem dizisi
    ItemCount:      Integer;
    ItemCap:        Integer;
    ItemIndex:      Integer;
    HoverIndex:     Integer;
    { Kayd?rma }
    ScrollX:        Integer;
    ScrollY:        Integer;
    VScrollVisible: Boolean;
    HScrollVisible: Boolean;
    VThumbSize:     Integer;
    VThumbPos:      Integer;
    HThumbSize:     Integer;
    HThumbPos:      Integer;
    VDragging:      Boolean;
    HDragging:      Boolean;
    VDragStart:     Integer;
    HDragStart:     Integer;
    { Metrikler }
    HeaderHeight:   Integer;
    RowHeight:      Integer;
    IconSize:       Integer;
    GridLines:      Boolean;
  end;

 PScrollBar=^TScrollBar;
 TScrollBar = object(TObject)
  public
    Min: Integer;
    Max: Integer;
    Position: Integer;
    PageSize: Integer;
    SmallChange: Integer;
    Orientation: Byte; { 0 = Yatay, 1 = Dikey }
    TrackRect: TRect;
    ThumbRect: TRect;
    Btn1Rect: TRect;
    Btn2Rect: TRect;
    Dragging: Boolean;
    DragStart: Integer;
    DragStartVal: Integer;
    ThumbColor: LongWord;
    BtnColor: LongWord;
  end;

function  CreateScrollBar(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PScrollBar;
procedure ScrollBar_SetPosition(AScrollBar: PScrollBar; APos: Integer);

function CheckBoxGetState(CheckBox:PCheckBox):Boolean;
procedure CheckBoxSetState(CheckBox:PCheckBox;Value:Boolean);




{ Factory & Helpers }
function CreateListView(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                        AAlign: TAlign=alNone): PListView;
procedure ListViewAddColumn(Sender: PListView; const ACaption: PChar; AWidth: Integer);
function  ListViewAddItem(Sender: PListView; const ACaption: PChar;AImageIndex:Integer=0): Integer;
procedure ListViewSetSubItem(Sender: PListView; ItemIdx, SubIdx: Integer; const AText: PChar);
procedure ListViewClear(Sender: PListView);
procedure ListViewSetViewStyle(Sender: PListView; AStyle: Byte);



{ Factory Functions }
function CreatePanel(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                     AAlign: TAlign = alNone): PPanel;
function CreateButton(AParent: PObject; const ACaption: PChar;
                      ALeft, ATop, AWidth, AHeight: Integer;
                      AAlign: TAlign = alNone): PButton;
function CreateLabel(AParent: PObject; const ACaption: PChar; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PLabel;
function CreateEdit(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PEdit;
function CreateMemo(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PMemo;
function CreateComboBox(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PComboBox;
procedure ComboBoxAddItem(Sender: PComboBox; const AText: PChar);
procedure ComboBoxClear(Sender: PComboBox);
function CreateListBox(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PListBox;
procedure ListBoxAddItem(Sender: PListBox; const AText: PChar);
procedure ListBoxClear(Sender: PListBox);
function CreateCheckBox(AParent: PObject; const ACaption: PChar; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PCheckBox;
function CreateRadioButton(AParent: PObject; const ACaption: PChar; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PRadioButton;
function CreateGroupBox(AParent: PObject; const ACaption: PChar; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PGroupBox;
function CreateProgressBar(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PProgressBar;
function CreateTrackBar(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PTrackBar;
function CreateImage(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=alNone): PImage;
function CreateSplitter(AParent: PObject; ALeft, ATop, ASize: Integer; AHorizontal: Boolean; AAlign: TAlign=alNone): PSplitter;
function CreateStatusBar(AParent: PObject; ALeft, ATop, AWidth: Integer; AAlign: TAlign=alNone): PStatusBar;
procedure StatusBarSetText(Sender: PStatusBar; Index: Integer; const AText: PChar);
function CreateMenuItem(const ACaption: PChar): PMenuItem;
procedure MenuItemAddSubItem(Parent, Child: PMenuItem);
function CreateMenuBar(AParent: PObject; ALeft, ATop, AWidth: Integer; AAlign: TAlign=alNone): PMenuBar;
procedure MenuBarAddItem(Sender: PMenuBar; Item: PMenuItem);

procedure EditSetText(Edit: PEdit; const AText: PChar);
procedure MemoSetText(Memo: PMemo; const AText: PChar);
function MemoLineLength(Memo: PMemo; Index: Integer): Integer;
procedure MemoClear(Memo: PMemo);
procedure MemoAddLine(Memo: PMemo; const ALine: PChar);
procedure EditGetText(Edit: PEdit;var Dst:array of char;N:Integer);
procedure MemoSelectAll(Memo: PMemo);
procedure MemoCopy(Memo: PMemo);
procedure MemoCut(Memo: PMemo);
procedure MemoPaste(Memo: PMemo);


{=============================================================================}
{ TTabControl                                                                 }
{=============================================================================}

type
  PTabControl = ^TTabControl;
  TTabControl = object(TObject)
  public
    Tabs:         PPCharArray;  { sekme basliklari (PChar) }
    Pages:        PPCharArray;  { her sekmenin sayfa paneli (PPanel, PChar'a cast) }
    TabCount:     Integer;
    TabCapacity:  Integer;
    PageCapacity: Integer;
    ActiveIndex:  Integer;
    HoverIndex:   Integer;
    TabHeight:    Integer;
    OnChange:     TNotifyEvent;
  end;

function CreateTabControl(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                          AAlign: TAlign = alNone): PTabControl;
function  TabControlAddTab(TC: PTabControl; const ACaption: PChar): PPanel;
procedure TabControlSetActive(TC: PTabControl; Index: Integer);

{=============================================================================}
{ TTreeView                                                                   }
{=============================================================================}

type
  PTreeNode = ^TTreeNode;
  TTreeNode = record
    Caption:     array[0..127] of Char;
    Level:       Integer;
    Expanded:    Boolean;
    ParentIndex: Integer;   { -1 = kok seviyesi }
    Data:        Pointer;   { kullaniciya ait ekstra veri (opsiyonel) }
  end;

  PTreeView = ^TTreeView;
  TTreeView = object(TObject)
  public
    Nodes:         PPCharArray;  { PTreeNode dizisi (PChar'a cast) }
    NodeCount:     Integer;
    NodeCapacity:  Integer;
    SelectedIndex: Integer;
    HoverIndex:    Integer;
    ItemHeight:    Integer;
    ScrollIndex:   Integer;   { gorunur (acik) satirlar arasinda ilk gorunen satirin sirasi }
    ThumbPos:      Integer;
    ThumbSize:     Integer;
    Dragging:      Boolean;
    DragStartY:    Integer;
    OnSelect:      TNotifyEvent;
  end;

function CreateTreeView(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                        AAlign: TAlign = alNone): PTreeView;
function  TreeViewAddNode(TV: PTreeView; AParentIndex: Integer; const ACaption: PChar): Integer;
procedure TreeViewClear(TV: PTreeView);
procedure TreeViewExpand(TV: PTreeView; Index: Integer; AExpand: Boolean);
function  TreeViewGetSelectedText(TV: PTreeView): PChar;



  procedure MenuPopupDraw(Menu: PMenuItem; AbsX, AbsY: Integer);
  procedure MenuPopupCloseAllSubMenus(Menu: PMenuItem);
  procedure MenuPopupProcessMouseDown(MenuBar: PMenuBar; MX, MY: Integer;
  out Handled: Boolean; out ClickedItem: PMenuItem);
  procedure MenuPopupProcessMouseMove(MenuBar: PMenuBar; MX, MY: Integer);



  {=============================================================================}
{ TToolBar / TToolButton                                                      }
{=============================================================================}

type
  PToolBar = ^TToolBar;
  TToolBarButtonClick = procedure(Sender: PToolBar; ButtonIndex: Integer) of Object;

  PToolButton = ^TToolButton;
  TToolButton = record
    Caption:     array[0..63] of Char;
    OnClick:     TNotifyEvent;
    Enabled:     Boolean;
    Visible:     Boolean;
    Separator:   Boolean;
    Down:        Boolean;
    Width:       Integer;
    Tag:         Integer;
  end;

  TToolBar = object(TObject)
  public
    Buttons:         array[0..MAX_TOOLBAR_BUTTONS-1] of PToolButton;
    ButtonCount:     Integer;
    ButtonWidth:     Integer;
    ButtonHeight:    Integer;
    ShowCaptions:    Boolean;
    Flat:            Boolean;
    HotIndex:        Integer;
    PressIndex:      Integer;
    OnClick:         TToolBarButtonClick;
  end;

  

function  CreateToolBar(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                        AAlign: TAlign = alNone): PToolBar;
function  ToolBarAddButton(TB: PToolBar; const ACaption: PChar;
                           AWidth: Integer = 0;AOnClick: TNotifyEvent=nil): Integer;
procedure ToolBarAddSeparator(TB: PToolBar);
procedure ToolBarClear(TB: PToolBar);
procedure ToolBarSetButtonEnabled(TB: PToolBar; Index: Integer; AEnabled: Boolean);


function CreatePopup(AParent: PObject; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign=ALnONE): PPopup;


const
  MAX_TIMERS = 32;

type
  PTimer = ^TTimer;
  TTimer = object(TObject)
  public
    Interval: LongWord;      // Milisaniye (en az 10 ms ad�m, ��nk� PIT 100 Hz)
    LastTick: LongWord;      // Son �al��t��� tick (ms cinsinden)
    OnTimer: TNotifyEvent;   // procedure(Sender: PObject)
  end;


var
  MemoClipboard: PChar = nil;

  TimerList: array[0..MAX_TIMERS-1] of PTimer;
  TimerCount: Integer = 0;

  procedure UpdateTimers;
  function CreateTimer(AParent: PObject; AInterval: LongWord): PTimer;

implementation

Uses
  ImageLists;

{=============================================================================}
{ Yard?mc?: PCharArray yeniden boyutland?rma                                  }
{=============================================================================}

{=============================================================================}
{ Yardimci: PCharArray yeniden boyutlandirma                                  }
{=============================================================================}

function LV_IconColor(Index: Integer): LongWord;
begin
  case Index mod 8 of
    0: Result := $00FF0000;
    1: Result := $0000FF00;
    2: Result := $000000FF;
    3: Result := $00FFFF00;
    4: Result := $0000FFFF;
    5: Result := $00FF00FF;
    6: Result := $00808080;
  else
    Result := $00804000;
  end;
end;

function Component_TextWidth(S: PChar): Integer;
begin
  Result := StrLen(S) * 8;
end;


procedure Component_DrawString(X, Y: Integer; S: PChar; Color: LongWord);
var i: Integer;
begin
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    KChar(X + i * 8, Y, S[i], Color);
    Inc(i);
  end;
end;



procedure GrowPCharArray(var Arr: PPCharArray; var Cap: Integer; Need: Integer);
var
  NewCap: Integer;
  OldSize: Integer;
begin
  if Need <= Cap then Exit;
  NewCap := Cap;
  if NewCap = 0 then NewCap := 8;
  while NewCap < Need do NewCap := NewCap * 2;

  OldSize := Cap * SizeOf(PChar);
  Arr := PPCharArray(ReallocMem(Arr, OldSize, NewCap * SizeOf(PChar)));
  Cap := NewCap;
end;

{=============================================================================}
{ TMenuBar / TMenuItem                                                        }
{=============================================================================}

{=============================================================================}
{ TMenuBar / TMenuItem - Cascade (Agac Yapili) Yardimcilari                   }
{=============================================================================}

{ Bir menunun ve tum alt agacinin SubMenuVisible/SubHoverIndex alanlarini
  temizler (kapatir). }
procedure MenuPopupCloseAllSubMenus(Menu: PMenuItem);
var
  I: Integer;
  SubItem: PMenuItem;
begin
  if Menu = nil then Exit;
  for I := 0 to Menu^.SubCount - 1 do
  begin
    SubItem := PMenuItem(Menu^.SubItems^[I]);
    if SubItem <> nil then
    begin
      if SubItem^.SubMenuVisible then
      begin
        MenuPopupCloseAllSubMenus(SubItem);
        SubItem^.SubMenuVisible := False;
      end;
      SubItem^.SubHoverIndex := -1;
    end;
  end;
  Menu^.SubHoverIndex := -1;
end;

{ Tum agactaki SubHoverIndex degerlerini -1 yapar (cizim temizligi). }
procedure MenuPopupClearHover(Menu: PMenuItem);
var
  I: Integer;
  SubItem: PMenuItem;
begin
  if Menu = nil then Exit;
  Menu^.SubHoverIndex := -1;
  for I := 0 to Menu^.SubCount - 1 do
  begin
    SubItem := PMenuItem(Menu^.SubItems^[I]);
    if (SubItem <> nil) and SubItem^.SubMenuVisible then
      MenuPopupClearHover(SubItem);
  end;
end;

{ Bir popupun genislik/yukseklik metrigini hesaplar. }
procedure MenuPopupGetMetrics(Menu: PMenuItem; out MaxW, ItemH: Integer);
var
  I: Integer;
  SubItem: PMenuItem;
begin
  ItemH := FONT_H + 6;
  MaxW := 80;
  for I := 0 to Menu^.SubCount - 1 do
  begin
    SubItem := PMenuItem(Menu^.SubItems^[I]);
    if SubItem = nil then Continue;
    if StrLen(SubItem^.Caption) * FONT_W + 24 > MaxW then
      MaxW := StrLen(SubItem^.Caption) * FONT_W + 24;
    if SubItem^.SubCount > 0 then Inc(MaxW, 12);  { Cascade oku icin yer }
  end;
end;

{ Recursive hit-test: Acik menu agacinda MX,MY hangi item'e denk geliyor?
  HitMenu = dogrudan sahibi olan menu (parent), HitIndex = item sirasi. }
function MenuPopupHitTestRecursive(Menu: PMenuItem; AbsX, AbsY, MX, MY: Integer;
  out HitMenu: PMenuItem; out HitIndex: Integer): Boolean;
var
  I, ItemH, MaxW, ItemY: Integer;
  SubItem: PMenuItem;
begin
  Result := False;
  HitMenu := nil;
  HitIndex := -1;
  if (Menu = nil) or (Menu^.SubCount = 0) or not Menu^.SubMenuVisible then Exit;

  MenuPopupGetMetrics(Menu, MaxW, ItemH);
  ItemY := AbsY + 1;

  for I := 0 to Menu^.SubCount - 1 do
  begin
    SubItem := PMenuItem(Menu^.SubItems^[I]);
    if SubItem = nil then begin Inc(ItemY, ItemH); Continue; end;

    { Bu item'in uzerinde mi? }
    if (MX >= AbsX + 1) and (MX < AbsX + MaxW - 1) and
       (MY >= ItemY) and (MY < ItemY + ItemH) then
    begin
      HitMenu := Menu;
      HitIndex := I;
      Result := True;
      Exit;
    end;

    { Bu item aciksa, onun sagindaki submenuleri de kontrol et }
    if SubItem^.SubMenuVisible and (SubItem^.SubCount > 0) then
      if MenuPopupHitTestRecursive(SubItem, AbsX + MaxW, ItemY, MX, MY, HitMenu, HitIndex) then
      begin
        Result := True;
        Exit;
      end;

    Inc(ItemY, ItemH);
  end;
end;

{ Popup uzerinde MouseDown olayi: Item varsa click veya ac, yoksa kapat. }
procedure MenuPopupProcessMouseDown(MenuBar: PMenuBar; MX, MY: Integer;
  out Handled: Boolean; out ClickedItem: PMenuItem);
var
  RootItem, HitMenu: PMenuItem;
  HitIndex, I: Integer;
  AbsX, AbsY: Integer;
  SubItem2: PMenuItem;
begin
  Handled := False;
  ClickedItem := nil;
  if (MenuBar = nil) or (MenuBar^.ActiveIndex < 0) then Exit;

  RootItem := PMenuItem(MenuBar^.Items^[MenuBar^.ActiveIndex]);
  if (RootItem = nil) or not RootItem^.SubMenuVisible then Exit;

  AbsX := MenuBar^.PopupAbsX + RootItem^.ItemLeft;
  AbsY := MenuBar^.PopupAbsY;

  if not MenuPopupHitTestRecursive(RootItem, AbsX, AbsY, MX, MY, HitMenu, HitIndex) then
    Exit;  { Popup disina tiklandi -> ust fonksiyon kapatsin }

  if (HitMenu = nil) or (HitIndex < 0) or (HitIndex >= HitMenu^.SubCount) then Exit;

  ClickedItem := PMenuItem(HitMenu^.SubItems^[HitIndex]);
  if (ClickedItem = nil) or not ClickedItem^.Enabled {or ClickedItem^.Separator} then
  begin
    Handled := True;  { Separator veya disabled -> sadece olayi yut }
    Exit;
  end;

  { Eger alt menusu varsa ac; yoksa click tetikle ve tum agaci kapat }
  if ClickedItem^.SubCount > 0 then
  begin
    { Ayni seviyedeki diger acik kardes submenuleri kapat }
    for I := 0 to HitMenu^.SubCount - 1 do
      if I <> HitIndex then
      begin
        SubItem2 := PMenuItem(HitMenu^.SubItems^[I]);
        if (SubItem2 <> nil) and SubItem2^.SubMenuVisible then
        begin
          MenuPopupCloseAllSubMenus(SubItem2);
          SubItem2^.SubMenuVisible := False;
        end;
      end;
    ClickedItem^.SubMenuVisible := True;
    ClickedItem^.SubHoverIndex := -1;
  end
  else
  begin
    { Yaprak dugum -> OnClick calistir ve kapat }
    if Assigned(ClickedItem^.OnClick) then
      ClickedItem^.OnClick(PObject(ClickedItem));
    MenuPopupCloseAllSubMenus(RootItem);
    RootItem^.SubMenuVisible := False;
    MenuBar^.ActiveIndex := -1;
    WinManager.ActiveMenuBar := nil;
  end;
  Handled := True;
end;

{ Popup uzerinde MouseMove: Hover index guncelle ve alt menuleri otomatik ac. }
procedure MenuPopupProcessMouseMove(MenuBar: PMenuBar; MX, MY: Integer);
var
  RootItem, HitMenu: PMenuItem;
  HitIndex, I: Integer;
  AbsX, AbsY: Integer;
  SubItem, SubItem2: PMenuItem;
begin
  if (MenuBar = nil) or (MenuBar^.ActiveIndex < 0) then Exit;

  RootItem := PMenuItem(MenuBar^.Items^[MenuBar^.ActiveIndex]);
  if (RootItem = nil) or not RootItem^.SubMenuVisible then Exit;

  AbsX := MenuBar^.PopupAbsX + RootItem^.ItemLeft;
  AbsY := MenuBar^.PopupAbsY;

  { Once tum agactaki hover'lari temizle }
  MenuPopupClearHover(RootItem);

  { Recursive hit test }
  if not MenuPopupHitTestRecursive(RootItem, AbsX, AbsY, MX, MY, HitMenu, HitIndex) then
    Exit;

  if (HitMenu = nil) or (HitIndex < 0) or (HitIndex >= HitMenu^.SubCount) then Exit;

  HitMenu^.SubHoverIndex := HitIndex;
  SubItem := PMenuItem(HitMenu^.SubItems^[HitIndex]);

  if (SubItem <> nil) and (SubItem^.SubCount > 0) and SubItem^.Enabled then
  begin
    { Uzerine gelince alt menusunu ac; diger kardeslerinkini kapat }
    if not SubItem^.SubMenuVisible then
    begin
      for I := 0 to HitMenu^.SubCount - 1 do
        if I <> HitIndex then
        begin
          SubItem2 := PMenuItem(HitMenu^.SubItems^[I]);
          if (SubItem2 <> nil) and SubItem2^.SubMenuVisible then
          begin
            MenuPopupCloseAllSubMenus(SubItem2);
            SubItem2^.SubMenuVisible := False;
          end;
        end;
      SubItem^.SubMenuVisible := True;
      SubItem^.SubHoverIndex := -1;
    end;
  end;
end;

procedure MenuItemAddSubItem(Parent, Child: PMenuItem);
var
  OldCap: Integer;
  OldSize: Integer;
begin
  if Parent^.SubCount >= Parent^.SubCapacity then
  begin
    OldCap := Parent^.SubCapacity;
    if Parent^.SubCapacity = 0 then
      Parent^.SubCapacity := 8
    else
      Parent^.SubCapacity := Parent^.SubCapacity * 2;

    OldSize := OldCap * SizeOf(PMenuItem);
    Parent^.SubItems := PPCharArray(ReallocMem(Parent^.SubItems, OldSize,
                              Parent^.SubCapacity * SizeOf(PMenuItem)));
  end;
  Parent^.SubItems^[Parent^.SubCount] := PChar(Child);
  Inc(Parent^.SubCount);
  Child^.Parent := PObject(Parent);
end;

procedure MenuBarAddItem(Sender: PMenuBar; Item: PMenuItem);
var
  OldCap: Integer;
  OldSize: Integer;
begin
  if Sender^.ItemCount >= Sender^.ItemCapacity then
  begin
    OldCap := Sender^.ItemCapacity;
    if Sender^.ItemCapacity = 0 then
      Sender^.ItemCapacity := 8
    else
      Sender^.ItemCapacity := Sender^.ItemCapacity * 2;

    OldSize := OldCap * SizeOf(PMenuItem);
    Sender^.Items := PPCharArray(ReallocMem(Sender^.Items, OldSize,
                            Sender^.ItemCapacity * SizeOf(PMenuItem)));
  end;
  Sender^.Items^[Sender^.ItemCount] := PChar(Item);
  Inc(Sender^.ItemCount);
  Item^.Parent := PObject(Sender);
end;

{=============================================================================}
{ TLabel                                                                      }
{=============================================================================}

procedure LabelDraw(Sender: PLabel; AbsX, AbsY: Integer);
var
  TxtColor: LongWord;
  Tx, Ty: Integer;
begin
  if not Sender^.Transparent then
    KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, Sender^.Color);

  if Sender^.Enabled then
    TxtColor := clBlack
  else
    TxtColor := clGray;

  Ty := AbsY + (Sender^.Height - FONT_H) div 2;

  if Sender^.Shadow then
  begin
    case Sender^.Alignment of
      0: KStr(AbsX + 1, Ty + 1, Sender^.Caption, Sender^.ShadowColor);
      1: KStrCentered(AbsX + 1, Ty + 1, Sender^.Width, Sender^.Caption, Sender^.ShadowColor);
      2: KStrRight(AbsX + 1, Ty + 1, Sender^.Width, Sender^.Caption, Sender^.ShadowColor);
    end;
  end;

  case Sender^.Alignment of
    0: KStr(AbsX, Ty, Sender^.Caption, TxtColor);
    1: KStrCentered(AbsX, Ty, Sender^.Width, Sender^.Caption, TxtColor);
    2: KStrRight(AbsX, Ty, Sender^.Width, Sender^.Caption, TxtColor);
  end;
end;

function CreateLabel(AParent: PObject; const ACaption: PChar; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign): PLabel;
begin
  Result := PLabel(MemAlloc(SizeOf(TLabel)));
  FillChar(Result^, SizeOf(TLabel), #0);
  if ACaption <> nil then
    Move(ACaption[0], Result^.Caption[0], StrLen(ACaption));
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := clBtnFace;
  Result^.BorderWidth := 0;
  Result^.ShowCaption := False;
  Result^.Cursor := 0;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.Alignment := 0;
  Result^.Transparent := True;
  Result^.Shadow := False;
  Result^.ShadowColor := clGray;
  Result^.BindPaint(@LabelDraw);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TEdit                                                                       }
{=============================================================================}

procedure EditSetText(Edit: PEdit; const AText: PChar);
var
  Len: Integer;
begin
  Len := StrLen(AText);
  if Len > 255 then Len := 255;
  Move(AText^, Edit^.Text[0], Len);
  Edit^.Text[Len] := #0;
  Edit^.CaretPos := Len;
  Edit^.SelStart := 0;
  Edit^.SelLength := 0;
end;

procedure EditGetText(Edit: PEdit;var Dst:array of char;N:Integer);
begin
  StrCopyN(Dst,@Edit^.Text[0],N);
end;

procedure EditInsertChar(Edit: PEdit; Ch: Char);
var
  Len, I: Integer;
begin
  if Edit^.ReadOnly then Exit;
  Len := StrLen(Edit^.Text);
  if (Edit^.MaxLength > 0) and (Len >= Edit^.MaxLength) then Exit;
  if Len >= 255 then Exit;

  if Edit^.SelLength > 0 then
  begin
    for I := Edit^.SelStart to Len - Edit^.SelLength do
      Edit^.Text[I] := Edit^.Text[I + Edit^.SelLength];
    Edit^.CaretPos := Edit^.SelStart;
    Edit^.SelLength := 0;
    Len := StrLen(Edit^.Text);
  end;

  for I := Len downto Edit^.CaretPos do
    Edit^.Text[I + 1] := Edit^.Text[I];
  Edit^.Text[Edit^.CaretPos] := Ch;
  Inc(Edit^.CaretPos);
end;

procedure EditDeleteChar(Edit: PEdit);
var
  Len, I: Integer;
begin
  if Edit^.ReadOnly then Exit;
  Len := StrLen(Edit^.Text);
  if Edit^.CaretPos >= Len then Exit;
  for I := Edit^.CaretPos to Len - 1 do
    Edit^.Text[I] := Edit^.Text[I + 1];
  Edit^.Text[Len] := #0;
end;

procedure EditBackspace(Edit: PEdit);
var
  Len, I: Integer;
begin
  if Edit^.ReadOnly then Exit;
  if Edit^.SelLength > 0 then
  begin
    EditDeleteChar(Edit);
    Exit;
  end;
  if Edit^.CaretPos <= 0 then Exit;
  Dec(Edit^.CaretPos);
  Len := StrLen(Edit^.Text);
  for I := Edit^.CaretPos to Len - 1 do
    Edit^.Text[I] := Edit^.Text[I + 1];
  Edit^.Text[Len] := #0;
end;

procedure EditKeyDown(Sender: PEdit; Key: Word);
begin
  case Key of
    VK_LEFT:  if Sender^.CaretPos > 0 then Dec(Sender^.CaretPos);
    VK_RIGHT: if Sender^.CaretPos < StrLen(Sender^.Text) then Inc(Sender^.CaretPos);
    VK_HOME:  Sender^.CaretPos := 0;
    VK_END:   Sender^.CaretPos := StrLen(Sender^.Text);
    VK_DELETE: EditDeleteChar(Sender);
    VK_BACK:   EditBackspace(Sender);
    else

     if (Key >= $100 + 32) and (Key <= $100 + 126) then
        EditInsertChar(Sender, Char(Key - $100))



  end;
  Sender^.SelLength := 0;
end;

procedure EditMouseDown(Sender: PEdit; AX, AY: Integer; Btn: Byte);
var
  NewPos: Integer;
begin
  if Btn <> 1 then Exit;
  NewPos := (AX - 3) div FONT_W;
  if NewPos < 0 then NewPos := 0;
  if NewPos > StrLen(Sender^.Text) then NewPos := StrLen(Sender^.Text);
  Sender^.CaretPos := NewPos;
  Sender^.SelStart := NewPos;
  Sender^.SelLength := 0;
end;

procedure EditDraw(Sender: PEdit; AbsX, AbsY: Integer);
var
  TxtColor: LongWord;
  DisplayText: array[0..255] of Char;
  I, Len, CX: Integer;
begin
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, C_EDIT_BG);

 

  KLineH(AbsX, AbsY, Sender^.Width, cl3DDkShadow);
  KLineV(AbsX, AbsY, Sender^.Height, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.Height - 1, Sender^.Width, cl3DHighLight);
  KLineV(AbsX + Sender^.Width - 1, AbsY, Sender^.Height, cl3DHighLight);

  KLineH(AbsX + 1, AbsY + 1, Sender^.Width - 2, clBlack);
  KLineV(AbsX + 1, AbsY + 1, Sender^.Height - 2, clBlack);
  KLineH(AbsX + 1, AbsY + Sender^.Height - 2, Sender^.Width - 2, clWhite);
  KLineV(AbsX + Sender^.Width - 2, AbsY + 1, Sender^.Height - 2, clWhite);


   if Sender^.Focused then KRect(AbsX+1,AbsY+1,Sender^.Width-2,Sender^.Height-2,$0078D7)
  else           KRect(AbsX+1,AbsY+1,Sender^.Width-2,Sender^.Height-2,$AAAAAA);

  if Sender^.Enabled then TxtColor := clBlack else TxtColor := clGray;

  Len := StrLen(Sender^.Text);
  if Sender^.PasswordChar <> #0 then
  begin
    for I := 0 to Len - 1 do
      DisplayText[I] := Sender^.PasswordChar;
    DisplayText[Len] := #0;
  end
  else
    Move(Sender^.Text[0], DisplayText[0], Len + 1);

  KStrClip(AbsX + 3, AbsY + (Sender^.Height - FONT_H) div 2,
           @DisplayText[0], TxtColor,
           AbsX + 2, AbsY + 2, Sender^.Width - 4, Sender^.Height - 4);

  if   Sender^.Enabled and ((GetTickCount div 500) mod 2 = 0) then
  begin
    CX := AbsX + 3 + Sender^.CaretPos * FONT_W;
    if CX < AbsX + Sender^.Width - 2 then
      KLineV(CX, AbsY + 4, Sender^.Height - 8, clBlack);
  end;
end;

function CreateEdit(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign): PEdit;
begin
  Result := PEdit(MemAlloc(SizeOf(TEdit)));
  FillChar(Result^, SizeOf(TEdit), #0);
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  if AHeight < 1 then Result^.Height := 22 else Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := C_EDIT_BG;
  Result^.BorderWidth := 2;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.CaretPos := 0;
  Result^.SelStart := 0;
  Result^.SelLength := 0;
  Result^.ReadOnly := False;
  Result^.PasswordChar := #0;
  Result^.MaxLength := 0;
  Result^.BorderStyle := 1;
  Result^.CanFocus := True;
  Result^.TabStop  := True;   { <-- BUNU EKLEY�N }

  Result^.BindPaint(@EditDraw);
  Result^.BindMouseDown(@EditMouseDown);
  Result^.BindKeyDown(@EditKeyDown);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TMemo                                                                       }
{=============================================================================}

{=============================================================================}
{ TMemo Scrollbar Yardimcilari                                                }
{=============================================================================}
procedure MemoGrow(Memo: PMemo; NewCapacity: Integer);
var
  NewLines: PPCharArray;
  NewCap: Integer;
  I: Integer;
begin
  if NewCapacity <= Memo^.LineCapacity then Exit;
  NewCap := Memo^.LineCapacity;
  if NewCap = 0 then NewCap := 16;
  while NewCap < NewCapacity do NewCap := NewCap * 2;
  NewLines := PPCharArray(MemAlloc(NewCap * SizeOf(PChar)));
  if Memo^.Lines <> nil then
  begin
    for I := 0 to Memo^.LineCount - 1 do
      NewLines^[I] := Memo^.Lines^[I];
    FreeMem(Memo^.Lines);
  end;
  Memo^.Lines := NewLines;
  Memo^.LineCapacity := NewCap;
end;




procedure MemoAddLine(Memo: PMemo; const ALine: PChar);
var
  Len: Integer;
  P: PChar;
begin
  if Memo^.LineCount >= Memo^.LineCapacity then
    MemoGrow(Memo, Memo^.LineCount + 1);
  Len := StrLen(ALine);
  P := PChar(MemAlloc(Len + 1));
  if P <> nil then
  begin
    Move(ALine^, P^, Len + 1);
    Memo^.Lines^[Memo^.LineCount] := P;
    Inc(Memo^.LineCount);
  end;
end;

procedure MemoClear(Memo: PMemo);
var
  I: Integer;
begin
  for I := 0 to Memo^.LineCount - 1 do
    if Memo^.Lines^[I] <> nil then
      FreeMem(Memo^.Lines^[I]);
  Memo^.LineCount := 0;
  Memo^.CaretX := 0;
  Memo^.CaretY := 0;
  Memo^.SelStartX := 0;
  Memo^.SelStartY := 0;
  Memo^.SelActive := False;
end;

{ TObject.FireDestroy tarafindan (FreeObject icinden) cagirilir. MemoClear
  ile satirlarin PChar buferlerini, ardindan Lines dizisinin kendisini
  (MemoGrow/MemAlloc ile ayrilmis blok) serbest birakir - aksi halde her
  Memo yok edildiginde bu bellek sizardi. }
procedure MemoDestroy(Sender: PObject);
var
  Memo: PMemo;
begin
  Memo := PMemo(Sender);
  MemoClear(Memo);
  if Memo^.Lines <> nil then
  begin
    FreeMem(Memo^.Lines);
    Memo^.Lines := nil;
  end;
  Memo^.LineCapacity := 0;
end;

procedure MemoSetText(Memo: PMemo; const AText: PChar);
var
  Start, P: PChar;
  Buf: array[0..1023] of Char;
  Len: Integer;
begin
  MemoClear(Memo);
  if AText = nil then Exit;
  Start := AText;
  P := Start;
  while P^ <> #0 do
  begin
    if (P^ = #13) or (P^ = #10) then
    begin
      Len := P - Start;
      if Len > 1023 then Len := 1023;
      if Len > 0 then Move(Start^, Buf[0], Len);
      Buf[Len] := #0;
      MemoAddLine(Memo, @Buf[0]);
      if (P^ = #13) and ((P + 1)^ = #10) then Inc(P);
      Inc(P);
      Start := P;
    end
    else
      Inc(P);
  end;
  if Start <> P then
  begin
    Len := P - Start;
    if Len > 1023 then Len := 1023;
    Move(Start^, Buf[0], Len);
    Buf[Len] := #0;
    MemoAddLine(Memo, @Buf[0]);
  end;
  if Memo^.LineCount = 0 then
    MemoAddLine(Memo, '');
end;



function MemoGetLine(Memo: PMemo; Index: Integer): PChar;
begin
  if (Index < 0) or (Index >= Memo^.LineCount) then
    Result := nil
  else
    Result := Memo^.Lines^[Index];
end;

function MemoLineLength(Memo: PMemo; Index: Integer): Integer;
var
  P: PChar;
begin
  P := MemoGetLine(Memo, Index);
  if P = nil then Result := 0 else Result := StrLen(P);
end;

procedure MemoDeleteSelection(Memo: PMemo);
var
  SX, SY, EX, EY, I: Integer;
  Line: PChar;
  LineLen: Integer;
  NewLine: PChar;
  NewLen, PreLen, PostLen: Integer;
begin
  if not Memo^.SelActive then Exit;
  if Memo^.SelStartY < Memo^.CaretY then
  begin
    SX := Memo^.SelStartX; SY := Memo^.SelStartY;
    EX := Memo^.CaretX;    EY := Memo^.CaretY;
  end
  else if Memo^.SelStartY > Memo^.CaretY then
  begin
    SX := Memo^.CaretX;    SY := Memo^.CaretY;
    EX := Memo^.SelStartX; EY := Memo^.SelStartY;
  end
  else
  begin
    SY := Memo^.SelStartY; EY := Memo^.CaretY;
    if Memo^.SelStartX < Memo^.CaretX then
    begin
      SX := Memo^.SelStartX; EX := Memo^.CaretX;
    end
    else
    begin
      SX := Memo^.CaretX; EX := Memo^.SelStartX;
    end;
  end;
  if (SX = EX) and (SY = EY) then
  begin
    Memo^.SelActive := False;
    Exit;
  end;
  if SY = EY then
  begin
    Line := Memo^.Lines^[SY];
    LineLen := StrLen(Line);
    PreLen := SX;
    PostLen := LineLen - EX;
    NewLen := PreLen + PostLen;
    NewLine := PChar(MemAlloc(NewLen + 1));
    if NewLine <> nil then
    begin
      if PreLen > 0 then Move(Line^, NewLine^, PreLen);
      if PostLen > 0 then Move(Line[EX], NewLine[PreLen], PostLen);
      NewLine[NewLen] := #0;
      FreeMem(Line);
      Memo^.Lines^[SY] := NewLine;
    end;
    Memo^.CaretX := SX;
    Memo^.CaretY := SY;
  end
  else
  begin
    Line := Memo^.Lines^[SY];
    LineLen := StrLen(Line);
    PreLen := SX;
    NewLine := PChar(MemAlloc(PreLen + 1));
    if NewLine <> nil then
    begin
      if PreLen > 0 then Move(Line^, NewLine^, PreLen);
      NewLine[PreLen] := #0;
      FreeMem(Line);
      Memo^.Lines^[SY] := NewLine;
    end;
    for I := SY + 1 to EY - 1 do
      if Memo^.Lines^[I] <> nil then
        FreeMem(Memo^.Lines^[I]);
    if EY < Memo^.LineCount then
    begin
      Line := Memo^.Lines^[EY];
      LineLen := StrLen(Line);
      PostLen := LineLen - EX;
      if PostLen > 0 then
      begin
        NewLen := PreLen + PostLen;
        NewLine := PChar(MemAlloc(NewLen + 1));
        if NewLine <> nil then
        begin
          if PreLen > 0 then Move(Memo^.Lines^[SY]^, NewLine^, PreLen);
          Move(Line[EX], NewLine[PreLen], PostLen);
          NewLine[NewLen] := #0;
          FreeMem(Memo^.Lines^[SY]);
          Memo^.Lines^[SY] := NewLine;
        end;
      end;
      FreeMem(Line);
    end;
    for I := EY + 1 to Memo^.LineCount - 1 do
      Memo^.Lines^[I - (EY - SY)] := Memo^.Lines^[I];
    Dec(Memo^.LineCount, EY - SY);
    Memo^.CaretX := SX;
    Memo^.CaretY := SY;
  end;
  Memo^.SelActive := False;
end;

procedure MemoInsertChar(Memo: PMemo; Ch: Char);
var
  Line: PChar;
  LineLen: Integer;
  NewLine: PChar;
  I: Integer;
begin
  if Memo^.ReadOnly then Exit;
  if Memo^.SelActive then MemoDeleteSelection(Memo);
  if (Ch = #13) or (Ch = #10) then
  begin
    Line := Memo^.Lines^[Memo^.CaretY];
    LineLen := StrLen(Line);
    if Memo^.LineCount >= Memo^.LineCapacity then
      MemoGrow(Memo, Memo^.LineCount + 1);
    for I := Memo^.LineCount downto Memo^.CaretY + 2 do
      Memo^.Lines^[I] := Memo^.Lines^[I - 1];
    NewLine := PChar(MemAlloc(LineLen - Memo^.CaretX + 1));
    if NewLine <> nil then
    begin
      if Memo^.CaretX < LineLen then
        Move(Line[Memo^.CaretX], NewLine^, LineLen - Memo^.CaretX);
      NewLine[LineLen - Memo^.CaretX] := #0;
    end;
    Line[Memo^.CaretX] := #0;
    Memo^.Lines^[Memo^.CaretY + 1] := NewLine;
    Inc(Memo^.LineCount);
    Memo^.CaretX := 0;
    Inc(Memo^.CaretY);
    Exit;
  end;
  Line := Memo^.Lines^[Memo^.CaretY];
  LineLen := StrLen(Line);
  NewLine := PChar(MemAlloc(LineLen + 2));
  if NewLine = nil then Exit;
  if Memo^.CaretX > 0 then
    Move(Line^, NewLine^, Memo^.CaretX);
  NewLine[Memo^.CaretX] := Ch;
  if Memo^.CaretX < LineLen then
    Move(Line[Memo^.CaretX], NewLine[Memo^.CaretX + 1], LineLen - Memo^.CaretX);
  NewLine[LineLen + 1] := #0;
  FreeMem(Line);
  Memo^.Lines^[Memo^.CaretY] := NewLine;
  Inc(Memo^.CaretX);
end;

procedure MemoBackspace(Memo: PMemo);
var
  Line: PChar;
  LineLen: Integer;
  NewLine: PChar;
  PrevLine: PChar;
  I:Integer;
  PrevLen: Integer;
begin
  if Memo^.ReadOnly then Exit;
  if Memo^.SelActive then
  begin
    MemoDeleteSelection(Memo);
    Exit;
  end;
  if Memo^.CaretX > 0 then
  begin
    Line := Memo^.Lines^[Memo^.CaretY];
    LineLen := StrLen(Line);
    NewLine := PChar(MemAlloc(LineLen));
    if NewLine = nil then Exit;
    if Memo^.CaretX > 1 then
      Move(Line^, NewLine^, Memo^.CaretX - 1);
    if Memo^.CaretX <= LineLen then
      Move(Line[Memo^.CaretX], NewLine[Memo^.CaretX - 1], LineLen - Memo^.CaretX + 1);
    FreeMem(Line);
    Memo^.Lines^[Memo^.CaretY] := NewLine;
    Dec(Memo^.CaretX);
  end
  else if Memo^.CaretY > 0 then
  begin
    Line := Memo^.Lines^[Memo^.CaretY];
    LineLen := StrLen(Line);
    PrevLine := Memo^.Lines^[Memo^.CaretY - 1];
    PrevLen := StrLen(PrevLine);
    NewLine := PChar(MemAlloc(PrevLen + LineLen + 1));
    if NewLine <> nil then
    begin
      if PrevLen > 0 then Move(PrevLine^, NewLine^, PrevLen);
      if LineLen > 0 then Move(Line^, NewLine[PrevLen], LineLen);
      NewLine[PrevLen + LineLen] := #0;
      FreeMem(PrevLine);
      Memo^.Lines^[Memo^.CaretY - 1] := NewLine;
    end;
    FreeMem(Line);
    for I := Memo^.CaretY + 1 to Memo^.LineCount - 1 do
      Memo^.Lines^[I - 1] := Memo^.Lines^[I];
    Dec(Memo^.LineCount);
    Dec(Memo^.CaretY);
    Memo^.CaretX := PrevLen;
  end;
end;

procedure MemoUpdateScrollbars(Memo: PMemo);
var
  CW, CH: Integer;
  I, MaxLineLen: Integer;
  Line: PChar;
  VisibleLines, VisibleCols: Integer;
  VTrackLen, HTrackLen: Integer;
begin
  CW := Memo^.Width - 4;
  CH := Memo^.Height - 4;

  MaxLineLen := 0;
  for I := 0 to Memo^.LineCount - 1 do
  begin
    Line := MemoGetLine(Memo, I);
    if Line <> nil then
      if StrLen(Line) > MaxLineLen then MaxLineLen := StrLen(Line);
  end;

  Memo^.VScrollVisible := Memo^.LineCount * FONT_H > CH;
  Memo^.HScrollVisible := MaxLineLen * FONT_W > CW;

  if Memo^.VScrollVisible and Memo^.HScrollVisible then
  begin
    Dec(CW, SCROLLBAR_SIZE);
    Dec(CH, SCROLLBAR_SIZE);
    if Memo^.LineCount * FONT_H <= CH then Memo^.VScrollVisible := False;
    if MaxLineLen * FONT_W <= CW then Memo^.HScrollVisible := False;
  end;

  if Memo^.VScrollVisible then
  begin
    VTrackLen := Memo^.Height - 4 - SCROLLBAR_SIZE * 2;
    if Memo^.HScrollVisible then Dec(VTrackLen, SCROLLBAR_SIZE);
    if VTrackLen < 0 then VTrackLen := 0;

    VisibleLines := CH div FONT_H;
    if VisibleLines < 1 then VisibleLines := 1;
    Memo^.VScrollMax := Memo^.LineCount - VisibleLines;
    if Memo^.VScrollMax < 0 then Memo^.VScrollMax := 0;
    if Memo^.ScrollY > Memo^.VScrollMax then Memo^.ScrollY := Memo^.VScrollMax;

    Memo^.VThumbSize := Max(SCROLLBAR_SIZE, CH * VTrackLen div (Memo^.LineCount * FONT_H));
    if Memo^.VThumbSize > VTrackLen then Memo^.VThumbSize := VTrackLen;

    if Memo^.VScrollMax > 0 then
      Memo^.VThumbPos := 2 + SCROLLBAR_SIZE + Memo^.ScrollY * (VTrackLen - Memo^.VThumbSize) div Memo^.VScrollMax
    else
      Memo^.VThumbPos := 2 + SCROLLBAR_SIZE;
  end
  else
  begin
    Memo^.ScrollY := 0;
    Memo^.VThumbPos := 2 + SCROLLBAR_SIZE;
    Memo^.VScrollMax := 0;
  end;

  if Memo^.HScrollVisible then
  begin
    HTrackLen := Memo^.Width - 4 - SCROLLBAR_SIZE * 2;
    if Memo^.VScrollVisible then Dec(HTrackLen, SCROLLBAR_SIZE);
    if HTrackLen < 0 then HTrackLen := 0;

    VisibleCols := CW div FONT_W;
    if VisibleCols < 1 then VisibleCols := 1;
    Memo^.HScrollMax := MaxLineLen - VisibleCols;
    if Memo^.HScrollMax < 0 then Memo^.HScrollMax := 0;
    if Memo^.ScrollX > Memo^.HScrollMax then Memo^.ScrollX := Memo^.HScrollMax;

    Memo^.HThumbSize := Max(SCROLLBAR_SIZE, CW * HTrackLen div (MaxLineLen * FONT_W));
    if Memo^.HThumbSize > HTrackLen then Memo^.HThumbSize := HTrackLen;

    if Memo^.HScrollMax > 0 then
      Memo^.HThumbPos := 2 + SCROLLBAR_SIZE + Memo^.ScrollX * (HTrackLen - Memo^.HThumbSize) div Memo^.HScrollMax
    else
      Memo^.HThumbPos := 2 + SCROLLBAR_SIZE;
  end
  else
  begin
    Memo^.ScrollX := 0;
    Memo^.HThumbPos := 2 + SCROLLBAR_SIZE;
    Memo^.HScrollMax := 0;
  end;
end;

function MemoVScrollHitTest(Memo: PMemo; AX, AY: Integer; out Part: Integer): Boolean;
var
  SX, SY, SW, SH: Integer;
begin
  Result := False;
  Part := -1;
  if not Memo^.VScrollVisible then Exit;

  SX := Memo^.Width - 2 - SCROLLBAR_SIZE;
  SY := 2;
  SW := SCROLLBAR_SIZE;
  SH := Memo^.Height - 4;
  if Memo^.HScrollVisible then Dec(SH, SCROLLBAR_SIZE);

  if (AX < SX) or (AX >= SX + SW) or (AY < SY) or (AY >= SY + SH) then Exit;

  if AY < SY + SCROLLBAR_SIZE then begin Part := 0; Result := True; Exit; end; { Yukari ok }
  if AY >= SY + SH - SCROLLBAR_SIZE then begin Part := 1; Result := True; Exit; end; { Asagi ok }
  if (AY >= Memo^.VThumbPos) and (AY < Memo^.VThumbPos + Memo^.VThumbSize) then begin Part := 4; Result := True; Exit; end; { Thumb }
  if AY < Memo^.VThumbPos then begin Part := 2; Result := True; Exit; end; { Page up }
  Part := 3; Result := True; { Page down }
end;

function MemoHScrollHitTest(Memo: PMemo; AX, AY: Integer; out Part: Integer): Boolean;
var
  SX, SY, SW, SH: Integer;
begin
  Result := False;
  Part := -1;
  if not Memo^.HScrollVisible then Exit;

  SX := 2;
  SY := Memo^.Height - 2 - SCROLLBAR_SIZE;
  SW := Memo^.Width - 4;
  if Memo^.VScrollVisible then Dec(SW, SCROLLBAR_SIZE);
  SH := SCROLLBAR_SIZE;

  if (AX < SX) or (AX >= SX + SW) or (AY < SY) or (AY >= SY + SH) then Exit;

  if AX < SX + SCROLLBAR_SIZE then begin Part := 0; Result := True; Exit; end; { Sol ok }
  if AX >= SX + SW - SCROLLBAR_SIZE then begin Part := 1; Result := True; Exit; end; { Sag ok }
  if (AX >= Memo^.HThumbPos) and (AX < Memo^.HThumbPos + Memo^.HThumbSize) then begin Part := 4; Result := True; Exit; end; { Thumb }
  if AX < Memo^.HThumbPos then begin Part := 2; Result := True; Exit; end; { Page left }
  Part := 3; Result := True; { Page right }
end;


{ T�m metni se� }
procedure MemoSelectAll(Memo: PMemo);
begin
  if Memo^.LineCount = 0 then Exit;
  Memo^.SelStartX := 0;
  Memo^.SelStartY := 0;
  Memo^.CaretY := Memo^.LineCount - 1;
  Memo^.CaretX := MemoLineLength(Memo, Memo^.LineCount - 1);
  Memo^.SelActive := True;
end;

{ Se�ili metni i� panoya kopyala }
procedure MemoCopy(Memo: PMemo);
var
  SX, SY, EX, EY, I, J, Len, TotalLen, Pos: Integer;
  Line, P: PChar;
begin
  if not Memo^.SelActive then Exit;

  { Se�im koordinatlar�n� normalize et (soldan sa�a, yukar�dan a�a��ya) }
  if Memo^.SelStartY < Memo^.CaretY then
  begin
    SX := Memo^.SelStartX; SY := Memo^.SelStartY;
    EX := Memo^.CaretX;    EY := Memo^.CaretY;
  end
  else if Memo^.SelStartY > Memo^.CaretY then
  begin
    SX := Memo^.CaretX;    SY := Memo^.CaretY;
    EX := Memo^.SelStartX; EY := Memo^.SelStartY;
  end
  else
  begin
    SY := Memo^.SelStartY; EY := Memo^.CaretY;
    if Memo^.SelStartX < Memo^.CaretX then
    begin
      SX := Memo^.SelStartX; EX := Memo^.CaretX;
    end
    else
    begin
      SX := Memo^.CaretX; EX := Memo^.SelStartX;
    end;
  end;

  if (SX = EX) and (SY = EY) then Exit;

  { Toplam uzunlu�u hesapla (+1'ler sat�r sonu #13 i�in) }
  TotalLen := 0;
  if SY = EY then
    TotalLen := EX - SX
  else
  begin
    Line := Memo^.Lines^[SY];
    if Line <> nil then Len := StrLen(Line) else Len := 0;
    TotalLen := TotalLen + (Len - SX) + 1;
    for I := SY + 1 to EY - 1 do
    begin
      Line := Memo^.Lines^[I];
      if Line <> nil then Len := StrLen(Line) else Len := 0;
      TotalLen := TotalLen + Len + 1;
    end;
    TotalLen := TotalLen + EX;
  end;

  P := PChar(MemAlloc(TotalLen + 1));
  if P = nil then Exit;

  Pos := 0;
  if SY = EY then
  begin
    Line := Memo^.Lines^[SY];
    for I := SX to EX - 1 do
    begin
      P[Pos] := Line[I];
      Inc(Pos);
    end;
  end
  else
  begin
    Line := Memo^.Lines^[SY];
    if Line <> nil then
    begin
      Len := StrLen(Line);
      for I := SX to Len - 1 do
      begin
        P[Pos] := Line[I];
        Inc(Pos);
      end;
    end;
    P[Pos] := #13; Inc(Pos);

    for I := SY + 1 to EY - 1 do
    begin
      Line := Memo^.Lines^[I];
      if Line <> nil then
      begin
        Len := StrLen(Line);
        for J := 0 to Len - 1 do
        begin
          P[Pos] := Line[J];
          Inc(Pos);
        end;
      end;
      P[Pos] := #13; Inc(Pos);
    end;

    Line := Memo^.Lines^[EY];
    if Line <> nil then
    begin
      for I := 0 to EX - 1 do
      begin
        P[Pos] := Line[I];
        Inc(Pos);
      end;
    end;
  end;
  P[Pos] := #0;

  if MemoClipboard <> nil then FreeMem(MemoClipboard);
  MemoClipboard := P;
end;

{ Kopyala + Sil }
procedure MemoCut(Memo: PMemo);
begin
  MemoCopy(Memo);
  MemoDeleteSelection(Memo);
end;

{ �� panodan yap��t�r }
procedure MemoPaste(Memo: PMemo);
var
  I: Integer;
  Ch: Char;
begin
  if Memo^.ReadOnly then Exit;
  if MemoClipboard = nil then Exit;
  if Memo^.SelActive then MemoDeleteSelection(Memo);

  I := 0;
  while MemoClipboard[I] <> #0 do
  begin
    Ch := MemoClipboard[I];
    { Windows tarz� #13#10 sat�r sonlar�nda #10'u atla }
    if (Ch = #10) and (I > 0) and (MemoClipboard[I - 1] = #13) then
    begin
      Inc(I);
      Continue;
    end;
    if Ch = #13 then
      MemoInsertChar(Memo, #13)
    else
      MemoInsertChar(Memo, Ch);
    Inc(I);
  end;
end;


procedure MemoDraw(Sender: PMemo; AbsX, AbsY: Integer);
var
  I, VisibleLines, VisibleCols, CX, CY, CW, CH: Integer;
  LX: Integer;
  Line: PChar;
  SelSX, SelSY, SelEX, SelEY: Integer;
  ScrollW, ScrollH: Integer;
  X, Y, W, H: Integer;
begin
  { Arka plan & Border }
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, Sender^.Color);
  KLineH(AbsX, AbsY, Sender^.Width, cl3DDkShadow);
  KLineV(AbsX, AbsY, Sender^.Height, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.Height - 1, Sender^.Width, cl3DHighLight);
  KLineV(AbsX + Sender^.Width - 1, AbsY, Sender^.Height, cl3DHighLight);
  KLineH(AbsX + 1, AbsY + 1, Sender^.Width - 2, clBlack);
  KLineV(AbsX + 1, AbsY + 1, Sender^.Height - 2, clBlack);
  KLineH(AbsX + 1, AbsY + Sender^.Height - 2, Sender^.Width - 2, clWhite);
  KLineV(AbsX + Sender^.Width - 2, AbsY + 1, Sender^.Height - 2, clWhite);

  { Scrollbar durumunu guncelle }
  MemoUpdateScrollbars(Sender);

  { Client alani (scrollbar'lar dusulmus) }
  CX := AbsX + 2;
  CY := AbsY + 2;
  CW := Sender^.Width - 4;
  CH := Sender^.Height - 4;
  ScrollW := 0; ScrollH := 0;
  if Sender^.VScrollVisible then begin Dec(CW, SCROLLBAR_SIZE); ScrollW := SCROLLBAR_SIZE; end;
  if Sender^.HScrollVisible then begin Dec(CH, SCROLLBAR_SIZE); ScrollH := SCROLLBAR_SIZE; end;
  if CW < 0 then CW := 0;
  if CH < 0 then CH := 0;

  KFill(CX, CY, CW, CH, C_EDIT_BG);

  VisibleLines := CH div FONT_H;
  VisibleCols  := CW div FONT_W;
  if VisibleLines < 1 then VisibleLines := 1;
  if VisibleCols  < 1 then VisibleCols  := 1;

  { Secim koordinatlari }
  if Sender^.SelActive then
  begin
    if Sender^.SelStartY < Sender^.CaretY then
    begin
      SelSX := Sender^.SelStartX; SelSY := Sender^.SelStartY;
      SelEX := Sender^.CaretX;    SelEY := Sender^.CaretY;
    end
    else if Sender^.SelStartY > Sender^.CaretY then
    begin
      SelSX := Sender^.CaretX;    SelSY := Sender^.CaretY;
      SelEX := Sender^.SelStartX; SelEY := Sender^.SelStartY;
    end
    else
    begin
      SelSY := Sender^.SelStartY; SelEY := Sender^.CaretY;
      if Sender^.SelStartX < Sender^.CaretX then
      begin
        SelSX := Sender^.SelStartX; SelEX := Sender^.CaretX;
      end
      else
      begin
        SelSX := Sender^.CaretX; SelEX := Sender^.SelStartX;
      end;
    end;
  end;

  { Satirlari ciz }
  for I := 0 to VisibleLines - 1 do
  begin
    if Sender^.ScrollY + I >= Sender^.LineCount then Break;
    Line := MemoGetLine(Sender, Sender^.ScrollY + I);
    if Line = nil then Continue;

    { Secim vurgusu }
    if Sender^.SelActive then
    begin
      if (Sender^.ScrollY + I >= SelSY) and (Sender^.ScrollY + I <= SelEY) then
      begin
        if SelSY = SelEY then
        begin
          if (SelSX < Sender^.ScrollX + VisibleCols) and (SelEX > Sender^.ScrollX) then
          begin
            LX := CX + (Max(SelSX, Sender^.ScrollX) - Sender^.ScrollX) * FONT_W;
            KFill(LX, CY + I * FONT_H,
                  (Min(SelEX, Sender^.ScrollX + VisibleCols) - Max(SelSX, Sender^.ScrollX)) * FONT_W,
                  FONT_H, $00A0C8F0);
          end;
        end
        else if Sender^.ScrollY + I = SelSY then
        begin
          if SelSX < Sender^.ScrollX + VisibleCols then
          begin
            LX := CX + (Max(SelSX, Sender^.ScrollX) - Sender^.ScrollX) * FONT_W;
            KFill(LX, CY + I * FONT_H,
                  (Sender^.ScrollX + VisibleCols - Max(SelSX, Sender^.ScrollX)) * FONT_W,
                  FONT_H, $00A0C8F0);
          end;
        end
        else if Sender^.ScrollY + I = SelEY then
        begin
          if SelEX > Sender^.ScrollX then
          begin
            KFill(CX, CY + I * FONT_H,
                  (Min(SelEX, Sender^.ScrollX + VisibleCols) - Sender^.ScrollX) * FONT_W,
                  FONT_H, $00A0C8F0);
          end;
        end
        else
        begin
          KFill(CX, CY + I * FONT_H, VisibleCols * FONT_W, FONT_H, $00A0C8F0);
        end;
      end;
    end;

    { Metni ciz (ScrollX offset uygulanmis) }
    if Sender^.ScrollX < StrLen(Line) then
      KStrClip(CX, CY + I * FONT_H,
               Line + Sender^.ScrollX, clBlack,
               CX, CY, CW, CH)
    else
      KStrClip(CX, CY + I * FONT_H,
               '', clBlack,
               CX, CY, CW, CH);
  end;

  { Caret }
  if  Sender^.ShowCaret and ((GetTickCount div 500) mod 2 = 0) then
  begin
    X := CX + (Sender^.CaretX - Sender^.ScrollX) * FONT_W;
    Y := CY + (Sender^.CaretY - Sender^.ScrollY) * FONT_H;
    if (X >= CX) and (X < CX + CW) and (Y >= CY) and (Y < CY + CH) then
      KLineV(X, Y, FONT_H, clBlack);
  end;

  { --- Dikey Scrollbar --- }
  if Sender^.VScrollVisible then
  begin
    X := AbsX + Sender^.Width - 2 - SCROLLBAR_SIZE;
    Y := AbsY + 2;
    W := SCROLLBAR_SIZE;
    H := Sender^.Height - 4;
    if Sender^.HScrollVisible then Dec(H, SCROLLBAR_SIZE);

    KFill(X, Y, W, H, clBtnFace);
    KRect(X, Y, W, H, cl3DShadow);

    { Yukari ok }
    KButton3D(X+1, Y, W-2, SCROLLBAR_SIZE, Sender^.VArrow1Pressed, clBtnFace);
    KLine(X + W div 2, Y + 4, X + W div 2 - 3, Y + 8, clBlack);
    KLine(X + W div 2, Y + 4, X + W div 2 + 3, Y + 8, clBlack);

    { Asagi ok }
    KButton3D(X+1, Y + H - SCROLLBAR_SIZE, W-2, SCROLLBAR_SIZE, Sender^.VArrow2Pressed, clBtnFace);
    KLine(X + W div 2 - 3, Y + H - SCROLLBAR_SIZE + 4, X + W div 2, Y + H - SCROLLBAR_SIZE + 8, clBlack);
    KLine(X + W div 2, Y + H - SCROLLBAR_SIZE + 8, X + W div 2 + 3, Y + H - SCROLLBAR_SIZE + 4, clBlack);

    { Thumb }
    if Sender^.VThumbSize > 0 then
      KButton3D(X+1, AbsY + Sender^.VThumbPos, W-2, Sender^.VThumbSize,
                Sender^.VDragging, clSilver);
  end;

  { --- Yatay Scrollbar --- }
  if Sender^.HScrollVisible then
  begin
    X := AbsX + 2;
    Y := AbsY + Sender^.Height - 2 - SCROLLBAR_SIZE;
    W := Sender^.Width - 4;
    if Sender^.VScrollVisible then Dec(W, SCROLLBAR_SIZE);
    H := SCROLLBAR_SIZE;

    KFill(X, Y, W, H, clBtnFace);
    KRect(X, Y, W, H, cl3DShadow);

    { Sol ok }
    KButton3D(X, Y+1, SCROLLBAR_SIZE, H-2, Sender^.HArrow1Pressed, clBtnFace);
    KLine(X + 4, Y + H div 2, X + 8, Y + H div 2 - 3, clBlack);
    KLine(X + 4, Y + H div 2, X + 8, Y + H div 2 + 3, clBlack);

    { Sag ok }
    KButton3D(X + W - SCROLLBAR_SIZE, Y+1, SCROLLBAR_SIZE, H-2, Sender^.HArrow2Pressed, clBtnFace);
    KLine(X + W - SCROLLBAR_SIZE + 4, Y + H div 2 - 3, X + W - SCROLLBAR_SIZE + 8, Y + H div 2, clBlack);
    KLine(X + W - SCROLLBAR_SIZE + 8, Y + H div 2, X + W - SCROLLBAR_SIZE + 4, Y + H div 2 + 3, clBlack);

    { Thumb }
    if Sender^.HThumbSize > 0 then
      KButton3D(AbsX + Sender^.HThumbPos, Y+1, Sender^.HThumbSize, H-2,
                Sender^.HDragging, clSilver);
  end;

  { Kose karesi (her iki scrollbar aciksa) }
  if Sender^.VScrollVisible and Sender^.HScrollVisible then
    KFill(AbsX + Sender^.Width - 2 - SCROLLBAR_SIZE,
          AbsY + Sender^.Height - 2 - SCROLLBAR_SIZE,
          SCROLLBAR_SIZE, SCROLLBAR_SIZE, clBtnFace);
end;



procedure MemoMouseDown(Sender: PMemo; AX, AY: Integer; Btn: Byte);
var
  NewX, NewY: Integer;
  Part: Integer;
  CW, CH: Integer;
begin
  if Btn <> 1 then Exit;

  { --- Dikey Scrollbar --- }
  if MemoVScrollHitTest(Sender, AX, AY, Part) then
  begin
    case Part of
      0: begin Sender^.VArrow1Pressed := True; Sender^.ScrollY := Max(0, Sender^.ScrollY - 1); end;
      1: begin Sender^.VArrow2Pressed := True; Sender^.ScrollY := Min(Sender^.VScrollMax, Sender^.ScrollY + 1); end;
      2: begin
           CH := Sender^.Height - 4;
           if Sender^.HScrollVisible then Dec(CH, SCROLLBAR_SIZE);
           Sender^.ScrollY := Max(0, Sender^.ScrollY - (CH div FONT_H));
         end;
      3: begin
           CH := Sender^.Height - 4;
           if Sender^.HScrollVisible then Dec(CH, SCROLLBAR_SIZE);
           Sender^.ScrollY := Min(Sender^.VScrollMax, Sender^.ScrollY + (CH div FONT_H));
         end;
      4: begin
           Sender^.VDragging := True;
           Sender^.VDragStart := AY;
         end;
    end;
    MemoUpdateScrollbars(Sender);
    Exit;
  end;

  { --- Yatay Scrollbar --- }
  if MemoHScrollHitTest(Sender, AX, AY, Part) then
  begin
    case Part of
      0: begin Sender^.HArrow1Pressed := True; Sender^.ScrollX := Max(0, Sender^.ScrollX - 1); end;
      1: begin Sender^.HArrow2Pressed := True; Sender^.ScrollX := Min(Sender^.HScrollMax, Sender^.ScrollX + 1); end;
      2: begin
           CW := Sender^.Width - 4;
           if Sender^.VScrollVisible then Dec(CW, SCROLLBAR_SIZE);
           Sender^.ScrollX := Max(0, Sender^.ScrollX - (CW div FONT_W));
         end;
      3: begin
           CW := Sender^.Width - 4;
           if Sender^.VScrollVisible then Dec(CW, SCROLLBAR_SIZE);
           Sender^.ScrollX := Min(Sender^.HScrollMax, Sender^.ScrollX + (CW div FONT_W));
         end;
      4: begin
           Sender^.HDragging := True;
           Sender^.HDragStart := AX;
         end;
    end;
    MemoUpdateScrollbars(Sender);
    Exit;
  end;

  { --- Normal metin alani --- }
  CW := Sender^.Width - 4;
  if Sender^.VScrollVisible then Dec(CW, SCROLLBAR_SIZE);
  CH := Sender^.Height - 4;
  if Sender^.HScrollVisible then Dec(CH, SCROLLBAR_SIZE);

  if (AX < 2) or (AX >= 2 + CW) or (AY < 2) or (AY >= 2 + CH) then Exit;

  NewX := Sender^.ScrollX + (AX - 2) div FONT_W;
  NewY := Sender^.ScrollY + (AY - 2) div FONT_H;
  if NewY >= Sender^.LineCount then NewY := Sender^.LineCount - 1;
  if NewY < 0 then NewY := 0;
  if NewX > MemoLineLength(Sender, NewY) then
    NewX := MemoLineLength(Sender, NewY);
  if NewX < 0 then NewX := 0;
  Sender^.CaretX := NewX;
  Sender^.CaretY := NewY;
  Sender^.SelStartX := NewX;
  Sender^.SelStartY := NewY;
  Sender^.SelActive := False;
  Sender^.MouseDownFlag := True;
end;


procedure MemoMouseMove(Sender: PMemo; AX, AY: Integer; Btn: Byte);
var
  NewX, NewY: Integer;
  CW, CH: Integer;
  VTrackLen, HTrackLen: Integer;
begin
  { VScroll surukleme }
  if Sender^.VDragging then
  begin
    VTrackLen := Sender^.Height - 4 - SCROLLBAR_SIZE * 2;
    if Sender^.HScrollVisible then Dec(VTrackLen, SCROLLBAR_SIZE);
    if (VTrackLen > 0) and (Sender^.VScrollMax > 0) then
    begin
      Sender^.ScrollY := (AY - Sender^.VDragStart - 2 - SCROLLBAR_SIZE) * Sender^.VScrollMax div VTrackLen;
      if Sender^.ScrollY < 0 then Sender^.ScrollY := 0;
      if Sender^.ScrollY > Sender^.VScrollMax then Sender^.ScrollY := Sender^.VScrollMax;
    end;
    MemoUpdateScrollbars(Sender);
    Exit;
  end;

  { HScroll surukleme }
  if Sender^.HDragging then
  begin
    HTrackLen := Sender^.Width - 4 - SCROLLBAR_SIZE * 2;
    if Sender^.VScrollVisible then Dec(HTrackLen, SCROLLBAR_SIZE);
    if (HTrackLen > 0) and (Sender^.HScrollMax > 0) then
    begin
      Sender^.ScrollX := (AX - Sender^.HDragStart - 2 - SCROLLBAR_SIZE) * Sender^.HScrollMax div HTrackLen;
      if Sender^.ScrollX < 0 then Sender^.ScrollX := 0;
      if Sender^.ScrollX > Sender^.HScrollMax then Sender^.ScrollX := Sender^.HScrollMax;
    end;
    MemoUpdateScrollbars(Sender);
    Exit;
  end;

  { Metin secimi }
  if not Sender^.MouseDownFlag then Exit;

  CW := Sender^.Width - 4;
  if Sender^.VScrollVisible then Dec(CW, SCROLLBAR_SIZE);
  CH := Sender^.Height - 4;
  if Sender^.HScrollVisible then Dec(CH, SCROLLBAR_SIZE);

  if AX < 2 then AX := 2;
  if AX >= 2 + CW then AX := 2 + CW - 1;
  if AY < 2 then AY := 2;
  if AY >= 2 + CH then AY := 2 + CH - 1;

  NewX := Sender^.ScrollX + (AX - 2) div FONT_W;
  NewY := Sender^.ScrollY + (AY - 2) div FONT_H;
  if NewY >= Sender^.LineCount then NewY := Sender^.LineCount - 1;
  if NewY < 0 then NewY := 0;
  if NewX > MemoLineLength(Sender, NewY) then
    NewX := MemoLineLength(Sender, NewY);
  if NewX < 0 then NewX := 0;
  Sender^.CaretX := NewX;
  Sender^.CaretY := NewY;
  Sender^.SelActive := (Sender^.CaretX <> Sender^.SelStartX) or
                       (Sender^.CaretY <> Sender^.SelStartY);
end;



procedure MemoMouseUp(Sender: PMemo; AX, AY: Integer; Btn: Byte);
begin
  Sender^.MouseDownFlag := False;
  Sender^.VDragging := False;
  Sender^.HDragging := False;
  Sender^.VArrow1Pressed := False;
  Sender^.VArrow2Pressed := False;
  Sender^.HArrow1Pressed := False;
  Sender^.HArrow2Pressed := False;
end;

procedure MemoKeyDown(Sender: PMemo; Key: Word);
var
  LineLen, PageH: Integer;

  procedure MoveLeft;
  begin
    if Sender^.CaretX > 0 then
      Dec(Sender^.CaretX)
    else if Sender^.CaretY > 0 then
    begin
      Dec(Sender^.CaretY);
      Sender^.CaretX := MemoLineLength(Sender, Sender^.CaretY);
    end;
  end;

  procedure MoveRight;
  begin
    LineLen := MemoLineLength(Sender, Sender^.CaretY);
    if Sender^.CaretX < LineLen then
      Inc(Sender^.CaretX)
    else if Sender^.CaretY < Sender^.LineCount - 1 then
    begin
      Inc(Sender^.CaretY);
      Sender^.CaretX := 0;
    end;
  end;

  procedure MoveUp;
  begin
    if Sender^.CaretY > 0 then
    begin
      Dec(Sender^.CaretY);
      LineLen := MemoLineLength(Sender, Sender^.CaretY);
      if Sender^.CaretX > LineLen then Sender^.CaretX := LineLen;
    end;
  end;

  procedure MoveDown;
  begin
    if Sender^.CaretY < Sender^.LineCount - 1 then
    begin
      Inc(Sender^.CaretY);
      LineLen := MemoLineLength(Sender, Sender^.CaretY);
      if Sender^.CaretX > LineLen then Sender^.CaretX := LineLen;
    end;
  end;

  procedure ClearSelection;
  begin
    Sender^.SelActive := False;
  end;

  procedure StartSelection;
  begin
    if not Sender^.SelActive then
    begin
      Sender^.SelStartX := Sender^.CaretX;
      Sender^.SelStartY := Sender^.CaretY;
      Sender^.SelActive := True;
    end;
  end;

begin
  PageH := (Sender^.Height - 4) div FONT_H;
  if PageH < 1 then PageH := 1;

  { === NAVIGASYON (Virtual Keys) === }
  if Key = VK_LEFT then
  begin
    if ShiftDown then StartSelection else ClearSelection;
    MoveLeft;
  end
  else if Key = VK_RIGHT then
  begin
    if ShiftDown then StartSelection else ClearSelection;
    MoveRight;
  end
  else if Key = VK_UP then
  begin
    if ShiftDown then StartSelection else ClearSelection;
    MoveUp;
  end
  else if Key = VK_DOWN then
  begin
    if ShiftDown then StartSelection else ClearSelection;
    MoveDown;
  end
  else if Key = VK_HOME then
  begin
    if ShiftDown then StartSelection else ClearSelection;
    Sender^.CaretX := 0;
  end
  else if Key = VK_END then
  begin
    if ShiftDown then StartSelection else ClearSelection;
    Sender^.CaretX := MemoLineLength(Sender, Sender^.CaretY);
  end
  else if Key = VK_PRIOR then
  begin
    if ShiftDown then StartSelection else ClearSelection;
    if Sender^.CaretY > 0 then
    begin
      Dec(Sender^.CaretY, PageH);
      if Sender^.CaretY < 0 then Sender^.CaretY := 0;
      LineLen := MemoLineLength(Sender, Sender^.CaretY);
      if Sender^.CaretX > LineLen then Sender^.CaretX := LineLen;
    end;
  end
  else if Key = VK_NEXT then
  begin
    if ShiftDown then StartSelection else ClearSelection;
    if Sender^.CaretY < Sender^.LineCount - 1 then
    begin
      Inc(Sender^.CaretY, PageH);
      if Sender^.CaretY >= Sender^.LineCount then
        Sender^.CaretY := Sender^.LineCount - 1;
      LineLen := MemoLineLength(Sender, Sender^.CaretY);
      if Sender^.CaretX > LineLen then Sender^.CaretX := LineLen;
    end;
  end

  { === DUZENLEME === }
  else if Key = VK_DELETE then
  begin
    if Sender^.SelActive then
      MemoDeleteSelection(Sender)
    else
    begin
      LineLen := MemoLineLength(Sender, Sender^.CaretY);
      if Sender^.CaretX < LineLen then
      begin
        LineLen := StrLen(Sender^.Lines^[Sender^.CaretY]);
        Move(Sender^.Lines^[Sender^.CaretY][Sender^.CaretX + 1],
             Sender^.Lines^[Sender^.CaretY][Sender^.CaretX],
             LineLen - Sender^.CaretX);
      end;
    end;
  end
  else if Key = VK_BACK then
    MemoBackspace(Sender)
  else if Key = VK_RETURN then
    MemoInsertChar(Sender, #13)
  else if Key = VK_TAB then
    MemoInsertChar(Sender, #9)

  else if Key = 1  then  MemoSelectAll(Sender)  { Ctrl+A }
  else if Key = 3  then  MemoCopy(Sender)     { Ctrl+C }
  else if Key = 24 then  MemoCut(Sender)        { Ctrl+X }
  else if Key = 22 then  MemoPaste(Sender)      { Ctrl+V }

  { === KARAKTER GIRISI ($100 ofsetli) === }
  else if (Key >= $100 + 32) and (Key <= $100 + 126) then
    MemoInsertChar(Sender, Char(Key - $100))

  else
    Exit; // Bilinmeyen tusu yut

  { === Caret'i gorunur alana getir === }
  if Sender^.CaretY < Sender^.ScrollY then
    Sender^.ScrollY := Sender^.CaretY
  else if Sender^.CaretY >= Sender^.ScrollY + PageH then
    Sender^.ScrollY := Sender^.CaretY - PageH + 1;

  if Sender^.CaretX < Sender^.ScrollX then
    Sender^.ScrollX := Sender^.CaretX
  else if Sender^.CaretX >= Sender^.ScrollX + ((Sender^.Width - 4) div FONT_W) then
    Sender^.ScrollX := Sender^.CaretX - ((Sender^.Width - 4) div FONT_W) + 1;

  MemoUpdateScrollbars(Sender);
end;



function CreateMemo(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign): PMemo;
begin
  Result := PMemo(MemAlloc(SizeOf(TMemo)));
  FillChar(Result^, SizeOf(TMemo), #0);
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := C_EDIT_BG;
  Result^.BorderWidth := 2;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.ReadOnly := False;
  Result^.ShowCaret := True;
  Result^.LineCount := 0;
  Result^.LineCapacity := 0;
  Result^.Lines := nil;
  Result^.CaretX := 0;
  Result^.CaretY := 0;
  Result^.ScrollX := 0;
  Result^.ScrollY := 0;
  Result^.SelStartX := 0;
  Result^.SelStartY := 0;
  Result^.SelActive := False;
  Result^.MouseDownFlag := False;

  { --- Scrollbar init --- }
  Result^.VScrollVisible := False;
  Result^.HScrollVisible := False;
  Result^.VScrollMax := 0;
  Result^.HScrollMax := 0;
  Result^.VThumbSize := 0;
  Result^.VThumbPos := 0;
  Result^.HThumbSize := 0;
  Result^.HThumbPos := 0;
  Result^.VDragging := False;
  Result^.HDragging := False;
  Result^.VDragStart := 0;
  Result^.HDragStart := 0;
  Result^.VArrow1Pressed := False;
  Result^.VArrow2Pressed := False;
  Result^.HArrow1Pressed := False;
  Result^.HArrow2Pressed := False;
  Result^.Focused:=False;
  Result^.CanFocus := True;
  Result^.TabStop  := True;   { <-- BUNU EKLEY�N }
  MemoAddLine(Result, '');
  Result^.BindPaint(@MemoDraw);
  Result^.BindMouseDown(@MemoMouseDown);
  Result^.BindMouseMove(@MemoMouseMove);
  Result^.BindMouseUp(@MemoMouseUp);
  Result^.BindKeyDown(@MemoKeyDown);
  Result^.BindDestroy(@MemoDestroy);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TComboBox                                                                   }
{=============================================================================}

{=============================================================================}
{ TComboBox                                                                   }
{=============================================================================}

procedure ComboBoxDraw(Sender: PComboBox; AbsX, AbsY: Integer);
var
  BtnW, ItemH, I, ItemY: Integer;
  TxtColor: LongWord;
  P: PChar;
begin
  BtnW := 18;

  { Edit arka plani }
  KFill(AbsX, AbsY, Sender^.Width, Sender^.FNormalHeight, C_EDIT_BG);

  KLineH(AbsX, AbsY, Sender^.Width, cl3DDkShadow);
  KLineV(AbsX, AbsY, Sender^.FNormalHeight, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.FNormalHeight - 1, Sender^.Width, cl3DHighLight);
  KLineV(AbsX + Sender^.Width - 1, AbsY, Sender^.FNormalHeight, cl3DHighLight);

  KLineH(AbsX + 1, AbsY + 1, Sender^.Width - 2, clBlack);
  KLineV(AbsX + 1, AbsY + 1, Sender^.FNormalHeight - 2, clBlack);
  KLineH(AbsX + 1, AbsY + Sender^.FNormalHeight - 2, Sender^.Width - 2, clWhite);
  KLineV(AbsX + Sender^.Width - 2, AbsY + 1, Sender^.FNormalHeight - 2, clWhite);

  { Secili metin }
  if Sender^.ItemIndex >= 0 then
  begin
    P := Sender^.Items^[Sender^.ItemIndex];
    if P <> nil then
    begin
      if Sender^.Enabled then TxtColor := clBlack else TxtColor := clGray;
      KStrClip(AbsX + 3, AbsY + (Sender^.FNormalHeight - FONT_H) div 2,
               P, TxtColor,
               AbsX + 2, AbsY + 2, Sender^.Width - BtnW - 4, Sender^.FNormalHeight - 4);
    end;
  end;

  { Acilir buton }
  KButton3D(AbsX + Sender^.Width - BtnW, AbsY, BtnW, Sender^.FNormalHeight,
            Sender^.DroppedDown, clBtnFace);
  KLine(AbsX + Sender^.Width - BtnW div 2 - 3, AbsY + Sender^.FNormalHeight div 2 - 1,
        AbsX + Sender^.Width - BtnW div 2, AbsY + Sender^.FNormalHeight div 2 + 2, clBlack);
  KLine(AbsX + Sender^.Width - BtnW div 2, AbsY + Sender^.FNormalHeight div 2 + 2,
        AbsX + Sender^.Width - BtnW div 2 + 3, AbsY + Sender^.FNormalHeight div 2 - 1, clBlack);

  { DropDown liste - FNormalHeight'dan itibaren ciz }
  if Sender^.DroppedDown and (Sender^.ItemCount > 0) then
  begin
    ItemH := FONT_H + 4;

    KFill(AbsX, AbsY + Sender^.FNormalHeight, Sender^.Width,
          Sender^.ItemCount * ItemH + 2, clWhite);
    KRect(AbsX, AbsY + Sender^.FNormalHeight, Sender^.Width,
          Sender^.ItemCount * ItemH + 2, clBlack);

    for I := 0 to Sender^.ItemCount - 1 do
    begin
      ItemY := AbsY + Sender^.FNormalHeight + 1 + I * ItemH;

      if I = Sender^.HoverIndex then
        KFill(AbsX + 1, ItemY, Sender^.Width - 2, ItemH, $00A0C8F0);

      if I = Sender^.ItemIndex then
      begin
        KFill(AbsX + 1, ItemY, Sender^.Width - 2, ItemH, $004080C0);
        TxtColor := clWhite;
      end
      else if I = Sender^.HoverIndex then
        TxtColor := clBlack
      else
        TxtColor := clBlack;

      P := Sender^.Items^[I];
      if P <> nil then
        KStr(AbsX + 4, ItemY + 2, P, TxtColor);
    end;
  end;
end;

procedure ComboBoxMouseDown(Sender: PComboBox; AX, AY: Integer; Btn: Byte);
var
  BtnW, ItemH, Idx: Integer;
begin
  if Btn <> 1 then Exit;

  BtnW := 18;

  { --- DropDown zaten aciksa --- }
  if Sender^.DroppedDown then
  begin
    { Butona tekrar tiklandi -> kapat }
    if (AX >= Sender^.Width - BtnW) and (AX < Sender^.Width) and
       (AY >= 0) and (AY < Sender^.FNormalHeight) then
    begin
      Sender^.DroppedDown := False;
      Sender^.Height := Sender^.FNormalHeight;
      Exit;
    end;

    { Liste alanina tiklandi mi? }
    ItemH := FONT_H + 4;
    if (AY >= Sender^.FNormalHeight) and
       (AY < Sender^.FNormalHeight + Sender^.ItemCount * ItemH + 2) then
    begin
      Idx := (AY - Sender^.FNormalHeight) div ItemH;
      if (Idx >= 0) and (Idx < Sender^.ItemCount) then
      begin
        if Sender^.ItemIndex <> Idx then
        begin
          Sender^.ItemIndex := Idx;
          if Assigned(Sender^.FOnChange) then
            Sender^.FOnChange(@Sender^);
        end;
        
        Sender^.DroppedDown := False;
        Sender^.Height := Sender^.FNormalHeight;
      end;
    end
    else
    begin
      { Disari tiklandi -> kapat }
      Sender^.DroppedDown := False;
      Sender^.Height := Sender^.FNormalHeight;
    end;
    Exit;
  end;

  { --- DropDown kapaliyken butona tiklama --- }
  if (AX >= Sender^.Width - BtnW) and (AX < Sender^.Width) and
     (AY >= 0) and (AY < Sender^.Height) then
  begin
    Sender^.FNormalHeight := Sender^.Height;
    ItemH := FONT_H + 4;
    if Sender^.ItemCount > 0 then
      Sender^.Height := Sender^.FNormalHeight + Sender^.ItemCount * ItemH + 2
    else
      Sender^.Height := Sender^.FNormalHeight;
    Sender^.DroppedDown := True;
  end;
end;

procedure ComboBoxMouseMove(Sender: PComboBox; AX, AY: Integer; Btn: Byte);
var
  ItemH: Integer;
begin
  if not Sender^.DroppedDown then Exit;

  ItemH := FONT_H + 4;
  if (AY >= Sender^.FNormalHeight) and
     (AY < Sender^.FNormalHeight + Sender^.ItemCount * ItemH + 2) then
    Sender^.HoverIndex := (AY - Sender^.FNormalHeight) div ItemH
  else
    Sender^.HoverIndex := -1;
end;

procedure ComboBoxMouseUp(Sender: PComboBox; AX, AY: Integer; Btn: Byte);
begin
end;

procedure ComboBoxAddItem(Sender: PComboBox; const AText: PChar);
var
  Len: Integer;
  P: PChar;
begin
  if Sender^.ItemCount >= Sender^.ItemCapacity then
    GrowPCharArray(Sender^.Items, Sender^.ItemCapacity, Sender^.ItemCount + 1);
  Len := StrLen(AText);
  P := PChar(MemAlloc(Len + 1));
  if P <> nil then
  begin
    Move(AText^, P^, Len + 1);
    Sender^.Items^[Sender^.ItemCount] := P;
    Inc(Sender^.ItemCount);
  end;
end;

procedure ComboBoxClear(Sender: PComboBox);
var
  I: Integer;
begin
  for I := 0 to Sender^.ItemCount - 1 do
    if Sender^.Items^[I] <> nil then
      FreeMem(Sender^.Items^[I]);
  Sender^.ItemCount := 0;
  Sender^.ItemIndex := -1;
  if Sender^.DroppedDown then
  begin
    Sender^.DroppedDown := False;
    Sender^.Height := Sender^.FNormalHeight;
  end;
end;

{ TObject.FireDestroy tarafindan cagirilir. ComboBoxClear ile her item'in
  PChar'ini, ardindan Items dizisinin kendisini serbest birakir. }
procedure ComboBoxDestroy(Sender: PObject);
var
  CB: PComboBox;
begin
  CB := PComboBox(Sender);
  ComboBoxClear(CB);
  if CB^.Items <> nil then
  begin
    FreeMem(CB^.Items);
    CB^.Items := nil;
  end;
  CB^.ItemCapacity := 0;
end;

function CreateComboBox(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                        AAlign: TAlign): PComboBox;
begin
  Result := PComboBox(MemAlloc(SizeOf(TComboBox)));
  FillChar(Result^, SizeOf(TComboBox), #0);

  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  if AHeight < 1 then Result^.Height := 22 else Result^.Height := AHeight;
  Result^.FNormalHeight := Result^.Height;   // Orijinal yuksekligi sakla
  Result^.Align := AAlign;
  Result^.Color := C_EDIT_BG;
  Result^.BorderWidth := 2;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 100;

  Result^.ItemIndex := -1;
  Result^.HoverIndex := -1;
  Result^.ItemCount := 0;
  Result^.ItemCapacity := 0;
  Result^.Items := nil;
  Result^.DroppedDown := False;
  Result^.FOnChange := nil; 

  Result^.BindPaint(@ComboBoxDraw);
  Result^.BindMouseDown(@ComboBoxMouseDown);
  Result^.BindMouseMove(@ComboBoxMouseMove);
  Result^.BindMouseUp(@ComboBoxMouseUp);
  Result^.BindDestroy(@ComboBoxDestroy);

  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TListBox                                                                    }
{=============================================================================}

procedure ListBoxDraw(Sender: PListBox; AbsX, AbsY: Integer);
var
  I, ItemY, ItemH,   ScrollW,VisibleItems ,ClientW: Integer;
  TxtColor: LongWord;
  P: PChar;
  ScrollVisible:Boolean;
begin
  ItemH := FONT_H + 4;
  ScrollW := SCROLLBAR_SIZE;
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, clWhite);
  KLineH(AbsX, AbsY, Sender^.Width, cl3DDkShadow);
  KLineV(AbsX, AbsY, Sender^.Height, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.Height - 1, Sender^.Width, cl3DHighLight);
  KLineV(AbsX + Sender^.Width - 1, AbsY, Sender^.Height, cl3DHighLight);
  KLineH(AbsX + 1, AbsY + 1, Sender^.Width - 2, clBlack);
  KLineV(AbsX + 1, AbsY + 1, Sender^.Height - 2, clBlack);
  KLineH(AbsX + 1, AbsY + Sender^.Height - 2, Sender^.Width - 2, clWhite);
  KLineV(AbsX + Sender^.Width - 2, AbsY + 1, Sender^.Height - 2, clWhite);

  VisibleItems := ((Sender^.Height - 4) div ItemH);
  ScrollVisible := (Sender^.ItemCount > VisibleItems);

  if ScrollVisible then
    ClientW := Sender^.Width - 4 - ScrollW
  else
    ClientW := Sender^.Width - 4;

  for I := 0 to VisibleItems - 1 do
  begin
    if Sender^.ScrollIndex + I >= Sender^.ItemCount then Break;
    ItemY := AbsY + 2 + I * ItemH;
    if Sender^.ScrollIndex + I = Sender^.ItemIndex then
    begin
      KFill(AbsX + 2, ItemY, ClientW, ItemH, $004080C0);
      TxtColor := clWhite;
    end
    else if Sender^.ScrollIndex + I = Sender^.HoverIndex then
    begin
      KFill(AbsX + 2, ItemY, ClientW, ItemH, $00E0E8F0);
      TxtColor := clBlack;
    end
    else
      TxtColor := clBlack;

    P := Sender^.Items^[Sender^.ScrollIndex + I];
    if P <> nil then
      KStr(AbsX + 4, ItemY + 2, P, TxtColor);
  end;

  if ScrollVisible then
  begin
    KFill(AbsX + Sender^.Width - 2 - ScrollW, AbsY + 2, ScrollW, Sender^.Height - 4, clBtnFace);
    KRect(AbsX + Sender^.Width - 2 - ScrollW, AbsY + 2, ScrollW, Sender^.Height - 4, cl3DShadow);

    Sender^.ThumbSize := Max(16, (Sender^.Height - 4) * VisibleItems div Sender^.ItemCount);
    if Sender^.ItemCount > VisibleItems then
      Sender^.ThumbPos := 2 + Sender^.ScrollIndex * (Sender^.Height - 4 - Sender^.ThumbSize) div
                          (Sender^.ItemCount - VisibleItems)
    else
      Sender^.ThumbPos := 2;

    KFill(AbsX + Sender^.Width - 1 - ScrollW, AbsY + Sender^.ThumbPos,
          ScrollW - 2, Sender^.ThumbSize, clSilver);
    KRect(AbsX + Sender^.Width - 1 - ScrollW, AbsY + Sender^.ThumbPos,
          ScrollW - 2, Sender^.ThumbSize, cl3DShadow);
  end;
  
end;

procedure ListBoxMouseDown(Sender: PListBox; AX, AY: Integer; Btn: Byte);
var
  ItemH, VisibleItems, Idx: Integer;
  ScrollVisible: Boolean;
  ScrollW: Integer;
begin
  if Btn <> 1 then Exit;
  ItemH := FONT_H + 4;
  VisibleItems := (Sender^.Height - 4) div ItemH;
  ScrollVisible := Sender^.ItemCount > VisibleItems;
  ScrollW := SCROLLBAR_SIZE;

  if ScrollVisible and (AX >= Sender^.Width - 4 - ScrollW) then
  begin
    { Thumb surukleme baslat }
    if (AY >= Sender^.ThumbPos) and (AY < Sender^.ThumbPos + Sender^.ThumbSize) then
    begin
      Sender^.Dragging := True;
      Sender^.DragStartY := AY;
    end;
    Exit;
  end;

  if (AY >= 2) and (AY < Sender^.Height - 2) then
  begin
    Idx := Sender^.ScrollIndex + (AY - 2) div ItemH;
    if (Idx >= 0) and (Idx < Sender^.ItemCount) then
      Sender^.ItemIndex := Idx;
  end;
end;

procedure ListBoxMouseMove(Sender: PListBox; AX, AY: Integer; Btn: Byte);
var
  ItemH, VisibleItems, Idx, TrackLen, Delta, NewThumb, NewScroll: Integer;
begin
  ItemH := FONT_H + 4;
  VisibleItems := (Sender^.Height - 4) div ItemH;

  if Sender^.Dragging then
  begin
    Delta := AY - Sender^.DragStartY;
    NewThumb := Sender^.ThumbPos + Delta;

    { Thumb sinirlari }
    if NewThumb < 2 then NewThumb := 2;
    TrackLen := Sender^.Height - 4 - Sender^.ThumbSize;
    if NewThumb > 2 + TrackLen then NewThumb := 2 + TrackLen;

    { ScrollIndex hesapla }
    if (Sender^.ItemCount > VisibleItems) and (TrackLen > 0) then
      NewScroll := (NewThumb - 2) * (Sender^.ItemCount - VisibleItems) div TrackLen
    else
      NewScroll := 0;

    if NewScroll < 0 then NewScroll := 0;
    if NewScroll > Sender^.ItemCount - VisibleItems then
      NewScroll := Sender^.ItemCount - VisibleItems;

    Sender^.ScrollIndex := NewScroll;
    Sender^.DragStartY := AY;
    Exit;
  end;

  if (AY >= 2) and (AY < Sender^.Height - 2) then
  begin
    Idx := Sender^.ScrollIndex + (AY - 2) div ItemH;
    if (Idx >= 0) and (Idx < Sender^.ItemCount) then
      Sender^.HoverIndex := Idx
    else
      Sender^.HoverIndex := -1;
  end
  else
    Sender^.HoverIndex := -1;
end;

procedure ListBoxMouseUp(Sender: PListBox; AX, AY: Integer; Btn: Byte);
begin
  Sender^.Dragging := False;
end;

function ListViewGetItem(Sender: PListView; Index: Integer): PListViewItem;
begin
  if (Index < 0) or (Index >= Sender^.ItemCount) then
    Result := nil
  else
    Result := PListViewItem(PPCharArray(Sender^.Items)^[Index]);
end;

procedure ListBoxAddItem(Sender: PListBox; const AText: PChar);
var
  Len: Integer;
  P: PChar;

begin
  if Sender^.ItemCount >= Sender^.ItemCapacity then
    GrowPCharArray(Sender^.Items, Sender^.ItemCapacity, Sender^.ItemCount + 1);
  Len := StrLen(AText);
  P := PChar(MemAlloc(Len + 1));
  if P <> nil then
  begin
    Move(AText^, P^, Len + 1);
    Sender^.Items^[Sender^.ItemCount] := P;


    Inc(Sender^.ItemCount);
  end;
end;

procedure ListBoxClear(Sender: PListBox);
var
  I: Integer;
begin
  for I := 0 to Sender^.ItemCount - 1 do
    if Sender^.Items^[I] <> nil then
      FreeMem(Sender^.Items^[I]);
  Sender^.ItemCount := 0;
  Sender^.ItemIndex := -1;
  Sender^.ScrollIndex := 0;
end;

{ TObject.FireDestroy tarafindan cagirilir. }
procedure ListBoxDestroy(Sender: PObject);
var
  LB: PListBox;
begin
  LB := PListBox(Sender);
  ListBoxClear(LB);
  if LB^.Items <> nil then
  begin
    FreeMem(LB^.Items);
    LB^.Items := nil;
  end;
  LB^.ItemCapacity := 0;
end;

function CreateListBox(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign): PListBox;
begin
  Result := PListBox(MemAlloc(SizeOf(TListBox)));
  FillChar(Result^, SizeOf(TListBox), #0);
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := clWhite;
  Result^.BorderWidth := 2;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.ItemIndex := -1;
  Result^.HoverIndex := -1;
  Result^.ItemCount := 0;
  Result^.ItemCapacity := 0;
  Result^.Items := nil;
  Result^.ScrollIndex := 0;
  Result^.Dragging := False;
  Result^.DragStartY := 0;   { Ekle }
  Result^.BindPaint(@ListBoxDraw);
  Result^.BindMouseDown(@ListBoxMouseDown);
  Result^.BindMouseMove(@ListBoxMouseMove);
  Result^.BindMouseUp(@ListBoxMouseUp);
  Result^.BindDestroy(@ListBoxDestroy);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TCheckBox                                                                   }
{=============================================================================}

procedure CheckBoxDraw(Sender: PCheckBox; AbsX, AbsY: Integer);
var
  BoxSize: Integer;
  TxtColor: LongWord;
begin
  BoxSize := 13;
  if Sender^.Enabled then
    TxtColor := clBlack
  else
    TxtColor := clGray;

  KStr(AbsX + BoxSize + 4, AbsY + (Sender^.Height - FONT_H) div 2,
       Sender^.Caption, TxtColor);

  KFill(AbsX, AbsY + (Sender^.Height - BoxSize) div 2, BoxSize, BoxSize, clWhite);
  KRect(AbsX, AbsY + (Sender^.Height - BoxSize) div 2, BoxSize, BoxSize, cl3DDkShadow);
  KLineH(AbsX + 1, AbsY + (Sender^.Height - BoxSize) div 2 + 1, BoxSize - 2, clWhite);
  KLineV(AbsX + 1, AbsY + (Sender^.Height - BoxSize) div 2 + 1, BoxSize - 2, clWhite);

  if Sender^.Checked then
  begin
    KLine(AbsX + 2, AbsY + (Sender^.Height - BoxSize) div 2 + 5,
          AbsX + 4, AbsY + (Sender^.Height - BoxSize) div 2 + 7, clBlack);
    KLine(AbsX + 4, AbsY + (Sender^.Height - BoxSize) div 2 + 7,
          AbsX + 10, AbsY + (Sender^.Height - BoxSize) div 2 + 1, clBlack);
  end;
end;

procedure CheckBoxMouseDown(Sender: PCheckBox; AX, AY: Integer; Btn: Byte);
begin
  if Btn = 1 then
    Sender^.Checked := not Sender^.Checked;
end;


function CheckBoxGetState(CheckBox:PCheckBox):Boolean;
begin
  Result:= CheckBox^.Checked;
end;

procedure CheckBoxSetState(CheckBox:PCheckBox;Value:Boolean);
begin
  CheckBox^.Checked:=Value;
end;

function CreateCheckBox(AParent: PObject; const ACaption: PChar; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign): PCheckBox;
begin
  Result := PCheckBox(MemAlloc(SizeOf(TCheckBox)));
  FillChar(Result^, SizeOf(TCheckBox), #0);
  if ACaption <> nil then
    Move(ACaption[0], Result^.Caption[0], StrLen(ACaption));
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  if Result^.Width < 1 then Result^.Width := 100;
  Result^.Height := AHeight;
  if Result^.Height < 1 then Result^.Height := 18;
  Result^.Align := AAlign;
  Result^.Color := clBtnFace;
  Result^.BorderWidth := 0;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.Checked := False;
  Result^.BindPaint(@CheckBoxDraw);
  Result^.BindMouseDown(@CheckBoxMouseDown);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TRadioButton                                                                }
{=============================================================================}

procedure RadioButtonDraw(Sender: PRadioButton; AbsX, AbsY: Integer);
var
  R, CX, CY: Integer;
  TxtColor: LongWord;
begin
  R := 6;
  CX := AbsX + R;
  CY := AbsY + Sender^.Height div 2;

  if Sender^.Enabled then
    TxtColor := clBlack
  else
    TxtColor := clGray;

   KStr(AbsX + R * 2 + 6, AbsY + (Sender^.Height - FONT_H) div 2,
       Sender^.Caption, TxtColor);

  KCircle(CX, CY, R, cl3DDkShadow);
  KFillCircle(CX, CY, R - 1, clWhite);

  if Sender^.Checked then
    KFillCircle(CX, CY, 3, clBlack);
end;

procedure RadioButtonMouseDown(Sender: PRadioButton; AX, AY: Integer; Btn: Byte);
var
  Sibling: PObject;
  ParentObj: PObject;
begin
  if Btn <> 1 then Exit;
  ParentObj := Sender^.Parent;
  if ParentObj <> nil then
  begin
    Sibling := ParentObj^.Child;
    while Sibling <> nil do
    begin
      if (Sibling <> PObject(Sender)) and (Sibling^.Tag = 2) then
        PRadioButton(Sibling)^.Checked := False;
      Sibling := Sibling^.Next;
    end;
  end;
  Sender^.Checked := True;
end;

function CreateRadioButton(AParent: PObject; const ACaption: PChar;
                           ALeft, ATop, AWidth, AHeight: Integer;
                           AAlign: TAlign): PRadioButton;
begin
  Result := PRadioButton(MemAlloc(SizeOf(TRadioButton)));
  FillChar(Result^, SizeOf(TRadioButton), #0);
  if ACaption <> nil then
    Move(ACaption[0], Result^.Caption[0], StrLen(ACaption));
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  if Result^.Width < 1 then Result^.Width := 100;
  Result^.Height := AHeight;
  if Result^.Height < 1 then Result^.Height := 18;
  Result^.Align := AAlign;
  Result^.Color := clBtnFace;
  Result^.BorderWidth := 0;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.Tag := 2;
  Result^.Checked := False;
  Result^.BindPaint(@RadioButtonDraw);
  Result^.BindMouseDown(@RadioButtonMouseDown);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TGroupBox                                                                   }
{=============================================================================}

procedure GroupBoxDraw(Sender: PGroupBox; AbsX, AbsY: Integer);
var
  CaptionW, CaptionH: Integer;
begin
  CaptionH := FONT_H;
  KLineH(AbsX, AbsY + CaptionH div 2, 8, cl3DDkShadow);
  KLineH(AbsX, AbsY + CaptionH div 2 + 1, 8, clWhite);

  if Sender^.Caption[0] <> #0 then
  begin
    CaptionW := StrLen(Sender^.Caption) * FONT_W;
    KStr(AbsX + 10, AbsY, Sender^.Caption, clBlack);
    KLineH(AbsX + 10 + CaptionW + 2, AbsY + CaptionH div 2,
           Sender^.Width - (10 + CaptionW + 2), cl3DDkShadow);
    KLineH(AbsX + 10 + CaptionW + 2, AbsY + CaptionH div 2 + 1,
           Sender^.Width - (10 + CaptionW + 2), clWhite);
  end
  else
  begin
    KLineH(AbsX + 8, AbsY + CaptionH div 2,
           Sender^.Width - 8, cl3DDkShadow);
    KLineH(AbsX + 8, AbsY + CaptionH div 2 + 1,
           Sender^.Width - 8, clWhite);
  end;

  KLineV(AbsX, AbsY + CaptionH div 2, Sender^.Height - CaptionH div 2, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.Height - 1, Sender^.Width, cl3DDkShadow);
  KLineV(AbsX + Sender^.Width - 1, AbsY + CaptionH div 2,
         Sender^.Height - CaptionH div 2, clWhite);
  KLineH(AbsX, AbsY + Sender^.Height - 2, Sender^.Width, clWhite);
end;

function CreateGroupBox(AParent: PObject; const ACaption: PChar;
                        ALeft, ATop, AWidth, AHeight: Integer;
                        AAlign: TAlign): PGroupBox;
begin
  Result := PGroupBox(MemAlloc(SizeOf(TGroupBox)));
  FillChar(Result^, SizeOf(TGroupBox), #0);
  if ACaption <> nil then
    Move(ACaption[0], Result^.Caption[0], StrLen(ACaption));
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := clBtnFace;
  Result^.BorderWidth := 2;
  Result^.ShowCaption := False;
  Result^.Cursor := 0;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 0;
  Result^.BindPaint(@GroupBoxDraw);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TProgressBar                                                                }
{=============================================================================}

procedure ProgressBarDraw(Sender: PProgressBar; AbsX, AbsY: Integer);
var
  FillW: Integer;
begin
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, clWhite);
  KLineH(AbsX, AbsY, Sender^.Width, cl3DDkShadow);
  KLineV(AbsX, AbsY, Sender^.Height, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.Height - 1, Sender^.Width, cl3DHighLight);
  KLineV(AbsX + Sender^.Width - 1, AbsY, Sender^.Height, cl3DHighLight);

  if Sender^.Max > Sender^.Min then
    FillW := (Sender^.Width - 4) * (Sender^.Position - Sender^.Min) div
             (Sender^.Max - Sender^.Min)
  else
    FillW := 0;
  if FillW > Sender^.Width - 4 then FillW := Sender^.Width - 4;
  if FillW < 0 then FillW := 0;

  if FillW > 0 then
  begin
    if Sender^.Smooth then
      KGradientH(AbsX + 2, AbsY + 2, FillW, Sender^.Height - 4,
                 $00A0C8F0, $004080C0)
    else
      KFill(AbsX + 2, AbsY + 2, FillW, Sender^.Height - 4, $004080C0);
  end;

  if Sender^.ShowPercent then
    KStrCentered(AbsX, AbsY + (Sender^.Height - FONT_H) div 2,
                 Sender^.Width, '%', clBlack);
end;

function CreateProgressBar(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                           AAlign: TAlign): PProgressBar;
begin
  Result := PProgressBar(MemAlloc(SizeOf(TProgressBar)));
  FillChar(Result^, SizeOf(TProgressBar), #0);
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := clWhite;
  Result^.BorderWidth := 2;
  Result^.ShowCaption := False;
  Result^.Cursor := 0;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.Min := 0;
  Result^.Max := 100;
  Result^.Position := 0;
  Result^.Smooth := True;
  Result^.ShowPercent := False;
  Result^.BindPaint(@ProgressBarDraw);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TTrackBar                                                                   }
{=============================================================================}

procedure TrackBarDraw(Sender: PTrackBar; AbsX, AbsY: Integer);
var
  TrackY, TrackW: Integer;
begin
  TrackY := AbsY + Sender^.Height div 2;
  TrackW := Sender^.Width - 20;

  KLineH(AbsX + 10, TrackY, TrackW, cl3DDkShadow);
  KLineH(AbsX + 10, TrackY + 1, TrackW, clWhite);

  if Sender^.Max > Sender^.Min then
    Sender^.ThumbX := 10 + TrackW * (Sender^.Position - Sender^.Min) div
                      (Sender^.Max - Sender^.Min)
  else
    Sender^.ThumbX := 10;

  if Sender^.ThumbX > 10 + TrackW then Sender^.ThumbX := 10 + TrackW;
  if Sender^.ThumbX < 10 then Sender^.ThumbX := 10;

  KButton3D(AbsX + Sender^.ThumbX - 6, TrackY - 8, 12, 16,
            Sender^.Dragging, clBtnFace);
end;


procedure TrackBarMouseDown(Sender: PTrackBar; AX, AY: Integer; Btn: Byte);
var
  TrackY: Integer;
begin
  if Btn <> 1 then Exit;
  TrackY := Sender^.Height div 2;
  if (AX >= Sender^.ThumbX - 6) and (AX <= Sender^.ThumbX + 6) and
     (AY >= TrackY - 8) and (AY <= TrackY + 8) then
  begin
    Sender^.Dragging := True;
    Sender^.DragOffset := AX - Sender^.ThumbX;
  end;
end;

procedure TrackBarMouseMove(Sender: PTrackBar; AX, AY: Integer; Btn: Byte);
var
  TrackW, NewPos: Integer;
begin
  if not Sender^.Dragging then Exit;
  TrackW := Sender^.Width - 20;
  NewPos := (AX - Sender^.DragOffset - 10) * (Sender^.Max - Sender^.Min) div TrackW;
  if NewPos < Sender^.Min then NewPos := Sender^.Min;
  if NewPos > Sender^.Max then NewPos := Sender^.Max;
  Sender^.Position := NewPos;
end;


procedure TrackBarMouseUp(Sender: PTrackBar; AX, AY: Integer; Btn: Byte);
begin
  Sender^.Dragging := False;
end;

function CreateTrackBar(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                        AAlign: TAlign): PTrackBar;
begin
  Result := PTrackBar(MemAlloc(SizeOf(TTrackBar)));
  FillChar(Result^, SizeOf(TTrackBar), #0);
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := clBtnFace;
  Result^.BorderWidth := 0;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.Min := 0;
  Result^.Max := 100;
  Result^.Position := 0;
  Result^.Dragging := False;
  Result^.BindPaint(@TrackBarDraw);
  Result^.BindMouseDown(@TrackBarMouseDown);
  Result^.BindMouseMove(@TrackBarMouseMove);
  Result^.BindMouseUp(@TrackBarMouseUp);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TImage                                                                      }
{=============================================================================}

procedure ImageDraw(Sender: PImage; AbsX, AbsY: Integer);
begin
  if Sender^.Bitmap = nil then
  begin
    KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, clSilver);
    KRect(AbsX, AbsY, Sender^.Width, Sender^.Height, clGray);
    KStrCentered(AbsX, AbsY + (Sender^.Height - FONT_H) div 2,
                 Sender^.Width, '(no image)', clGray);
  end
  else
  begin
    KBitBlt(AbsX, AbsY, Sender^.Width, Sender^.Height,
            PLongWordArray(Sender^.Bitmap), Sender^.BitmapWidth, 0, 0);
  end;
  if Sender^.BorderWidth > 0 then
    KRect(AbsX, AbsY, Sender^.Width, Sender^.Height, Sender^.BorderColor);
end;

function CreateImage(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                     AAlign: TAlign): PImage;
begin
  Result := PImage(MemAlloc(SizeOf(TImage)));
  FillChar(Result^, SizeOf(TImage), #0);
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := clSilver;
  Result^.BorderWidth := 0;
  Result^.ShowCaption := False;
  Result^.Cursor := 0;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.Bitmap := nil;
  Result^.BitmapWidth := 0;
  Result^.BitmapHeight := 0;
  Result^.BindPaint(@ImageDraw);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TSplitter                                                                   }
{=============================================================================}


{=============================================================================}
{ TSplitter                                                                   }
{=============================================================================}

function TSplitter.FindControlToResize: PObject;
begin
  // Genellikle splitter'dan bir ?nce eklenen (Previous) bile?eni boyutland?r?r?z.
  // E?er ?zel bir kural?n?z varsa buray? revize edebilirsiniz.
  Result :=FControl ;//Previous; //next ;
end;



procedure Splitter_Draw(Sender: PSplitter; OX, OY: Integer);
begin
  // Klasik Win32 / 3D g?r?n?ml? splitter ?izimi
  KFill(OX, OY, Sender^.Width, Sender^.Height, $D4D0C8); // cl3DFace veya clBtnFace e?de?eri

  // Splitter'?n ortas?na tutamak (gripper) ?izgileri ?izelim
  if Sender^.FOrientation = soVertical then
  begin
    KLineV(OX + (Sender^.Width div 2) - 1, OY + (Sender^.Height div 2) - 10, 20, $808080);
    KLineV(OX + (Sender^.Width div 2) + 1, OY + (Sender^.Height div 2) - 10, 20, $FFFFFF);
  end
  else
  begin
    KLineH(OX + (Sender^.Width div 2) - 10, OY + (Sender^.Height div 2) - 1, 20, $808080);
    KLineH(OX + (Sender^.Width div 2) - 10, OY + (Sender^.Height div 2) + 1, 20, $FFFFFF);
  end;
end;

procedure Splitter_MouseDown(Sender: PSplitter; X, Y: Integer; Btn: Byte);
var
  target: PObject;
begin
  Target := Sender^.FindControlToResize;
  if Target <> nil then
  begin
    Sender^.FDragging := True;
    MouseCapture := Sender; // Fare hareketini capture ediyoruz

    if Sender^.FOrientation = soVertical then
    begin
      Sender^.FStartPos := Sender^.Left + X; // Absolute fare X pozisyonu
      Sender^.FStartSize := Target^.Width;
    end
    else
    begin
      Sender^.FStartPos := Sender^.Top + Y;  // Absolute fare Y pozisyonu
      Sender^.FStartSize := Target^.Height;
    end;
  end;



end;

procedure Splitter_MouseMove(Sender: PSplitter; X, Y: Integer; Btn: Byte);
var
  Target: PObject;
  CurrentPos, Delta, NewSize: Integer;
begin
  if not Sender^.FDragging then Exit;

  Target := Sender^.FindControlToResize;
  if Target = nil then Exit;

  if Sender^.FOrientation = soVertical then
  begin
    CurrentPos := Sender^.Left + X;
    Delta := CurrentPos - Sender^.FStartPos;
    
    // E?er splitter alLeft hizal?ysa sa?a ?ektik?e Previous bile?en b?y?yecektir.
    // alRight hizal?ysa tersi gerekir. A?a??da en yayg?n olan alLeft/alTop varsay?lm??t?r.
    if Target^.Align = alRight then
      NewSize := Sender^.FStartSize - Delta
    else
      NewSize := Sender^.FStartSize + Delta;

    if NewSize < Sender^.FMinSize then NewSize := Sender^.FMinSize;
    Target^.Width := NewSize;
  end
  else
  begin
    CurrentPos := Sender^.Top + Y;
    Delta := CurrentPos - Sender^.FStartPos;

    if Target^.Align = alBottom then
      NewSize := Sender^.FStartSize - Delta
    else
      NewSize := Sender^.FStartSize + Delta;

    if NewSize < Sender^.FMinSize then NewSize := Sender^.FMinSize;
    Target^.Height := NewSize;
  end;



    RelayoutForm(FindRootForm(PObject(Sender)));
 


end;


procedure Splitter_MouseUp(Sender: PSplitter; X, Y: Integer; Btn: Byte);
begin
   if Sender^.FDragging then
  begin
    Sender^.FDragging := False;

  if (MouseCapture<>nil) and (MouseCapture = PObject(Sender)) then
    MouseCapture := nil;

  end;
end;


function CreateSplitter(AParent: PObject; ALeft, ATop, ASize: Integer; AHorizontal: Boolean; AAlign: TAlign): PSplitter;
begin
  Result := PSplitter(MemAlloc(SizeOf(TSplitter)));
  FillChar(Result^, SizeOf(TSplitter), #0);

  Result^.Left := ALeft;
  Result^.Top := ATop;
  if AHorizontal then
  begin
    Result^.Width := 100;
    Result^.Height := ASize;
    Result^.FOrientation := soHorizontal;
  end
  else
  begin
    Result^.Width := ASize;
    Result^.Height := 100;
    Result^.FOrientation := soVertical;
  end;

   Result^.FDragging := False;
  Result^.FMinSize := 30; // Varsay?lan minimum bile?en geni?lik/y?kseklik s?n?r?

  Result^.Align := AAlign;
  Result^.FMinSize := 30;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 2;

  // Fare Olaylar?n? Ba?lama (Eksik Olan K?s?m)
  Result^.BindMouseDown(@Splitter_MouseDown);
  Result^.BindMouseMove(@Splitter_MouseMove);
  Result^.BindMouseUp(@Splitter_MouseUp);
  Result^.BindPaint(@Splitter_Draw); // Var olan ?izim prosed?r?n?z

  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;
{=============================================================================}
{ TStatusBar                                                                  }
{=============================================================================}



procedure StatusBarSetText(Sender: PStatusBar; Index: Integer; const AText: PChar);
begin
   if (Index >= 0) and (Index < Sender^.FPanelCount) then
   begin
    StrCopy(@Sender^.FPanels[Index].Text[0], AText);
   end;
end;


function TStatusBar.AddPanel(AText: PChar; AWidth: Integer): Integer;
begin
  if FPanelCount < MAX_STATUS_PANELS then
  begin
    StrCopy(@FPanels[FPanelCount].Text[0], AText);
    FPanels[FPanelCount].Width := AWidth;
    Result := FPanelCount;
    Inc(FPanelCount);
    FSimplePanel := False;
  end
  else
    Result := -1;
end;

procedure TStatusBar.SetPanelText(Index: Integer; AText: PChar);
begin
  if (Index >= 0) and (Index < FPanelCount) then
  begin
    StrCopy(@FPanels[Index].Text[0], AText);
  end;
end;

procedure TStatusBar.SetSimpleText(AText: PChar);
begin
  StrCopy(@FSimpleText[0], AText);
end;

procedure TStatusBar.SetSimplePanel(Value: Boolean);
begin
  FSimplePanel := Value;
end;

procedure StatusBar_Draw(Sender: PStatusBar; OX, OY: Integer);
var
  I, PX, PW, TextY: Integer;
begin
  // 1. Ana Zemin ?izimi
  KFill(OX, OY, Sender^.Width, Sender^.Height, $D4D0C8);

  // 2. ?st 3D ?izgi
  KLineH(OX, OY, Sender^.Width, $808080);
  KLineH(OX, OY + 1, Sender^.Width, $FFFFFF);

  TextY := OY + (Sender^.Height - 8) div 2;

  // 3. BAS?T MOD
  if Sender^.FSimplePanel or (Sender^.FPanelCount = 0) then
  begin
    // Sunken Frame
    KLineH(OX + 2, OY + 3, Sender^.Width - 4, $808080);
    KLineV(OX + 2, OY + 3, Sender^.Height - 5, $808080);
    KLineH(OX + 2, OY + Sender^.Height - 2, Sender^.Width - 4, $FFFFFF);
    KLineV(OX + Sender^.Width - 2, OY + 3, Sender^.Height - 5, $FFFFFF);

    // Metni PChar adresi olarak ?izim fonksiyonuna veriyoruz
    KStr(OX + 6, TextY, @Sender^.FSimpleText[0], $000000);
  end
  else
  // 4. ?OKLU PANEL MODU
  begin
    PX := OX + 2;
    for I := 0 to Sender^.FPanelCount - 1 do
    begin
      PW := Sender^.FPanels[I].Width;

      if (I = Sender^.FPanelCount - 1) or (PW <= 0) then
        PW := (OX + Sender^.Width - 2) - PX;

      if PW > 4 then
      begin
        // Panel ?er?evesi
        KLineH(PX, OY + 3, PW, $808080);
        KLineV(PX, OY + 3, Sender^.Height - 5, $808080);
        KLineH(PX, OY + Sender^.Height - 2, PW, $FFFFFF);
        KLineV(PX + PW - 1, OY + 3, Sender^.Height - 5, $FFFFFF);

        // Panel Metnini ?iz (@Dizi[0] adresi PChar'd?r)
        KStr(PX + 5, TextY, @Sender^.FPanels[I].Text[0], $000000);
      end;

      PX := PX + PW + 2;
      if PX >= (OX + Sender^.Width - 4) then Break;
    end;
  end;
end;


function CreateStatusBar(AParent: PObject; ALeft, ATop, AWidth: Integer;
                         AAlign: TAlign): PStatusBar;
begin
  Result := PStatusBar(MemAlloc(SizeOf(TStatusBar)));
  FillChar(Result^, SizeOf(TStatusBar), #0);
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := 22;
  Result^.Align := AAlign;
  Result^.Color := clBtnFace;
  Result^.BorderWidth := 0;
  Result^.ShowCaption := False;
  Result^.Cursor := 0;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.FPanelCount := 0;
  Result^.FSimplePanel := True;
  StrCopy(@Result^.FSimpleText[0], 'Hazir');
  Result^.BindPaint(@StatusBar_Draw);
 // Result^.BindDestroy(@StatusBarDestroy);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TMenuBar / TMenuItem                                                        }
{=============================================================================}

procedure MenuPopupDraw(Menu: PMenuItem; AbsX, AbsY: Integer);
var
  I, ItemY, ItemH, MaxW: Integer;
  TxtColor: LongWord;
  SubItem: PMenuItem;
begin
  if (Menu = nil) or (Menu^.SubCount = 0) or not Menu^.SubMenuVisible then Exit;

  ItemH := FONT_H + 6;
  MaxW := 80;
  for I := 0 to Menu^.SubCount - 1 do
  begin
    SubItem := PMenuItem(Menu^.SubItems^[I]);
    if SubItem = nil then Continue;
    if StrLen(SubItem^.Caption) * FONT_W + 24 > MaxW then
      MaxW := StrLen(SubItem^.Caption) * FONT_W + 24;
    if SubItem^.SubCount > 0 then Inc(MaxW, 12);
  end;

  KFill(AbsX, AbsY, MaxW, Menu^.SubCount * ItemH + 2, clBtnFace);
  KRect(AbsX, AbsY, MaxW, Menu^.SubCount * ItemH + 2, clBlack);
  KLineH(AbsX + 1, AbsY + 1, MaxW - 2, clWhite);
  KLineV(AbsX + 1, AbsY + 1, Menu^.SubCount * ItemH, clWhite);
  KLineH(AbsX + 1, AbsY + Menu^.SubCount * ItemH, MaxW - 2, cl3DShadow);
  KLineV(AbsX + MaxW - 2, AbsY + 1, Menu^.SubCount * ItemH, cl3DShadow);

  ItemY := AbsY + 1;
  for I := 0 to Menu^.SubCount - 1 do
  begin
    SubItem := PMenuItem(Menu^.SubItems^[I]);
    if SubItem = nil then begin Inc(ItemY, ItemH); Continue; end;

    if not SubItem^.Enabled then
      TxtColor := clGray
    else if I = Menu^.SubHoverIndex then
    begin
      KFill(AbsX + 1, ItemY, MaxW - 2, ItemH, $004080C0);
      TxtColor := clWhite;
    end
    else
      TxtColor := clBlack;

    if SubItem^.Caption[0] = '-' then
    begin
      KLineH(AbsX + 4, ItemY + ItemH div 2, MaxW - 8, cl3DShadow);
      KLineH(AbsX + 4, ItemY + ItemH div 2 + 1, MaxW - 8, clWhite);
    end
    else
    begin
      KStr(AbsX + 20, ItemY + 3, SubItem^.Caption, TxtColor);
      if SubItem^.Shortcut[0] <> #0 then
        KStrRight(AbsX + 4, ItemY + 3, MaxW - 8, SubItem^.Shortcut, TxtColor);
      if SubItem^.SubCount > 0 then
      begin
        KLine(AbsX + MaxW - 12, ItemY + ItemH div 2 - 2,
              AbsX + MaxW - 8, ItemY + ItemH div 2, TxtColor);
        KLine(AbsX + MaxW - 8, ItemY + ItemH div 2,
              AbsX + MaxW - 12, ItemY + ItemH div 2 + 2, TxtColor);
      end;
    end;

    { === Recursive: Bu subitem'in de acik submenusunu saginda ciz === }
    if SubItem^.SubMenuVisible and (SubItem^.SubCount > 0) then
      MenuPopupDraw(SubItem, AbsX + MaxW, ItemY);

    Inc(ItemY, ItemH);
  end;
end;

procedure MenuBarDraw(Sender: PMenuBar; AbsX, AbsY: Integer);
var
  I, ItemX, ItemW: Integer;
  TxtColor: LongWord;
  Item: PMenuItem;
begin
  KFill(AbsX, AbsY, Sender^.Width, MENU_BAR_HEIGHT, clBtnFace);
  KLineH(AbsX, AbsY + MENU_BAR_HEIGHT - 1, Sender^.Width, cl3DShadow);

  ItemX := AbsX + 4;
  for I := 0 to Sender^.ItemCount - 1 do
  begin
    Item := PMenuItem(Sender^.Items^[I]);
    if Item = nil then Continue;

    ItemW := StrLen(Item^.Caption) * FONT_W + 12;
    if (I = Sender^.ActiveIndex) or (I = Sender^.HoverIndex) then
    begin
      KFill(ItemX, AbsY + 1, ItemW, MENU_BAR_HEIGHT - 2, $00A0C8F0);
      KRect(ItemX, AbsY + 1, ItemW, MENU_BAR_HEIGHT - 2, $004080C0);
      TxtColor := clBlack;
    end
    else
      TxtColor := clBlack;

    KStr(ItemX + 6, AbsY + (MENU_BAR_HEIGHT - FONT_H) div 2,
         Item^.Caption, TxtColor);

    Item^.ItemLeft := ItemX - AbsX;
    Item^.ItemTop := 0;
    Item^.ItemWidth := ItemW;
    Item^.ItemHeight := MENU_BAR_HEIGHT;

    Inc(ItemX, ItemW + 4);
  end;

  if (Sender^.ActiveIndex >= 0) and
     (Sender^.ActiveIndex < Sender^.ItemCount) then
  begin
    Item := PMenuItem(Sender^.Items^[Sender^.ActiveIndex]);
    if (Item <> nil) and Item^.SubMenuVisible then
    begin
      Sender^.PopupAbsX := AbsX;
      Sender^.PopupAbsY := AbsY + MENU_BAR_HEIGHT;
      WinManager.ActiveMenuBar := Sender;
    end;
  end;

end;

procedure MenuBarMouseDown(Sender: PMenuBar; AX, AY: Integer; Btn: Byte);
var
  I: Integer;
  Item: PMenuItem;
begin
  if Btn <> 1 then Exit;
  for I := 0 to Sender^.ItemCount - 1 do
  begin
    Item := PMenuItem(Sender^.Items^[I]);
    if Item = nil then Continue;
    if (AX >= Item^.ItemLeft) and (AX < Item^.ItemLeft + Item^.ItemWidth) and
       (AY >= 0) and (AY < MENU_BAR_HEIGHT) then
    begin
      if Sender^.ActiveIndex = I then
      begin
        Sender^.ActiveIndex := -1;
        Item^.SubMenuVisible := False;
        WinManager.ActiveMenuBar := nil;   { YENI }
      end
      else
      begin
        if (Sender^.ActiveIndex >= 0) and
           (Sender^.ActiveIndex < Sender^.ItemCount) then
          PMenuItem(Sender^.Items^[Sender^.ActiveIndex])^.SubMenuVisible := False;
        Sender^.ActiveIndex := I;
        Item^.SubMenuVisible := True;
        WinManager.ActiveMenuBar := Sender; { YENI }
      end;
      Exit;
    end;
  end;
  if Sender^.ActiveIndex >= 0 then
  begin
    PMenuItem(Sender^.Items^[Sender^.ActiveIndex])^.SubMenuVisible := False;
    Sender^.ActiveIndex := -1;
    WinManager.ActiveMenuBar := nil;        { YENI }
  end;
end;


procedure MenuBarMouseMove(Sender: PMenuBar; AX, AY: Integer; Btn: Byte);
var
  I: Integer;
  Item: PMenuItem;
begin
  Sender^.HoverIndex := -1;
  if (AY < 0) or (AY >= MENU_BAR_HEIGHT) then Exit;
  for I := 0 to Sender^.ItemCount - 1 do
  begin
    Item := PMenuItem(Sender^.Items^[I]);
    if Item = nil then Continue;
    if (AX >= Item^.ItemLeft) and (AX < Item^.ItemLeft + Item^.ItemWidth) then
    begin
      Sender^.HoverIndex := I;
      if (Sender^.ActiveIndex >= 0) and (Sender^.ActiveIndex <> I) then
      begin
        PMenuItem(Sender^.Items^[Sender^.ActiveIndex])^.SubMenuVisible := False;
        Sender^.ActiveIndex := I;
        Item^.SubMenuVisible := True;
      end;
      Exit;
    end;
  end;
end;

procedure MenuBarMouseUp(Sender: PMenuBar; AX, AY: Integer; Btn: Byte);
begin
end;

procedure MenuPopupMouseDown(Sender: PMenuBar; AX, AY: Integer; Btn: Byte);
var
  Item, SubItem: PMenuItem;
  I, ItemH, RelY: Integer;
begin
  if Btn <> 1 then Exit;
  if Sender^.ActiveIndex < 0 then Exit;
  Item := PMenuItem(Sender^.Items^[Sender^.ActiveIndex]);
  if (Item = nil) or not Item^.SubMenuVisible then Exit;
  if (AX < Item^.ItemLeft) or (AX >= Item^.ItemLeft + Item^.ItemWidth) or
     (AY < MENU_BAR_HEIGHT) then
  begin
    Item^.SubMenuVisible := False;
    Sender^.ActiveIndex := -1;
    Exit;
  end;
  ItemH := FONT_H + 6;
  RelY := AY - MENU_BAR_HEIGHT - 1;
  I := RelY div ItemH;
  if (I >= 0) and (I < Item^.SubCount) then
  begin
    SubItem := PMenuItem(Item^.SubItems^[I]);
    if (SubItem <> nil) and SubItem^.Enabled and (SubItem^.Caption[0] <> '-') then
    begin
      if Assigned(SubItem^.OnClick) then
        SubItem^.OnClick(PObject(SubItem));
      Item^.SubMenuVisible := False;
      Sender^.ActiveIndex := -1;
    end;
  end;
end;

procedure MenuPopupMouseMove(Sender: PMenuBar; AX, AY: Integer; Btn: Byte);
var
  Item: PMenuItem;
  RelY, I, ItemH: Integer;
begin
  if Sender^.ActiveIndex < 0 then Exit;
  Item := PMenuItem(Sender^.Items^[Sender^.ActiveIndex]);
  if (Item = nil) or not Item^.SubMenuVisible then Exit;
  ItemH := FONT_H + 6;
  RelY := AY - MENU_BAR_HEIGHT - 1;
  if (AX >= Item^.ItemLeft) and (AY >= MENU_BAR_HEIGHT) then
  begin
    I := RelY div ItemH;
    if (I >= 0) and (I < Item^.SubCount) then
      Item^.SubHoverIndex := I
    else
      Item^.SubHoverIndex := -1;
  end
  else
    Item^.SubHoverIndex := -1;
end;

function CreateMenuItem(const ACaption: PChar): PMenuItem;
begin
  Result := PMenuItem(MemAlloc(SizeOf(TMenuItem)));
  FillChar(Result^, SizeOf(TMenuItem), #0);
  if ACaption <> nil then
    Move(ACaption[0], Result^.Caption[0], StrLen(ACaption));
  Result^.Enabled := True;
  Result^.SubCount := 0;
  Result^.SubCapacity := 0;
  Result^.SubItems := nil;
  Result^.SubHoverIndex := -1;
  Result^.SubMenuVisible := False;
end;

{ MenuItem'lar (CreateMenuItem/MenuItemAddSubItem) GUI.pas'in standart
  AddObject/Child agacina hic eklenmez - kendi SubItems dizisiyle ayri bir
  yap� olarak yonetilirler. Bu yuzden GUI.pas'in FreeObject'i (formun/
  MenuBar'in normal cocuk agacini gezerek yok eden mekanizma) bunlari
  GOREMEZ ve otomatik serbest birakamaz. Bu nedenle butun alt menu agacini
  (recursive) elle gezip her PMenuItem'i, once kendi SubItems'ini bosaltarak,
  sonra kendisini FreeMem ile serbest birakmamiz gerekiyor. }
procedure FreeMenuItemTree(Item: PMenuItem);
var
  I: Integer;
  Child: PMenuItem;
begin
  if Item = nil then Exit;
  for I := 0 to Item^.SubCount - 1 do
  begin
    Child := PMenuItem(Item^.SubItems^[I]);
    FreeMenuItemTree(Child);
  end;
  if Item^.SubItems <> nil then
  begin
    FreeMem(Item^.SubItems);
    Item^.SubItems := nil;
  end;
  FreeMem(Item);
end;

{=============================================================================}
{ Yardimci: PCharArray yeniden boyutlandirma                                  }
{=============================================================================}


{=============================================================================}
{ TMenuBar / TMenuItem                                                        }
{=============================================================================}



{ TObject.FireDestroy tarafindan cagirilir (sadece MenuBar'in kendisi icin -
  MenuBar gercekten AddObject ile forma eklenen bir TObject cocugudur, bu
  yuzden FreeObject onu bulup FireDestroy'unu tetikler). Butun ust seviye
  menu ogelerini (ve onlarin tum alt menu agaclarini) FreeMenuItemTree ile
  serbest biraktiktan sonra, Items dizisinin kendisini de serbest birakir. }
procedure MenuBarDestroy(Sender: PObject);
var
  MB: PMenuBar;
  I: Integer;
begin
  MB := PMenuBar(Sender);
  for I := 0 to MB^.ItemCount - 1 do
    FreeMenuItemTree(PMenuItem(MB^.Items^[I]));
  if MB^.Items <> nil then
  begin
    FreeMem(MB^.Items);
    MB^.Items := nil;
  end;
  MB^.ItemCount := 0;
  MB^.ItemCapacity := 0;
end;

function CreateMenuBar(AParent: PObject; ALeft, ATop, AWidth: Integer;
                       AAlign: TAlign): PMenuBar;
begin
  Result := PMenuBar(MemAlloc(SizeOf(TMenuBar)));
  FillChar(Result^, SizeOf(TMenuBar), #0);
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := MENU_BAR_HEIGHT;
  Result^.Align := AAlign;
  Result^.Color := clBtnFace;
  Result^.BorderWidth := 0;
  Result^.ShowCaption := False;
  Result^.Cursor := 0;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 10;
  Result^.ItemCount := 0;
  Result^.ItemCapacity := 0;
  Result^.Items := nil;
  Result^.ActiveIndex := -1;
  Result^.HoverIndex := -1;
  Result^.BindPaint(@MenuBarDraw);
  Result^.BindMouseDown(@MenuBarMouseDown);
  Result^.BindMouseMove(@MenuBarMouseMove);
  Result^.BindMouseUp(@MenuBarMouseUp);
  Result^.BindDestroy(@MenuBarDestroy);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;


{=============================================================================}
{ TListView  -  Yardimci Hesaplamalar                                         }
{=============================================================================}

procedure GrowPtrArray(var Arr: PPCharArray; var Cap: Integer; Need, ItemSize: Integer);
var
  NewCap, OldSize, NewSize: Integer;
  NewArr: Pointer;
begin
  if Need <= Cap then Exit;
  NewCap := Cap;
  if NewCap = 0 then NewCap := 8;
  while NewCap < Need do NewCap := NewCap * 2;
  OldSize := Cap * ItemSize;
  NewSize := NewCap * ItemSize;
  NewArr := ReallocMem(Arr, OldSize, NewSize);
  Arr := PPCharArray(NewArr);
  Cap := NewCap;
end;

procedure ListViewAddColumn(Sender: PListView; const ACaption: PChar; AWidth: Integer);
var
  Col: PListColumn;
begin
  if Sender^.ColumnCount >= Sender^.ColumnCap then
    GrowPtrArray(Sender^.Columns, Sender^.ColumnCap,
                 Sender^.ColumnCount + 1, SizeOf(PListColumn));

  Col := PListColumn(MemAlloc(SizeOf(TListColumn)));
  FillChar(Col^, SizeOf(TListColumn), #0);
  if ACaption <> nil then
    Move(ACaption[0], Col^.Caption[0], StrLen(ACaption));
  Col^.Width := AWidth;

  PPCharArray(Sender^.Columns)^[Sender^.ColumnCount] := PChar(Col);
  Inc(Sender^.ColumnCount);
end;

function ListViewAddItem(Sender: PListView; const ACaption: PChar;AImageIndex:Integer=0): Integer;
var
  Itm: PListViewItem;
begin
  if Sender^.ItemCount >= Sender^.ItemCap then
    GrowPtrArray(Sender^.Items, Sender^.ItemCap,
                 Sender^.ItemCount + 1, SizeOf(PListViewItem));

  Itm := PListViewItem(MemAlloc(SizeOf(TListViewItem)));
  FillChar(Itm^, SizeOf(TListViewItem), #0);
  if ACaption <> nil then
    Move(ACaption[0], Itm^.Caption[0], StrLen(ACaption));

  Itm^.ImageIndex:=AImageIndex;

  PPCharArray(Sender^.Items)^[Sender^.ItemCount] := PChar(Itm);
  Result := Sender^.ItemCount;
  Inc(Sender^.ItemCount);
end;

procedure ListViewSetSubItem(Sender: PListView; ItemIdx, SubIdx: Integer; const AText: PChar);
var
  Itm: PListViewItem;
  Len: Integer;
  P: PChar;
begin
  if (ItemIdx < 0) or (ItemIdx >= Sender^.ItemCount) then Exit;
  Itm := PListViewItem(PPCharArray(Sender^.Items)^[ItemIdx]);
  if Itm = nil then Exit;

  { SubItems dizisini genislet }
  if SubIdx >= Itm^.SubCap then
  begin
    GrowPtrArray(Itm^.SubItems, Itm^.SubCap, SubIdx + 1, SizeOf(PChar));
    Itm^.SubCount := Itm^.SubCap; { Basit: kapasite kadar say }
  end;

  { Eski metni temizle }
  if Itm^.SubItems^[SubIdx] <> nil then
    FreeMem(Itm^.SubItems^[SubIdx]);

  { Yeni metni kopyala }
  Len := StrLen(AText);
  P := PChar(MemAlloc(Len + 1));
  if P <> nil then
  begin
    Move(AText^, P^, Len + 1);
    Itm^.SubItems^[SubIdx] := P;
  end;
end;

procedure ListViewClear(Sender: PListView);
var
  I, J: Integer;
  Itm: PListViewItem;
begin
  for I := 0 to Sender^.ItemCount - 1 do
  begin
    Itm := PListViewItem(PPCharArray(Sender^.Items)^[I]);
    if Itm = nil then Continue;
    for J := 0 to Itm^.SubCount - 1 do
      if Itm^.SubItems^[J] <> nil then
        FreeMem(Itm^.SubItems^[J]);
    if Itm^.SubItems <> nil then FreeMem(Itm^.SubItems);
    FreeMem(Itm);
  end;
  Sender^.ItemCount := 0;
  Sender^.ItemIndex := -1;
  Sender^.HoverIndex := -1;
  Sender^.ScrollX := 0;
  Sender^.ScrollY := 0;
end;

{ TObject.FireDestroy tarafindan cagirilir. ListViewClear zaten her item'i
  (SubItems dahil) serbest birakiyor; burada ek olarak Items dizisinin
  kendisini, her sutun (PListColumn) kaydini ve Columns dizisinin kendisini
  de serbest birakiyoruz. }
procedure ListViewDestroy(Sender: PObject);
var
  LV: PListView;
  I: Integer;
  Col: PListColumn;
begin
  LV := PListView(Sender);

  ListViewClear(LV);
  if LV^.Items <> nil then
  begin
    FreeMem(LV^.Items);
    LV^.Items := nil;
  end;
  LV^.ItemCap := 0;

  for I := 0 to LV^.ColumnCount - 1 do
  begin
    Col := PListColumn(PPCharArray(LV^.Columns)^[I]);
    if Col <> nil then FreeMem(Col);
  end;
  if LV^.Columns <> nil then
  begin
    FreeMem(LV^.Columns);
    LV^.Columns := nil;
  end;
  LV^.ColumnCount := 0;
  LV^.ColumnCap := 0;
end;

procedure ListViewSetViewStyle(Sender: PListView; AStyle: Byte);
begin
  if AStyle > 2 then AStyle := 0;
  Sender^.ViewStyle := AStyle;
  Sender^.ScrollX := 0;
  Sender^.ScrollY := 0;
end;

{=============================================================================}
{ TListView  -  Scrollbar & Metrik Hesaplamalari                              }
{=============================================================================}

function ListViewGetColumn(Sender: PListView; Index: Integer): PListColumn;
begin
  if (Index < 0) or (Index >= Sender^.ColumnCount) then
    Result := nil
  else
    Result := PListColumn(PPCharArray(Sender^.Columns)^[Index]);
end;



function ListViewTotalColumnWidth(Sender: PListView): Integer;
var
  I: Integer;
  Col: PListColumn;
begin
  Result := 0;
  for I := 0 to Sender^.ColumnCount - 1 do
  begin
    Col := ListViewGetColumn(Sender, I);
    if Col <> nil then Inc(Result, Col^.Width);
  end;
end;

procedure ListViewCalcMetrics(Sender: PListView; out ClientW, ClientH, TotalW, TotalH: Integer);
var
  IconsPerRow, IconRows: Integer;
  ScrollW, ScrollH: Integer;
begin
  ScrollW := 0; ScrollH := 0;
  if Sender^.VScrollVisible then ScrollW := SCROLLBAR_SIZE;
  if Sender^.HScrollVisible then ScrollH := SCROLLBAR_SIZE;

  ClientW := Sender^.Width - 4 - ScrollW;
  ClientH := Sender^.Height - 4 - ScrollH;

  case Sender^.ViewStyle of
    0: { List }
      begin
        TotalW := ClientW;
        TotalH := Sender^.ItemCount * Sender^.RowHeight;
      end;
    1: { Icon }
      begin
        IconsPerRow := ClientW div (Sender^.IconSize + 16);
        if IconsPerRow < 1 then IconsPerRow := 1;
        IconRows := (Sender^.ItemCount + IconsPerRow - 1) div IconsPerRow;
        TotalW := ClientW;
        TotalH := IconRows * (Sender^.IconSize + FONT_H + 8);
      end;
    2: { Details }
      begin
        TotalW := ListViewTotalColumnWidth(Sender);
        if TotalW < ClientW then TotalW := ClientW;
        TotalH := Sender^.ItemCount * Sender^.RowHeight;
        Dec(ClientH, Sender^.HeaderHeight);
      end;
  end;
end;

procedure ListViewUpdateScrollbars(Sender: PListView);
var
  CW, CH, TW, TH: Integer;
  VTrackLen, HTrackLen: Integer;
begin
  Sender^.VScrollVisible := False;
  Sender^.HScrollVisible := False;

  ListViewCalcMetrics(Sender, CW, CH, TW, TH);

  if TH > CH then Sender^.VScrollVisible := True;
  if (Sender^.ViewStyle = 2) and (TW > CW) then Sender^.HScrollVisible := True;

  { Ikinci gecis: birbiri alan daraltir }
  if Sender^.HScrollVisible and Sender^.VScrollVisible then
  begin
    Dec(CW, SCROLLBAR_SIZE);
    Dec(CH, SCROLLBAR_SIZE);
    { Tekrar hesapla }
    if TH <= CH then Sender^.VScrollVisible := False;
    if (Sender^.ViewStyle <> 2) or (TW <= CW) then Sender^.HScrollVisible := False;
  end;

  { VScroll }
  if Sender^.VScrollVisible then
  begin
    VTrackLen := Sender^.Height - 4 - SCROLLBAR_SIZE * 2;
    if Sender^.HScrollVisible then Dec(VTrackLen, SCROLLBAR_SIZE);
    if VTrackLen < 0 then VTrackLen := 0;

    Sender^.VThumbSize := Max(16, CH * VTrackLen div TH);
    if Sender^.VThumbSize > VTrackLen then Sender^.VThumbSize := VTrackLen;

    if TH > CH then
      Sender^.VThumbPos := 2 + SCROLLBAR_SIZE +
        Sender^.ScrollY * (VTrackLen - Sender^.VThumbSize) div (TH - CH)
    else
      Sender^.VThumbPos := 2 + SCROLLBAR_SIZE;
  end;

  { HScroll (Details) }
  if Sender^.HScrollVisible then
  begin
    HTrackLen := Sender^.Width - 4 - SCROLLBAR_SIZE * 2;
    if Sender^.VScrollVisible then Dec(HTrackLen, SCROLLBAR_SIZE);
    if HTrackLen < 0 then HTrackLen := 0;

    Sender^.HThumbSize := Max(16, CW * HTrackLen div TW);
    if Sender^.HThumbSize > HTrackLen then Sender^.HThumbSize := HTrackLen;

    if TW > CW then
      Sender^.HThumbPos := 2 + SCROLLBAR_SIZE +
        Sender^.ScrollX * (HTrackLen - Sender^.HThumbSize) div (TW - CW)
    else
      Sender^.HThumbPos := 2 + SCROLLBAR_SIZE;
  end;
end;

{=============================================================================}
{ TListView  -  Cizim                                                         }
{=============================================================================}


function TruncateCaption(const Caption: PChar; MaxWidth, CharWidth: Integer): PChar;
var
  Len, MaxChars, ExtLen, BaseLen, i: Integer;
  Ext: array[0..15] of Char;
  DotPos: Integer;
  staticResult: array[0..255] of Char; // Ge�ici metin tamponu
begin
  Result := Caption;
  if Caption = nil then Exit;

  Len := StrLen(Caption);
  MaxChars := (MaxWidth - 8) div CharWidth; // Padding d���lm�� max karakter say�s�

  if (Len <= MaxChars) or (MaxChars < 4) then Exit;

  // Nokta (.) yani uzant� yerini bul (Sondan ba�a do�ru)
  DotPos := -1;
  for i := Len - 1 downto 0 do
  begin
    if Caption[i] = '.' then
    begin
      DotPos := i;
      Break;
    end;
  end;

  // Dosya uzant�l� ise (�rn: Cap$.bmp)
  if (DotPos > 0) and (Len - DotPos <= 5) then
  begin
    ExtLen := Len - DotPos; // Uzant� uzunlu�u (.bmp -> 4)
    BaseLen := MaxChars - ExtLen - 1; // 'Cap$' k�sm� i�in kalan yer

    if BaseLen < 1 then BaseLen := 1;

    // Dosya ad�n�n ba� k�sm�n� kopyala
    MemCopy(@staticResult[0], Caption, BaseLen);
    
    // Ayr��t�r�c� karakteri koy ('$' veya '...')
    staticResult[BaseLen] := '$';
    
    // Uzant�y� ekle (.bmp)
    MemCopy(@staticResult[BaseLen + 1], @Caption[DotPos], ExtLen + 1);
  end
  else
  begin
    // Uzant�s� yoksa veya �ok uzunsa d�z kes (�rn: Klasor$ )
    MemCopy(@staticResult[0], Caption, MaxChars - 1);
    staticResult[MaxChars - 1] := '$';
    staticResult[MaxChars] := #0;
  end;

  Result := @staticResult[0];
end;


procedure ListViewDraw(Sender: PListView; AbsX, AbsY: Integer);

var
  CX, CY, CW, CH: Integer;
  I, X, Y, Tx, Ty: Integer;
  TxtColor, BGColor: LongWord;
  IconsPerRow, IconRows, Col, Row: Integer;
  ItemH, ItemW: Integer;
  Itm: PListViewItem;
  LCol: PListColumn;
  P: PChar;
  ScrollW, ScrollH: Integer;
  ColX, ColIdx: Integer;
  IconSz, TextX: Integer;
begin
  ScrollW := 0; ScrollH := 0;
  if Sender^.VScrollVisible then ScrollW := SCROLLBAR_SIZE;
  if Sender^.HScrollVisible then ScrollH := SCROLLBAR_SIZE;

  CX := AbsX + 2;
  CY := AbsY + 2;
  CW := Sender^.Width - 4 - ScrollW;
  CH := Sender^.Height - 4 - ScrollH;

  { Arka plan & Border }
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, clBtnFace);
  KLineH(AbsX, AbsY, Sender^.Width, cl3DDkShadow);
  KLineV(AbsX, AbsY, Sender^.Height, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.Height - 1, Sender^.Width, cl3DHighLight);
  KLineV(AbsX + Sender^.Width - 1, AbsY, Sender^.Height, cl3DHighLight);
  KLineH(AbsX + 1, AbsY + 1, Sender^.Width - 2, clBlack);
  KLineV(AbsX + 1, AbsY + 1, Sender^.Height - 2, clBlack);
  KLineH(AbsX + 1, AbsY + Sender^.Height - 2, Sender^.Width - 2, clWhite);
  KLineV(AbsX + Sender^.Width - 2, AbsY + 1, Sender^.Height - 2, clWhite);

  if Sender^.ViewStyle = 2 then
    KFill(CX, CY + Sender^.HeaderHeight, CW, CH - Sender^.HeaderHeight, clWhite)
  else
    KFill(CX, CY, CW, CH, clWhite);

  { ====== DETAILS HEADER ====== }
  if Sender^.ViewStyle = 2 then
  begin
    KGradientH(CX, CY, CW, Sender^.HeaderHeight, $00A0C8F0, $004080C0);
    KLineH(CX, CY + Sender^.HeaderHeight, CW, cl3DDkShadow);

    ColX := CX - Sender^.ScrollX;
    for ColIdx := 0 to Sender^.ColumnCount - 1 do
    begin
      LCol := ListViewGetColumn(Sender, ColIdx);
      if LCol = nil then Continue;

      { Sutun basligi }
      if ColX + LCol^.Width > CX then
        KStrClip(ColX + 4, CY + (Sender^.HeaderHeight - FONT_H) div 2,
                 LCol^.Caption, clWhite,
                 CX, CY, CW, Sender^.HeaderHeight);

      { Sutun ayraci }
      KLineV(ColX + LCol^.Width, CY, Sender^.HeaderHeight, clWhite);
      KLineV(ColX + LCol^.Width + 1, CY, Sender^.HeaderHeight, cl3DDkShadow);

      Inc(ColX, LCol^.Width);
    end;
  end;

  { ====== ITEMS ====== }
  case Sender^.ViewStyle of
    0: { --- LIST --- }
      begin
        ItemH := Sender^.RowHeight;

        { Satir yuksekligine sigacak ikon boyutu (kucuk bir bosluk birak) }
        IconSz := ItemH - 4;
        if IconSz > Sender^.IconSize then IconSz := Sender^.IconSize;
        if IconSz < 8 then IconSz := 8;
        TextX := CX + IconSz + 8;   { metin ikonun sagindan baslar }

        for I := 0 to Sender^.ItemCount - 1 do
        begin
          Y := CY + I * ItemH - Sender^.ScrollY;
          if Y + ItemH < CY then Continue;
          if Y > CY + CH then Break;

          Itm := ListViewGetItem(Sender, I);
          if Itm = nil then Continue;

          if I = Sender^.ItemIndex then
          begin
            KFill(CX, Y, CW, ItemH, $004080C0);
            TxtColor := clWhite;
          end
          else if I = Sender^.HoverIndex then
          begin
            KFill(CX, Y, CW, ItemH, $00E0E8F0);
            TxtColor := clBlack;
          end
          else
            TxtColor := clBlack;


         //  Sender^.IconSize:=IconSz;
          // Itm^.ImageIndex:= GetImageIndex(Itm^.Caption);

         // DrawIcon(CX + 2, Y + (ItemH - IconSz) div 2, IconSz, TIconType(Itm^.ImageIndex));


          { Her satir icin (secili olsun olmasin) uzantiya gore ikon ciz }
          DrawFileIconByExt(CX + 2, Y + (ItemH - IconSz) div 2, IconSz,
                             Itm^.Caption, Itm^.ImageIndex = 1);

          KStr(TextX, Y + (ItemH - FONT_H) div 2, Itm^.Caption, TxtColor);

          if Sender^.GridLines then
            KLineH(CX, Y + ItemH, CW, $00D0D0D0);
        end;
      end;

    1: { --- ICON --- }
      begin
        { �kon ve metnin yan yana s��mas� i�in h�cre geni�li�i art�r�ld� (�rn: 48px �kon + 120px Metin) }
        ItemW := Sender^.IconSize + 120;
        ItemH := Sender^.IconSize + 8;
        if ItemH < FONT_H + 8 then ItemH := FONT_H + 8;

        IconsPerRow := CW div ItemW;
        if IconsPerRow < 1 then IconsPerRow := 1;

        for I := 0 to Sender^.ItemCount - 1 do
        begin
          Row := I div IconsPerRow;
          Col := I mod IconsPerRow;

          X := CX + Col * ItemW;
          Y := CY + Row * ItemH - Sender^.ScrollY;

          if Y + ItemH < CY then Continue;
          if Y > CY + CH then Break;

          Itm := ListViewGetItem(Sender, I);
          if Itm = nil then Continue;

          { Se�im & Hover Arka Plan� }
          if I = Sender^.ItemIndex then
          begin
            KFill(X, Y, ItemW - 4, ItemH, $004080C0);
            TxtColor := clWhite;
          end
          else if I = Sender^.HoverIndex then
          begin
            KFill(X, Y, ItemW - 4, ItemH, $00E0E8F0);
            TxtColor := clBlack;
          end
          else
            TxtColor := clBlack;

          { �kon Dizini Tespiti }
          if Itm^.ImageIndex = -1 then
             Itm^.ImageIndex := GetImageIndex(Itm^.Caption);

          { 1. �konu H�crenin Soluna �iz (Dikeyde Ortalanm��) }
          DrawIcon(X + 4, Y + (ItemH - Sender^.IconSize) div 2, 
                   Sender^.IconSize, TIconType(Itm^.ImageIndex));

          { 2. Metni �konun Sa��na Hizala (K�saltmas�z ve K�rpmal�) }
          // X konumu: H�cre Solu + Sol Padding (4) + �kon Boyutu + �kon-Metin Aras� Bo�luk (6)
          TextX := X + 4 + Sender^.IconSize + 6;
          
          // Metnin h�cre d���na ta�mamas� i�in KStrClip kullan�ld�
          KStrClip(TextX, Y + (ItemH - FONT_H) div 2, Itm^.Caption, TxtColor,
                   CX, CY, CW, CH);
        end;
      end;

   { 1: // --- ICON ---
      begin
        ItemW := Sender^.IconSize + 16;
        ItemH := Sender^.IconSize + FONT_H + 8;
        IconsPerRow := CW div ItemW;
        if IconsPerRow < 1 then IconsPerRow := 1;

        for I := 0 to Sender^.ItemCount - 1 do
        begin
          Row := I div IconsPerRow;
          Col := I mod IconsPerRow;

          X := CX + Col * ItemW + (ItemW - Sender^.IconSize) div 2;
          Y := CY + Row * ItemH - Sender^.ScrollY;

          if Y + ItemH < CY then Continue;
          if Y > CY + CH then Break;

          Itm := ListViewGetItem(Sender, I);
          if Itm = nil then Continue;

          if I = Sender^.ItemIndex then
          begin
            KFill(X - 4, Y - 2, ItemW, ItemH, $004080C0);
            TxtColor := clWhite;
          end
          else if I = Sender^.HoverIndex then
          begin
            KFill(X - 4, Y - 2, ItemW, ItemH, $00E0E8F0);
            TxtColor := clBlack;
          end
          else
            TxtColor := clBlack;


          // Sender^.IconSize:=48;


          if Itm^.ImageIndex=-1 then
             Itm^.ImageIndex:= GetImageIndex(Itm^.Caption);

           DrawIcon(X, Y, Sender^.IconSize, TIconType(Itm^.ImageIndex));


         // DrawFileIconByExt(X, Y, Sender^.IconSize, Itm^.Caption, Itm^.ImageIndex = 1);

         KStrCentered(X - 4, Y + Sender^.IconSize + 4, ItemW,
            TruncateCaption(Itm^.Caption, ItemW, 8), TxtColor);

       //   KStrCentered(X - 4, Y + Sender^.IconSize + 4, ItemW, Itm^.Caption, TxtColor);
        end;
      end;}

    2: { --- DETAILS (Multi-Column) --- }
      begin
        ItemH := Sender^.RowHeight;

        IconSz := ItemH - 4;
        if IconSz > Sender^.IconSize then IconSz := Sender^.IconSize;
        if IconSz < 8 then IconSz := 8;

        for I := 0 to Sender^.ItemCount - 1 do
        begin
          Y := CY + Sender^.HeaderHeight + I * ItemH - Sender^.ScrollY;
          if Y + ItemH < CY + Sender^.HeaderHeight then Continue;
          if Y > CY + CH then Break;

          Itm := ListViewGetItem(Sender, I);
          if Itm = nil then Continue;

          if I = Sender^.ItemIndex then
          begin
            KFill(CX, Y, CW, ItemH, $004080C0);
            TxtColor := clWhite;
          end
          else if I = Sender^.HoverIndex then
          begin
            KFill(CX, Y, CW, ItemH, $00E0E8F0);
            TxtColor := clBlack;
          end
          else
            TxtColor := clBlack;

          { Sutunlari ciz }
          ColX := CX - Sender^.ScrollX;
          for ColIdx := 0 to Sender^.ColumnCount - 1 do
          begin
            LCol := ListViewGetColumn(Sender, ColIdx);
            if LCol = nil then Continue;

            if ColIdx = 0 then
            begin
              P := Itm^.Caption;

              { Sadece 0. sutunda (ad sutunu), ikonu metinden once ciz ve
                metni ikonun sagina kaydir - boylece diger sutunlarin
                (Boyut/Tarih/Tur vb.) uzerine binmez }
              if (P <> nil) and (ColX + LCol^.Width > CX) then
              begin
                DrawFileIconByExt(ColX + 2, Y + (ItemH - IconSz) div 2, IconSz,
                                   Itm^.Caption, Itm^.ImageIndex = 1);

                // Sender^.IconSize:=IconSz;
          // Itm^.ImageIndex:= GetImageIndex(Itm^.Caption);

          // DrawIcon(ColX + 2, Y + (ItemH - IconSz) div 2, IconSz, TIconType(Itm^.ImageIndex));




                KStrClip(ColX + IconSz + 8, Y + (ItemH - FONT_H) div 2, P, TxtColor,
                         CX, CY + Sender^.HeaderHeight, CW, CH - Sender^.HeaderHeight);
              end;
            end
            else
            begin
              if (ColIdx - 1 < Itm^.SubCount) and (Itm^.SubItems <> nil) then
                P := Itm^.SubItems^[ColIdx - 1]
              else
                P := nil;

              if (P <> nil) and (ColX + LCol^.Width > CX) then
                KStrClip(ColX + 4, Y + (ItemH - FONT_H) div 2, P, TxtColor,
                         CX, CY + Sender^.HeaderHeight, CW, CH - Sender^.HeaderHeight);
            end;

            { Grid cizgileri }
            if Sender^.GridLines then
            begin
              KLineV(ColX + LCol^.Width, Y, ItemH, $00D0D0D0);
              KLineH(CX, Y + ItemH, CW, $00D0D0D0);
            end;

            Inc(ColX, LCol^.Width);
          end;
        end;
      end;
  end;

  { ====== SCROLLBARS ====== }
  ListViewUpdateScrollbars(Sender);

  { Dikey Scrollbar }
  if Sender^.VScrollVisible then
  begin
    X := AbsX + Sender^.Width - 2 - SCROLLBAR_SIZE;
    KFill(X, AbsY + 2, SCROLLBAR_SIZE, Sender^.Height - 4 - ScrollH, clBtnFace);
    KRect(X, AbsY + 2, SCROLLBAR_SIZE, Sender^.Height - 4 - ScrollH, cl3DShadow);

    KButton3D(X + 1, AbsY + 2, SCROLLBAR_SIZE - 2, SCROLLBAR_SIZE, False, clBtnFace);
    KLine(X + SCROLLBAR_SIZE div 2, AbsY + 6,
          X + SCROLLBAR_SIZE div 2 - 3, AbsY + 10, clBlack);
    KLine(X + SCROLLBAR_SIZE div 2, AbsY + 6,
          X + SCROLLBAR_SIZE div 2 + 3, AbsY + 10, clBlack);

    KButton3D(X + 1, AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE,
              SCROLLBAR_SIZE - 2, SCROLLBAR_SIZE, False, clBtnFace);
    KLine(X + SCROLLBAR_SIZE div 2 - 3,
          AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE + 4,
          X + SCROLLBAR_SIZE div 2,
          AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE + 8, clBlack);
    KLine(X + SCROLLBAR_SIZE div 2,
          AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE + 8,
          X + SCROLLBAR_SIZE div 2 + 3,
          AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE + 4, clBlack);

    if Sender^.VThumbSize > 0 then
      KButton3D(X + 1, AbsY + Sender^.VThumbPos,
                SCROLLBAR_SIZE - 2, Sender^.VThumbSize,
                Sender^.VDragging, clSilver);
  end;

  { Yatay Scrollbar }
  if Sender^.HScrollVisible then
  begin
    Y := AbsY + Sender^.Height - 2 - SCROLLBAR_SIZE;
    KFill(AbsX + 2, Y, Sender^.Width - 4 - ScrollW, SCROLLBAR_SIZE, clBtnFace);
    KRect(AbsX + 2, Y, Sender^.Width - 4 - ScrollW, SCROLLBAR_SIZE, cl3DShadow);

    KButton3D(AbsX + 2, Y + 1, SCROLLBAR_SIZE, SCROLLBAR_SIZE - 2, False, clBtnFace);
    KLine(AbsX + 6, Y + SCROLLBAR_SIZE div 2,
          AbsX + 10, Y + SCROLLBAR_SIZE div 2 - 3, clBlack);
    KLine(AbsX + 6, Y + SCROLLBAR_SIZE div 2,
          AbsX + 10, Y + SCROLLBAR_SIZE div 2 + 3, clBlack);

    KButton3D(AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE, Y + 1,
              SCROLLBAR_SIZE, SCROLLBAR_SIZE - 2, False, clBtnFace);
    KLine(AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE + 4,
          Y + SCROLLBAR_SIZE div 2 - 3,
          AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE + 8,
          Y + SCROLLBAR_SIZE div 2, clBlack);
    KLine(AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE + 8,
          Y + SCROLLBAR_SIZE div 2,
          AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE + 4,
          Y + SCROLLBAR_SIZE div 2 + 3, clBlack);

    if Sender^.HThumbSize > 0 then
      KButton3D(AbsX + Sender^.HThumbPos, Y + 1,
                Sender^.HThumbSize, SCROLLBAR_SIZE - 2,
                Sender^.HDragging, clSilver);
  end;
end;


procedure ListViewDraw1(Sender: PListView; AbsX, AbsY: Integer);
var
  CX, CY, CW, CH: Integer;
  I, X, Y, Tx, Ty: Integer;
  TxtColor, BGColor: LongWord;
  IconsPerRow, IconRows, Col, Row: Integer;
  ItemH, ItemW: Integer;
  Itm: PListViewItem;
  LCol: PListColumn;
  P: PChar;
  ScrollW, ScrollH: Integer;
  ColX, ColIdx: Integer;
begin
  ScrollW := 0; ScrollH := 0;
  if Sender^.VScrollVisible then ScrollW := SCROLLBAR_SIZE;
  if Sender^.HScrollVisible then ScrollH := SCROLLBAR_SIZE;

  CX := AbsX + 2;
  CY := AbsY + 2;
  CW := Sender^.Width - 4 - ScrollW;
  CH := Sender^.Height - 4 - ScrollH;

  { Arka plan & Border }
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, clBtnFace);
  KLineH(AbsX, AbsY, Sender^.Width, cl3DDkShadow);
  KLineV(AbsX, AbsY, Sender^.Height, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.Height - 1, Sender^.Width, cl3DHighLight);
  KLineV(AbsX + Sender^.Width - 1, AbsY, Sender^.Height, cl3DHighLight);
  KLineH(AbsX + 1, AbsY + 1, Sender^.Width - 2, clBlack);
  KLineV(AbsX + 1, AbsY + 1, Sender^.Height - 2, clBlack);
  KLineH(AbsX + 1, AbsY + Sender^.Height - 2, Sender^.Width - 2, clWhite);
  KLineV(AbsX + Sender^.Width - 2, AbsY + 1, Sender^.Height - 2, clWhite);

  if Sender^.ViewStyle = 2 then
    KFill(CX, CY + Sender^.HeaderHeight, CW, CH - Sender^.HeaderHeight, clWhite)
  else
    KFill(CX, CY, CW, CH, clWhite);

  { ====== DETAILS HEADER ====== }
  if Sender^.ViewStyle = 2 then
  begin
    KGradientH(CX, CY, CW, Sender^.HeaderHeight, $00A0C8F0, $004080C0);
    KLineH(CX, CY + Sender^.HeaderHeight, CW, cl3DDkShadow);

    ColX := CX - Sender^.ScrollX;
    for ColIdx := 0 to Sender^.ColumnCount - 1 do
    begin
      LCol := ListViewGetColumn(Sender, ColIdx);
      if LCol = nil then Continue;

      { S?tun basligi }
      if ColX + LCol^.Width > CX then
        KStrClip(ColX + 4, CY + (Sender^.HeaderHeight - FONT_H) div 2,
                 LCol^.Caption, clWhite,
                 CX, CY, CW, Sender^.HeaderHeight);

      { S?tun ayraci }
      KLineV(ColX + LCol^.Width, CY, Sender^.HeaderHeight, clWhite);
      KLineV(ColX + LCol^.Width + 1, CY, Sender^.HeaderHeight, cl3DDkShadow);

      Inc(ColX, LCol^.Width);
    end;
  end;

  { ====== ITEMS ====== }
  case Sender^.ViewStyle of
    0: { --- LIST --- }
      begin
        ItemH := Sender^.RowHeight;
        for I := 0 to Sender^.ItemCount - 1 do
        begin
          Y := CY + I * ItemH - Sender^.ScrollY;
          if Y + ItemH < CY then Continue;
          if Y > CY + CH then Break;

          Itm := ListViewGetItem(Sender, I);
          if Itm = nil then Continue;

          if I = Sender^.ItemIndex then
          begin

         // Itm := ListViewGetItem(Sender, I);
          DrawFileIconByExt(CX, Y, Sender^.IconSize, Itm^.Caption, False);

          // ImageList_DrawImageByIndex(ImageList1,Sender^.ItemIndex,CX, Y);

           // KFill(CX, Y, CW, ItemH, $004080C0);
            TxtColor := clWhite;
          end
          else if I = Sender^.HoverIndex then
          begin
            KFill(CX, Y, CW, ItemH, $00E0E8F0);
            TxtColor := clBlack;
          end
          else
            TxtColor := clBlack;

          KStr(CX + 4, Y + 2, Itm^.Caption, TxtColor);

          if Sender^.GridLines then
            KLineH(CX, Y + ItemH, CW, $00D0D0D0);
        end;
      end;

    1: { --- ICON --- }
      begin
        ItemW := Sender^.IconSize + 16;
        ItemH := Sender^.IconSize + FONT_H + 8;
        IconsPerRow := CW div ItemW;
        if IconsPerRow < 1 then IconsPerRow := 1;

        for I := 0 to Sender^.ItemCount - 1 do
        begin
          Row := I div IconsPerRow;
          Col := I mod IconsPerRow;

          X := CX + Col * ItemW + (ItemW - Sender^.IconSize) div 2;
          Y := CY + Row * ItemH - Sender^.ScrollY;

          if Y + ItemH < CY then Continue;
          if Y > CY + CH then Break;

          Itm := ListViewGetItem(Sender, I);
          if Itm = nil then Continue;

          if I = Sender^.ItemIndex then
          begin
             DrawFileIconByExt(CX, Y, Sender^.IconSize, Itm^.Caption, False);

            // ImageList_DrawImageByIndex(ImageList1,Sender^.ItemIndex,CX, Y);

           // KFill(X - 4, Y - 2, ItemW, ItemH, $004080C0);
            TxtColor := clWhite;
          end
          else if I = Sender^.HoverIndex then
          begin
            KFill(X - 4, Y - 2, ItemW, ItemH, $00E0E8F0);
            TxtColor := clBlack;
          end
          else
            TxtColor := clBlack;

          KButton3D(X, Y, Sender^.IconSize, Sender^.IconSize, False, clSilver);
          KFill(X + 4, Y + 4, Sender^.IconSize - 8, Sender^.IconSize - 8, $00E8E8E8);

          KStrCentered(X - 4, Y + Sender^.IconSize + 4, ItemW, Itm^.Caption, TxtColor);
        end;
      end;

    2: { --- DETAILS (Multi-Column) --- }
      begin
        ItemH := Sender^.RowHeight;
        for I := 0 to Sender^.ItemCount - 1 do
        begin
          Y := CY + Sender^.HeaderHeight + I * ItemH - Sender^.ScrollY;
          if Y + ItemH < CY + Sender^.HeaderHeight then Continue;
          if Y > CY + CH then Break;

          Itm := ListViewGetItem(Sender, I);
          if Itm = nil then Continue;

          if I = Sender^.ItemIndex then
          begin
              DrawFileIconByExt(CX, Y, Sender^.IconSize, Itm^.Caption, False);

            // ImageList_DrawImageByIndex(ImageList1,Sender^.ItemIndex,CX, Y);

           // KFill(CX, Y, CW, ItemH, $004080C0);
            TxtColor := clWhite;
          end
          else if I = Sender^.HoverIndex then
          begin
            KFill(CX, Y, CW, ItemH, $00E0E8F0);
            TxtColor := clBlack;
          end
          else
            TxtColor := clBlack;

          { S?tunlari ciz }
          ColX := CX - Sender^.ScrollX;
          for ColIdx := 0 to Sender^.ColumnCount - 1 do
          begin
            LCol := ListViewGetColumn(Sender, ColIdx);
            if LCol = nil then Continue;

            if ColIdx = 0 then
              P := Itm^.Caption
            else if (ColIdx - 1 < Itm^.SubCount) and (Itm^.SubItems <> nil) then
              P := Itm^.SubItems^[ColIdx - 1]
            else
              P := nil;

            if (P <> nil) and (ColX + LCol^.Width > CX) then
              KStrClip(ColX + 4, Y + 2, P, TxtColor,
                       CX, CY + Sender^.HeaderHeight, CW, CH - Sender^.HeaderHeight);

            { Grid cizgileri }
            if Sender^.GridLines then
            begin
              KLineV(ColX + LCol^.Width, Y, ItemH, $00D0D0D0);
              if I = Sender^.ItemCount - 1 then
                KLineH(CX, Y + ItemH, CW, $00D0D0D0)
              else
                KLineH(CX, Y + ItemH, CW, $00D0D0D0);
            end;

            Inc(ColX, LCol^.Width);
          end;
        end;
      end;
  end;

  { ====== SCROLLBARS ====== }
  ListViewUpdateScrollbars(Sender);

  { Dikey Scrollbar }
  if Sender^.VScrollVisible then
  begin
    X := AbsX + Sender^.Width - 2 - SCROLLBAR_SIZE;
    KFill(X, AbsY + 2, SCROLLBAR_SIZE, Sender^.Height - 4 - ScrollH, clBtnFace);
    KRect(X, AbsY + 2, SCROLLBAR_SIZE, Sender^.Height - 4 - ScrollH, cl3DShadow);

    KButton3D(X + 1, AbsY + 2, SCROLLBAR_SIZE - 2, SCROLLBAR_SIZE, False, clBtnFace);
    KLine(X + SCROLLBAR_SIZE div 2, AbsY + 6,
          X + SCROLLBAR_SIZE div 2 - 3, AbsY + 10, clBlack);
    KLine(X + SCROLLBAR_SIZE div 2, AbsY + 6,
          X + SCROLLBAR_SIZE div 2 + 3, AbsY + 10, clBlack);

    KButton3D(X + 1, AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE,
              SCROLLBAR_SIZE - 2, SCROLLBAR_SIZE, False, clBtnFace);
    KLine(X + SCROLLBAR_SIZE div 2 - 3,
          AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE + 4,
          X + SCROLLBAR_SIZE div 2,
          AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE + 8, clBlack);
    KLine(X + SCROLLBAR_SIZE div 2,
          AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE + 8,
          X + SCROLLBAR_SIZE div 2 + 3,
          AbsY + Sender^.Height - 4 - ScrollH - SCROLLBAR_SIZE + 4, clBlack);

    if Sender^.VThumbSize > 0 then
      KButton3D(X + 1, AbsY + Sender^.VThumbPos,
                SCROLLBAR_SIZE - 2, Sender^.VThumbSize,
                Sender^.VDragging, clSilver);
  end;

  { Yatay Scrollbar }
  if Sender^.HScrollVisible then
  begin
    Y := AbsY + Sender^.Height - 2 - SCROLLBAR_SIZE;
    KFill(AbsX + 2, Y, Sender^.Width - 4 - ScrollW, SCROLLBAR_SIZE, clBtnFace);
    KRect(AbsX + 2, Y, Sender^.Width - 4 - ScrollW, SCROLLBAR_SIZE, cl3DShadow);

    KButton3D(AbsX + 2, Y + 1, SCROLLBAR_SIZE, SCROLLBAR_SIZE - 2, False, clBtnFace);
    KLine(AbsX + 6, Y + SCROLLBAR_SIZE div 2,
          AbsX + 10, Y + SCROLLBAR_SIZE div 2 - 3, clBlack);
    KLine(AbsX + 6, Y + SCROLLBAR_SIZE div 2,
          AbsX + 10, Y + SCROLLBAR_SIZE div 2 + 3, clBlack);

    KButton3D(AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE, Y + 1,
              SCROLLBAR_SIZE, SCROLLBAR_SIZE - 2, False, clBtnFace);
    KLine(AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE + 4,
          Y + SCROLLBAR_SIZE div 2 - 3,
          AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE + 8,
          Y + SCROLLBAR_SIZE div 2, clBlack);
    KLine(AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE + 8,
          Y + SCROLLBAR_SIZE div 2,
          AbsX + Sender^.Width - 4 - ScrollW - SCROLLBAR_SIZE + 4,
          Y + SCROLLBAR_SIZE div 2 + 3, clBlack);

    if Sender^.HThumbSize > 0 then
      KButton3D(AbsX + Sender^.HThumbPos, Y + 1,
                Sender^.HThumbSize, SCROLLBAR_SIZE - 2,
                Sender^.HDragging, clSilver);
  end;
end;

{=============================================================================}
{ TListView  -  Fare Olaylari                                                 }
{=============================================================================}

procedure ListViewMouseDown(Sender: PListView; AX, AY: Integer; Btn: Byte);
var
  CW, CH, TW, TH: Integer;
  ScrollW, ScrollH: Integer;
  IconsPerRow, IconW, IconH, Row, Col: Integer;
  ItemH: Integer;
  VTrackLen, HTrackLen: Integer;
begin
  if Btn <> 1 then Exit;

  ScrollW := 0; ScrollH := 0;
  if Sender^.VScrollVisible then ScrollW := SCROLLBAR_SIZE;
  if Sender^.HScrollVisible then ScrollH := SCROLLBAR_SIZE;

  { VScroll hit }
  if Sender^.VScrollVisible and
     (AX >= Sender^.Width - 2 - SCROLLBAR_SIZE) and
     (AX < Sender^.Width - 2) and
     (AY >= 2 + SCROLLBAR_SIZE) and
     (AY < Sender^.Height - 2 - ScrollH - SCROLLBAR_SIZE) then
  begin
    if (AY >= Sender^.VThumbPos) and (AY < Sender^.VThumbPos + Sender^.VThumbSize) then
    begin
      Sender^.VDragging := True;
      Sender^.VDragStart := AY;
    end
    else if AY < Sender^.VThumbPos then
    begin
      ListViewCalcMetrics(Sender, CW, CH, TW, TH);
      Sender^.ScrollY := Max(0, Sender^.ScrollY - CH);
    end
    else
    begin
      ListViewCalcMetrics(Sender, CW, CH, TW, TH);
      Sender^.ScrollY := Sender^.ScrollY + CH;
      if Sender^.ScrollY > TH - CH then Sender^.ScrollY := TH - CH;
    end;
    Exit;
  end;

  { HScroll hit }
  if Sender^.HScrollVisible and
     (AY >= Sender^.Height - 2 - SCROLLBAR_SIZE) and
     (AY < Sender^.Height - 2) and
     (AX >= 2 + SCROLLBAR_SIZE) and
     (AX < Sender^.Width - 2 - ScrollW - SCROLLBAR_SIZE) then
  begin
    if (AX >= Sender^.HThumbPos) and (AX < Sender^.HThumbPos + Sender^.HThumbSize) then
    begin
      Sender^.HDragging := True;
      Sender^.HDragStart := AX;
    end
    else if AX < Sender^.HThumbPos then
    begin
      ListViewCalcMetrics(Sender, CW, CH, TW, TH);
      Sender^.ScrollX := Max(0, Sender^.ScrollX - CW);
    end
    else
    begin
      ListViewCalcMetrics(Sender, CW, CH, TW, TH);
      Sender^.ScrollX := Sender^.ScrollX + CW;
      if Sender^.ScrollX > TW - CW then Sender^.ScrollX := TW - CW;
    end;
    Exit;
  end;

  { Item secimi }
  CW := Sender^.Width - 4 - ScrollW;
  CH := Sender^.Height - 4 - ScrollH;

  case Sender^.ViewStyle of
    0: { List }
      begin
        ItemH := Sender^.RowHeight;
        if (AX >= 2) and (AX < 2 + CW) and (AY >= 2) and (AY < 2 + CH) then
        begin
          Row := (AY - 2 + Sender^.ScrollY) div ItemH;
          if (Row >= 0) and (Row < Sender^.ItemCount) then
            Sender^.ItemIndex := Row;
        end;
      end;

    1: { Icon }
      begin
      //  IconW := Sender^.IconSize + 16;
      IconW := Sender^.IconSize + 120;
        IconH := Sender^.IconSize + FONT_H + 8;
        IconsPerRow := CW div IconW;
        if IconsPerRow < 1 then IconsPerRow := 1;

        if (AX >= 2) and (AX < 2 + CW) and (AY >= 2) and (AY < 2 + CH) then
        begin
          Col := (AX - 2 + Sender^.ScrollX) div IconW;
          Row := (AY - 2 + Sender^.ScrollY) div IconH;
          if (Col >= 0) and (Col < IconsPerRow) then
          begin
            Row := Row * IconsPerRow + Col;
            if (Row >= 0) and (Row < Sender^.ItemCount) then
              Sender^.ItemIndex := Row;
          end;
        end;
      end;

    2: { Details }
      begin
        ItemH := Sender^.RowHeight;
        if (AX >= 2) and (AX < 2 + CW) and
           (AY >= 2 + Sender^.HeaderHeight) and (AY < 2 + CH) then
        begin
          Row := (AY - 2 - Sender^.HeaderHeight + Sender^.ScrollY) div ItemH;
          if (Row >= 0) and (Row < Sender^.ItemCount) then
            Sender^.ItemIndex := Row;
        end;
      end;
  end;
end;

procedure ListViewMouseMove(Sender: PListView; AX, AY: Integer; Btn: Byte);
var
  CW, CH, TW, TH: Integer;
  ScrollW, ScrollH: Integer;
  IconsPerRow, IconW, IconH, Row, Col: Integer;
  ItemH: Integer;
  VTrackLen, HTrackLen: Integer;
begin
  ScrollW := 0; ScrollH := 0;
  if Sender^.VScrollVisible then ScrollW := SCROLLBAR_SIZE;
  if Sender^.HScrollVisible then ScrollH := SCROLLBAR_SIZE;

  { VScroll surukleme }
  if Sender^.VDragging then
  begin
    ListViewCalcMetrics(Sender, CW, CH, TW, TH);
    VTrackLen := Sender^.Height - 4 - SCROLLBAR_SIZE * 2 - ScrollH;
    if (VTrackLen > 0) and (TH > CH) then
    begin
      Sender^.ScrollY := (AY - Sender^.VDragStart - 2 - SCROLLBAR_SIZE) *
                         (TH - CH) div VTrackLen;
      if Sender^.ScrollY < 0 then Sender^.ScrollY := 0;
      if Sender^.ScrollY > TH - CH then Sender^.ScrollY := TH - CH;
    end;
    Exit;
  end;

  { HScroll surukleme }
  if Sender^.HDragging then
  begin
    ListViewCalcMetrics(Sender, CW, CH, TW, TH);
    HTrackLen := Sender^.Width - 4 - SCROLLBAR_SIZE * 2 - ScrollW;
    if (HTrackLen > 0) and (TW > CW) then
    begin
      Sender^.ScrollX := (AX - Sender^.HDragStart - 2 - SCROLLBAR_SIZE) *
                         (TW - CW) div HTrackLen;
      if Sender^.ScrollX < 0 then Sender^.ScrollX := 0;
      if Sender^.ScrollX > TW - CW then Sender^.ScrollX := TW - CW;
    end;
    Exit;
  end;

  { Hover }
  CW := Sender^.Width - 4 - ScrollW;
  CH := Sender^.Height - 4 - ScrollH;

  case Sender^.ViewStyle of
    0:
      begin
        ItemH := Sender^.RowHeight;
        if (AX >= 2) and (AX < 2 + CW) and (AY >= 2) and (AY < 2 + CH) then
        begin
          Row := (AY - 2 + Sender^.ScrollY) div ItemH;
          if (Row >= 0) and (Row < Sender^.ItemCount) then
            Sender^.HoverIndex := Row
          else
            Sender^.HoverIndex := -1;
        end
        else
          Sender^.HoverIndex := -1;
      end;

    1:
      begin
       // IconW := Sender^.IconSize + 16;
       IconW := Sender^.IconSize + 120;
        IconH := Sender^.IconSize + FONT_H + 8;
        IconsPerRow := CW div IconW;
        if IconsPerRow < 1 then IconsPerRow := 1;

        if (AX >= 2) and (AX < 2 + CW) and (AY >= 2) and (AY < 2 + CH) then
        begin
          Col := (AX - 2 + Sender^.ScrollX) div IconW;
          Row := (AY - 2 + Sender^.ScrollY) div IconH;
          if (Col >= 0) and (Col < IconsPerRow) then
          begin
            Row := Row * IconsPerRow + Col;
            if (Row >= 0) and (Row < Sender^.ItemCount) then
              Sender^.HoverIndex := Row
            else
              Sender^.HoverIndex := -1;
          end
          else
            Sender^.HoverIndex := -1;
        end
        else
          Sender^.HoverIndex := -1;
      end;

    2:
      begin
        ItemH := Sender^.RowHeight;
        if (AX >= 2) and (AX < 2 + CW) and
           (AY >= 2 + Sender^.HeaderHeight) and (AY < 2 + CH) then
        begin
          Row := (AY - 2 - Sender^.HeaderHeight + Sender^.ScrollY) div ItemH;
          if (Row >= 0) and (Row < Sender^.ItemCount) then
            Sender^.HoverIndex := Row
          else
            Sender^.HoverIndex := -1;
        end
        else
          Sender^.HoverIndex := -1;
      end;
  end;
end;

procedure ListViewMouseUp(Sender: PListView; AX, AY: Integer; Btn: Byte);
begin
  Sender^.VDragging := False;
  Sender^.HDragging := False;
end;

{=============================================================================}
{ TListView  -  Klavye                                                        }
{=============================================================================}

procedure ListViewKeyDown(Sender: PListView; Key: Word);
var
  CW, CH, TW, TH: Integer;
  IconsPerRow :Integer;
begin
  case Key of
    VK_UP:
      if Sender^.ItemIndex > 0 then Dec(Sender^.ItemIndex)
      else Sender^.ItemIndex := 0;
    VK_DOWN:
      if Sender^.ItemIndex < Sender^.ItemCount - 1 then Inc(Sender^.ItemIndex)
      else Sender^.ItemIndex := Sender^.ItemCount - 1;
    VK_HOME:  Sender^.ItemIndex := 0;
    VK_END:   Sender^.ItemIndex := Sender^.ItemCount - 1;
    VK_PGUP:
      begin
        ListViewCalcMetrics(Sender, CW, CH, TW, TH);
        Sender^.ItemIndex := Max(0, Sender^.ItemIndex - CH div Sender^.RowHeight);
      end;
    VK_PGDOWN:
      begin
        ListViewCalcMetrics(Sender, CW, CH, TW, TH);
        Sender^.ItemIndex := Min(Sender^.ItemCount - 1,
                                 Sender^.ItemIndex + CH div Sender^.RowHeight);
      end;
  end;

  { Secili itemi g?r?n?r alana getir }
  ListViewCalcMetrics(Sender, CW, CH, TW, TH);
  if Sender^.ViewStyle = 1 then
  begin
    IconsPerRow := CW div (Sender^.IconSize + 16);
    if IconsPerRow < 1 then IconsPerRow := 1;
    if Sender^.ItemIndex >= 0 then
      Sender^.ScrollY := (Sender^.ItemIndex div IconsPerRow) *
                         (Sender^.IconSize + FONT_H + 8);
  end
  else
  begin
    if Sender^.ItemIndex * Sender^.RowHeight < Sender^.ScrollY then
      Sender^.ScrollY := Sender^.ItemIndex * Sender^.RowHeight
    else if (Sender^.ItemIndex + 1) * Sender^.RowHeight > Sender^.ScrollY + CH then
      Sender^.ScrollY := (Sender^.ItemIndex + 1) * Sender^.RowHeight - CH;
  end;

  if Sender^.ScrollY < 0 then Sender^.ScrollY := 0;
  if Sender^.ScrollX < 0 then Sender^.ScrollX := 0;
end;

{=============================================================================}
{ TListView  -  Fabrika                                                       }
{=============================================================================}

function CreateListView(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                        AAlign: TAlign): PListView;
begin
  Result := PListView(MemAlloc(SizeOf(TListView)));
  FillChar(Result^, SizeOf(TListView), #0);

  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := clBtnFace;
  Result^.BorderWidth := 2;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;

  Result^.ViewStyle := 0;
  Result^.ItemIndex := -1;
  Result^.HoverIndex := -1;
  Result^.ItemCount := 0;
  Result^.ItemCap := 0;
  Result^.Items := nil;

  Result^.ColumnCount := 0;
  Result^.ColumnCap := 0;
  Result^.Columns := nil;

  Result^.ScrollX := 0;
  Result^.ScrollY := 0;
  Result^.HeaderHeight := 20;
  Result^.RowHeight := FONT_H + 6;
  Result^.IconSize := 32;
  Result^.GridLines := True;

  Result^.VScrollVisible := False;
  Result^.HScrollVisible := False;
  Result^.VDragging := False;
  Result^.HDragging := False;

  Result^.BindPaint(@ListViewDraw);
  Result^.BindMouseDown(@ListViewMouseDown);
  Result^.BindMouseMove(@ListViewMouseMove);
  Result^.BindMouseUp(@ListViewMouseUp);
  Result^.BindKeyDown(@ListViewKeyDown);
  Result^.BindDestroy(@ListViewDestroy);

  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;


{==============================================================================}
{  TSCROLLBAR - IMPLEMENTATION                                                 }
{==============================================================================}

procedure ScrollBar_SetPosition(AScrollBar: PScrollBar; APos: Integer);
begin
  if AScrollBar = nil then Exit;
  if APos < AScrollBar^.Min then APos := AScrollBar^.Min;
  if APos > AScrollBar^.Max then APos := AScrollBar^.Max;
  AScrollBar^.Position := APos;
end;

procedure SB_DrawArrow(X, Y: Integer; Dir: Byte; Color: LongWord);
begin
  case Dir of
    0: KChar(X + 4, Y + 4, '<', Color);
    1: KChar(X + 4, Y + 4, '>', Color);
    2: KChar(X + 4, Y + 4, '^', Color);
    3: KChar(X + 4, Y + 4, 'v', Color);
  end;
end;

procedure ScrollBar_Draw(AScrollBar: PScrollBar;absX, absY: Integer);
var
 // absX, absY: Integer;
  trackPixels, thumbSize, thumbPos: Integer;
  btnSize: Integer;
begin
  if AScrollBar = nil then Exit;
  if not AScrollBar^.Visible then Exit;

// absX := ParentX + AScrollBar^.Left;
 // absY := ParentY + AScrollBar^.Top;
  btnSize := 16;

  { 3D kenarl?k }
  KRect3D(absX, absY, AScrollBar^.Width, AScrollBar^.Height, False);

  if AScrollBar^.Orientation = 0 then
  begin
    { Yatay ScrollBar }
    AScrollBar^.Btn1Rect.Left := 2;
    AScrollBar^.Btn1Rect.Top := 2;
    AScrollBar^.Btn1Rect.Right := 2 + btnSize;
    AScrollBar^.Btn1Rect.Bottom := AScrollBar^.Height - 2;

    AScrollBar^.Btn2Rect.Left := AScrollBar^.Width - 2 - btnSize;
    AScrollBar^.Btn2Rect.Top := 2;
    AScrollBar^.Btn2Rect.Right := AScrollBar^.Width - 2;
    AScrollBar^.Btn2Rect.Bottom := AScrollBar^.Height - 2;

    AScrollBar^.TrackRect.Left := AScrollBar^.Btn1Rect.Right;
    AScrollBar^.TrackRect.Top := 2;
    AScrollBar^.TrackRect.Right := AScrollBar^.Btn2Rect.Left;
    AScrollBar^.TrackRect.Bottom := AScrollBar^.Height - 2;

    { Track zemin }
    KFill(absX + AScrollBar^.TrackRect.Left, absY + AScrollBar^.TrackRect.Top,
          AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left,
          AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top, AScrollBar^.Color);

    { Butonlar }
    KButton3D(absX + AScrollBar^.Btn1Rect.Left, absY + AScrollBar^.Btn1Rect.Top,
              btnSize, AScrollBar^.Height - 4, False, AScrollBar^.BtnColor);
    KButton3D(absX + AScrollBar^.Btn2Rect.Left, absY + AScrollBar^.Btn2Rect.Top,
              btnSize, AScrollBar^.Height - 4, False, AScrollBar^.BtnColor);
    SB_DrawArrow(absX + AScrollBar^.Btn1Rect.Left, absY + AScrollBar^.Btn1Rect.Top, 0, $00000000);
    SB_DrawArrow(absX + AScrollBar^.Btn2Rect.Left, absY + AScrollBar^.Btn2Rect.Top, 1, $00000000);

    { Thumb }
    trackPixels := AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left;
    if AScrollBar^.Max > AScrollBar^.Min then
    begin
      thumbSize := (AScrollBar^.PageSize * trackPixels) div
                   (AScrollBar^.Max - AScrollBar^.Min + AScrollBar^.PageSize);
      if thumbSize < 8 then thumbSize := 8;
      if thumbSize > trackPixels then thumbSize := trackPixels;

      thumbPos := ((AScrollBar^.Position - AScrollBar^.Min) * (trackPixels - thumbSize)) div
                  (AScrollBar^.Max - AScrollBar^.Min);
      if thumbPos < 0 then thumbPos := 0;
      if thumbPos > trackPixels - thumbSize then thumbPos := trackPixels - thumbSize;
    end
    else
    begin
      thumbSize := trackPixels;
      thumbPos := 0;
    end;

    AScrollBar^.ThumbRect.Left := AScrollBar^.TrackRect.Left + thumbPos;
    AScrollBar^.ThumbRect.Top := 3;
    AScrollBar^.ThumbRect.Right := AScrollBar^.ThumbRect.Left + thumbSize;
    AScrollBar^.ThumbRect.Bottom := AScrollBar^.Height - 3;

    KButton3D(absX + AScrollBar^.ThumbRect.Left, absY + AScrollBar^.ThumbRect.Top,
              AScrollBar^.ThumbRect.Right - AScrollBar^.ThumbRect.Left,
              AScrollBar^.ThumbRect.Bottom - AScrollBar^.ThumbRect.Top, False, AScrollBar^.ThumbColor);
  end
  else
  begin
    { Dikey ScrollBar }
    AScrollBar^.Btn1Rect.Left := 2;
    AScrollBar^.Btn1Rect.Top := 2;
    AScrollBar^.Btn1Rect.Right := AScrollBar^.Width - 2;
    AScrollBar^.Btn1Rect.Bottom := 2 + btnSize;

    AScrollBar^.Btn2Rect.Left := 2;
    AScrollBar^.Btn2Rect.Top := AScrollBar^.Height - 2 - btnSize;
    AScrollBar^.Btn2Rect.Right := AScrollBar^.Width - 2;
    AScrollBar^.Btn2Rect.Bottom := AScrollBar^.Height - 2;

    AScrollBar^.TrackRect.Left := 2;
    AScrollBar^.TrackRect.Top := AScrollBar^.Btn1Rect.Bottom;
    AScrollBar^.TrackRect.Right := AScrollBar^.Width - 2;
    AScrollBar^.TrackRect.Bottom := AScrollBar^.Btn2Rect.Top;

    { Track zemin }
    KFill(absX + AScrollBar^.TrackRect.Left, absY + AScrollBar^.TrackRect.Top,
          AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left,
          AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top, AScrollBar^.Color);

    { Butonlar }
    KButton3D(absX + AScrollBar^.Btn1Rect.Left, absY + AScrollBar^.Btn1Rect.Top,
              AScrollBar^.Width - 4, btnSize, False, AScrollBar^.BtnColor);
    KButton3D(absX + AScrollBar^.Btn2Rect.Left, absY + AScrollBar^.Btn2Rect.Top,
              AScrollBar^.Width - 4, btnSize, False, AScrollBar^.BtnColor);
    SB_DrawArrow(absX + AScrollBar^.Btn1Rect.Left, absY + AScrollBar^.Btn1Rect.Top, 2, $00000000);
    SB_DrawArrow(absX + AScrollBar^.Btn2Rect.Left, absY + AScrollBar^.Btn2Rect.Top, 3, $00000000);

    { Thumb }
    trackPixels := AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top;
    if AScrollBar^.Max > AScrollBar^.Min then
    begin
      thumbSize := (AScrollBar^.PageSize * trackPixels) div
                   (AScrollBar^.Max - AScrollBar^.Min + AScrollBar^.PageSize);
      if thumbSize < 8 then thumbSize := 8;
      if thumbSize > trackPixels then thumbSize := trackPixels;

      thumbPos := ((AScrollBar^.Position - AScrollBar^.Min) * (trackPixels - thumbSize)) div
                  (AScrollBar^.Max - AScrollBar^.Min);
      if thumbPos < 0 then thumbPos := 0;
      if thumbPos > trackPixels - thumbSize then thumbPos := trackPixels - thumbSize;
    end
    else
    begin
      thumbSize := trackPixels;
      thumbPos := 0;
    end;

    AScrollBar^.ThumbRect.Left := 3;
    AScrollBar^.ThumbRect.Top := AScrollBar^.TrackRect.Top + thumbPos;
    AScrollBar^.ThumbRect.Right := AScrollBar^.Width - 3;
    AScrollBar^.ThumbRect.Bottom := AScrollBar^.ThumbRect.Top + thumbSize;

    KButton3D(absX + AScrollBar^.ThumbRect.Left, absY + AScrollBar^.ThumbRect.Top,
              AScrollBar^.ThumbRect.Right - AScrollBar^.ThumbRect.Left,
              AScrollBar^.ThumbRect.Bottom - AScrollBar^.ThumbRect.Top, False, AScrollBar^.ThumbColor);
  end;
end;

procedure ScrollBar_MouseDown(AScrollBar: PScrollBar; X, Y: Integer; Btn: Byte);
var
  trackPixels, thumbSize: Integer;
  clickPos: Integer;
begin
  if AScrollBar = nil then Exit;

  { Btn1 (sol/yukar?) }
  if (X >= AScrollBar^.Btn1Rect.Left) and (X < AScrollBar^.Btn1Rect.Right) and
     (Y >= AScrollBar^.Btn1Rect.Top) and (Y < AScrollBar^.Btn1Rect.Bottom) then
  begin
    ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position - AScrollBar^.SmallChange);
    Exit;
  end;

  { Btn2 (sa?/a?a??) }
  if (X >= AScrollBar^.Btn2Rect.Left) and (X < AScrollBar^.Btn2Rect.Right) and
     (Y >= AScrollBar^.Btn2Rect.Top) and (Y < AScrollBar^.Btn2Rect.Bottom) then
  begin
    ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position + AScrollBar^.SmallChange);
    Exit;
  end;

  { Thumb }
  if (X >= AScrollBar^.ThumbRect.Left) and (X < AScrollBar^.ThumbRect.Right) and
     (Y >= AScrollBar^.ThumbRect.Top) and (Y < AScrollBar^.ThumbRect.Bottom) then
  begin
    AScrollBar^.Dragging := True;
    if AScrollBar^.Orientation = 0 then
      AScrollBar^.DragStart := X
    else
      AScrollBar^.DragStart := Y;
    AScrollBar^.DragStartVal := AScrollBar^.Position;
    Exit;
  end;

  { Track (bo? alan) - Page Size }
  if (X >= AScrollBar^.TrackRect.Left) and (X < AScrollBar^.TrackRect.Right) and
     (Y >= AScrollBar^.TrackRect.Top) and (Y < AScrollBar^.TrackRect.Bottom) then
  begin
    if AScrollBar^.Orientation = 0 then
    begin
      trackPixels := AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left;
      thumbSize := AScrollBar^.ThumbRect.Right - AScrollBar^.ThumbRect.Left;
      clickPos := X - AScrollBar^.TrackRect.Left;
      if clickPos < (AScrollBar^.ThumbRect.Left - AScrollBar^.TrackRect.Left) then
        ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position - AScrollBar^.PageSize)
      else
        ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position + AScrollBar^.PageSize);
    end
    else
    begin
      trackPixels := AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top;
      thumbSize := AScrollBar^.ThumbRect.Bottom - AScrollBar^.ThumbRect.Top;
      clickPos := Y - AScrollBar^.TrackRect.Top;
      if clickPos < (AScrollBar^.ThumbRect.Top - AScrollBar^.TrackRect.Top) then
        ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position - AScrollBar^.PageSize)
      else
        ScrollBar_SetPosition(AScrollBar, AScrollBar^.Position + AScrollBar^.PageSize);
    end;
  end;
end;

procedure ScrollBar_MouseMove(AScrollBar: PScrollBar; X, Y: Integer; Btn: Byte);
var
  deltaMouse, trackPixels, thumbSize, maxPos: Integer;
begin
  if AScrollBar = nil then Exit;
  if not AScrollBar^.Dragging then Exit;

  if AScrollBar^.Orientation = 0 then
  begin
    deltaMouse := X - AScrollBar^.DragStart;
    trackPixels := AScrollBar^.TrackRect.Right - AScrollBar^.TrackRect.Left;
    thumbSize := AScrollBar^.ThumbRect.Right - AScrollBar^.ThumbRect.Left;
  end
  else
  begin
    deltaMouse := Y - AScrollBar^.DragStart;
    trackPixels := AScrollBar^.TrackRect.Bottom - AScrollBar^.TrackRect.Top;
    thumbSize := AScrollBar^.ThumbRect.Bottom - AScrollBar^.ThumbRect.Top;
  end;

  if (trackPixels > thumbSize) and (AScrollBar^.Max > AScrollBar^.Min) then
  begin
    maxPos := AScrollBar^.Max - AScrollBar^.Min;
    AScrollBar^.Position := AScrollBar^.DragStartVal +
      (deltaMouse * maxPos) div (trackPixels - thumbSize);
    if AScrollBar^.Position < AScrollBar^.Min then AScrollBar^.Position := AScrollBar^.Min;
    if AScrollBar^.Position > AScrollBar^.Max then AScrollBar^.Position := AScrollBar^.Max;
  end;
end;

procedure ScrollBar_MouseUp(AScrollBar: PScrollBar; X, Y: Integer; Btn: Byte);
begin
  if AScrollBar = nil then Exit;
  AScrollBar^.Dragging := False;
end;


function CreateScrollBar(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign): PScrollBar;
begin
  Result := MemAlloc(SizeOf(TScrollBar));
  if Result = nil then begin Result := nil; Exit; end;
  MemSet(Result, 0, SizeOf(TScrollBar));


  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Visible := True;
  Result^.Min := 0;
  Result^.Max := 100;
  Result^.Position := 0;
  Result^.PageSize := 10;
  Result^.SmallChange := 1;
  Result^.BorderColor := $00808080;
  Result^.Color := $00E0E0E0;
  Result^.ThumbColor := $00D0D0D0;
  Result^.BtnColor := $00DCDCDC;
  Result^.Dragging := False;

  Result^.Align := AAlign;
  Result^.Color := clBtnFace;
  Result^.BorderWidth := 0;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;

  { Boyuta g?re otomatik y?n }
  if AWidth > AHeight then
    Result^.Orientation := 0
  else
    Result^.Orientation := 1;

  Result^.BindPaint(@ScrollBar_Draw);
  Result^.BindMouseDown(@ScrollBar_MouseDown);
  Result^.BindMouseMove(@ScrollBar_MouseMove);
  Result^.BindMouseUp(@ScrollBar_MouseUp);
 // Result^.BindKeyDown(@ScrollBar_KeyDown);

  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

{=============================================================================}
{ TTabControl                                                                 }
{=============================================================================}

{ Sekme seridi uzerinde AX,AY (control-local koordinat) hangi sekmeye denk
  geliyor - hem MouseDown hem MouseMove(hover) tarafindan kullanilir. }
function TabControlHitTest(TC: PTabControl; AX, AY: Integer; out Index: Integer): Boolean;
var
  I, TX, TW: Integer;
begin
  Result := False;
  Index := -1;
  if (AY < 2) or (AY >= TC^.TabHeight) then Exit;

  TX := 2;
  for I := 0 to TC^.TabCount - 1 do
  begin
    TW := StrLen(TC^.Tabs^[I]) * FONT_W + 16;
    if (AX >= TX) and (AX < TX + TW) then
    begin
      Index := I;
      Result := True;
      Exit;
    end;
    Inc(TX, TW);
  end;
end;

{ ActiveIndex'e gore sayfalarin Visible/Left/Top/Width/Height alanlarini
  gunceller. Her Draw'da cagrilir - boylece TabControl yeniden boyutlandirilsa
  bile (orn. Align ile) sayfalar her zaman dogru alani doldurur. }
procedure TabControlSyncPages(TC: PTabControl);
var
  I: Integer;
  Pg: PObject;
  NewH: Integer;
begin
  NewH := TC^.Height - TC^.TabHeight;
  if NewH < 0 then NewH := 0;
  for I := 0 to TC^.TabCount - 1 do
  begin
    Pg := PObject(TC^.Pages^[I]);
    if Pg = nil then Continue;
    Pg^.Visible := (I = TC^.ActiveIndex);
    Pg^.Left   := 0;
    Pg^.Top    := TC^.TabHeight;
    Pg^.Width  := TC^.Width;
    Pg^.Height := NewH;
  end;
end;

procedure TabControlDraw(Sender: PTabControl; AbsX, AbsY: Integer);
var
  I, TX, TW: Integer;
  Bg: LongWord;
begin
  TabControlSyncPages(Sender);

  KFill(AbsX, AbsY, Sender^.Width, Sender^.TabHeight, clBtnFace);
  KLineH(AbsX, AbsY + Sender^.TabHeight - 1, Sender^.Width, cl3DDkShadow);

  TX := AbsX + 2;
  for I := 0 to Sender^.TabCount - 1 do
  begin
    TW := StrLen(Sender^.Tabs^[I]) * FONT_W + 16;

    if I = Sender^.ActiveIndex then Bg := clWhite
    else if I = Sender^.HoverIndex then Bg := $00E0E8F0
    else Bg := clBtnFace;

    KFill(TX, AbsY + 2, TW, Sender^.TabHeight - 2, Bg);
    KLineH(TX, AbsY + 2, TW, cl3DDkShadow);
    KLineV(TX, AbsY + 2, Sender^.TabHeight - 2, cl3DDkShadow);
    KLineV(TX + TW - 1, AbsY + 2, Sender^.TabHeight - 2, cl3DDkShadow);
    if I = Sender^.ActiveIndex then
      { aktif sekmenin alt kenari, govdeyle birlesecek sekilde 'kesilir' }
      KLineH(TX + 1, AbsY + Sender^.TabHeight - 1, TW - 2, clWhite);

    KStrCentered(TX, AbsY + 2 + (Sender^.TabHeight - 2 - FONT_H) div 2, TW,
                 Sender^.Tabs^[I], clBlack);
    Inc(TX, TW);
  end;

  KFill(AbsX, AbsY + Sender^.TabHeight, Sender^.Width, Sender^.Height - Sender^.TabHeight, clWhite);
  KRect(AbsX, AbsY + Sender^.TabHeight, Sender^.Width, Sender^.Height - Sender^.TabHeight, cl3DDkShadow);
end;

procedure TabControlMouseDown(Sender: PTabControl; AX, AY: Integer; Btn: Byte);
var
  Idx: Integer;
begin
  if Btn <> 1 then Exit;
  if not TabControlHitTest(Sender, AX, AY, Idx) then Exit;
  if Idx = Sender^.ActiveIndex then Exit;

  Sender^.ActiveIndex := Idx;
  TabControlSyncPages(Sender);
  if Assigned(Sender^.OnChange) then Sender^.OnChange(PObject(Sender));
end;

procedure TabControlMouseMove(Sender: PTabControl; AX, AY: Integer; Btn: Byte);
var
  Idx: Integer;
begin
  if TabControlHitTest(Sender, AX, AY, Idx) then
    Sender^.HoverIndex := Idx
  else
    Sender^.HoverIndex := -1;
end;

{ TObject.FireDestroy tarafindan cagirilir. Sekme basliklarinin (Tabs[i])
  PChar'larini ve Tabs dizisinin kendisini serbest birakir. Pages dizisindeki
  PPanel'ler ise GERCEK cocuklardir (TabControlAddTab icinde CreatePanel ->
  AParent^.AddObject ile eklenmislerdir); GUI.pas'in FreeObject'i TabControl'u
  yok ederken bu paneli zaten kendi cocuk agacinda bulup otomatik serbest
  birakacaktir - bu yuzden burada Pages^[i] icin FreeMem CAGIRMIYORUZ (cift
  serbest birakma / dangling pointer riski olur), sadece isaretci dizisinin
  (Pages) kendisini serbest birakiyoruz. }
procedure TabControlDestroy(Sender: PObject);
var
  TC: PTabControl;
  I: Integer;
begin
  TC := PTabControl(Sender);
  for I := 0 to TC^.TabCount - 1 do
    if TC^.Tabs^[I] <> nil then
      FreeMem(TC^.Tabs^[I]);
  if TC^.Tabs <> nil then
  begin
    FreeMem(TC^.Tabs);
    TC^.Tabs := nil;
  end;
  if TC^.Pages <> nil then
  begin
    FreeMem(TC^.Pages);
    TC^.Pages := nil;
  end;
  TC^.TabCount := 0;
  TC^.TabCapacity := 0;
  TC^.PageCapacity := 0;
end;

function CreateTabControl(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
  AAlign: TAlign): PTabControl;
begin
  Result := PTabControl(MemAlloc(SizeOf(TTabControl)));
  FillChar(Result^, SizeOf(TTabControl), #0);
  Result^.Left   := ALeft;
  Result^.Top    := ATop;
  Result^.Width  := AWidth;
  if AHeight < 1 then Result^.Height := 200 else Result^.Height := AHeight;
  Result^.Align  := AAlign;
  Result^.Color  := clWhite;
  Result^.BorderWidth := 0;
  Result^.ShowCaption := False;
  Result^.Cursor := 0;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.TabHeight := FONT_H + 10;
  Result^.ActiveIndex := -1;
  Result^.HoverIndex := -1;
  Result^.TabCount := 0;
  Result^.TabCapacity := 0;
  Result^.PageCapacity := 0;
  Result^.Tabs := nil;
  Result^.Pages := nil;
  Result^.BindPaint(@TabControlDraw);
  Result^.BindMouseDown(@TabControlMouseDown);
  Result^.BindMouseMove(@TabControlMouseMove);
  Result^.BindDestroy(@TabControlDestroy);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

function TabControlAddTab(TC: PTabControl; const ACaption: PChar): PPanel;
var
  Len: Integer;
  P: PChar;
  Page: PPanel;
begin
  if TC^.TabCount >= TC^.TabCapacity then
    GrowPCharArray(TC^.Tabs, TC^.TabCapacity, TC^.TabCount + 1);
  if TC^.TabCount >= TC^.PageCapacity then
    GrowPCharArray(TC^.Pages, TC^.PageCapacity, TC^.TabCount + 1);

  Len := StrLen(ACaption);
  P := PChar(MemAlloc(Len + 1));
  Move(ACaption^, P^, Len + 1);
  TC^.Tabs^[TC^.TabCount] := P;

  { Sayfa: gercek bir TPanel, TabControl'un cocugu olarak eklenir. Kullanici
    kendi component'lerini BU panelin (PObject(Page)) altina ekler. Konum/
    boyut, TabControlSyncPages tarafindan her cizimde otomatik guncellenir,
    bu yuzden burada verilen degerler sadece baslangic degeridir. }
  Page := CreatePanel(PObject(TC), 0, TC^.TabHeight, TC^.Width,
                       TC^.Height - TC^.TabHeight, alNone);
  Page^.Color := clWhite;
  Page^.BorderWidth := 0;
  Page^.Tag := TC^.TabCount;
  TC^.Pages^[TC^.TabCount] := PChar(Page);

  Result := Page;
  Inc(TC^.TabCount);

  if TC^.ActiveIndex < 0 then
    TC^.ActiveIndex := 0;
  TabControlSyncPages(TC);
end;

procedure TabControlSetActive(TC: PTabControl; Index: Integer);
begin
  if (TC = nil) or (Index < 0) or (Index >= TC^.TabCount) then Exit;
  TC^.ActiveIndex := Index;
  TabControlSyncPages(TC);
  if Assigned(TC^.OnChange) then TC^.OnChange(PObject(TC));
end;

{=============================================================================}
{ TTreeView                                                                   }
{=============================================================================}

{=============================================================================}
{ TTreeView                                                                   }
{=============================================================================}

const
  TREE_INDENT = 16;
  TREE_BOX    = 9;
  TREE_MAX_VISIBLE = 256;  { Draw/MouseDown icin gecici "gorunur satir" tamponu }

function TreeViewNode(TV: PTreeView; Index: Integer): PTreeNode;
begin
  Result := PTreeNode(TV^.Nodes^[Index]);
end;

{ Index'in en az bir cocugu var mi (dogrudan alt dugum taramasi). }
function TreeViewHasChildren(TV: PTreeView; Index: Integer): Boolean;
var
  I: Integer;
begin
  Result := False;
  for I := 0 to TV^.NodeCount - 1 do
    if TreeViewNode(TV, I)^.ParentIndex = Index then
    begin
      Result := True;
      Exit;
    end;
end;

{ ParentIdx'in dogrudan cocuklarini (ekleme sirasiyla) VisList'e ekler; her
  cocuk Expanded ise hemen ardindan kendi cocuklarini (recursive, DFS) ekler.
  Boylece sonuc, agacin gorsel (dikey) sirasini birebir yansitir - dugumlerin
  TreeViewAddNode'a hangi sirayla eklendigi (NodeCount indeksleri) onemli
  degildir, sadece agac hiyerarsisi (ParentIndex) belirleyicidir. }
procedure TreeViewCollectVisible(TV: PTreeView; ParentIdx: Integer;
  var VisList: array of Integer; var Count: Integer);
var
  I: Integer;
begin
  for I := 0 to TV^.NodeCount - 1 do
  begin
    if Count > High(VisList) then Exit;
    if TreeViewNode(TV, I)^.ParentIndex = ParentIdx then
    begin
      VisList[Count] := I;
      Inc(Count);
      if TreeViewNode(TV, I)^.Expanded then
        TreeViewCollectVisible(TV, I, VisList, Count);
    end;
  end;
end;

function TreeViewBuildVisible(TV: PTreeView; var VisList: array of Integer): Integer;
begin
  Result := 0;
  TreeViewCollectVisible(TV, -1, VisList, Result);
end;

procedure TreeViewDraw(Sender: PTreeView; AbsX, AbsY: Integer);
var
  VisList: array[0..TREE_MAX_VISIBLE - 1] of Integer;
  VisCount, VisibleRows, ScrollW, ClientW: Integer;
  I, Row, ItemY, NodeIdx, BoxX, TextX: Integer;
  Node: PTreeNode;
  TxtColor: LongWord;
  ScrollVisible: Boolean;
begin
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, clWhite);
  KLineH(AbsX, AbsY, Sender^.Width, cl3DDkShadow);
  KLineV(AbsX, AbsY, Sender^.Height, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.Height - 1, Sender^.Width, cl3DHighLight);
  KLineV(AbsX + Sender^.Width - 1, AbsY, Sender^.Height, cl3DHighLight);

  VisCount := TreeViewBuildVisible(Sender, VisList);
  ScrollW := SCROLLBAR_SIZE;
  VisibleRows := (Sender^.Height - 4) div Sender^.ItemHeight;
  ScrollVisible := VisCount > VisibleRows;

  if ScrollVisible then
    ClientW := Sender^.Width - 4 - ScrollW
  else
    ClientW := Sender^.Width - 4;

  for Row := 0 to VisibleRows - 1 do
  begin
    if Sender^.ScrollIndex + Row >= VisCount then Break;
    NodeIdx := VisList[Sender^.ScrollIndex + Row];
    Node := TreeViewNode(Sender, NodeIdx);
    ItemY := AbsY + 2 + Row * Sender^.ItemHeight;

    if NodeIdx = Sender^.SelectedIndex then
    begin
      KFill(AbsX + 2, ItemY, ClientW, Sender^.ItemHeight, $004080C0);
      TxtColor := clWhite;
    end
    else if NodeIdx = Sender^.HoverIndex then
    begin
      KFill(AbsX + 2, ItemY, ClientW, Sender^.ItemHeight, $00E0E8F0);
      TxtColor := clBlack;
    end
    else
      TxtColor := clBlack;

    BoxX := AbsX + 2 + Node^.Level * TREE_INDENT;
    if TreeViewHasChildren(Sender, NodeIdx) then
    begin
      KRect(BoxX, ItemY + (Sender^.ItemHeight - TREE_BOX) div 2, TREE_BOX, TREE_BOX, cl3DDkShadow);
      KLineH(BoxX + 2, ItemY + Sender^.ItemHeight div 2, TREE_BOX - 4, clBlack);
      if not Node^.Expanded then
        KLineV(BoxX + TREE_BOX div 2, ItemY + (Sender^.ItemHeight - TREE_BOX) div 2 + 2,
               TREE_BOX - 4, clBlack);
    end;

    TextX := BoxX + TREE_INDENT;
    KStrClipped(TextX, ItemY + (Sender^.ItemHeight - FONT_H) div 2,
                (AbsX + 2 + ClientW) - TextX, @Node^.Caption[0], TxtColor);
  end;

  if ScrollVisible then
  begin
    KFill(AbsX + Sender^.Width - 2 - ScrollW, AbsY + 2, ScrollW, Sender^.Height - 4, clBtnFace);
    KRect(AbsX + Sender^.Width - 2 - ScrollW, AbsY + 2, ScrollW, Sender^.Height - 4, cl3DShadow);

    Sender^.ThumbSize := Max(16, (Sender^.Height - 4) * VisibleRows div VisCount);
    if VisCount > VisibleRows then
      Sender^.ThumbPos := 2 + Sender^.ScrollIndex * (Sender^.Height - 4 - Sender^.ThumbSize) div
                          (VisCount - VisibleRows)
    else
      Sender^.ThumbPos := 2;

    KFill(AbsX + Sender^.Width - 1 - ScrollW, AbsY + Sender^.ThumbPos,
          ScrollW - 2, Sender^.ThumbSize, clSilver);
    KRect(AbsX + Sender^.Width - 1 - ScrollW, AbsY + Sender^.ThumbPos,
          ScrollW - 2, Sender^.ThumbSize, cl3DShadow);
  end;
end;

procedure TreeViewMouseDown(Sender: PTreeView; AX, AY: Integer; Btn: Byte);
var
  VisList: array[0..TREE_MAX_VISIBLE - 1] of Integer;
  VisCount, VisibleRows, ScrollW, Row, NodeIdx, BoxX: Integer;
  Node: PTreeNode;
  ScrollVisible: Boolean;
begin
  if Btn <> 1 then Exit;
  VisCount := TreeViewBuildVisible(Sender, VisList);
  ScrollW := SCROLLBAR_SIZE;
  VisibleRows := (Sender^.Height - 4) div Sender^.ItemHeight;
  ScrollVisible := VisCount > VisibleRows;

  if ScrollVisible and (AX >= Sender^.Width - 4 - ScrollW) then
  begin
    if (AY >= Sender^.ThumbPos) and (AY < Sender^.ThumbPos + Sender^.ThumbSize) then
    begin
      Sender^.Dragging := True;
      Sender^.DragStartY := AY;
    end;
    Exit;
  end;

  if (AY < 2) or (AY >= Sender^.Height - 2) then Exit;
  Row := Sender^.ScrollIndex + (AY - 2) div Sender^.ItemHeight;
  if (Row < 0) or (Row >= VisCount) then Exit;

  NodeIdx := VisList[Row];
  Node := TreeViewNode(Sender, NodeIdx);
  BoxX := 2 + Node^.Level * TREE_INDENT;

  if (AX >= BoxX) and (AX < BoxX + TREE_BOX) and TreeViewHasChildren(Sender, NodeIdx) then
  begin
    Node^.Expanded := not Node^.Expanded;
    Exit;
  end;

  if Sender^.SelectedIndex <> NodeIdx then
  begin
    Sender^.SelectedIndex := NodeIdx;
    if Assigned(Sender^.OnSelect) then Sender^.OnSelect(PObject(Sender));
  end;
end;

procedure TreeViewMouseMove(Sender: PTreeView; AX, AY: Integer; Btn: Byte);
var
  VisList: array[0..TREE_MAX_VISIBLE - 1] of Integer;
  VisCount, VisibleRows, Row, TrackLen, Delta, NewThumb, NewScroll: Integer;
begin
  VisCount := TreeViewBuildVisible(Sender, VisList);
  VisibleRows := (Sender^.Height - 4) div Sender^.ItemHeight;

  if Sender^.Dragging then
  begin
    Delta := AY - Sender^.DragStartY;
    NewThumb := Sender^.ThumbPos + Delta;
    if NewThumb < 2 then NewThumb := 2;
    TrackLen := Sender^.Height - 4 - Sender^.ThumbSize;
    if NewThumb > 2 + TrackLen then NewThumb := 2 + TrackLen;

    if (VisCount > VisibleRows) and (TrackLen > 0) then
      NewScroll := (NewThumb - 2) * (VisCount - VisibleRows) div TrackLen
    else
      NewScroll := 0;
    if NewScroll < 0 then NewScroll := 0;
    if NewScroll > VisCount - VisibleRows then NewScroll := VisCount - VisibleRows;

    Sender^.ScrollIndex := NewScroll;
    Sender^.DragStartY := AY;
    Exit;
  end;

  if (AY >= 2) and (AY < Sender^.Height - 2) then
  begin
    Row := Sender^.ScrollIndex + (AY - 2) div Sender^.ItemHeight;
    if (Row >= 0) and (Row < VisCount) then
      Sender^.HoverIndex := VisList[Row]
    else
      Sender^.HoverIndex := -1;
  end
  else
    Sender^.HoverIndex := -1;
end;

procedure TreeViewMouseUp(Sender: PTreeView; AX, AY: Integer; Btn: Byte);
begin
  Sender^.Dragging := False;
end;

{ TreeViewClear asagida tanimli oldugu (CreateTreeView'dan SONRA geldigi)
  icin, burada BindDestroy'da kullanabilmek adina ileri bildirim (forward)
  gerekiyor - gercek govdesi TreeViewClear'in hemen altinda. }
procedure TreeViewDestroy(Sender: PObject); forward;

function CreateTreeView(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
  AAlign: TAlign): PTreeView;
begin
  Result := PTreeView(MemAlloc(SizeOf(TTreeView)));
  FillChar(Result^, SizeOf(TTreeView), #0);
  Result^.Left   := ALeft;
  Result^.Top    := ATop;
  Result^.Width  := AWidth;
  Result^.Height := AHeight;
  Result^.Align  := AAlign;
  Result^.Color  := clWhite;
  Result^.BorderWidth := 2;
  Result^.ShowCaption := False;
  Result^.Cursor := 0;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.ZIndex := 1;
  Result^.ItemHeight := FONT_H + 4;
  Result^.SelectedIndex := -1;
  Result^.HoverIndex := -1;
  Result^.NodeCount := 0;
  Result^.NodeCapacity := 0;
  Result^.Nodes := nil;
  Result^.ScrollIndex := 0;
  Result^.Dragging := False;
  Result^.BindPaint(@TreeViewDraw);
  Result^.BindMouseDown(@TreeViewMouseDown);
  Result^.BindMouseMove(@TreeViewMouseMove);
  Result^.BindMouseUp(@TreeViewMouseUp);
  Result^.BindDestroy(@TreeViewDestroy);
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

function TreeViewAddNode(TV: PTreeView; AParentIndex: Integer; const ACaption: PChar): Integer;
var
  Node: PTreeNode;
  Len: Integer;
begin
  if (AParentIndex >= 0) and (AParentIndex >= TV^.NodeCount) then
  begin
    Result := -1;
    Exit;
  end;

  if TV^.NodeCount >= TV^.NodeCapacity then
    GrowPCharArray(TV^.Nodes, TV^.NodeCapacity, TV^.NodeCount + 1);

  Node := PTreeNode(MemAlloc(SizeOf(TTreeNode)));
  FillChar(Node^, SizeOf(TTreeNode), #0);
  Len := StrLen(ACaption);
  if Len > 127 then Len := 127;
  Move(ACaption^, Node^.Caption[0], Len);
  Node^.Caption[Len] := #0;
  Node^.ParentIndex := AParentIndex;
  Node^.Expanded := True;
  if AParentIndex >= 0 then
    Node^.Level := TreeViewNode(TV, AParentIndex)^.Level + 1
  else
    Node^.Level := 0;

  TV^.Nodes^[TV^.NodeCount] := PChar(Node);
  Result := TV^.NodeCount;
  Inc(TV^.NodeCount);
end;

procedure TreeViewClear(TV: PTreeView);
var
  I: Integer;
begin
  for I := 0 to TV^.NodeCount - 1 do
    if TV^.Nodes^[I] <> nil then
      FreeMem(TV^.Nodes^[I]);
  TV^.NodeCount := 0;
  TV^.SelectedIndex := -1;
  TV^.HoverIndex := -1;
  TV^.ScrollIndex := 0;
end;

{ CreateTreeView'daki forward bildirimin gercek govdesi. TreeViewClear ile
  her dugumun (TTreeNode) kendisini, ardindan Nodes dizisinin kendisini
  serbest birakir. }
procedure TreeViewDestroy(Sender: PObject);
var
  TV: PTreeView;
begin
  TV := PTreeView(Sender);
  TreeViewClear(TV);
  if TV^.Nodes <> nil then
  begin
    FreeMem(TV^.Nodes);
    TV^.Nodes := nil;
  end;
  TV^.NodeCapacity := 0;
end;

procedure TreeViewExpand(TV: PTreeView; Index: Integer; AExpand: Boolean);
begin
  if (TV = nil) or (Index < 0) or (Index >= TV^.NodeCount) then Exit;
  TreeViewNode(TV, Index)^.Expanded := AExpand;
end;

function TreeViewGetSelectedText(TV: PTreeView): PChar;
begin
  if (TV <> nil) and (TV^.SelectedIndex >= 0) and (TV^.SelectedIndex < TV^.NodeCount) then
    Result := @TreeViewNode(TV, TV^.SelectedIndex)^.Caption[0]
  else
    Result := nil;
end;





{==============================================================================}
{  TTOOLBAR - IMPLEMENTATION                                                   }
{==============================================================================}


{=============================================================================}
{ TToolBar Helpers                                                            }
{=============================================================================}

function ToolBarButtonWidth(TB: PToolBar; Btn: PToolButton): Integer;
begin
  if Btn^.Separator then
    Result := 8
  else if Btn^.Width > 0 then
    Result := Btn^.Width
  else if TB^.ButtonWidth > 0 then
    Result := TB^.ButtonWidth
  else if TB^.ShowCaptions then
    Result := StrLen(Btn^.Caption) * FONT_W + 12
  else
    Result := 24; { sadece ikon alani varsayimi }
end;

function ToolBarHitTest(Sender: PToolBar; AX, AY: Integer; out Index: Integer): Boolean;
var
  I, BX, BW: Integer;
  Btn: PToolButton;
begin
  Result := False;
  Index := -1;
  if (AY < 2) or (AY >= Sender^.Height - 2) then Exit;
  BX := 4;
  for I := 0 to Sender^.ButtonCount - 1 do
  begin
    Btn := PToolButton(Sender^.Buttons[I]);
    if (Btn = nil) or not Btn^.Visible then Continue;
    BW := ToolBarButtonWidth(Sender, Btn);
    if (AX >= BX) and (AX < BX + BW) then
    begin
      Index := I;
      Result := True;
      Exit;
    end;
    Inc(BX, BW + 2);
  end;
end;

{=============================================================================}
{ TToolBar Cizim                                                              }
{=============================================================================}

procedure ToolBarDraw(Sender: PToolBar; AbsX, AbsY: Integer);
var
  I, BX, BY, BW, BH: Integer;
  Btn: PToolButton;
  TxtColor: LongWord;
  Pressed: Boolean;
begin
  { Arka plan }
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, Sender^.Color);
  KLineH(AbsX, AbsY, Sender^.Width, cl3DHighLight);
  KLineH(AbsX, AbsY + Sender^.Height - 1, Sender^.Width, cl3DDkShadow);
  KLineH(AbsX, AbsY + Sender^.Height - 2, Sender^.Width, clWhite);

  BX := AbsX + 4;
  BY := AbsY + (Sender^.Height - Sender^.ButtonHeight) div 2;
  if BY < AbsY + 2 then BY := AbsY + 2;
  BH := Sender^.ButtonHeight;
  if BH < 1 then BH := Sender^.Height - 4;

  for I := 0 to Sender^.ButtonCount - 1 do
  begin
    Btn := PToolButton(Sender^.Buttons[I]);
    if (Btn = nil) or not Btn^.Visible then Continue;

    BW := ToolBarButtonWidth(Sender, Btn);

    { Separator }
    if Btn^.Separator then
    begin
      KLineV(BX + 3, BY, BH, cl3DDkShadow);
      KLineV(BX + 4, BY, BH, clWhite);
    end
    else
    begin
      Pressed := Btn^.Down or ((I = Sender^.PressIndex) and (I = Sender^.HotIndex));

      if Sender^.Flat then
      begin
        if (I = Sender^.HotIndex) or (I = Sender^.PressIndex) or Btn^.Down then
           KButton3DEx(BX, BY, BW, BH,
            Pressed,
            True,
            clBtnFace)


        else
          KButton3DEx(BX, BY, BW, BH,
            Pressed,
            False,
            clBtnFace);

      end
      else
      begin
        KButton3D(BX, BY, BW, BH, Pressed, clBtnFace);
      end;

      if not Btn^.Enabled then
        TxtColor := clGray
      else
        TxtColor := clBlack;

      if Sender^.ShowCaptions and (Btn^.Caption[0] <> #0) then
        KStrCentered(BX, BY + (BH - FONT_H) div 2, BW, Btn^.Caption, TxtColor);
    end;

    Inc(BX, BW + 2);
    if BX > AbsX + Sender^.Width - 4 then Break;
  end;
end;

{=============================================================================}
{ TToolBar Fare Olaylari                                                      }
{=============================================================================}

procedure ToolBarMouseDown(Sender: PToolBar; AX, AY: Integer; Btn: Byte);
var
  Idx: Integer;
  B: PToolButton;
begin
  if Btn <> 1 then Exit;
  if ToolBarHitTest(Sender, AX, AY, Idx) then
  begin
    B := PToolButton(Sender^.Buttons[Idx]);
    if (B <> nil) and B^.Enabled and not B^.Separator then
      Sender^.PressIndex := Idx;
  end;
end;

procedure ToolBarMouseMove(Sender: PToolBar; AX, AY: Integer; Btn: Byte);
var
  Idx: Integer;
begin
  if not ToolBarHitTest(Sender, AX, AY, Idx) then
    Idx := -1;
  Sender^.HotIndex := Idx;
end;

procedure ToolBarMouseUp(Sender: PToolBar; AX, AY: Integer; Btn: Byte);
var
  Idx: Integer;
  B: PToolButton;
begin
  if Btn <> 1 then Exit;
  if ToolBarHitTest(Sender, AX, AY, Idx) then
  begin
    if Idx = Sender^.PressIndex then
    begin
      B := PToolButton(Sender^.Buttons[Idx]);
      if (B <> nil) and B^.Enabled and not B^.Separator then
      begin
        { Toggle buton ise Down durumunu tersine cevir }
        if B^.Down then
          B^.Down := False
        else if { istege bagli: gruptaki digerlerini kapat } True then
          ; { normal buton }

        // if Assigned(B^.OnClick) then
         //   B^.OnClick(PObject(Sender));
       if Assigned(Sender^.OnClick) then

        Sender^.OnClick(Sender, Idx);
      end;
    end;
  end;
  Sender^.PressIndex := -1;
end;


procedure ToolBarDestroy(Sender: PObject);
var
  TB: PToolBar;
  I: Integer;
begin
  TB := PToolBar(Sender);
  for I := 0 to TB^.ButtonCount - 1 do
    if TB^.Buttons[I] <> nil then
    begin
      FreeMem(TB^.Buttons[I]);
      TB^.Buttons[I] := nil;
    end;
  TB^.ButtonCount := 0;
end;

function ToolBarAddButton(TB: PToolBar; const ACaption: PChar;
                          AWidth: Integer; AOnClick: TNotifyEvent): Integer;
var
  Btn: PToolButton;
  Len: Integer;
begin
  if TB^.ButtonCount >= MAX_TOOLBAR_BUTTONS then
  begin
    Result := -1;
    Exit;
  end;

  Btn := PToolButton(MemAlloc(SizeOf(TToolButton)));
  FillChar(Btn^, SizeOf(TToolButton), #0);
  
  if ACaption <> nil then
  begin
    Len := StrLen(ACaption);
    if Len > 63 then Len := 63;
    Move(ACaption^, Btn^.Caption[0], Len);
    Btn^.Caption[Len] := #0;
  end;
  
  Btn^.Enabled := True;
  Btn^.Visible := True;
  Btn^.Width   := AWidth;
  Btn^.Tag     := 0;
  Btn^.OnClick := AOnClick;

  TB^.Buttons[TB^.ButtonCount] := Btn;
  Result := TB^.ButtonCount;
  Inc(TB^.ButtonCount);
end;

procedure ToolBarAddSeparator(TB: PToolBar);
var
  Btn: PToolButton;
begin
  if TB^.ButtonCount >= MAX_TOOLBAR_BUTTONS then Exit;

  Btn := PToolButton(MemAlloc(SizeOf(TToolButton)));
  FillChar(Btn^, SizeOf(TToolButton), #0);
  Btn^.Separator := True;
  Btn^.Enabled   := False;
  Btn^.Visible   := True;

  TB^.Buttons[TB^.ButtonCount] := Btn;
  Inc(TB^.ButtonCount);
end;

procedure ToolBarClear(TB: PToolBar);
var
  I: Integer;
begin
  for I := 0 to TB^.ButtonCount - 1 do
    if TB^.Buttons[I] <> nil then
    begin
      FreeMem(TB^.Buttons[I]);
      TB^.Buttons[I] := nil;
    end;
  TB^.ButtonCount := 0;
  TB^.HotIndex    := -1;
  TB^.PressIndex  := -1;
end;

procedure ToolBarSetButtonEnabled(TB: PToolBar; Index: Integer; AEnabled: Boolean);
begin
  if (Index < 0) or (Index >= TB^.ButtonCount) then Exit;
  if TB^.Buttons[Index] <> nil then
    TB^.Buttons[Index]^.Enabled := AEnabled;
end;

function CreateToolBar(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
                       AAlign: TAlign): PToolBar;
begin
  Result := PToolBar(MemAlloc(SizeOf(TToolBar)));
  FillChar(Result^, SizeOf(TToolBar), #0);

  Result^.Left   := ALeft;
  Result^.Top    := ATop;
  Result^.Width  := AWidth;
  if AHeight < 1 then Result^.Height := 28 else Result^.Height := AHeight;
  Result^.Align  := AAlign;
  Result^.Color  :=  C_FORM_BG;
  Result^.BorderWidth  := 0;
  Result^.ShowCaption  := False;
  Result^.Cursor       := 0;
  Result^.Visible      := True;
  Result^.Enabled      := True;
  Result^.Parent       := AParent;
  Result^.ZIndex       := 0;

  Result^.ButtonCount    := 0;
  Result^.ButtonWidth    := 0;
  Result^.ButtonHeight   := Result^.Height - 6;
  Result^.ShowCaptions   := True;
  Result^.Flat           := True;
  Result^.HotIndex       := -1;
  Result^.PressIndex     := -1;
  Result^.OnClick        := nil;

  { Array zaten FillChar ile sifirlandi, nil dolu }

  Result^.BindPaint(@ToolBarDraw);
  Result^.BindMouseDown(@ToolBarMouseDown);
  Result^.BindMouseMove(@ToolBarMouseMove);
  Result^.BindMouseUp(@ToolBarMouseUp);
  Result^.BindDestroy(@ToolBarDestroy);

  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;

procedure DrawPanel(Sender: PForm; AbsX, AbsY: Integer);
begin
  KPanel3D(AbsX, AbsY, Sender^.Width, Sender^.Height, True, Sender^.Color);
end;




function CreatePanel(AParent: PObject; ALeft, ATop, AWidth, AHeight: Integer;
  AAlign: TAlign): PPanel;
begin
  Result := MemAlloc(SizeOf(TPanel));
  FillChar(Result^, SizeOf(TPanel), #0);
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := C_FORM_BG;
  Result^.BorderWidth := 5;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Parent := AParent;
  Result^.BindPaint(@DrawPanel);
  Result^.ZIndex := 2;
  AParent^.AddObject(PObject(Result));
  { Not: AParent her zaman bir Form olmayabilir (orn. bir Panel'in icine baska
    bir Panel/Button eklenmesi); bu yuzden dogrudan PForm(AParent) yerine
    FindRootForm ile gercek kok formu buluyoruz. }
  RelayoutForm(FindRootForm(AParent));
end;




procedure Button_Draw(Sender: PButton; AbsX, AbsY: Integer);
var
  FC, FillCol: LongWord;
  c: LongWord;
   tx: Integer;
begin
  if (Sender = nil) then Exit;

 if not Sender^.Enabled then
 begin
    FillCol := $00E0E0E0;
   { KButton3D(AbsX, AbsY, Sender^.Width, Sender^.Height, False, FillCol);
    KFillAlpha(AbsX, AbsY, Sender^.Width, Sender^.Height, $00FFFFFF, 150);
    FC := $00808080; }
     KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, C_FORM_BG);
     K3D(AbsX, AbsY, Sender^.Width, Sender^.Height, Sender^.FPressed);
     KStrCentered(AbsX, AbsY + (Sender^.Height - FONT_H) div 2, Sender^.Width, Sender^.Caption, C_BTN_PRESS);
  end 
  else
  begin



   if Sender^.FPressed then c :=C_FORM_BG   else c :=$FFF0F0F0  ;

  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, c);
  K3D(AbsX, AbsY, Sender^.Width, Sender^.Height,Sender^.FPressed);
  if Sender^.Hover then
  begin
     KStrCentered(AbsX-1, (AbsY + (Sender^.Height - FONT_H) div 2)-1, Sender^.Width, Sender^.Caption, C_SHADOW);
  end
  else
  begin
     KStrCentered(AbsX, AbsY + (Sender^.Height - FONT_H) div 2, Sender^.Width, Sender^.Caption, C_BLACK);
  end;
 end;


end;


procedure Button_MouseDown(Sender: Pbutton; X, Y: Integer; Btn: Byte);
begin
  Sender^.FPressed:=True;
end;
procedure  Button_MouseUp(Sender: Pbutton; X, Y: Integer; Btn: Byte);
begin
  Sender^.FPressed:=false;
end;

function CreateButton(AParent: PObject; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign): PButton;
begin
  Result := MemAlloc(SizeOf(TButton));
  FillChar(Result^, SizeOf(TButton), #0);
  Move(ACaption[0], Result^.Caption[0], StrLen(ACaption));
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := C_FORM_BG;
  Result^.BorderWidth := 5;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := True;
  Result^.Enabled := True;
  Result^.Focused := False;
  Result^.CanFocus := False;
  Result^.TabStop := False;
  Result^.Parent := AParent;
  Result^.BindPaint(@Button_Draw);
  Result^.BindMouseDown(@Button_MouseDown);
  Result^.BindMouseUp(@Button_MouseUp);
  Result^.ZIndex := 1;
  AParent^.AddObject(PObject(Result));
  RelayoutForm(FindRootForm(AParent));
end;



procedure TPopup.AddItem(const ACaption: PChar; AOnClick: TPopupClickProc; AEnabled: Boolean);
var
  Item: PPopupItem;
  OldCap, OldSize: Integer;
begin
  if ItemCount >= ItemCapacity then
  begin
    OldCap := ItemCapacity;
    if ItemCapacity = 0 then ItemCapacity := 8
    else ItemCapacity := ItemCapacity * 2;
    OldSize := OldCap * SizeOf(PPopupItem);
    Items := PPCharArray(ReallocMem(Items, OldSize, ItemCapacity * SizeOf(PPopupItem)));
  end;
  Item := PPopupItem(MemAlloc(SizeOf(TPopupItem)));
  FillChar(Item^, SizeOf(TPopupItem), #0);
  if ACaption <> nil then
    Move(ACaption[0], Item^.Caption[0], StrLen(ACaption));
  Item^.Enabled := AEnabled;
  Item^.OnClick := AOnClick;
  Items^[ItemCount] := PChar(Item);
  Inc(ItemCount);
end;

procedure TPopup.AddSeparator;
begin
  AddItem('-', nil, False);
  PPopupItem(Items^[ItemCount - 1])^.Separator := True;
end;

procedure TPopup.Show(AX, AY: Integer);
var
  I, W, MaxW: Integer;
  Item: PPopupItem;
begin
  MaxW := 80;
  for I := 0 to ItemCount - 1 do
  begin
    Item := PPopupItem(Items^[I]);
    if Item^.Separator then Continue;
    W := StrLen(Item^.Caption) * FONT_W + 40;
    if W > MaxW then MaxW := W;
  end;
  Width := MaxW;
  X := AX;
  Y := AY;

  if X + Width > SCREEN_WIDTH then X := SCREEN_WIDTH - Width;
  if X < 0 then X := 0;
  if Y + ItemCount * ItemHeight + 4 > SCREEN_HEIGHT then
    Y := SCREEN_HEIGHT - (ItemCount * ItemHeight + 4);
  if Y < 0 then Y := 0;

  Visible := True;
  SelectedIndex := -1;
  WinManager.ActivePopup := @Self;
end;

procedure TPopup.Hide;
begin
  Visible := False;
  SelectedIndex := -1;
  WinManager.ActivePopup := nil;
end;

procedure TPopup.Draw;
var
  I, ItemY: Integer;
  Item: PPopupItem;
  TxtColor: LongWord;
begin
  if not Visible then Exit;

  { Arka plan + 3D border }
  KFill(X, Y, Width, ItemCount * ItemHeight + 4, clBtnFace);
  KRect(X, Y, Width, ItemCount * ItemHeight + 4, clBlack);
  KLineH(X + 1, Y + 1, Width - 2, clWhite);
  KLineV(X + 1, Y + 1, ItemCount * ItemHeight + 2, clWhite);
  KLineH(X + 1, Y + ItemCount * ItemHeight + 2, Width - 2, cl3DShadow);
  KLineV(X + Width - 2, Y + 1, ItemCount * ItemHeight + 2, cl3DShadow);

  for I := 0 to ItemCount - 1 do
  begin
    Item := PPopupItem(Items^[I]);
    ItemY := Y + 2 + I * ItemHeight;

    if I = SelectedIndex then
    begin
      if Item^.Enabled and not Item^.Separator then
      begin
        KFill(X + 2, ItemY, Width - 4, ItemHeight, $004080C0);
        TxtColor := clWhite;
      end
      else
      begin
        KFill(X + 2, ItemY, Width - 4, ItemHeight, $00A0C8F0);
        TxtColor := clGray;
      end;
    end
    else
    begin
      if not Item^.Enabled then TxtColor := clGray
      else TxtColor := clBlack;
    end;

    if Item^.Separator then
    begin
      KLineH(X + 4, ItemY + ItemHeight div 2, Width - 8, cl3DShadow);
      KLineH(X + 4, ItemY + ItemHeight div 2 + 1, Width - 8, clWhite);
    end
    else
    begin
      if Item^.Checked then
      begin
        KStr(X + 4, ItemY + (ItemHeight - FONT_H) div 2, '?', TxtColor);
        KStr(X + 16, ItemY + (ItemHeight - FONT_H) div 2, Item^.Caption, TxtColor);
      end
      else
        KStr(X + 8, ItemY + (ItemHeight - FONT_H) div 2, Item^.Caption, TxtColor);
    end;
  end;
end;

function TPopup.HitTest(MX, MY: Integer): Integer;
begin
  Result := -1;
  if not Visible then Exit;
  if (MX < X) or (MX >= X + Width) or
     (MY < Y) or (MY >= Y + ItemCount * ItemHeight + 4) then Exit;
  Result := (MY - Y - 2) div ItemHeight;
  if (Result < 0) or (Result >= ItemCount) then Result := -1;
end;

procedure TPopup.MouseDown(MX, MY: Integer; Btn: Byte);
var
  Idx: Integer;
  Item: PPopupItem;
begin
  if Btn <> 1 then Exit;
  Idx := HitTest(MX, MY);
  if (Idx >= 0) and (Idx < ItemCount) then
  begin
    Item := PPopupItem(Items^[Idx]);
    if Item^.Enabled and not Item^.Separator then
    begin
      if Assigned(Item^.OnClick) then Item^.OnClick(Item);
      Hide;
    end;
  end;
end;

procedure TPopup.MouseMove(MX, MY: Integer);
var
  Idx: Integer;
begin
  Idx := HitTest(MX, MY);
  if Idx <> SelectedIndex then SelectedIndex := Idx;
end;


procedure Popup_MouseDown(Sender: PPopup; X, Y: Integer; Btn: Byte);
begin
   Sender^.MouseDown(X, Y, Btn);
end;


procedure Popup_MouseMove(Sender: PPopup; X, Y: Integer; Btn: Byte);
begin
   Sender^.MouseMove(X, Y);
end;

procedure Popup_Draw(Sender: PPopup; AbsX, AbsY: Integer);
begin
  Sender^.Draw;
end;



function CreatePopup(AParent: PObject; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: TAlign): PPopup;
begin
  Result := MemAlloc(SizeOf(TPopup));
  FillChar(Result^, SizeOf(TPopup), #0);
  Move(ACaption[0], Result^.Caption[0], StrLen(ACaption));
  Result^.Left := ALeft;
  Result^.Top := ATop;
  Result^.Width := AWidth;
  Result^.Height := AHeight;
  Result^.Align := AAlign;
  Result^.Color := clNavy;
  Result^.BorderWidth := 5;
  Result^.ShowCaption := False;
  Result^.Cursor := 3;
  Result^.Visible := False;
  Result^.Enabled := True;
  Result^.Focused := False;
  Result^.CanFocus := False;
  Result^.TabStop := False;
  Result^.Parent := AParent;
  Result^.BindPaint(@Popup_Draw);
  Result^.BindMouseDown(@Popup_MouseDown);
  Result^.BindMouseMove(@Popup_MouseMove);
  Result^.ZIndex := 1;
  AParent^.AddObject(PObject(Result));

end;


{=============================================================================}
{ TTimer                                                                      }
{=============================================================================}

procedure TimerDestroy(Sender: PObject);
var
  I, J: Integer;
begin
  for I := 0 to TimerCount - 1 do
    if TimerList[I] = PTimer(Sender) then
    begin
      for J := I to TimerCount - 2 do
        TimerList[J] := TimerList[J + 1];
      Dec(TimerCount);
      Break;
    end;
end;

procedure UpdateTimers;
var
  T: PTimer;
  CurrentTick: LongWord;
  I: Integer;
begin
  CurrentTick := GetTickCount();  // LongWord, ms de�il, tick (10ms ��z�n�rl�k)

  for I := 0 to TimerCount - 1 do
  begin
    T := TimerList[I];
    if (T = nil) or not T^.Enabled then Continue;
    if not Assigned(T^.OnTimer) then Continue;

    // LongWord subtraction � wrap-around'a kar�� dayan�kl�!
    if (CurrentTick - T^.LastTick) >= (T^.Interval div 10) then
    begin
      T^.LastTick := CurrentTick;
      T^.OnTimer(PObject(T));
    end;
  end;
end;

function CreateTimer(AParent: PObject; AInterval: LongWord): PTimer;
begin
  Result := PTimer(MemAlloc(SizeOf(TTimer)));
  FillChar(Result^, SizeOf(TTimer), #0);

 // Result^.Interval := AInterval;
  
 // Result^.LastTick := LongWord(GetTickCount() * 10);
  Result^.Enabled  := True;
  Result^.Interval := AInterval;        // ms cinsinden (�rn: 500)
  Result^.LastTick := GetTickCount()*10;   // LongWord, do�al de�er
  Result^.Visible  := False;   // G�rsel bir �ey �izmiyoruz
  Result^.Parent   := AParent;
  Result^.ZIndex   := 0;

  if TimerCount < MAX_TIMERS then
  begin
    TimerList[TimerCount] := Result;
    Inc(TimerCount);
  end;

  Result^.BindDestroy(@TimerDestroy);

  if AParent <> nil then
    AParent^.AddObject(PObject(Result));
end;




end.

Unit TaskBar;

interface

uses
  SysUtils, GUI, Ports, Draw32, Fat32, Memory, Vesa, DrawIcons;

const
  MAX_TASKBAR_ITEMS = 32;
  TASKBAR_HEIGHT    = 32;
  ITEM_MIN_WIDTH    = 120;
  ITEM_MAX_WIDTH    = 200;
  ICON_ONLY_WIDTH   = 32; // Sadece ikon g�sterildi�inde kullan�lacak geni�lik
  ITEM_SPACING      = 2;
  START_BUTTON_WIDTH= 80;
  SYSTRAY_WIDTH     = 100;

type
  TTaskBarAlign = (tbLeft, tbCenter, tbRight);
  TTaskBarItemType = (tbiButton, tbiWindow, tbiSeparator);
  
  PTaskBarItem = ^TTaskBarItem;
  TTaskBarItemClick = procedure(Item: PTaskBarItem);

  TTaskBarItem = record
    ItemType: TTaskBarItemType;
    Align: TTaskBarAlign;
    
    Title: array[0..63] of Char;
    IconType: TIconType;    // �izilecek ikon t�r�
    ShowCaption: Boolean;   // Metin g�sterilsin mi?
    ShowIcon: Boolean;      // �kon g�sterilsin mi?
    IconBitmap: Pointer;
    
    X, Y: Integer;
    Width, Height: Integer;
    
    Pressed: Boolean;
    Active: Boolean;

    Form: PForm;
    OnClick: TTaskBarItemClick;
  end;

  PTaskBarData = ^TTaskBarData;
  TTaskBarData = record
    Items: array[0..MAX_TASKBAR_ITEMS-1] of TTaskBarItem;
    ItemCount: Integer;
    
    X, Y: Integer;
    Width, Height: Integer;
    
    StartPressed: Boolean;
    ScreenWidth: Integer;
  end;

var
  TaskBar1: PTaskBarData;

// API
procedure TaskBar_Init(ScreenWidth: Integer);
procedure TaskBar_Render;
function TaskBar_AddItem(Title: PChar; Align: TTaskBarAlign;
                         ItemType: TTaskBarItemType; 
                         IconType: TIconType = itFolder;
                         ShowCaption: Boolean = False;
                         ShowIcon: Boolean = True;
                         Click: TTaskBarItemClick = nil): Integer;

procedure TaskBar_UpdateWindow(Form: PForm);
procedure TaskBar_HandleClick(X, Y: Integer);

function TaskBar_AddWindow(Form: PForm; IconType: TIconType = itDoc; ShowCaption: Boolean = False): Integer;
procedure TaskBar_SetActive(Form: PForm);
procedure TaskBar_RemoveWindow(Form: PForm);


procedure GetRTCTime(var Hour, Min, Sec: Byte);

implementation

uses Desktops;

procedure TaskBar_CalculateLayout;
var
  i: Integer;
  leftCount, centerCount, rightCount: Integer;
  leftX, rightX: Integer;
  leftWidth, rightWidth: Integer;
  itemWidth: Integer;
  currentX: Integer;
  totalCenterWidth: Integer;
begin
  if TaskBar1 = nil then Exit;
  
  leftCount := 0;
  centerCount := 0;
  rightCount := 0;
  
  // Hizalama t�rlerine g�re eleman say�lar�n� hesapla
  i := 0;
  while i < TaskBar1^.ItemCount do
  begin
    case TaskBar1^.Items[i].Align of
      tbLeft: Inc(leftCount);
      tbCenter: Inc(centerCount);
      tbRight: Inc(rightCount);
    end;
    Inc(i);
  end;
  
  leftX := START_BUTTON_WIDTH + ITEM_SPACING;
  rightX := TaskBar1^.Width - SYSTRAY_WIDTH;
  
  // --- Sol ��eler (tbLeft) ---
  currentX := leftX;
  i := 0;
  while i < TaskBar1^.ItemCount do
  begin
    if TaskBar1^.Items[i].Align = tbLeft then
    begin
      if TaskBar1^.Items[i].ShowCaption then
      begin
        leftWidth := (rightX - leftX - (leftCount * ITEM_SPACING)) div 3;
        itemWidth := leftWidth div leftCount;
        if itemWidth < ITEM_MIN_WIDTH then itemWidth := ITEM_MIN_WIDTH;
        if itemWidth > ITEM_MAX_WIDTH then itemWidth := ITEM_MAX_WIDTH;
      end
      else
        itemWidth := ICON_ONLY_WIDTH;
      
      TaskBar1^.Items[i].X := currentX;
      TaskBar1^.Items[i].Y := TaskBar1^.Y + 2;
      TaskBar1^.Items[i].Width := itemWidth;
      TaskBar1^.Items[i].Height := TASKBAR_HEIGHT - 4;
      
      currentX := currentX + itemWidth + ITEM_SPACING;
    end;
    Inc(i);
  end;
  
  // --- Orta ��eler (tbCenter - Tam Ekran Merkezli) ---
  if centerCount > 0 then
  begin
    // 1. T�m orta elemanlar�n geni�liklerini belirle ve toplam geni�li�i topla
    totalCenterWidth := 0;
    i := 0;
    while i < TaskBar1^.ItemCount do
    begin
      if TaskBar1^.Items[i].Align = tbCenter then
      begin
        if not TaskBar1^.Items[i].ShowCaption then
          TaskBar1^.Items[i].Width := ICON_ONLY_WIDTH
        else
          TaskBar1^.Items[i].Width := ITEM_MIN_WIDTH;

        totalCenterWidth := totalCenterWidth + TaskBar1^.Items[i].Width;
      end;
      Inc(i);
    end;

    // Aralardaki bo�luklar� (spacing) ekle
    totalCenterWidth := totalCenterWidth + ((centerCount - 1) * ITEM_SPACING);

    // 2. Ekran geni�li�ine (ScreenWidth) g�re tam merkez X koordinat�n� bul
    currentX := (TaskBar1^.Width - totalCenterWidth) div 2;

    // Sol buton alan�na �ak��may� �nle
    if currentX < leftX then currentX := leftX;

    // 3. Elemanlar�n X koordinatlar�n� s�rayla ata
    i := 0;
    while i < TaskBar1^.ItemCount do
    begin
      if TaskBar1^.Items[i].Align = tbCenter then
      begin
        TaskBar1^.Items[i].X := currentX;
        TaskBar1^.Items[i].Y := TaskBar1^.Y + 2;
        TaskBar1^.Items[i].Height := TASKBAR_HEIGHT - 4;
        
        currentX := currentX + TaskBar1^.Items[i].Width + ITEM_SPACING;
      end;
      Inc(i);
    end;
  end;
  
  // --- Sa� ��eler (tbRight) ---
  if rightCount > 0 then
  begin
    rightWidth := (rightX - leftX - (rightCount * ITEM_SPACING)) div 3;
    itemWidth := rightWidth div rightCount;
    if itemWidth < ITEM_MIN_WIDTH then itemWidth := ITEM_MIN_WIDTH;
    if itemWidth > ITEM_MAX_WIDTH then itemWidth := ITEM_MAX_WIDTH;
    
    currentX := rightX - (rightCount * itemWidth + (rightCount - 1) * ITEM_SPACING);
    
    i := 0;
    while i < TaskBar1^.ItemCount do
    begin
      if TaskBar1^.Items[i].Align = tbRight then
      begin
        if not TaskBar1^.Items[i].ShowCaption then
          TaskBar1^.Items[i].Width := ICON_ONLY_WIDTH
        else
          TaskBar1^.Items[i].Width := itemWidth;

        TaskBar1^.Items[i].X := currentX;
        TaskBar1^.Items[i].Y := TaskBar1^.Y + 2;
        TaskBar1^.Items[i].Height := TASKBAR_HEIGHT - 4;
        
        currentX := currentX + TaskBar1^.Items[i].Width + ITEM_SPACING;
      end;
      Inc(i);
    end;
  end;
end;

procedure TaskBarItemClick(Item: PTaskBarItem);
begin
  Desktop_ToggleGridMode;
end;

procedure TaskBar_Init(ScreenWidth: Integer);
var
  i: Integer;
begin
  if TaskBar1 = nil then
  begin
    TaskBar1 := PTaskBarData(MemAlloc(SizeOf(TTaskBarData)));
    if TaskBar1 = nil then Exit;
  end;

  FillChar(TaskBar1^, SizeOf(TTaskBarData), 0);

  TaskBar1^.ScreenWidth := ScreenWidth;
  TaskBar1^.Width := ScreenWidth;
  TaskBar1^.Height := TASKBAR_HEIGHT;
  TaskBar1^.X := 0;
  TaskBar1^.Y := SCREEN_HEIGHT - TASKBAR_HEIGHT;

  i := 0;
  while i < MAX_TASKBAR_ITEMS do
  begin
    TaskBar1^.Items[i].Pressed := False;
    TaskBar1^.Items[i].Active := False;
    TaskBar1^.Items[i].Form := nil;
    Inc(i);
  end;

  // Varsay�lan Uygulama Butonu (�kon + Ba�l�k)
  TaskBar_AddItem('App', tbCenter, tbiButton, itSettings1, False, True, @TaskBarItemClick);
  TaskBar_AddItem('App', tbCenter, tbiButton, itSettings1, False, True, @TaskBarItemClick);
  TaskBar_AddItem('App', tbCenter, tbiButton, itSettings1, False, True, @TaskBarItemClick);
end;

procedure TaskBar_DrawStartButton;
var
  bgColor: LongWord;
begin
  if TaskBar1 = nil then Exit;
  
  if TaskBar1^.StartPressed then
    bgColor := $00008000
  else
    bgColor := $0000C000;
  
  KFill(TaskBar1^.X, TaskBar1^.Y, START_BUTTON_WIDTH, TASKBAR_HEIGHT, bgColor);
  KRect(TaskBar1^.X, TaskBar1^.Y, START_BUTTON_WIDTH, TASKBAR_HEIGHT, $00000000);
  
  // Ba�lat ikonu (iste�e ba�l�) ve yaz�s�
  DrawIcon(TaskBar1^.X + 6, TaskBar1^.Y + 6, 20, itMyComputer);
  KStr(TaskBar1^.X + 30, TaskBar1^.Y + 10, 'Start', $00FFFFFF);
end;

{ --- CMOS / RTC YARDIMCI FONKS�YONLARI --- }

// CMOS Kayd�ndan 1 Bayt Oku
function ReadCMOS(Reg: Byte): Byte;
begin
  WritePortB($70, Reg);
  Result := ReadPortB($71);
end;

// CMOS Saatinin G�ncellenip G�ncellenmedi�ini Kontrol Et
function CMOSIsUpdating: Boolean;
begin
  WritePortB($70, $0A);
  Result := (ReadPortB($71) and $80) <> 0;
end;

// BCD Format�n� Say�sala �evir (�rn: $12 -> 12)
function BCDToBin(Val: Byte): Byte;
begin
  Result := (Val and $0F) + ((Val shr 4) * 10);
end;

// Say�y� 2 Haneli Metne �evir (�rn: 9 -> "09")
procedure ByteTo2Char(Val: Byte; Dest: PChar);
begin
  Dest[0] := Char(Ord('0') + (Val div 10));
  Dest[1] := Char(Ord('0') + (Val mod 10));
end;

// Ger�ek Zamanl� Saati CMOS'tan �ek
procedure GetRTCTime(var Hour, Min, Sec: Byte);
var
  StatusB: Byte;
  IsBCD: Boolean;
begin
  // G�ncelleme bitene kadar bekle
  while CMOSIsUpdating do ;

  Sec  := ReadCMOS($00);
  Min  := ReadCMOS($02);
  Hour := ReadCMOS($04);

  // Status Register B ($0B): Bit 2 = 1 ise Binary, 0 ise BCD format�ndad�r
  StatusB := ReadCMOS($0B);
  IsBCD   := (StatusB and $04) = 0;

  if IsBCD then
  begin
    Sec  := BCDToBin(Sec);
    Min  := BCDToBin(Min);
    Hour := BCDToBin(Hour);
  end;
end;

// Saati "HH:MM:SS" Metnine �evir
procedure GetTimeString(TimeStr: PChar);
var
  H, M, S: Byte;
begin
  GetRTCTime(H, M, S);
  
  ByteTo2Char(H, @TimeStr[0]);
  TimeStr[2] := ':';
  ByteTo2Char(M, @TimeStr[3]);
  TimeStr[5] := ':';
  ByteTo2Char(S, @TimeStr[6]);
  TimeStr[8] := #0;
end;

{ --- G�NCELLENM�� SYSTRAY ��Z�M� --- }

procedure TaskBar_DrawSysTray;
var
  x: Integer;
  TimeStr: array[0..15] of Char;
begin
  if TaskBar1 = nil then Exit;
  
  x := TaskBar1^.X + TaskBar1^.Width - SYSTRAY_WIDTH;
  
  // Systray Arka Plan ve �er�eve
  KFill(x, TaskBar1^.Y, SYSTRAY_WIDTH, TASKBAR_HEIGHT, $00404040);
  KRect(x, TaskBar1^.Y, SYSTRAY_WIDTH, TASKBAR_HEIGHT, $00000000);
  
  // Canl� Saati Oku ve �iz
  GetTimeString(@TimeStr[0]);
  KStr(x + 18, TaskBar1^.Y + 10, @TimeStr[0], $00FFFFFF);
end;

procedure TaskBar_DrawItem(Item: PTaskBarItem);
var
  bgColor: LongWord;
  textColor: LongWord;
  textX, iconX, iconY, iconSize: Integer;
begin
  if Item = nil then Exit;
  
  // Arka plan rengi
  if Item^.Active then
    bgColor := $00808080
  else if Item^.Pressed then
    bgColor := $00606060
  else
    bgColor := $00505050;
  
  KFill(Item^.X, Item^.Y, Item^.Width, Item^.Height, bgColor);
  
  // D�� �er�eve
  if Item^.Active then
    KRect(Item^.X, Item^.Y, Item^.Width, Item^.Height, $00FFFFFF)
  else
    KRect(Item^.X, Item^.Y, Item^.Width, Item^.Height, $00000000);
  
  textX := Item^.X + 6;
  
  // 1. �KON ��Z�M�
  if Item^.ShowIcon then
  begin
    iconSize := 24; // 32px y�kseklik i�in 20px ikon
    
    if Item^.ShowCaption then
      iconX := Item^.X + 5
    else
      iconX := Item^.X + ((Item^.Width - iconSize) div 2); // Sadece ikonsa ortala
      
    iconY := Item^.Y + ((Item^.Height - iconSize) div 2);
    
    DrawIcon(iconX, iconY, iconSize, Item^.IconType);
    textX := iconX + iconSize + 6;
  end;
  
  // 2. YAZI (CAPTION) ��Z�M�
  if Item^.ShowCaption then
  begin
    if Item^.Active then
      textColor := $00FFFFFF
    else
      textColor := $00CCCCCC;
      
    KStr(textX, Item^.Y + 8, @Item^.Title[0], textColor);
  end;
end;

procedure TaskBar_Render;
var
  i: Integer;
begin
  if TaskBar1 = nil then Exit;
  
  KFill(TaskBar1^.X, TaskBar1^.Y, TaskBar1^.Width, TaskBar1^.Height, $00303030);
  KLine(TaskBar1^.X, TaskBar1^.Y, TaskBar1^.X + TaskBar1^.Width, TaskBar1^.Y, $00000000);
  
  TaskBar_DrawStartButton;
  
  i := 0;
  while i < TaskBar1^.ItemCount do
  begin
    if TaskBar1^.Items[i].ItemType <> tbiSeparator then
      TaskBar_DrawItem(@TaskBar1^.Items[i]);
    
    Inc(i);
  end;
  
  TaskBar_DrawSysTray;
end;

function TaskBar_AddItem(Title: PChar; Align: TTaskBarAlign;
                         ItemType: TTaskBarItemType;
                         IconType: TIconType;
                         ShowCaption: Boolean;
                         ShowIcon: Boolean;
                         Click: TTaskBarItemClick): Integer;
var
  idx: Integer;
begin
  Result := -1;
  if TaskBar1 = nil then Exit;
  if TaskBar1^.ItemCount >= MAX_TASKBAR_ITEMS then Exit;
  
  idx := TaskBar1^.ItemCount;
  FillChar(TaskBar1^.Items[idx], SizeOf(TTaskBarItem), 0);

  TaskBar1^.Items[idx].ItemType    := ItemType;
  TaskBar1^.Items[idx].Align       := Align;
  TaskBar1^.Items[idx].IconType    := IconType;
  TaskBar1^.Items[idx].ShowCaption := ShowCaption;
  TaskBar1^.Items[idx].ShowIcon    := ShowIcon;
  TaskBar1^.Items[idx].OnClick     := Click;
  
  if Title <> nil then
    StrCopy(@TaskBar1^.Items[idx].Title[0], Title);
  
  Inc(TaskBar1^.ItemCount);
  TaskBar_CalculateLayout;
  
  Result := idx;
end;

function TaskBar_AddWindow(Form: PForm; IconType: TIconType; ShowCaption: Boolean): Integer;
var
  idx, i: Integer;
begin
  Result := -1;
  if TaskBar1 = nil then Exit;

  i := 0;
  while i < TaskBar1^.ItemCount do
  begin
    if TaskBar1^.Items[i].Form = Form then
    begin
      Result := i;
      Exit;
    end;
    Inc(i);
  end;
  
  idx := TaskBar_AddItem(@Form^.Caption[0], tbCenter, tbiWindow, IconType, ShowCaption, True);
  if idx >= 0 then
  begin
    TaskBar1^.Items[idx].Form := Form;
    Result := idx;
  end;
end;

procedure TaskBar_RemoveWindow(Form: PForm);
var
  i, j: Integer;
begin
  if TaskBar1 = nil then Exit;
  
  i := 0;
  while i < TaskBar1^.ItemCount do
  begin
    if TaskBar1^.Items[i].Form = Form then
    begin
      j := i;
      while j < TaskBar1^.ItemCount - 1 do
      begin
        TaskBar1^.Items[j] := TaskBar1^.Items[j + 1];
        Inc(j);
      end;
      
      Dec(TaskBar1^.ItemCount);
      TaskBar_CalculateLayout;
      Exit;
    end;
    Inc(i);
  end;
end;

procedure TaskBar_UpdateWindow(Form: PForm);
var
  i: Integer;
begin
  if TaskBar1 = nil then Exit;

  i := 0;
  while i < TaskBar1^.ItemCount do
  begin
    if TaskBar1^.Items[i].Form = Form then
    begin
      StrCopy(@TaskBar1^.Items[i].Title[0], @Form^.Caption[0]);
      Exit;
    end;
    Inc(i);
  end;
end;

procedure TaskBar_SetActive(Form: PForm);
var
  i: Integer;
begin
  if TaskBar1 = nil then Exit;
  
  i := 0;
  while i < TaskBar1^.ItemCount do
  begin
    TaskBar1^.Items[i].Active := False;
    Inc(i);
  end;
  
  i := 0;
  while i < TaskBar1^.ItemCount do
  begin
    if TaskBar1^.Items[i].Form = Form then
    begin
      TaskBar1^.Items[i].Active := True;
      Exit;
    end;
    Inc(i);
  end;
end;

procedure TaskBar_HandleClick(X, Y: Integer);
var
  i: Integer;
begin
  if TaskBar1 = nil then Exit;
  
  if (X >= TaskBar1^.X) and (X < TaskBar1^.X + START_BUTTON_WIDTH) and
     (Y >= TaskBar1^.Y) and (Y < TaskBar1^.Y + TASKBAR_HEIGHT) then
  begin
    TaskBar1^.StartPressed := not TaskBar1^.StartPressed;
    Desktop_ToggleGridMode;
    Exit;
  end;

  i := 0;
  while i < TaskBar1^.ItemCount do
  begin
    if (X >= TaskBar1^.Items[i].X) and
       (X < TaskBar1^.Items[i].X + TaskBar1^.Items[i].Width) and
       (Y >= TaskBar1^.Items[i].Y) and
       (Y < TaskBar1^.Items[i].Y + TaskBar1^.Items[i].Height) then
    begin
      if TaskBar1^.Items[i].ItemType = tbiWindow then
      begin
        if TaskBar1^.Items[i].Form <> nil then
        begin
          if TaskBar1^.Items[i].Active then
          begin
            if not TaskBar1^.Items[i].Form^.Minimized then
            begin
              TaskBar1^.Items[i].Form^.Hide();
              TaskBar1^.Items[i].Form^.Minimized := True;
            end
            else
            begin
              TaskBar1^.Items[i].Form^.Maximized := False;
              TaskBar1^.Items[i].Form^.Minimized := False;
              TaskBar1^.Items[i].Form^.Show();
              WinManager.BringToFront(TaskBar1^.Items[i].Form);
            end;
          end
          else
          begin
            TaskBar1^.Items[i].Form^.Maximized := False;
            TaskBar1^.Items[i].Form^.Minimized := False;
            TaskBar1^.Items[i].Form^.Show();
            WinManager.BringToFront(TaskBar1^.Items[i].Form);
            TaskBar_SetActive(TaskBar1^.Items[i].Form);
          end;
        end;
      end
      else if Assigned(TaskBar1^.Items[i].OnClick) then
      begin
        TaskBar1^.Items[i].OnClick(@TaskBar1^.Items[i]);
      end;
      
      Exit;
    end;
    Inc(i);
  end;
end;

end.

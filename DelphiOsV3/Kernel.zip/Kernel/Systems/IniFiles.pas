unit IniFiles;

interface

uses
  SysUtils, Memory, Fat32;

type
  PIniItem = ^TIniItem;
  TIniItem = record
    Next: PIniItem;
    Key:   array[0..29] of Char;
    Value: array[0..29] of Char;
  end;

  TIniFile = object
  private
    Head: PIniItem;
  public
    procedure Init;
    procedure Done;
    procedure Add(Key, Value: PChar);
    function  Find(Key: PChar): PChar;
    procedure Delete(Key: PChar);
    procedure LoadFromFile(Filename: PChar);
    procedure SaveToFile(Filename: PChar);
  end;

function  CompareINIValue(FileName, Key, Deger: PChar): Boolean;
function  ReadINIFile(FileName, Key: PChar; Output: PChar): Boolean;
procedure WriteINIFile(FileName, Key, Value: PChar);

implementation

{-----------------------------------------------------------------------------}
{ Yardimci: Case-insensitive PChar compare }
{-----------------------------------------------------------------------------}
function StrEqualI(s1, s2: PChar): Boolean;
var
  c1, c2: Char;
begin
  Result := False;
  if (s1 = nil) or (s2 = nil) then Exit;

  while True do
  begin
    c1 := s1^;  c2 := s2^;
    if (c1 >= 'a') and (c1 <= 'z') then c1 := Char(Ord(c1) - 32);
    if (c2 >= 'a') and (c2 <= 'z') then c2 := Char(Ord(c2) - 32);

    if c1 <> c2 then Exit;
    if c1 = #0 then Break;
    Inc(s1); Inc(s2);
  end;
  Result := True;
end;

function StrScanChar(Str: PChar; Chr: Char): PChar;
begin
  Result := Str;
  while Result^ <> #0 do
  begin
    if Result^ = Chr then Exit;
    Inc(Result);
  end;
  Result := nil;
end;

{-----------------------------------------------------------------------------}
{ TIniFile }
{-----------------------------------------------------------------------------}
procedure TIniFile.Init;
begin
  Head := nil;
end;

procedure TIniFile.Done;
var
  Current, Next: PIniItem;
begin
  Current := Head;
  while Current <> nil do
  begin
    Next := Current^.Next;
    FreeMem(Current);
    Current := Next;
  end;
  Head := nil;
end;

procedure TIniFile.Add(Key, Value: PChar);
var
  Item: PIniItem;
  Len: Integer;
begin
  if (Key = nil) or (Value = nil) then Exit;

  Delete(Key);  // Varsa once sil (guncelleme)

  Item := PIniItem(MemAlloc(SizeOf(TIniItem)));
  if Item = nil then Exit;
  FillChar(Item^, SizeOf(TIniItem), 0);

  Len := StrLen(Key);
  if Len > 29 then Len := 29;
  Move(Key^, Item^.Key[0], Len);
  Item^.Key[Len] := #0;

  Len := StrLen(Value);
  if Len > 29 then Len := 29;
  Move(Value^, Item^.Value[0], Len);
  Item^.Value[Len] := #0;

  Item^.Next := Head;
  Head := Item;
end;

function TIniFile.Find(Key: PChar): PChar;
var
  Current: PIniItem;
begin
  Result := nil;
  if Key = nil then Exit;

  Current := Head;
  while Current <> nil do
  begin
    if StrEqualI(Key, @Current^.Key[0]) then
    begin
      Result := @Current^.Value[0];
      Exit;
    end;
    Current := Current^.Next;
  end;
end;

procedure TIniFile.Delete(Key: PChar);
var
  Current, Prev: PIniItem;
begin
  if Key = nil then Exit;

  Current := Head;
  Prev := nil;
  while Current <> nil do
  begin
    if StrEqualI(Key, @Current^.Key[0]) then
    begin
      if Prev = nil then Head := Current^.Next
      else Prev^.Next := Current^.Next;
      FreeMem(Current);
      Exit;
    end;
    Prev := Current;
    Current := Current^.Next;
  end;
end;

{-----------------------------------------------------------------------------}
{ LoadFromFile � Fat32 API ile (ReadFileLine YOK) }
{-----------------------------------------------------------------------------}
procedure TIniFile.LoadFromFile(Filename: PChar);
var
  FileHandle: Integer;
  FileSizeVal: LongWord;
  Buf: PChar;
  P, LineStart, EqPos: PChar;
  KeyBuf, ValBuf: array[0..63] of Char;
  I: Integer;
begin
  FileHandle := OpenFile(Filename, FILE_READ);
  if FileHandle < 0 then Exit;

  FileSizeVal := FileSize(FileHandle);
  if FileSizeVal = 0 then
  begin
    CloseFile(FileHandle);
    Exit;
  end;

  Buf := PChar(MemAlloc(FileSizeVal + 1));
  if Buf = nil then
  begin
    CloseFile(FileHandle);
    Exit;
  end;

  ReadFile(FileHandle, Buf, FileSizeVal);
  Buf[FileSizeVal] := #0;
  CloseFile(FileHandle);

  P := Buf;
  while P^ <> #0 do
  begin
    { Satir baslangicina git (newline'lari atla) }
    while (P^ = #13) or (P^ = #10) do Inc(P);
    if P^ = #0 then Break;
    LineStart := P;

    { Satir sonunu bul }
    while (P^ <> #0) and (P^ <> #13) and (P^ <> #10) do Inc(P);
    if P^ <> #0 then begin P^ := #0; Inc(P); end;

    { Yorum/bos satir atla }
    if (LineStart^ = '#') or (LineStart^ = ';') or (LineStart^ = #0) then Continue;

    { '=' ara }
    EqPos := StrScanChar(LineStart, '=');
    if EqPos <> nil then
    begin
      EqPos^ := #0;
      Inc(EqPos);

      { Key (bosluklari kirp) }
      while LineStart^ = ' ' do Inc(LineStart);
      I := 0;
      while (LineStart^ <> #0) and (I < 29) do
      begin
        KeyBuf[I] := LineStart^;
        Inc(I); Inc(LineStart);
      end;
      while (I > 0) and (KeyBuf[I-1] = ' ') do Dec(I);
      KeyBuf[I] := #0;

      { Value (bosluklari kirp) }
      while EqPos^ = ' ' do Inc(EqPos);
      I := 0;
      while (EqPos^ <> #0) and (I < 29) do
      begin
        ValBuf[I] := EqPos^;
        Inc(I); Inc(EqPos);
      end;
      while (I > 0) and (ValBuf[I-1] = ' ') do Dec(I);
      ValBuf[I] := #0;

      if KeyBuf[0] <> #0 then
        Add(@KeyBuf[0], @ValBuf[0]);
    end;
  end;

  FreeMem(Buf);
end;

{-----------------------------------------------------------------------------}
{ SaveToFile � Fat32 API ile (WriteFileLine YOK) }
{-----------------------------------------------------------------------------}
procedure TIniFile.SaveToFile(Filename: PChar);
var
  FileHandle: Integer;
  Current: PIniItem;
  LineBuf: array[0..127] of Char;
  I: Integer;
  P: PChar;
begin
  FileHandle := OpenFile(Filename, FILE_WRITE or  FILE_CREATE);  //
  if FileHandle < 0 then Exit;

  Current := Head;
  while Current <> nil do
  begin
    FillChar(LineBuf, SizeOf(LineBuf), 0);

    { Key }
    I := 0;  P := @Current^.Key[0];
    while (P^ <> #0) and (I < 29) do
    begin
      LineBuf[I] := P^;
      Inc(I); Inc(P);
    end;

    { = }
    LineBuf[I] := '=';
    Inc(I);

    { Value }
    P := @Current^.Value[0];
    while (P^ <> #0) and (I < 124) do
    begin
      LineBuf[I] := P^;
      Inc(I); Inc(P);
    end;

    { CRLF }
    LineBuf[I] := #13;  Inc(I);
    LineBuf[I] := #10;  Inc(I);

    WriteFile(FileHandle, @LineBuf[0], I);
    Current := Current^.Next;
  end;

  CloseFile(FileHandle);
end;

{-----------------------------------------------------------------------------}
{ Global Fonksiyonlar }
{-----------------------------------------------------------------------------}
function CompareINIValue(FileName, Key, Deger: PChar): Boolean;
var
  IniFile: TIniFile;
  P: PChar;
begin
  Result := False;
  if (FileName = nil) or (Key = nil) or (Deger = nil) then Exit;

  IniFile.Init;
  IniFile.LoadFromFile(FileName);
  P := IniFile.Find(Key);
  if P <> nil then Result := StrEqualI(P, Deger);
  IniFile.Done;
end;

function ReadINIFile(FileName, Key: PChar; Output: PChar): Boolean;
var
  IniFile: TIniFile;
  P: PChar;
begin
  Result := False;
  if (FileName = nil) or (Key = nil) or (Output = nil) then Exit;

  IniFile.Init;
  IniFile.LoadFromFile(FileName);
  P := IniFile.Find(Key);
  if P <> nil then
  begin
    StrCopy(Output, P);
    Result := True;
  end;
  IniFile.Done;
end;

procedure WriteINIFile(FileName, Key, Value: PChar);
var
  IniFile: TIniFile;
begin
  if (FileName = nil) or (Key = nil) or (Value = nil) then Exit;

  IniFile.Init;
  IniFile.LoadFromFile(FileName);
  IniFile.Add(Key, Value);
  IniFile.SaveToFile(FileName);
  IniFile.Done;
end;

end.

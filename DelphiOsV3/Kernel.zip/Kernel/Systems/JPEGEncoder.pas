{===============================================================================
  JPEGEncoder.pas
  -------------------------------------------------------------------------------
  Minimal JPEG Baseline Encoder (4:2:0) - Delphi 7 / Kernel
  -------------------------------------------------------------------------------
  Giri?  : 24-bit BGR
  ??kt?  : Bellekte JPEG (SOI ... EOI)
  Quality: 1..100
===============================================================================}

unit JPEGEncoder;

interface

uses
  SysUtils, Memory,Fat32,Vesa,Math;

  {
function JPEG_Encode(PixelData: Pointer; Width, Height, Quality: Integer;
  var OutSize: Integer): Pointer;}

   procedure JPEG_Encode(const fileName: PChar;PixelData: PByteArray; Width, Height, Quality: Integer);

   function JPEG_Encode_Stream(PixelData: PByteArray; Width, Height, Quality: Integer;out  OutData:PByteArray):Integer;

implementation

//=============================================================================
// Tipler ve Sabitler
//=============================================================================

const
  DCT_SIZE = 8;
  HUFF_TREE_DC_LEN = 16;
  HUFF_TREE_AC_LEN = 256;

  const
  default_luma_table: array[0..63] of Byte = (
    16, 11, 10, 16,  24,  40,  51,  61,
    12, 12, 14, 19,  26,  58,  60,  55,
    14, 13, 16, 24,  40,  57,  69,  56,
    14, 17, 22, 29,  51,  87,  80,  62,
    18, 22, 37, 56,  68, 109, 103,  77,
    24, 35, 55, 64,  81, 104, 113,  92,
    49, 64, 78, 87, 103, 121, 120, 101,
    72, 92, 95, 98, 112, 100, 103,  99
  );

  const
  default_chroma_table: array[0..63] of Byte = (
    17, 18, 24, 47, 99, 99, 99, 99,
    18, 21, 26, 66, 99, 99, 99, 99,
    24, 26, 56, 99, 99, 99, 99, 99,
    47, 66, 99, 99, 99, 99, 99, 99,
    99, 99, 99, 99, 99, 99, 99, 99,
    99, 99, 99, 99, 99, 99, 99, 99,
    99, 99, 99, 99, 99, 99, 99, 99,
    99, 99, 99, 99, 99, 99, 99, 99
  );

  const
  zigzag_table: array[0..63] of Byte = (
     0,  1,  5,  6, 14, 15, 27, 28,
     2,  4,  7, 13, 16, 26, 29, 42,
     3,  8, 12, 17, 25, 30, 41, 43,
     9, 11, 18, 24, 31, 40, 44, 53,
    10, 19, 23, 32, 39, 45, 52, 54,
    20, 22, 33, 38, 46, 51, 55, 60,
    21, 34, 37, 47, 50, 56, 59, 61,
    35, 36, 48, 49, 57, 58, 62, 63
  );

  const
  default_ht_luma_dc_len: array[0..15] of Byte = (0,1,5,1,1,1,1,1,1,0,0,0,0,0,0,0);
  default_ht_luma_dc: array[0..11] of Byte = (0,1,2,3,4,5,6,7,8,9,10,11);

  default_ht_chroma_dc_len: array[0..15] of Byte = (0,3,1,1,1,1,1,1,1,1,1,0,0,0,0,0);
  default_ht_chroma_dc: array[0..11] of Byte = (0,1,2,3,4,5,6,7,8,9,10,11);

  default_ht_luma_ac_len: array[0..15] of Byte = (0,2,1,3,3,2,4,3,5,5,4,4,0,0,1,$7d);
  default_ht_chroma_ac_len: array[0..15] of Byte = (0,2,1,2,4,4,3,4,7,5,4,4,0,1,2,$77);

  const
  default_ht_luma_ac: array[0..161] of Byte = (
    $01,$02,$03,$00,$04,$11,$05,$12,$21,$31,$41,$06,$13,$51,$61,$07,
    $22,$71,$14,$32,$81,$91,$A1,$08,$23,$42,$B1,$C1,$15,$52,$D1,$F0,
    $24,$33,$62,$72,$82,$09,$0A,$16,$17,$18,$19,$1A,$25,$26,$27,$28,
    $29,$2A,$34,$35,$36,$37,$38,$39,$3A,$43,$44,$45,$46,$47,$48,$49,
    $4A,$53,$54,$55,$56,$57,$58,$59,$5A,$63,$64,$65,$66,$67,$68,$69,
    $6A,$73,$74,$75,$76,$77,$78,$79,$7A,$83,$84,$85,$86,$87,$88,$89,
    $8A,$92,$93,$94,$95,$96,$97,$98,$99,$9A,$A2,$A3,$A4,$A5,$A6,$A7,
    $A8,$A9,$AA,$B2,$B3,$B4,$B5,$B6,$B7,$B8,$B9,$BA,$C2,$C3,$C4,$C5,
    $C6,$C7,$C8,$C9,$CA,$D2,$D3,$D4,$D5,$D6,$D7,$D8,$D9,$DA,$E1,$E2,
    $E3,$E4,$E5,$E6,$E7,$E8,$E9,$EA,$F1,$F2,$F3,$F4,$F5,$F6,$F7,$F8,
    $F9,$FA
  );

  default_ht_chroma_ac: array[0..161] of Byte = (
    $00,$01,$02,$03,$11,$04,$05,$21,$31,$06,$12,$41,$51,$07,$61,$71,
    $13,$22,$32,$81,$08,$14,$42,$91,$A1,$B1,$C1,$09,$23,$33,$52,$F0,
    $15,$62,$72,$D1,$0A,$16,$24,$34,$E1,$25,$F1,$17,$18,$19,$1A,$26,
    $27,$28,$29,$2A,$35,$36,$37,$38,$39,$3A,$43,$44,$45,$46,$47,$48,
    $49,$4A,$53,$54,$55,$56,$57,$58,$59,$5A,$63,$64,$65,$66,$67,$68,
    $69,$6A,$73,$74,$75,$76,$77,$78,$79,$7A,$82,$83,$84,$85,$86,$87,
    $88,$89,$8A,$92,$93,$94,$95,$96,$97,$98,$99,$9A,$A2,$A3,$A4,$A5,
    $A6,$A7,$A8,$A9,$AA,$B2,$B3,$B4,$B5,$B6,$B7,$B8,$B9,$BA,$C2,$C3,
    $C4,$C5,$C6,$C7,$C8,$C9,$CA,$D2,$D3,$D4,$D5,$D6,$D7,$D8,$D9,$DA,
    $E2,$E3,$E4,$E5,$E6,$E7,$E8,$E9,$EA,$F2,$F3,$F4,$F5,$F6,$F7,$F8,
    $F9,$FA
  );


  const

   coe:array[0..8-1,0..8-1] of Smallint=(
        (4096,    4096,    4096,    4096,    4096,    4096,    4096,   4096),
	(5681,    4816,    3218,    1130,   -1130,   -3218,   -4816,  -5681),
	(5352,    2217,   -2217,   -5352,   -5352,   -2217,    2217,   5352),
	(4816,   -1130,   -5681,   -3218,    3218,    5681,    1130,  -4816),
	(4096,   -4096,   -4096,    4096,    4096,   -4096,   -4096,   4096),
	(3218,   -5681,    1130,    4816,   -4816,   -1130,    5681,  -3218),
	(2217,   -5352,    5352,   -2217,   -2217,    5352,   -5352,   2217),
	(1130,   -3218,    4816,   -5681,    5681,   -4816,    3218,  -1130)
  );



  type
  TJFIFHeader = packed record
    len: Word;
    identifier: array[0..4] of Byte;
    version: Word;
    units: Byte;
    Hdensity: Word;
    Vdensity: Word;
    HthumbnailA: Byte;
    VthumbnailA: Byte;
  end;

  type
  TColorComponent = packed record
    id: Byte;
    sampling_factors: Byte;
    qt_table_id: Byte;
  end;


  type
  TFrameHeader = packed record
    precision: Byte;
    height: Word;
    width: Word;
    component_num: Byte;
    component: array[0..2] of TColorComponent;
  end;

  type
  TCoefficients = packed record
    raw: Byte;
    code_length: Byte;
    code_word: Word;
  end;

  type
  TFixedBuffer = array[0..65565] of Byte;

  var
     bit_ptr: Cardinal = 0;
     bitbuf: Cardinal = 0;

     jpegbuffer: PByteArray;//TFixedBuffer;
     buffer_pos: Integer=0;

      CosTable: array[0..7, 0..7] of Single;
      CosTableReady: Boolean = False;

procedure InitCosTable;
var
  i, j: Integer;
begin
  if CosTableReady then Exit;
  for i := 0 to 7 do
    for j := 0 to 7 do
      CosTable[i, j] := Cos((2 * j + 1) * i * Pi / 16) *
                        (ifThen( i = 0, Sqrt(1/8) , Sqrt(2/8)));
  CosTableReady := True;
end;

// H�zl� ayr�labilir DCT (Float)
procedure BlockDCT(const InBlock: array of ShortInt; var OutBlock: array of Double);
var
  tmp: array[0..63] of Single;
  i, j, k: Integer;
  sum: Single;
begin
  InitCosTable;

  // 1. Sat�rlar
  for i := 0 to 7 do
  begin
    for j := 0 to 7 do
    begin
      sum := 0;
      for k := 0 to 7 do
        sum := sum + InBlock[i*8 + k] * CosTable[j, k];
      tmp[i*8 + j] := sum;

    end;
  end;

  // 2. S�tunlar
  for j := 0 to 7 do
  begin
    for i := 0 to 7 do
    begin
      sum := 0;
      for k := 0 to 7 do
        sum := sum + tmp[k*8 + j] * CosTable[i, k];
      OutBlock[i*8 + j] := sum;

    end;
  end;
end;






procedure SetBuffer();
begin
  jpegbuffer := PByteArray(MemAlloc(65565));
  buffer_pos := 0; // Yeni buffer ile pozisyonu s f rla
  bit_ptr := 0; // Bit yazma i in s f rlama
  bitbuf := 0;
end;

function jpegwritefile(data: PByteArray; len: Integer): Integer;
var
  i: Integer;
begin
  // Buffer s n rlar n  kontrol et
  if buffer_pos + len > 65565 {Length(jpegbuffer)} then
  begin
    Result := -1; // Buffer ta mas 
    Exit;
  end;

  // Veriyi buffer'a kopyala
  for i := 0 to len - 1 do
  begin
    jpegbuffer[buffer_pos + i] := data[i];
  end;
  Inc(buffer_pos, len);
  Result := len;
end;

function jpegwriteu8(data: Byte): Integer;
begin
  // Buffer s n rlar n  kontrol et
  if buffer_pos >=   65565 {Length(jpegbuffer)} then
  begin
    Result := -1; // Buffer ta mas 
    Exit;
  end;

  jpegbuffer[buffer_pos] := data;
  Inc(buffer_pos);
  Result := 1;
end;

function jpegwriteu16(data: Word): Integer;
begin
  // Buffer s n rlar n  kontrol et
  if buffer_pos + 2 >   65565 {Length(jpegbuffer)} then
  begin
    Result := -1; // Buffer ta mas 
    Exit;
  end;

  jpegbuffer[buffer_pos] := Byte(data and $FF); // D   k bayt
  jpegbuffer[buffer_pos + 1] := Byte(data shr 8); // Y ksek bayt
  Inc(buffer_pos, 2);
  Result := 2;
end;

function jpegwriteu32(data: Cardinal): Integer;
begin
  // Buffer s n rlar n  kontrol et
  if buffer_pos + 4 >   65565 {Length(jpegbuffer)} then
  begin
    Result := -1; // Buffer ta mas 
    Exit;
  end;

  jpegbuffer[buffer_pos] := Byte(data and $FF);
  jpegbuffer[buffer_pos + 1] := Byte((data shr 8) and $FF);
  jpegbuffer[buffer_pos + 2] := Byte((data shr 16) and $FF);
  jpegbuffer[buffer_pos + 3] := Byte((data shr 24) and $FF);
  Inc(buffer_pos, 4);
  Result := 4;
end;


function jpegwritebits(data: Cardinal; len: Integer; flush: boolean): Integer;
var
  w: Byte;
begin
  bitbuf := bitbuf or (data shl (32 - bit_ptr - len));
  bit_ptr := bit_ptr + len;

  while bit_ptr >= 8 do
  begin
    w := Byte((bitbuf and $FF000000) shr 24);
    if jpegwriteu8(w) < 0 then
    begin
      Result := -1; // Buffer ta mas 
      Exit;
    end;
    if w = $FF then
    begin
      if jpegwriteu8(   0) < 0 then
      begin
        Result := -1; // Buffer ta mas 
        Exit;
      end;
    end;
    bitbuf := bitbuf shl 8;
    bit_ptr := bit_ptr - 8;
  end;

  if flush then
  begin
    w := Byte((bitbuf and $FF000000) shr 24);
    if jpegwriteu8(   w) < 0 then
    begin
      Result := -1; // Buffer ta mas 
      Exit;
    end;
  end;

  Result := 0;
end;







function Swap16(dat: Word): Word;
var
  lo, hi: Word;
begin
  lo := dat and $00FF;
  hi := (dat and $FF00) shr 8;
  Result := (lo shl 8) or hi;
end;

function ck(k: Integer): Double;
begin
  if k = 0 then
    Result := Sqrt(1.0 / DCT_SIZE)
  else
    Result := Sqrt(2.0 / DCT_SIZE);
end;



function ReadBlock(const RGB: PByteArray; var Block: array of Byte;
                   W, H, X, Y: Integer): Integer;
var
  dx, dy: Integer;
  rgb_offset, block_offset: Integer;
begin
  for dy := 0 to 7 do
  begin
    for dx := 0 to 7 do
    begin
      rgb_offset := (((Y + dy) * W) + (X + dx)) * 3;
      block_offset := (dy * DCT_SIZE + dx) * 3;

      if (X + dx >= W) then
      begin
        Block[block_offset + 0] := Block[block_offset - 3 + 0];
        Block[block_offset + 1] := Block[block_offset - 3 + 1];
        Block[block_offset + 2] := Block[block_offset - 3 + 2];
        Continue;
      end;
      if (Y + dy >= H) then
      begin
        Block[block_offset + 0] := Block[block_offset - 3 * DCT_SIZE + 0];
        Block[block_offset + 1] := Block[block_offset - 3 * DCT_SIZE + 1];
        Block[block_offset + 2] := Block[block_offset - 3 * DCT_SIZE + 2];
        Continue;
      end;

      Block[block_offset + 0] := RGB[rgb_offset + 0];
      Block[block_offset + 1] := RGB[rgb_offset + 1];
      Block[block_offset + 2] := RGB[rgb_offset + 2];
    end;
  end;
  Result := 0;
end;

function EnsureInRange(Value, MinVal, MaxVal: Integer): ShortInt;
begin
  if Value < MinVal then
    Result := MinVal
  else if Value > MaxVal then
    Result := MaxVal
  else
    Result := Value;
end;

function BlockRGBToYUV444(const Block: array of Byte;
                          var Y, U, V: array of ShortInt): Integer;       //
var
  r, g, b: Byte;
  dx, dy: Integer;
  block_offset: Integer;
  luma, cb, cr: Single;
begin
  for dy := 0 to DCT_SIZE - 1 do
  begin
    for dx := 0 to DCT_SIZE - 1 do
    begin
      block_offset := dy * DCT_SIZE + dx;
      r := Block[block_offset * 3 + 0];
      g := Block[block_offset * 3 + 1];
      b := Block[block_offset * 3 + 2];

      luma := 0.299 * r + 0.587 * g + 0.114 * b - 128;
      cb   := -0.1687 * r - 0.3313 * g + 0.5 * b;
      cr   :=  0.5 * r - 0.4187 * g - 0.0813 * b;

      Y[block_offset] := EnsureInRange(Round(luma), -128, 127);
      U[block_offset] := EnsureInRange(Round(cb),   -128, 127);
      V[block_offset] := EnsureInRange(Round(cr),   -128, 127);
    end;
  end;
  Result := 0;
end;


function MakeQTTable(qt: Integer; const InTable: array of Byte; var OutTable: array of Byte): Integer;
var
  dx, dy, offset: Integer;
  alpha, tmp: Single;
begin
  if qt < 50 then
    alpha := 50.0 / qt
  else
    alpha := 2.0 - qt / 50.0;

  for dy := 0 to DCT_SIZE - 1 do
  begin
    for dx := 0 to DCT_SIZE - 1 do
    begin
      offset := dy * DCT_SIZE + dx;
      tmp := InTable[offset] * alpha;

      if tmp < 1.0 then
        tmp := 1.0
      else if tmp > 255.0 then
        tmp := 255.0;

      OutTable[offset] := Round(tmp);
    end;
  end;
  Result := 0;
end;

function MakeHuffmanTree(code_length, raw_val: array of Byte;
                         out_len: Integer; var OutTable: array of TCoefficients): Integer;
var
  i, j, count: Integer;
  code: Cardinal;
  code_bits: Integer;
begin
  code := 0;
  code_bits := 1;
  count := 0;

  for i := 0 to 15 do
  begin
    for j := 0 to code_length[i] - 1 do
    begin
      // Huffman a ac n  raw de er  zerinden yerle tiriyoruz
      OutTable[raw_val[count]].raw := raw_val[count];
      OutTable[raw_val[count]].code_word := code;
      OutTable[raw_val[count]].code_length := code_bits;

      Inc(count);
      Inc(code);
    end;
    Inc(code_bits);
    code := code shl 1;
  end;

  Result := 0;
end;

function BlockQuantization(const Table: array of Byte;
                           const InBlock: array of Double;
                           var OutBlock: array of Integer): Integer;
var
  dx, dy, offset: Integer;
begin
  for dy := 0 to DCT_SIZE - 1 do
  begin
    for dx := 0 to DCT_SIZE - 1 do
    begin
      offset := dy * DCT_SIZE + dx;
      OutBlock[offset] := Round(InBlock[offset] / Table[offset]);
    end;
  end;
  Result := 0;
end;


procedure BlockZigZag(const InBlock: array of Integer; 
                      var OutBlock: array of Integer);
var
  i: Integer;
begin
  for i := 0 to DCT_SIZE * DCT_SIZE - 1 do
  begin
    OutBlock[zigzag_table[i]] := InBlock[i];
  end;
end;


function GetValBitAndCode(Value: Integer; out BitNum: byte; out Code: Word): Integer;
var
  AbsVal: Integer;
begin
  AbsVal := Value;
  if Value < 0 then
  begin
    AbsVal := -AbsVal;
    Dec(Value); // JPEG format na  zg : negatif de erler i in  Value - 1 
  end;

  BitNum := 1;
  while (AbsVal shr 1) <> 0 do
  begin
     AbsVal := AbsVal shr 1;
    Inc(BitNum);
  end;

  Code := Word(Value and ((1 shl BitNum) - 1));
  Result := 0;
end;




procedure BlockEncode(const InBlock: array of Integer;
                      var LastDC: Integer;
                      const DC, AC: array of TCoefficients);
var
  i, lastNotZeroCnt, zeroCnt, dcDelta: Integer;
   bitNum,runSize: Byte;
  code: Word;
begin
   zeroCnt:=0;
   dcDelta:=0;
   lastNotZeroCnt:=0;
   runSize:=0;

  // DC kodlama
  dcDelta := InBlock[0] - LastDC;
  LastDC := InBlock[0];

  if dcDelta <> 0 then
  begin
    GetValBitAndCode(dcDelta, bitNum, code);
    JPEGWriteBits(  DC[bitNum].code_word, DC[bitNum].code_length, False);
    JPEGWriteBits(  code, bitNum, False);
  end
  else
  begin
    JPEGWriteBits(  DC[0].code_word, DC[0].code_length, False);
  end;

  // Son s f r olmayan AC bile enini bul
  lastNotZeroCnt := 0;
  for i := 63 downto 1 do
  begin
    if InBlock[i] <> 0 then
    begin
      lastNotZeroCnt := i;
      Break;
    end;
  end;


   // AC kodlama
  i := 1;
  while i <= lastNotZeroCnt do
  begin
    zeroCnt := 0;
    while (i <= lastNotZeroCnt) and (InBlock[i] = 0) do
    begin
      Inc(zeroCnt);
      Inc(i);
      if zeroCnt = 16 then
      begin
        JPEGWriteBits(  AC[$F0].code_word, AC[$F0].code_length, False);
        zeroCnt := 0;
      end;
    end;

    if i <= lastNotZeroCnt then
    begin
      GetValBitAndCode(InBlock[i], bitNum, code);
      runSize := (zeroCnt shl 4) or bitNum;
      JPEGWriteBits(  AC[runSize].code_word, AC[runSize].code_length, False);
      JPEGWriteBits(  code, bitNum, False);
      Inc(i);
    end;
  end;

  // EOB (End of Block) marker
  if lastNotZeroCnt <> 63 then
  begin
    JPEGWriteBits(  AC[0].code_word, AC[0].code_length, False);
  end;
end;





procedure JPEG_Encode(const fileName: PChar;PixelData: PByteArray; Width, Height, Quality: Integer);
var
  F:Integer;
  W, H, X, Y: Integer;
  LastY, LastU, LastV: Integer;
  QT, I: Integer;


  RGBBlock: array[0..DCT_SIZE * DCT_SIZE * 3 - 1] of Byte;

  YBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of ShortInt;
  UBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of ShortInt;
  VBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of ShortInt;

  DCTBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of Double;
  QTBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of Integer;
  ZigZagBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of Integer;

  LumaTable: array[0..DCT_SIZE * DCT_SIZE - 1] of Byte;
  ChromaTable: array[0..DCT_SIZE * DCT_SIZE - 1] of Byte;
  QTTableTmp: array[0..DCT_SIZE * DCT_SIZE - 1] of Byte;

  JFIF: TJFIFHeader;
  Frame: TFrameHeader;

  HuffTreeLumaDC: array[0..HUFF_TREE_DC_LEN - 1] of TCoefficients;
  HuffTreeChromaDC: array[0..HUFF_TREE_DC_LEN - 1] of TCoefficients;
  HuffTreeLumaAC: array[0..HUFF_TREE_AC_LEN - 1] of TCoefficients;
  HuffTreeChromaAC: array[0..HUFF_TREE_AC_LEN - 1] of TCoefficients;

begin

  InitCosTable;

  
  QT := Max(1, Min(100, Quality));
  LastY := 0;
  LastU := 0;
  LastV := 0;

  FillChar(HuffTreeLumaDC, SizeOf(HuffTreeLumaDC), #0);
  FillChar(HuffTreeChromaDC, SizeOf(HuffTreeChromaDC), #0);
  FillChar(HuffTreeLumaAC, SizeOf(HuffTreeLumaAC), #0);
  FillChar(HuffTreeChromaAC, SizeOf(HuffTreeChromaAC), #0);

  // Huffman a a lar n  olu tur
  MakeHuffmanTree(Default_HT_Luma_DC_Len, Default_HT_Luma_DC, HUFF_TREE_DC_LEN, HuffTreeLumaDC);
  MakeHuffmanTree(Default_HT_Chroma_DC_Len, Default_HT_Chroma_DC, HUFF_TREE_DC_LEN, HuffTreeChromaDC);
  MakeHuffmanTree(Default_HT_Luma_AC_Len, Default_HT_Luma_AC, HUFF_TREE_AC_LEN, HuffTreeLumaAC);
  MakeHuffmanTree(Default_HT_Chroma_AC_Len, Default_HT_Chroma_AC, HUFF_TREE_AC_LEN, HuffTreeChromaAC);

  // Kalite tablosu  ret
  MakeQTTable(QT, Default_Luma_Table, LumaTable);
  MakeQTTable(QT, Default_Chroma_Table, ChromaTable);
  W:=Width;//SCREEN_WIDTH;
  H:=Height;//  SCREEN_HEIGHT;


   JPEGWriteU16(  Swap16($FFD8));

   jfif.len := Swap16(sizeof(TJFIFHeader));
    StrCopy(@jfif.identifier, 'JFIF');
    jfif.version := Swap16($0102);
    jfif.units := $01; // 0x00-unspecified 0x01-dots_per_inch 0x02-dots_per_cm
    jfif.Hdensity := Swap16(96);
    jfif.Vdensity := Swap16(96);
    jfif.HthumbnailA := Swap16(0);
    jfif.VthumbnailA := Swap16(0);
    JPEGWriteU16(  Swap16($FFE0));
    jpegwritefile(  @jfif, sizeof(TJFIFHeader));



    JPEGWriteU16(  Swap16($FFDB));
    JPEGWriteU16(  Swap16(2+1+64));
    JPEGWriteU8(  $00); // AAAABBBB(bin), AAAA = ??(0:8?,1:16?) BBBB = ???ID(??4?)
    for i := 0 to  (DCT_SIZE * DCT_SIZE)-1 do
    begin
        qttabletmp[zigzag_table[i]] := lumatable[i];
    end;
    jpegwritefile(  @qttabletmp[0], sizeof(qttabletmp));
    // ?????
    JPEGWriteU16(  Swap16($FFDB));
    JPEGWriteU16(  Swap16(2+1+64));
    JPEGWriteU8(  $01); // AAAABBBB(bin), AAAA = ??(0:8?,1:16?) BBBB = ???ID(??4?)
    for i := 0 to  (DCT_SIZE * DCT_SIZE)-1 do
    begin
        qttabletmp[zigzag_table[i]] := chromatable[i];
    end;
    jpegwritefile(  @qttabletmp[0], sizeof(qttabletmp));

    // ???????
    JPEGWriteU16(  Swap16($FFC0));
    JPEGWriteU16(  Swap16(2+sizeof(TFrameHeader)));
    frame.precision := 8;
    frame.height := Swap16(h);
    frame.width := Swap16(w);
    frame.component_num := 3;

    frame.component[0].id := 1;
    frame.component[0].sampling_factors := $11;
    frame.component[0].qt_table_id := 0;
    // ????
    frame.component[1].id := 2;
    frame.component[1].sampling_factors := $11;
    frame.component[1].qt_table_id := 1;
    // ????
    frame.component[2].id := 3;
    frame.component[2].sampling_factors := $11;
    frame.component[2].qt_table_id := 1;
    jpegwritefile(  @frame, sizeof(TFrameHeader));

    // ?huffman?,AC?DC??ID???0????
    // ??DC?
    JPEGWriteU16(  Swap16($FFC4));
    JPEGWriteU16(  Swap16(2+1+16+sizeof(default_ht_luma_dc)));
    JPEGWriteU8(  $00); // AAAABBBB(bin), AAAA = ??(0:DC,1:AC) BBBB = ?ID
    jpegwritefile(  @default_ht_luma_dc_len[0], sizeof(default_ht_luma_dc_len));
    jpegwritefile(  @default_ht_luma_dc[0], sizeof(default_ht_luma_dc));
    // ??AC?
    JPEGWriteU16(  Swap16($FFC4));
    JPEGWriteU16(  Swap16(2+1+16+sizeof(default_ht_luma_ac)));
    JPEGWriteU8(  $10); // AAAABBBB(bin), AAAA = ??(0:DC,1:AC) BBBB = ?ID
    jpegwritefile(  @default_ht_luma_ac_len[0], sizeof(default_ht_luma_ac_len));
    jpegwritefile(  @default_ht_luma_ac[0], sizeof(default_ht_luma_ac));
    // ??DC?
    JPEGWriteU16(  Swap16($FFC4));
    JPEGWriteU16(  Swap16(2+1+16+sizeof(default_ht_chroma_dc)));
    JPEGWriteU8(  $01); // AAAABBBB(bin), AAAA = ??(0:DC,1:AC) BBBB = ?ID
    jpegwritefile(  @default_ht_chroma_dc_len[0], sizeof(default_ht_chroma_dc_len));
    jpegwritefile(  @default_ht_chroma_dc[0], sizeof(default_ht_chroma_dc));
    // ??AC?
    JPEGWriteU16(  Swap16($FFC4));
    JPEGWriteU16(  Swap16(2+1+16+sizeof(default_ht_chroma_ac)));
    JPEGWriteU8(  $11); // AAAABBBB(bin), AAAA = ??(0:DC,1:AC) BBBB = ?ID
    jpegwritefile(  @default_ht_chroma_ac_len[0], sizeof(default_ht_chroma_ac_len));
    jpegwritefile(  @default_ht_chroma_ac[0], sizeof(default_ht_chroma_ac));

    // ???????
    JPEGWriteU16(  Swap16($FFDA));
    JPEGWriteU16(  Swap16(2+1+3*2+3));
    JPEGWriteU8(  $03); // ?????? 1-??? 3-YUV 4-CMYK
    // ??????,?????????
    JPEGWriteU8(  $01); // ????ID
    JPEGWriteU8(  $00); // ?4?????huffman?ID,?4?????huffman?ID
    JPEGWriteU8(  $02); // ????ID
    JPEGWriteU8(  $11); // ?4?????huffman?ID,?4?????huffman?ID
    JPEGWriteU8(  $03); // ????ID
    JPEGWriteU8(  $11); // ?4?????huffman?ID,?4?????huffman?ID
    JPEGWriteU8(  $00);// ?????:1???,???$00
    JPEGWriteU8(  $3F);// ?????:1???,???$3F
    JPEGWriteU8(  $00);// ???:1???,???$00


     y := 0;
    while   y < h do
    begin
        x := 0;
       while   x < w do
        begin
            Readblock(PixelData, rgbblock, w, h, x, y);
            Blockrgbtoyuv444(rgbblock, yblock, ublock, vblock);



            BlockDCT(yblock, dctblock);
            blockquantization(lumatable, dctblock, qtblock);
            blockzigzag(qtblock, zigzagblock);
            blockencode(zigzagblock,lasty, hufftreelumadc, hufftreelumaac);

            BlockDCT(ublock, dctblock);
            blockquantization(chromatable, dctblock, qtblock);
            blockzigzag(qtblock, zigzagblock);
            blockencode(zigzagblock, lastu, hufftreechromadc, hufftreechromaac);


            BlockDCT(vblock, dctblock);
            blockquantization(chromatable, dctblock, qtblock);
            blockzigzag(qtblock, zigzagblock);
            blockencode(zigzagblock, lastv, hufftreechromadc, hufftreechromaac);

          Inc(x , 8);
        end;

        Inc( y , 8);
    end;

    // ????
    jpegwritebits(  0, 0, True);

    // ??????
    jpegwriteu16(  Swap16($FFD9));


    F := OpenFile(FileName,   FILE_WRITE or  FILE_CREATE);
    if F < 0 then Exit;

    WriteFile(F,jpegbuffer, buffer_pos);
    CloseFile(F);

end;







function JPEG_Encode_Stream(PixelData: PByteArray; Width, Height, Quality: Integer; out OutData:PByteArray):Integer;
var

  W, H, X, Y: Integer;
  LastY, LastU, LastV: Integer;
  QT, I: Integer;


  RGBBlock: array[0..DCT_SIZE * DCT_SIZE * 3 - 1] of Byte;

  YBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of ShortInt;
  UBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of ShortInt;
  VBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of ShortInt;

  DCTBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of Double;
  QTBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of Integer;
  ZigZagBlock: array[0..DCT_SIZE * DCT_SIZE - 1] of Integer;

  LumaTable: array[0..DCT_SIZE * DCT_SIZE - 1] of Byte;
  ChromaTable: array[0..DCT_SIZE * DCT_SIZE - 1] of Byte;
  QTTableTmp: array[0..DCT_SIZE * DCT_SIZE - 1] of Byte;

  JFIF: TJFIFHeader;
  Frame: TFrameHeader;

  HuffTreeLumaDC: array[0..HUFF_TREE_DC_LEN - 1] of TCoefficients;
  HuffTreeChromaDC: array[0..HUFF_TREE_DC_LEN - 1] of TCoefficients;
  HuffTreeLumaAC: array[0..HUFF_TREE_AC_LEN - 1] of TCoefficients;
  HuffTreeChromaAC: array[0..HUFF_TREE_AC_LEN - 1] of TCoefficients;

begin

  InitCosTable;

  
  QT := Max(1, Min(100, Quality));
  LastY := 0;
  LastU := 0;
  LastV := 0;

  FillChar(HuffTreeLumaDC, SizeOf(HuffTreeLumaDC), #0);
  FillChar(HuffTreeChromaDC, SizeOf(HuffTreeChromaDC), #0);
  FillChar(HuffTreeLumaAC, SizeOf(HuffTreeLumaAC), #0);
  FillChar(HuffTreeChromaAC, SizeOf(HuffTreeChromaAC), #0);

  // Huffman a a lar n  olu tur
  MakeHuffmanTree(Default_HT_Luma_DC_Len, Default_HT_Luma_DC, HUFF_TREE_DC_LEN, HuffTreeLumaDC);
  MakeHuffmanTree(Default_HT_Chroma_DC_Len, Default_HT_Chroma_DC, HUFF_TREE_DC_LEN, HuffTreeChromaDC);
  MakeHuffmanTree(Default_HT_Luma_AC_Len, Default_HT_Luma_AC, HUFF_TREE_AC_LEN, HuffTreeLumaAC);
  MakeHuffmanTree(Default_HT_Chroma_AC_Len, Default_HT_Chroma_AC, HUFF_TREE_AC_LEN, HuffTreeChromaAC);

  // Kalite tablosu  ret
  MakeQTTable(QT, Default_Luma_Table, LumaTable);
  MakeQTTable(QT, Default_Chroma_Table, ChromaTable);
  W:=Width;//SCREEN_WIDTH;
  H:=Height;//  SCREEN_HEIGHT;


   JPEGWriteU16(  Swap16($FFD8));

   jfif.len := Swap16(sizeof(TJFIFHeader));
    StrCopy(@jfif.identifier, 'JFIF');
    jfif.version := Swap16($0102);
    jfif.units := $01; // 0x00-unspecified 0x01-dots_per_inch 0x02-dots_per_cm
    jfif.Hdensity := Swap16(96);
    jfif.Vdensity := Swap16(96);
    jfif.HthumbnailA := Swap16(0);
    jfif.VthumbnailA := Swap16(0);
    JPEGWriteU16(  Swap16($FFE0));
    jpegwritefile(  @jfif, sizeof(TJFIFHeader));



    JPEGWriteU16(  Swap16($FFDB));
    JPEGWriteU16(  Swap16(2+1+64));
    JPEGWriteU8(  $00); // AAAABBBB(bin), AAAA = ??(0:8?,1:16?) BBBB = ???ID(??4?)
    for i := 0 to  (DCT_SIZE * DCT_SIZE)-1 do
    begin
        qttabletmp[zigzag_table[i]] := lumatable[i];
    end;
    jpegwritefile(  @qttabletmp[0], sizeof(qttabletmp));
    // ?????
    JPEGWriteU16(  Swap16($FFDB));
    JPEGWriteU16(  Swap16(2+1+64));
    JPEGWriteU8(  $01); // AAAABBBB(bin), AAAA = ??(0:8?,1:16?) BBBB = ???ID(??4?)
    for i := 0 to  (DCT_SIZE * DCT_SIZE)-1 do
    begin
        qttabletmp[zigzag_table[i]] := chromatable[i];
    end;
    jpegwritefile(  @qttabletmp[0], sizeof(qttabletmp));

    // ???????
    JPEGWriteU16(  Swap16($FFC0));
    JPEGWriteU16(  Swap16(2+sizeof(TFrameHeader)));
    frame.precision := 8;
    frame.height := Swap16(h);
    frame.width := Swap16(w);
    frame.component_num := 3;

    frame.component[0].id := 1;
    frame.component[0].sampling_factors := $11;
    frame.component[0].qt_table_id := 0;
    // ????
    frame.component[1].id := 2;
    frame.component[1].sampling_factors := $11;
    frame.component[1].qt_table_id := 1;
    // ????
    frame.component[2].id := 3;
    frame.component[2].sampling_factors := $11;
    frame.component[2].qt_table_id := 1;
    jpegwritefile(  @frame, sizeof(TFrameHeader));

    // ?huffman?,AC?DC??ID???0????
    // ??DC?
    JPEGWriteU16(  Swap16($FFC4));
    JPEGWriteU16(  Swap16(2+1+16+sizeof(default_ht_luma_dc)));
    JPEGWriteU8(  $00); // AAAABBBB(bin), AAAA = ??(0:DC,1:AC) BBBB = ?ID
    jpegwritefile(  @default_ht_luma_dc_len[0], sizeof(default_ht_luma_dc_len));
    jpegwritefile(  @default_ht_luma_dc[0], sizeof(default_ht_luma_dc));
    // ??AC?
    JPEGWriteU16(  Swap16($FFC4));
    JPEGWriteU16(  Swap16(2+1+16+sizeof(default_ht_luma_ac)));
    JPEGWriteU8(  $10); // AAAABBBB(bin), AAAA = ??(0:DC,1:AC) BBBB = ?ID
    jpegwritefile(  @default_ht_luma_ac_len[0], sizeof(default_ht_luma_ac_len));
    jpegwritefile(  @default_ht_luma_ac[0], sizeof(default_ht_luma_ac));
    // ??DC?
    JPEGWriteU16(  Swap16($FFC4));
    JPEGWriteU16(  Swap16(2+1+16+sizeof(default_ht_chroma_dc)));
    JPEGWriteU8(  $01); // AAAABBBB(bin), AAAA = ??(0:DC,1:AC) BBBB = ?ID
    jpegwritefile(  @default_ht_chroma_dc_len[0], sizeof(default_ht_chroma_dc_len));
    jpegwritefile(  @default_ht_chroma_dc[0], sizeof(default_ht_chroma_dc));
    // ??AC?
    JPEGWriteU16(  Swap16($FFC4));
    JPEGWriteU16(  Swap16(2+1+16+sizeof(default_ht_chroma_ac)));
    JPEGWriteU8(  $11); // AAAABBBB(bin), AAAA = ??(0:DC,1:AC) BBBB = ?ID
    jpegwritefile(  @default_ht_chroma_ac_len[0], sizeof(default_ht_chroma_ac_len));
    jpegwritefile(  @default_ht_chroma_ac[0], sizeof(default_ht_chroma_ac));

    // ???????
    JPEGWriteU16(  Swap16($FFDA));
    JPEGWriteU16(  Swap16(2+1+3*2+3));
    JPEGWriteU8(  $03); // ?????? 1-??? 3-YUV 4-CMYK
    // ??????,?????????
    JPEGWriteU8(  $01); // ????ID
    JPEGWriteU8(  $00); // ?4?????huffman?ID,?4?????huffman?ID
    JPEGWriteU8(  $02); // ????ID
    JPEGWriteU8(  $11); // ?4?????huffman?ID,?4?????huffman?ID
    JPEGWriteU8(  $03); // ????ID
    JPEGWriteU8(  $11); // ?4?????huffman?ID,?4?????huffman?ID
    JPEGWriteU8(  $00);// ?????:1???,???$00
    JPEGWriteU8(  $3F);// ?????:1???,???$3F
    JPEGWriteU8(  $00);// ???:1???,???$00


     y := 0;
    while   y < h do
    begin
        x := 0;
       while   x < w do
        begin
            Readblock(PixelData, rgbblock, w, h, x, y);
            Blockrgbtoyuv444(rgbblock, yblock, ublock, vblock);



            BlockDCT(yblock, dctblock);
            blockquantization(lumatable, dctblock, qtblock);
            blockzigzag(qtblock, zigzagblock);
            blockencode(zigzagblock,lasty, hufftreelumadc, hufftreelumaac);

            BlockDCT(ublock, dctblock);
            blockquantization(chromatable, dctblock, qtblock);
            blockzigzag(qtblock, zigzagblock);
            blockencode(zigzagblock, lastu, hufftreechromadc, hufftreechromaac);


            BlockDCT(vblock, dctblock);
            blockquantization(chromatable, dctblock, qtblock);
            blockzigzag(qtblock, zigzagblock);
            blockencode(zigzagblock, lastv, hufftreechromadc, hufftreechromaac);

          Inc(x , 8);
        end;

        Inc( y , 8);
    end;

    // ????
    jpegwritebits(  0, 0, True);

    // ??????
    jpegwriteu16(  Swap16($FFD9));

    OutData:=jpegbuffer;
    Result:= buffer_pos;


end;


end.

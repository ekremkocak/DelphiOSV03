unit SyscallGUI;

interface

uses
  SysUtils,IDT,PIT,Vesa,Fat32, ProcessMgr, GUI,GUIControls,Console,Messages,Math, Task,Draw32, Memory;

const
  SYS_WAIT_EVENT  = 20;
  SYS_DRAW_WINDOW = 21;
  SYS_DRAW_TEXT   = 22;
  SYS_GET_KEY     = 23;
  SYS_GET_BUTTON  = 24;





  SYS_FILL_RECT = 201;
  SYS_LINE_H    = 202;
  SYS_LINE_V    = 203;


  const
  WM_NULL        = $0000;
  WM_CREATE      = $0001;
  WM_DESTROY     = $0002;
  WM_CLOSE       = $0010;
  WM_QUIT        = $0012;
  WM_PAINT       = $000F;

  WM_MOUSEMOVE   = $0200;
  WM_LBUTTONDOWN = $0201;
  WM_LBUTTONUP   = $0202;
  WM_LBUTTONDBLCLK = $0203;

  WM_KEYDOWN     = $0100;
  WM_KEYUP       = $0101;

  WM_SIZE        = $0005;
  WM_MOVE        = $0003;

{==============================================}
{  GUI Syscall Numaralari                    }
{==============================================}

const
  SYS_NONE           = 0;
  SYS_CREATE_FORM    = 1;
  SYS_DESTROY_FORM   = 2;
  SYS_SHOW_FORM      = 3;
  SYS_HIDE_FORM      = 4;
  SYS_SET_CAPTION    = 5;
  SYS_GET_MESSAGE    = 6;
  SYS_POST_MESSAGE   = 7;
  SYS_EXIT_PROCESS   = 8;
  SYS_ALLOC          = 9;
  SYS_FREE           = 10;
  SYS_GET_PID        = 11;
  SYS_GET_CMDLINE    = 12;



  SYS_GET_YIELD    = 13;
  SYS_BEGIN_THREAD = 14;
  SYS_KILL_THREAD  = 15;
  SYS_REPAINT      = 16;
  SYS_DELAY_MS     = 17;
  SYS_GETTICKCOUNT = 18;


const
  { --- Factory: Create --- }
  SYS_GUI_CREATE_PANEL         = $100;
  SYS_GUI_CREATE_BUTTON        = $101;
  SYS_GUI_CREATE_LABEL         = $102;
  SYS_GUI_CREATE_EDIT          = $103;
  SYS_GUI_CREATE_MEMO          = $104;
  SYS_GUI_CREATE_COMBOBOX      = $105;
  SYS_GUI_CREATE_LISTBOX       = $106;
  SYS_GUI_CREATE_CHECKBOX      = $107;
  SYS_GUI_CREATE_RADIOBUTTON   = $108;
  SYS_GUI_CREATE_GROUPBOX      = $109;
  SYS_GUI_CREATE_PROGRESSBAR   = $10A;
  SYS_GUI_CREATE_TRACKBAR      = $10B;
  SYS_GUI_CREATE_IMAGE         = $10C;
  SYS_GUI_CREATE_SPLITTER      = $10D;
  SYS_GUI_CREATE_STATUSBAR     = $10E;
  SYS_GUI_CREATE_MENUITEM      = $10F;
  SYS_GUI_CREATE_MENUBAR       = $110;
  SYS_GUI_CREATE_LISTVIEW      = $111;
  SYS_GUI_CREATE_TABCONTROL    = $112;
  SYS_GUI_CREATE_TREEVIEW      = $113;
  SYS_GUI_CREATE_SPLITTERPANEL = $114;
  SYS_GUI_CREATE_TOOLBAR       = $115;
  SYS_GUI_CREATE_SCROLLBAR     = $116;

  { --- Helpers --- }
  SYS_GUI_EDIT_SETTEXT         = $120;
  SYS_GUI_EDIT_GETTEXT         = $121;
  SYS_GUI_MEMO_SETTEXT         = $122;
  SYS_GUI_COMBOBOX_ADDITEM     = $123;
  SYS_GUI_COMBOBOX_CLEAR       = $124;
  SYS_GUI_LISTBOX_ADDITEM      = $125;
  SYS_GUI_LISTBOX_CLEAR        = $126;
  SYS_GUI_STATUSBAR_SETTEXT    = $127;
  SYS_GUI_MENUITEM_ADDSUBITEM  = $128;
  SYS_GUI_MENUBAR_ADDITEM      = $129;
  SYS_GUI_LISTVIEW_ADDCOLUMN   = $12A;
  SYS_GUI_LISTVIEW_ADDITEM     = $12B;
  SYS_GUI_LISTVIEW_SETSUBITEM  = $12C;
  SYS_GUI_LISTVIEW_CLEAR       = $12D;
  SYS_GUI_LISTVIEW_SETVIEWSTYLE= $12E;
  SYS_GUI_TABCONTROL_ADDTAB    = $12F;
  SYS_GUI_TABCONTROL_SETACTIVE = $130;
  SYS_GUI_TREEVIEW_ADDNODE     = $131;
  SYS_GUI_TREEVIEW_CLEAR       = $132;
  SYS_GUI_TREEVIEW_EXPAND      = $133;
  SYS_GUI_TREEVIEW_GETSELECTEDTEXT = $134;
  SYS_GUI_TOOLBAR_ADDBUTTON    = $135;
  SYS_GUI_TOOLBAR_ADDSEPARATOR = $136;
  SYS_GUI_TOOLBAR_CLEAR        = $137;
  SYS_GUI_TOOLBAR_SETBUTTONENABLED = $138;
  SYS_GUI_SCROLLBAR_SETPOSITION= $139;

  { --- Generic Properties --- }
  SYS_GUI_SET_LEFT             = $140;
  SYS_GUI_SET_TOP              = $141;
  SYS_GUI_SET_WIDTH            = $142;
  SYS_GUI_SET_HEIGHT           = $143;
  SYS_GUI_SET_COLOR            = $144;
  SYS_GUI_SET_VISIBLE          = $145;
  SYS_GUI_SET_ENABLED          = $146;
  SYS_GUI_SET_CAPTION          = $147;
  SYS_GUI_SET_TEXT             = $148;
  SYS_GUI_GET_TEXT             = $149;
  SYS_GUI_SET_CHECKED          = $14A;
  SYS_GUI_GET_CHECKED          = $14B;
  SYS_GUI_SET_POSITION         = $14C;  { ProgressBar/TrackBar/ScrollBar }
  SYS_GUI_GET_POSITION         = $14D;
  SYS_GUI_SET_ITEMINDEX        = $14E;  { ComboBox/ListBox }
  SYS_GUI_GET_ITEMINDEX        = $14F;
  SYS_GUI_GET_ITEMCOUNT        = $150;
  SYS_GUI_DESTROY_OBJECT       = $151;
  
  SYS_DRAW_INIT                = $500;
  SYS_MAP_MEMORY               = $602;

const
  { FAT32 Dosya Sistemi Syscall Numaraları ($200 - $20F) }
  SYS_FILE_OPEN       = $200;   { OpenFile(Path, Mode) → Handle }
  SYS_FILE_CLOSE      = $201;   { CloseFile(Handle) }
  SYS_FILE_READ       = $202;   { ReadFile(Handle, Buffer, Size) → BytesRead }
  SYS_FILE_WRITE      = $203;   { WriteFile(Handle, Buffer, Size) → BytesWritten }
  SYS_FILE_SEEK       = $204;   { SeekFile(Handle, Offset, Origin) → NewPos }
  SYS_FILE_POS        = $205;   { FilePos(Handle) → Position }
  SYS_FILE_SIZE       = $206;   { FileSize(Handle) → Size }
  SYS_FILE_MKDIR      = $207;   { MakeDir(Path) → Boolean }
  SYS_FILE_DELETE     = $208;   { DeleteFile(Path) → Boolean }
  SYS_FILE_FINDFIRST  = $209;   { FindFirst(Path, Pattern, Attr, Rec) → FindHandle }
  SYS_FILE_FINDNEXT   = $20A;   { FindNext(FindHandle, Rec) → Boolean }
  SYS_FILE_FINDCLOSE  = $20B;   { FindClose(FindHandle) }
  SYS_FILE_EXISTS     = $20C;   { FileExists(Path) → Boolean }
  SYS_DRIVE_COUNT     = $20D;   { DriveCount → Integer }
  SYS_DRIVE_INFO      = $20E;   { DriveInfo(Index, out Info) }

const
  SYS_BIND_KEYDOWN    = $300;  { BindKeyDown(Handle, Proc)   }
  SYS_BIND_KEYUP      = $301;  { BindKeyUp(Handle, Proc)     }
  SYS_BIND_MOUSEDOWN  = $302;  { BindMouseDown(Handle, Proc) }
  SYS_BIND_MOUSEUP    = $303;  { BindMouseUp(Handle, Proc)   }
  SYS_BIND_MOUSEMOVE  = $304;  { BindMouseMove(Handle, Proc) }
  SYS_BIND_PAINT      = $305;  { BindPaint(Handle, Proc)     }
  SYS_BIND_DBLCLICK   = $306;  { BindDblClick(Handle, Proc)  }
  SYS_BIND_DESTROY    = $307;  { BindDestroy(Handle, Proc)   }

  { Event Unbind (temizle) }
  SYS_UNBIND_ALL      = $308;  { FreeEvents(Handle)          }


const
  { Dialog Syscall'lar� }
  SYS_SHOW_MESSAGE     = 50;
  SYS_MESSAGE_DLG      = 51;
  SYS_INPUT_BOX        = 52;
  SYS_OPEN_DLG         = 53;
  SYS_SAVE_DLG         = 54;
  SYS_GET_DLG_RESULT   = 55;
  SYS_GET_DLG_FILENAME = 56;
  SYS_DEBUG_PRINT      = 57;
  
const
{ ============================================================
  CONSOLE SYSCALLS (20-24) � eski GUI event'lerinin yerine
  ============================================================ }
  SYS_GETSTDHANDLE  = 20;
  SYS_WRITECONSOLE  = 21;
  SYS_READCONSOLE   = 22;
  SYS_PUTCHAR       = 23;
  SYS_CLEARSCREEN   = 24;
  SYS_SET_CONSOLE_ATTR = 25;

const
  SYS_DRAW32 = $400;

  { Draw32 Komut Kodlar� }
  DCMD_PUTPIXEL       = 1;
  DCMD_KLINE          = 2;
  DCMD_KLINEH         = 3;
  DCMD_KLINEV         = 4;
  DCMD_KFILL          = 5;
  DCMD_KRECT          = 6;
  DCMD_KCIRCLE        = 7;
  DCMD_KFILLCIRCLE    = 8;
  DCMD_KELLIPSE       = 9;
  DCMD_KFILLELLIPSE   = 10;
  DCMD_KARC           = 11;
  DCMD_KPIE           = 12;
  DCMD_KTRIANGLE      = 13;
  DCMD_KFILLTRIANGLE  = 14;
  DCMD_KROUNDRECT     = 15;
  DCMD_KSTR           = 16;
  DCMD_KSTRCENTERED   = 17;
  DCMD_KSTRRIGHT      = 18;
  DCMD_KCHAR          = 19;
  DCMD_KBUTTON3D      = 20;
  DCMD_KBUTTON3DEX    = 21;
  DCMD_KRECT3D        = 22;
  DCMD_KPANEL3D       = 23;
  DCMD_KSUNKEN        = 24;
  DCMD_KGRADIENTH     = 25;
  DCMD_KGRADIENTV     = 26;
  DCMD_KGRADIENTD     = 27;
  DCMD_KGRADIENTRAD   = 28;
  DCMD_KRAINBOW       = 29;
  DCMD_KFILLALPHA     = 30;
  DCMD_KBLENDPIXEL    = 31;
  DCMD_KSHADOWRECT    = 32;
  DCMD_KGLOWRECT      = 33;
  DCMD_KBITBLT        = 34;
  DCMD_KSTRETCHBLT    = 35;
  DCMD_KTRANSBLT      = 36;
  DCMD_KFLIPH         = 37;
  DCMD_KFLIPV         = 38;
  DCMD_KINVERT        = 39;
  DCMD_KGRAYSCALE     = 40;
  DCMD_KBLUR          = 41;
  DCMD_KGRANITE       = 42;
  DCMD_KMARBLE        = 43;
  DCMD_KWOOD          = 44;
  DCMD_KMETAL         = 45;
  DCMD_KCHECKER       = 46;
  DCMD_KDOTS          = 47;
  DCMD_KHATCH         = 48;
  DCMD_KCROSSHATCH    = 49;
  DCMD_KLINEDASHED    = 50;
  DCMD_KLINEALPHA     = 51;
  DCMD_KSTRSHADOW     = 52;
  DCMD_KSTROUTLINED   = 53;
  DCMD_KBEVEL         = 54;
  DCMD_KEDGE          = 55;
  DCMD_KGROOVE        = 56;
  DCMD_KTITLEBAR      = 57;
  DCMD_K3D            = 58;
  DCMD_KEMBOSS        = 59;
  DCMD_KPOLYGON       = 60;
  DCMD_KBUTTON3DDIS   = 62;
  DCMD_KSTRCLIPPED    = 63;

type
   TDraw32Cmd = packed record
    Cmd: Byte;
    Pad: Byte;
    X, Y, W, H: Integer;
    X2, Y2: Integer;
    Color, Color2: LongWord;
    Text: PChar;
    Radius: Integer;
    Alpha: Byte;
    Raised, Pressed, Hover: Byte;
    DashLen: Integer;
    StartAngle, EndAngle: Integer;
    Src: Pointer;
    SrcW, SrcH: Integer;
    TransColor: LongWord;
    TileSize, Spacing: Integer;
    Density: Integer;
    BevelW: Integer;
    EdgeType: Integer;
    ShadowSize, GlowSize: Integer;
    Passes: Integer;
    Active: Byte;
    DstW, DstH: Integer;
    Count: Integer;
    Points: PPoint;
  end;
  PDraw32Cmd = ^TDraw32Cmd;


type
  TConsoleWriteParams = packed record
    Handle: LongWord;
    Buffer: PChar;
    Count: LongWord;
  end;
  PConsoleWriteParams = ^TConsoleWriteParams;

  TConsoleReadParams = packed record
    Handle: LongWord;
    Buffer: PChar;
    Count: LongWord;
  end;
  PConsoleReadParams = ^TConsoleReadParams;


{---------------------------------------------------------------------------}
{  Dialog Syscall Parameter Types                                          }
{---------------------------------------------------------------------------}

type
  TShowMessageParams = packed record
    Msg: PChar;
  end;
  PShowMessageParams = ^TShowMessageParams;

  TMessageDlgParams = packed record
    Msg: PChar;
    DlgType: Byte;        { 0=Warning, 1=Error, 2=Information, 3=Confirmation, 4=Custom }
    Buttons: LongWord;    { Bitmask }
  end;
  PMessageDlgParams = ^TMessageDlgParams;

  TInputBoxParams = packed record
    Caption: PChar;
    Prompt: PChar;
    Default: PChar;
    ResultBuffer: PChar; { D�n�� i�in buffer }
    BufferSize: Integer;
  end;
  PInputBoxParams = ^TInputBoxParams;

  TOpenDlgParams = packed record
    Title: PChar;
    StartPath: PChar;
    ResultBuffer: PChar; { Se�ilen dosya ad� i�in buffer }
    BufferSize: Integer;
  end;
  POpenDlgParams = ^TOpenDlgParams;

  TSaveDlgParams = packed record
    Title: PChar;
    StartPath: PChar;
    ResultBuffer: PChar;
    BufferSize: Integer;
  end;
  PSaveDlgParams = ^TSaveDlgParams;

  TGetDlgResultParams = packed record
    FormHandle: LongWord;
  end;
  PGetDlgResultParams = ^TGetDlgResultParams;

  TGetDlgFileNameParams = packed record
    FormHandle: LongWord;
    Buffer: PChar;
    BufSize: Integer;
  end;
  PGetDlgFileNameParams = ^TGetDlgFileNameParams;


type
  { Tüm Bind işlemleri için tek ortak record }
  TBindEventParams = packed record
    Handle : LongWord;   { Kernel-side PObject pointer }
    Proc   : Pointer;    { EXE-side fonksiyon pointer'ı }
  end;
  PBindEventParams = ^TBindEventParams;


  TRepaintParams = packed record
    Handle : LongWord;
  end;

   TDelayParams = packed record
    MS : Integer;
  end;
  PDelayParams=^TDelayParams;


 type
  TBeginThreadParams = packed record
    Entry    : Pointer;      { Thread entry point }
    Param    : Pointer;      { Thread parametresi }
    Name     : PChar;        { Thread ad� }
    Priority : Byte;         { PRIO_* }
    Flags    : Byte;         { TF_* }
  end;
  PBeginThreadParams = ^TBeginThreadParams;


  type
  TKillThreadParams = packed record
    TID: Integer;
  end;
  PKillThreadParams = ^TKillThreadParams;


type
  { OpenFile: Path + Mode }
  TFileOpenParams = packed record
    Path : PChar;
    Mode : Byte;     { FILE_READ=$01, FILE_WRITE=$02, FILE_CREATE=$04, FILE_APPEND=$08 }
  end;
  PFileOpenParams = ^TFileOpenParams;

  { CloseFile / FilePos / FileSize : sadece handle }
  TFileHandleParams = packed record
    Handle : Integer;
  end;
  PFileHandleParams = ^TFileHandleParams;

  { ReadFile / WriteFile }
  TFileRWParams = packed record
    Handle : Integer;
    Buffer : Pointer;
    Size   : LongWord;
  end;
  PFileRWParams = ^TFileRWParams;

  { SeekFile }
  TFileSeekParams = packed record
    Handle : Integer;
    Offset : LongInt;
    Origin : Byte;   { SEEK_SET=0, SEEK_CUR=1, SEEK_END=2 }
  end;
  PFileSeekParams = ^TFileSeekParams;

  { MakeDir / DeleteFile / FileExists }
  TFilePathParams = packed record
    Path : PChar;
  end;
  PFilePathParams = ^TFilePathParams;

  { FindFirst }
  TFileFindFirstParams = packed record
    Path      : PChar;
    Pattern   : PChar;
    Attr      : Byte;
    SearchRec : PSearchRec;  { Fat32.pas'tan }
  end;
  PFileFindFirstParams = ^TFileFindFirstParams;

  { FindNext }
  TFileFindNextParams = packed record
    FindHandle : Integer;
    SearchRec  : PSearchRec;
  end;
  PFileFindNextParams = ^TFileFindNextParams;

  { DriveInfo çıktısı (user tarafına sade bilgi) }
  TDriveInfoOut = packed record
    Present   : Byte;         { Boolean: 0=yok, 1=var }
    Letter    : Char;         { 'C', 'D', ... }
    IsFAT32   : Byte;
    TotalMB   : LongWord;
  end;
  PDriveInfoOut = ^TDriveInfoOut;

  TDriveInfoParams = packed record
    DriveIndex : Integer;
    InfoOut    : PDriveInfoOut;
  end;
  PDriveInfoParams = ^TDriveInfoParams;
  
  
  {==============================================}
{  Parametre Recordlari (Kernel icin)        }
{==============================================}
type
  TCreatePanelParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreatePanelParams = ^TCreatePanelParams;

  TCreateButtonParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateButtonParams = ^TCreateButtonParams;

  TCreateLabelParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateLabelParams = ^TCreateLabelParams;

  TCreateEditParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateEditParams = ^TCreateEditParams;

  TCreateMemoParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateMemoParams = ^TCreateMemoParams;

  TCreateComboBoxParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateComboBoxParams = ^TCreateComboBoxParams;

  TCreateListBoxParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateListBoxParams = ^TCreateListBoxParams;

  TCreateCheckBoxParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateCheckBoxParams = ^TCreateCheckBoxParams;

  TCreateRadioButtonParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateRadioButtonParams = ^TCreateRadioButtonParams;

  TCreateGroupBoxParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateGroupBoxParams = ^TCreateGroupBoxParams;

  TCreateProgressBarParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateProgressBarParams = ^TCreateProgressBarParams;

  TCreateTrackBarParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateTrackBarParams = ^TCreateTrackBarParams;

  TCreateImageParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateImageParams = ^TCreateImageParams;

  TCreateSplitterParams = packed record
    Parent: LongWord;
    Left, Top: Integer;
    Size: Integer;
    Horizontal: Byte;  { 0=Vertical, 1=Horizontal }
    Align: Byte;
  end;
  PCreateSplitterParams = ^TCreateSplitterParams;

  TCreateStatusBarParams = packed record
    Parent: LongWord;
    Left, Top, Width: Integer;
    Align: Byte;
  end;
  PCreateStatusBarParams = ^TCreateStatusBarParams;

  TCreateMenuItemParams = packed record
    Caption: PChar;
  end;
  PCreateMenuItemParams = ^TCreateMenuItemParams;

  TCreateMenuBarParams = packed record
    Parent: LongWord;
    Left, Top, Width: Integer;
    Align: Byte;
  end;
  PCreateMenuBarParams = ^TCreateMenuBarParams;

  TCreateListViewParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateListViewParams = ^TCreateListViewParams;

  TCreateTabControlParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateTabControlParams = ^TCreateTabControlParams;

  TCreateTreeViewParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateTreeViewParams = ^TCreateTreeViewParams;

  TCreateSplitterPanelParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Orientation: Byte; { 0=Horizontal, 1=Vertical }
    Align: Byte;
  end;
  PCreateSplitterPanelParams = ^TCreateSplitterPanelParams;

  TCreateToolBarParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateToolBarParams = ^TCreateToolBarParams;

  TCreateScrollBarParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;
  PCreateScrollBarParams = ^TCreateScrollBarParams;

  { --- Helper Params --- }
  TGuiHandleParams = packed record
    Handle: LongWord;
  end;
  PGuiHandleParams = ^TGuiHandleParams;

  TGuiSetIntParams = packed record
    Handle: LongWord;
    Value: Integer;
  end;
  PGuiSetIntParams = ^TGuiSetIntParams;

  TGuiSetTextParams = packed record
    Handle: LongWord;
    Text: PChar;
  end;
  PGuiSetTextParams = ^TGuiSetTextParams;

  TGuiGetTextParams = packed record
    Handle: LongWord;
    Buffer: PChar;
    BufSize: Integer;
  end;
  PGuiGetTextParams = ^TGuiGetTextParams;

  TGuiSetBoolParams = packed record
    Handle: LongWord;
    Value: Byte; { Boolean }
  end;
  PGuiSetBoolParams = ^TGuiSetBoolParams;

  TGuiAddItemParams = packed record
    Handle: LongWord;
    Text: PChar;
  end;
  PGuiAddItemParams = ^TGuiAddItemParams;

  TGuiListViewColumnParams = packed record
    Handle: LongWord;
    Caption: PChar;
    Width: Integer;
  end;
  PGuiListViewColumnParams = ^TGuiListViewColumnParams;

  TGuiListViewSubItemParams = packed record
    Handle: LongWord;
    ItemIdx, SubIdx: Integer;
    Text: PChar;
  end;
  PGuiListViewSubItemParams = ^TGuiListViewSubItemParams;

  TGuiMenuItemAddParams = packed record
    Parent, Child: LongWord;
  end;
  PGuiMenuItemAddParams = ^TGuiMenuItemAddParams;

  TGuiStatusBarSetTextParams = packed record
    Handle: LongWord;
    Index: Integer;
    Text: PChar;
  end;
  PGuiStatusBarSetTextParams = ^TGuiStatusBarSetTextParams;

  TGuiTabControlAddTabParams = packed record
    Handle: LongWord;
    Caption: PChar;
  end;
  PGuiTabControlAddTabParams = ^TGuiTabControlAddTabParams;

  TGuiTreeViewAddNodeParams = packed record
    Handle: LongWord;
    ParentIndex: Integer;
    Caption: PChar;
  end;
  PGuiTreeViewAddNodeParams = ^TGuiTreeViewAddNodeParams;

  TGuiToolBarAddButtonParams = packed record
    Handle: LongWord;
    Caption: PChar;
    Width: Integer;
  end;
  PGuiToolBarAddButtonParams = ^TGuiToolBarAddButtonParams;

  TGuiToolBarSetEnabledParams = packed record
    Handle: LongWord;
    Index: Integer;
    Enabled: Byte;
  end;
  PGuiToolBarSetEnabledParams = ^TGuiToolBarSetEnabledParams;

  TGuiScrollBarSetPosParams = packed record
    Handle: LongWord;
    Position: Integer;
  end;
  PGuiScrollBarSetPosParams = ^TGuiScrollBarSetPosParams;

  TGuiEditGetTextParams = packed record
    Handle: LongWord;
    Buffer: PChar;
    BufSize: Integer;
  end;
  PGuiEditGetTextParams = ^TGuiEditGetTextParams;


  PDrawInitParams = ^TDrawInitParams;
  TDrawInitParams = packed record
    Buffer: Pointer;
    Width: Integer;
    Height: Integer;
    BitsPerPixel: Integer;
  end;


{===========================================================================}
{  Syscall Handler                                                          }
{===========================================================================}

procedure Syscall_Init;
function  SysCall_Handle(Regs: PRegisters): Integer;

var
   KernelSharedMem: array[0..$100000] of Byte;


implementation


{---------------------------------------------------------------------------}
{  SYS_SHOW_MESSAGE_HANDLER                                                }
{---------------------------------------------------------------------------}
function SYS_SHOW_MESSAGE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PShowMessageParams;
begin
  Result := 0;
  P := PShowMessageParams(Regs^.EBX);
  if (P = nil) or (P^.Msg = nil) then Exit;

  ShowMessage(P^.Msg);
  Regs^.EAX := 1;
  Result := 1;
end;

{---------------------------------------------------------------------------}
{  SYS_MESSAGE_DLG_HANDLER                                                 }
{  D�ner: EAX = Modal result (0-9)                                         }
{---------------------------------------------------------------------------}
function SYS_MESSAGE_DLG_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PMessageDlgParams;
  DlgType: TMsgDlgType;
  Buttons: TMsgDlgButtons;
  Result_Val: TModalResult;
begin
  Result := 0;
  P := PMessageDlgParams(Regs^.EBX);
  if (P = nil) or (P^.Msg = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  { Tip d�n���m� }
  case P^.DlgType of
    0: DlgType := mtWarning;
    1: DlgType := mtError;
    2: DlgType := mtInformation;
    3: DlgType := mtConfirmation;
  else
    DlgType := mtCustom;
  end;

  { Button bitmask'� set'e d�n��t�r }
  Buttons := [];
  if (P^.Buttons and $001) <> 0 then Include(Buttons, mbYes);
  if (P^.Buttons and $002) <> 0 then Include(Buttons, mbNo);
  if (P^.Buttons and $004) <> 0 then Include(Buttons, mbOK);
  if (P^.Buttons and $008) <> 0 then Include(Buttons, mbCancel);
  if (P^.Buttons and $010) <> 0 then Include(Buttons, mbAbort);
  if (P^.Buttons and $020) <> 0 then Include(Buttons, mbRetry);
  if (P^.Buttons and $040) <> 0 then Include(Buttons, mbIgnore);

  Result_Val := MessageDlg(P^.Msg, DlgType, Buttons);

  { Result'u integer'a d�n��t�r }
  Regs^.EAX := Ord(Result_Val);
  Result := Ord(Result_Val);
end;

{---------------------------------------------------------------------------}
{  SYS_INPUT_BOX_HANDLER                                                   }
{  D�ner: EAX = 1 (OK) veya 0 (Cancel), InputBox ��kt�s� buffer'a yaz�l�r }
{---------------------------------------------------------------------------}
function SYS_INPUT_BOX_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PInputBoxParams;
  Result_Str: PChar;
begin
  Result := 0;
  P := PInputBoxParams(Regs^.EBX);
  if (P = nil) or (P^.Caption = nil) or (P^.Prompt = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  Result_Str := InputBox(P^.Caption, P^.Prompt, P^.Default);

  if Result_Str <> nil then
  begin
    { Sonucu buffer'a kopyala }
    if (P^.ResultBuffer <> nil) and (P^.BufferSize > 0) then
    begin
      Move(Result_Str^, P^.ResultBuffer^, MinI(StrLen(Result_Str) + 1, P^.BufferSize));
    end;
    Regs^.EAX := 1;
    Result := 1;
  end
  else
  begin
    Regs^.EAX := 0;
    Result := 0;
  end;
end;

{---------------------------------------------------------------------------}
{  SYS_OPEN_DLG_HANDLER                                                    }
{  D�ner: EAX = Form handle veya 0 (hata)                                  }
{---------------------------------------------------------------------------}
function SYS_OPEN_DLG_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: POpenDlgParams;
  F: PForm;
begin
  Result := 0;
  P := POpenDlgParams(Regs^.EBX);
  if (P = nil) or (P^.Title = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  F := OpenDlg(P^.Title, P^.StartPath);

  if F <> nil then
  begin
    { Dosya ad�n� buffer'a kopyala }
    if (P^.ResultBuffer <> nil) and (P^.BufferSize > 0) then
    begin
      StrCopy(P^.ResultBuffer, GetDlgFileName(F));
    end;
    Regs^.EAX := LongWord(F);
    Result := LongWord(F);
  end
  else
  begin
    Regs^.EAX := 0;
    Result := 0;
  end;
end;

{---------------------------------------------------------------------------}
{  SYS_SAVE_DLG_HANDLER                                                    }
{  D�ner: EAX = 1 (OK) veya 0 (Cancel)                                     }
{---------------------------------------------------------------------------}
function SYS_SAVE_DLG_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PSaveDlgParams;
  Success: Boolean;
begin
  Result := 0;
  P := PSaveDlgParams(Regs^.EBX);
  if (P = nil) or (P^.Title = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  Success := SaveDlg(P^.Title, P^.StartPath);

  Regs^.EAX := Ord(Success);
  Result := Ord(Success);
end;

{---------------------------------------------------------------------------}
{  SYS_GET_DLG_RESULT_HANDLER                                              }
{  D�ner: EAX = Modal result kodu                                          }
{---------------------------------------------------------------------------}
function SYS_GET_DLG_RESULT_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PGetDlgResultParams;
  F: PForm;
begin
  Result := 0;
  P := PGetDlgResultParams(Regs^.EBX);
  if P = nil then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  F := PForm(P^.FormHandle);
  if F = nil then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  Regs^.EAX := GetDlgModalResult(F);
  Result := GetDlgModalResult(F);
end;

{---------------------------------------------------------------------------}
{  SYS_GET_DLG_FILENAME_HANDLER                                            }
{  D�ner: EAX = Filename uzunlu�u veya 0                                   }
{---------------------------------------------------------------------------}
function SYS_GET_DLG_FILENAME_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PGetDlgFileNameParams;
  F: PForm;
  Filename: PChar;
  Len: Integer;
begin
  Result := 0;
  P := PGetDlgFileNameParams(Regs^.EBX);
  if (P = nil) or (P^.Buffer = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  F := PForm(P^.FormHandle);
  if F = nil then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  Filename := GetDlgFileName(F);
  if Filename = nil then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  Len := StrLen(Filename);
  if Len > P^.BufSize - 1 then
    Len := P^.BufSize - 1;

  Move(Filename^, P^.Buffer^, Len);
  P^.Buffer[Len] := #0;

  Regs^.EAX := Len;
  Result := Len;
end;

{ ── Ortak güvenlik kontrolü ── }
function GetSafeObject(Handle: LongWord): PObject;
begin
  Result := nil;
  if Handle = 0 then Exit;
  Result := PObject(Handle);
  { İleride pointer doğrulama eklenebilir }
end;

{ ── KeyDown Bind ── }
function SYS_BIND_KEYDOWN_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P  : PBindEventParams;
  Obj: PObject;
begin
  Result := 0;
  P := PBindEventParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Obj := GetSafeObject(P^.Handle);
  if Obj = nil then begin Regs^.EAX := 0; Exit; end;

  Obj^.BindKeyDown(TKeyDownProc(P^.Proc));
  Regs^.EAX := 1;
  Result := 1;
end;

{ ── KeyUp Bind ── }
function SYS_BIND_KEYUP_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P  : PBindEventParams;
  Obj: PObject;
begin
  Result := 0;
  P := PBindEventParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Obj := GetSafeObject(P^.Handle);
  if Obj = nil then begin Regs^.EAX := 0; Exit; end;

  Obj^.BindKeyUp(TKeyDownProc(P^.Proc));
  Regs^.EAX := 1;
  Result := 1;
end;

{ ── MouseDown Bind ── }
function SYS_BIND_MOUSEDOWN_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P  : PBindEventParams;
  Obj: PObject;
begin
  Result := 0;
  P := PBindEventParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Obj := GetSafeObject(P^.Handle);
  if Obj = nil then begin Regs^.EAX := 0; Exit; end;

  Obj^.BindMouseDown(TMouseProc(P^.Proc));
  Regs^.EAX := 1;
  Result := 1;
end;

{ ── MouseUp Bind ── }
function SYS_BIND_MOUSEUP_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P  : PBindEventParams;
  Obj: PObject;
begin
  Result := 0;
  P := PBindEventParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Obj := GetSafeObject(P^.Handle);
  if Obj = nil then begin Regs^.EAX := 0; Exit; end;

  Obj^.BindMouseUp(TMouseProc(P^.Proc));
  Regs^.EAX := 1;
  Result := 1;
end;

{ ── MouseMove Bind ── }
function SYS_BIND_MOUSEMOVE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P  : PBindEventParams;
  Obj: PObject;
begin
  Result := 0;
  P := PBindEventParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Obj := GetSafeObject(P^.Handle);
  if Obj = nil then begin Regs^.EAX := 0; Exit; end;

  Obj^.BindMouseMove(TMouseProc(P^.Proc));
  Regs^.EAX := 1;
  Result := 1;
end;

{ ── Paint Bind ── }
function SYS_BIND_PAINT_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P  : PBindEventParams;
  Obj: PObject;
begin
  Result := 0;
  P := PBindEventParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Obj := GetSafeObject(P^.Handle);
  if Obj = nil then begin Regs^.EAX := 0; Exit; end;

  Obj^.BindPaint(TPaintProc(P^.Proc));
  Regs^.EAX := 1;
  Result := 1;
end;

{ ── DblClick Bind ── }
function SYS_BIND_DBLCLICK_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P  : PBindEventParams;
  Obj: PObject;
begin
  Result := 0;
  P := PBindEventParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Obj := GetSafeObject(P^.Handle);
  if Obj = nil then begin Regs^.EAX := 0; Exit; end;

  Obj^.BindDblClick(TMouseProc(P^.Proc));
  Regs^.EAX := 1;
  Result := 1;
end;

{ ── Destroy Bind ── }
function SYS_BIND_DESTROY_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P  : PBindEventParams;
  Obj: PObject;
begin
  Result := 0;
  P := PBindEventParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Obj := GetSafeObject(P^.Handle);
  if Obj = nil then begin Regs^.EAX := 0; Exit; end;

  Obj^.BindDestroy(TDestroyProc(P^.Proc));
  Regs^.EAX := 1;
  Result := 1;
end;

{ ── UnbindAll (tüm eventleri temizle) ── }
function SYS_UNBIND_ALL_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P  : PBindEventParams;
  Obj: PObject;
begin
  Result := 0;
  P := PBindEventParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Obj := GetSafeObject(P^.Handle);
  if Obj = nil then begin Regs^.EAX := 0; Exit; end;

  Obj^.FreeEvents;
  Regs^.EAX := 1;
  Result := 1;
end;

function SYS_FILE_OPEN_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileOpenParams;
begin
  Result := -1;
  P := PFileOpenParams(Regs^.EBX);
  if (P = nil) or (P^.Path = nil) then
  begin
    Regs^.EAX := LongWord(-1);   //
    Exit;
  end;
  Regs^.EAX := LongWord(OpenFile(P^.Path , P^.Mode));
  Result := Integer(Regs^.EAX);
end;

function SYS_FILE_CLOSE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileHandleParams;
begin
  Result := 0;
  P := PFileHandleParams(Regs^.EBX);
  if P = nil then Exit;
  CloseFile(P^.Handle);
  Regs^.EAX := 0;
end;

function SYS_FILE_READ_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileRWParams;
begin
  Result := 0;
  P := PFileRWParams(Regs^.EBX);
  if (P = nil) or (P^.Buffer = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;
  Regs^.EAX := ReadFile(P^.Handle, P^.Buffer, P^.Size);
  Result := Regs^.EAX;
end;

function SYS_FILE_WRITE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileRWParams;
begin
  Result := 0;
  P := PFileRWParams(Regs^.EBX);
  if (P = nil) or (P^.Buffer = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;
  Regs^.EAX := WriteFile(P^.Handle, P^.Buffer, P^.Size);
  Result := Regs^.EAX;
end;

function SYS_FILE_SEEK_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileSeekParams;
begin
  Result := 0;
  P := PFileSeekParams(Regs^.EBX);
  if P = nil then
  begin
    Regs^.EAX := 0;
    Exit;
  end;
  Regs^.EAX := SeekFile(P^.Handle, P^.Offset, P^.Origin);
  Result := Regs^.EAX;
end;

function SYS_FILE_POS_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileHandleParams;
begin
  Result := 0;
  P := PFileHandleParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;
  Regs^.EAX := FilePos(P^.Handle);
  Result := Regs^.EAX;
end;

function SYS_FILE_SIZE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileHandleParams;
begin
  Result := 0;
  P := PFileHandleParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;
  Regs^.EAX := FileSize(P^.Handle);
  Result := Regs^.EAX;
end;

function SYS_FILE_MKDIR_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFilePathParams;
begin
  Result := 0;
  P := PFilePathParams(Regs^.EBX);
  if (P = nil) or (P^.Path = nil) then begin Regs^.EAX := 0; Exit; end;
  Regs^.EAX := Ord(MakeDir(P^.Path));
  Result := Regs^.EAX;
end;

function SYS_FILE_DELETE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFilePathParams;
begin
  Result := 0;
  P := PFilePathParams(Regs^.EBX);
  if (P = nil) or (P^.Path = nil) then begin Regs^.EAX := 0; Exit; end;
  Regs^.EAX := Ord(DeleteFile(P^.Path));
  Result := Regs^.EAX;
end;

function SYS_FILE_FINDFIRST_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileFindFirstParams;
begin
  Result := -1;
  P := PFileFindFirstParams(Regs^.EBX);
  if (P = nil) or (P^.SearchRec = nil) then
  begin
    Regs^.EAX := LongWord(-1);
    Exit;
  end;
  Regs^.EAX := LongWord(FindFirst(P^.Path, P^.Pattern, P^.Attr, P^.SearchRec));
  Result := Integer(Regs^.EAX);
end;

function SYS_FILE_FINDNEXT_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileFindNextParams;
begin
  Result := 0;
  P := PFileFindNextParams(Regs^.EBX);
  if (P = nil) or (P^.SearchRec = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;
  Regs^.EAX := Ord(FindNext(P^.FindHandle, P^.SearchRec));
  Result := Regs^.EAX;
end;

function SYS_FILE_FINDCLOSE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PFileHandleParams;
begin
  Result := 0;
  P := PFileHandleParams(Regs^.EBX);
  if P = nil then Exit;
  FindClose(P^.Handle);
  Regs^.EAX := 0;
end;

function SYS_FILE_EXISTS_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P   : PFilePathParams;
  H   : Integer;
begin
  Result := 0;
  P := PFilePathParams(Regs^.EBX);
  if (P = nil) or (P^.Path = nil) then begin Regs^.EAX := 0; Exit; end;
  { Basit kontrol: OpenFile ile aç, varsa kapat }
  H := OpenFile(P^.Path, FILE_READ);
  if H >= 0 then
  begin
    CloseFile(H);
    Regs^.EAX := 1;
    Result := 1;
  end
  else
  begin
    Regs^.EAX := 0;
    Result := 0;
  end;
end;

function SYS_DRIVE_COUNT_HANDLER(Regs: PRegisters): Integer; stdcall;
begin
  Regs^.EAX := LongWord(DriveCount);   { Fat32.pas global değişkeni }
  Result := DriveCount;
end;

function SYS_DRIVE_INFO_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PDriveInfoParams;
  D: PDriveInfo;
begin
  Result := 0;
  P := PDriveInfoParams(Regs^.EBX);
  if (P = nil) or (P^.InfoOut = nil) then begin Regs^.EAX := 0; Exit; end;
  if (P^.DriveIndex < 0) or (P^.DriveIndex >= MAX_DRIVES) then
  begin
    Regs^.EAX := 0; Exit;
  end;
  D := @Drives[P^.DriveIndex];
  P^.InfoOut^.Present  := Ord(D^.Present);
  P^.InfoOut^.Letter   := D^.Letter;
  P^.InfoOut^.IsFAT32  := Ord(D^.IsFAT32);
  { TotalMB = TotalSectors * 512 / 1024 / 1024 }
  P^.InfoOut^.TotalMB  := (D^.BPB.TotSec32 div 2048);
  Regs^.EAX := 1;
  Result := 1;
end;


function SYS_DRAW_INIT_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PDrawInitParams;
begin
  Result := 0;
  
  { EBX = EXE taraf�ndaki record adresi }
  P := PDrawInitParams(Regs^.EBX);
  if P = nil then
  begin
    Regs^.EAX := 0;  { Ba�ar�s�z: null pointer }
    Exit;
  end;

  { Kerneldeki global video de�i�kenlerini record'a yaz }
  P^.Buffer       := @Screen_Buffer[0];      { veya LFBAddr / BackBuffer }
  P^.Width        := SCREEN_WIDTH;
  P^.Height       := SCREEN_HEIGHT;
  P^.BitsPerPixel := SCREEN_BPP;

  { Ba�ar�l� d�n�� }
  Regs^.EAX := 1;
  Result := Regs^.EAX;
end;


{==============================================}
{  Kernel Handler'lar                          }
{==============================================}
function SafeParent(ParentPtr: LongWord): PObject;
begin
  if ParentPtr = 0 then Result := nil
  else Result := PObject(ParentPtr);
end;

function SafeHandle(Handle: LongWord): PObject;
begin
  if Handle = 0 then Result := nil
  else Result := PObject(Handle);
end;

{ --- CREATE HANDLER'LAR --- }
function SYS_CREATE_PANEL_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreatePanelParams; Obj: PPanel;
begin Result:=0; P:=PCreatePanelParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreatePanel(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

{
function SYS_CREATE_BUTTON_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PCreateButtonParams;
  Parent: PObject;
  Btn: PButton;
begin
  Result := 0;
  P := PCreateButtonParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Parent := PObject(P^.Parent);
  if Parent = nil then begin Regs^.EAX := 0; Exit; end;

  Btn := GUIControls.CreateButton(Parent, P^.Caption, P^.Left, P^.Top,
                                  P^.Width, P^.Height, TAlign(P^.Align));
  if Btn <> nil then
    Regs^.EAX := LongWord(Btn)
  else
    Regs^.EAX := 0;
  Result := Regs^.EAX;
end; }


function SYS_CREATE_BUTTON_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PCreateButtonParams;
  Obj: PButton;
begin
   Result:=0;
   P:=PCreateButtonParams(Regs^.EBX);
   if P=nil then
   begin
      Regs^.EAX:=0;
      Exit;
   end;
  Obj:=GUIControls.CreateButton(SafeParent(P^.Parent),P^.Caption,P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then
     Regs^.EAX:=LongWord(Obj)
  else
     Regs^.EAX:=0;

  Result:=Regs^.EAX;
end;

function SYS_CREATE_LABEL_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateLabelParams; Obj: PLabel;
begin Result:=0; P:=PCreateLabelParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateLabel(SafeParent(P^.Parent),P^.Caption,P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_EDIT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateEditParams; Obj: PEdit;
begin Result:=0; P:=PCreateEditParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateEdit(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_MEMO_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateMemoParams; Obj: PMemo;
begin Result:=0; P:=PCreateMemoParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateMemo(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_COMBOBOX_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateComboBoxParams; Obj: PComboBox;
begin Result:=0; P:=PCreateComboBoxParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateComboBox(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_LISTBOX_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateListBoxParams; Obj: PListBox;
begin Result:=0; P:=PCreateListBoxParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateListBox(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_CHECKBOX_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateCheckBoxParams; Obj: PCheckBox;
begin Result:=0; P:=PCreateCheckBoxParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateCheckBox(SafeParent(P^.Parent),P^.Caption,P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_RADIOBUTTON_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateRadioButtonParams; Obj: PRadioButton;
begin Result:=0; P:=PCreateRadioButtonParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateRadioButton(SafeParent(P^.Parent),P^.Caption,P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_GROUPBOX_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateGroupBoxParams; Obj: PGroupBox;
begin Result:=0; P:=PCreateGroupBoxParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateGroupBox(SafeParent(P^.Parent),P^.Caption,P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_PROGRESSBAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateProgressBarParams; Obj: PProgressBar;
begin Result:=0; P:=PCreateProgressBarParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateProgressBar(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_TRACKBAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateTrackBarParams; Obj: PTrackBar;
begin Result:=0; P:=PCreateTrackBarParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateTrackBar(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_IMAGE_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateImageParams; Obj: PImage;
begin Result:=0; P:=PCreateImageParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateImage(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_SPLITTER_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateSplitterParams; Obj: PSplitter;
begin Result:=0; P:=PCreateSplitterParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateSplitter(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Size,P^.Horizontal<>0,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_STATUSBAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateStatusBarParams; Obj: PStatusBar;
begin Result:=0; P:=PCreateStatusBarParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateStatusBar(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_MENUITEM_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateMenuItemParams; Obj: PMenuItem;
begin Result:=0; P:=PCreateMenuItemParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateMenuItem(P^.Caption);
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_MENUBAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateMenuBarParams; Obj: PMenuBar;
begin Result:=0; P:=PCreateMenuBarParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateMenuBar(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_LISTVIEW_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateListViewParams; Obj: PListView;
begin Result:=0; P:=PCreateListViewParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateListView(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_TABCONTROL_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateTabControlParams; Obj: PTabControl;
begin Result:=0; P:=PCreateTabControlParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateTabControl(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_TREEVIEW_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateTreeViewParams; Obj: PTreeView;
begin Result:=0; P:=PCreateTreeViewParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateTreeView(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;



function SYS_CREATE_TOOLBAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateToolBarParams; Obj: PToolBar;
begin Result:=0; P:=PCreateToolBarParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateToolBar(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

function SYS_CREATE_SCROLLBAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PCreateScrollBarParams; Obj: PScrollBar;
begin Result:=0; P:=PCreateScrollBarParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Obj:=GUIControls.CreateScrollBar(SafeParent(P^.Parent),P^.Left,P^.Top,P^.Width,P^.Height,TAlign(P^.Align));
  if Obj<>nil then Regs^.EAX:=LongWord(Obj) else Regs^.EAX:=0; Result:=Regs^.EAX; end;

{ --- HELPER HANDLER'LAR --- }
function SYS_GUI_EDIT_SETTEXT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetTextParams;
begin Result:=0; P:=PGuiSetTextParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.EditSetText(PEdit(P^.Handle),P^.Text); end;

function SYS_GUI_EDIT_GETTEXT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiEditGetTextParams;
begin Result:=0; P:=PGuiEditGetTextParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.EditGetText(PEdit(P^.Handle),P^.Buffer^,P^.BufSize); end;

function SYS_GUI_MEMO_SETTEXT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetTextParams;
begin Result:=0; P:=PGuiSetTextParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.MemoSetText(PMemo(P^.Handle),P^.Text); end;

function SYS_GUI_COMBOBOX_ADDITEM_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiAddItemParams;
begin Result:=0; P:=PGuiAddItemParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ComboBoxAddItem(PComboBox(P^.Handle),P^.Text); end;

function SYS_GUI_COMBOBOX_CLEAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ComboBoxClear(PComboBox(P^.Handle)); end;

function SYS_GUI_LISTBOX_ADDITEM_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiAddItemParams;
begin Result:=0; P:=PGuiAddItemParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ListBoxAddItem(PListBox(P^.Handle),P^.Text); end;

function SYS_GUI_LISTBOX_CLEAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ListBoxClear(PListBox(P^.Handle)); end;

function SYS_GUI_STATUSBAR_SETTEXT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiStatusBarSetTextParams;
begin Result:=0; P:=PGuiStatusBarSetTextParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.StatusBarSetText(PStatusBar(P^.Handle),P^.Index,P^.Text); end;

function SYS_GUI_MENUITEM_ADDSUBITEM_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiMenuItemAddParams;
begin Result:=0; P:=PGuiMenuItemAddParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.MenuItemAddSubItem(PMenuItem(P^.Parent),PMenuItem(P^.Child)); end;

function SYS_GUI_MENUBAR_ADDITEM_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiMenuItemAddParams;
begin Result:=0; P:=PGuiMenuItemAddParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.MenuBarAddItem(PMenuBar(P^.Parent),PMenuItem(P^.Child)); end;

function SYS_GUI_LISTVIEW_ADDCOLUMN_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiListViewColumnParams;
begin Result:=0; P:=PGuiListViewColumnParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ListViewAddColumn(PListView(P^.Handle),P^.Caption,P^.Width); end;

function SYS_GUI_LISTVIEW_ADDITEM_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiAddItemParams;
begin Result:=0; P:=PGuiAddItemParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Regs^.EAX:=GUIControls.ListViewAddItem(PListView(P^.Handle),P^.Text); end;

function SYS_GUI_LISTVIEW_SETSUBITEM_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiListViewSubItemParams;
begin Result:=0; P:=PGuiListViewSubItemParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ListViewSetSubItem(PListView(P^.Handle),P^.ItemIdx,P^.SubIdx,P^.Text); end;

function SYS_GUI_LISTVIEW_CLEAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ListViewClear(PListView(P^.Handle)); end;

function SYS_GUI_LISTVIEW_SETVIEWSTYLE_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetIntParams;
begin Result:=0; P:=PGuiSetIntParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ListViewSetViewStyle(PListView(P^.Handle),Byte(P^.Value)); end;

function SYS_GUI_TABCONTROL_ADDTAB_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiTabControlAddTabParams; Pg: PPanel;
begin Result:=0; P:=PGuiTabControlAddTabParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Pg:=GUIControls.TabControlAddTab(PTabControl(P^.Handle),P^.Caption);
  if Pg<>nil then Regs^.EAX:=LongWord(Pg) else Regs^.EAX:=0; end;

function SYS_GUI_TABCONTROL_SETACTIVE_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetIntParams;
begin Result:=0; P:=PGuiSetIntParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.TabControlSetActive(PTabControl(P^.Handle),P^.Value); end;

function SYS_GUI_TREEVIEW_ADDNODE_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiTreeViewAddNodeParams;
begin Result:=0; P:=PGuiTreeViewAddNodeParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=-1; Exit; end;
  Regs^.EAX:=GUIControls.TreeViewAddNode(PTreeView(P^.Handle),P^.ParentIndex,P^.Caption); end;

function SYS_GUI_TREEVIEW_CLEAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.TreeViewClear(PTreeView(P^.Handle)); end;

function SYS_GUI_TREEVIEW_EXPAND_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetBoolParams;
begin Result:=0; P:=PGuiSetBoolParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.TreeViewExpand(PTreeView(P^.Handle),PGuiSetIntParams(P)^.Value,P^.Value<>0); end;

function SYS_GUI_TREEVIEW_GETSELECTEDTEXT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams; Txt: PChar;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=0; Exit; end;
  Txt:=GUIControls.TreeViewGetSelectedText(PTreeView(P^.Handle));
  Regs^.EAX:=LongWord(Txt); end;

function SYS_GUI_TOOLBAR_ADDBUTTON_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiToolBarAddButtonParams;
begin Result:=0; P:=PGuiToolBarAddButtonParams(Regs^.EBX); if P=nil then begin Regs^.EAX:=-1; Exit; end;
  Regs^.EAX:=GUIControls.ToolBarAddButton(PToolBar(P^.Handle),P^.Caption,P^.Width,nil); end;

function SYS_GUI_TOOLBAR_ADDSEPARATOR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ToolBarAddSeparator(PToolBar(P^.Handle)); end;

function SYS_GUI_TOOLBAR_CLEAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ToolBarClear(PToolBar(P^.Handle)); end;

function SYS_GUI_TOOLBAR_SETBUTTONENABLED_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiToolBarSetEnabledParams;
begin Result:=0; P:=PGuiToolBarSetEnabledParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ToolBarSetButtonEnabled(PToolBar(P^.Handle),P^.Index,P^.Enabled<>0); end;

function SYS_GUI_SCROLLBAR_SETPOSITION_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiScrollBarSetPosParams;
begin Result:=0; P:=PGuiScrollBarSetPosParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.ScrollBar_SetPosition(PScrollBar(P^.Handle),P^.Position); end;

{ --- GENERIC PROPERTY HANDLER'LAR --- }
function SYS_GUI_SET_LEFT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetIntParams; O: PObject;
begin Result:=0; P:=PGuiSetIntParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit; O^.Left:=P^.Value; RelayoutForm(FindRootForm(O)); end;

function SYS_GUI_SET_TOP_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetIntParams; O: PObject;
begin Result:=0; P:=PGuiSetIntParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit; O^.Top:=P^.Value; RelayoutForm(FindRootForm(O)); end;

function SYS_GUI_SET_WIDTH_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetIntParams; O: PObject;
begin Result:=0; P:=PGuiSetIntParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit; O^.Width:=P^.Value; RelayoutForm(FindRootForm(O)); end;

function SYS_GUI_SET_HEIGHT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetIntParams; O: PObject;
begin Result:=0; P:=PGuiSetIntParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit; O^.Height:=P^.Value; RelayoutForm(FindRootForm(O)); end;

function SYS_GUI_SET_COLOR_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetIntParams; O: PObject;
begin Result:=0; P:=PGuiSetIntParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit; O^.Color:=LongWord(P^.Value); end;

function SYS_GUI_SET_VISIBLE_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetBoolParams; O: PObject;
begin Result:=0; P:=PGuiSetBoolParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit; O^.Visible:=P^.Value<>0; end;

function SYS_GUI_SET_ENABLED_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetBoolParams; O: PObject;
begin Result:=0; P:=PGuiSetBoolParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit; O^.Enabled:=P^.Value<>0; end;

function SYS_GUI_SET_CAPTION_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetTextParams; O: PObject; L: Integer;
begin Result:=0; P:=PGuiSetTextParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit; if P^.Text=nil then Exit;
  L:=StrLen(P^.Text); if L>127 then L:=127; Move(P^.Text^,O^.Caption[0],L); O^.Caption[L]:=#0; end;

function SYS_GUI_SET_TEXT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetTextParams;
begin Result:=0; P:=PGuiSetTextParams(Regs^.EBX); if P=nil then Exit;
  GUIControls.EditSetText(PEdit(P^.Handle),P^.Text); end;

function SYS_GUI_GET_TEXT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiGetTextParams; Src: PChar; Len: Integer;
begin Result:=0; P:=PGuiGetTextParams(Regs^.EBX); if P=nil then Exit;
  Src:=PEdit(P^.Handle)^.Text; if Src=nil then begin Regs^.EAX:=0; Exit; end;
  Len:=StrLen(Src); if Len>=P^.BufSize then Len:=P^.BufSize-1;
  Move(Src^,P^.Buffer^,Len); P^.Buffer[Len]:=#0; Regs^.EAX:=Len; end;

function SYS_GUI_SET_CHECKED_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetBoolParams; O: PObject;
begin Result:=0; P:=PGuiSetBoolParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit;
  if O^.Tag=2 then PRadioButton(O)^.Checked:=P^.Value<>0
  else PCheckBox(O)^.Checked:=P^.Value<>0; end;

function SYS_GUI_GET_CHECKED_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams; O: PObject;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then begin Regs^.EAX:=0; Exit; end;
  if O^.Tag=2 then Regs^.EAX:=Ord(PRadioButton(O)^.Checked)
  else Regs^.EAX:=Ord(PCheckBox(O)^.Checked); end;

function SYS_GUI_SET_POSITION_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetIntParams; O: PObject;
begin Result:=0; P:=PGuiSetIntParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit;
  if O^.ClassType=nil then begin {tip kontrolu yoksa direkt atama}
    PProgressBar(O)^.Position:=P^.Value;
  end else begin
    {VMT yoksa basit tip alan uzakligi ile tahmin edilebilir, ama burada
     ProgressBar, TrackBar, ScrollBar hepsinde Position ayni yerde degil.
     Guvenli yol: her tip icin ayri syscall kullanmak. Alternatif: Handle'in
     ilk 4 byte'ina tip imzasi koymak. Basit tutalim: ProgressBar varsayimi}
    PProgressBar(O)^.Position:=P^.Value;
  end; end;

function SYS_GUI_GET_POSITION_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams; O: PObject;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then begin Regs^.EAX:=0; Exit; end;
  Regs^.EAX:=PProgressBar(O)^.Position; end;

function SYS_GUI_SET_ITEMINDEX_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiSetIntParams; O: PObject;
begin Result:=0; P:=PGuiSetIntParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit;
  if PComboBox(O)^.ItemCount>0 then PComboBox(O)^.ItemIndex:=P^.Value
  else PListBox(O)^.ItemIndex:=P^.Value; end;

function SYS_GUI_GET_ITEMINDEX_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams; O: PObject;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then begin Regs^.EAX:=-1; Exit; end;
  if PComboBox(O)^.ItemCount>0 then Regs^.EAX:=PComboBox(O)^.ItemIndex
  else Regs^.EAX:=PListBox(O)^.ItemIndex; end;

function SYS_GUI_GET_ITEMCOUNT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams; O: PObject;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then begin Regs^.EAX:=0; Exit; end;
  if PComboBox(O)^.ItemCount>0 then Regs^.EAX:=PComboBox(O)^.ItemCount
  else Regs^.EAX:=PListBox(O)^.ItemCount; end;

function SYS_GUI_DESTROY_OBJECT_HANDLER(Regs: PRegisters): Integer; stdcall;
var P: PGuiHandleParams; O: PObject;
begin Result:=0; P:=PGuiHandleParams(Regs^.EBX); if P=nil then Exit; O:=SafeHandle(P^.Handle);
  if O=nil then Exit;

 // if O^.Parent<>nil then O^.Parent^.RemoveObject(O); {eger varsa}
 // FreeObject(O);
end;



{


function SYS_CREATE_PANEL_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PCreatePanelParams;
  Parent: PObject;
  Pnl: PPanel;
begin
  Result := 0;
  P := PCreatePanelParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Parent := PObject(P^.Parent);
  if Parent = nil then begin Regs^.EAX := 0; Exit; end;

  Pnl := GUIControls.CreatePanel(Parent, P^.Left, P^.Top,
                                 P^.Width, P^.Height, TAlign(P^.Align));
  if Pnl <> nil then
    Regs^.EAX := LongWord(Pnl)
  else
    Regs^.EAX := 0;
  Result := Regs^.EAX;
end;

function SYS_CREATE_LABEL_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PCreateLabelParams;
  Parent: PObject;
  Lbl: PLabel;
begin
  Result := 0;
  P := PCreateLabelParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Parent := PObject(P^.Parent);
  if Parent = nil then begin Regs^.EAX := 0; Exit; end;

  Lbl := GUIControls.CreateLabel(Parent, P^.Caption, P^.Left, P^.Top,
                                 P^.Width, P^.Height, TAlign(P^.Align));
  if Lbl <> nil then
    Regs^.EAX := LongWord(Lbl)
  else
    Regs^.EAX := 0;
  Result := Regs^.EAX;
end;

function SYS_CREATE_EDIT_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PCreateEditParams;
  Parent: PObject;
  Ed: PEdit;
begin
  Result := 0;
  P := PCreateEditParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  Parent := PObject(P^.Parent);
  if Parent = nil then begin Regs^.EAX := 0; Exit; end;

  Ed := GUIControls.CreateEdit(Parent, P^.Left, P^.Top,
                               P^.Width, P^.Height, TAlign(P^.Align));
  if Ed <> nil then
    Regs^.EAX := LongWord(Ed)
  else
    Regs^.EAX := 0;
  Result := Regs^.EAX;
end;


  }



function SYS_GETMESSAGE1(Regs: PRegisters): Integer; stdcall;
var
  Proc  : PProcess;
  MsgPtr: PMessage;
begin
  Result := 0;
  Proc   := ProcessGetCurrent;
  if Proc = nil then begin Regs^.EAX := 0; Exit; end;

  MsgPtr := PMessage(Regs^.EBX);
  if MsgPtr = nil then begin Regs^.EAX := 0; Exit; end;

  repeat
    // 1. �nce normal mesajlar� t�ket
    if PeekMessage(Proc, MsgPtr^) then
    begin
      Regs^.EAX := 1;
      Result := 1;
      Exit;
    end;

    // 2. Kuyruk bo� + dirty flag varsa � WM_PAINT �ret
    if Proc^.IsDirty then
    begin
      MsgPtr^.hWnd   := Proc^.DirtyForm;
      MsgPtr^.Msg    := WM_PAINT;
      MsgPtr^.WParam := 0;
      MsgPtr^.LParam := 0;      // 0 = t�m form
      Proc^.IsDirty  := False;  // Temizle
      Regs^.EAX := 1;
      Result := 1;
      Exit;
    end;

    // 3. Ger�ekten bo� � yield
    Thread_Yield;

  until False;
end;



function SYS_GETMESSAGE(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
  MsgPtr: PMessage;
begin
  Result := 0;
  Proc := ProcessGetCurrent;
  if Proc = nil then
  begin
    Regs^.EAX := 0;
    Exit;
  end;




  MsgPtr := PMessage(Regs^.EBX);
  if (MsgPtr = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  // Block until a message is available for this process.
  // We use PeekMessage to try to fetch the message; if none we idle
  // the CPU until next interrupt (timer) so scheduler can run.
  while not PeekMessage(Proc, MsgPtr^) do
  begin
    // enable interrupts & hlt so CPU waits for an interrupt (timer),
    // other tasks can run. This is safe in kernel context.
   Thread_Yield;
  end;

  // message copied into user buffer by PeekMessage
  Regs^.EAX := 1;
  Result := 1; 
end;
{---------------------------------------------------------------------------}
{  SYS_CREATEWINDOW_HANDLER — DÜZELTİLMİŞ                                  }
{  Process bağlantısı kuruluyor!                                            }
{---------------------------------------------------------------------------}




function SYS_CREATEWINDOW_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc     : PProcess;
  Form     : PForm;
 
begin
  Result := 0;

  // 1. Mevcut process'i bul (kim çağırdı?)
  Proc := ProcessGetCurrent;
  if Proc = nil then
  begin
    // Kernel task veya bilinmeyen task
    Regs^.EAX := 0;
    Exit;
  end;

  // 2. Process zaten bir MainForm'a sahip mi?
  // (Opsiyonel: her process tek pencere)
  if Proc^.MainForm <> nil then
  begin
    // Zaten form var, mevcut handle'ı döndür
    Regs^.EAX := LongWord(Proc^.MainForm);
    Exit;
  end;

  // 3. Parametreleri oku
  // EBX = WndProc, ECX = X, EDX = Y, ESI = W, EDI = H, [ESP+4] = Title


  // 4. Kernel-side form oluştur
  // Not: Form_Create, GUI unit'inizdeki fonksiyon
  Form := CreateForm(@Proc^.Name[0], Regs^.EBX, Regs^.ECX, Regs^.EDX, Regs^.ESI,bsWindow);
  if Form = nil then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  // 5. KRİTİK: Form ↔ Process bağlantısı
  Proc^.MainForm := Form;           // Process → Form
  Form^.OwnerProcess := LongWord(Proc); // Form → Process (ters bağlantı)

 

  // 6. Form handle'ını döndür (user-mode bu adresi kullanır)
  Regs^.EAX := LongWord(Form);
  Result := Regs^.EAX;
end;

{---------------------------------------------------------------------------}
{  SYS_DESTROYWINDOW_HANDLER                                               }
{---------------------------------------------------------------------------}
function SYS_DESTROYWINDOW_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
  Form: PForm;
begin
  Result := 0;

  Form := PForm(Regs^.EBX);
  if Form = nil then Exit;

  // Form'un sahibi kim?
  Proc := PProcess(Form^.OwnerProcess);
  if Proc = nil then
  begin
    // Sahipsiz form, sadece serbest bırak
    // Form_Free(Form);
    Exit;
  end;

  // Sadece kendi formunu kapatabilir (güvenlik)
  if ProcessGetCurrent <> Proc then Exit;



  ProcessKillByHWND(Form);
  // Form'u serbest bırak
  // Form_Free(Form);
  Proc^.MainForm := nil;
  Form^.Tag      := 0;
end;

{---------------------------------------------------------------------------}
{  SYS_EXIT_PROCESS                                                        }
{---------------------------------------------------------------------------}
function SYS_EXIT_PROCESS_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
begin
  Result := 0;
  Proc := ProcessGetCurrent;
  if Proc <> nil then
    ProcessKill(Proc);
end;

{---------------------------------------------------------------------------}
{  SYS_ALLOC / SYS_FREE                                                    }
{---------------------------------------------------------------------------}
function SYS_ALLOC_HANDLER(Regs: PRegisters): Integer; stdcall;
begin
  Regs^.EAX := LongWord(HeapAlloc(Regs^.EBX));
  Result := Regs^.EAX;
end;

function SYS_FREE_HANDLER(Regs: PRegisters): Integer; stdcall;
begin
  HeapFree(Pointer(Regs^.EBX));
  Result := 0;
end;

{---------------------------------------------------------------------------}
{  SYS_GET_PID                                                             }
{---------------------------------------------------------------------------}
function SYS_GET_PID_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
begin
  Proc := ProcessGetCurrent;
  if Proc <> nil then
    Regs^.EAX := Proc^.PID
  else
    Regs^.EAX := 0;
  Result := Regs^.EAX;
end;

{---------------------------------------------------------------------------}
{  SYS_GET_CMDLINE                                                         }
{---------------------------------------------------------------------------}
function SYS_GET_CMDLINE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
  Buf: PChar;
  MaxLen: Integer;
  i: Integer;
begin
  Result := 0;
  Proc := ProcessGetCurrent;
  if Proc = nil then Exit;

  Buf := PChar(Regs^.EBX);
  MaxLen := Integer(Regs^.ECX);
  if (Buf = nil) or (MaxLen <= 0) then Exit;

  i := 0;
  while (Proc^.CmdLine[i] <> #0) and (i < MaxLen - 1) do
  begin
    Buf[i] := Proc^.CmdLine[i];
    Inc(i);
  end;
  Buf[i] := #0;
end;

function SYS_SHOW_FORM_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Form: PForm;
begin
  Form := PForm(Regs^.EBX);
  if Form <> nil then
  begin
    Form^.Visible := True;
    { �sterseniz z-index / focus g�ncellemesi de yap�n }
  end;
  Regs^.EAX := 0;
  Result := 0;
end;

function SYS_HIDE_FORM_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Form: PForm;
begin
  Form := PForm(Regs^.EBX);
  if Form <> nil then Form^.Visible := False;
  Regs^.EAX := 0;
  Result := 0;
end;

function SYS_SET_CAPTION_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Form: PForm;
  Cap: PChar;
begin
  Form := PForm(Regs^.EBX);
  Cap  := PChar(Regs^.ECX);
  if (Form <> nil) and (Cap <> nil) then
  begin
    StrCopy(@Form^.Caption[0], Cap);  { ve mevcut string kopyalama rutininiz }
  end;
  Regs^.EAX := 0;
  Result := 0;
end;

function SYS_POST_MESSAGE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
begin
  Result := 0;
  Proc := ProcessGetCurrent;
  if Proc = nil then Exit;
  
  PostMessage(
    Proc,
    Regs^.EBX,   { hWnd }
    Regs^.ECX,   { Msg }
    Regs^.EDX,   { WParam }
    Regs^.ESI    { LParam }
  );
  Regs^.EAX := 1;
  Result := 1;
end;


function SYS_GET_YIELD_HANDLER(Regs: PRegisters): Integer; stdcall;
begin
  Thread_Yield; // if available in your Task unit
  Regs^.EAX := 0;
  Result := 0;
end;


function SYS_BEGIN_THREAD_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PBeginThreadParams;
  TID: Integer;
begin
  Result := -1;
  P := PBeginThreadParams(Regs^.EBX);
  if (P = nil) or (P^.Entry = nil) then
  begin
    Regs^.EAX := LongWord(-1);
    Exit;
  end;

  { Task.pas'tan BeginThread �a��r }
  TID := BeginThread(P^.Entry, P^.Param, P^.Name, P^.Priority, P^.Flags);

  Regs^.EAX := TID;
  Result := TID;
end;

function SYS_KILL_THREAD_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PKillThreadParams;
begin
  Result := 0;
  P := PKillThreadParams(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  { Task.pas'tan Thread_Kill �a��r }
  Thread_Kill(P^.TID);

  Regs^.EAX := 1;
  Result := 1;
end;

function SYS_REPAINT_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: TRepaintParams;
  F: PForm;
begin
  Result := 0;
  Move(PByte(Regs^.EBX)^, P, SizeOf(P));
  if P.Handle = 0 then Exit;

  F := PForm(P.Handle);
  { RelayoutForm zaten mevcut — formu tamamen yeniden çizer }
  RelayoutForm(F);
  Regs^.EAX := 1;
  Result := 1;
end;

function SYS_DELAY_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PDelayParams;
begin
  Result := 0;
  P := PDelayParams(Regs^.EBX);
  if P = nil then Exit;
  Thread_Sleep(P^.MS);   { Pit.pas veya Task.pas'taki Delay }
  Regs^.EAX := 1;
  Result := 1;
end;


function SYS_GETTICKCOUNT_HANDLER(Regs: PRegisters): Integer; stdcall;
begin
  Regs^.EAX := Integer(GetTickCount);
  Result := Regs^.EAX;
end;




{-----------------------------------------------------------------------------}
{  CONSOLE HANDLER'LARI                                                       }
{  Not: PProcess record'unuza Console: PConsole alani ekleyin                }
{-----------------------------------------------------------------------------}

function SYS_GETSTDHANDLE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
begin
  Result := 0;
  Proc := ProcessGetCurrent;
  if (Proc = nil) or (Proc^.Console = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;
  { PConsole pointer'inin kendisini Handle olarak d�nd�r.
    EXE taraf� bunu tekrar syscall'lara paslayacak. }
  Regs^.EAX := LongWord(Proc^.Console);
  Result := Regs^.EAX;
end;

function SYS_WRITECONSOLE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PConsoleWriteParams;
  C: PConsole;
  Proc: PProcess;
begin
  Result := 0;
  P := PConsoleWriteParams(Regs^.EBX);
  if (P = nil) or (P^.Buffer = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  { Handle = PConsole pointer'� (kernel taraf�ndan d�nd�r�len) }
  C := PConsole(P^.Handle);

  { G�VENL�K: Bu console ger�ekten bu process'e mi ait? }
  Proc := ProcessGetCurrent;
  if (Proc = nil) or (Proc^.Console <> C) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  ConsoleWriteBuf(C, P^.Buffer, P^.Count);
  Regs^.EAX := P^.Count;
  Result := P^.Count;
end;

function SYS_SET_CONSOLE_ATTR_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
  C: PConsole;
begin
  Result := 0;
  Proc := ProcessGetCurrent;
  if (Proc = nil) or (Proc^.Console = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;
  C := Proc^.Console;
  { Windows uyumlu: d���k 4 bit = metin, �st 4 bit = arka plan }
  C^.TextColor := Byte(Regs^.EBX and $0F);
  C^.BackColor := Byte((Regs^.EBX shr 4) and $0F);
  Regs^.EAX := 1;
  Result := 1;
end;

function SYS_PUTCHAR_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
begin
  Result := 0;
  Proc := ProcessGetCurrent;
  if (Proc = nil) or (Proc^.Console = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;
  ConsolePutChar(Proc^.Console, Char(Regs^.EBX and $FF));
  Regs^.EAX := 1;
end;

function SYS_CLEARSCREEN_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  Proc: PProcess;
begin
  Result := 0;
  Proc := ProcessGetCurrent;
  if (Proc = nil) or (Proc^.Console = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;
  ConsoleClear(Proc^.Console);
  Regs^.EAX := 1;
end;






function SYS_READCONSOLE_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PConsoleReadParams;
  Proc: PProcess;
  C: PConsole;
  i: Integer;
begin
  Result := 0;
  P := PConsoleReadParams(Regs^.EBX);
  if (P = nil) or (P^.Buffer = nil) or (P^.Count = 0) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  { G�venlik: Bu process'in console'u mu? }
  Proc := ProcessGetCurrent;
  if (Proc = nil) or (Proc^.Console = nil) then
  begin
    Regs^.EAX := 0;
    Exit;
  end;
  C := Proc^.Console;

  { >>> KR�T�K: Enter bas�lmad�ysa 0 d�nd�r (bo�) <<< }
  if not C^.LineReady then
  begin
    Regs^.EAX := 0;
    Exit;
  end;

  { Enter bas�ld�, sat�r� kopyala }
  i := 0;
  while (i < Integer(P^.Count) - 1) and (i < C^.LineLen) do
  begin
    P^.Buffer[i] := C^.LineBuf[i];
    Inc(i);
  end;
  P^.Buffer[i] := #0;   // Null-terminate g�venli�i

  { Buffer'� s�f�rla, yeni sat�r bekle }
  C^.LineLen := 0;
  C^.LineReady := False;

  Regs^.EAX := i;
  Result := i;
end;


function SYS_DRAW32_HANDLER(Regs: PRegisters): Integer; stdcall;
var
  P: PDraw32Cmd;
begin
  Result := 0;
  P := PDraw32Cmd(Regs^.EBX);
  if P = nil then begin Regs^.EAX := 0; Exit; end;

  case P^.Cmd of
    DCMD_PUTPIXEL:       PutPixel(P^.X, P^.Y, P^.Color);
    DCMD_KLINE:          KLine(P^.X, P^.Y, P^.X2, P^.Y2, P^.Color);
    DCMD_KLINEH:         KLineH(P^.X, P^.Y, P^.W, P^.Color);
    DCMD_KLINEV:         KLineV(P^.X, P^.Y, P^.H, P^.Color);
    DCMD_KFILL:          KFill(P^.X, P^.Y, P^.W, P^.H, P^.Color);
    DCMD_KRECT:          KRect(P^.X, P^.Y, P^.W, P^.H, P^.Color);
    DCMD_KCIRCLE:        KCircle(P^.X, P^.Y, P^.Radius, P^.Color);
    DCMD_KFILLCIRCLE:    KFillCircle(P^.X, P^.Y, P^.Radius, P^.Color);
    DCMD_KELLIPSE:       KEllipse(P^.X, P^.Y, P^.W, P^.H, P^.Color);
    DCMD_KFILLELLIPSE:   KFillEllipse(P^.X, P^.Y, P^.W, P^.H, P^.Color);
    DCMD_KARC:           KArc(P^.X, P^.Y, P^.Radius, P^.StartAngle, P^.EndAngle, P^.Color);
    DCMD_KPIE:           KPie(P^.X, P^.Y, P^.Radius, P^.StartAngle, P^.EndAngle, P^.Color);
    DCMD_KTRIANGLE:      KTriangle(P^.X, P^.Y, P^.X2, P^.Y2, P^.W, P^.H, P^.Color);
    DCMD_KFILLTRIANGLE:  KFillTriangle(P^.X, P^.Y, P^.X2, P^.Y2, P^.W, P^.H, P^.Color);
    DCMD_KROUNDRECT:     KRoundRect(P^.X, P^.Y, P^.W, P^.H, P^.Radius, P^.Color, P^.Color2);
    DCMD_KSTR:           KStr(P^.X, P^.Y, P^.Text, P^.Color);
    DCMD_KSTRCENTERED:   KStrCentered(P^.X, P^.Y, P^.W, P^.Text, P^.Color);
    DCMD_KSTRRIGHT:      KStrRight(P^.X, P^.Y, P^.W, P^.Text, P^.Color);
    DCMD_KCHAR:          KChar(P^.X, P^.Y, Char(P^.W and $FF), P^.Color);
    DCMD_KBUTTON3D:      KButton3D(P^.X, P^.Y, P^.W, P^.H, P^.Pressed <> 0, P^.Color);
    DCMD_KBUTTON3DEX:    KButton3DEx(P^.X, P^.Y, P^.W, P^.H, P^.Pressed <> 0, P^.Hover <> 0, P^.Color);
    DCMD_KRECT3D:        KRect3D(P^.X, P^.Y, P^.W, P^.H, P^.Raised <> 0);
    DCMD_KPANEL3D:       KPanel3D(P^.X, P^.Y, P^.W, P^.H, P^.Raised <> 0, P^.Color);
    DCMD_KSUNKEN:        KSunken(P^.X, P^.Y, P^.W, P^.H, P^.Color);
    DCMD_KGRADIENTH:     KGradientH(P^.X, P^.Y, P^.W, P^.H, P^.Color, P^.Color2);
    DCMD_KGRADIENTV:     KGradientV(P^.X, P^.Y, P^.W, P^.H, P^.Color, P^.Color2);
    DCMD_KGRADIENTD:     KGradientD(P^.X, P^.Y, P^.W, P^.H, P^.Color, P^.Color2);
    DCMD_KGRADIENTRAD:   KGradientRadial(P^.X, P^.Y, P^.Radius, P^.Color, P^.Color2);
    DCMD_KRAINBOW:       KRainbow(P^.X, P^.Y, P^.W, P^.H);
    DCMD_KFILLALPHA:     KFillAlpha(P^.X, P^.Y, P^.W, P^.H, P^.Color, P^.Alpha);
    DCMD_KBLENDPIXEL:    KBlendPixel(P^.X, P^.Y, P^.Color, P^.Alpha);
    DCMD_KSHADOWRECT:    KShadowRect(P^.X, P^.Y, P^.W, P^.H, P^.ShadowSize, P^.Color);
    DCMD_KGLOWRECT:      KGlowRect(P^.X, P^.Y, P^.W, P^.H, P^.GlowSize, P^.Color);
    DCMD_KBITBLT:        KBitBlt(P^.X, P^.Y, P^.W, P^.H, P^.Src, P^.SrcW, P^.X2, P^.Y2);
    DCMD_KSTRETCHBLT:    KStretchBlt(P^.X, P^.Y, P^.DstW, P^.DstH, P^.Src, P^.SrcW, P^.SrcH);
    DCMD_KTRANSBLT:      KTransBlt(P^.X, P^.Y, P^.W, P^.H, P^.Src, P^.SrcW, P^.X2, P^.Y2, P^.TransColor);
    DCMD_KFLIPH:         KFlipH(P^.X, P^.Y, P^.W, P^.H);
    DCMD_KFLIPV:         KFlipV(P^.X, P^.Y, P^.W, P^.H);
    DCMD_KINVERT:        KInvert(P^.X, P^.Y, P^.W, P^.H);
    DCMD_KGRAYSCALE:     KGrayscale(P^.X, P^.Y, P^.W, P^.H);
    DCMD_KBLUR:          KBlurRect(P^.X, P^.Y, P^.W, P^.H, P^.Passes);
    DCMD_KGRANITE:       KGranite(P^.X, P^.Y, P^.W, P^.H, P^.Color, P^.Density);
    DCMD_KMARBLE:        KMarble(P^.X, P^.Y, P^.W, P^.H, P^.Color, P^.Color2);
    DCMD_KWOOD:          KWood(P^.X, P^.Y, P^.W, P^.H, P^.Color, P^.Color2);
    DCMD_KMETAL:         KMetal(P^.X, P^.Y, P^.W, P^.H, P^.Color);
    DCMD_KCHECKER:       KChecker(P^.X, P^.Y, P^.W, P^.H, P^.TileSize, P^.Color, P^.Color2);
    DCMD_KDOTS:          KDots(P^.X, P^.Y, P^.W, P^.H, P^.Spacing, P^.Color);
    DCMD_KHATCH:         KHatch(P^.X, P^.Y, P^.W, P^.H, P^.Spacing, P^.Color);
    DCMD_KCROSSHATCH:    KCrossHatch(P^.X, P^.Y, P^.W, P^.H, P^.Spacing, P^.Color);
    DCMD_KLINEDASHED:    KLineDashed(P^.X, P^.Y, P^.X2, P^.Y2, P^.Color, P^.DashLen);
    DCMD_KLINEALPHA:     KLineAlpha(P^.X, P^.Y, P^.X2, P^.Y2, P^.Color, P^.Alpha);
    DCMD_KSTRSHADOW:     KStrShadow(P^.X, P^.Y, P^.Text, P^.Color, P^.Color2);
    DCMD_KSTROUTLINED:   KStrOutlined(P^.X, P^.Y, P^.Text, P^.Color, P^.Color2);
    DCMD_KBEVEL:         KBevel(P^.X, P^.Y, P^.W, P^.H, P^.BevelW, P^.Raised <> 0);
    DCMD_KEDGE:          KEdge(P^.X, P^.Y, P^.W, P^.H, P^.EdgeType);
    DCMD_KGROOVE:        KGroove(P^.X, P^.Y, P^.W, P^.H);
    DCMD_KTITLEBAR:      KTitleBar(P^.X, P^.Y, P^.W, P^.H, P^.Active <> 0, P^.Text);
    DCMD_K3D:            K3D(P^.X, P^.Y, P^.W, P^.H, P^.Pressed <> 0);
    DCMD_KEMBOSS:        KEmboss(P^.X, P^.Y, P^.W, P^.H);
    DCMD_KPOLYGON:       KPolygon(P^.Points, P^.Count, P^.Color);
    DCMD_KBUTTON3DDIS:   KButton3DDisabled(P^.X, P^.Y, P^.W, P^.H, P^.Color);
  else
    begin Regs^.EAX := 0; Exit; end;
  end;

  Regs^.EAX := 1;
  Result := 1;
end;


function SYS_MAP_MEMORY_HANDLER(Regs: PRegisters): Integer; stdcall;
begin
  { Kernel dizisinin ba�lang�� adresini EXE'ye d�nd�r }
  Regs^.EAX := LongWord(@KernelSharedMem[0]);
  Result := Regs^.EAX;
end;

{===========================================================================}
{  ANA SYSCALL HANDLER                                                     }
{===========================================================================}
function SysCall_Handle(Regs: PRegisters): Integer;
begin
  Result := 0;
  if Regs = nil then Exit;

  case Regs^.EAX of
    SYS_NONE:           Result := 0;
    SYS_CREATE_FORM:    Result := SYS_CREATEWINDOW_HANDLER(Regs);
    SYS_DESTROY_FORM:   Result := SYS_DESTROYWINDOW_HANDLER(Regs);
    SYS_SHOW_FORM:      Result := SYS_SHOW_FORM_HANDLER(Regs);      { YENI }
    SYS_HIDE_FORM:      Result := SYS_HIDE_FORM_HANDLER(Regs);      { YENI }
    SYS_SET_CAPTION:    Result := SYS_SET_CAPTION_HANDLER(Regs);    { YENI }
    SYS_GET_MESSAGE:    Result := SYS_GETMESSAGE(Regs);              { <-- BURASI EKSIKTI }
    SYS_POST_MESSAGE:   Result := SYS_POST_MESSAGE_HANDLER(Regs);    { YENI }
    SYS_EXIT_PROCESS:   Result := SYS_EXIT_PROCESS_HANDLER(Regs);
    SYS_ALLOC:          Result := SYS_ALLOC_HANDLER(Regs);
    SYS_FREE:           Result := SYS_FREE_HANDLER(Regs);
    SYS_GET_PID:        Result := SYS_GET_PID_HANDLER(Regs);
    SYS_GET_CMDLINE:    Result := SYS_GET_CMDLINE_HANDLER(Regs);
    SYS_GET_YIELD:      Result := SYS_GET_YIELD_HANDLER(Regs);
    SYS_BEGIN_THREAD:   Result := SYS_BEGIN_THREAD_HANDLER(Regs);
    SYS_KILL_THREAD:    Result := SYS_KILL_THREAD_HANDLER(Regs);
    SYS_REPAINT:        Result := SYS_REPAINT_HANDLER(Regs);
    SYS_DELAY_MS:       Result := SYS_DELAY_HANDLER(Regs);
    SYS_GETTICKCOUNT:   Result := SYS_GETTICKCOUNT_HANDLER(Regs);

    200: KFill(Regs^.EBX, Regs^.ECX, 50, 50, Regs^.EDX);
        { �izim primitive'leri }
    201: begin  { SYS_FILL_RECT }
           KFill(Regs^.EBX, Regs^.ECX, Regs^.EDX, Regs^.ESI, Regs^.EDI);
           Regs^.EAX := 1;
         end;
    202: begin  { SYS_LINE_H }
           KLineH(Regs^.EBX, Regs^.ECX, Regs^.EDX, Regs^.ESI);
           Regs^.EAX := 1;
         end;
    203: begin  { SYS_LINE_V }
           KLineV(Regs^.EBX, Regs^.ECX, Regs^.EDX, Regs^.ESI);
           Regs^.EAX := 1;
         end;

    $1000: WinManager.ProcessMessages();



    SYS_GUI_CREATE_BUTTON:  Result := SYS_CREATE_BUTTON_HANDLER(Regs);
    SYS_GUI_CREATE_PANEL:   Result := SYS_CREATE_PANEL_HANDLER(Regs);
    SYS_GUI_CREATE_LABEL:   Result := SYS_CREATE_LABEL_HANDLER(Regs);
    SYS_GUI_CREATE_EDIT:    Result := SYS_CREATE_EDIT_HANDLER(Regs);
    SYS_GUI_EDIT_SETTEXT:   Result := SYS_GUI_EDIT_SETTEXT_HANDLER(Regs);
    SYS_DRAW_INIT       :   Result := SYS_DRAW_INIT_HANDLER(Regs);
    
    SYS_FILE_OPEN      : Result := SYS_FILE_OPEN_HANDLER(Regs);
    SYS_FILE_CLOSE     : Result := SYS_FILE_CLOSE_HANDLER(Regs);
    SYS_FILE_READ      : Result := SYS_FILE_READ_HANDLER(Regs);
    SYS_FILE_WRITE     : Result := SYS_FILE_WRITE_HANDLER(Regs);
    SYS_FILE_SEEK      : Result := SYS_FILE_SEEK_HANDLER(Regs);
    SYS_FILE_POS       : Result := SYS_FILE_POS_HANDLER(Regs);
    SYS_FILE_SIZE      : Result := SYS_FILE_SIZE_HANDLER(Regs);
    SYS_FILE_MKDIR     : Result := SYS_FILE_MKDIR_HANDLER(Regs);
    SYS_FILE_DELETE    : Result := SYS_FILE_DELETE_HANDLER(Regs);
    SYS_FILE_FINDFIRST : Result := SYS_FILE_FINDFIRST_HANDLER(Regs);
    SYS_FILE_FINDNEXT  : Result := SYS_FILE_FINDNEXT_HANDLER(Regs);
    SYS_FILE_FINDCLOSE : Result := SYS_FILE_FINDCLOSE_HANDLER(Regs);
    SYS_FILE_EXISTS    : Result := SYS_FILE_EXISTS_HANDLER(Regs);
    SYS_DRIVE_COUNT    : Result := SYS_DRIVE_COUNT_HANDLER(Regs);
    SYS_DRIVE_INFO     : Result := SYS_DRIVE_INFO_HANDLER(Regs);

    SYS_BIND_KEYDOWN   : Result := SYS_BIND_KEYDOWN_HANDLER(Regs);
    SYS_BIND_KEYUP     : Result := SYS_BIND_KEYUP_HANDLER(Regs);
    SYS_BIND_MOUSEDOWN : Result := SYS_BIND_MOUSEDOWN_HANDLER(Regs);
    SYS_BIND_MOUSEUP   : Result := SYS_BIND_MOUSEUP_HANDLER(Regs);
    SYS_BIND_MOUSEMOVE : Result := SYS_BIND_MOUSEMOVE_HANDLER(Regs);
    SYS_BIND_PAINT     : Result := SYS_BIND_PAINT_HANDLER(Regs);
    SYS_BIND_DBLCLICK  : Result := SYS_BIND_DBLCLICK_HANDLER(Regs);
    SYS_BIND_DESTROY   : Result := SYS_BIND_DESTROY_HANDLER(Regs);
    SYS_UNBIND_ALL     : Result := SYS_UNBIND_ALL_HANDLER(Regs);

    SYS_SHOW_MESSAGE:     Result := SYS_SHOW_MESSAGE_HANDLER(Regs);
    SYS_MESSAGE_DLG:      Result := SYS_MESSAGE_DLG_HANDLER(Regs);
    SYS_INPUT_BOX:        Result := SYS_INPUT_BOX_HANDLER(Regs);
    SYS_OPEN_DLG:         Result := SYS_OPEN_DLG_HANDLER(Regs);
    SYS_SAVE_DLG:         Result := SYS_SAVE_DLG_HANDLER(Regs);
    SYS_GET_DLG_RESULT:   Result := SYS_GET_DLG_RESULT_HANDLER(Regs);
    SYS_GET_DLG_FILENAME: Result := SYS_GET_DLG_FILENAME_HANDLER(Regs);
    SYS_DEBUG_PRINT      : DebugPrint(Pchar(Regs^.EBX));

    SYS_GETSTDHANDLE:  Result := SYS_GETSTDHANDLE_HANDLER(Regs);
    SYS_WRITECONSOLE:  Result := SYS_WRITECONSOLE_HANDLER(Regs);
    SYS_READCONSOLE:   Result := SYS_READCONSOLE_HANDLER(Regs);
    SYS_PUTCHAR:       Result := SYS_PUTCHAR_HANDLER(Regs);
    SYS_CLEARSCREEN:   Result := SYS_CLEARSCREEN_HANDLER(Regs);
    SYS_SET_CONSOLE_ATTR: Result := SYS_SET_CONSOLE_ATTR_HANDLER(Regs);

    SYS_DRAW32: Result := SYS_DRAW32_HANDLER(Regs);
    SYS_MAP_MEMORY: Result := SYS_MAP_MEMORY_HANDLER(Regs);
  else
    Regs^.EAX := 0;
  end;
end;
{===========================================================================}
{  INIT                                                                     }
{===========================================================================}
procedure Syscall_Init;
begin
   RegisterISR($80, @SysCall_Handle);
end;

end.

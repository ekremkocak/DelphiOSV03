{===============================================================================
  JPEGDecoder.pas
  -------------------------------------------------------------------------------
  Minimal JPEG Baseline Decoder - Kernel / Delphi 7 (D�zeltilmi� S�r�m)

  Destek:
    - Baseline JPEG (SOF0)
    - 8-bit
    - Grayscale + YCbCr
    - 4:4:4, 4:2:2, 4:2:0 (H/V factor ? 2)
    - Birden fazla DQT / DHT
    - Restart marker
    - JFIF APP0 / APPn / COM atlama

  ��kt�: 24-bit BGR (B,G,R,B,G,R,...)
===============================================================================}

unit JPEGDecoder;

interface

uses
  SysUtils, Fat32, Memory;

type
  TQuantTable = array[0..63] of Word;

  PHuffTable = ^THuffTable;
  THuffTable = record
    Bits   : array[0..15] of Byte;
    HuffVal: array[0..255] of Byte;
    MinCode: array[0..15] of Integer;
    MaxCode: array[0..15] of Integer;
    ValPtr : array[0..15] of Integer;
    NumValues: Integer;
    Valid  : Boolean;
  end;

  TComponent = record
    CompID    : Byte;
    HFactor   : Byte;
    VFactor   : Byte;
    QTableIdx : Byte;
    DCTableIdx: Byte;
    ACTableIdx: Byte;
  end;

  PJPEGDecoder = ^TJPEGDecoder;
  TJPEGDecoder = record
    FileData      : Pointer;
    FileSize      : Integer;
    FilePos       : Integer;

    Width         : Integer;
    Height        : Integer;
    Precision     : Byte;
    NumComponents : Integer;
    Components    : array[0..3] of TComponent;

    QuantTables   : array[0..3] of TQuantTable;
    QuantValid    : array[0..3] of Boolean;

    DCHuffTables  : array[0..3] of THuffTable;
    ACHuffTables  : array[0..3] of THuffTable;

    BitBuffer     : LongWord;
    BitCount      : Integer;
    LastDCValue   : array[0..3] of Integer;

    HMax, VMax    : Integer;
    MCUWidth      : Integer;
    MCUHeight     : Integer;

    RestartInterval: Integer;
    RestartCount   : Integer;

    Error         : Boolean;

    PixelData     : Pointer;
    PixelDataSize : Integer;
  end;

function JPEG_LoadFromFile(FileName: PChar; var Width, Height: Integer): Pointer;
procedure JPEG_Free(Decoder: PJPEGDecoder);

implementation

const
  JPEG_SOI   = $FFD8;
  JPEG_EOI   = $FFD9;
  JPEG_SOF0  = $FFC0;
  JPEG_DHT   = $FFC4;
  JPEG_DQT   = $FFDB;
  JPEG_DRI   = $FFDD;
  JPEG_SOS   = $FFDA;
  JPEG_RST0  = $FFD0;
  JPEG_RST7  = $FFD7;
  JPEG_APP0  = $FFE0;
  JPEG_APP15 = $FFEF;
  JPEG_COM   = $FFFE;

  ZigZag: array[0..63] of Byte = (
     0,  1,  8, 16,  9,  2,  3, 10,
    17, 24, 32, 25, 18, 11,  4,  5,
    12, 19, 26, 33, 40, 48, 41, 34,
    27, 20, 13,  6,  7, 14, 21, 28,
    35, 42, 49, 56, 57, 50, 43, 36,
    29, 22, 15, 23, 30, 37, 44, 51,
    58, 59, 52, 45, 38, 31, 39, 46,
    53, 60, 61, 54, 47, 55, 62, 63
  );

  { 2048 * cos((2x+1)*u*pi/16) * sqrt(2) }
  IDCT_C: array[0..7, 0..7] of Integer = (
    (1448, 1448, 1448, 1448, 1448, 1448, 1448, 1448),
    (2008, 1702, 1137,  399, -399,-1137,-1702,-2008),
    (1892,  783, -783,-1892,-1892, -783,  783, 1892),
    (1702, -399,-2008,-1137, 1137, 2008,  399,-1702),
    (1448,-1448,-1448, 1448, 1448,-1448,-1448, 1448),
    (1137,-2008,  399, 1702,-1702, -399, 2008,-1137),
    ( 783,-1892, 1892, -783, -783, 1892,-1892,  783),
    ( 399,-1137, 1702,-2008, 2008,-1702, 1137, -399)
  );

type
  TBlock = array[0..63] of LongInt;

  TComponentPlane = record
    Width, Height: Integer;
    Data: array[0..255] of Byte;   // max 16x16
  end;

//=============================================================================
// Yard�mc�lar
//=============================================================================

function InByte(P: Pointer; Offset: Integer): Byte;
begin
  Result := PByte(LongWord(P) + LongWord(Offset))^;
end;

function InWord(P: Pointer; Offset: Integer): Word;
begin
  Result := (Word(InByte(P, Offset)) shl 8) or Word(InByte(P, Offset + 1));
end;

{ Delphi "shr" i�aret korumaz � arithmetic right shift }
function SarInt(Value, Shift: Integer): Integer;
begin
  if Value >= 0 then
    Result := Value shr Shift
  else
    Result := not ((not Value) shr Shift);
end;

function ClampByte(Value: Integer): Byte;
begin
  if Value < 0 then Result := 0
  else if Value > 255 then Result := 255
  else Result := Byte(Value);
end;

//=============================================================================
// Bit ak���
//=============================================================================

procedure ResetBitStream(Decoder: PJPEGDecoder);
begin
  Decoder^.BitBuffer := 0;
  Decoder^.BitCount  := 0;
end;

function ReadEntropyByte(Decoder: PJPEGDecoder; var B: Byte): Boolean;
var
  NextB: Byte;
begin
  Result := False;
  if Decoder^.FilePos >= Decoder^.FileSize then
  begin
    Decoder^.Error := True;
    Exit;
  end;

  B := InByte(Decoder^.FileData, Decoder^.FilePos);
  Inc(Decoder^.FilePos);

  if B <> $FF then
  begin
    Result := True;
    Exit;
  end;

  if Decoder^.FilePos >= Decoder^.FileSize then
  begin
    Decoder^.Error := True;
    Exit;
  end;

  NextB := InByte(Decoder^.FileData, Decoder^.FilePos);
  if NextB = $00 then
  begin
    Inc(Decoder^.FilePos);          // FF 00 � FF
    B := $FF;
    Result := True;
  end
  else
  begin
    Dec(Decoder^.FilePos);          // marker, geri koy
    Decoder^.Error := True;
  end;
end;

procedure FillBits(Decoder: PJPEGDecoder; Needed: Integer);
var
  B: Byte;
begin
  if Decoder^.Error then Exit;
  while Decoder^.BitCount < Needed do
  begin
    if not ReadEntropyByte(Decoder, B) then Exit;
    Decoder^.BitBuffer := (Decoder^.BitBuffer shl 8) or LongWord(B);
    Inc(Decoder^.BitCount, 8);
  end;
end;

function GetBits(Decoder: PJPEGDecoder; NumBits: Integer): Integer;
var
  Mask: LongWord;
begin
  Result := 0;
  if (Decoder^.Error) or (NumBits <= 0) then Exit;
  if NumBits > 16 then begin Decoder^.Error := True; Exit; end;

  FillBits(Decoder, NumBits);
  if Decoder^.Error or (Decoder^.BitCount < NumBits) then
  begin
    Decoder^.Error := True;
    Exit;
  end;

  Mask := (LongWord(1) shl NumBits) - 1;
  Result := Integer((Decoder^.BitBuffer shr (Decoder^.BitCount - NumBits)) and Mask);
  Dec(Decoder^.BitCount, NumBits);
end;

function GetBit(Decoder: PJPEGDecoder): Integer;
begin
  Result := GetBits(Decoder, 1);
end;

function Extend(Value, NumBits: Integer): Integer;
var
  Vt: Integer;
begin
  if NumBits <= 0 then begin Result := 0; Exit; end;
  Vt := 1 shl (NumBits - 1);
  if Value < Vt then
    Result := Value - ((1 shl NumBits) - 1)
  else
    Result := Value;
end;

//=============================================================================
// Huffman
//=============================================================================

procedure ClearHuffTable(var Table: THuffTable);
var
  i: Integer;
begin
  for i := 0 to 15 do
  begin
    Table.Bits[i]    := 0;
    Table.MinCode[i] := -1;
    Table.MaxCode[i] := -1;
    Table.ValPtr[i]  := 0;
  end;
  for i := 0 to 255 do Table.HuffVal[i] := 0;
  Table.NumValues := 0;
  Table.Valid := False;
end;

procedure BuildHuffTable(var Table: THuffTable);
var
  i, Code, NumSymbols: Integer;
begin
  Code := 0;
  NumSymbols := 0;
  for i := 0 to 15 do
  begin
    Table.ValPtr[i] := NumSymbols;
    if Table.Bits[i] = 0 then
    begin
      Table.MinCode[i] := -1;
      Table.MaxCode[i] := -1;
    end
    else
    begin
      Table.MinCode[i] := Code;
      Table.MaxCode[i] := Code + Table.Bits[i] - 1;
      Inc(NumSymbols, Table.Bits[i]);
      Code := Code + Table.Bits[i];
    end;
    Code := Code shl 1;
  end;
  Table.NumValues := NumSymbols;
  Table.Valid := NumSymbols > 0;
end;

function HuffDecode(Decoder: PJPEGDecoder; Table: PHuffTable): Integer;
var
  Code, i, Idx, Bit: Integer;
begin
  Result := -1;
  if Decoder^.Error or (Table = nil) or (not Table^.Valid) then
  begin
    Decoder^.Error := True;
    Exit;
  end;

  Code := 0;
  for i := 0 to 15 do
  begin
    Bit := GetBit(Decoder);
    if Decoder^.Error then Exit;
    Code := (Code shl 1) or Bit;

    if (Table^.MinCode[i] >= 0) and
       (Code >= Table^.MinCode[i]) and
       (Code <= Table^.MaxCode[i]) then
    begin
      Idx := Table^.ValPtr[i] + (Code - Table^.MinCode[i]);
      if (Idx < 0) or (Idx >= Table^.NumValues) then
      begin
        Decoder^.Error := True;
        Exit;
      end;
      Result := Table^.HuffVal[Idx];
      Exit;
    end;
  end;
  Decoder^.Error := True;
end;

//=============================================================================
// IDCT
//=============================================================================

procedure IDCTBlock(var Block: TBlock);
var
  x, y, u, Sum: Integer;
  Tmp: array[0..63] of Integer;
begin
  // Sat�rlar
  for y := 0 to 7 do
    for x := 0 to 7 do
    begin
      Sum := 0;
      for u := 0 to 7 do
        Inc(Sum, Integer(Block[y*8 + u]) * IDCT_C[u][x]);
      Tmp[y*8 + x] := SarInt(Sum + 2048, 12);
    end;

  // S�tunlar + level shift
  for y := 0 to 7 do
    for x := 0 to 7 do
    begin
      Sum := 0;
      for u := 0 to 7 do
        Inc(Sum, Tmp[u*8 + x] * IDCT_C[u][y]);
      Sum := SarInt(Sum + 2048, 12) + 128;
      if Sum < 0 then Sum := 0
      else if Sum > 255 then Sum := 255;
      Block[y*8 + x] := Sum;
    end;
end;

//=============================================================================
// Renk d�n���m� (JFIF full-range)
//=============================================================================

procedure YCbCrToRGB(Y, Cb, Cr: Byte; var R, G, B: Byte);
var
  Cbv, Crv, Rv, Gv, Bv: Integer;
begin
  Cbv := Integer(Cb) - 128;
  Crv := Integer(Cr) - 128;

  Rv := Integer(Y) + SarInt(359 * Crv, 8);
  Gv := Integer(Y) - SarInt(88 * Cbv + 183 * Crv, 8);
  Bv := Integer(Y) + SarInt(454 * Cbv, 8);

  R := ClampByte(Rv);
  G := ClampByte(Gv);
  B := ClampByte(Bv);
end;

//=============================================================================
// Marker okuma
//=============================================================================

function ReadByte(Decoder: PJPEGDecoder; var B: Byte): Boolean;
begin
  Result := False;
  if (Decoder = nil) or (Decoder^.FilePos >= Decoder^.FileSize) then
  begin
    Decoder^.Error := True;
    Exit;
  end;
  B := InByte(Decoder^.FileData, Decoder^.FilePos);
  Inc(Decoder^.FilePos);
  Result := True;
end;

function ReadWordBE(Decoder: PJPEGDecoder; var W: Word): Boolean;
begin
  Result := False;
  if Decoder^.FilePos + 1 >= Decoder^.FileSize then
  begin
    Decoder^.Error := True;
    Exit;
  end;
  W := InWord(Decoder^.FileData, Decoder^.FilePos);
  Inc(Decoder^.FilePos, 2);
  Result := True;
end;

function SkipBytes(Decoder: PJPEGDecoder; Count: Integer): Boolean;
begin
  Result := False;
  if (Count < 0) or (Decoder^.FilePos + Count > Decoder^.FileSize) then
  begin
    Decoder^.Error := True;
    Exit;
  end;
  Inc(Decoder^.FilePos, Count);
  Result := True;
end;

function ReadMarker(Decoder: PJPEGDecoder; var Marker: Word): Boolean;
var
  B: Byte;
begin
  Result := False;
  while Decoder^.FilePos < Decoder^.FileSize do
  begin
    B := InByte(Decoder^.FileData, Decoder^.FilePos);
    Inc(Decoder^.FilePos);
    if B <> $FF then Continue;

    while Decoder^.FilePos < Decoder^.FileSize do
    begin
      B := InByte(Decoder^.FileData, Decoder^.FilePos);
      Inc(Decoder^.FilePos);
      if B = $FF then Continue;
      if B = 0 then Break;               // stuffed
      Marker := $FF00 or B;
      Result := True;
      Exit;
    end;
  end;
  Decoder^.Error := True;
end;

function SkipVariableMarker(Decoder: PJPEGDecoder): Boolean;
var
  Len: Word;
begin
  Result := False;
  if not ReadWordBE(Decoder, Len) then Exit;
  if Len < 2 then begin Decoder^.Error := True; Exit; end;
  Result := SkipBytes(Decoder, Integer(Len) - 2);
end;

//=============================================================================
// DQT / DHT / SOF0 / DRI / SOS
//=============================================================================

function ParseDQT(Decoder: PJPEGDecoder): Boolean;
var
  SegLen: Word;
  Remaining, Precision, TableIdx, i: Integer;
  Info: Byte;
  V: Word;
begin
  Result := False;
  if not ReadWordBE(Decoder, SegLen) then Exit;
  if SegLen < 2 then begin Decoder^.Error := True; Exit; end;

  Remaining := SegLen - 2;
  while Remaining > 0 do
  begin
    if not ReadByte(Decoder, Info) then Exit;
    Dec(Remaining);

    Precision := (Info shr 4) and $0F;
    TableIdx  := Info and $0F;
    if TableIdx > 3 then begin Decoder^.Error := True; Exit; end;

    if Precision = 0 then
    begin
      if Remaining < 64 then begin Decoder^.Error := True; Exit; end;
      for i := 0 to 63 do
      begin
        if not ReadByte(Decoder, Info) then Exit;
        Decoder^.QuantTables[TableIdx][i] := Info;
      end;
      Dec(Remaining, 64);
    end
    else if Precision = 1 then
    begin
      if Remaining < 128 then begin Decoder^.Error := True; Exit; end;
      for i := 0 to 63 do
      begin
        if not ReadWordBE(Decoder, V) then Exit;
        Decoder^.QuantTables[TableIdx][i] := V;
      end;
      Dec(Remaining, 128);
    end
    else begin Decoder^.Error := True; Exit; end;

    Decoder^.QuantValid[TableIdx] := True;
  end;
  Result := not Decoder^.Error;
end;

function ParseOneDHT(Decoder: PJPEGDecoder; var Remaining: Integer): Boolean;
var
  Info: Byte;
  TableClass, TableIdx, i, CodeCount: Integer;
  Table: PHuffTable;
begin
  Result := False;
  if Remaining < 17 then begin Decoder^.Error := True; Exit; end;

  if not ReadByte(Decoder, Info) then Exit;
  Dec(Remaining);

  TableClass := (Info shr 4) and $0F;
  TableIdx   := Info and $0F;
  if TableIdx > 3 then begin Decoder^.Error := True; Exit; end;

  if TableClass = 0 then Table := @Decoder^.DCHuffTables[TableIdx]
  else if TableClass = 1 then Table := @Decoder^.ACHuffTables[TableIdx]
  else begin Decoder^.Error := True; Exit; end;

  ClearHuffTable(Table^);

  CodeCount := 0;
  for i := 0 to 15 do
  begin
    if Remaining <= 0 then begin Decoder^.Error := True; Exit; end;
    if not ReadByte(Decoder, Table^.Bits[i]) then Exit;
    Inc(CodeCount, Table^.Bits[i]);
    Dec(Remaining);
  end;

  if (CodeCount > 256) or (Remaining < CodeCount) then
  begin
    Decoder^.Error := True;
    Exit;
  end;

  for i := 0 to CodeCount - 1 do
    if not ReadByte(Decoder, Table^.HuffVal[i]) then Exit;

  Dec(Remaining, CodeCount);
  BuildHuffTable(Table^);
  Result := not Decoder^.Error;
end;

function ParseDHT(Decoder: PJPEGDecoder): Boolean;
var
  SegLen: Word;
  Remaining: Integer;
begin
  Result := False;
  if not ReadWordBE(Decoder, SegLen) then Exit;
  if SegLen < 2 then begin Decoder^.Error := True; Exit; end;

  Remaining := SegLen - 2;
  while Remaining > 0 do
    if not ParseOneDHT(Decoder, Remaining) then Exit;

  Result := not Decoder^.Error;
end;

function ParseSOF0(Decoder: PJPEGDecoder): Boolean;
var
  SegLen: Word;
  Prec, CompCount, B, HFactor, VFactor, QIdx: Byte;
  i: Integer;
  H, W: Word;
begin
  Result := False;
  if not ReadWordBE(Decoder, SegLen) then Exit;
  if SegLen < 8 then begin Decoder^.Error := True; Exit; end;

  if not ReadByte(Decoder, Prec) then Exit;
  if Prec <> 8 then begin Decoder^.Error := True; Exit; end;

  if not ReadWordBE(Decoder, H) then Exit;
  if not ReadWordBE(Decoder, W) then Exit;
  if not ReadByte(Decoder, CompCount) then Exit;

  if (CompCount = 0) or (CompCount > 3) then begin Decoder^.Error := True; Exit; end;

  Decoder^.Precision     := Prec;
  Decoder^.Height        := H;
  Decoder^.Width         := W;
  Decoder^.NumComponents := CompCount;

  if SegLen <> Word(8 + 3 * CompCount) then begin Decoder^.Error := True; Exit; end;

  for i := 0 to CompCount - 1 do
  begin
    if not ReadByte(Decoder, Decoder^.Components[i].CompID) then Exit;
    if not ReadByte(Decoder, B) then Exit;
    HFactor := (B shr 4) and $0F;
    VFactor := B and $0F;
    if (HFactor = 0) or (HFactor > 2) or (VFactor = 0) or (VFactor > 2) then
    begin
      Decoder^.Error := True;
      Exit;
    end;
    if not ReadByte(Decoder, QIdx) then Exit;
    if QIdx > 3 then begin Decoder^.Error := True; Exit; end;

    Decoder^.Components[i].HFactor    := HFactor;
    Decoder^.Components[i].VFactor    := VFactor;
    Decoder^.Components[i].QTableIdx  := QIdx;
    Decoder^.Components[i].DCTableIdx := 0;
    Decoder^.Components[i].ACTableIdx := 0;
  end;

  Decoder^.HMax := 1;
  Decoder^.VMax := 1;
  for i := 0 to CompCount - 1 do
  begin
    if Decoder^.Components[i].HFactor > Decoder^.HMax then
      Decoder^.HMax := Decoder^.Components[i].HFactor;
    if Decoder^.Components[i].VFactor > Decoder^.VMax then
      Decoder^.VMax := Decoder^.Components[i].VFactor;
  end;

  Decoder^.MCUWidth  := Decoder^.HMax * 8;
  Decoder^.MCUHeight := Decoder^.VMax * 8;
  Result := True;
end;

function ParseDRI(Decoder: PJPEGDecoder): Boolean;
var
  SegLen, Interval: Word;
begin
  Result := False;
  if not ReadWordBE(Decoder, SegLen) then Exit;
  if SegLen <> 4 then begin Decoder^.Error := True; Exit; end;
  if not ReadWordBE(Decoder, Interval) then Exit;
  Decoder^.RestartInterval := Interval;
  Decoder^.RestartCount    := 0;
  Result := True;
end;

function ParseSOS(Decoder: PJPEGDecoder): Boolean;
var
  SegLen: Word;
  CompCount, CompID, Selector: Byte;
  i, j: Integer;
  Found: Boolean;
begin
  Result := False;
  if not ReadWordBE(Decoder, SegLen) then Exit;
  if SegLen < 6 then begin Decoder^.Error := True; Exit; end;

  if not ReadByte(Decoder, CompCount) then Exit;
  if (CompCount = 0) or (CompCount > Decoder^.NumComponents) then
  begin
    Decoder^.Error := True;
    Exit;
  end;

  for i := 0 to Integer(CompCount) - 1 do
  begin
    if not ReadByte(Decoder, CompID) then Exit;
    if not ReadByte(Decoder, Selector) then Exit;

    Found := False;
    for j := 0 to Decoder^.NumComponents - 1 do
      if Decoder^.Components[j].CompID = CompID then
      begin
        Decoder^.Components[j].DCTableIdx := (Selector shr 4) and $0F;
        Decoder^.Components[j].ACTableIdx := Selector and $0F;
        if (Decoder^.Components[j].DCTableIdx > 3) or
           (Decoder^.Components[j].ACTableIdx > 3) then
        begin
          Decoder^.Error := True;
          Exit;
        end;
        Found := True;
        Break;
      end;
    if not Found then begin Decoder^.Error := True; Exit; end;
  end;

  // Ss, Se, AhAl atla (baseline = 0,63,0)
  if not SkipBytes(Decoder, 3) then Exit;

  ResetBitStream(Decoder);
  for i := 0 to 3 do Decoder^.LastDCValue[i] := 0;
  Result := True;
end;

//=============================================================================
// Blok decode
//=============================================================================

function DecodeBlock(Decoder: PJPEGDecoder; CompIdx: Integer; var Block: TBlock): Boolean;
var
  i, k, S, RS, Run, Size, Value, DC, QIdx: Integer;
  DCTable, ACTable: PHuffTable;
begin
  Result := False;
  if Decoder^.Error then Exit;

  for i := 0 to 63 do Block[i] := 0;

  DCTable := @Decoder^.DCHuffTables[Decoder^.Components[CompIdx].DCTableIdx];
  ACTable := @Decoder^.ACHuffTables[Decoder^.Components[CompIdx].ACTableIdx];
  QIdx    := Decoder^.Components[CompIdx].QTableIdx;

  if not Decoder^.QuantValid[QIdx] then begin Decoder^.Error := True; Exit; end;

  // DC
  S := HuffDecode(Decoder, DCTable);
  if Decoder^.Error or (S < 0) or (S > 11) then begin Decoder^.Error := True; Exit; end;

  if S = 0 then DC := 0
  else
  begin
    Value := GetBits(Decoder, S);
    if Decoder^.Error then Exit;
    DC := Extend(Value, S);
  end;

  Inc(Decoder^.LastDCValue[CompIdx], DC);
  Block[0] := Decoder^.LastDCValue[CompIdx] * Integer(Decoder^.QuantTables[QIdx][0]);

  // AC
  k := 1;
  while k < 64 do
  begin
    RS := HuffDecode(Decoder, ACTable);
    if Decoder^.Error or (RS < 0) then begin Decoder^.Error := True; Exit; end;

    if RS = 0 then Break;                     // EOB

    Run  := (RS shr 4) and $0F;
    Size := RS and $0F;

    if (Run = 15) and (Size = 0) then          // ZRL
    begin
      Inc(k, 16);
      if k > 64 then begin Decoder^.Error := True; Exit; end;
      Continue;
    end;

    if Size = 0 then begin Decoder^.Error := True; Exit; end;

    Inc(k, Run);
    if k >= 64 then begin Decoder^.Error := True; Exit; end;

    Value := GetBits(Decoder, Size);
    if Decoder^.Error then Exit;
    Value := Extend(Value, Size);

    Block[ZigZag[k]] := Value * Integer(Decoder^.QuantTables[QIdx][k]);
    Inc(k);
  end;

  IDCTBlock(Block);
  Result := not Decoder^.Error;
end;

//=============================================================================
// MCU
//=============================================================================

procedure CopyBlockToPlane(var Plane: TComponentPlane; var Block: TBlock;
  BlockX, BlockY: Integer);
var
  x, y, px, py, idx: Integer;
begin
  for y := 0 to 7 do
  begin
    py := BlockY + y;
    if (py < 0) or (py >= Plane.Height) then Continue;
    for x := 0 to 7 do
    begin
      px := BlockX + x;
      if (px < 0) or (px >= Plane.Width) then Continue;
      idx := py * Plane.Width + px;
      if (idx >= 0) and (idx < 256) then
        Plane.Data[idx] := Byte(Block[y*8 + x]);
    end;
  end;
end;

function DecodeMCU(Decoder: PJPEGDecoder; MCUX, MCUY: Integer): Boolean;
var
  CompIdx, bx, by, x, y, sx, sy, px, py, OutX, OutY, Offset: Integer;
  CompW, CompH, MaxW, MaxH: Integer;
  Block: TBlock;
  Plane: array[0..3] of TComponentPlane;
  Yv, Cb, Cr, R, G, B: Byte;
begin
  Result := False;
  if Decoder^.Error then Exit;

  // Bile�en d�zlemlerini haz�rla ve bloklar� decode et
  for CompIdx := 0 to Decoder^.NumComponents - 1 do
  begin
    CompW := Decoder^.Components[CompIdx].HFactor * 8;
    CompH := Decoder^.Components[CompIdx].VFactor * 8;
    Plane[CompIdx].Width  := CompW;
    Plane[CompIdx].Height := CompH;
    for y := 0 to 255 do Plane[CompIdx].Data[y] := 128;

    for by := 0 to Decoder^.Components[CompIdx].VFactor - 1 do
      for bx := 0 to Decoder^.Components[CompIdx].HFactor - 1 do
      begin
        if not DecodeBlock(Decoder, CompIdx, Block) then Exit;
        CopyBlockToPlane(Plane[CompIdx], Block, bx*8, by*8);
      end;
  end;

  MaxW := Decoder^.HMax * 8;
  MaxH := Decoder^.VMax * 8;

  // Pikselleri yaz
  for py := 0 to MaxH - 1 do
  begin
    OutY := MCUY + py;
    if OutY >= Decoder^.Height then Break;

    for px := 0 to MaxW - 1 do
    begin
      OutX := MCUX + px;
      if OutX >= Decoder^.Width then Break;

      if Decoder^.NumComponents = 1 then
      begin
        // Grayscale
        sx := (px * Plane[0].Width ) div MaxW;
        sy := (py * Plane[0].Height) div MaxH;
        if sx >= Plane[0].Width  then sx := Plane[0].Width  - 1;
        if sy >= Plane[0].Height then sy := Plane[0].Height - 1;
        Yv := Plane[0].Data[sy * Plane[0].Width + sx];
        R := Yv; G := Yv; B := Yv;
      end
      else
      begin
        // Y
        sx := (px * Plane[0].Width ) div MaxW;
        sy := (py * Plane[0].Height) div MaxH;
        if sx >= Plane[0].Width  then sx := Plane[0].Width  - 1;
        if sy >= Plane[0].Height then sy := Plane[0].Height - 1;
        Yv := Plane[0].Data[sy * Plane[0].Width + sx];

        // Cb
        sx := (px * Plane[1].Width ) div MaxW;
        sy := (py * Plane[1].Height) div MaxH;
        if sx >= Plane[1].Width  then sx := Plane[1].Width  - 1;
        if sy >= Plane[1].Height then sy := Plane[1].Height - 1;
        Cb := Plane[1].Data[sy * Plane[1].Width + sx];

        // Cr
        sx := (px * Plane[2].Width ) div MaxW;
        sy := (py * Plane[2].Height) div MaxH;
        if sx >= Plane[2].Width  then sx := Plane[2].Width  - 1;
        if sy >= Plane[2].Height then sy := Plane[2].Height - 1;
        Cr := Plane[2].Data[sy * Plane[2].Width + sx];

        YCbCrToRGB(Yv, Cb, Cr, R, G, B);
      end;

      Offset := (OutY * Decoder^.Width + OutX) * 3;
      if (Offset >= 0) and (Offset + 2 < Decoder^.PixelDataSize) then
      begin
        PByteArray(Decoder^.PixelData)[Offset + 0] := R;
        PByteArray(Decoder^.PixelData)[Offset + 1] := G;
        PByteArray(Decoder^.PixelData)[Offset + 2] := B;
      end;
    end;
  end;

  Result := not Decoder^.Error;
end;

//=============================================================================
// Restart
//=============================================================================

function ProcessRestartMarker(Decoder: PJPEGDecoder; Expected: Integer): Boolean;
var
  Marker: Word;
begin
  Result := False;
  ResetBitStream(Decoder);

  while Decoder^.FilePos < Decoder^.FileSize do
  begin
    if InByte(Decoder^.FileData, Decoder^.FilePos) <> $FF then
    begin
      Inc(Decoder^.FilePos);
      Continue;
    end;
    if Decoder^.FilePos + 1 >= Decoder^.FileSize then Break;

    Marker := InWord(Decoder^.FileData, Decoder^.FilePos);
    if (Marker >= JPEG_RST0) and (Marker <= JPEG_RST7) then
    begin
      Inc(Decoder^.FilePos, 2);
      if (Marker and $FF) <> ($D0 + (Expected and 7)) then
      begin
        Decoder^.Error := True;
        Exit;
      end;
      Decoder^.LastDCValue[0] := 0;
      Decoder^.LastDCValue[1] := 0;
      Decoder^.LastDCValue[2] := 0;
      Decoder^.LastDCValue[3] := 0;
      Result := True;
      Exit;
    end;
    Break;
  end;
  Decoder^.Error := True;
end;

//=============================================================================
// Scan
//=============================================================================

function DecodeScan(Decoder: PJPEGDecoder): Boolean;
var
  MCUsX, MCUsY, mx, my, MCUCounter, RestartNum: Integer;
begin
  Result := False;
  if (Decoder^.Width <= 0) or (Decoder^.Height <= 0) then Exit;

  MCUsX := (Decoder^.Width  + Decoder^.MCUWidth  - 1) div Decoder^.MCUWidth;
  MCUsY := (Decoder^.Height + Decoder^.MCUHeight - 1) div Decoder^.MCUHeight;

  MCUCounter := 0;
  RestartNum := 0;

  for my := 0 to MCUsY - 1 do
    for mx := 0 to MCUsX - 1 do
    begin
      if Decoder^.Error then Exit;
      if not DecodeMCU(Decoder, mx * Decoder^.MCUWidth, my * Decoder^.MCUHeight) then Exit;

      Inc(MCUCounter);
      if (Decoder^.RestartInterval > 0) and (MCUCounter = Decoder^.RestartInterval) then
      begin
        if not ProcessRestartMarker(Decoder, RestartNum) then Exit;
        Inc(RestartNum);
        MCUCounter := 0;
      end;
    end;

  Result := not Decoder^.Error;
end;

//=============================================================================
// Ana decode
//=============================================================================

function JPEG_Decode(Decoder: PJPEGDecoder): Boolean;
var
  Marker: Word;
  FoundSOF, FoundSOS: Boolean;
begin
  Result := False;
  if (Decoder = nil) or (Decoder^.FileData = nil) or (Decoder^.FileSize < 4) then Exit;

  Decoder^.Error := False;
  Decoder^.FilePos := 0;
  Decoder^.Width := 0;
  Decoder^.Height := 0;
  Decoder^.NumComponents := 0;
  Decoder^.RestartInterval := 0;
  FoundSOF := False;
  FoundSOS := False;

  if InWord(Decoder^.FileData, 0) <> JPEG_SOI then Exit;
  Decoder^.FilePos := 2;

  while Decoder^.FilePos < Decoder^.FileSize do
  begin
    if not ReadMarker(Decoder, Marker) then Exit;

    case Marker of
      JPEG_SOF0:
        begin
          if not ParseSOF0(Decoder) then Exit;
          FoundSOF := True;
        end;
      JPEG_DQT:  if not ParseDQT(Decoder) then Exit;
      JPEG_DHT:  if not ParseDHT(Decoder) then Exit;
      JPEG_DRI:  if not ParseDRI(Decoder) then Exit;
      JPEG_SOS:
        begin
          if not FoundSOF then Exit;
          if not ParseSOS(Decoder) then Exit;
          FoundSOS := True;
          if not DecodeScan(Decoder) then Exit;

          // EOI ara
          while Decoder^.FilePos < Decoder^.FileSize do
          begin
            if InByte(Decoder^.FileData, Decoder^.FilePos) = $FF then Break;
            Inc(Decoder^.FilePos);
          end;
          if Decoder^.FilePos < Decoder^.FileSize then
          begin
            if not ReadMarker(Decoder, Marker) then Exit;
            if Marker = JPEG_EOI then
            begin
              Result := True;
              Exit;
            end;
          end;
          Exit;
        end;
      JPEG_EOI:
        begin
          if FoundSOS then Result := True;
          Exit;
        end;
      JPEG_COM, JPEG_APP0..JPEG_APP15:
        if not SkipVariableMarker(Decoder) then Exit;
    else
      if not SkipVariableMarker(Decoder) then Exit;
    end;
  end;

  Result := FoundSOF and FoundSOS and (not Decoder^.Error);
end;

//=============================================================================
// Public API
//=============================================================================

function JPEG_LoadFromFile(FileName: PChar; var Width, Height: Integer): Pointer;
var
  Handle: Integer;
  Decoder: PJPEGDecoder;
  Size, ReadSize, PixelDataSize, i: Integer;
  Marker: Word;
begin
  Result := nil;
  Width := 0;
  Height := 0;

  if FileName = nil then Exit;

  Handle := OpenFile(FileName, FILE_READ);
  if Handle < 0 then Exit;

  Size := FileSize(Handle);
  if Size < 20 then begin CloseFile(Handle); Exit; end;

  Decoder := MemAlloc(SizeOf(TJPEGDecoder));
  if Decoder = nil then begin CloseFile(Handle); Exit; end;
  MemSet(Decoder, 0, SizeOf(TJPEGDecoder));

  Decoder^.FileData := MemAlloc(Size);
  if Decoder^.FileData = nil then
  begin
    FreeMem(Decoder);
    CloseFile(Handle);
    Exit;
  end;

  ReadSize := ReadFile(Handle, Decoder^.FileData, Size);
  CloseFile(Handle);
  if ReadSize <= 0 then
  begin
    FreeMem(Decoder^.FileData);
    FreeMem(Decoder);
    Exit;
  end;
  Decoder^.FileSize := ReadSize;

  if InWord(Decoder^.FileData, 0) <> JPEG_SOI then
  begin
    FreeMem(Decoder^.FileData);
    FreeMem(Decoder);
    Exit;
  end;

  // �nce SOF0 bul (boyut i�in)
  Decoder^.FilePos := 2;
  while Decoder^.FilePos < Decoder^.FileSize do
  begin
    if not ReadMarker(Decoder, Marker) then Break;
    if Marker = JPEG_SOF0 then
    begin
      if ParseSOF0(Decoder) then Break
      else Break;
    end
    else if not SkipVariableMarker(Decoder) then Break;
  end;

  if Decoder^.Error or (Decoder^.Width <= 0) or (Decoder^.Height <= 0) then
  begin
    FreeMem(Decoder^.FileData);
    FreeMem(Decoder);
    Exit;
  end;

  // Pixel buffer
  if (Decoder^.Width > (MaxInt div Decoder^.Height)) then
  begin
    FreeMem(Decoder^.FileData);
    FreeMem(Decoder);
    Exit;
  end;
  PixelDataSize := Decoder^.Width * Decoder^.Height;
  if PixelDataSize > (MaxInt div 3) then
  begin
    FreeMem(Decoder^.FileData);
    FreeMem(Decoder);
    Exit;
  end;
  PixelDataSize := PixelDataSize * 3;

  Decoder^.PixelData := MemAlloc(PixelDataSize);
  if Decoder^.PixelData = nil then
  begin
    FreeMem(Decoder^.FileData);
    FreeMem(Decoder);
    Exit;
  end;
  Decoder^.PixelDataSize := PixelDataSize;
  MemSet(Decoder^.PixelData, 0, PixelDataSize);

  // Tam decode
  Decoder^.FilePos := 0;
  Decoder^.BitBuffer := 0;
  Decoder^.BitCount := 0;
  Decoder^.Error := False;
  for i := 0 to 3 do Decoder^.LastDCValue[i] := 0;

  if not JPEG_Decode(Decoder) then
  begin
    FreeMem(Decoder^.PixelData);
    FreeMem(Decoder^.FileData);
    FreeMem(Decoder);
    Exit;
  end;

  Width  := Decoder^.Width;
  Height := Decoder^.Height;
  Result := Decoder^.PixelData;

  // Sadece pixel datay� b�rak, geri kalan� serbest b�rak
  FreeMem(Decoder^.FileData);
  FreeMem(Decoder);
end;

procedure JPEG_Free(Decoder: PJPEGDecoder);
begin
  // Not: JPEG_LoadFromFile zaten Decoder'� ve FileData'y� serbest b�rak�yor.
  // Bu fonksiyon geriye uyumluluk i�in b�rak�ld�.
  if Decoder = nil then Exit;
  if Decoder^.FileData  <> nil then FreeMem(Decoder^.FileData);
  if Decoder^.PixelData <> nil then FreeMem(Decoder^.PixelData);
  FreeMem(Decoder);
end;

end.

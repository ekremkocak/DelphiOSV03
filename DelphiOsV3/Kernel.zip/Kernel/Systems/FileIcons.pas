unit FileIcons;

{ ============================================================================
  FileIcons.pas

  Gercek bitmap/ImageList olmadan, SADECE Draw32.pas'in vektorel cizim
  fonksiyonlarini (KFill, KRect, KTriangle, KFillCircle, vs.) kullanarak
  dosya uzantisina gore basit, taninabilir ikonlar cizer.

  Kullanim:
    DrawFileIconByExt(X, Y, Size, '.exe', False);   // uzantidan
    DrawFileIconByExt(X, Y, Size, nil, True);       // klasor
    DrawFileIconByType(X, Y, Size, FT_SOUND);       // turu zaten biliniyorsa

  ListViewDraw.pas icindeki ImageList_DrawImageByIndex(...) cagrisi yerine
  dogrudan bu birimdeki DrawFileIconByExt/DrawFileIconByType kullanilabilir -
  asagida "ListViewDraw ENTEGRASYONU" basligi altinda ornek verildi.
============================================================================ }

interface

uses
  SysUtils, Draw32;

const
  { --- Dosya turu sabitleri --- }
  FT_FOLDER   = 0;
  FT_EXE      = 1;
  FT_IMAGE    = 2;   { bmp, jpg, png, gif, ico ... }
  FT_SOUND    = 3;   { wav, mp3, ogg, mid ... }
  FT_TEXT     = 4;   { txt, log, ini, cfg ... }
  FT_SOURCE   = 5;   { pas, c, cpp, h, asm, inc ... }
  FT_ARCHIVE  = 6;   { zip, rar, 7z, tar, gz ... }
  FT_DOC      = 7;   { doc, rtf, pdf ... }
  FT_OTHER    = 8;   { bilinmeyen / genel dosya }

{ Uzantiyi (veya tam dosya adini) inceleyip uygun turu dondurur.
  Ext nil ise veya IsDir=True ise FT_FOLDER dondurur. }
function  DetectFileIconType(const NameOrExt: PChar; IsDir: Boolean): Integer;

{ Dosya adindan/uzantidan doğrudan cizer (en cok kullanilacak fonksiyon) }
procedure DrawFileIconByExt(X, Y, Size: Integer; const NameOrExt: PChar; IsDir: Boolean);

{ Tur zaten biliniyorsa (ornegin bir kez hesaplanip saklanmissa) dogrudan cizer }
procedure DrawFileIconByType(X, Y, Size: Integer; FileType: Integer);

{ Tek tek turler icin dogrudan erisim (gerekirse) }
procedure DrawFolderIcon(X, Y, Size: Integer);
procedure DrawExeIcon(X, Y, Size: Integer);
procedure DrawImageIcon(X, Y, Size: Integer);
procedure DrawSoundIcon(X, Y, Size: Integer);
procedure DrawTextIcon(X, Y, Size: Integer);
procedure DrawSourceIcon(X, Y, Size: Integer);
procedure DrawArchiveIcon(X, Y, Size: Integer);
procedure DrawDocIcon(X, Y, Size: Integer);
procedure DrawGenericFileIcon(X, Y, Size: Integer);

implementation

{=============================================================================}
{ Yardimci: dosya adindan uzantiyi cikar (kucuk harfe cevirmeden, StrIEqual  }
{ zaten buyuk/kucuk harf duyarsiz karsilastiriyor)                          }
{=============================================================================}

function GetExtension(const Name: PChar): PChar;
var
  i, LastDot: Integer;
begin
  Result := nil;
  if Name = nil then Exit;

  LastDot := -1;
  i := 0;
  while Name[i] <> #0 do
  begin
    if Name[i] = '.' then LastDot := i;
    Inc(i);
  end;

  if (LastDot >= 0) and (Name[LastDot + 1] <> #0) then
    Result := @Name[LastDot + 1];
end;

function DetectFileIconType(const NameOrExt: PChar; IsDir: Boolean): Integer;
var
  Ext: PChar;
begin
  if IsDir then begin Result := FT_FOLDER; Exit; end;
  if NameOrExt = nil then begin Result := FT_OTHER; Exit; end;

  { Hem "dosya.txt" hem sadece "txt"/".txt" ile calissin diye:
    icinde nokta varsa uzanti cikar, yoksa parametrenin kendisini uzanti kabul et. }
  Ext := GetExtension(NameOrExt);
  if Ext = nil then Ext := NameOrExt;
  if (Ext[0] = '.') then Inc(Ext);   { basindaki '.' varsa atla }

  if StrEqualI(Ext, 'EXE') or StrEqualI(Ext, 'COM') or StrEqualI(Ext, 'BAT') then
    Result := FT_EXE
  else if StrEqualI(Ext, 'BMP') or StrEqualI(Ext, 'JPG') or StrEqualI(Ext, 'JPEG')
       or StrEqualI(Ext, 'PNG') or StrEqualI(Ext, 'GIF') or StrEqualI(Ext, 'ICO') then
    Result := FT_IMAGE
  else if StrEqualI(Ext, 'WAV') or StrEqualI(Ext, 'MP3') or StrEqualI(Ext, 'OGG')
       or StrEqualI(Ext, 'MID') or StrEqualI(Ext, 'MIDI') then
    Result := FT_SOUND
  else if StrEqualI(Ext, 'TXT') or StrEqualI(Ext, 'LOG') or StrEqualI(Ext, 'INI')
       or StrEqualI(Ext, 'CFG') or StrEqualI(Ext, 'CSV') then
    Result := FT_TEXT
  else if StrEqualI(Ext, 'PAS') or StrEqualI(Ext, 'C') or StrEqualI(Ext, 'CPP')
       or StrEqualI(Ext, 'H') or StrEqualI(Ext, 'ASM') or StrEqualI(Ext, 'INC')
       or StrEqualI(Ext, 'DPR') then
    Result := FT_SOURCE
  else if StrEqualI(Ext, 'ZIP') or StrEqualI(Ext, 'RAR') or StrEqualI(Ext, '7Z')
       or StrEqualI(Ext, 'TAR') or StrEqualI(Ext, 'GZ') then
    Result := FT_ARCHIVE
  else if StrEqualI(Ext, 'DOC') or StrEqualI(Ext, 'RTF') or StrEqualI(Ext, 'PDF') then
    Result := FT_DOC
  else
    Result := FT_OTHER;
end;

{=============================================================================}
{ Ortak "kagit" siluet cizimi (Text/Source/Doc/Generic'in temeli) - kivrik   }
{ ust-sag kose ile klasik "dosya" gorunumu                                   }
{=============================================================================}

procedure DrawPaperShape(X, Y, Size: Integer; FillColor, BorderColor: LongWord);
var
  Fold: Integer;
  L, T, W, H: Integer;
begin
  L := X + (Size div 8);
  T := Y + (Size div 10);
  W := Size - (Size div 4);
  H := Size - (Size div 5);
  Fold := Size div 4;

  { Govde }
  KFill(L, T, W, H, FillColor);
  KRect(L, T, W, H, BorderColor);

  { Sag ust kivrik kose (ucgen kesik gorunumu) }
  KFillTriangle(L + W - Fold, T, L + W, T + Fold, L + W - Fold, T + Fold, clSilver);
  KLine(L + W - Fold, T, L + W - Fold, T + Fold, BorderColor);
  KLine(L + W - Fold, T + Fold, L + W, T + Fold, BorderColor);
end;

{=============================================================================}
{ KLASOR                                                                     }
{=============================================================================}

procedure DrawFolderIcon(X, Y, Size: Integer);
var
  TabW, TabH, BodyY, BodyH: Integer;
begin
  TabW := Size div 2;
  TabH := Size div 6;
  BodyY := Y + TabH + (Size div 12);
  BodyH := Size - TabH - (Size div 12) - (Size div 12);

  { Klasor sekmesi (ust) }
  KFill(X + (Size div 12), Y + (Size div 12), TabW, TabH, $0060A0F0);
  KRect(X + (Size div 12), Y + (Size div 12), TabW, TabH, $00305078);

  { Klasor govdesi }
  KFill(X + (Size div 12), BodyY, Size - (Size div 6), BodyH, $0070B0FF);
  KRect(X + (Size div 12), BodyY, Size - (Size div 6), BodyH, $00305078);

  { Ust kenarda hafif parlama cizgisi (3D his) }
  KLineH(X + (Size div 12) + 1, BodyY + 1, Size - (Size div 6) - 2, $00A8D0FF);
end;

{=============================================================================}
{ EXE / UYGULAMA - disli/dairesel "makine" simgesi                          }
{=============================================================================}

procedure DrawExeIcon(X, Y, Size: Integer);
var
  CX, CY, R, i: Integer;
  Angle: Integer;
  Px, Py: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := (Size div 2) - (Size div 8);

  { Govde: yuvarlatilmis kutu }
  KRoundRect(X + (Size div 8), Y + (Size div 8),
             Size - (Size div 4), Size - (Size div 4),
             Size div 6, $00305078, $00909090);

  { Basit "disli" gorunumu: merkez daire + 6 kucuk dis (dikdortgen).
    Sin_Int/Cos_Int 10000 olcekli sabit nokta dondurur (Draw32.pas). }
  for i := 0 to 5 do
  begin
    Angle := i * 60;
    Px := CX + (R * Cos_Int(Angle)) div 10000;
    Py := CY + (R * Sin_Int(Angle)) div 10000;
    KFillCircle(Px, Py, Size div 14, $00404040);
  end;

  KFillCircle(CX, CY, R - (Size div 10), $00606060);
  KCircle(CX, CY, R - (Size div 10), clWhite);
  KFillCircle(CX, CY, Size div 12, clWhite);
end;

{=============================================================================}
{ RESIM (BMP/JPG/PNG...) - dag + gunes motifi olan bir "fotograf" karesi    }
{=============================================================================}

procedure DrawImageIcon(X, Y, Size: Integer);
var
  L, T, W, H: Integer;
begin
  L := X + (Size div 8);
  T := Y + (Size div 8);
  W := Size - (Size div 4);
  H := Size - (Size div 4);

  KFill(L, T, W, H, $00E8F0FF);
  KRect(L, T, W, H, $00305078);

  { Gunes }
  KFillCircle(L + W - (W div 4), T + (H div 4), Size div 12, $0000C0FF);

  { Daglar }
  KFillTriangle(L + 2, T + H - 2, L + (W div 3), T + (H div 3), L + (W div 2) + 2, T + H - 2, $0040A040);
  KFillTriangle(L + (W div 3), T + H - 2, L + (2 * W div 3), T + (H div 4), L + W - 2, T + H - 2, $00308030);
end;

{=============================================================================}
{ SES (WAV/MP3/...) - hoparlor + ses dalgalari                              }
{=============================================================================}

procedure DrawSoundIcon(X, Y, Size: Integer);
var
  CX, CY: Integer;
  SpX, SpY, SpW, SpH: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;

  SpW := Size div 4;
  SpH := Size div 3;
  SpX := X + (Size div 3) - (SpW div 2);
  SpY := CY - (SpH div 2);

  { Hoparlor govdesi: kucuk kare }
  KFill(SpX, SpY + (SpH div 4), SpW div 2, SpH div 2, $00404040);

  { Huni (konus) - iki ucgenle olusturulan yamuk gorunumu }
  KFillTriangle(SpX + (SpW div 2), SpY,
                SpX + SpW, SpY - (SpH div 4),
                SpX + SpW, SpY + SpH + (SpH div 4), $00404040);
  KFillTriangle(SpX + (SpW div 2), SpY + SpH,
                SpX + (SpW div 2), SpY,
                SpX + SpW, SpY + SpH + (SpH div 4), $00404040);

  { Ses dalgalari (yay parcalari) }
  KArc(CX + (Size div 10), CY, Size div 6,  -45, 45, $00305078);
  KArc(CX + (Size div 6),  CY, Size div 4,  -45, 45, $00305078);
end;

{=============================================================================}
{ METIN (TXT/LOG/INI...) - kagit + satir cizgileri                          }
{=============================================================================}

procedure DrawTextIcon(X, Y, Size: Integer);
var
  L, T, W, H, LineY, LineGap, i: Integer;
begin
  DrawPaperShape(X, Y, Size, clWhite, cl3DShadow);

  L := X + (Size div 8) + (Size div 12);
  T := Y + (Size div 10);
  W := Size - (Size div 4) - (Size div 6);
  H := Size - (Size div 5);
  LineGap := H div 5;

  for i := 1 to 3 do
  begin
    LineY := T + i * LineGap;
    KLineH(L, LineY, W, cl3DShadow);
  end;
end;

{=============================================================================}
{ KAYNAK KOD (PAS/C/CPP/...) - kagit + "< >" sembolu                        }
{=============================================================================}

procedure DrawSourceIcon(X, Y, Size: Integer);
var
  L, T, W, H, CY: Integer;
begin
  DrawPaperShape(X, Y, Size, $00FFF4E0, $00806020);

  L := X + (Size div 8) + (Size div 12);
  T := Y + (Size div 10);
  W := Size - (Size div 4) - (Size div 6);
  H := Size - (Size div 5);
  CY := T + H div 2;

  { "<" }
  KLine(L + (W div 3), CY - (H div 6), L + (W div 6), CY, $00806020);
  KLine(L + (W div 6), CY, L + (W div 3), CY + (H div 6), $00806020);

  { ">" }
  KLine(L + W - (W div 3), CY - (H div 6), L + W - (W div 6), CY, $00806020);
  KLine(L + W - (W div 6), CY, L + W - (W div 3), CY + (H div 6), $00806020);
end;

{=============================================================================}
{ ARSIV (ZIP/RAR/...) - kutu + fermuar cizgisi                              }
{=============================================================================}

procedure DrawArchiveIcon(X, Y, Size: Integer);
var
  L, T, W, H, i, ZY: Integer;
begin
  L := X + (Size div 8);
  T := Y + (Size div 8);
  W := Size - (Size div 4);
  H := Size - (Size div 4);

  KFill(L, T, W, H, $0080A080);
  KRect(L, T, W, H, $00305030);

  { Fermuar (dikey orta cizgi + kucuk kareler) }
  for i := 0 to 3 do
  begin
    ZY := T + (Size div 10) + i * (H div 5);
    KFill(L + (W div 2) - 2, ZY, 4, H div 10, clWhite);
  end;
end;

{=============================================================================}
{ BELGE (DOC/RTF/PDF) - kagit + katlanmis kose, koyu renk seridi            }
{=============================================================================}

procedure DrawDocIcon(X, Y, Size: Integer);
var
  L, T, W: Integer;
begin
  DrawPaperShape(X, Y, Size, clWhite, cl3DShadow);

  L := X + (Size div 8) + (Size div 12);
  T := Y + (Size div 10);
  W := Size - (Size div 4) - (Size div 6);

  KFill(L, T + (Size div 8), W, Size div 10, $00A03030);
end;

{=============================================================================}
{ GENEL / BILINMEYEN DOSYA - sade kagit siluet                              }
{=============================================================================}

procedure DrawGenericFileIcon(X, Y, Size: Integer);
begin
  DrawPaperShape(X, Y, Size, clWhite, cl3DShadow);
end;

{=============================================================================}
{ Dispatcher'lar                                                            }
{=============================================================================}

procedure DrawFileIconByType(X, Y, Size: Integer; FileType: Integer);
begin
  case FileType of
    FT_FOLDER:  DrawFolderIcon(X, Y, Size);
    FT_EXE:     DrawExeIcon(X, Y, Size);
    FT_IMAGE:   DrawImageIcon(X, Y, Size);
    FT_SOUND:   DrawSoundIcon(X, Y, Size);
    FT_TEXT:    DrawTextIcon(X, Y, Size);
    FT_SOURCE:  DrawSourceIcon(X, Y, Size);
    FT_ARCHIVE: DrawArchiveIcon(X, Y, Size);
    FT_DOC:     DrawDocIcon(X, Y, Size);
  else
    DrawGenericFileIcon(X, Y, Size);
  end;
end;

procedure DrawFileIconByExt(X, Y, Size: Integer; const NameOrExt: PChar; IsDir: Boolean);
begin
  DrawFileIconByType(X, Y, Size, DetectFileIconType(NameOrExt, IsDir));
end;

end.

Unit DrawIcons;

interface

uses
  SysUtils, Math, Draw32;

type
  TIconType = (
    itFolder,       // Klas�r
    itPictures,     // Resimlerim
    itMusic,        // M�ziklerim
    itHDD,          // Sabit Disk
    itRAM,          // RAM Bellek
    itPaint,        // Paint / �izim
    itMyComputer,   // Bilgisayar�m
    itFiles,        // Dosyalar�m
    itSettings,     // Ayarlar
    itSettings1,    // Ayarlar
    itTxt,          // Metin Belgesi
    itWav,          // Ses Dosyas�
    itBmp,          // Resim Dosyas�
    itExe,          // �al��t�r�labilir Dosya
    itBin,          // Binary / Veri Dosyas�
    itRecycleBin,   // ��p Kutusu
    itRecycleBin1,   // ��p Kutusu
    itNetwork,      // A�
    itZip,          // S�k��t�r�lm�� Ar�iv
    itTerminal,     // Komut Sat�r� / Terminal
    itDoc,          // Genel Dok�man / PDF
    itHttpServer,   // Web Sunucusu (HttpServer)
    itWebBrowser,    // Web Taray�c�s� (WebBrowser)
    itCalculator,
    itINFO ,
    itGames,
    itClock ,
    itCDROM,
    itCPU,
    itUSB,
    itPrinter,
    itUser,
    itLock,
    itWifi,
    itMail
  );

const
  IconNames: array[TIconType] of PChar = (
    'Klasor', 'Resimler', 'Muzik', 'HDD', 'RAM',
    'Paint', 'PC', 'Dosyalar', 'Ayarlar', 'Ayarlar', 'TXT',
    'WAV', 'BMP', 'EXE', 'BIN', 'Cop','Cop',
    'Ag', 'ZIP', 'Terminal', 'DOC', 'HttpServer', 'Browser',
    'Calculator','INFO','Games','Saat','CD-ROM',
    'CPU', 'USB', 'Yazici', 'Kullanici', 'Kilit', 'Wi-Fi', 'E-Posta'
  );

  const
  // --- YEN� CANLI HDD RENKLER� ---
  cHDDPlatterTop   = $00FFE0A0; // Parlak Turkuaz/A��k Mavi Yans�ma
  cHDDPlatterBot   = $00C06000; // Koyu Mavi Metal
  cHDDCoverTop     = $00606060; // Titanyum Gri Top
  cHDDCoverBot     = $00252525; // Koyu Metalik G�vde
  cHDDPcbGreen     = $0000C000; // Canl� Devre Kart� Ye�ili
  cHDDActuatorRed  = $004040FF; // Parlak K�rm�z� Okuyucu Kol
  cHDDBorderDark   = $001A1A1A;

  // --- YEN� CANLI CD-ROM RENKLER� ---
  cCDDiscCenter    = $00FFFFFF; // Parlak Beyaz ��
  cCDHoloBlue      = $00FF8000; // Y�r�nge Mavisi (BGR)
  cCDHoloMagenta   = $00FF00CC; // Canl� Pembe/Eflatun Yans�ma
  cCDHoloCyan      = $00FFFF00; // Parlak Turkuaz Yans�ma
  cCDTrayFrontTop  = $00505050; // Kasa �st
  cCDTrayFrontBot  = $001E1E1E; // Kasa Alt
  // --- SAAT RENKLER� ---
  cClockBodyTop    = $00F0F0F0;
  cClockBodyBot    = $00B0B0B0;
  cClockBorder     = $00404040;
  cClockHandHour   = $00101010;
  cClockHandMin    = $00202020;
  cClockHandSec    = $000000FF; // K�rm�z� saniye ibresi

  // --- OYUN (GAMEPAD) RENKLER� ---
  cGamePadBodyTop  = $00606060;
  cGamePadBodyBot  = $00202020;
  cGamePadBtnRed   = $000000FF;
  cGamePadBtnBlue  = $00FF0000;
  cGamePadBtnGreen = $0000FF00;
  cGamePadBtnYellow= $0000FFFF;
  cGamePadDpad     = $00101010;

  // =========================================================
  // �KON RENK PALET� (Delphi BGR Format�: $00BBGGRR)
  // =========================================================
  
  // --- KLAS�R (Sar� / Alt�n) ---
  cFolderTabTop    = $00FFC800; // Parlak Turuncu-Sar� (R:255, G:200, B:0)
  cFolderTabBot    = $00C89600; // Koyu Sar� (R:200, G:150, B:0)
  cFolderBodyTop   = $00FFD030; // G�vde A��k Sar� (R:255, G:208, B:48)
  cFolderBodyBot   = $00BD8C00; // G�vde Koyu Alt�n (R:189, G:140, B:0)
  cFolderHighlight = $00FFFF80; // �� A��k Sar� �izgi
  cFolderBorder    = $00825A00; // Koyu Kahve/Sar� �er�eve

  // --- RES�MLER ---
  cPicSkyTop       = $00C0F0FF; 
  cPicSkyBot       = $000080FF; 
  cPicSun          = $0000FFFF; 
  cPicMountain1    = $00008000; 
  cPicMountain2    = $002AA500; 
  cPicCardBg       = $00FAFAFA; 
  cPicBorder       = $00C0C0C0;

  // --- M�Z�K ---
  cMusicVinylBody  = $00202020;
  cMusicVinylRing1 = $00505050;
  cMusicVinylRing2 = $003A3A3A;
  cMusicLabel      = $000033FF; 
  cMusicNote       = clYellow;

  // --- HDD & RAM ---
  cHDDMetal        = $00808080;
  cHDDBorder       = $00404040;
  cRAMPcbTop       = $00008800; 
  cRAMPcbBot       = $00004400;
  cRAMChip         = $001A1A1A;
  cRAMPin          = $00FFD700; 

  // --- PAINT ---
  cWoodTop         = $002A527A; 
  cWoodBot         = $001B3550;
  cWoodHole        = $000F1E2D;

  // --- PC & DOSYALAR ---
  cMonScreenTop    = $000060D0; 
  cMonScreenBot    = $00000080;
  cFilesMetal      = $00B0B0B0;

  // --- DOSYA T�PLER� ---
  cWavBgTop        = $00800080; 
  cWavBgBot        = $00400040;
  cExeSunken       = $001A1A1A;
  cBinBorder       = clGreen;
  cBinDots         = clLime;
  cRecycleArrow    = clLime;
  cNetworkGlobe    = $00FF8000; 
  cZipZipper       = clYellow;
  cDocRed          = clRed;

  // --- HTTP SERVER & WEB BROWSER RENKLER� ---
  cServerRack      = $00333333; // Koyu Sunucu Kasas�
  cServerLedGreen  = $0000FF00; // �al���yor LED'i
  cServerLedBlue   = $00FF8000; // A� Aktivasyon LED'i
  cBrowserGlobe    = $00E67E22; // Okyanus Mavisi (BGR: R:34, G:126, B:230)
  cBrowserCompass  = $000000FF; // Pusula / �bre K�rm�z�s�




type
  // Group Icon Header
  PGRPIconDirEntry = ^TGRPIconDirEntry;
  TGRPIconDirEntry = packed record
    bWidth        : Byte;      // 0 = 256px
    bHeight       : Byte;      // 0 = 256px
    bColorCount   : Byte;
    bReserved     : Byte;
    wPlanes       : Word;
    wBitCount     : Word;      // Renk Derinli�i (24, 32 vb.)
    dwBytesInRes  : LongWord;
    nID           : Word;      // RT_ICON dizinindeki Ordinal Name (ID)
  end;

  PGRPIconDir = ^TGRPIconDir;
  TGRPIconDir = packed record
    idReserved : Word;
    idType     : Word;         // 1 = Icon
    idCount    : Word;         // Grup i�indeki ikon say�s�
  end;


  PRGBQuad = ^TRGBQuad;
  TRGBQuad = record
    rgbBlue     : Byte;
    rgbGreen    : Byte;
    rgbRed      : Byte;
    rgbReserved : Byte;
  end;


 
  // PE Header Yap�lar� (Resource Okuma ��in)
  PImageDosHeader = ^TImageDosHeader;
  TImageDosHeader = record
    e_magic    : Word;
    e_cblp     : Word;
    e_cp       : Word;
    e_crlc     : Word;
    e_cparhdr  : Word;
    e_minalloc : Word;
    e_maxalloc : Word;
    e_ss       : Word;
    e_sp       : Word;
    e_csum     : Word;
    e_ip       : Word;
    e_cs       : Word;
    e_lfarlc   : Word;
    e_ovno     : Word;
    e_res      : array[0..3] of Word;
    e_oemid    : Word;
    e_oeminfo  : Word;
    e_res2     : array[0..9] of Word;
    _lfanew    : LongInt;
  end;

  PImageResourceDirectory = ^TImageResourceDirectory;
  TImageResourceDirectory = record
    Characteristics      : LongWord;
    TimeDateStamp        : LongWord;
    MajorVersion         : Word;
    MinorVersion         : Word;
    NumberOfNamedEntries : Word;
    NumberOfIdEntries    : Word;
  end;

  PImageResourceDirectoryEntry = ^TImageResourceDirectoryEntry;
  TImageResourceDirectoryEntry = record
    NameOrID   : LongWord;
    OffsetToData: LongWord;
  end;

  PImageResourceDataEntry = ^TImageResourceDataEntry;
  TImageResourceDataEntry = record
    OffsetToData : LongWord;
    Size         : LongWord;
    CodePage     : LongWord;
    Reserved     : LongWord;
  end;

  PBitmapInfoHeader = ^TBitmapInfoHeader;
  TBitmapInfoHeader = record
    biSize          : LongWord;
    biWidth         : LongInt;
    biHeight        : LongInt;
    biPlanes        : Word;
    biBitCount      : Word;
    biCompression   : LongWord;
    biSizeImage     : LongWord;
    biXPelsPerMeter : LongInt;
    biYPelsPerMeter : LongInt;
    biClrUsed       : LongWord;
    biClrImportant  : LongWord;
  end;

// Fonksiyon ve Prosed�r Bildirimleri



// Prosed�r Tan�mlar�
procedure DrawIcon(X, Y, Size: Integer; IconType: TIconType); stdcall;
procedure DrawIconFolder(X, Y, Size: Integer); stdcall;
procedure DrawIconPictures(X, Y, Size: Integer); stdcall;
procedure DrawIconMusic(X, Y, Size: Integer); stdcall;
procedure DrawIconHDD(X, Y, Size: Integer); stdcall;
procedure DrawIconRAM(X, Y, Size: Integer); stdcall;
procedure DrawIconPaint(X, Y, Size: Integer); stdcall;
procedure DrawIconMyComputer(X, Y, Size: Integer); stdcall;
procedure DrawIconFiles(X, Y, Size: Integer); stdcall;
procedure DrawIconSettings(X, Y, Size: Integer); stdcall;
procedure DrawIconSettings1(X, Y, Size: Integer); stdcall;
procedure DrawIconTxt(X, Y, Size: Integer); stdcall;
procedure DrawIconWav(X, Y, Size: Integer); stdcall;
procedure DrawIconBmp(X, Y, Size: Integer); stdcall;
procedure DrawIconExe(X, Y, Size: Integer); stdcall;
procedure DrawIconBin(X, Y, Size: Integer); stdcall;
procedure DrawIconRecycleBin(X, Y, Size: Integer); stdcall;
procedure DrawIconRecycleBin1(X, Y, Size: Integer); stdcall;
procedure DrawIconNetwork(X, Y, Size: Integer); stdcall;
procedure DrawIconZip(X, Y, Size: Integer); stdcall;
procedure DrawIconTerminal(X, Y, Size: Integer); stdcall;
procedure DrawIconDoc(X, Y, Size: Integer); stdcall;
procedure DrawIconHttpServer(X, Y, Size: Integer); stdcall;
procedure DrawIconWebBrowser(X, Y, Size: Integer); stdcall;

function GetImageIndex(FileName: PChar): Integer; stdcall;

procedure DrawIconCalc(X, Y, Size: Integer); stdcall;
procedure DrawIconClock(X, Y, Size: Integer); stdcall;
procedure DrawIconGames(X, Y, Size: Integer); stdcall;
procedure DrawIconSysInfo(X, Y, Size: Integer); stdcall;

procedure Test_DrawAllIcons(StartX, StartY, IconSize: Integer);

implementation

Uses Messages;


function S(Val, Size: Integer): Integer;
begin
  Result := (Val * Size) div 32;
end;





function ExtMatches(Ext, Target: PChar): Boolean;
var
  i: Integer;
  c1, c2: Char;
begin
  i := 0;
  while True do
  begin
    c1 := Ext[i];
    c2 := Target[i];
    
    if (c1 >= 'A') and (c1 <= 'Z') then c1 := Char(Ord(c1) + 32);
    if (c2 >= 'A') and (c2 <= 'Z') then c2 := Char(Ord(c2) + 32);
    
    if c1 <> c2 then
    begin
      Result := False;
      Exit;
    end;
    if c1 = #0 then
    begin
      Result := True;
      Exit;
    end;
    Inc(i);
  end;
end;

function GetImageIndex(FileName: PChar): Integer; stdcall;
var
  Len, i, DotPos: Integer;
  Ext: array[0..15] of Char;
  ExtLen: Integer;
begin
  Result := Ord(itDoc);

  if (FileName = nil) or (FileName[0] = #0) then
  begin
    Result := Ord(itFolder);
    Exit;
  end;

  Len := 0;
  DotPos := -1;
  while FileName[Len] <> #0 do
  begin
    if FileName[Len] = '.' then DotPos := Len;
    if (FileName[Len] = '\') or (FileName[Len] = '/') then DotPos := -1;
    Inc(Len);
  end;

  if (DotPos = -1) or (DotPos = Len - 1) then
  begin
    Result := Ord(itFolder);
    Exit;
  end;

  ExtLen := 0;
  for i := DotPos + 1 to Len - 1 do
  begin
    if ExtLen >= 15 then Break;
    Ext[ExtLen] := FileName[i];
    Inc(ExtLen);
  end;
  Ext[ExtLen] := #0;

  if ExtMatches(Ext, 'exe') or ExtMatches(Ext, 'bat') or ExtMatches(Ext, 'com') then 
    Result := Ord(itExe)
  else if ExtMatches(Ext, 'htm') or ExtMatches(Ext, 'html') or ExtMatches(Ext, 'php') or ExtMatches(Ext, 'asp') then 
    Result := Ord(itWebBrowser)
  else if ExtMatches(Ext, 'bmp') then 
    Result := Ord(itBmp)
  else if ExtMatches(Ext, 'jpg') or ExtMatches(Ext, 'jpeg') or ExtMatches(Ext, 'png') or ExtMatches(Ext, 'gif') then 
    Result := Ord(itPictures)
  else if ExtMatches(Ext, 'wav') then 
    Result := Ord(itWav)
  else if ExtMatches(Ext, 'mp3') or ExtMatches(Ext, 'ogg') or ExtMatches(Ext, 'mid') then 
    Result := Ord(itMusic)
  else if ExtMatches(Ext, 'txt') or ExtMatches(Ext, 'log') or ExtMatches(Ext, 'ini') or ExtMatches(Ext, 'cfg') then 
    Result := Ord(itTxt)
  else if ExtMatches(Ext, 'bin') or ExtMatches(Ext, 'dat') or ExtMatches(Ext, 'sys') or ExtMatches(Ext, 'dll') then 
    Result := Ord(itBin)
  else if ExtMatches(Ext, 'zip') or ExtMatches(Ext, 'rar') or ExtMatches(Ext, '7z') or ExtMatches(Ext, 'tar') then 
    Result := Ord(itZip)
  else if ExtMatches(Ext, 'pdf') or ExtMatches(Ext, 'doc') or ExtMatches(Ext, 'docx') then 
    Result := Ord(itDoc)
  else if ExtMatches(Ext, 'iso') or ExtMatches(Ext, 'img') or ExtMatches(Ext, 'cue') or ExtMatches(Ext, 'nrg') then 
    Result := Ord(itCDROM)
  else if ExtMatches(Ext, 'cp8') or ExtMatches(Ext, 'rom') or ExtMatches(Ext, 'nes') then 
  Result := Ord(itGames);
end;


{ ... Di�er prosed�rler de�i�meden aynen kal�yor ... }

procedure DrawIconFolder(X, Y, Size: Integer); stdcall;
var TabW, TabH, MainH: Integer;
begin
  KFillAlpha(X + S(2, Size), Y + S(28, Size), S(28, Size), S(3, Size), clBlack, 80);
  TabW := S(14, Size); TabH := S(6, Size);
  KGradientV(X + S(2, Size), Y + S(4, Size), TabW, TabH, cFolderTabTop, cFolderTabBot);
  MainH := S(20, Size);
  KGradientV(X + S(1, Size), Y + S(8, Size), S(30, Size), MainH, cFolderBodyTop, cFolderBodyBot);
  KLineH(X + S(2, Size), Y + S(9, Size), S(28, Size), cFolderHighlight);
  KRect(X + S(1, Size), Y + S(8, Size), S(30, Size), MainH, cFolderBorder);
end;

procedure DrawIconPictures(X, Y, Size: Integer); stdcall;
begin
  KShadowRect(X + S(2, Size), Y + S(2, Size), S(28, Size), S(28, Size), S(2, Size), clWhite);
  KRect(X + S(2, Size), Y + S(2, Size), S(28, Size), S(28, Size), cPicBorder);
  KGradientV(X + S(4, Size), Y + S(4, Size), S(24, Size), S(16, Size), cPicSkyTop, cPicSkyBot);
  KFillCircle(X + S(8, Size), Y + S(8, Size), S(3, Size), cPicSun);
  KFillTriangle(X + S(4, Size), Y + S(20, Size), X + S(12, Size), Y + S(10, Size), X + S(20, Size), Y + S(20, Size), cPicMountain1);
  KFillTriangle(X + S(12, Size), Y + S(20, Size), X + S(20, Size), Y + S(12, Size), X + S(28, Size), Y + S(20, Size), cPicMountain2);
  KFill(X + S(4, Size), Y + S(21, Size), S(24, Size), S(7, Size), cPicCardBg);
end;

procedure DrawIconMusic(X, Y, Size: Integer); stdcall;
var R, CX, CY: Integer;
begin
  CX := X + Size div 2; CY := Y + Size div 2; R := S(14, Size);
  KFillCircle(CX, CY, R, cMusicVinylBody);
  KCircle(CX, CY, R, cMusicVinylRing1);
  KCircle(CX, CY, S(10, Size), cMusicVinylRing2);
  KCircle(CX, CY, S(7, Size),  cMusicVinylRing1);
  KFillCircle(CX, CY, S(5, Size), cMusicLabel);
  KFillCircle(CX, CY, S(2, Size), clWhite);
  KLineV(CX + S(3, Size), CY - S(6, Size), S(10, Size), cMusicNote);
  KFillCircle(CX + S(1, Size), CY + S(4, Size), S(2, Size), cMusicNote);
end;


procedure DrawIconCDROM(X, Y, Size: Integer); stdcall;
var
  CX, CY, R: Integer;
begin
  // 1. CD / DVD Diski (�stte D��ar� ��kan Renkli B�l�m)
  CX := X + Size div 2;
  CY := Y + S(11, Size);
  R  := S(10, Size);

  // Mavi-Eflatun Holofil Disk Taban�
  KGradientRadial(CX, CY, R, cCDHoloCyan, cCDHoloBlue);
  KCircle(CX, CY, R, cCDHoloMagenta);

  // X �eklinde Canl� Lazer / Spektrum Yans�ma �izgileri
  KLine(CX - S(7, Size), CY - S(7, Size), CX + S(7, Size), CY + S(7, Size), cCDHoloMagenta);
  KLine(CX - S(7, Size), CY + S(7, Size), CX + S(7, Size), CY - S(7, Size), clWhite);

  // �effaf �� Halka ve �effaf G�bek
  KCircle(CX, CY, S(5, Size), clWhite);
  KFillCircle(CX, CY, S(3, Size), cCDDiscCenter);
  KCircle(CX, CY, S(3, Size), clGray);
  KFillCircle(CX, CY, S(1, Size), clBlack);

  // 2. S�r�c� �n Paneli (HttpServer Stilinde Koyu Gradyan Kasa)
  KGradientV(X + S(2, Size), Y + S(17, Size), S(28, Size), S(11, Size), cCDTrayFrontTop, cCDTrayFrontBot);
  KRect(X + S(2, Size), Y + S(17, Size), S(28, Size), S(11, Size), clBlack);
  KBevel(X + S(3, Size), Y + S(18, Size), S(26, Size), S(9, Size), S(1, Size), True);

  // S�r�c� Y�kleme �izgisi (Tray Slot)
  KLineH(X + S(5, Size), Y + S(21, Size), S(22, Size), clBlack);

  // 3. Canl� LED'ler ve Eject D��mesi
  // ��karma D��mesi
  KFill(X + S(21, Size), Y + S(23, Size), S(5, Size), S(3, Size), $00404040);
  KRect(X + S(21, Size), Y + S(23, Size), S(5, Size), S(3, Size), clGray);

  // Okuma LED'i (Ye�il Parlama)
  KFillCircle(X + S(6, Size), Y + S(24, Size), S(1, Size), clLime);
  KGlowRect(X + S(5, Size), Y + S(23, Size), S(3, Size), S(3, Size), S(1, Size), clLime);

  // Kulakl�k / Ses LED'i veya Jak� (Turuncu/Sar�)
  KFillCircle(X + S(11, Size), Y + S(24, Size), S(1, Size), $0000A5FF);
end;


procedure DrawIconHDD(X, Y, Size: Integer); stdcall;
begin
  // 1. Ana D�� Kasa (Titanyum Gradyan)
  KGradientV(X + S(3, Size), Y + S(2, Size), S(26, Size), S(28, Size), cHDDCoverTop, cHDDCoverBot);
  KRect(X + S(3, Size), Y + S(2, Size), S(26, Size), S(28, Size), cHDDBorderDark);

  // 2. Manyetik Plak (Canl� Mavi/Turkuaz Metalik Gradyan)
  KGradientRadial(X + S(16, Size), Y + S(12, Size), S(9, Size), cHDDPlatterTop, cHDDPlatterBot);
  KCircle(X + S(16, Size), Y + S(12, Size), S(9, Size), $00E08000);
  
  // Plak Orta G�be�i
  KFillCircle(X + S(16, Size), Y + S(12, Size), S(3, Size), clSilver);
  KCircle(X + S(16, Size), Y + S(12, Size), S(3, Size), clWhite);
  KCircle(X + S(16, Size), Y + S(12, Size), S(1, Size), clDkGray);

  // 3. Okuyucu Kafa (Actuator Arm - K�rm�z� Vurgulu)
  KLine(X + S(8, Size), Y + S(18, Size), X + S(14, Size), Y + S(13, Size), cHDDActuatorRed);
  KFillCircle(X + S(8, Size), Y + S(18, Size), S(2, Size), clSilver); // Mafsal

  // 4. Alt Devre Kart� B�lgesi (Canl� Ye�il PCB)
  KFill(X + S(5, Size), Y + S(23, Size), S(22, Size), S(5, Size), cHDDPcbGreen);
  KRect(X + S(5, Size), Y + S(23, Size), S(22, Size), S(5, Size), $00004000);
  
  // Alt Konnekt�r Alt�n Pin Hatt�
  KLineH(X + S(7, Size), Y + S(26, Size), S(18, Size), $0000FFFF);

  // 5. Durum LED'i ve Parlama (Glow)
  KFillCircle(X + S(24, Size), Y + S(25, Size), S(1, Size), clLime);
  KGlowRect(X + S(23, Size), Y + S(24, Size), S(3, Size), S(3, Size), S(1, Size), clLime);

  // K��e Vidalar�
  PutPixel(X + S(4, Size),  Y + S(3, Size),  clWhite);
  PutPixel(X + S(27, Size), Y + S(3, Size),  clWhite);
end;

procedure DrawIconHDD1(X, Y, Size: Integer); stdcall;
begin
  KMetal(X + S(3, Size), Y + S(4, Size), S(26, Size), S(24, Size), cHDDMetal);
  KRect(X + S(3, Size), Y + S(4, Size), S(26, Size), S(24, Size), cHDDBorder);
  KBevel(X + S(5, Size), Y + S(6, Size), S(22, Size), S(18, Size), S(1, Size), True);
  PutPixel(X + S(4, Size), Y + S(5, Size), clBlack);
  PutPixel(X + S(27, Size), Y + S(5, Size), clBlack);
  PutPixel(X + S(4, Size), Y + S(26, Size), clBlack);
  PutPixel(X + S(27, Size), Y + S(26, Size), clBlack);
  KFillCircle(X + S(7, Size), Y + S(21, Size), S(1, Size), clGreen);
  KGlowRect(X + S(6, Size), Y + S(20, Size), S(3, Size), S(3, Size), S(1, Size), clGreen);
end;

procedure DrawIconRAM(X, Y, Size: Integer); stdcall;
var i, PinCount: Integer;
begin
  KGradientV(X + S(2, Size), Y + S(8, Size), S(28, Size), S(16, Size), cRAMPcbTop, cRAMPcbBot);
  KRect(X + S(2, Size), Y + S(8, Size), S(28, Size), S(16, Size), $00002200);
  KFill(X + S(4, Size),  Y + S(10, Size), S(5, Size), S(8, Size), cRAMChip);
  KFill(X + S(10, Size), Y + S(10, Size), S(5, Size), S(8, Size), cRAMChip);
  KFill(X + S(17, Size), Y + S(10, Size), S(5, Size), S(8, Size), cRAMChip);
  KFill(X + S(23, Size), Y + S(10, Size), S(5, Size), S(8, Size), cRAMChip);
  PinCount := S(8, Size);
  for i := 0 to PinCount do
    KLineV(X + S(3, Size) + (i * S(2, Size)), Y + S(21, Size), S(3, Size), cRAMPin);
end;

procedure DrawIconPaint(X, Y, Size: Integer); stdcall;
var CX, CY, RX, RY: Integer;
begin
  CX := X + Size div 2; CY := Y + Size div 2; RX := S(13, Size); RY := S(10, Size);
  KWood(X + S(2, Size), Y + S(5, Size), S(28, Size), S(22, Size), cWoodTop, cWoodBot);
  KEllipse(CX, CY, RX, RY, cWoodHole);
  KFillCircle(CX + S(7, Size), CY + S(2, Size), S(2, Size), clWhite);
  KFillCircle(CX - S(7, Size), CY - S(3, Size), S(2, Size), clRed);
  KFillCircle(CX - S(3, Size), CY - S(6, Size), S(2, Size), clYellow);
  KFillCircle(CX + S(3, Size), CY - S(6, Size), S(2, Size), clBlue);
  KFillCircle(CX - S(8, Size), CY + S(3, Size), S(2, Size), clGreen);
end;

procedure DrawIconMyComputer(X, Y, Size: Integer); stdcall;
begin
  KPanel3D(X + S(2, Size), Y + S(3, Size), S(20, Size), S(16, Size), True, cl3DFace);
  KGradientV(X + S(4, Size), Y + S(5, Size), S(16, Size), S(12, Size), cMonScreenTop, cMonScreenBot);
  KFill(X + S(9, Size), Y + S(19, Size), S(6, Size), S(3, Size), clGray);
  KFill(X + S(6, Size), Y + S(22, Size), S(12, Size), S(2, Size), clDkGray);
  KPanel3D(X + S(22, Size), Y + S(5, Size), S(8, Size), S(20, Size), True, cl3DFace);
  KLineH(X + S(24, Size), Y + S(8, Size), S(4, Size), clDkGray);
  PutPixel(X + S(26, Size), Y + S(18, Size), clRed);
end;

procedure DrawIconFiles(X, Y, Size: Integer); stdcall;
begin
  KMetal(X + S(5, Size), Y + S(2, Size), S(22, Size), S(28, Size), cFilesMetal);
  KRect(X + S(5, Size), Y + S(2, Size), S(22, Size), S(28, Size), clDkGray);
  KPanel3D(X + S(7, Size), Y + S(4, Size), S(18, Size), S(11, Size), True, cl3DFace);
  KFill(X + S(13, Size), Y + S(9, Size), S(6, Size), S(2, Size), clDkGray);
  KPanel3D(X + S(7, Size), Y + S(17, Size), S(18, Size), S(11, Size), True, cl3DFace);
  KFill(X + S(13, Size), Y + S(22, Size), S(6, Size), S(2, Size), clDkGray);
end;

procedure DrawIconSettings(X, Y, Size: Integer); stdcall;
var CX, CY, R, i: Integer;
begin
  CX := X + Size div 2; CY := Y + Size div 2; R := S(9, Size);
  for i := 0 to 7 do
    KFillCircle(CX + Round(R * Cos_Int(i * 45)), CY + Round(R * Sin_Int(i * 45)), S(3, Size), clGray);
  KGradientRadial(CX, CY, R, clSilver, clDkGray);
  KCircle(CX, CY, R, clBlack);
  KFillCircle(CX, CY, S(4, Size), clWhite);
  KCircle(CX, CY, S(4, Size), clDkGray);
end;

procedure DrawIconSettings1(X, Y, Size: Integer); stdcall;
var CX, CY, R, i, Angle, Px, Py: Integer;
begin
  CX := X + Size div 2; CY := Y + Size div 2; R := (Size div 2) - (Size div 8);
  for i := 0 to 7 do
  begin
    Angle := i * 45;
    Px := CX + (R * Cos_Int(Angle)) div 10000;
    Py := CY + (R * Sin_Int(Angle)) div 10000;
    KFillCircle(Px, Py, Size div 10, $00707070);
  end;
  KFillCircle(CX, CY, R - (Size div 12), $00909090);
  KCircle(CX, CY, R - (Size div 12), $00505050);
  KFillCircle(CX, CY, Size div 10, clWhite);
  KCircle(CX, CY, Size div 10, $00505050);
end;

procedure DrawIconTxt(X, Y, Size: Integer); stdcall;
var i: Integer;
begin
  KShadowRect(X + S(5, Size), Y + S(2, Size), S(22, Size), S(28, Size), S(2, Size), clWhite);
  KRect(X + S(5, Size), Y + S(2, Size), S(22, Size), S(28, Size), $00D0D0D0);
  KFillTriangle(X + S(21, Size), Y + S(2, Size), X + S(27, Size), Y + S(8, Size), X + S(21, Size), Y + S(8, Size), $00E0E0E0);
  KLine(X + S(21, Size), Y + S(2, Size), X + S(27, Size), Y + S(8, Size), $00B0B0B0);
  for i := 0 to 5 do
    KLineH(X + S(8, Size), Y + S(11, Size) + (i * S(3, Size)), S(15, Size), $00808080);
end;

procedure DrawIconWav(X, Y, Size: Integer); stdcall;
begin
  KGradientV(X + S(4, Size), Y + S(3, Size), S(24, Size), S(26, Size), cWavBgTop, cWavBgBot);
  KRect(X + S(4, Size), Y + S(3, Size), S(24, Size), S(26, Size), $00200020);
  KFill(X + S(7, Size),  Y + S(16, Size), S(2, Size), S(8, Size),  clCyan);
  KFill(X + S(11, Size), Y + S(10, Size), S(2, Size), S(14, Size), clCyan);
  KFill(X + S(15, Size), Y + S(6, Size),  S(2, Size), S(18, Size), clCyan);
  KFill(X + S(19, Size), Y + S(12, Size), S(2, Size), S(12, Size), clCyan);
  KFill(X + S(23, Size), Y + S(18, Size), S(2, Size), S(6, Size),  clCyan);
end;

procedure DrawIconBmp(X, Y, Size: Integer); stdcall;
begin
  DrawIconTxt(X, Y, Size);
  KGradientV(X + S(8, Size), Y + S(14, Size), S(16, Size), S(12, Size), $000080FF, $00004080);
  KFillCircle(X + S(12, Size), Y + S(17, Size), S(2, Size), clYellow);
  KFillTriangle(X + S(9, Size), Y + S(24, Size), X + S(14, Size), Y + S(19, Size), X + S(18, Size), Y + S(24, Size), clGreen);
end;

procedure DrawIconExe(X, Y, Size: Integer); stdcall;
begin
  KPanel3D(X + S(3, Size), Y + S(3, Size), S(26, Size), S(26, Size), True, cl3DFace);
  KTitleBar(X + S(5, Size), Y + S(5, Size), S(22, Size), S(5, Size), True, '');
  KSunken(X + S(5, Size), Y + S(11, Size), S(22, Size), S(16, Size), cExeSunken);
  KFillCircle(X + S(16, Size), Y + S(19, Size), S(4, Size), clLtGray);
  KCircle(X + S(16, Size), Y + S(19, Size), S(2, Size), clBlack);
end;

procedure DrawIconBin(X, Y, Size: Integer); stdcall;
begin
  KFill(X + S(4, Size), Y + S(3, Size), S(24, Size), S(26, Size), clBlack);
  KRect(X + S(4, Size), Y + S(3, Size), S(24, Size), S(26, Size), cBinBorder);
  KDots(X + S(7, Size), Y + S(6, Size), S(18, Size), S(20, Size), S(3, Size), cBinDots);
end;

procedure DrawIconRecycleBin(X, Y, Size: Integer); stdcall;
begin
  KGradientV(X + S(6, Size), Y + S(10, Size), S(20, Size), S(18, Size), clSilver, clDkGray);
  KBevel(X + S(6, Size), Y + S(10, Size), S(20, Size), S(18, Size), S(1, Size), True);
  KFillEllipse(X + S(16, Size), Y + S(10, Size), S(11, Size), S(3, Size), clGray);
  KFillTriangle(X + S(16, Size), Y + S(13, Size), X + S(12, Size), Y + S(20, Size), X + S(20, Size), Y + S(20, Size), cRecycleArrow);
end;

procedure DrawIconRecycleBin1(X, Y, Size: Integer); stdcall;
var
  L, T, W, H, i, LineX: Integer;
begin
  L := X + (Size div 5);
  T := Y + (Size div 4);
  W := Size - (2 * (Size div 5));
  H := Size - (Size div 3);

  { Kapak }
  KFill(L - 2, T, W + 4, Size div 12, $00707070);
  KFill(X + Size div 2 - Size div 10, T - Size div 14, Size div 5, Size div 14, $00707070);

  { Govde (trapez hissi icin dikdortgen yeterli) }
  KFill(L, T + Size div 12, W, H, $00909090);
  KRect(L, T + Size div 12, W, H, $00505050);

  for i := 0 to 2 do
  begin
    LineX := L + (W div 4) * (i + 1);
    KLineV(LineX, T + Size div 12 + 4, H - 8, $00606060);
  end;
end;


procedure DrawIconNetwork(X, Y, Size: Integer); stdcall;
var CX, CY: Integer;
begin
  CX := X + Size div 2; CY := Y + Size div 2;
  KGradientRadial(CX, CY, S(11, Size), cNetworkGlobe, $00800000);
  KEllipse(CX, CY, S(11, Size), S(4, Size), clWhite);
  KLineV(CX, CY - S(11, Size), S(22, Size), clWhite);
  KCircle(CX, CY, S(11, Size), clNavy);
end;

procedure DrawIconZip(X, Y, Size: Integer); stdcall;
var i: Integer;
begin
  DrawIconFolder(X, Y, Size);
  KFill(X + S(13, Size), Y + S(8, Size), S(6, Size), S(20, Size), clDkGray);
  for i := 0 to 6 do
    KLineH(X + S(13, Size) + ((i mod 2) * S(3, Size)), Y + S(9, Size) + (i * S(2, Size)), S(3, Size), clWhite);
  KFill(X + S(14, Size), Y + S(22, Size), S(4, Size), S(5, Size), cZipZipper);
end;

procedure DrawIconTerminal(X, Y, Size: Integer); stdcall;
begin
  KFill(X + S(2, Size), Y + S(4, Size), S(28, Size), S(24, Size), clBlack);
  KRect(X + S(2, Size), Y + S(4, Size), S(28, Size), S(24, Size), clGray);
  KFill(X + S(3, Size), Y + S(5, Size), S(26, Size), S(4, Size), clDkGray);
  KLine(X + S(6, Size), Y + S(13, Size), X + S(10, Size), Y + S(16, Size), clLime);
  KLine(X + S(10, Size), Y + S(16, Size), X + S(6, Size), Y + S(19, Size), clLime);
  KLineH(X + S(12, Size), Y + S(19, Size), S(5, Size), clLime);
end;

procedure DrawIconDoc(X, Y, Size: Integer); stdcall;
begin
  DrawIconTxt(X, Y, Size);
  KFillTriangle(X + S(5, Size), Y + S(2, Size), X + S(15, Size), Y + S(2, Size), X + S(5, Size), Y + S(12, Size), cDocRed);
end;

{ =========================================================
  HTTP SERVER �KONU (Web Sunucusu Kasa + LED)
  ========================================================= }
procedure DrawIconHttpServer(X, Y, Size: Integer); stdcall;
begin
  // �st Kasa (Server Blade 1)
  KGradientV(X + S(3, Size), Y + S(4, Size), S(26, Size), S(10, Size), $00505050, cServerRack);
  KRect(X + S(3, Size), Y + S(4, Size), S(26, Size), S(10, Size), clBlack);
  // Hava kanallar� / Fan Izgaras�
  KLineH(X + S(6, Size), Y + S(7, Size), S(10, Size), clGray);
  KLineH(X + S(6, Size), Y + S(9, Size), S(10, Size), clGray);
  // LED'ler
  KFillCircle(X + S(21, Size), Y + S(8, Size), S(1, Size), cServerLedGreen);
  KGlowRect(X + S(20, Size), Y + S(7, Size), S(3, Size), S(3, Size), S(1, Size), cServerLedGreen);
  KFillCircle(X + S(25, Size), Y + S(8, Size), S(1, Size), cServerLedBlue);

  // Alt Kasa (Server Blade 2)
  KGradientV(X + S(3, Size), Y + S(17, Size), S(26, Size), S(10, Size), $00505050, cServerRack);
  KRect(X + S(3, Size), Y + S(17, Size), S(26, Size), S(10, Size), clBlack);
  // Hava kanallar�
  KLineH(X + S(6, Size), Y + S(20, Size), S(10, Size), clGray);
  KLineH(X + S(6, Size), Y + S(22, Size), S(10, Size), clGray);
  // LED'ler
  KFillCircle(X + S(21, Size), Y + S(21, Size), S(1, Size), cServerLedGreen);
  KGlowRect(X + S(20, Size), Y + S(20, Size), S(3, Size), S(3, Size), S(1, Size), cServerLedGreen);
  KFillCircle(X + S(25, Size), Y + S(21, Size), S(1, Size), clYellow);
end;

{ =========================================================
  WEB BROWSER �KONU (K�resel �nternet / D�nya + Orbit)
  ========================================================= }
procedure DrawIconWebBrowser(X, Y, Size: Integer); stdcall;
var
  CX, CY, R: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := S(12, Size);

  // Mavi Okyanus K�resi
  KGradientRadial(CX, CY, R, $00FFAA44, cBrowserGlobe);
  KCircle(CX, CY, R, $00803000);

  // Paralel ve Meridyen �izgileri (D�nya Izgaras�)
  KEllipse(CX, CY, R, S(4, Size), clWhite);
  KEllipse(CX, CY, S(5, Size), R, clWhite);
  KLineH(CX - R, CY, R * 2, clWhite);
  KLineV(CX, CY - R, R * 2, clWhite);

  // E�ik �nternet Y�r�nge Halkas� (Orbit Ring)
  KEllipse(CX + S(1, Size), CY - S(1, Size), S(14, Size), S(6, Size), clYellow);
  
  // K���k Uydu / Pusula Noktas�
  KFillCircle(CX + S(9, Size), CY - S(4, Size), S(2, Size), cBrowserCompass);
end;

procedure DrawIconSysInfo(X, Y, Size: Integer); stdcall;
var
  CX, CY, R: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := (Size div 2) - (Size div 10);

  KFillCircle(CX, CY, R, $004080D0);
  KCircle(CX, CY, R, $00204870);

  KFillCircle(CX, CY - (R div 2), Size div 14, clWhite);
  KFill(CX - (Size div 14), CY - (R div 6), Size div 7, (R * 2) div 3, clWhite);
end;


{ =========================================================
  SAAT �KONU (Analog Saat)
  ========================================================= }
procedure DrawIconClock(X, Y, Size: Integer); stdcall;
var
  CX, CY, R, i, Px, Py: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := (Size div 2) - S(2, Size);

  // Saat G�vdesi ve �er�eve
  KGradientRadial(CX, CY, R, cClockBodyTop, cClockBodyBot);
  KCircle(CX, CY, R, cClockBorder);
  KCircle(CX, CY, R - 1, clWhite);

  // Saat ��aret�ileri (12, 3, 6, 9 Noktalar�)
  for i := 0 to 3 do
  begin
    Px := CX + Round((R - S(3, Size)) * Cos_Int(i * 90));
    Py := CY + Round((R - S(3, Size)) * Sin_Int(i * 90));
    KFillCircle(Px, Py, S(1, Size), cClockBorder);
  end;

  // Akrep (10 y�n�n� g�sterir)
  KLine(CX, CY, CX - S(4, Size), CY - S(4, Size), cClockHandHour);
  // Yelkovan (2 y�n�n� g�sterir)
  KLine(CX, CY, CX + S(7, Size), CY - S(5, Size), cClockHandMin);
  // Saniye �bresi
  KLine(CX, CY, CX + S(2, Size), CY + S(8, Size), cClockHandSec);

  // Orta G�bek
  KFillCircle(CX, CY, S(2, Size), cClockHandSec);
end;

{ =========================================================
  OYUN �KONU (Gamepad / Oyun Kolu)
  ========================================================= }
procedure DrawIconGames(X, Y, Size: Integer); stdcall;
var
  L, T, W, H, CX, CY: Integer;
begin
  L := X + S(2, Size);
  T := Y + S(8, Size);
  W := Size - S(4, Size);
  H := Size - S(14, Size);

  // Gamepad Ana G�vde (Yuvarlat�lm�� G�vde Hissi)
  KGradientV(L, T, W, H, cGamePadBodyTop, cGamePadBodyBot);
  KRect(L, T, W, H, clBlack);

  // Sol D-Pad (Y�n Tu�lar�)
  CX := L + S(6, Size);
  CY := T + (H div 2);
  KFill(CX - S(1, Size), CY - S(4, Size), S(3, Size), S(9, Size), cGamePadDpad); // Dikey
  KFill(CX - S(4, Size), CY - S(1, Size), S(9, Size), S(3, Size), cGamePadDpad); // Yatay

  // Sa� Aksiyon Tu�lar� (X, Y, A, B D�zeni)
  CX := L + W - S(7, Size);
  CY := T + (H div 2);
  KFillCircle(CX, CY - S(3, Size), S(1, Size), cGamePadBtnYellow); // �st
  KFillCircle(CX + S(3, Size), CY, S(1, Size), cGamePadBtnRed);    // Sa�
  KFillCircle(CX, CY + S(3, Size), S(1, Size), cGamePadBtnGreen);  // Alt
  KFillCircle(CX - S(3, Size), CY, S(1, Size), cGamePadBtnBlue);   // Sol

  // Ortadaki Select/Start Tu�lar�
  KLineH(L + (W div 2) - S(3, Size), CY, S(2, Size), clGray);
  KLineH(L + (W div 2) + S(1, Size), CY, S(2, Size), clGray);
end;


procedure DrawIconCalc(X, Y, Size: Integer); stdcall;
var
  L, T, W, H, i, j, BtnW, BtnH, BX, BY: Integer;
begin
  L := X + (Size div 5);
  T := Y + (Size div 10);
  W := Size - (2 * (Size div 5));
  H := Size - (Size div 5);

  KFill(L, T, W, H, $00404040);
  KRect(L, T, W, H, $00202020);

  { Ekran }
  KFill(L + 3, T + 3, W - 6, H div 5, $00A0D090);

  { Tuslar (3x3 grid) }
  BtnW := (W - 8) div 3;
  BtnH := (H - (H div 5) - 10) div 3;
  for i := 0 to 2 do
    for j := 0 to 2 do
    begin
      BX := L + 3 + i * (BtnW + 1);
      BY := T + (H div 5) + 6 + j * (BtnH + 1);
      KFill(BX, BY, BtnW - 1, BtnH - 1, $00D0D0D0);
    end;
end;


procedure DrawIconCPU(X, Y, Size: Integer); stdcall;
var
  i: Integer;
begin
  // Ye�il Ye�il PCB / Taban
  KGradientV(X + S(4, Size), Y + S(4, Size), S(24, Size), S(24, Size), $00008800, $00004400);
  KRect(X + S(4, Size), Y + S(4, Size), S(24, Size), S(24, Size), $00002200);

  // Metal Is� Da��t�c� (IHS) �ekirdek
  KGradientV(X + S(9, Size), Y + S(9, Size), S(14, Size), S(14, Size), clSilver, clDkGray);
  KRect(X + S(9, Size), Y + S(9, Size), S(14, Size), S(14, Size), clGray);

  // D�� Alt�n Bacaklar / Pinler
  for i := 0 to 4 do
  begin
    // �st ve Alt Pinler
    PutPixel(X + S(6 + i * 4, Size), Y + S(2, Size), $00FFD700);
    PutPixel(X + S(6 + i * 4, Size), Y + S(29, Size), $00FFD700);
    // Sol ve Sa� Pinler
    PutPixel(X + S(2, Size), Y + S(6 + i * 4, Size), $00FFD700);
    PutPixel(X + S(29, Size), Y + S(6 + i * 4, Size), $00FFD700);
  end;
end;


procedure DrawIconUSB(X, Y, Size: Integer); stdcall;
begin
  // Metal Konnekt�r Ucu (�st)
  KFill(X + S(11, Size), Y + S(3, Size), S(10, Size), S(7, Size), clSilver);
  KRect(X + S(11, Size), Y + S(3, Size), S(10, Size), S(7, Size), clGray);
  // USB Delikleri
  KFill(X + S(13, Size), Y + S(5, Size), S(2, Size), S(2, Size), clDkGray);
  KFill(X + S(17, Size), Y + S(5, Size), S(2, Size), S(2, Size), clDkGray);

  // Plastik G�vde (Alt)
  KGradientV(X + S(9, Size), Y + S(10, Size), S(14, Size), S(19, Size), $00505050, $00202020);
  KRect(X + S(9, Size), Y + S(10, Size), S(14, Size), S(19, Size), clBlack);

  // Durum LED'i
  KFillCircle(X + S(16, Size), Y + S(24, Size), S(1, Size), clCyan);
  KGlowRect(X + S(15, Size), Y + S(23, Size), S(3, Size), S(3, Size), S(1, Size), clCyan);
end;

procedure DrawIconWifi(X, Y, Size: Integer); stdcall;
var
  CX, CY: Integer;
begin
  CX := X + Size div 2;
  CY := Y + S(24, Size);

  // Merkez Sinyal Noktas�
  KFillCircle(CX, CY, S(2, Size), clLime);

  // Sinyal Dalgalar� (Halkalar)
  KCircle(CX, CY, S(6, Size), clLime);
  KCircle(CX, CY, S(11, Size), clLime);
  KCircle(CX, CY, S(16, Size), clLime);

  // Alt Taraf� Temizleyerek Sadece �st Yelpaze Hissini Ver
  KFill(X, CY + 1, Size, S(8, Size), clBlack); // Varsa arka plan renginizle kapat�n
end;

{ =========================================================
  YAZICI �KONU (Printer)
  ========================================================= }
procedure DrawIconPrinter(X, Y, Size: Integer); stdcall;
begin
  // 1. �stten ��kan Ka��t
  KFill(X + S(8, Size), Y + S(2, Size), S(16, Size), S(10, Size), clWhite);
  KRect(X + S(8, Size), Y + S(2, Size), S(16, Size), S(10, Size), clGray);
  // Ka��t �zerindeki hayali yaz�lar
  KLineH(X + S(11, Size), Y + S(5, Size), S(10, Size), clLtGray);
  KLineH(X + S(11, Size), Y + S(8, Size), S(8, Size), clLtGray);

  // 2. Yaz�c� G�vdesi (Kasa)
  KGradientV(X + S(3, Size), Y + S(10, Size), S(26, Size), S(12, Size), $00E0E0E0, $00909090);
  KRect(X + S(3, Size), Y + S(10, Size), S(26, Size), S(12, Size), clDkGray);

  // Ka��t ��k�� Yuvas� (Slot)
  KFill(X + S(6, Size), Y + S(18, Size), S(20, Size), S(3, Size), clBlack);

  // Durum LED'i ve G�� D��mesi
  KFillCircle(X + S(6, Size), Y + S(13, Size), S(1, Size), clLime);
  KGlowRect(X + S(5, Size), Y + S(12, Size), S(3, Size), S(3, Size), S(1, Size), clLime);

  // 3. Alttan ��kan / Tepsideki Ka��t
  KFill(X + S(7, Size), Y + S(20, Size), S(18, Size), S(8, Size), clWhite);
  KRect(X + S(7, Size), Y + S(20, Size), S(18, Size), S(8, Size), clGray);
  KLineH(X + S(10, Size), Y + S(23, Size), S(12, Size), $004080C0);
end;

{ =========================================================
  KULLANICI �KONU (User / Profile)
  ========================================================= }
procedure DrawIconUser(X, Y, Size: Integer); stdcall;
var
  CX, CY, R: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;

  // Arka Plan Mavi Daire
  R := (Size div 2) - S(2, Size);
  KGradientRadial(CX, CY, R, $00FF8000, $00800000);
  KCircle(CX, CY, R, clNavy);

  // Kafa (Yuvarlak)
  KFillCircle(CX, CY - S(4, Size), S(5, Size), clWhite);

  // Omuzlar / G�vde (Yar�m Daire / Elips)
  KEllipse(CX, CY + S(10, Size), S(9, Size), S(6, Size), clWhite);
  KFillCircle(CX, CY + S(8, Size), S(7, Size), clWhite);
end;

{ =========================================================
  K�L�T �KONU (Lock / Security)
  ========================================================= }
procedure DrawIconLock(X, Y, Size: Integer); stdcall;
var
  CX, CY: Integer;
begin
  CX := X + Size div 2;

  // 1. �st Kilit Halkas� (Shackle)
  KCircle(CX, Y + S(11, Size), S(6, Size), cRAMPin);
  KCircle(CX, Y + S(11, Size), S(5, Size), cRAMPin);
  // Halkan�n alt k�s�mlar�n� temizleyip kilit g�vdesine oturtma
  KFill(CX - S(3, Size), Y + S(11, Size), S(7, Size), S(5, Size), clBlack); // Arka plan ile �rtme

  // 2. Kilit G�vdesi (Sar� / Alt�n Gradyan)
  KGradientV(X + S(6, Size), Y + S(13, Size), S(20, Size), S(15, Size), $0000FFFF, $000080FF);
  KRect(X + S(6, Size), Y + S(13, Size), S(20, Size), S(15, Size), $00004080);
  KBevel(X + S(7, Size), Y + S(14, Size), S(18, Size), S(13, Size), S(1, Size), True);

  // 3. Anahtar Deli�i
  CY := Y + S(19, Size);
  KFillCircle(CX, CY, S(2, Size), clBlack);
  KFillTriangle(CX - S(1, Size), CY, CX + S(1, Size), CY, CX, CY + S(4, Size), clBlack);
end;

{ =========================================================
  E-POSTA �KONU (Mail / Zarf)
  ========================================================= }
procedure DrawIconMail(X, Y, Size: Integer); stdcall;
var
  L, T, W, H: Integer;
begin
  L := X + S(3, Size);
  T := Y + S(7, Size);
  W := Size - S(6, Size);
  H := Size - S(14, Size);

  // Zarf G�vdesi (Krem / Beyaz Gradyan)
  KGradientV(L, T, W, H, clWhite, $00E0E0E0);
  KRect(L, T, W, H, clGray);

  // Zarf Kapak �izgileri (�stten Ortaya Katlanma V �ekli)
  KLine(L, T, X + (Size div 2), T + (H div 2), clDkGray);
  KLine(L + W - 1, T, X + (Size div 2), T + (H div 2), clDkGray);

  // Alt �apraz Katlanma �izgileri
  KLine(L, T + H, L + (W div 3), T + (H div 2), $00B0B0B0);
  KLine(L + W - 1, T + H, L + W - (W div 3), T + (H div 2), $00B0B0B0);
end;




{ =========================================================
  ANA �KON DA�ITICI (G�NCELLEND�)
  ========================================================= }
procedure DrawIcon(X, Y, Size: Integer; IconType: TIconType); stdcall;
begin
  case IconType of
    itFolder:      DrawIconFolder(X, Y, Size);
    itPictures:    DrawIconPictures(X, Y, Size);
    itMusic:       DrawIconMusic(X, Y, Size);
    itHDD:         DrawIconHDD(X, Y, Size);
    itRAM:         DrawIconRAM(X, Y, Size);
    itPaint:       DrawIconPaint(X, Y, Size);
    itMyComputer:  DrawIconMyComputer(X, Y, Size);
    itFiles:       DrawIconFiles(X, Y, Size);
    itSettings:    DrawIconSettings(X, Y, Size);
    itSettings1:   DrawIconSettings1(X, Y, Size);
    itTxt:         DrawIconTxt(X, Y, Size);
    itWav:         DrawIconWav(X, Y, Size);
    itBmp:         DrawIconBmp(X, Y, Size);
    itExe:         DrawIconExe(X, Y, Size);
    itBin:         DrawIconBin(X, Y, Size);
    itRecycleBin:  DrawIconRecycleBin(X, Y, Size);
    itRecycleBin1: DrawIconRecycleBin1(X, Y, Size);
    itNetwork:     DrawIconNetwork(X, Y, Size);
    itZip:         DrawIconZip(X, Y, Size);
    itTerminal:    DrawIconTerminal(X, Y, Size);
    itDoc:         DrawIconDoc(X, Y, Size);
    itHttpServer:  DrawIconHttpServer(X, Y, Size);
    itWebBrowser:  DrawIconWebBrowser(X, Y, Size);
    itCalculator:  DrawIconCalc(X, Y, Size);
    itInfo:        DrawIconSysInfo(X, Y, Size);
    itGames:       DrawIconGames(X, Y, Size); // <-- Eklenen
    itClock:       DrawIconClock(X, Y, Size); // <-- Eklenen
    itCDROM:       DrawIconCDROM(X, Y, Size);
    itCPU:         DrawIconCPU(X, Y, Size);
    itUSB:         DrawIconUSB(X, Y, Size);
    itWifi:        DrawIconWifi(X, Y, Size);
    itPrinter:     DrawIconPrinter(X, Y, Size);
    itUser:        DrawIconUser(X, Y, Size);
    itLock:        DrawIconLock(X, Y, Size);
    itMail:        DrawIconMail(X, Y, Size);
  end;
end;



procedure Test_DrawAllIcons(StartX, StartY, IconSize: Integer);
const
  Cols = 5;         // Her sat�rdaki ikon say�s�
  SpacingX = 80;    // �konlar aras� yatay mesafe
  SpacingY = 70;    // �konlar aras� dikey mesafe
var
  Icon: TIconType;
  Index, Col, Row: Integer;
  CurX, CurY: Integer;
begin
  Index := 0;

  for Icon := Low(TIconType) to High(TIconType) do
  begin
    // Izgara koordinatlar�n� hesapla
    Col := Index mod Cols;
    Row := Index div Cols;

    CurX := StartX + (Col * SpacingX);
    CurY := StartY + (Row * SpacingY);

    // �kon arka plan�na hafif bir kart/�er�eve �iz (opsiyonel)
    KFillAlpha(CurX - 4, CurY - 4, IconSize + 8, IconSize + 22, clBlack, 40);

    // �konu �iz
    DrawIcon(CurX, CurY, IconSize, Icon);

    // �konun alt�na ismini yaz
    KStrCentered(CurX - 4, CurY + IconSize + 4, IconSize + 8, IconNames[Icon], clWhite);

    Inc(Index);
  end;
end;

end.

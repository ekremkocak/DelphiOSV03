unit GUI;

interface

uses
  SysUtils, Memory, Draw32,DrawIcons, Vesa, Mouse, Math,KernelFont;

const
  FORM_WIDTH      = 640;
  FORM_HEIGHT     = 480;
  HEADER_HEIGHT   = 20;
  BORDER_SIZE     = 5;
  MIN_FORM_WIDTH  = 120;
  MIN_FORM_HEIGHT = 80;
  MAX_FORM_WIDTH  = 1200;
  MAX_FORM_HEIGHT = 900;
  SCROLLBAR_SIZE  = 16;
  SYSBUTTON_WIDTH = 16;
  FONT_W         = 8;
  FONT_H         = 8;
  HEADER_H       = 24;


  C_TITLE_A1    = $00000080;
  C_TITLE_A2    = $00000040;
  C_TITLE_I1    = $00808080;
  C_TITLE_I2    = $00606060;
  C_BORDER      = $00404040;
  C_WHITE       = $00FFFFFF;
  C_BLACK       = $00000000;
  C_BTN_FACE    = $00D4D0C8;
  C_BTN_PRESS   = $00B0B0B0;
  C_EDIT_BG     = $00FFFFFF;
  C_EDIT_BD     = $00808080;
  C_SHADOW      = $00404040;
  C_CLOSE_N     = $00FF0000;
  C_RZ_GRIP     = $00808080;

  C_FORM_BG    = $00ECECEC;

type
  PObject = ^TObject;
  PForm   = ^TForm;

  TNotifyEvent = procedure(Sender: PObject);

  TDestroyProc = procedure(Sender: PObject);
  PDestroySlot = ^TDestroySlot;
  TDestroySlot = object
    Proc: TDestroyProc;
    Next: PDestroySlot;
    procedure Fire(Sender: PObject);
  end;

  TMouseProc = procedure(Sender: PObject; AX, AY: Integer; Btn: Byte);
  PMouseSlot = ^TMouseSlot;
  TMouseSlot = object
    Proc: TMouseProc;
    Next: PMouseSlot;
    procedure Fire(Sender: PObject; AX, AY: Integer; Btn: Byte);
  end;

  TPaintProc = procedure(Sender: PObject; AX, AY: Integer);
  PPaintSlot = ^TPaintSlot;
  TPaintSlot = object
    Proc: TPaintProc;
    Next: PPaintSlot;
    procedure Fire(Sender: PObject; AX, AY: Integer);
  end;

  TKeyDownProc = procedure(Sender: PObject; Key: Word);
  PKeyDownSlot = ^TKeyDownSlot;
  TKeyDownSlot = object
    Proc: TKeyDownProc;
    Next: PKeyDownSlot;
    procedure Fire(Sender: PObject; Key: Word);
  end;

  { ScrollBar formun i?inde entegre }
  TScrollState = record
    Visible: Boolean;
    Pos, Min, Max, PageSize: Integer;
    Left, Top, Width, Height: Integer;
    ThumbPos, ThumbSize: Integer;
    TrackStart, TrackLen: Integer;
    Dragging: Boolean;
    DragStart, DragPosStart: Integer;
    Arrow1Pressed, Arrow2Pressed: Boolean;
    Page1Pressed, Page2Pressed: Boolean;
  end;

  { Delphi/Lazarus'taki TAlign ile ayni mantik: bir component'in kendi
    parent'inin (Form ya da baska bir component) client alani icinde
    otomatik olarak nereye yaslanacagini belirler. }
  TAlign = (alNone, alTop, alBottom, alLeft, alRight, alClient);

  TObject = Object
  private
    FOnDblClick: PMouseSlot;
    FOnMouseDown: PMouseSlot;
    FOnMouseUp: PMouseSlot;
    FOnMouseMove: PMouseSlot;
    FOnPaint: PPaintSlot;
    FOnKeyDown: PKeyDownSlot;
    FOnKeyUp: PKeyDownSlot;
    FOnDestroy: PDestroySlot;
  Public
    ClassType:Pointer;
    Handle: LongWord;
    ZIndex: Integer;
    Caption: array[0..255] of Char;
    Left, Top, Width, Height: Integer;
    Align: TAlign;
    Color: TColor;
    BorderColor: TColor;
    BorderWidth: Integer;
    Visible: Boolean;
    Cursor: Integer;
    ShowCaption: Boolean;
    Data:LongWord;
    Control: PObject;
    Parent: PObject;
    Next: PObject;
    Child: PObject;
    Previous: PObject;
    Tag: Integer;
    Enabled: Boolean;
    Hover: Boolean;
    Focused : Boolean;
    CanFocus : Boolean;
    TabStop : Boolean;
    function AbsLeft: Integer;
    function AbstOP: Integer;
    procedure AddObject(Sender: PObject);
    procedure FreeEvents;
    procedure FireKeyDown(Key: Word);
    procedure FireKeyUp(Key: Word);
    procedure FireDblClick(AX, AY: Integer; Btn: Byte);
    procedure FireMouseDown(AX, AY: Integer; Btn: Byte);
    procedure FireMouseUp(AX, AY: Integer; Btn: Byte);
    procedure FireMouseMove(AX, AY: Integer; Btn: Byte);
    procedure FirePaint(AX, AY: Integer);
    procedure FireDestroy(Sender: PObject);
    procedure BindKeyDown(P: TKeyDownProc);
    procedure BindKeyUp(P: TKeyDownProc);
    procedure BindDblClick(P: TMouseProc);
    procedure BindMouseDown(P: TMouseProc);
    procedure BindMouseUp(P: TMouseProc);
    procedure BindMouseMove(P: TMouseProc);
    procedure BindPaint(P: TPaintProc);
    procedure BindDestroy(P: TDestroyProc);
  end;

  TFormInteractionState = (fisIdle, fisMoving, fisResizing);
  TResizeCorner = (rcNone, rcLeft, rcRight, rcTop, rcBottom,
                   rcTopLeft, rcTopRight, rcBottomLeft, rcBottomRight);
  TBorderStyle = (bsNone, bsDialog, bsWindow);

  TPosition = (poDesigned, poDefault, poDefaultPosOnly, poDefaultSizeOnly,
    poScreenCenter, poDesktopCenter, poMainFormCenter, poOwnerFormCenter);


  TWndProc = procedure(hWnd: LongWord; Msg, WParam, LParam: LongWord);

  TForm = Object(TObject)
  private
     FPosition:TPosition;
     procedure SetPosition(APosition: TPosition);
  Public
    Hint: array[0..255] of char;
    Modal: Boolean;
    ActiveControl: PObject;
    BorderStyle: TBorderStyle;
    VScroll: TScrollState;
    HScroll: TScrollState;
    ShowHeader: Boolean;
    ShowSysButtons: Boolean;
    Maximized: Boolean;
    Minimized: Boolean;
    NormalBounds: TRect;
    OwnerProcess : LongWord;
    FBtnHot:Integer;
    procedure Show;
    procedure Hide;
    procedure SetFocus(C: PObject);
    procedure FocusNext;
    property Position: TPosition read FPosition write FPosition;//SetPosition;
  end;



  type
  PPopupMenuItem = ^TPopupMenuItem;
  TPopupMenuClickProc = procedure(Item: PPopupMenuItem);

  TPopupMenuItem = record
    Caption:      array[0..127] of Char;
    Enabled:      Boolean;
    Checked:      Boolean;
    Separator:    Boolean;
    Tag:          Integer;
    OnClick:      TPopupMenuClickProc;
  end;

  PPopupMenu = ^TPopupMenu;
  TPopupMenu = object
  public
    Items:         PPCharArray;   { PPopupMenuItem dizisi }
    ItemCount:     Integer;
    ItemCapacity:  Integer;
    X, Y:          Integer;
    Width:         Integer;
    ItemHeight:    Integer;
    Visible:       Boolean;
    SelectedIndex: Integer;

    procedure AddItem(const ACaption: PChar; AOnClick: TPopupMenuClickProc; AEnabled: Boolean = True);
    procedure AddSeparator;
    procedure Show(AX, AY: Integer);
    procedure Hide;
    procedure Draw;
    function  HitTest(MX, MY: Integer): Integer;  { -1 = d��ar� }
    procedure MouseDown(MX, MY: Integer; Btn: Byte);
    procedure MouseMove(MX, MY: Integer);
  end;

  TWinManager = object
  private
  public
    ObjectList: PObject;
    ActiveForm: PForm;
    ActivePopup: PPopupMenu;
    ActiveMenuBar: PObject;
    procedure Init;
    function  AddForm(AObj: PObject): Boolean;
    procedure RemoveForm(F: PForm);
    procedure BringToFront(AObj: PForm);
    procedure FindActiveForm(X, Y: Integer);
    function  FormResizing(MouseX, MouseY: Integer; MouseState: Byte): Boolean;
    function  CountObject: Integer;
    procedure FreeObject(AObj: PObject);
    procedure PaintAll;
    procedure MouseDown(MX, MY: Integer; Btn: Byte);
    procedure MouseUp(MX, MY: Integer; Btn: Byte);
    procedure MouseMove(MX, MY: Integer; Btn: Byte);
    procedure DblClick(MX, MY: Integer; Btn: Byte);
    procedure KeyDown(Key: Word);
    procedure KeyUp(Key: Word);

    procedure ProcessMessages(PM: Boolean = False);
  end;

var
  WinManager: TWinManager;
  LastHitObject: PObject = Nil;
  Cursor: Integer;
  InteractionState: TFormInteractionState = fisIdle;
  ResizeCorner: TResizeCorner;
  FormOffset: TPoint;
  FreeMemory: Integer = 0;
  MouseCapture: PObject = nil;
  Wall_Data: SysUtils.PByteArray;

  procedure GetAbsoluteRect(Obj: PObject; out AX, AY, AWidth, AHeight: Integer);

function CreateForm(const ACaption: PChar; ALeft, ATop, AWidth, AHeight: Integer;BorderStyle: TBorderStyle=bsWindow): PForm;


{ Bir nesnenin Align degerini calisma zamaninda degistirir ve ilgili formun
  butun agacini (header/scrollbar dahil) yeniden hizalar. }
procedure SetAlign(Obj: PObject; AAlign: TAlign);

procedure RelayoutForm(F: PForm);
function FindRootForm(Obj: PObject): PForm;
procedure AutoUpdateScrollBars(Form: PForm);
procedure UpdateFormScrollLayout(Form: PForm);
function ScreenCenterX(AWidth: Integer): Integer;
function ScreenCenterY(AHeight: Integer): Integer;
procedure FormCenterScreen(F: PForm);

function IsMouseOverAnyForm(X, Y: Integer): Boolean;

implementation

Uses GUIControls,DeskTops,Messages,DirectoryView,TaskBar,ProcessMgr;



var
  Form1: PForm;

  

{=============================================================================}
{ Yard?mc?lar                                                                 }
{=============================================================================}

function ScreenCenterX(AWidth: Integer): Integer;
begin
  Result := (SCREEN_WIDTH - AWidth) div 2;
end;

function ScreenCenterY(AHeight: Integer): Integer;
begin
  Result := (SCREEN_HEIGHT - AHeight) div 2;
end;

procedure FormCenterScreen(F: PForm);
begin
  F^.Left := (SCREEN_WIDTH - F^.Width) div 2;
  F^.Top  := (SCREEN_HEIGHT - F^.Height) div 2;
end;


procedure TForm.SetPosition(APosition: TPosition);
begin
  if  Position <> APosition then
  begin
     Position:= APosition;

     if Position= poScreenCenter then
     FormCenterScreen(@Self);

  end;

end;


procedure TForm.Hide;
begin
  if  Visible then
  begin
    Visible := False;
  end;
end;

procedure TForm.Show;
begin
  if not Visible then
     begin
      Visible := True;
     end;
end;



procedure TForm.SetFocus(C: PObject);
begin
  if ActiveControl = C then Exit;
  if (C <> nil) and not C^.CanFocus then Exit;  { <-- EKLEND� }

  if ActiveControl <> nil then
    ActiveControl^.Focused := False;

  ActiveControl := C;

  if ActiveControl <> nil then
    ActiveControl^.Focused := True;
end;


procedure TForm.FocusNext;
var
  Found: Boolean;
  NextCtrl: PObject;

  { A�a�ta ilerler; Found=true olduktan SONRA ilk uygun kontrol� al�r }
  procedure Scan(C: PObject);
  begin
    if C = nil then Exit;

    if Found then
    begin
      if C^.CanFocus and C^.Visible and C^.Enabled and C^.TabStop then
      begin
        NextCtrl := C;
        Exit;
      end;
    end
    else if C = ActiveControl then
      Found := True;

    { �nce derinlemesine �ocuklar (i� i�e Edit/Memo'lar� bulabilmek i�in) }
    Scan(C^.Child);
    if NextCtrl <> nil then Exit;

    { Sonra yan yana karde�ler }
    Scan(C^.Next);
    if NextCtrl <> nil then Exit;
  end;

  { Ba�tan ba�layarak ilk uygun kontrol� bulur }
  procedure ScanFromRoot(C: PObject);
  begin
    if C = nil then Exit;
    if C^.CanFocus and C^.Visible and C^.Enabled and C^.TabStop then
    begin
      NextCtrl := C;
      Exit;
    end;
    ScanFromRoot(C^.Child);
    if NextCtrl <> nil then Exit;
    ScanFromRoot(C^.Next);
    if NextCtrl <> nil then Exit;
  end;

begin
  { Hi�bir kontrol aktif de�ilse a�a�taki ilk uygun olana git }
  if ActiveControl = nil then
  begin
    NextCtrl := nil;
    ScanFromRoot(Child);
    if NextCtrl <> nil then
      SetFocus(NextCtrl);
    Exit;
  end;

  { Aktif kontrolden sonrakini bul }
  Found := False;
  NextCtrl := nil;
  Scan(Child);

  { Sona gelindiyse d�ng�sel olarak ba�tan devam et }
  if NextCtrl = nil then
  begin
    Found := False;
    Scan(Child);
  end;

  if NextCtrl <> nil then
    SetFocus(NextCtrl);
end;


function TObject.AbsLeft: Integer;
var P: PObject;
begin Result:=Left; P:=Parent; while P<>nil do begin Inc(Result,P^.Left); P:=P^.Parent; end; end;

function TObject.AbsTop: Integer;
var P: PObject;
begin Result:=Top; P:=Parent; while P<>nil do begin Inc(Result,P^.Top); P:=P^.Parent; end; end;



procedure GetAbsoluteRect(Obj: PObject; out AX, AY, AWidth, AHeight: Integer);
var
  P, Root: PObject;
begin
  AX := Obj^.Left;
  AY := Obj^.Top;
  Root := Obj;
  P := Obj^.Parent;
  while P <> nil do
  begin
    Inc(AX, P^.Left);
    Inc(AY, P^.Top);
    Root := P;
    P := P^.Parent;
  end;

  { PaintObject formun child'larini (AbsLeft - HScroll.Pos, AbsTop - VScroll.Pos)
    konumunda ciziyor. Hit-test'in cizimle ayni yerde calismasi icin, Obj bir
    formun (dogrudan veya dolayli) cocuguysa ayni ofseti burada da dusmeliyiz.
    Aksi halde form kaydirildiginda mouse/dblclick olaylari yanlis nesneye
    (ornegin altta kalan formun kendisine) gidebilir. }
  if Obj^.Parent <> nil then
  begin
    Dec(AX, PForm(Root)^.HScroll.Pos);
    Dec(AY, PForm(Root)^.VScroll.Pos);
  end;

  AWidth := Obj^.Width;
  AHeight := Obj^.Height;
end;

procedure GetFormClientRect(Form: PForm; out CX, CY, CW, CH: Integer);
begin
  CX := Form^.Left + Form^.BorderWidth;
  CY := Form^.Top + Form^.BorderWidth;
  if Form^.ShowHeader then Inc(CY, HEADER_HEIGHT);

  CW := Form^.Width - 2 * Form^.BorderWidth;
  CH := Form^.Height - 2 * Form^.BorderWidth;
  if Form^.ShowHeader then Dec(CH, HEADER_HEIGHT);

  if Form^.VScroll.Visible then Dec(CW, SCROLLBAR_SIZE);
  if Form^.HScroll.Visible then Dec(CH, SCROLLBAR_SIZE);
end;

function FindRootForm(Obj: PObject): PForm;
begin
  while (Obj <> nil) and (Obj^.Parent <> nil) do
    Obj := Obj^.Parent;
  Result := PForm(Obj);
end;


//--------------------POPUP--------------------------------------------------
{=============================================================================}
{ TPopupMenu                                                                  }
{=============================================================================}

procedure TPopupMenu.AddItem(const ACaption: PChar; AOnClick: TPopupMenuClickProc; AEnabled: Boolean);
var
  Item: PPopupMenuItem;
  OldCap, OldSize: Integer;
begin
  if ItemCount >= ItemCapacity then
  begin
    OldCap := ItemCapacity;
    if ItemCapacity = 0 then ItemCapacity := 8
    else ItemCapacity := ItemCapacity * 2;
    OldSize := OldCap * SizeOf(PPopupMenuItem);
    Items := PPCharArray(ReallocMem(Items, OldSize, ItemCapacity * SizeOf(PPopupMenuItem)));
  end;
  Item := PPopupMenuItem(MemAlloc(SizeOf(TPopupMenuItem)));
  FillChar(Item^, SizeOf(TPopupMenuItem), #0);
  if ACaption <> nil then
    Move(ACaption[0], Item^.Caption[0], StrLen(ACaption));
  Item^.Enabled := AEnabled;
  Item^.OnClick := AOnClick;
  Items^[ItemCount] := PChar(Item);
  Inc(ItemCount);
end;

procedure TPopupMenu.AddSeparator;
begin
  AddItem('-', nil, False);
  PPopupMenuItem(Items^[ItemCount - 1])^.Separator := True;
end;

procedure TPopupMenu.Show(AX, AY: Integer);
var
  I, W, MaxW: Integer;
  Item: PPopupMenuItem;
begin
  MaxW := 80;
  for I := 0 to ItemCount - 1 do
  begin
    Item := PPopupMenuItem(Items^[I]);
    if Item^.Separator then Continue;
    W := StrLen(Item^.Caption) * FONT_W + 40;
    if W > MaxW then MaxW := W;
  end;
  Width := MaxW;
  X := AX;
  Y := AY;

  if X + Width > SCREEN_WIDTH then X := SCREEN_WIDTH - Width;
  if X < 0 then X := 0;
  if Y + ItemCount * ItemHeight + 4 > SCREEN_HEIGHT then
    Y := SCREEN_HEIGHT - (ItemCount * ItemHeight + 4);
  if Y < 0 then Y := 0;

  Visible := True;
  SelectedIndex := -1;
  WinManager.ActivePopup := @Self;
end;

procedure TPopupMenu.Hide;
begin
  Visible := False;
  SelectedIndex := -1;
  WinManager.ActivePopup := nil;
end;

procedure TPopupMenu.Draw;
var
  I, ItemY: Integer;
  Item: PPopupMenuItem;
  TxtColor: LongWord;
begin
  if not Visible then Exit;

  { Arka plan + 3D border }
  KFill(X, Y, Width, ItemCount * ItemHeight + 4, clBtnFace);
  KRect(X, Y, Width, ItemCount * ItemHeight + 4, clBlack);
  KLineH(X + 1, Y + 1, Width - 2, clWhite);
  KLineV(X + 1, Y + 1, ItemCount * ItemHeight + 2, clWhite);
  KLineH(X + 1, Y + ItemCount * ItemHeight + 2, Width - 2, cl3DShadow);
  KLineV(X + Width - 2, Y + 1, ItemCount * ItemHeight + 2, cl3DShadow);

  for I := 0 to ItemCount - 1 do
  begin
    Item := PPopupMenuItem(Items^[I]);
    ItemY := Y + 2 + I * ItemHeight;

    if I = SelectedIndex then
    begin
      if Item^.Enabled and not Item^.Separator then
      begin
        KFill(X + 2, ItemY, Width - 4, ItemHeight, $004080C0);
        TxtColor := clWhite;
      end
      else
      begin
        KFill(X + 2, ItemY, Width - 4, ItemHeight, $00A0C8F0);
        TxtColor := clGray;
      end;
    end
    else
    begin
      if not Item^.Enabled then TxtColor := clGray
      else TxtColor := clBlack;
    end;

    if Item^.Separator then
    begin
      KLineH(X + 4, ItemY + ItemHeight div 2, Width - 8, cl3DShadow);
      KLineH(X + 4, ItemY + ItemHeight div 2 + 1, Width - 8, clWhite);
    end
    else
    begin
      if Item^.Checked then
      begin
        KStr(X + 4, ItemY + (ItemHeight - FONT_H) div 2, '?', TxtColor);
        KStr(X + 16, ItemY + (ItemHeight - FONT_H) div 2, Item^.Caption, TxtColor);
      end
      else
        KStr(X + 8, ItemY + (ItemHeight - FONT_H) div 2, Item^.Caption, TxtColor);
    end;
  end;
end;

function TPopupMenu.HitTest(MX, MY: Integer): Integer;
begin
  Result := -1;
  if not Visible then Exit;
  if (MX < X) or (MX >= X + Width) or
     (MY < Y) or (MY >= Y + ItemCount * ItemHeight + 4) then Exit;
  Result := (MY - Y - 2) div ItemHeight;
  if (Result < 0) or (Result >= ItemCount) then Result := -1;
end;

procedure TPopupMenu.MouseDown(MX, MY: Integer; Btn: Byte);
var
  Idx: Integer;
  Item: PPopupMenuItem;
begin
  if Btn <> 1 then Exit;
  Idx := HitTest(MX, MY);
  if (Idx >= 0) and (Idx < ItemCount) then
  begin
    Item := PPopupMenuItem(Items^[Idx]);
    if Item^.Enabled and not Item^.Separator then
    begin
      if Assigned(Item^.OnClick) then Item^.OnClick(Item);
      Hide;
    end;
  end;
end;

procedure TPopupMenu.MouseMove(MX, MY: Integer);
var
  Idx: Integer;
begin
  Idx := HitTest(MX, MY);
  if Idx <> SelectedIndex then SelectedIndex := Idx;
end;



{=============================================================================}
{ Slot Y?netimi (Orijinal)                                                    }
{=============================================================================}

procedure FreeDestroySlots(var L: PDestroySlot);
var S, N: PDestroySlot;
begin
  S := L;
  while S <> nil do
  begin N := S^.Next; FreeMem(S); S := N; end;
  L := nil;
end;

procedure FreeKeyDownSlots(var L: PKeyDownSlot);
var S, N: PKeyDownSlot;
begin
  S := L;
  while S <> nil do
  begin N := S^.Next; FreeMem(S); S := N; end;
  L := nil;
end;

procedure FreeMouseSlots(var L: PMouseSlot);
var S, N: PMouseSlot;
begin
  S := L;
  while S <> nil do
  begin N := S^.Next; FreeMem(S); S := N; end;
  L := nil;
end;

procedure FreePaintSlots(var L: PPaintSlot);
var S, N: PPaintSlot;
begin
  S := L;
  while S <> nil do
  begin N := S^.Next; FreeMem(S); S := N; end;
  L := nil;
end;

procedure AddDestroySlot(var List: PDestroySlot; P: TDestroyProc);
var S: PDestroySlot;
begin
  S := PDestroySlot(MemAlloc(SizeOf(TDestroySlot)));
  S^.Proc := P; S^.Next := List; List := S;
end;

procedure AddMouseSlot1(var List: PMouseSlot; P: TMouseProc);
var S: PMouseSlot;
begin
  S:=PMouseSlot(MemAlloc(SizeOf(TMouseSlot)));
  S^.Proc := P; S^.Next := List; List := S;
end;

procedure AddMouseSlot(var List: PMouseSlot; P: TMouseProc);
var
  S, N: PMouseSlot;
begin
  S := PMouseSlot(MemAlloc(SizeOf(TMouseSlot)));
  FillChar(S^, SizeOf(TMouseSlot), 0);
  S^.Proc := P;

  if List = nil then
  begin
    List := S;
    Exit;
  end;

  N := List;
  while N^.Next <> nil do
    N := N^.Next;

  N^.Next := S;
end;



procedure AddKeyDownSlot(var List: PKeyDownSlot; P: TKeyDownProc);
var
  S, N: PKeyDownSlot;
begin
  S := PKeyDownSlot(MemAlloc(SizeOf(TKeyDownSlot)));
  FillChar(S^, SizeOf(TKeyDownSlot), 0);
  S^.Proc := P;

  if List = nil then
  begin
    List := S;
    Exit;
  end;

  N := List;
  while N^.Next <> nil do
    N := N^.Next;

  N^.Next := S;
end;


procedure AddPaintSlot1(var List: PPaintSlot; P: TPaintProc);
var S: PPaintSlot;
begin
   S:=PPaintSlot(MemAlloc(SizeOf(TPaintSlot)));
  S^.Proc := P; S^.Next := List; List := S;
end;


procedure AddPaintSlot(var List: PPaintSlot; P: TPaintProc);
var
  S, N: PPaintSlot;
begin
  S := PPaintSlot(MemAlloc(SizeOf(TPaintSlot)));
  FillChar(S^, SizeOf(TPaintSlot), 0);
  S^.Proc := P;

  if List = nil then
  begin
    List := S;
    Exit;
  end;

  N := List;
  while N^.Next <> nil do
    N := N^.Next;

  N^.Next := S;
end;

procedure TDestroySlot.Fire(Sender: PObject);
var S: PDestroySlot;
begin
  S := @Self;
  while S <> nil do
  begin
    if Assigned(S^.Proc) then S^.Proc(Sender);
    S := S^.Next;
  end;
end;

procedure TKeyDownSlot.Fire(Sender: PObject; Key: Word);
var S: PKeyDownSlot;
begin
  S := @Self;
  while S <> nil do
  begin
    if Assigned(S^.Proc) then S^.Proc(Sender, Key);
    S := S^.Next;
  end;
end;

procedure TMouseSlot.Fire(Sender: PObject; AX, AY: Integer; Btn: Byte);
var S: PMouseSlot;
begin
  S := @Self;
  while S <> nil do
  begin
    if Assigned(S^.Proc) then S^.Proc(Sender, AX, AY, Btn);
    S := S^.Next;
  end;
end;

procedure TPaintSlot.Fire(Sender: PObject; AX, AY: Integer);
var S: PPaintSlot;
begin
  S := @Self;
  while S <> nil do
  begin
    if Assigned(S^.Proc) then S^.Proc(Sender, AX, AY);
    S := S^.Next;
  end;
end;


procedure TObject.FireDestroy(Sender: PObject);
begin
  if not Enabled then Exit;
  if FOnDestroy <> nil then FOnDestroy^.Fire(@Self);
end;



procedure TObject.FireKeyDown(Key: Word);
begin
  if not Enabled then Exit;
  if FOnKeyDown <> nil then FOnKeyDown^.Fire(@Self, Key);
end;

procedure TObject.FireKeyUp(Key: Word);
begin
  if not Enabled then Exit;
  if FOnKeyUp <> nil then FOnKeyUp^.Fire(@Self, Key);
end;

procedure TObject.FireDblClick(AX, AY: Integer; Btn: Byte);
var
  AbsX, AbsY, W, H: Integer;
begin
  if not Enabled then Exit;
  if FOnDblClick <> nil then
  begin
    GetAbsoluteRect(@Self, AbsX, AbsY, W, H);
    FOnDblClick^.Fire(@Self, AX - AbsX, AY - AbsY, Btn);
  end;
end;


procedure TObject.FireMouseDown(AX, AY: Integer; Btn: Byte);
var
  AbsX, AbsY, W, H: Integer;
begin
  if not Enabled then Exit;
  if FOnMouseDown <> nil then
  begin

    GetAbsoluteRect(@Self, AbsX, AbsY, W, H);
    FOnMouseDown^.Fire(@Self, AX - AbsX, AY - AbsY, Btn);
  end;
end;

procedure TObject.FireMouseMove(AX, AY: Integer; Btn: Byte);
var
  AbsX, AbsY, W, H: Integer;
begin
  if FOnMouseMove <> nil then
  begin
    GetAbsoluteRect(@Self, AbsX, AbsY, W, H);
    FOnMouseMove^.Fire(@Self, AX - AbsX, AY - AbsY, 0);
  end;
end;


procedure TObject.FireMouseUp(AX, AY: Integer; Btn: Byte);
var
  AbsX, AbsY, W, H: Integer;
begin
  if not Enabled then Exit;
  if FOnMouseUp <> nil then
  begin

    GetAbsoluteRect(@Self, AbsX, AbsY, W, H);
    FOnMouseUp^.Fire(@Self, AX - AbsX, AY - AbsY, Btn);
  end;
end;


procedure TObject.FirePaint(AX, AY: Integer);
begin
  if (FOnPaint <> nil) and Visible then
    FOnPaint^.Fire(@Self, AX, AY);
end;

procedure TObject.BindDestroy(P: TDestroyProc);
begin
  AddDestroySlot(FOnDestroy, P);
end;

procedure TObject.BindKeyDown(P: TKeyDownProc);
begin
  AddKeyDownSlot(FOnKeyDown, P);
end;

procedure TObject.BindKeyUp(P: TKeyDownProc);
begin
  AddKeyDownSlot(FOnKeyUp, P);
end;


procedure TObject.BindDblClick(P: TMouseProc);
begin
  AddMouseSlot(FOnDblClick, P);
end;

procedure TObject.BindMouseDown(P: TMouseProc);
begin
  AddMouseSlot(FOnMouseDown, P);
end;

procedure TObject.BindMouseUp(P: TMouseProc);
begin
  AddMouseSlot(FOnMouseUp, P);
end;

procedure TObject.BindMouseMove(P: TMouseProc);
begin
  AddMouseSlot(FOnMouseMove, P);
end;

procedure TObject.BindPaint(P: TPaintProc);
begin
  AddPaintSlot(FOnPaint, P);
end;



procedure TObject.AddObject(Sender: PObject);
var
  Last, Current: PObject;
begin
  if Child = nil then
  begin
    Child := Sender;
    Sender^.Previous := nil;
    Sender^.Next := nil;
  end
  else
  begin
    Current := Child;
    Last := nil;
    while (Current <> nil) and (Current^.ZIndex <= Sender^.ZIndex) do
    begin
      Last := Current;
      Current := Current^.Next;
    end;
    if Last = nil then
    begin
      Sender^.Next := Child;
      Sender^.Previous := nil;
      Child^.Previous := Sender;
      Child := Sender;
    end
    else
    begin
      Sender^.Next := Last^.Next;
      Sender^.Previous := Last;
      if Last^.Next <> nil then
        Last^.Next^.Previous := Sender;
      Last^.Next := Sender;
    end;
  end;
end;

{=============================================================================}
{ Form ScrollBar Y?netimi (Form-Integrated)                                   }
{=============================================================================}

procedure UpdateFormScrollLayout(Form: PForm);
var
  CX, CY, CW, CH: Integer;
begin
  { Not: GetFormClientRect scrollbar'lar zaten Visible=True/False olarak
    ayarlanmis olmasini bekler (bunlar burada, bu prosedurden ONCE
    AutoUpdateScrollBars tarafindan belirlenir), bu yuzden CW/CH burada
    scrollbar'lar dusulmus client genislik/yukseklik olarak gelir; scrollbar
    Left/Top/Width/Height hesaplarinda buna gore CX/CY/CW/CH kullaniliyor. }
  GetFormClientRect(Form, CX, CY, CW, CH);

  if Form^.VScroll.Visible then
  begin
    Form^.VScroll.Left := Form^.Left + Form^.Width - Form^.BorderWidth - SCROLLBAR_SIZE;
    Form^.VScroll.Top := CY;
    Form^.VScroll.Width := SCROLLBAR_SIZE;
    Form^.VScroll.Height := Form^.Height - (CY - Form^.Top) - Form^.BorderWidth;
    if Form^.HScroll.Visible then Dec(Form^.VScroll.Height, SCROLLBAR_SIZE);

    Form^.VScroll.TrackStart := Form^.VScroll.Top + SCROLLBAR_SIZE;
    Form^.VScroll.TrackLen := Form^.VScroll.Height - SCROLLBAR_SIZE * 2;
    if Form^.VScroll.TrackLen < 0 then Form^.VScroll.TrackLen := 0;

    if Form^.VScroll.PageSize > 0 then
      Form^.VScroll.ThumbSize := Max(SCROLLBAR_SIZE div 2,
        Form^.VScroll.TrackLen * Form^.VScroll.PageSize div
        (Form^.VScroll.Max - Form^.VScroll.Min + Form^.VScroll.PageSize))
    else
      Form^.VScroll.ThumbSize := SCROLLBAR_SIZE;

    if Form^.VScroll.ThumbSize > Form^.VScroll.TrackLen then Form^.VScroll.ThumbSize := Form^.VScroll.TrackLen;
    if Form^.VScroll.ThumbSize < 4 then Form^.VScroll.ThumbSize := 4;

    if Form^.VScroll.Max > Form^.VScroll.Min then
      Form^.VScroll.ThumbPos := Form^.VScroll.TrackStart +
        (Form^.VScroll.Pos - Form^.VScroll.Min) *
        (Form^.VScroll.TrackLen - Form^.VScroll.ThumbSize) div
        (Form^.VScroll.Max - Form^.VScroll.Min)
    else
      Form^.VScroll.ThumbPos := Form^.VScroll.TrackStart;
  end;

  if Form^.HScroll.Visible then
  begin
    Form^.HScroll.Left := CX;
    Form^.HScroll.Top := Form^.Top + Form^.Height - Form^.BorderWidth - SCROLLBAR_SIZE;
    Form^.HScroll.Width := Form^.Width - (CX - Form^.Left) - Form^.BorderWidth;
    if Form^.VScroll.Visible then Dec(Form^.HScroll.Width, SCROLLBAR_SIZE);
    Form^.HScroll.Height := SCROLLBAR_SIZE;

    Form^.HScroll.TrackStart := Form^.HScroll.Left + SCROLLBAR_SIZE;
    Form^.HScroll.TrackLen := Form^.HScroll.Width - SCROLLBAR_SIZE * 2;
    if Form^.HScroll.TrackLen < 0 then Form^.HScroll.TrackLen := 0;

    if Form^.HScroll.PageSize > 0 then
      Form^.HScroll.ThumbSize := Max(SCROLLBAR_SIZE div 2,
        Form^.HScroll.TrackLen * Form^.HScroll.PageSize div
        (Form^.HScroll.Max - Form^.HScroll.Min + Form^.HScroll.PageSize))
    else
      Form^.HScroll.ThumbSize := SCROLLBAR_SIZE;

    if Form^.HScroll.ThumbSize > Form^.HScroll.TrackLen then Form^.HScroll.ThumbSize := Form^.HScroll.TrackLen;
    if Form^.HScroll.ThumbSize < 4 then Form^.HScroll.ThumbSize := 4;

    if Form^.HScroll.Max > Form^.HScroll.Min then
      Form^.HScroll.ThumbPos := Form^.HScroll.TrackStart +
        (Form^.HScroll.Pos - Form^.HScroll.Min) *
        (Form^.HScroll.TrackLen - Form^.HScroll.ThumbSize) div
        (Form^.HScroll.Max - Form^.HScroll.Min)
    else
      Form^.HScroll.ThumbPos := Form^.HScroll.TrackStart;
  end;
end;

procedure AutoUpdateScrollBars(Form: PForm);
var
  Child: PObject;
  MaxRight, MaxBottom: Integer;
  NeedV, NeedH: Boolean;
  CW, CH: Integer;
begin
  // Ba?lang??ta scrollbar'lar kapal? varsay?m?yla hesapla
  CW := Form^.Width - 2 * Form^.BorderWidth;
  CH := Form^.Height - 2 * Form^.BorderWidth;
  if Form^.ShowHeader then Dec(CH, HEADER_HEIGHT);

  MaxRight := Form^.Left + Form^.BorderWidth;
  MaxBottom := Form^.Top + Form^.BorderWidth;

  Child := Form^.Child;
  while (Child <> nil) and (Child^.Align=alNone) do
  begin
    if Child^.Visible  then
    begin
      if Form^.Left + Child^.Left + Child^.Width > MaxRight then
        MaxRight := Form^.Left + Child^.Left + Child^.Width;
      if Form^.Top + Child^.Top + Child^.Height > MaxBottom then
        MaxBottom := Form^.Top + Child^.Top + Child^.Height;
    end;
    Child := Child^.Next;
  end;

  // Ta?ma kontrol? (scrollbar yokken)
  NeedH := MaxRight > Form^.Left + CW;
  NeedV := MaxBottom > Form^.Top + CH;

  // Bir scrollbar a??l?nca di?erini de gerektirebilir
  if NeedV and not NeedH then
    if MaxRight > Form^.Left + CW - SCROLLBAR_SIZE then NeedH := True;
  if NeedH and not NeedV then
    if MaxBottom > Form^.Top + CH - SCROLLBAR_SIZE then NeedV := True;

  Form^.VScroll.Visible := NeedV;
  Form^.HScroll.Visible := NeedH;

  // Scrollbar'lar a??kken ger?ek client boyutlar?
  if Form^.VScroll.Visible then Dec(CW, SCROLLBAR_SIZE);
  if Form^.HScroll.Visible then Dec(CH, SCROLLBAR_SIZE);

  if Form^.VScroll.Visible then
  begin
    Form^.VScroll.Min := 0;
    Form^.VScroll.Max := (MaxBottom - Form^.Top) - (Form^.BorderWidth + CH);
    if Form^.VScroll.Max < 0 then Form^.VScroll.Max := 0;
    Form^.VScroll.PageSize := CH;
    if Form^.VScroll.Pos > Form^.VScroll.Max then Form^.VScroll.Pos := Form^.VScroll.Max;
  end
  else
    Form^.VScroll.Pos := 0;

  if Form^.HScroll.Visible then
  begin
    Form^.HScroll.Min := 0;
    Form^.HScroll.Max := (MaxRight - Form^.Left) - (Form^.BorderWidth + CW);
    if Form^.HScroll.Max < 0 then Form^.HScroll.Max := 0;
    Form^.HScroll.PageSize := CW;
    if Form^.HScroll.Pos > Form^.HScroll.Max then Form^.HScroll.Pos := Form^.HScroll.Max;
  end
  else
    Form^.HScroll.Pos := 0;

  UpdateFormScrollLayout(Form);
end;

{=============================================================================}
{ Align (TAlign) Y?netimi                                                     }
{=============================================================================}

{ AParent'in COCUKLARININ yerlesecegi client alanini, AParent'in KENDI
  orijinine (Left/Top) GORE (yani local/relative) koordinatlarda dondurur.
  - AParent bir Form ise (Parent = nil): border, header ve GORUNUR
    scrollbar'lar dusulur (GetFormClientRect'i tekrar yazmamak icin onu
    kullanip Form.Left/Top'u geri cikariyoruz).
  - AParent baska bir component ise (orn. Panel icindeki component'ler):
    sadece kendi BorderWidth'i kadar ic bosluk birakilir. }
procedure GetContainerClientRect(AParent: PObject; out CX, CY, CW, CH: Integer);
var
  F: PForm;
begin
  if AParent^.Parent = nil then
  begin
    F := PForm(AParent);
    GetFormClientRect(F, CX, CY, CW, CH);
    Dec(CX, F^.Left);
    Dec(CY, F^.Top);
  end
  else
  begin
    CX := AParent^.BorderWidth;
    CY := AParent^.BorderWidth;
    CW := AParent^.Width - 2 * AParent^.BorderWidth;
    CH := AParent^.Height - 2 * AParent^.BorderWidth;
  end;
  if CW < 0 then CW := 0;
  if CH < 0 then CH := 0;
end;

{ AParent'in dogrudan cocuklarini Align degerlerine gore client alan icinde
  konumlandirir (klasik VCL/Lazarus dock algoritmasi): once alTop/alBottom/
  alLeft/alRight sirayla kalan alani daraltir, sonra alClient kalan tum alani
  doldurur. alNone olan nesnelere dokunulmaz (elle konumlandirma korunur).
  Her cocugun kendi cocuklari varsa (component icinde component), o cocuk
  icin de recursive olarak AlignChildren cagrilir; boylece i? ice gecmis
  panel/button hiyerarsisinin tamami tek cagriyla guncellenir. }
procedure AlignChildren(AParent: PObject);
var
  RX, RY, RW, RH: Integer;
  Child: PObject;
begin
  if (AParent = nil) or (AParent^.Child = nil) then Exit;

  GetContainerClientRect(AParent, RX, RY, RW, RH);

  { 1. gecis: kenara yasla (Z-Order / ekleme sirasina gore) }
  Child := AParent^.Child;
  while Child <> nil do
  begin
    case Child^.Align of
      alTop:
        begin
          Child^.Left  := RX;
          Child^.Top   := RY;
          Child^.Width := RW;
          if Child^.Height > RH then Child^.Height := RH;
          if Child^.Height < 0 then Child^.Height := 0;
          Inc(RY, Child^.Height);
          Dec(RH, Child^.Height);
        end;
      alBottom:
        begin
          if Child^.Height > RH then Child^.Height := RH;
          if Child^.Height < 0 then Child^.Height := 0;
          Child^.Left  := RX;
          Child^.Top   := RY + RH - Child^.Height;
          Child^.Width := RW;
          Dec(RH, Child^.Height);
        end;
      alLeft:
        begin
          Child^.Top    := RY;
          Child^.Left   := RX;
          Child^.Height := RH;
          if Child^.Width > RW then Child^.Width := RW;
          if Child^.Width < 0 then Child^.Width := 0;
          Inc(RX, Child^.Width);
          Dec(RW, Child^.Width);
        end;
      alRight:
        begin
          if Child^.Width > RW then Child^.Width := RW;
          if Child^.Width < 0 then Child^.Width := 0;
          Child^.Top    := RY;
          Child^.Left   := RX + RW - Child^.Width;
          Child^.Height := RH;
          Dec(RW, Child^.Width);
        end;
    end;
    Child := Child^.Next;
  end;

  if RW < 0 then RW := 0;
  if RH < 0 then RH := 0;

  { 2. gecis: alClient - kalan alanin tamamini doldurur }
  Child := AParent^.Child;
  while Child <> nil do
  begin
    if Child^.Align = alClient then
    begin
      Child^.Left   := RX;
      Child^.Top    := RY;
      Child^.Width  := RW;
      Child^.Height := RH;
    end;
    Child := Child^.Next;
  end;

  { 3. gecis: component icinde component - alt agaci recursive hizala }
  Child := AParent^.Child;
  while Child <> nil do
  begin
    if Child^.Child <> nil then
      AlignChildren(Child);
    Child := Child^.Next;
  end;
end;

{ Bir formun scrollbar durumunu ve Align'li tum alt agacini tek seferde
  gunceller. Not: AutoUpdateScrollBars, scrollbar gorunurlugune once (bir
  onceki hizalamadan kalma) cocuk boyutlarina bakarak karar verir; AlignChildren
  bu karara gore client alanini hesaplayip docked cocuklari yerlestirir. Bu,
  scrollbar<->align arasinda kucuk bir "bir adim gecikme" yaratir ama bu
  olcekte (birkac form/component) pratikte sorun cikarmaz. }
procedure RelayoutForm(F: PForm);
begin
  if F = nil then Exit;
  AutoUpdateScrollBars(F);
  AlignChildren(PObject(F));
end;

procedure SetAlign(Obj: PObject; AAlign: TAlign);
begin
  if Obj = nil then Exit;
  Obj^.Align := AAlign;
  if Obj^.Parent <> nil then
    RelayoutForm(FindRootForm(Obj^.Parent));
end;

function FormVScrollHitTest(Form: PForm; MX, MY: Integer; out Part: Integer): Boolean;
begin
  Result := False;
  Part := -1;
  if not Form^.VScroll.Visible then Exit;
  if (MX < Form^.VScroll.Left) or (MX >= Form^.VScroll.Left + Form^.VScroll.Width) or
     (MY < Form^.VScroll.Top) or (MY >= Form^.VScroll.Top + Form^.VScroll.Height) then Exit;

  if MY < Form^.VScroll.Top + SCROLLBAR_SIZE then begin Part := 0; Result := True; Exit; end;
  if MY >= Form^.VScroll.Top + Form^.VScroll.Height - SCROLLBAR_SIZE then begin Part := 1; Result := True; Exit; end;
  if (MY >= Form^.VScroll.ThumbPos) and (MY < Form^.VScroll.ThumbPos + Form^.VScroll.ThumbSize) then begin Part := 4; Result := True; Exit; end;
  if MY < Form^.VScroll.ThumbPos then begin Part := 2; Result := True; Exit; end;
  Part := 3; Result := True;
end;

function FormHScrollHitTest(Form: PForm; MX, MY: Integer; out Part: Integer): Boolean;
begin
  Result := False;
  Part := -1;
  if not Form^.HScroll.Visible then Exit;
  if (MX < Form^.HScroll.Left) or (MX >= Form^.HScroll.Left + Form^.HScroll.Width) or
     (MY < Form^.HScroll.Top) or (MY >= Form^.HScroll.Top + Form^.HScroll.Height) then Exit;

  if MX < Form^.HScroll.Left + SCROLLBAR_SIZE then begin Part := 0; Result := True; Exit; end;
  if MX >= Form^.HScroll.Left + Form^.HScroll.Width - SCROLLBAR_SIZE then begin Part := 1; Result := True; Exit; end;
  if (MX >= Form^.HScroll.ThumbPos) and (MX < Form^.HScroll.ThumbPos + Form^.HScroll.ThumbSize) then begin Part := 4; Result := True; Exit; end;
  if MX < Form^.HScroll.ThumbPos then begin Part := 2; Result := True; Exit; end;
  Part := 3; Result := True;
end;

procedure FormVScrollMouseDown(Form: PForm; Part: Integer; MY: Integer);
begin
  case Part of
    0: begin Form^.VScroll.Arrow1Pressed := True; Form^.VScroll.Pos := Max(Form^.VScroll.Min, Form^.VScroll.Pos - 10); end;
    1: begin Form^.VScroll.Arrow2Pressed := True; Form^.VScroll.Pos := Min(Form^.VScroll.Max, Form^.VScroll.Pos + 10); end;
    2: begin Form^.VScroll.Page1Pressed := True; Form^.VScroll.Pos := Max(Form^.VScroll.Min, Form^.VScroll.Pos - Form^.VScroll.PageSize); end;
    3: begin Form^.VScroll.Page2Pressed := True; Form^.VScroll.Pos := Min(Form^.VScroll.Max, Form^.VScroll.Pos + Form^.VScroll.PageSize); end;
    4: begin
         Form^.VScroll.Dragging := True;
         Form^.VScroll.DragStart := MY;
         Form^.VScroll.DragPosStart := Form^.VScroll.ThumbPos;
       end;
  end;
  if Form^.VScroll.Pos < Form^.VScroll.Min then Form^.VScroll.Pos := Form^.VScroll.Min;
  if Form^.VScroll.Pos > Form^.VScroll.Max then Form^.VScroll.Pos := Form^.VScroll.Max;
  UpdateFormScrollLayout(Form);
end;

procedure FormHScrollMouseDown(Form: PForm; Part: Integer; MX: Integer);
begin
  case Part of
    0: begin Form^.HScroll.Arrow1Pressed := True; Form^.HScroll.Pos := Max(Form^.HScroll.Min, Form^.HScroll.Pos - 10); end;
    1: begin Form^.HScroll.Arrow2Pressed := True; Form^.HScroll.Pos := Min(Form^.HScroll.Max, Form^.HScroll.Pos + 10); end;
    2: begin Form^.HScroll.Page1Pressed := True; Form^.HScroll.Pos := Max(Form^.HScroll.Min, Form^.HScroll.Pos - Form^.HScroll.PageSize); end;
    3: begin Form^.HScroll.Page2Pressed := True; Form^.HScroll.Pos := Min(Form^.HScroll.Max, Form^.HScroll.Pos + Form^.HScroll.PageSize); end;
    4: begin
         Form^.HScroll.Dragging := True;
         Form^.HScroll.DragStart := MX;
         Form^.HScroll.DragPosStart := Form^.HScroll.ThumbPos;
       end;
  end;
  if Form^.HScroll.Pos < Form^.HScroll.Min then Form^.HScroll.Pos := Form^.HScroll.Min;
  if Form^.HScroll.Pos > Form^.HScroll.Max then Form^.HScroll.Pos := Form^.HScroll.Max;
  UpdateFormScrollLayout(Form);
end;

procedure FormVScrollMouseMove(Form: PForm; MY: Integer);
var
  Delta, NewThumbPos, MaxThumbPos: Integer;
begin
  if not Form^.VScroll.Dragging then Exit;
  Delta := MY - Form^.VScroll.DragStart;
  NewThumbPos := Form^.VScroll.DragPosStart + Delta;
  if NewThumbPos < Form^.VScroll.TrackStart then NewThumbPos := Form^.VScroll.TrackStart;
  MaxThumbPos := Form^.VScroll.TrackStart + Form^.VScroll.TrackLen - Form^.VScroll.ThumbSize;
  if NewThumbPos > MaxThumbPos then NewThumbPos := MaxThumbPos;

  if Form^.VScroll.TrackLen - Form^.VScroll.ThumbSize > 0 then
    Form^.VScroll.Pos := Form^.VScroll.Min +
      (NewThumbPos - Form^.VScroll.TrackStart) * (Form^.VScroll.Max - Form^.VScroll.Min) div
      (Form^.VScroll.TrackLen - Form^.VScroll.ThumbSize)
  else
    Form^.VScroll.Pos := Form^.VScroll.Min;

  Form^.VScroll.ThumbPos := NewThumbPos;
end;

procedure FormHScrollMouseMove(Form: PForm; MX: Integer);
var
  Delta, NewThumbPos, MaxThumbPos: Integer;
begin
  if not Form^.HScroll.Dragging then Exit;
  Delta := MX - Form^.HScroll.DragStart;
  NewThumbPos := Form^.HScroll.DragPosStart + Delta;
  if NewThumbPos < Form^.HScroll.TrackStart then NewThumbPos := Form^.HScroll.TrackStart;
  MaxThumbPos := Form^.HScroll.TrackStart + Form^.HScroll.TrackLen - Form^.HScroll.ThumbSize;
  if NewThumbPos > MaxThumbPos then NewThumbPos := MaxThumbPos;

  if Form^.HScroll.TrackLen - Form^.HScroll.ThumbSize > 0 then
    Form^.HScroll.Pos := Form^.HScroll.Min +
      (NewThumbPos - Form^.HScroll.TrackStart) * (Form^.HScroll.Max - Form^.HScroll.Min) div
      (Form^.HScroll.TrackLen - Form^.HScroll.ThumbSize)
  else
    Form^.HScroll.Pos := Form^.HScroll.Min;

  Form^.HScroll.ThumbPos := NewThumbPos;
end;

procedure FormVScrollMouseUp(Form: PForm);
begin
  Form^.VScroll.Arrow1Pressed := False;
  Form^.VScroll.Arrow2Pressed := False;
  Form^.VScroll.Page1Pressed := False;
  Form^.VScroll.Page2Pressed := False;
  Form^.VScroll.Dragging := False;
end;

procedure FormHScrollMouseUp(Form: PForm);
begin
  Form^.HScroll.Arrow1Pressed := False;
  Form^.HScroll.Arrow2Pressed := False;
  Form^.HScroll.Page1Pressed := False;
  Form^.HScroll.Page2Pressed := False;
  Form^.HScroll.Dragging := False;
end;

{=============================================================================}
{ Sistem Butonlar?                                                            }
{=============================================================================}

function FormSysButtonHitTest(Form: PForm; MX, MY: Integer; out Button: Integer): Boolean;
var
  BtnX, BtnY: Integer;
begin
  Result := False;
  Button := -1;
  if not Form^.ShowSysButtons then Exit;
  if Form^.Minimized then Exit;

  BtnX := Form^.Left + Form^.Width - Form^.BorderWidth - SYSBUTTON_WIDTH;
  BtnY := Form^.Top + Form^.BorderWidth + 2;

  if PtInRect(MX, MY, BtnX, BtnY, SYSBUTTON_WIDTH - 2, HEADER_HEIGHT - 4) then
  begin Button := 2; Result := True; Exit; end;
  Dec(BtnX, SYSBUTTON_WIDTH);

  if PtInRect(MX, MY, BtnX, BtnY, SYSBUTTON_WIDTH - 2, HEADER_HEIGHT - 4) then
  begin Button := 1; Result := True; Exit; end;
  Dec(BtnX, SYSBUTTON_WIDTH);

  if PtInRect(MX, MY, BtnX, BtnY, SYSBUTTON_WIDTH - 2, HEADER_HEIGHT - 4) then
  begin Button := 0; Result := True; Exit; end;
end;

{=============================================================================}
{ ?izim Prosed?rleri                                                          }
{=============================================================================}

procedure DrawFormVScroll(Form: PForm);
var
  X, Y, W, H: Integer;
begin
  X := Form^.VScroll.Left;
  Y := Form^.VScroll.Top;
  W := Form^.VScroll.Width;
  H := Form^.VScroll.Height;

  KFill(X, Y, W, H, clBtnFace);

  KButton3D(X, Y, W, W, Form^.VScroll.Arrow1Pressed, clBtnFace);
  KLine(X + W div 2 - 2, Y + W div 2 + 2, X + W div 2, Y + W div 2 - 2, clBlack);
  KLine(X + W div 2, Y + W div 2 - 2, X + W div 2 + 2, Y + W div 2 + 2, clBlack);

  KButton3D(X, Y + H - W, W, W, Form^.VScroll.Arrow2Pressed, clBtnFace);
  KLine(X + W div 2 - 2, Y + H - W div 2 - 2, X + W div 2, Y + H - W div 2 + 2, clBlack);
  KLine(X + W div 2, Y + H - W div 2 + 2, X + W div 2 + 2, Y + H - W div 2 - 2, clBlack);

  if Form^.VScroll.ThumbSize > 0 then
  begin
    KButton3D(X + 1, Form^.VScroll.ThumbPos, W - 2, Form^.VScroll.ThumbSize,
              Form^.VScroll.Page2Pressed or Form^.VScroll.Dragging, clSilver);
    if Form^.VScroll.ThumbSize > 8 then
    begin
      KLineH(X + 3, Form^.VScroll.ThumbPos + Form^.VScroll.ThumbSize div 2 - 2, W - 6, clGray);
      KLineH(X + 3, Form^.VScroll.ThumbPos + Form^.VScroll.ThumbSize div 2,     W - 6, clGray);
      KLineH(X + 3, Form^.VScroll.ThumbPos + Form^.VScroll.ThumbSize div 2 + 2, W - 6, clGray);
    end;
  end;

  KRect(X, Y, W, H, cl3DShadow);
end;

procedure DrawFormHScroll(Form: PForm);
var
  X, Y, W, H: Integer;
begin
  X := Form^.HScroll.Left;
  Y := Form^.HScroll.Top;
  W := Form^.HScroll.Width;
  H := Form^.HScroll.Height;

  KFill(X, Y, W, H, clBtnFace);

  KButton3D(X, Y, H, H, Form^.HScroll.Arrow1Pressed, clBtnFace);
  KLine(X + H div 2 + 2, Y + H div 2 - 2, X + H div 2 - 2, Y + H div 2, clBlack);
  KLine(X + H div 2 - 2, Y + H div 2,     X + H div 2 + 2, Y + H div 2 + 2, clBlack);

  KButton3D(X + W - H, Y, H, H, Form^.HScroll.Arrow2Pressed, clBtnFace);
  KLine(X + W - H div 2 - 2, Y + H div 2 - 2, X + W - H div 2 + 2, Y + H div 2, clBlack);
  KLine(X + W - H div 2 + 2, Y + H div 2,     X + W - H div 2 - 2, Y + H div 2 + 2, clBlack);

  if Form^.HScroll.ThumbSize > 0 then
  begin
    KButton3D(Form^.HScroll.ThumbPos, Y + 1, Form^.HScroll.ThumbSize, H - 2,
              Form^.HScroll.Page2Pressed or Form^.HScroll.Dragging, clSilver);
    if Form^.HScroll.ThumbSize > 8 then
    begin
      KLineV(Form^.HScroll.ThumbPos + Form^.HScroll.ThumbSize div 2 - 2, Y + 3, H - 6, clGray);
      KLineV(Form^.HScroll.ThumbPos + Form^.HScroll.ThumbSize div 2,     Y + 3, H - 6, clGray);
      KLineV(Form^.HScroll.ThumbPos + Form^.HScroll.ThumbSize div 2 + 2, Y + 3, H - 6, clGray);
    end;
  end;

  KRect(X, Y, W, H, cl3DShadow);
end;



// Tek piksel (2?2 block ? kernel'de 1?1 ?ok k???k g?r?n?r)
procedure Px(X, Y: Integer; C: LongWord);
begin KFill(X, Y, 2, 2, C); end;

// ?? X (Kapat) ikonu ? 7?7 ?ift piksel ?apraz ?????????????????????????????
procedure DrawIconX(CX, CY: Integer; C: LongWord);
var I: Integer;
begin
  for I := 0 to 4 do begin
    KFill(CX-4+I*2, CY-4+I*2, 2, 2, C);      // \ y?n?
    KFill(CX+4-I*2, CY-4+I*2, 2, 2, C);      // / y?n?
  end;
end;

// ?? ? (Maximize) ikonu ? i?i bo? dikd?rtgen ??????????????????????????????
procedure DrawIconMax(CX, CY: Integer; C: LongWord);
begin
  KLineH(CX-5, CY-4, 11, C);   // ?st kenar (2px kal?n ? ba?l?k ?izgisi)
  KLineH(CX-5, CY-3, 11, C);
  KLineH(CX-5, CY+4, 11, C);   // Alt kenar
  KLineV(CX-5, CY-4, 9,  C);   // Sol kenar
  KLineV(CX+5, CY-4, 9,  C);   // Sa? kenar
end;

// ?? ? (Restore) ikonu ? iki i? i?e kare ??????????????????????????????????
procedure DrawIconRestore(CX, CY: Integer; C: LongWord);
begin
  // Arka kare (?st-sa?, ofsetli)
  KLineH(CX-2, CY-5, 8, C); KLineH(CX-2, CY-4, 8, C);
  KLineH(CX+5, CY-5, 1, C); KLineH(CX+5, CY-4, 1, C);
  KLineV(CX+5, CY-5, 6, C);
  KLineH(CX-2, CY,   8, C);
  // ?n kare (alt-sol)
  KLineH(CX-5, CY-2, 8, C); KLineH(CX-5, CY-1, 8, C);
  KLineH(CX-5, CY+4, 8, C);
  KLineV(CX-5, CY-2, 7, C);
  KLineV(CX+2, CY-2, 7, C);
end;

// ?? _ (Minimize) ikonu ? altta yatay ?izgi ???????????????????????????????
procedure DrawIconMin(CX, CY: Integer; C: LongWord);
begin
  KLineH(CX-5, CY+4, 11, C);
  KLineH(CX-5, CY+5, 11, C);   // 2px kal?n
end;

// ?? Sistem Butonu ?izici ??????????????????????????????????????????????????
// BtnType: 0=Close 1=Max 2=Min
// Hot/Press: -1 ile kar??la?t?r?l?r
procedure DrawSysBtn(X, Y, W, H: Integer;
                     BtnType, HotBtn, PressBtn: Integer;
                     IsMaximized: Boolean);
var
  BgColor, IconColor: LongWord;
  CX, CY: Integer;
begin
  CX := X + W div 2;
  CY := Y + H div 2;

  // ?? Arka plan rengi ??????????????????????????????????????????????????
  BgColor := $00000000;  // ?effaf (ba?l?k bar?yla ayn?)
  if BtnType = PressBtn then begin
    case BtnType of
      0: BgColor := $8B1A10;   // K?rm?z? koyu (close bas?l?)
      1: BgColor := $8A4070;   // Koyu mavi (max bas?l?)
      2: BgColor := $8A4070;
    end;
  end else if BtnType = HotBtn then begin
    case BtnType of
      0: BgColor := RGB(232,17,35);   // Windows 10 k?rm?z? (close hover)
      1: BgColor := RGB(64,160,80);   // A??k mavi (max hover)
      2: BgColor :=RGB(39,174,96);// $3A6090;
    end;
  end;

  if BgColor <> $00000000 then
    KFill(X, Y, W, H, BgColor);

  // ?? ?kon rengi ???????????????????????????????????????????????????????
  IconColor := clWhite;

  // ?? ?konu ?iz ????????????????????????????????????????????????????????
  case BtnType of
    0: DrawIconX      (CX, CY,       IconColor);
    1: if IsMaximized then DrawIconRestore(CX, CY, IconColor)
       else               DrawIconMax    (CX, CY, IconColor);
    2: DrawIconMin    (CX, CY,       IconColor);
  end;
end;

// =============================================================================
// B?L?M 3 ? TForm yard?mc? metodlar (InitForm'dan ?nce implementation'a ekle)
// =============================================================================

// Hangi sistem butonu? Form-local (LX,LY) ? 0=Close 1=Max 2=Min -1=yok


procedure DrawForm(Sender: PForm; AbsX, AbsY: Integer);
const
  ACT_L = $1C3F6E; ACT_R = $2B6CB8;
  INV_L = $707070; INV_R = $9A9A9A;
var
  G1, G2: LongWord;
  CX, CY, CW, CH: Integer;
  BtnR,  BtnX,BtnY, BtnBH: Integer;
  FBtnPress:Integer;
begin

  if Sender <> WinManager.ActiveForm then
     DrawRect(Sender^.Left, Sender^.Top, Sender^.Width, Sender^.Height, clGray)
  else
     DrawRect(Sender^.Left, Sender^.Top, Sender^.Width, Sender^.Height, Sender^.BorderColor);

   // �� arka plan
  KFill(Sender^.Left + 1, Sender^.Top + 1, Sender^.Width - 2, Sender^.Height - 2, Sender^.Color);


  if Sender^.ShowHeader then
  begin

     // 3. Ba?l?k ?ubu?u
  if Sender = WinManager.ActiveForm then
    begin
      G1 := ACT_L;
      G2 := ACT_R;
  end
  else
  begin
     G1 := INV_L;
     G2 := INV_R;
  end;

  KGradientV(Sender^.Left + Sender^.BorderWidth, Sender^.Top + Sender^.BorderWidth, Sender^.Width-Sender^.BorderWidth, HEADER_HEIGHT-1, G1, G2);
  KLineH(Sender^.Left + Sender^.BorderWidth, Sender^.Top + Sender^.BorderWidth+HEADER_HEIGHT-1, Sender^.Width-Sender^.BorderWidth-2, $0A1F40);


   if Sender^.ShowCaption then
      KStr(Sender^.Left + Sender^.BorderWidth + 4,
           Sender^.Top + Sender^.BorderWidth + (HEADER_HEIGHT - 8) div 2,
           Sender^.Caption, clWhite);




  BtnBH := HEADER_H - 2;
  BtnR := Sender^.Left + Sender^.Width - Sender^.BorderWidth;
  BtnY := Sender^.Top + Sender^.BorderWidth + 2;
  

  FBtnPress:=0;

  // Close [X] (Daima ?izilir)
  DrawSysBtn(BtnR - SYSBUTTON_WIDTH, BtnY, SYSBUTTON_WIDTH, BtnBH, 0, Sender^.FBtnHot, FBtnPress, Sender^.Minimized);


  if Sender^.ShowSysButtons and  not Sender^.Modal then
  begin
    // Maximize/Restore [?]
    DrawSysBtn(BtnR - 2*SYSBUTTON_WIDTH - 2, BtnY, SYSBUTTON_WIDTH, BtnBH, 1, Sender^.FBtnHot, FBtnPress, Sender^.Maximized);
    // Minimize [_]
    DrawSysBtn(BtnR - 3*SYSBUTTON_WIDTH - 4, BtnY, SYSBUTTON_WIDTH, BtnBH, 2, Sender^.FBtnHot, FBtnPress, Sender^.Maximized);

    // Buton ay?r?c? dikey ?izgiler (Normal form)
    KLineV(BtnR - SYSBUTTON_WIDTH - 1,       BtnY+3, BtnBH-6, $3A70A0);
    KLineV(BtnR - 2*SYSBUTTON_WIDTH - 3,     BtnY+3, BtnBH-6, $3A70A0);
    KLineV(BtnR - 3*SYSBUTTON_WIDTH - 5,     BtnY+3, BtnBH-6, $3A70A0);
  end
  else
  begin
    // Modal formda sadece Kapat butonunun yan?na ?izgi ?ekilir
    KLineV(BtnR - SYSBUTTON_WIDTH - 1,       BtnY+3, BtnBH-6, $3A70A0);
  end;




  end;  

  GetFormClientRect(Sender, CX, CY, CW, CH);
  if (CW > 0) and (CH > 0) then
    KFill(CX, CY, CW, CH, Sender^.Color);
end;



{=============================================================================}
{ PaintObject - Orijinal + Client Clip & Scroll Offset                        }
{=============================================================================}

procedure PaintObject(Obj: PObject; X, Y: Integer);
var
  Child: PObject;
  AbsLeft, AbsTop: Integer;
  CX, CY, CW, CH: Integer;

  HPos, VPos: Integer;
  F: PForm;
begin
  if (Obj = nil) or not Obj^.Visible then Exit;

  AbsLeft := X + Obj^.Left;
  AbsTop := Y + Obj^.Top;

  Obj^.FirePaint(AbsLeft, AbsTop);

  Child := Obj^.Child;
  if Child <> nil then
  begin
    if Obj^.Parent = nil then
    begin
      F := PForm(Obj);

      Clip_Save;

      GetFormClientRect(F, CX, CY, CW, CH);

      HPos := F^.HScroll.Pos;
      VPos := F^.VScroll.Pos;

      if (CW > 0) and (CH > 0) then
        Clip_Set(CX, CY, CX + CW - 1, CY + CH - 1);

      while Child <> nil do
      begin
        if Child^.Visible then
          PaintObject(Child, AbsLeft - HPos, AbsTop - VPos);
        Child := Child^.Next;
      end;

     Clip_Restore;
     
    end
    else
    begin
      while Child <> nil do
      begin
        if Child^.Visible then
          PaintObject(Child, AbsLeft, AbsTop);
        Child := Child^.Next;
      end;
    end;
  end;
end;

{=============================================================================}
{ Nesne A?ac? ve Form Y?netimi (Orijinal)                                     }
{=============================================================================}

function FindObjectAt(Obj: PObject; X, Y: Integer): PObject;
var
  Child, Hit: PObject;
  AX, AY, W, H: Integer;
begin
  Result := nil;
  if (Obj = nil) or (Obj^.Visible = False) then Exit;

  GetAbsoluteRect(Obj, AX, AY, W, H);

  if not PtInRect(X, Y, AX, AY, W, H) then
     Exit;

  Child := Obj^.Child;
  if Child <> nil then
  begin
    while Child^.Next <> nil do
      Child := Child^.Next;

    while Child <> nil do
    begin
      Hit := FindObjectAt(Child, X, Y);
      if Hit <> nil then
      begin
        Result := Hit;
        Exit;
      end;
      Child := Child^.Previous;
    end;
  end;

  Result := Obj;
end;

function TWinManager.AddForm(AObj: PObject): Boolean;
var
  Cur: PObject;
begin
  Result := False;
  if AObj = nil then Exit;

  if ObjectList = nil then
  begin
    ObjectList := AObj;
    AObj^.Previous := nil;
    AObj^.Next := nil;
  end
  else
  begin
    Cur := ObjectList;
    while Cur^.Next <> nil do
      Cur := Cur^.Next;

    Cur^.Next := AObj;
    AObj^.Previous := Cur;
    AObj^.Next := nil;
  end;

   if PForm(AObj)^.Modal=False then
      TaskBar_AddWindow(PForm(AObj));


  Result := True;
end;

function TWinManager.CountObject: Integer;
var
  Cur: PObject;
begin
  Result := 0;
  Cur := ObjectList;
  while Cur <> nil do
  begin
    Inc(Result);
    Cur := Cur^.Next;
  end;
end;

procedure TObject.FreeEvents;
begin
  FreeDestroySlots(FOnDestroy);
  FreeKeyDownSlots(FOnKeyDown);
  FreeMouseSlots(FOnDblClick);
  FreeMouseSlots(FOnMouseDown);
  FreeMouseSlots(FOnMouseUp);
  FreeMouseSlots(FOnMouseMove);
  FreePaintSlots(FOnPaint);

  FOnDestroy   := nil;
  FOnKeyDown   := nil;
  FOnDblClick  := nil;
  FOnMouseDown := nil;
  FOnMouseUp   := nil;
  FOnMouseMove := nil;
  FOnPaint     := nil;
end;

procedure TWinManager.FreeObject(AObj: PObject);
var
  Child, NextChild: PObject;
  RootF: PForm;
begin
  if AObj = nil then Exit;

  RootF := FindRootForm(AObj^.Parent);

  { �nce �ocuklar� sil }
  Child := AObj^.Child;
  while Child <> nil do
  begin
    NextChild := Child^.Next;
    FreeObject(Child);
    Child := NextChild;
  end;

  { Kullan�c�n�n Destroy olay� }
  AObj^.FireDestroy(AObj);

  { Parent listesinden ��kar }
  if AObj^.Previous <> nil then
    AObj^.Previous^.Next := AObj^.Next
  else if AObj^.Parent <> nil then
    AObj^.Parent^.Child := AObj^.Next
  else
    ObjectList := AObj^.Next;

  if AObj^.Next <> nil then
    AObj^.Next^.Previous := AObj^.Previous;

  { Aktif form g�ncelle }
  if AObj = PObject(ActiveForm) then
  begin
    if AObj^.Previous <> nil then
      ActiveForm := PForm(AObj^.Previous)
    else
      ActiveForm := nil;
  end;

  AObj^.FreeEvents;

  FreeMem(AObj);

  if RootF <> nil then
    RelayoutForm(RootF);
end;



procedure TWinManager.Init;
begin
  ObjectList := nil;
  ActiveForm := nil;
  ActivePopup := nil;
  ActiveMenuBar := nil;
end;

procedure TWinManager.RemoveForm(F: PForm);
begin
  TaskBar_RemoveWindow(F);
  FreeObject(F);
  F:=Nil;
end;

procedure TWinManager.BringToFront(AObj: PForm);
var
  Cur: PObject;
begin
  if (AObj = nil) or (ObjectList = nil) then Exit;
  if AObj^.Next = nil then Exit;

  if AObj^.Previous <> nil then
    AObj^.Previous^.Next := AObj^.Next
  else
    ObjectList := AObj^.Next;

  if AObj^.Next <> nil then
    AObj^.Next^.Previous := AObj^.Previous;

  AObj^.Next := nil;
  AObj^.Previous := nil;

  Cur := ObjectList;
  while Cur^.Next <> nil do
    Cur := Cur^.Next;

  Cur^.Next := AObj;
  AObj^.Previous := Cur;

  ActiveForm := PForm(AObj);
end;

procedure TWinManager.FindActiveForm(X, Y: Integer);
var
  Cur, Hit: PObject;
  AX, AY, W, H: Integer;
begin
  Cur := ObjectList;
  if Cur = nil then Exit;
  while Cur^.Next <> nil do
    Cur := Cur^.Next;

  while Cur <> nil do
  begin
    if Cur^.Parent = nil then
    begin
      GetAbsoluteRect(Cur, AX, AY, W, H);
      if PtInRect(X, Y, AX, AY, W, H) and Cur^.Visible then
      begin
        if (ActiveForm = nil) or (ActiveForm^.Modal = False) then
          BringToFront(PForm(Cur));
        Exit;
      end;
    end;
    Cur := Cur^.Previous;
  end;
end;

function GetResizeEdge(F: PForm; X, Y: Integer; out Corner: TResizeCorner): Boolean;
var
  L, T, R, B: Integer;
begin
  Result := False;
  Corner := rcNone;

  L := F^.Left;
  T := F^.Top;
  R := F^.Left + F^.Width;
  B := F^.Top + F^.Height;

  if (X < L) or (X > R) or (Y < T) or (Y > B) then Exit;

  if (X - L <= BORDER_SIZE) then
  begin
    if (Y - T <= BORDER_SIZE) then begin Corner := rcTopLeft; Result := True; Exit; end;
    if (B - Y <= BORDER_SIZE) then begin Corner := rcBottomLeft; Result := True; Exit; end;
    Corner := rcLeft; Result := True; Exit;
  end;

  if (R - X <= BORDER_SIZE) then
  begin
    if (Y - T <= BORDER_SIZE) then begin Corner := rcTopRight; Result := True; Exit; end;
    if (B - Y <= BORDER_SIZE) then begin Corner := rcBottomRight; Result := True; Exit; end;
    Corner := rcRight; Result := True; Exit;
  end;

  if (Y - T <= BORDER_SIZE) then
  begin
    Corner := rcTop; Result := True; Exit;
  end;
  if (B - Y <= BORDER_SIZE) then
  begin
    Corner := rcBottom; Result := True; Exit;
  end;

  Result := False;
end;

function TWinManager.FormResizing(MouseX, MouseY: Integer; MouseState: Byte): Boolean;
var
  NewLeft, NewTop, NewWidth, NewHeight: Integer;
  WorkArea: TRect;
begin
  Result := False;

  case MouseState of
    0:
    begin
      InteractionState := fisIdle;
      ResizeCorner := rcNone;
      if ActiveForm = nil then Exit;
      if ActiveForm^.Maximized then Exit;
      if ActiveForm^.Minimized then Exit;

      if PtInRect(
           Rect(ActiveForm^.Left, ActiveForm^.Top,
                ActiveForm^.Left + ActiveForm^.Width,
                ActiveForm^.Top + HEADER_HEIGHT),
             MouseX, MouseY) then
      begin
        InteractionState := fisMoving;
        FormOffset.X := MouseX - ActiveForm^.Left;
        FormOffset.Y := MouseY - ActiveForm^.Top;
        Result := True;
        Exit;
      end;

      if GetResizeEdge(ActiveForm, MouseX, MouseY, ResizeCorner) then
      begin
        Cursor := 4;
        InteractionState := fisResizing;
        FormOffset.X := MouseX - ActiveForm^.Left;
        FormOffset.Y := MouseY - ActiveForm^.Top;
        Result := True;
      end;
    end;

    1:
    begin
      if InteractionState = fisIdle then Exit;

      NewLeft   := ActiveForm^.Left;
      NewTop    := ActiveForm^.Top;
      NewWidth  := ActiveForm^.Width;
      NewHeight := ActiveForm^.Height;

      if InteractionState = fisResizing then
      begin
        if ActiveForm^.BorderStyle <> bsWindow then Exit;
        Cursor := 4;
        case ResizeCorner of
          rcLeft: begin NewWidth := ActiveForm^.Width + (ActiveForm^.Left - MouseX); NewLeft := MouseX; end;
          rcRight: NewWidth := MouseX - ActiveForm^.Left;
          rcTop: begin NewHeight := ActiveForm^.Height + (ActiveForm^.Top - MouseY); NewTop := MouseY; end;
          rcBottom: NewHeight := MouseY - ActiveForm^.Top;
          rcTopLeft: begin
            NewWidth := ActiveForm^.Left + ActiveForm^.Width - MouseX;
            NewHeight := ActiveForm^.Top + ActiveForm^.Height - MouseY;
            NewLeft := MouseX; NewTop := MouseY;
          end;
          rcTopRight: begin
            NewWidth := MouseX - ActiveForm^.Left;
            NewHeight := ActiveForm^.Top + ActiveForm^.Height - MouseY;
            NewTop := MouseY;
          end;
          rcBottomRight: begin
            NewWidth := MouseX - ActiveForm^.Left;
            NewHeight := MouseY - ActiveForm^.Top;
          end;
          rcBottomLeft: begin
            NewWidth := ActiveForm^.Left + ActiveForm^.Width - MouseX;
            NewHeight := MouseY - ActiveForm^.Top;
            NewLeft := MouseX;
          end;
        end;

        NewWidth  := Max(MIN_FORM_WIDTH,  Min(NewWidth,  MAX_FORM_WIDTH));
        NewHeight := Max(MIN_FORM_HEIGHT, Min(NewHeight, MAX_FORM_HEIGHT));
      end
      else if InteractionState = fisMoving then
      begin
        NewLeft := MouseX - FormOffset.X;
        NewTop  := MouseY - FormOffset.Y;
      end;

      WorkArea := Rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
      NewLeft := Max(WorkArea.Left,   Min(NewLeft, WorkArea.Right  - NewWidth));
      NewTop  := Max(WorkArea.Top,    Min(NewTop,  WorkArea.Bottom - NewHeight));

      if (NewLeft <> ActiveForm^.Left) or (NewTop <> ActiveForm^.Top) or
         (NewWidth <> ActiveForm^.Width) or (NewHeight <> ActiveForm^.Height) then
      begin
        ActiveForm^.Left   := NewLeft;
        ActiveForm^.Top    := NewTop;
        ActiveForm^.Width  := NewWidth;
        ActiveForm^.Height := NewHeight;
        RelayoutForm(ActiveForm);
      end;

      Result := True;
    end;

    2:
    begin
      InteractionState := fisIdle;
      ResizeCorner := rcNone;
      Result := False;
    end;
  end;
end;


procedure MenuBarMouseDown(Sender: PMenuBar; AX, AY: Integer; Btn: Byte);
var
  I: Integer;
  Item: PMenuItem;
begin
  if Btn <> 1 then Exit;
  for I := 0 to Sender^.ItemCount - 1 do
  begin
    Item := PMenuItem(Sender^.Items^[I]);
    if Item = nil then Continue;
    if (AX >= Item^.ItemLeft) and (AX < Item^.ItemLeft + Item^.ItemWidth) and
       (AY >= 0) and (AY < MENU_BAR_HEIGHT) then
    begin
      if Sender^.ActiveIndex = I then
      begin
        Sender^.ActiveIndex := -1;
        Item^.SubMenuVisible := False;
        MenuPopupCloseAllSubMenus(Item);   { YENI }
        WinManager.ActiveMenuBar := nil;   { zaten vardi }
      end
      else
      begin
        if (Sender^.ActiveIndex >= 0) and
           (Sender^.ActiveIndex < Sender^.ItemCount) then
        begin
          PMenuItem(Sender^.Items^[Sender^.ActiveIndex])^.SubMenuVisible := False;
          MenuPopupCloseAllSubMenus(PMenuItem(Sender^.Items^[Sender^.ActiveIndex])); { YENI }
        end;
        Sender^.ActiveIndex := I;
        Item^.SubMenuVisible := True;
        WinManager.ActiveMenuBar := Sender; { zaten vardi }
      end;
      Exit;
    end;
  end;
  if Sender^.ActiveIndex >= 0 then
  begin
    PMenuItem(Sender^.Items^[Sender^.ActiveIndex])^.SubMenuVisible := False;
    MenuPopupCloseAllSubMenus(PMenuItem(Sender^.Items^[Sender^.ActiveIndex])); { YENI }
    Sender^.ActiveIndex := -1;
    WinManager.ActiveMenuBar := nil;        { zaten vardi }
  end;
end;


procedure MenuBarMouseMove(Sender: PMenuBar; AX, AY: Integer; Btn: Byte);
var
  I: Integer;
  Item: PMenuItem;
  PItem: PMenuItem;
begin
  Sender^.HoverIndex := -1;
  if (AY < 0) or (AY >= MENU_BAR_HEIGHT) then Exit;
  for I := 0 to Sender^.ItemCount - 1 do
  begin
    Item := PMenuItem(Sender^.Items^[I]);
    if Item = nil then Continue;
    if (AX >= Item^.ItemLeft) and (AX < Item^.ItemLeft + Item^.ItemWidth) then
    begin
      Sender^.HoverIndex := I;
      if (Sender^.ActiveIndex >= 0) and (Sender^.ActiveIndex <> I) then
      begin
        { ESKI popup'i ve tum alt agacini kapat }
        PItem := PMenuItem(Sender^.Items^[Sender^.ActiveIndex]);
        if PItem <> nil then
        begin
          PItem^.SubMenuVisible := False;
          MenuPopupCloseAllSubMenus(PItem);   { YENI }
        end;
        Sender^.ActiveIndex := I;
        Item^.SubMenuVisible := True;
        WinManager.ActiveMenuBar := Sender;
      end;
      Exit;
    end;
  end;
end;




{=============================================================================}
{ Mouse Event Y?netimi                                                        }
{=============================================================================}

procedure TWinManager.MouseDown(MX, MY: Integer; Btn: Byte);
var
  Hit: PObject;
  SysBtn: Integer;
  Part: Integer;
  Handled: Boolean;
    ClickedItem: PMenuItem;
    PItem: PMenuItem;
   Item: PMenuItem;
  SubItem: PMenuItem;
  I, ItemH, RelY, MaxW: Integer;
  Proc: PProcess;
begin

   { === ONCELIK 1: Acik menubar popup agaci (cascade dahil) === }
    if (ActiveMenuBar <> nil) and (Btn = 1) then
    begin
      MenuPopupProcessMouseDown(PMenuBar(ActiveMenuBar), MX, MY, Handled, ClickedItem);
      if Handled then Exit;   { Bir item'e tiklandi (acildi veya click calisti) }

      { Popup disina tiklandi -> tum agaci kapat }
      if (PMenuBar(ActiveMenuBar)^.ActiveIndex >= 0) then
      begin
        PItem := PMenuItem(PMenuBar(ActiveMenuBar)^.Items^[PMenuBar(ActiveMenuBar)^.ActiveIndex]);
        if PItem <> nil then
        begin
          MenuPopupCloseAllSubMenus(PItem);
          PItem^.SubMenuVisible := False;
        end;
      end;
      PMenuBar(ActiveMenuBar)^.ActiveIndex := -1;
      WinManager.ActiveMenuBar := nil;
      Exit;  { Sol tik alttaki nesneyi etkilemesin }
    end;


  if (ActivePopup <> nil) and ActivePopup^.Visible then
  begin
    if ActivePopup^.HitTest(MX, MY) >= 0 then
    begin
      ActivePopup^.MouseDown(MX, MY, Btn);
      Exit;  { Event t�ketildi }
    end
    else
    begin
      ActivePopup^.Hide;  { D��ar� t�klan�nca kapan�r }
      if Btn = 1 then Exit; { Sol t�klama alttaki nesneyi tetiklemez }
    end;
  end;




  FindActiveForm(MX, MY);

  { Sistem butonlari ve scrollbar, form kenarindaki BORDER_SIZE resize
    alaniyla gorsel olarak cakisabildigi icin (BorderWidth < BORDER_SIZE),
    bu ikisi her zaman resize testinden ONCE kontrol edilmeli. Aksi halde
    scrollbar'a yapilan bir tiklama yanlislikla "kenardan yeniden boyutlandirma"
    olarak alginip formun surukleme sirasinda kucul/kaybol gibi davranmasina
    yol acabiliyordu. }
  if (ActiveForm <> nil) and not ActiveForm^.Minimized then
  begin
    if FormVScrollHitTest(ActiveForm, MX, MY, Part) then
    begin
      FormVScrollMouseDown(ActiveForm, Part, MY);
      Exit;
    end;
    if FormHScrollHitTest(ActiveForm, MX, MY, Part) then
    begin
      FormHScrollMouseDown(ActiveForm, Part, MX);
      Exit;
    end;
  end;

  if (ActiveForm <> nil) and ActiveForm^.ShowSysButtons and not ActiveForm^.Minimized then
  begin
    if FormSysButtonHitTest(ActiveForm, MX, MY, SysBtn) then
    begin
      case SysBtn of
        0: begin
             if not ActiveForm^.Minimized then
             begin
               ActiveForm^.Minimized := True;
               ActiveForm^.Visible:=False;
             {  ActiveForm^.NormalBounds.Left := ActiveForm^.Left;
               ActiveForm^.NormalBounds.Top := ActiveForm^.Top;
               ActiveForm^.NormalBounds.Right := ActiveForm^.Left + ActiveForm^.Width;
               ActiveForm^.NormalBounds.Bottom := ActiveForm^.Top + ActiveForm^.Height;
               ActiveForm^.Height := HEADER_HEIGHT + 2 * ActiveForm^.BorderWidth;
               RelayoutForm(ActiveForm); }
             end;
           end;
        1: begin
             if ActiveForm^.Maximized then
             begin
               ActiveForm^.Maximized := False;
               ActiveForm^.Minimized := False;
               ActiveForm^.Left := ActiveForm^.NormalBounds.Left;
               ActiveForm^.Top := ActiveForm^.NormalBounds.Top;
               ActiveForm^.Width := ActiveForm^.NormalBounds.Right - ActiveForm^.NormalBounds.Left;
               ActiveForm^.Height := ActiveForm^.NormalBounds.Bottom - ActiveForm^.NormalBounds.Top;
             end
             else
             begin
               ActiveForm^.Maximized := True;
               ActiveForm^.Minimized := False;
               ActiveForm^.NormalBounds.Left := ActiveForm^.Left;
               ActiveForm^.NormalBounds.Top := ActiveForm^.Top;
               ActiveForm^.NormalBounds.Right := ActiveForm^.Left + ActiveForm^.Width;
               ActiveForm^.NormalBounds.Bottom := ActiveForm^.Top + ActiveForm^.Height;
               ActiveForm^.Left := 0;
               ActiveForm^.Top := 0;
               ActiveForm^.Width := SCREEN_WIDTH;
               ActiveForm^.Height := SCREEN_HEIGHT;
             end;
             RelayoutForm(ActiveForm);
           end;
        2: begin
              Proc:=PProcess(ActiveForm^.OwnerProcess);
              if Proc<>Nil then
              begin
               //  KernelDESTROY(ActiveForm);
                 ProcessKillByHWND(ActiveForm);
              end
              else
                 RemoveForm(ActiveForm);
           end;
      end;
      Exit;
    end;
  end;

  if FormResizing(MX, MY, 0) then Exit;

  if (ActiveForm <> nil) and ActiveForm^.Minimized then Exit;

  if MouseCapture<>nil then
  begin
    MouseCapture^.FireMouseDown(MX,MY,Btn);
    Exit;
  end;

  Hit := FindObjectAt(ActiveForm, MX, MY);
  if (Hit <> nil) and Hit^.Enabled then
  begin
     ActiveForm^.ActiveControl := Hit;
     Hit^.FireMouseDown(MX, MY, Btn);

    // ActiveForm^.SetFocus(Hit);

      Proc:=PProcess(ActiveForm^.OwnerProcess);
      if Proc<>Nil then
      begin
         PostCommand(Proc, LongWord(ActiveForm), LongWord(Hit), Btn);
      end

  end;
end;

procedure TWinManager.MouseMove(MX, MY: Integer; Btn: Byte);
var
  Hit: PObject;
   Item: PMenuItem;
  SubItem: PMenuItem;
  I, ItemH, RelY, MaxW,SysBtn: Integer;
begin

   { === Menubar Cascade Popup Hover === }
    if (ActiveMenuBar <> nil) then
    begin
      MenuPopupProcessMouseMove(PMenuBar(ActiveMenuBar), MX, MY);
      Exit;  { Olayi tuket, imleci normal birak }
    end;


    if (ActivePopup <> nil) and ActivePopup^.Visible then
  begin
    ActivePopup^.MouseMove(MX, MY);
    Exit;
  end;


  if FormResizing(MX, MY, 1) then Exit;

  if (ActiveForm <> nil) and not ActiveForm^.Minimized then
  begin
    if ActiveForm^.VScroll.Dragging then
    begin
      FormVScrollMouseMove(ActiveForm, MY);
      Exit;
    end;
    if ActiveForm^.HScroll.Dragging then
    begin
      FormHScrollMouseMove(ActiveForm, MX);
      Exit;
    end;
    ActiveForm^.FBtnHot:=-1;
    if FormSysButtonHitTest(ActiveForm, MX, MY, SysBtn) then
    begin
      case SysBtn of
        0: ActiveForm^.FBtnHot:=2;
        1: ActiveForm^.FBtnHot:=1;
        2: ActiveForm^.FBtnHot:=0;

      end;
   end;
  end;


  if MouseCapture<>nil then
  begin
    MouseCapture^.FireMouseMove(MX,MY,Btn);
    Exit;
  end;

  Hit := FindObjectAt(ActiveForm, MX, MY);

  if Hit <> LastHitObject then
  begin
    if (LastHitObject <> nil) then
      LastHitObject^.Hover := False;
    if (Hit <> nil) then
      Hit^.Hover := True;
    LastHitObject := Hit;
  end;

  if (Hit <> nil) and Hit^.Enabled then
  begin
    Hit^.FireMouseMove(MX, MY, Btn);
    Cursor := Hit^.Cursor;
  end
  else
    Cursor := 0;
end;

procedure TWinManager.MouseUp(MX, MY: Integer; Btn: Byte);
var
  Hit: PObject;
  Part: Integer;
begin
  Cursor := 0;


  if (ActiveForm <> nil) then
  begin
    if ActiveForm^.VScroll.Dragging or ActiveForm^.VScroll.Arrow1Pressed or
       ActiveForm^.VScroll.Arrow2Pressed or ActiveForm^.VScroll.Page1Pressed or
       ActiveForm^.VScroll.Page2Pressed then
      FormVScrollMouseUp(ActiveForm);
    if ActiveForm^.HScroll.Dragging or ActiveForm^.HScroll.Arrow1Pressed or
       ActiveForm^.HScroll.Arrow2Pressed or ActiveForm^.HScroll.Page1Pressed or
       ActiveForm^.HScroll.Page2Pressed then
      FormHScrollMouseUp(ActiveForm);
  end;

  if FormResizing(MX, MY, 2) then Exit;

  if (ActiveForm <> nil) and not ActiveForm^.Minimized then
  begin
    if FormVScrollHitTest(ActiveForm, MX, MY, Part) then Exit;
    if FormHScrollHitTest(ActiveForm, MX, MY, Part) then Exit;
  end;

  if MouseCapture<>nil then
  begin
    MouseCapture^.FireMouseUp(MX,MY,Btn);
    Exit;
  end;




  Hit := FindObjectAt(ActiveForm, MX, MY);
  if (Hit <> nil) and Hit^.Enabled then
  begin
     Hit^.FireMouseUp(MX, MY, Btn);
  end;

  LastHitObject := nil;
end;

procedure TWinManager.DblClick(MX, MY: Integer; Btn: Byte);
var
  Hit: PObject;
  SysBtn, Part: Integer;
begin
  { Cift tiklama scrollbar veya sistem butonlari uzerindeyse, bunu
    formun/kontrolun kendi OnDblClick olayina yonlendirmemeliyiz.
    Aksi halde -orn. bu unit'in test kodundaki gibi- formun
    OnDblClick'ine "formu kapat" baglanmissa, scrollbara cift tiklamak
    formu tamamen yok eder. }
  if (ActiveForm <> nil) and not ActiveForm^.Minimized then
  begin
    if FormVScrollHitTest(ActiveForm, MX, MY, Part) then Exit;
    if FormHScrollHitTest(ActiveForm, MX, MY, Part) then Exit;
    if ActiveForm^.ShowSysButtons and FormSysButtonHitTest(ActiveForm, MX, MY, SysBtn) then Exit;
  end;

  Hit := FindObjectAt(ActiveForm, MX, MY);
  if (Hit <> nil) and Hit^.Enabled then
  begin
     Hit^.FireDblClick(MX, MY, Btn);
  end;
end;

procedure TWinManager.KeyDown(Key: Word);
var
PItem : PMenuItem;
Proc:PProcess;
begin
  if (ActivePopup <> nil) and ActivePopup^.Visible then
  begin
    if Key = 27 then ActivePopup^.Hide;  { ESC ile kapat }
    Exit;
  end;


  if (ActiveMenuBar <> nil) and (Key = 27) then  { ESC }
  begin
    if (PMenuBar(ActiveMenuBar)^.ActiveIndex >= 0) then
    begin
      PItem := PMenuItem(PMenuBar(ActiveMenuBar)^.Items^[PMenuBar(ActiveMenuBar)^.ActiveIndex]);
      if PItem <> nil then
      begin
        MenuPopupCloseAllSubMenus(PItem);
        PItem^.SubMenuVisible := False;
      end;
    end;
    PMenuBar(ActiveMenuBar)^.ActiveIndex := -1;
    WinManager.ActiveMenuBar := nil;
    Exit;
  end;


  if Key = VK_TAB then
  begin
    if ActiveForm <> nil then        { <-- nil kontrol� eklendi }
      ActiveForm^.FocusNext;
    Exit;
  end;




  if ActiveForm = nil then Exit;
  if ActiveForm^.ActiveControl <> nil then
    ActiveForm^.ActiveControl^.FireKeyDown(Key)
  else
    ActiveForm^.FireKeyDown(Key);



    Proc:=PProcess(ActiveForm^.OwnerProcess);
    if Proc<>Nil then
    begin
      KernelKeyDown(ActiveForm,Key);
    end
end;



procedure TWinManager.KeyUp(Key: Word);
var
PItem : PMenuItem;
Proc:PProcess;
begin



  if ActiveForm = nil then Exit;
  if ActiveForm^.ActiveControl <> nil then
    ActiveForm^.ActiveControl^.FireKeyUp(Key)
  else
    ActiveForm^.FireKeyUp(Key);



    Proc:=PProcess(ActiveForm^.OwnerProcess);
    if Proc<>Nil then
    begin
      KernelKeyUp(ActiveForm,Key);
    end
end;

{=============================================================================}
{ Ana D?ng? ve ?izim                                                          }
{=============================================================================}

procedure TWinManager.PaintAll;
var
  Cur: PObject;
  F: PForm;
  Item : PMenuItem;
  Proc:PProcess;
  MouseLP:LongWord;
begin
  Cur := ObjectList;
  while Cur <> nil do
  begin
    if Cur^.Visible then
    begin
      PaintObject(Cur, 0, 0);
      if Cur^.Parent = nil then
      begin
           F := PForm(Cur);
           Proc:=PProcess(F^.OwnerProcess);
           if Proc<>Nil then
           begin
              KernelPaint(Proc,F,F^.Left,F^.Top);
            end;


        if F^.VScroll.Visible then DrawFormVScroll(F);
        if F^.HScroll.Visible then DrawFormHScroll(F);

           
       end;
    end;
    Cur := Cur^.Next;
  end;

   if (ActivePopup <> nil) and ActivePopup^.Visible then
    ActivePopup^.Draw;

    { === MENUBAR POPUP EN �STTE === }
  if (ActiveMenuBar <> nil) then
  begin
    if (PMenuBar(ActiveMenuBar)^.ActiveIndex >= 0) and
       (PMenuBar(ActiveMenuBar)^.ActiveIndex < PMenuBar(ActiveMenuBar)^.ItemCount) then
    begin
      Item := PMenuItem(PMenuBar(ActiveMenuBar)^.Items^[PMenuBar(ActiveMenuBar)^.ActiveIndex]);
      if (Item <> nil) and Item^.SubMenuVisible then
        MenuPopupDraw(Item,
          PMenuBar(ActiveMenuBar)^.PopupAbsX + Item^.ItemLeft,
          PMenuBar(ActiveMenuBar)^.PopupAbsY);
    end;
  end;
end;

procedure btnFormDown(Sender: PForm; X, Y: Integer; Btn: Byte);
begin
  WinManager.RemoveForm(Sender);
end;

procedure OnPopupCut(Item: PPopupMenuItem);
begin
  { Kes i�lemi }
end;

procedure OnPopupCopy(Item: PPopupMenuItem);
begin
  { Kopyala i�lemi }
end;



{ ============================================================
  Yardimci: Fare herhangi bir gorunur form uzerinde mi?
  ============================================================ }
function IsMouseOverAnyForm(X, Y: Integer): Boolean;
var
  Cur: PObject;
  AX, AY, W, H: Integer;
begin
  Result := False;
  Cur := WinManager.ObjectList;
  while Cur <> nil do
  begin
    if (Cur^.Parent = nil) and Cur^.Visible then
    begin
      GetAbsoluteRect(Cur, AX, AY, W, H);
      if PtInRect(X, Y, AX, AY, W, H) then
      begin
        Result := True;
        Exit;
      end;
    end;
    Cur := Cur^.Next;
  end;
end;

{ ============================================================
  Ana Dongu - Mouse Olay Siralamasi
  ============================================================
  Sira: 1.Move -> 2.Down -> 3.Up -> 4.DblClick
  Neden: 
    - Move her zaman ilk (konum guncellemesi)
    - Down once, Up sonra (basma birakma mantigi)
    - DblClick en son (Down/Up zincirinin sonucu)
  ============================================================ }


procedure Test_DrawAllIcons(StartX, StartY, IconSize: Integer);
const
  Cols = 5;         // Her sat�rdaki ikon say�s�
  SpacingX = 80;    // �konlar aras� yatay mesafe
  SpacingY = 70;    // �konlar aras� dikey mesafe

 
var
  Icon: TIconType;
  Index, Col, Row: Integer;
  CurX, CurY: Integer;
begin
  Index := 0;

  for Icon := Low(TIconType) to High(TIconType) do
  begin
    // Izgara koordinatlar�n� hesapla
    Col := Index mod Cols;
    Row := Index div Cols;

    CurX := StartX + (Col * SpacingX);
    CurY := StartY + (Row * SpacingY);

    // �kon arka plan�na hafif bir kart/�er�eve �iz (opsiyonel)
    KFillAlpha(CurX - 4, CurY - 4, IconSize + 8, IconSize + 22, clBlack, 40);

    // �konu �iz
    DrawIcon(CurX, CurY, IconSize, Icon);

    // �konun alt�na ismini yaz
    KStrCentered(CurX - 4, CurY + IconSize + 4, IconSize + 8, IconNames[Icon], clWhite);

    Inc(Index);
  end;
end;


procedure TWinManager.ProcessMessages(PM: Boolean = False);
var
  OverForm: Boolean;
begin
  Cls($800080);

 // Move(Wall_Data[0], Screen_Buffer[0], SCREEN_SIZE);

  Desktop_Render;
  TaskBar_Render;

  UpdateTimers;

  WriteInt(250, 40, FreeMemory, clBlack);
  WriteInt(250, 50, GetFreeMemKB, clBlack);
  WriteInt(250, 60, (FreeMemory - GetFreeMemKB), clBlack);

  PaintAll;

  


// Test_DrawAllIcons(300,10,48);

 // _WriteStr(100,100,'�����',clWhite);

  { ----------------------------------------------------------
    1. MOUSE MOVE (Her zaman ILK - koordinat guncellemesi)
    ---------------------------------------------------------- }
  if MouseState.IsMove then
  begin
    MouseMove(MouseState.X, MouseState.Y, 0);
    
   
    if not IsMouseOverAnyForm(MouseState.X, MouseState.Y) then
      Desktop_HandleMouseMove(MouseState.X, MouseState.Y);
  end;


  

  if MouseState.LeftDown then
  begin

    TaskBar_HandleClick(MouseState.X, MouseState.Y);


    MouseDown(MouseState.X, MouseState.Y, 1);
  end;


  if MouseState.RightDown then
  begin
    MouseDown(MouseState.X, MouseState.Y, 2);
  end;


  if MouseState.LeftUp then
  begin
    MouseUp(MouseState.X, MouseState.Y, 1);
    

    if not IsMouseOverAnyForm(MouseState.X, MouseState.Y) then
      Desktop_HandleMouseUp(MouseState.X, MouseState.Y);
  end;


  if MouseState.RightUp then
  begin
    MouseUp(MouseState.X, MouseState.Y, 2);
  end;


  if MouseState.DblClick then
  begin
    DblClick(MouseState.X, MouseState.Y, 3);
    
    if not IsMouseOverAnyForm(MouseState.X, MouseState.Y) then
      Desktop_HandleDoubleClick(MouseState.X, MouseState.Y);
  end;
       
  { ----------------------------------------------------------
    Ekran guncelleme
    ---------------------------------------------------------- }
  Mouse_DrawCursor;
  Move(Screen_Buffer, Pointer(Vesa_Info.PhysBasePtr)^, SCREEN_SIZE);
  
  { Tum event'leri tek seferde temizle }
  Mouse_ClearEvents;

  asm
    sti;
    hlt
  end;
end;

{=============================================================================}
{ Factory Fonksiyonlar?                                                       }
{=============================================================================}


function CreateForm(const ACaption: PChar; ALeft, ATop, AWidth, AHeight: Integer;BorderStyle: TBorderStyle): PForm;
begin
  Result := MemAlloc(SizeOf(TForm));
  FillChar(Result^, SizeOf(TForm), #0);
  Move(ACaption[0], Result^.Caption[0], StrLen(ACaption));

  if (ALeft = 0) and (ATop = 0) and (AWidth = 0) and (AHeight = 0) then
  begin
    Result^.Width  := FORM_WIDTH;
    Result^.Height := FORM_HEIGHT;
    Result^.Left := (SCREEN_WIDTH - FORM_WIDTH) div 2;
    Result^.Top  := (SCREEN_HEIGHT - FORM_HEIGHT) div 2;
  end
  else
  begin
    Result^.Left := ALeft;
    Result^.Top := ATop;
    if AWidth > 0 then Result^.Width := AWidth else Result^.Width := FORM_WIDTH;
    if AHeight > 0 then Result^.Height := AHeight else Result^.Height := FORM_HEIGHT;
  end;

  Result^.Color := C_FORM_BG;
  Result^.Visible := True;
  Result^.Cursor := 0;
  Result^.ShowCaption := True;
  Result^.ShowHeader := True;
  Result^.ShowSysButtons := True;
  Result^.Position:= poDefault;
  Result^.Handle := 0;
  Result^.Parent := nil;
  Result^.Child := nil;
  Result^.BorderColor := clNavy;
  Result^.BorderWidth := 2;
  Result^.BorderStyle := bsWindow;
  Result^.Enabled := True;
  Result^.ZIndex := 0;
  Result^.Maximized := False;
  Result^.Minimized := False;
  Result^.BorderStyle:= BorderStyle;
  Result^.Modal:= BorderStyle=bsDialog;

  // Scroll init
  FillChar(Result^.VScroll, SizeOf(TScrollState), 0);
  FillChar(Result^.HScroll, SizeOf(TScrollState), 0);

  Result^.BindPaint(@DrawForm);

  if WinManager.AddForm(PObject(Result)) then
     WinManager.ActiveForm := Result;
end;


end.

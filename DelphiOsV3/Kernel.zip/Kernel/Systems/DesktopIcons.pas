unit DesktopIcons;

{ ============================================================================
  DesktopIcons.pas

  Desktop.pas'taki TDesktopItem icin, gercek bitmap olmadan SADECE Draw32.pas
  vektorel fonksiyonlarini kullanarak "ImageIndex" degerine gore 32x32 masaustu
  ikonu cizer. FileIcons.pas'taki mantigin ayni (uzanti yerine burada sabit
  bir tur listesi var, cunku masaustu ogeleri dosya degil kisayol/uygulama).

  Kullanim (Desktop.pas icinde):
    Desktop_DrawIcon icindeki "Default icon" blogu yerine:
      DrawDesktopIcon(iconX, iconY, 32, Item^.ImageIndex);

    Desktop_AddItem cagrilarina ImageIndex eklenir (asagida ornekler var).
============================================================================ }

interface

uses
  SysUtils, Draw32;

const
  { --- Masaustu ikon turleri (ImageIndex degerleri) --- }
  DI_MYCOMPUTER = 0;
  DI_PICTURES   = 1;   { Resimlerim }
  DI_MUSIC      = 2;   { Muziklerim }
  DI_DOCUMENTS  = 3;   { Belgelerim }
  DI_SETTINGS   = 4;   { Ayarlar }
  DI_SYSINFO    = 5;   { Sistem Bilgisi }
  DI_TASKMGR    = 6;   { Gorev Yoneticisi }
  DI_HDD        = 7;   { Disk / HDD }
  DI_MEMORY     = 8;   { Bellek (RAM) }
  DI_BROWSER    = 9;   { Web Tarayici }
  DI_PAINT      = 10;  { Paint / Cizim }
  DI_CALC       = 11;  { Hesap Makinesi }
  DI_TEXTEDIT   = 12;  { Metin Duzenleyici }
  DI_RECYCLEBIN = 13;  { Geri Donusum Kutusu }
  DI_NETWORK    = 14;  { Ag / Network }
  DI_FOLDER     = 15;  { Genel klasor }
  DI_GENERIC    = 16;  { Bilinmeyen / genel uygulama }

{ Ana cizim fonksiyonu - Desktop_DrawIcon icinden cagrilir }
procedure DrawDesktopIcon(X, Y, Size: Integer; ImageIndex: Integer);

{ Tek tek erisim (gerekirse) }
procedure DrawIconMyComputer(X, Y, Size: Integer);
procedure DrawIconPictures(X, Y, Size: Integer);
procedure DrawIconMusic(X, Y, Size: Integer);
procedure DrawIconDocuments(X, Y, Size: Integer);
procedure DrawIconSettings(X, Y, Size: Integer);
procedure DrawIconSysInfo(X, Y, Size: Integer);
procedure DrawIconTaskMgr(X, Y, Size: Integer);
procedure DrawIconHDD(X, Y, Size: Integer);
procedure DrawIconMemory(X, Y, Size: Integer);
procedure DrawIconBrowser(X, Y, Size: Integer);
procedure DrawIconPaint(X, Y, Size: Integer);
procedure DrawIconCalc(X, Y, Size: Integer);
procedure DrawIconTextEdit(X, Y, Size: Integer);
procedure DrawIconRecycleBin(X, Y, Size: Integer);
procedure DrawIconNetwork(X, Y, Size: Integer);
procedure DrawIconFolder(X, Y, Size: Integer);
procedure DrawIconGeneric(X, Y, Size: Integer);

implementation

{=============================================================================}
{ MY COMPUTER - monitor + govde                                              }
{=============================================================================}
procedure DrawIconMyComputer(X, Y, Size: Integer);
var
  MonW, MonH, MonX, MonY: Integer;
begin
  MonW := Size - (Size div 6);
  MonH := (Size * 2) div 3;
  MonX := X + (Size - MonW) div 2;
  MonY := Y + (Size div 12);

  { Ekran cercevesi }
  KRoundRect(MonX, MonY, MonW, MonH, 3, $00203050, $00587090);
  { Ekran ici (mavi ekran) }
  KFill(MonX + 3, MonY + 3, MonW - 6, MonH - 10, $0060A0F0);
  KLineH(MonX + 5, MonY + 7, MonW - 10, $00A0D0FF);

  { Govde / stand }
  KFill(X + (Size div 2) - (Size div 10), MonY + MonH, Size div 5, Size div 10, $00405060);
  KFill(X + (Size div 4), MonY + MonH + Size div 10, Size div 2, Size div 14, $00304050);
end;

{=============================================================================}
{ RESIMLERIM - cerceve + dag + gunes                                        }
{=============================================================================}
procedure DrawIconPictures(X, Y, Size: Integer);
var
  L, T, W, H: Integer;
begin
  L := X + (Size div 8);
  T := Y + (Size div 8);
  W := Size - (Size div 4);
  H := Size - (Size div 4);

  KFill(L, T, W, H, clWhite);
  KRect(L, T, W, H, $00305078);

  KFillCircle(L + W - (W div 4), T + (H div 4), Size div 12, $00FFC000);
  KFillTriangle(L + 2, T + H - 2, L + (W div 3), T + (H div 3), L + (W div 2) + 2, T + H - 2, $0040A040);
  KFillTriangle(L + (W div 3), T + H - 2, L + (2 * W div 3), T + (H div 4), L + W - 2, T + H - 2, $00308030);
end;

{=============================================================================}
{ MUZIKLERIM - nota simgesi                                                  }
{=============================================================================}
procedure DrawIconMusic(X, Y, Size: Integer);
var
  StemX, HeadY, HeadR, StemTop: Integer;
begin
  HeadR   := Size div 7;
  StemX   := X + (Size div 3);
  HeadY   := Y + Size - (Size div 5) - HeadR;
  StemTop := Y + (Size div 8);

  { Notanin sapı }
  KFill(StemX + HeadR - 2, StemTop, 3, HeadY - StemTop, $00203060);
  { Bayrak (flag) }
  KFillTriangle(StemX + HeadR + 1, StemTop,
                StemX + HeadR + (Size div 4), StemTop + (Size div 8),
                StemX + HeadR + 1, StemTop + (Size div 4), $00203060);

  { Nota basi (oval) }
  KFillEllipse(StemX, HeadY, HeadR, HeadR - 2, $00203060);

  { Ikinci (kucuk) nota - stereo/muzik hissi }
  KFillCircle(X + Size - (Size div 5), Y + Size - (Size div 4), Size div 10, $00203060);
  KFill(X + Size - (Size div 5) + (Size div 10) - 2, Y + (Size div 3),
        3, (Y + Size - (Size div 4)) - (Y + (Size div 3)), $00203060);
end;

{=============================================================================}
{ BELGELERIM - kagit yigin + satirlar                                       }
{=============================================================================}
procedure DrawIconDocuments(X, Y, Size: Integer);
var
  L, T, W, H, i: Integer;
begin
  { Arkadaki kagit (hafif kaydirilmis, yigin hissi) }
  L := X + (Size div 6);
  T := Y + (Size div 10);
  W := Size - (Size div 3);
  H := Size - (Size div 5);
  KFill(L + 4, T + 4, W, H, $00D8D8D8);
  KRect(L + 4, T + 4, W, H, cl3DShadow);

  { On kagit }
  KFill(L, T, W, H, clWhite);
  KRect(L, T, W, H, $00305078);

  for i := 1 to 3 do
    KLineH(L + 5, T + (H div 4) * i, W - 10, $00A0A0A0);
end;

{=============================================================================}
{ AYARLAR - disli carki                                                     }
{=============================================================================}
procedure DrawIconSettings(X, Y, Size: Integer);
var
  CX, CY, R, i, Angle, Px, Py: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := (Size div 2) - (Size div 8);

  for i := 0 to 7 do
  begin
    Angle := i * 45;
    Px := CX + (R * Cos_Int(Angle)) div 10000;
    Py := CY + (R * Sin_Int(Angle)) div 10000;
    KFillCircle(Px, Py, Size div 10, $00707070);
  end;

  KFillCircle(CX, CY, R - (Size div 12), $00909090);
  KCircle(CX, CY, R - (Size div 12), $00505050);
  KFillCircle(CX, CY, Size div 10, clWhite);
  KCircle(CX, CY, Size div 10, $00505050);
end;

{=============================================================================}
{ SISTEM BILGISI - "i" harfli bilgi rozeti                                  }
{=============================================================================}
procedure DrawIconSysInfo(X, Y, Size: Integer);
var
  CX, CY, R: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := (Size div 2) - (Size div 10);

  KFillCircle(CX, CY, R, $004080D0);
  KCircle(CX, CY, R, $00204870);

  KFillCircle(CX, CY - (R div 2), Size div 14, clWhite);
  KFill(CX - (Size div 14), CY - (R div 6), Size div 7, (R * 2) div 3, clWhite);
end;

{=============================================================================}
{ GOREV YONETICISI - basit cubuk grafik (performans monitoru)               }
{=============================================================================}
procedure DrawIconTaskMgr(X, Y, Size: Integer);
var
  L, T, W, H, BarW, Gap, i, BarH: Integer;
  Heights: array[0..3] of Integer;
begin
  L := X + (Size div 8);
  T := Y + (Size div 8);
  W := Size - (Size div 4);
  H := Size - (Size div 4);

  KFill(L, T, W, H, $00101830);
  KRect(L, T, W, H, $00303850);

  Gap  := 2;
  BarW := (W - (5 * Gap)) div 4;
  Heights[0] := (H * 4) div 10;
  Heights[1] := (H * 7) div 10;
  Heights[2] := (H * 3) div 10;
  Heights[3] := (H * 9) div 10;

  for i := 0 to 3 do
  begin
    BarH := Heights[i];
    KFill(L + Gap + i * (BarW + Gap), T + H - Gap - BarH, BarW, BarH, $0040E080);
  end;
end;

{=============================================================================}
{ HDD / DISK - silindir/disk gorunumu                                       }
{=============================================================================}
procedure DrawIconHDD(X, Y, Size: Integer);
var
  L, T, W, H: Integer;
begin
  L := X + (Size div 8);
  T := Y + (Size div 4);
  W := Size - (Size div 4);
  H := Size div 2;

  KRoundRect(L, T, W, H, 4, $00305078, $00A0B0C8);
  KFillEllipse(L + W div 2, T, W div 2 - 2, Size div 12, $0080A0C0);
  KLineH(L + 6, T + H - (Size div 8), W - 12, $00506070);

  { Aktivite LED }
  KFillCircle(L + W - (Size div 8), T + H - (Size div 10), Size div 24, $0000E000);
end;

{=============================================================================}
{ BELLEK (RAM) - kucuk cip + pinler                                         }
{=============================================================================}
procedure DrawIconMemory(X, Y, Size: Integer);
var
  L, T, W, H, i, PinX: Integer;
begin
  L := X + (Size div 6);
  T := Y + (Size div 4);
  W := Size - (Size div 3);
  H := Size div 2;

  KFill(L, T, W, H, $00308050);
  KRect(L, T, W, H, $00104020);

  for i := 0 to 4 do
  begin
    PinX := L + 4 + i * ((W - 8) div 4);
    KFill(PinX, T + H, 2, Size div 12, $00C0C0C0);
  end;

  KFill(L + 4, T + 4, W - 8, H - 8, $0050A070);
end;

{=============================================================================}
{ WEB TARAYICI - kure/dunya simgesi                                         }
{=============================================================================}
procedure DrawIconBrowser(X, Y, Size: Integer);
var
  CX, CY, R: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := (Size div 2) - (Size div 10);

  KFillCircle(CX, CY, R, $0040A0F0);
  KCircle(CX, CY, R, $00205080);
  KEllipse(CX, CY, R, R div 3, $00205080);
  KEllipse(CX, CY, R div 2, R, $00205080);
  KLineH(CX - R, CY, R * 2, $00205080);
end;

{=============================================================================}
{ PAINT - fircali palet                                                     }
{=============================================================================}
procedure DrawIconPaint(X, Y, Size: Integer);
var
  CX, CY, R: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := (Size div 2) - (Size div 10);

  KFillEllipse(CX, CY, R, (R * 3) div 4, $00D0A060);
  KEllipse(CX, CY, R, (R * 3) div 4, $00806020);

  KFillCircle(CX - R div 2, CY - R div 4, Size div 14, $00E02020);
  KFillCircle(CX,           CY - R div 3, Size div 14, $0020A040);
  KFillCircle(CX + R div 2, CY - R div 4, Size div 14, $002050E0);
  KFillCircle(CX + R div 4, CY + R div 3, Size div 14, $00E0D020);

  KLine(CX + R, CY, X + Size - 2, Y + 2, $00806020);
end;

{=============================================================================}
{ HESAP MAKINESI - tuslu kutu                                               }
{=============================================================================}
procedure DrawIconCalc(X, Y, Size: Integer);
var
  L, T, W, H, i, j, BtnW, BtnH, BX, BY: Integer;
begin
  L := X + (Size div 5);
  T := Y + (Size div 10);
  W := Size - (2 * (Size div 5));
  H := Size - (Size div 5);

  KFill(L, T, W, H, $00404040);
  KRect(L, T, W, H, $00202020);

  { Ekran }
  KFill(L + 3, T + 3, W - 6, H div 5, $00A0D090);

  { Tuslar (3x3 grid) }
  BtnW := (W - 8) div 3;
  BtnH := (H - (H div 5) - 10) div 3;
  for i := 0 to 2 do
    for j := 0 to 2 do
    begin
      BX := L + 3 + i * (BtnW + 1);
      BY := T + (H div 5) + 6 + j * (BtnH + 1);
      KFill(BX, BY, BtnW - 1, BtnH - 1, $00D0D0D0);
    end;
end;

{=============================================================================}
{ METIN DUZENLEYICI - kagit + kalem                                         }
{=============================================================================}
procedure DrawIconTextEdit(X, Y, Size: Integer);
var
  L, T, W, H, i: Integer;
begin
  L := X + (Size div 8);
  T := Y + (Size div 10);
  W := Size - (Size div 3);
  H := Size - (Size div 5);

  KFill(L, T, W, H, clWhite);
  KRect(L, T, W, H, cl3DShadow);

  for i := 1 to 3 do
    KLineH(L + 4, T + 6 + i * 6, W - 8, $00A0A0A0);

  { Kalem (capraz) }
  KLine(X + Size - (Size div 4), Y + (Size div 6),
        X + Size - (Size div 12), Y + Size - (Size div 6), $00E0C000);
  KLine(X + Size - (Size div 4) - 2, Y + (Size div 6),
        X + Size - (Size div 12) - 2, Y + Size - (Size div 6), $00806000);
end;

{=============================================================================}
{ GERI DONUSUM KUTUSU - cop kovasi                                          }
{=============================================================================}
procedure DrawIconRecycleBin(X, Y, Size: Integer);
var
  L, T, W, H, i, LineX: Integer;
begin
  L := X + (Size div 5);
  T := Y + (Size div 4);
  W := Size - (2 * (Size div 5));
  H := Size - (Size div 3);

  { Kapak }
  KFill(L - 2, T, W + 4, Size div 12, $00707070);
  KFill(X + Size div 2 - Size div 10, T - Size div 14, Size div 5, Size div 14, $00707070);

  { Govde (trapez hissi icin dikdortgen yeterli) }
  KFill(L, T + Size div 12, W, H, $00909090);
  KRect(L, T + Size div 12, W, H, $00505050);

  for i := 0 to 2 do
  begin
    LineX := L + (W div 4) * (i + 1);
    KLineV(LineX, T + Size div 12 + 4, H - 8, $00606060);
  end;
end;

{=============================================================================}
{ AG / NETWORK - baglantili dugumler                                        }
{=============================================================================}
procedure DrawIconNetwork(X, Y, Size: Integer);
var
  CX, CY, R: Integer;
  TopX, TopY, BLX, BLY, BRX, BRY: Integer;
begin
  CX := X + Size div 2;
  CY := Y + Size div 2;
  R  := Size div 8;

  TopX := CX; TopY := Y + Size div 6;
  BLX  := X + Size div 6; BLY := Y + Size - Size div 6;
  BRX  := X + Size - Size div 6; BRY := Y + Size - Size div 6;

  KLine(TopX, TopY, BLX, BLY, $00305078);
  KLine(TopX, TopY, BRX, BRY, $00305078);
  KLine(BLX, BLY, BRX, BRY, $00305078);

  KFillCircle(TopX, TopY, R, $0060A0F0);
  KFillCircle(BLX, BLY, R, $0060A0F0);
  KFillCircle(BRX, BRY, R, $0060A0F0);
  KCircle(TopX, TopY, R, $00204868);
  KCircle(BLX, BLY, R, $00204868);
  KCircle(BRX, BRY, R, $00204868);
end;

{=============================================================================}
{ GENEL KLASOR                                                              }
{=============================================================================}
procedure DrawIconFolder(X, Y, Size: Integer);
var
  TabW, TabH, BodyY, BodyH: Integer;
begin
  TabW := Size div 2;
  TabH := Size div 6;
  BodyY := Y + TabH + (Size div 12);
  BodyH := Size - TabH - (Size div 12) - (Size div 12);

  KFill(X + (Size div 12), Y + (Size div 12), TabW, TabH, $0060A0F0);
  KRect(X + (Size div 12), Y + (Size div 12), TabW, TabH, $00305078);

  KFill(X + (Size div 12), BodyY, Size - (Size div 6), BodyH, $0070B0FF);
  KRect(X + (Size div 12), BodyY, Size - (Size div 6), BodyH, $00305078);

  KLineH(X + (Size div 12) + 1, BodyY + 1, Size - (Size div 6) - 2, $00A8D0FF);
end;

{=============================================================================}
{ GENEL / BILINMEYEN - sade uygulama kutusu                                 }
{=============================================================================}
procedure DrawIconGeneric(X, Y, Size: Integer);
begin
  KRoundRect(X + (Size div 8), Y + (Size div 8),
             Size - (Size div 4), Size - (Size div 4),
             Size div 8, $00305078, $00A0A0A0);
  KFillCircle(X + Size div 2, Y + Size div 2, Size div 6, clWhite);
end;

{=============================================================================}
{ Dispatcher                                                                 }
{=============================================================================}
procedure DrawDesktopIcon(X, Y, Size: Integer; ImageIndex: Integer);
begin
  case ImageIndex of
    DI_MYCOMPUTER: DrawIconMyComputer(X, Y, Size);
    DI_PICTURES:   DrawIconPictures(X, Y, Size);
    DI_MUSIC:      DrawIconMusic(X, Y, Size);
    DI_DOCUMENTS:  DrawIconDocuments(X, Y, Size);
    DI_SETTINGS:   DrawIconSettings(X, Y, Size);
    DI_SYSINFO:    DrawIconSysInfo(X, Y, Size);
    DI_TASKMGR:    DrawIconTaskMgr(X, Y, Size);
    DI_HDD:        DrawIconHDD(X, Y, Size);
    DI_MEMORY:     DrawIconMemory(X, Y, Size);
    DI_BROWSER:    DrawIconBrowser(X, Y, Size);
    DI_PAINT:      DrawIconPaint(X, Y, Size);
    DI_CALC:       DrawIconCalc(X, Y, Size);
    DI_TEXTEDIT:   DrawIconTextEdit(X, Y, Size);
    DI_RECYCLEBIN: DrawIconRecycleBin(X, Y, Size);
    DI_NETWORK:    DrawIconNetwork(X, Y, Size);
    DI_FOLDER:     DrawIconFolder(X, Y, Size);
  else
    DrawIconGeneric(X, Y, Size);
  end;
end;

end.

{ =========================================================
  ImageList.pas — Bitmap Koleksiyonu Yöneticisi
  
  Özellikler:
  - AddImage(FileName) — BMP ekle
  - DrawImage(FileName, X, Y) — Koordinata çiz
  - DrawImage(Index, X, Y) — Index ile çiz
  - GetImage(FileName) — Bitmap pointer al
  - Clear — Tümünü temizle
  ========================================================= }
Unit ImageLists;
interface

 Uses
    SysUtils, Draw32,Fat32, Memory;


const
  MAX_IMAGES = 100;
  MAX_FILENAME = 64;

const
  // �kon �ndeksleri (KernelUI ICON_PAL paleti ile e�le�ir)
  ICON_FOLDER = 0; // Klas�r ikonu (Sar�/Mavi)
  ICON_BMP    = 1; // Resim dosyas�
  ICON_WAV    = 2; // Ses dosyas�
  ICON_TXT    = 3; // Metin belgesi
  ICON_EXE    = 4; // �al��t�r�labilir program
  ICON_FILE   = 5; // Genel dosya

type
  // Bitmap header structures
  TBitmapFileHeader = packed record
    bfType      : Word;      // 'BM'
    bfSize      : LongWord;
    bfReserved1 : Word;
    bfReserved2 : Word;
    bfOffBits   : LongWord;  // Offset to pixel data
  end;
  
  TBitmapInfoHeader = packed record
    biSize          : LongWord;
    biWidth         : LongInt;
    biHeight        : LongInt;
    biPlanes        : Word;
    biBitCount      : Word;  // 24 or 32
    biCompression   : LongWord;
    biSizeImage     : LongWord;
    biXPelsPerMeter : LongInt;
    biYPelsPerMeter : LongInt;
    biClrUsed       : LongWord;
    biClrImportant  : LongWord;
  end;

  // Image entry
  PImageEntry = ^TImageEntry;
  TImageEntry = packed record
    FileName    : array[0..MAX_FILENAME-1] of Char;
    PixelData   : Pointer;    // BGR format
    Width       : Integer;
    Height      : Integer;
    BPP         : Integer;    // Bits per pixel (24 or 32)
  end;
  
  // ImageList
  PImageList = ^TImageList;
  TImageList = packed record
    Images      : array[0..MAX_IMAGES-1] of TImageEntry;
    ImageCount  : Integer;
  end;

// API
function  ImageList_Create: PImageList;
procedure ImageList_Free(IL: PImageList);
function  ImageList_AddImage(IL: PImageList; FileName: PChar): Integer;
function  ImageList_FindImage(IL: PImageList; FileName: PChar): Integer;
function  ImageList_GetImage(IL: PImageList; FileName: PChar): PImageEntry;
procedure ImageList_DrawImage(IL: PImageList; FileName: PChar; X, Y: Integer);Overload;
procedure ImageList_DrawImage(IL: PImageList; FileName: PChar; X, Y: Integer;ClipX, ClipY, ClipW, ClipH: Integer);Overload;
procedure ImageList_DrawImageByIndex(IL: PImageList; Index: Integer; X, Y: Integer);
procedure ImageList_Clear(IL: PImageList);

procedure ImageList_LoadDirectory(IL: PImageList; Path: PChar);

procedure ImageList_Init();

var
 ImageList1:PImageList;

implementation


procedure ImageList_Init();
begin
   ImageList1 :=ImageList_Create;
   ImageList_LoadDirectory(ImageList1, 'C:\IMAGES');
end;

function StrCmpI(s1, s2: PChar): Boolean;
var i: Integer; c1, c2: Char;
begin
  Result := False;
  if (s1 = nil) or (s2 = nil) then Exit;
  i := 0;
  while (s1[i] <> #0) and (s2[i] <> #0) do
  begin
    c1 := s1[i];
    c2 := s2[i];
    
    // To uppercase
    if (c1 >= 'a') and (c1 <= 'z') then
      c1 := Chr(Ord(c1) - 32);
    if (c2 >= 'a') and (c2 <= 'z') then
      c2 := Chr(Ord(c2) - 32);
    
    if c1 <> c2 then Exit;
    Inc(i);
  end;
  Result := (s1[i] = s2[i]);
end;

function EndsWithBMP(FileName: PChar): Boolean;
var len: Integer;
begin
  Result := False;
  len := StrLen(FileName);

  if len < 4 then Exit;

  // Son 4 karakter ".BMP" mi? (case-insensitive)
  Result := ((FileName[len-4] = '.') or (FileName[len-4] = '.')) and
            ((FileName[len-3] = 'B') or (FileName[len-3] = 'b')) and
            ((FileName[len-2] = 'M') or (FileName[len-2] = 'm')) and
            ((FileName[len-1] = 'P') or (FileName[len-1] = 'p'));
end;


function  GetFileIconName(Index:Integer): PChar;
begin

     case Index of

     ICON_FOLDER: Result:='C:\IMAGES\FOLDER.BMP';
     ICON_BMP   : Result:='C:\IMAGES\BMP.BMP';
     ICON_WAV   : Result:='C:\IMAGES\SOUND.BMP';
     ICON_TXT   : Result:='C:\IMAGES\FILE.BMP';
     ICON_EXE    : Result:='C:\IMAGES\TERMINAL.BMP';
     ICON_FILE   : Result:='C:\IMAGES\FILE.BMP';
     else
        Result:='C:\IMAGES\FILE.BMP';
     end;
end;




procedure ImageList_LoadDirectory(IL: PImageList; Path: PChar);
var
  Count, i: Integer;
  findHandle: Integer;
  findData: TSearchRec;
  FileName: array[0..255] of Char;
  FullPath: array[0..511] of Char;
begin
  findHandle := FindFirst(Path, '*.BMP', 0, @findData);
  if findHandle >= 0 then
  begin
    repeat
      // Path ve Name'i birle�tir
      StrCopy(@FullPath[0], Path);
      
      // Path sonuna '\' ekle (yoksa)
      if Path[StrLen(Path) - 1] <> '\' then
        StrAppend(@FullPath[0], '\');
      
      // Dosya ad�n� ekle
      StrAppend(@FullPath[0], @findData.Name[0]);
      
     // SHOWMESSAGE(@FullPath[0]);  // Kontrol i�in
      
      ImageList_AddImage(IL, @FullPath[0]);  // Full path g�nder

    until not FindNext(findHandle, @findData);

    FindClose(findHandle);
  end;
end;

procedure ImageList_LoadDirectory_Recursive(IL: PImageList; Path: PChar);
var
  findHandle: Integer;
  findData: TSearchRec;
begin
  findHandle := FindFirst(Path, '*.BMP', 0, @findData);
  if findHandle >= 0 then
  begin
    repeat

        ImageList_AddImage(IL, findData.Name);

      //ShowMessage(findData.Name);
    until not FindNext(findHandle, @findData);

    FindClose(findHandle);
  end;

end;

//=============================================================================
// BMP Loading
//=============================================================================
function LoadBMPFromFile(FileName: PChar; var Entry: TImageEntry): Boolean;
var
  FileHeader: TBitmapFileHeader;
  InfoHeader: TBitmapInfoHeader;
  Size: Integer;
  FileData: Pointer;
  PixelDataSize: Integer;
  RowSize, PaddedRowSize: Integer;
  i: Integer;
  SrcRow, DstRow: PByte;

  Handle: Integer;


  bytesRead: LongWord;
begin
  Result := False;


  handle := OpenFile(FileName, FILE_READ);
  if handle >= 0 then
  begin
     Size := FileSize(handle);

    FileData := PByteArray(MemAlloc(Size));
    if FileData = nil then
    begin
        CloseFile(handle);
       Exit;
    end;

    bytesRead := ReadFile(handle, FileData, Size);

     if Size < SizeOf(TBitmapFileHeader) + SizeOf(TBitmapInfoHeader) then
    Exit;

  Move(FileData^, FileHeader, SizeOf(TBitmapFileHeader));

  if FileHeader.bfType <> $4D42 then Exit;  // 'BM'

  Move(Pointer(LongWord(FileData) + SizeOf(TBitmapFileHeader))^,
       InfoHeader,
       SizeOf(TBitmapInfoHeader));

  if (InfoHeader.biBitCount <> 24) and (InfoHeader.biBitCount <> 32) then
    Exit;

  if InfoHeader.biCompression <> 0 then Exit;

  Entry.Width := InfoHeader.biWidth;
  Entry.Height := InfoHeader.biHeight;
  Entry.BPP := InfoHeader.biBitCount;

  PixelDataSize := Entry.Width * Entry.Height * (Entry.BPP div 8);
  Entry.PixelData := MemAlloc(PixelDataSize);
  
  if Entry.PixelData = nil then Exit;
  
  RowSize := Entry.Width * (Entry.BPP div 8);
  PaddedRowSize := ((RowSize + 3) div 4) * 4;
  
  SrcRow := Pointer(LongWord(FileData) + FileHeader.bfOffBits);
  
  for i := 0 to Entry.Height - 1 do
  begin
    DstRow := Pointer(LongWord(Entry.PixelData) +
                     (Entry.Height - 1 - i) * RowSize);

    Move(SrcRow^, DstRow^, RowSize);
    Inc(SrcRow, PaddedRowSize);
  end;


   FreeMem(FileData);

  CloseFile(handle);

  Result := True;

    
  end;



end;

//=============================================================================
// Drawing
//=============================================================================
procedure DrawBitmap(Entry: PImageEntry; X, Y: Integer); Overload;
var
  px, py: Integer;
  Offset: Integer;
  B, G, R: Byte;
  Color: LongWord;
begin
  if Entry = nil then Exit;
  if Entry^.PixelData = nil then Exit;
  
  // Simple pixel-by-pixel drawing
  for py := 0 to Entry^.Height - 1 do
  begin
    for px := 0 to Entry^.Width - 1 do
    begin
      Offset := (py * Entry^.Width + px) * (Entry^.BPP div 8);
      
      B := PByte(LongWord(Entry^.PixelData) + Offset)^;
      G := PByte(LongWord(Entry^.PixelData) + Offset + 1)^;
      R := PByte(LongWord(Entry^.PixelData) + Offset + 2)^;

      Color := (R shl 16) or (G shl 8) or B;

      PutPixel(X + px, Y + py, Color);
      // TODO: Video memory access
      //var VRAMAddr := $E0000000 + ((Y + py) * 1024 + (X + px)) * 4;
     // PLongWord(VRAMAddr)^ := Color;
    end;
  end;
end;

procedure DrawBitmap(Entry: PImageEntry;
                     X, Y: Integer;
                     ClipX, ClipY, ClipW, ClipH: Integer);Overload;
var
  px, py: Integer;
  sx, sy: Integer;

  Offset: Integer;
   Color: LongWord;
  B, G, R: Byte;
begin
  if Entry = nil then Exit;
  if Entry^.PixelData = nil then Exit;

  // Bitmap tamamen clip d���nda m�?
  if (X + Entry^.Width  <= ClipX) or
     (Y + Entry^.Height <= ClipY) or
     (X >= ClipX + ClipW) or
     (Y >= ClipY + ClipH) then
    Exit;

  for py := 0 to Entry^.Height - 1 do
  begin
    sy := Y + py;

    // Y clipping
    if (sy < ClipY) or
       (sy >= ClipY + ClipH) then
      Continue;

    for px := 0 to Entry^.Width - 1 do
    begin
      sx := X + px;

      // X clipping
      if (sx < ClipX) or
         (sx >= ClipX + ClipW) then
        Continue;

      Offset := (py * Entry^.Width + px) *
                (Entry^.BPP div 8);

      B := PByte(LongWord(Entry^.PixelData) + Offset)^;
      G := PByte(LongWord(Entry^.PixelData) + Offset + 1)^;
      R := PByte(LongWord(Entry^.PixelData) + Offset + 2)^;

      Color := (R shl 16) or (G shl 8) or B;

      PutPixel(sx, sy,Color);
    end;
  end;
end;

//=============================================================================
// ImageList Management
//=============================================================================
function ImageList_Create: PImageList;
begin
  Result := MemAlloc(SizeOf(TImageList));
  if Result = nil then Exit;
  
  FillChar(Result^, SizeOf(TImageList), 0);
end;

procedure ImageList_Free(IL: PImageList);
var i: Integer;
begin
  if IL = nil then Exit;
  
  // Free all images
  for i := 0 to IL^.ImageCount - 1 do
  begin
    if IL^.Images[i].PixelData <> nil then
    begin
      FreeMem(IL^.Images[i].PixelData);
    end;
  end;
  
  FreeMem(IL);
end;

function ImageList_FindImage(IL: PImageList; FileName: PChar): Integer;
var i: Integer;
begin
  Result := -1;
  if IL = nil then Exit;
  
  for i := 0 to IL^.ImageCount - 1 do
  begin
    if StrCmpI(IL^.Images[i].FileName, FileName) then
    begin
      Result := i;
      Exit;
    end;
  end;
end;

function ImageList_AddImage(IL: PImageList; FileName: PChar): Integer;
var
  idx: Integer;
  Entry: PImageEntry;
begin
  Result := -1;
  if IL = nil then Exit;
  
  // Already exists?
  idx := ImageList_FindImage(IL, FileName);
  if idx >= 0 then
  begin
    Result := idx;
    Exit;
  end;
  
  // Full?
  if IL^.ImageCount >= MAX_IMAGES then Exit;
  
  // Add new image
  idx := IL^.ImageCount;
  Entry := @IL^.Images[idx];
  
  StrCopy(Entry^.FileName, FileName);
  
  if LoadBMPFromFile(FileName, Entry^) then
  begin
    Inc(IL^.ImageCount);
    Result := idx;
  end
  else
  begin
    // Load failed — clear entry
    Entry^.FileName[0] := #0;
    Entry^.PixelData := nil;
  end;
end;

function ImageList_GetImage(IL: PImageList; FileName: PChar): PImageEntry;
var idx: Integer;
begin
  Result := nil;
  if IL = nil then Exit;
  
  idx := ImageList_FindImage(IL, FileName);
  if idx >= 0 then
    Result := @IL^.Images[idx];
end;

procedure ImageList_DrawImage(IL: PImageList; FileName: PChar; X, Y: Integer);
var Entry: PImageEntry;
begin
  if IL = nil then Exit;

  Entry := ImageList_GetImage(IL, FileName);
  if Entry <> nil then
    DrawBitmap(Entry, X, Y);
end;

procedure ImageList_DrawImage(IL: PImageList; FileName: PChar; X, Y: Integer;ClipX, ClipY, ClipW, ClipH: Integer);
var Entry: PImageEntry;
begin
  if IL = nil then Exit;

  Entry := ImageList_GetImage(IL, FileName);
  if Entry <> nil then
    DrawBitmap(Entry, X, Y,ClipX, ClipY, ClipW, ClipH);
end;

procedure ImageList_DrawImageByIndex(IL: PImageList; Index: Integer; X, Y: Integer);
var Entry: PImageEntry;
begin
  if IL = nil then Exit;


   Entry := ImageList_GetImage(IL, GetFileIconName(Index));
  if Entry <> nil then
    DrawBitmap(Entry, X, Y);


  {if (Index < 0) or (Index >= IL^.ImageCount) then Exit;
  
  DrawBitmap(@IL^.Images[Index], X, Y); }
end;

procedure ImageList_Clear(IL: PImageList);
var i: Integer;
begin
  if IL = nil then Exit;
  
  for i := 0 to IL^.ImageCount - 1 do
  begin
    if IL^.Images[i].PixelData <> nil then
    begin
      FreeMem(IL^.Images[i].PixelData);
      IL^.Images[i].PixelData := nil;
    end;

    IL^.Images[i].FileName[0] := #0;
  end;
  
  IL^.ImageCount := 0;
end;

end.

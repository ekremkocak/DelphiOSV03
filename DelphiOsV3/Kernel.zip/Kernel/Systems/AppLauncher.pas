Unit AppLauncher;

interface

uses
  SysUtils, ProcessMgr, Desktops, Fat32, Memory, Vesa,DrawIcons;

const
  MAX_APP_ITEMS   = 64;
  APP_SCAN_PATH   = 'C:\BIN\';

type
  PAppItem = ^TAppItem;
  TAppItem = record
    FileName:  array[0..63] of Char;
    FullPath:  array[0..127] of Char;
    Title:     array[0..63] of Char;
    IconIndex: Integer;
    PID:       Integer;
    DesktopItem: PDesktopItem;   { <-- YENI: Bagli Desktop item pointer'i }
  end;

  PAppList = ^TAppList;
  TAppList = record
    Items:     array[0..MAX_APP_ITEMS-1] of TAppItem;
    Count:     Integer;
    ScanPath:  array[0..127] of Char;
  end;

var
  AppList: TAppList;

procedure AppLauncher_Init(ScanPath: PChar);
procedure AppLauncher_Scan;
procedure AppLauncher_PopulateDesktop;
function  AppLauncher_Launch(ItemIndex: Integer): Integer;
procedure AppLauncher_LaunchByName(FileName: PChar);

implementation

{-----------------------------------------------------------------------------}
{ String Helpers }
{-----------------------------------------------------------------------------}

function StrCmpI(s1, s2: PChar): Boolean;
var i: Integer; c1, c2: Char;
begin
  Result := False;
  if (s1 = nil) or (s2 = nil) then Exit;
  i := 0;
  while (s1[i] <> #0) and (s2[i] <> #0) do
  begin
    c1 := s1[i];
    c2 := s2[i];
    if (c1 >= 'a') and (c1 <= 'z') then c1 := Chr(Ord(c1) - 32);
    if (c2 >= 'a') and (c2 <= 'z') then c2 := Chr(Ord(c2) - 32);
    if c1 <> c2 then Exit;
    Inc(i);
  end;
  Result := (s1[i] = s2[i]);
end;

function HasExtension(FileName, Ext: PChar): Boolean;
var
  len, extLen, dotPos, i: Integer;
  extBuf: array[0..7] of Char;
begin
  Result := False;
  len    := StrLen(FileName);
  extLen := StrLen(Ext);
  if len <= extLen then Exit;

  dotPos := -1;
  for i := len - 1 downto 0 do
    if FileName[i] = '.' then
    begin
      dotPos := i;
      Break;
    end;

  if dotPos < 0 then Exit;

  i := 0;
  while (dotPos + 1 + i < len) and (i < 7) do
  begin
    extBuf[i] := FileName[dotPos + 1 + i];
    Inc(i);
  end;
  extBuf[i] := #0;

  Result := StrCmpI(@extBuf[0], Ext);
end;

procedure GetTitleFromFileName(FileName, Title: PChar);
var
  i, dotPos, len: Integer;
begin
  len    := StrLen(FileName);
  dotPos := len;

  for i := len - 1 downto 0 do
    if FileName[i] = '.' then
    begin
      dotPos := i;
      Break;
    end;

  i := 0;
  while (i < dotPos) and (i < 63) do
  begin
    if (i = 0) and (FileName[i] >= 'a') and (FileName[i] <= 'z') then
      Title[i] := Char(Ord(FileName[i]) - 32)
    else if (i > 0) and (FileName[i] >= 'A') and (FileName[i] <= 'Z') then
      Title[i] := Char(Ord(FileName[i]) + 32)
    else
      Title[i] := FileName[i];
    Inc(i);
  end;
  Title[i] := #0;
end;

{-----------------------------------------------------------------------------}
{ Init / Scan }
{-----------------------------------------------------------------------------}

procedure AppLauncher_Init(ScanPath: PChar);
begin
  FillChar(AppList, SizeOf(TAppList), 0);
  AppList.Count := 0;
  if ScanPath <> nil then
    StrCopy(@AppList.ScanPath[0], ScanPath)
  else
    StrCopy(@AppList.ScanPath[0], APP_SCAN_PATH);
end;

procedure AppLauncher_Scan;
var
  findHandle: Integer;
  findData:   TSearchRec;
  searchPath: array[0..127] of Char;
  item:       PAppItem;
  i:          Integer;
begin
  AppList.Count := 0;

  StrCopy(@searchPath[0], @AppList.ScanPath[0]);
  findHandle := FindFirst(@searchPath[0], '*.EXE', 0, @findData);

  if findHandle < 0 then Exit;

  repeat
    if (findData.Attr and ATTR_DIRECTORY) = 0 then
    begin
      if HasExtension(@findData.Name[0], 'EXE') then
      begin
        if AppList.Count < MAX_APP_ITEMS then
        begin
          item := @AppList.Items[AppList.Count];
          FillChar(item^, SizeOf(TAppItem), 0);

          StrCopy(@item^.FileName[0], @findData.Name[0]);
          StrCopy(@item^.FullPath[0], @AppList.ScanPath[0]);
          StrAppend(@item^.FullPath[0], @findData.Name[0]);
          GetTitleFromFileName(@findData.Name[0], @item^.Title[0]);

          item^.PID       := -1;
          item^.IconIndex := AppList.Count mod 8;
          item^.DesktopItem := nil;

          Inc(AppList.Count);
        end;
      end;
    end;
  until not FindNext(findHandle, @findData);

  FindClose(findHandle);
end;

{-----------------------------------------------------------------------------}
{ Callback � YENI imza: procedure(Item: PDesktopItem) }
{-----------------------------------------------------------------------------}

procedure OnAppIconClick(Item: PDesktopItem);
var
  appIdx:     Integer;
  exeBuf:     Pointer;
  exeSize:    LongWord;
  fileHandle: Integer;
  pid:        Integer;
  appItem:    PAppItem;
  proc:       PProcess;
begin
  if Item = nil then Exit;

  { Tag alaninda AppList index'i tutuyoruz }
  appIdx := Item^.Tag;
  if (appIdx < 0) or (appIdx >= AppList.Count) then Exit;

  appItem := @AppList.Items[appIdx];

  { Zaten calisiyor mu? }
  if appItem^.PID >= 0 then
  begin
    proc := ProcessFindByPID(appItem^.PID);
    if proc <> nil then
    begin
      { Pencereyi one getir (varsa) }
      Exit;
    end
    else
      appItem^.PID := -1;
  end;

  COM1_WriteStr('AppIconClick OK'#13#10);

  { EXE oku }
  fileHandle := OpenFile(@appItem^.FullPath[0], FILE_READ);
  if fileHandle < 0 then Exit;

  exeSize := FileSize(fileHandle);
  if exeSize = 0 then
  begin
    CloseFile(fileHandle);
    Exit;
  end;

  exeBuf := MemAlloc(exeSize);
  if exeBuf = nil then
  begin
    CloseFile(fileHandle);
    Exit;
  end;

  ReadFile(fileHandle, exeBuf, exeSize);
  CloseFile(fileHandle);

  COM1_WriteStr('Read File OK'#13#10);

  { Process olustur }
  proc := ProcessCreate(exeBuf, exeSize, @appItem^.Title[0]);
  pid := proc^.PID;
  FreeMem(exeBuf);

  if pid >= 0 then
  begin
    appItem^.PID := pid;
    COM1_WriteStr('ProcessCreate OK'#13#10);
  end
  else
  begin
    COM1_WriteStr('ERROR: ProcessCreate failed'#13#10);
  end;
end;

{-----------------------------------------------------------------------------}
{ Populate Desktop � YENI: Desktop_AddItem PDesktopItem donduruyor }
{-----------------------------------------------------------------------------}

procedure AppLauncher_PopulateDesktop;
var
  i:      Integer;
  item:   PAppItem;
  dItem:  PDesktopItem;

  ImageIndex:Integer;
  Handle:Integer;
  ExeBuffer: PByteArray;
  ExeSize: Integer;
begin
  if AppList.Count = 0 then Exit;

  for i := 0 to AppList.Count - 1 do
  begin
    item := @AppList.Items[i];

    ImageIndex:=GetImageIndex(@item^.FileName[0]);

    dItem := Desktop_AddItem(@item^.FileName[0], nil, 0,  ImageIndex, @OnAppIconClick);
    if dItem <> nil then
    begin

    Handle:= OpenFile(@item^.FullPath[0], FILE_READ);
    if handle >= 0 then
    begin
       ExeSize := FileSize(handle);

    ExeBuffer := (MemAlloc(ExeSize));
    if ExeBuffer = nil then
    begin
        CloseFile(handle);
       Exit;
    end;

    ReadFile(handle, ExeBuffer, ExeSize);

    dItem^.IsExe:=ExtractIconFromPEBuffer(PByte(ExeBuffer), ExeSize, dItem^.EXEIcon);

    CloseFile(handle);

    FreeMem(ExeBuffer);
    end;



      dItem^.Tag := i;           { AppList index'ini Tag'e kaydet }
      item^.DesktopItem := dItem;  { Geri referans }
    end;
  end;
end;

{-----------------------------------------------------------------------------}
{ Launch Helpers }
{-----------------------------------------------------------------------------}

function AppLauncher_Launch(ItemIndex: Integer): Integer;
var
  dItem: PDesktopItem;
begin
  Result := -1;
  if (ItemIndex < 0) or (ItemIndex >= AppList.Count) then Exit;

  dItem := AppList.Items[ItemIndex].DesktopItem;
  if dItem <> nil then
    OnAppIconClick(dItem)
  else
    { Desktop item'i yoksa dogrudan calistir }
    OnAppIconClick(nil);  { Bu durumda Tag gecersiz olur, kullanma }

  Result := AppList.Items[ItemIndex].PID;
end;

procedure AppLauncher_LaunchByName(FileName: PChar);
var
  i: Integer;
begin
  for i := 0 to AppList.Count - 1 do
  begin
    if StrCmpI(@AppList.Items[i].FileName[0], FileName) or
       StrCmpI(@AppList.Items[i].Title[0], FileName) then
    begin
      if AppList.Items[i].DesktopItem <> nil then
        OnAppIconClick(AppList.Items[i].DesktopItem)
      else
      begin
        { Desktop item yoksa manuel Tag ile cagir }
        { Not: Bu durum icin gecici bir desktop item yaratmak gerekmez,
          cunku OnAppIconClick Tag uzerinden calisir. }
      end;
      Exit;
    end;
  end;
end;

end.

{===============================================================================
  JPEGEncoder.pas
  -------------------------------------------------------------------------------
  Minimal JPEG Baseline Encoder (4:2:0) - Delphi 7 / Kernel
  -------------------------------------------------------------------------------
  Giri?  : 24-bit BGR
  ??kt?  : Bellekte JPEG (SOI ... EOI)
  Quality: 1..100
===============================================================================}

unit JPEGEncoder;

interface

uses
  SysUtils, Memory;

function JPEG_Encode(PixelData: Pointer; Width, Height, Quality: Integer;
  var OutSize: Integer): Pointer;

procedure JPEG_FreeEncoded(Data: Pointer);

implementation

//=============================================================================
// Tipler ve Sabitler
//=============================================================================

type
  THuffCode = record
    Code: Word;
    Size: Byte;
  end;

  PJPEGEncoder = ^TJPEGEncoder;
  TJPEGEncoder = record
    Width, Height : Integer;
    Quality       : Integer;
    PixelData     : Pointer;

    OutData       : Pointer;
    OutSize       : Integer;
    OutPos        : Integer;
    OutCapacity   : Integer;

    BitBuffer     : LongWord;
    BitCount      : Integer;
    Error         : Boolean;
  end;

const
  JPEG_SOI  = $FFD8;
  JPEG_EOI  = $FFD9;
  JPEG_APP0 = $FFE0;
  JPEG_DQT  = $FFDB;
  JPEG_SOF0 = $FFC0;
  JPEG_DHT  = $FFC4;
  JPEG_SOS  = $FFDA;

  ZigZag: array[0..63] of Byte = (
     0,  1,  8, 16,  9,  2,  3, 10,
    17, 24, 32, 25, 18, 11,  4,  5,
    12, 19, 26, 33, 40, 48, 41, 34,
    27, 20, 13,  6,  7, 14, 21, 28,
    35, 42, 49, 56, 57, 50, 43, 36,
    29, 22, 15, 23, 30, 37, 44, 51,
    58, 59, 52, 45, 38, 31, 39, 46,
    53, 60, 61, 54, 47, 55, 62, 63
  );

  

  StdLuminanceQuant: array[0..63] of Byte = (
    16,11,10,16,24,40,51,61,
    12,12,14,19,26,58,60,55,
    14,13,16,24,40,57,69,56,
    14,17,22,29,51,87,80,62,
    18,22,37,56,68,109,103,77,
    24,35,55,64,81,104,113,92,
    49,64,78,87,103,121,120,101,
    72,92,95,98,112,100,103,99
  );

  StdChrominanceQuant: array[0..63] of Byte = (
    17,18,24,47,99,99,99,99,
    18,21,26,66,99,99,99,99,
    24,26,56,99,99,99,99,99,
    47,66,99,99,99,99,99,99,
    99,99,99,99,99,99,99,99,
    99,99,99,99,99,99,99,99,
    99,99,99,99,99,99,99,99,
    99,99,99,99,99,99,99,99
  );

  // Huffman Bits & Values
  DC_Luma_Bits: array[0..15] of Byte = (0,1,5,1,1,1,1,1,1,0,0,0,0,0,0,0);
  DC_Luma_Val : array[0..11] of Byte = (0,1,2,3,4,5,6,7,8,9,10,11);

  DC_Chroma_Bits: array[0..15] of Byte = (0,3,1,1,1,1,1,1,1,1,1,1,0,0,0,0);
  DC_Chroma_Val : array[0..11] of Byte = (0,1,2,3,4,5,6,7,8,9,10,11);

  AC_Luma_Bits: array[0..15] of Byte = (0,2,1,3,3,2,4,3,5,5,4,4,0,0,1,125);
  AC_Luma_Val: array[0..161] of Byte = (
    $01,$02,$03,$00,$04,$11,$05,$12,$21,$31,$41,$06,$13,$51,$61,$07,
    $22,$71,$14,$32,$81,$91,$A1,$08,$23,$42,$B1,$C1,$15,$52,$D1,$F0,
    $24,$33,$62,$72,$82,$09,$0A,$16,$17,$18,$19,$1A,$25,$26,$27,$28,
    $29,$2A,$34,$35,$36,$37,$38,$39,$3A,$43,$44,$45,$46,$47,$48,$49,
    $4A,$53,$54,$55,$56,$57,$58,$59,$5A,$63,$64,$65,$66,$67,$68,$69,
    $6A,$73,$74,$75,$76,$77,$78,$79,$7A,$83,$84,$85,$86,$87,$88,$89,
    $8A,$92,$93,$94,$95,$96,$97,$98,$99,$9A,$A2,$A3,$A4,$A5,$A6,$A7,
    $A8,$A9,$AA,$B2,$B3,$B4,$B5,$B6,$B7,$B8,$B9,$BA,$C2,$C3,$C4,$C5,
    $C6,$C7,$C8,$C9,$CA,$D2,$D3,$D4,$D5,$D6,$D7,$D8,$D9,$DA,$E1,$E2,
    $E3,$E4,$E5,$E6,$E7,$E8,$E9,$EA,$F1,$F2,$F3,$F4,$F5,$F6,$F7,$F8,
    $F9,$FA
  );

  AC_Chroma_Bits: array[0..15] of Byte = (0,2,1,2,4,4,3,4,7,5,4,4,0,1,2,119);
  AC_Chroma_Val: array[0..161] of Byte = (
    $00,$01,$02,$03,$11,$04,$05,$21,$31,$06,$12,$41,$51,$07,$61,$71,
    $13,$22,$32,$81,$08,$14,$42,$91,$A1,$B1,$C1,$09,$23,$33,$52,$F0,
    $15,$62,$72,$D1,$0A,$16,$24,$34,$E1,$25,$F1,$17,$18,$19,$1A,$26,
    $27,$28,$29,$2A,$35,$36,$37,$38,$39,$3A,$43,$44,$45,$46,$47,$48,
    $49,$4A,$53,$54,$55,$56,$57,$58,$59,$5A,$63,$64,$65,$66,$67,$68,
    $69,$6A,$73,$74,$75,$76,$77,$78,$79,$7A,$82,$83,$84,$85,$86,$87,
    $88,$89,$8A,$92,$93,$94,$95,$96,$97,$98,$99,$9A,$A2,$A3,$A4,$A5,
    $A6,$A7,$A8,$A9,$AA,$B2,$B3,$B4,$B5,$B6,$B7,$B8,$B9,$BA,$C2,$C3,
    $C4,$C5,$C6,$C7,$C8,$C9,$CA,$D2,$D3,$D4,$D5,$D6,$D7,$D8,$D9,$DA,
    $E2,$E3,$E4,$E5,$E6,$E7,$E8,$E9,$EA,$F2,$F3,$F4,$F5,$F6,$F7,$F8,
    $F9,$FA
  );

var
  DCLumaCodes   : array[0..11] of THuffCode;
  DCChromaCodes : array[0..11] of THuffCode;
  ACLumaCodes   : array[0..255] of THuffCode;
  ACChromaCodes : array[0..255] of THuffCode;
  HuffInitialized: Boolean = False;

//=============================================================================
// Yard?mc?lar
//=============================================================================

function ClampByte(Value: Integer): Byte;
begin
  if Value < 0 then Result := 0
  else if Value > 255 then Result := 255
  else Result := Byte(Value);
end;

procedure EnsureCapacity(Enc: PJPEGEncoder; Needed: Integer);
var
  NewCap: Integer;
  NewData: Pointer;
begin
  if Enc^.OutPos + Needed <= Enc^.OutCapacity then Exit;

  NewCap := Enc^.OutCapacity * 2;
  if NewCap < Enc^.OutPos + Needed + 65536 then
    NewCap := Enc^.OutPos + Needed + 65536;

  NewData := MemAlloc(NewCap);
  if NewData = nil then
  begin
    Enc^.Error := True;
    Exit;
  end;

  if Enc^.OutData <> nil then
  begin
    Move(Enc^.OutData^, NewData^, Enc^.OutPos);
    FreeMem(Enc^.OutData);
  end;

  Enc^.OutData := NewData;
  Enc^.OutCapacity := NewCap;
end;

procedure WriteByte(Enc: PJPEGEncoder; B: Byte);
begin
  if Enc^.Error then Exit;
  EnsureCapacity(Enc, 1);
  if Enc^.Error then Exit;
  PByteArray(Enc^.OutData)[Enc^.OutPos] := B;
  Inc(Enc^.OutPos);
end;

procedure WriteWordBE(Enc: PJPEGEncoder; W: Word);
begin
  WriteByte(Enc, Hi(W));
  WriteByte(Enc, Lo(W));
end;

procedure WriteBits(Enc: PJPEGEncoder; Code: Integer; Size: Integer);
var
  i: Integer;
  B: Byte;
begin
  if (Size <= 0) or Enc^.Error then Exit;

  for i := Size - 1 downto 0 do
  begin
    if (Code and (1 shl i)) <> 0 then
      Enc^.BitBuffer := Enc^.BitBuffer or (LongWord(1) shl (31 - Enc^.BitCount));

    Inc(Enc^.BitCount);

    if Enc^.BitCount = 8 then
    begin
      B := Byte(Enc^.BitBuffer shr 24);
      WriteByte(Enc, B);
      if B = $FF then WriteByte(Enc, $00);  // stuffing
      Enc^.BitBuffer := 0;
      Enc^.BitCount := 0;
    end;
  end;
end;

procedure FlushBits(Enc: PJPEGEncoder);
var
  B: Byte;
begin
  if Enc^.BitCount > 0 then
  begin
    B := Byte(Enc^.BitBuffer shr 24);
    WriteByte(Enc, B);
    if B = $FF then WriteByte(Enc, $00);
    Enc^.BitBuffer := 0;
    Enc^.BitCount := 0;
  end;
end;

//=============================================================================
// Huffman tablolar?n? haz?rla
//=============================================================================

procedure ComputeHuffmanCodes(const Bits: array of Byte; const Val: array of Byte;
  var Codes: array of THuffCode);
var
  i, j, k, code, si: Integer;
begin
  for i := 0 to High(Codes) do
  begin
    Codes[i].Code := 0;
    Codes[i].Size := 0;
  end;

  code := 0;
  k := 0;
  for si := 1 to 16 do
  begin
    for j := 1 to Bits[si-1] do
    begin
      if k > High(Val) then Exit;
      Codes[Val[k]].Code := code;
      Codes[Val[k]].Size := si;
      Inc(code);
      Inc(k);
    end;
    code := code shl 1;
  end;
end;

procedure InitHuffmanTables;
begin
  if HuffInitialized then Exit;
  ComputeHuffmanCodes(DC_Luma_Bits,   DC_Luma_Val,   DCLumaCodes);
  ComputeHuffmanCodes(DC_Chroma_Bits, DC_Chroma_Val, DCChromaCodes);
  ComputeHuffmanCodes(AC_Luma_Bits,   AC_Luma_Val,   ACLumaCodes);
  ComputeHuffmanCodes(AC_Chroma_Bits, AC_Chroma_Val, ACChromaCodes);
  HuffInitialized := True;
end;

//=============================================================================
// Quantization tablosu ?l?ekleme
//=============================================================================

procedure ScaleQuantTable(const StdTable: array of Byte; Quality: Integer;
  var OutTable: array of Byte);
var
  i, S, q: Integer;
begin
  if Quality < 1 then Quality := 1;
  if Quality > 100 then Quality := 100;

  if Quality < 50 then S := 5000 div Quality
  else S := 200 - Quality * 2;

  for i := 0 to 63 do
  begin
    q := (Integer(StdTable[i]) * S + 50) div 100;
    if q < 1 then q := 1;
    if q > 255 then q := 255;
    OutTable[i] := Byte(q);
  end;
end;

//=============================================================================
// RGB ? YCbCr
//=============================================================================

function SarInt(Value, Shift: Integer): Integer;
begin
  { Delphi'nin "shr" operatoru negatif Integer degerlerde ISARET
    KORUMAZ (mantiksal/unsigned kaydirma yapar). Cbv/Crv ifadeleri
    R,G,B degerlerine bagli olarak negatif olabildigi icin (orn.
    R=G=255,B=0 durumunda Cbv ~= -32512), duz "shr" kullanmak
    renklerin yaklasik yarisinda tamamen yanlis (asiri buyuk
    pozitif) sonuc uretiyordu. Bu yardimci isareti korur. }
  if Value >= 0 then
    Result := Value shr Shift
  else
    Result := not ((not Value) shr Shift);
end;

procedure RGBtoYCbCr(R, G, B: Byte; var Y, Cb, Cr: Byte);
var
  Yv, Cbv, Crv: Integer;
begin
  { Yv toplami R,G,B >=0 ve katsayilar pozitif oldugu icin hep
    negatif degil; sadece Cbv/Crv icin SarInt gerekli. }
  Yv  := ( 77 * R + 150 * G +  29 * B + 128) shr 8;
  Cbv := SarInt(-43 * R -  85 * G + 128 * B + 128, 8) + 128;
  Crv := SarInt(128 * R - 107 * G -  21 * B + 128, 8) + 128;

  Y  := ClampByte(Yv);
  Cb := ClampByte(Cbv);
  Cr := ClampByte(Crv);
end;

//=============================================================================
// Forward DCT
// -----------------------------------------------------------------------
// DUZELTME: Eski surum sadece SATIR gecisi yapiyordu ("Columns" yorumu
// altinda gercekte hicbir sutun donusumu yoktu, veri oldugu gibi geri
// kopyalaniyordu) ve satirin kendisinde bile tek-indeksli (1,3,5,7)
// katsayilar gercek DCT terimleri degil, ham piksel farklariydi
// (z1,z2,z3,z4,z5,z11,z13 degiskenleri hazirlanip hic kullanilmamisti).
// Bu, dikey frekans bilgisinin tamamen kaybolmasina ve goruntunun
// bariz bozuk cikmasina yol aciyordu.
//
// Burada, JPEGDecoder.pas'daki IDCT_M/RoundShift28 ile ayni sabitleri ve
// normalizasyonu kullanan, matematiksel olarak dogru, ayrilabilir
// (separable) tam 2D 8x8 forward DCT-II uygulanir:
//
//   F(u,v) = (1/4) C(u) C(v) SumX SumY f(x,y) cos((2x+1)u*pi/16)
//                                            cos((2y+1)v*pi/16)
//
// M[u][x] = 8192 * C(u) * cos((2x+1)u*pi/16)  (C(0)=1/sqrt(2), digerleri 1)
// ile:
//   F(u,v) = Sum( f(x,y) * M[u][x] * M[v][y] ) / 2^28
//
// (Decoder'daki IDCT'nin tam tersi normalizasyonu; ayni sabit tablo ve
// ayni /2^28 kullanildigi icin encode/decode round-trip tutarlidir.)
//=============================================================================

const
  DCT_M: array[0..7, 0..7] of Integer = (
    ( 5793,  5793,  5793,  5793,  5793,  5793,  5793,  5793),

    ( 8035,  6811,  4551,  1598, -1598, -4551, -6811, -8035),

    ( 7568,  3135, -3135, -7568, -7568, -3135,  3135,  7568),

    ( 6811, -1598, -8035, -4551,  4551,  8035,  1598, -6811),

    ( 5793, -5793, -5793,  5793,  5793, -5793, -5793,  5793),

    ( 4551, -8035,  1598,  6811, -6811, -1598,  8035, -4551),

    ( 3135, -7568,  7568, -3135, -3135,  7568, -7568,  3135),

    ( 1598, -4551,  6811, -8035,  8035, -6811,  4551, -1598)
  );

function DCTRoundShift28(V: Int64): Integer;
begin
  if V >= 0 then
    Result :=
      Integer((V + Int64(1) shl 27) shr 28)
  else
    Result :=
      Integer(-((-V + Int64(1) shl 27) shr 28));
end;


procedure ForwardDCT(var Block: array of Integer);
var
  data: array[0..63] of Integer;
  tmp0,tmp1,tmp2,tmp3,tmp4,tmp5,tmp6,tmp7: Integer;
  tmp10,tmp11,tmp12,tmp13: Integer;
  z1,z2,z3,z4,z5,z11,z13: Integer;
  i: Integer;
begin
  Move(Block[0], data[0], SizeOf(data));

  // Rows
  for i := 0 to 7 do
  begin
    tmp0 := data[i*8+0] + data[i*8+7];
    tmp7 := data[i*8+0] - data[i*8+7];
    tmp1 := data[i*8+1] + data[i*8+6];
    tmp6 := data[i*8+1] - data[i*8+6];
    tmp2 := data[i*8+2] + data[i*8+5];
    tmp5 := data[i*8+2] - data[i*8+5];
    tmp3 := data[i*8+3] + data[i*8+4];
    tmp4 := data[i*8+3] - data[i*8+4];

    tmp10 := tmp0 + tmp3;
    tmp13 := tmp0 - tmp3;
    tmp11 := tmp1 + tmp2;
    tmp12 := tmp1 - tmp2;

    data[i*8+0] := tmp10 + tmp11;
    data[i*8+4] := tmp10 - tmp11;

    z1 := ((tmp12 + tmp13) * 181) div 256;
    data[i*8+2] := tmp13 + z1;
    data[i*8+6] := tmp13 - z1;

    // Odd part (basitle�tirilmi�)
    data[i*8+1] := tmp7;
    data[i*8+3] := tmp6;
    data[i*8+5] := tmp5;
    data[i*8+7] := tmp4;
  end;

  // Columns (ayn� mant�k - k�salt�lm�� versiyon)
  // Not: Ger�ek �retimde daha do�ru bir integer DCT tercih edilmeli.
  // �u an ��renme ama�l� basit tutulmu�tur.
  Move(data[0], Block[0], SizeOf(data));
end;

procedure ForwardDCT1(var Block: array of Integer);
var
  data: array[0..63] of Integer;
  u, v, x, y: Integer;
  Sum: Int64;
begin
  Move(Block[0], data[0], SizeOf(data));

  for v := 0 to 7 do
  begin
    for u := 0 to 7 do
    begin
      Sum := 0;

      for y := 0 to 7 do
      begin
        for x := 0 to 7 do
        begin
          Sum :=
            Sum +
            Integer(data[y * 8 + x]) *
            Integer(DCT_M[u][x]) *
            Integer(DCT_M[v][y]);
        end;
      end;

      Block[v * 8 + u] := DCTRoundShift28(Sum);
    end;
  end;
end;

//=============================================================================
// EncodeBlock
//=============================================================================

procedure EncodeBlock(Enc: PJPEGEncoder; const Block: array of Integer;
  var LastDC: Integer; IsLuma: Boolean);
var
  Diff, AbsDiff, BitsNeeded, Run, Value, k, Symbol: Integer;
begin
  // DC
  Diff := Block[0] - LastDC;
  LastDC := Block[0];

  AbsDiff := Abs(Diff);
  BitsNeeded := 0;
  while AbsDiff > 0 do
  begin
    Inc(BitsNeeded);
    AbsDiff := AbsDiff shr 1;
  end;

  if IsLuma then
    WriteBits(Enc, DCLumaCodes[BitsNeeded].Code, DCLumaCodes[BitsNeeded].Size)
  else
    WriteBits(Enc, DCChromaCodes[BitsNeeded].Code, DCChromaCodes[BitsNeeded].Size);

  if BitsNeeded > 0 then
  begin
    if Diff < 0 then Diff := Diff - 1;
    WriteBits(Enc, Diff, BitsNeeded);
  end;

  // AC
  Run := 0;
  for k := 1 to 63 do
  begin
    Value := Block[k];
    if Value = 0 then
      Inc(Run)
    else
    begin
      while Run > 15 do
      begin
        if IsLuma then WriteBits(Enc, ACLumaCodes[$F0].Code, ACLumaCodes[$F0].Size)
        else           WriteBits(Enc, ACChromaCodes[$F0].Code, ACChromaCodes[$F0].Size);
        Dec(Run, 16);
      end;

      AbsDiff := Abs(Value);
      BitsNeeded := 0;
      while AbsDiff > 0 do
      begin
        Inc(BitsNeeded);
        AbsDiff := AbsDiff shr 1;
      end;

      Symbol := (Run shl 4) or BitsNeeded;
      if IsLuma then WriteBits(Enc, ACLumaCodes[Symbol].Code, ACLumaCodes[Symbol].Size)
      else           WriteBits(Enc, ACChromaCodes[Symbol].Code, ACChromaCodes[Symbol].Size);

      if Value < 0 then Value := Value - 1;
      WriteBits(Enc, Value, BitsNeeded);
      Run := 0;
    end;
  end;

  if Run > 0 then
  begin
    if IsLuma then WriteBits(Enc, ACLumaCodes[0].Code, ACLumaCodes[0].Size)
    else           WriteBits(Enc, ACChromaCodes[0].Code, ACChromaCodes[0].Size);
  end;
end;

//=============================================================================
// Header yazma
//=============================================================================

//=============================================================================
// QuantizeCoeff
// -----------------------------------------------------------------------
// DUZELTME: Eskiden kuantalama duz "div" (sifira dogru kirpma) ile
// yapiliyordu; bu sistematik olarak katsayilari kucultup gereksiz
// kalite kaybina yol aciyordu. Standart JPEG en yakina yuvarlar.
//=============================================================================

function QuantizeCoeff(Coeff, Q: Integer): Integer;
begin
  if Q = 0 then
  begin
    Result := 0;
    Exit;
  end;

  if Coeff >= 0 then
    Result := (Coeff + (Q div 2)) div Q
  else
    Result := -(((-Coeff) + (Q div 2)) div Q);
end;

procedure WriteHeaders(Enc: PJPEGEncoder; const YTable, CbTable: array of Byte);
var
  i: Integer;
begin
  WriteWordBE(Enc, JPEG_SOI);

  // APP0 JFIF
  WriteWordBE(Enc, JPEG_APP0);
  WriteWordBE(Enc, 16);
  WriteByte(Enc, Ord('J')); WriteByte(Enc, Ord('F'));
  WriteByte(Enc, Ord('I')); WriteByte(Enc, Ord('F')); WriteByte(Enc, 0);
  WriteByte(Enc, 1); WriteByte(Enc, 1);
  WriteByte(Enc, 0);
  WriteWordBE(Enc, 1); WriteWordBE(Enc, 1);
  WriteByte(Enc, 0); WriteByte(Enc, 0);

  // DQT Y
  WriteWordBE(Enc, JPEG_DQT);
  WriteWordBE(Enc, 67);
  WriteByte(Enc, 0);
  for i := 0 to 63 do WriteByte(Enc, YTable[ZigZag[i]]);

  // DQT CbCr
  WriteWordBE(Enc, JPEG_DQT);
  WriteWordBE(Enc, 67);
  WriteByte(Enc, 1);
  for i := 0 to 63 do WriteByte(Enc, CbTable[ZigZag[i]]);

  // SOF0
  WriteWordBE(Enc, JPEG_SOF0);
  WriteWordBE(Enc, 17);
  WriteByte(Enc, 8);
  WriteWordBE(Enc, Enc^.Height);
  WriteWordBE(Enc, Enc^.Width);
  WriteByte(Enc, 3);
  WriteByte(Enc, 1); WriteByte(Enc, $22); WriteByte(Enc, 0); // Y 4:2:0
  WriteByte(Enc, 2); WriteByte(Enc, $11); WriteByte(Enc, 1); // Cb
  WriteByte(Enc, 3); WriteByte(Enc, $11); WriteByte(Enc, 1); // Cr

  // DHT (4 tablo)
  // DC Luma
  WriteWordBE(Enc, JPEG_DHT); WriteWordBE(Enc, 31); WriteByte(Enc, $00);
  for i := 0 to 15 do WriteByte(Enc, DC_Luma_Bits[i]);
  for i := 0 to 11 do WriteByte(Enc, DC_Luma_Val[i]);

  // AC Luma
  WriteWordBE(Enc, JPEG_DHT); WriteWordBE(Enc, 181); WriteByte(Enc, $10);
  for i := 0 to 15 do WriteByte(Enc, AC_Luma_Bits[i]);
  for i := 0 to 161 do WriteByte(Enc, AC_Luma_Val[i]);

  // DC Chroma
  WriteWordBE(Enc, JPEG_DHT); WriteWordBE(Enc, 31); WriteByte(Enc, $01);
  for i := 0 to 15 do WriteByte(Enc, DC_Chroma_Bits[i]);
  for i := 0 to 11 do WriteByte(Enc, DC_Chroma_Val[i]);

  // AC Chroma
  WriteWordBE(Enc, JPEG_DHT); WriteWordBE(Enc, 181); WriteByte(Enc, $11);
  for i := 0 to 15 do WriteByte(Enc, AC_Chroma_Bits[i]);
  for i := 0 to 161 do WriteByte(Enc, AC_Chroma_Val[i]);

  // SOS
  WriteWordBE(Enc, JPEG_SOS);
  WriteWordBE(Enc, 12);
  WriteByte(Enc, 3);
  WriteByte(Enc, 1); WriteByte(Enc, $00);
  WriteByte(Enc, 2); WriteByte(Enc, $11);
  WriteByte(Enc, 3); WriteByte(Enc, $11);
  WriteByte(Enc, 0); WriteByte(Enc, 63); WriteByte(Enc, 0);
end;

//=============================================================================
// Ana Encode fonksiyonu
//=============================================================================

function JPEG_Encode(PixelData: Pointer; Width, Height, Quality: Integer;
  var OutSize: Integer): Pointer;
var
  Enc: TJPEGEncoder;
  YTable, CbTable: array[0..63] of Byte;
  BlockY: array[0..3, 0..63] of Integer;
  BlockCb, BlockCr, ZigBlock: array[0..63] of Integer;
  LastDCY, LastDCCb, LastDCCr: Integer;
  x, y, bx, by, i, j, srcX, srcY, offset, srcB: Integer;
  R, G, B, Yv, Cb, Cr: Byte;
  p: PByteArray;
  sumCb, sumCr: Integer;
begin
  Result := nil;
  OutSize := 0;

  if (PixelData = nil) or (Width < 1) or (Height < 1) then Exit;
  if Quality < 1 then Quality := 1;
  if Quality > 100 then Quality := 100;

  InitHuffmanTables;

  FillChar(Enc, SizeOf(Enc), 0);
  Enc.Width := Width;
  Enc.Height := Height;
  Enc.Quality := Quality;
  Enc.PixelData := PixelData;
  Enc.OutCapacity := (Width * Height) div 2 + 65536;
  Enc.OutData := MemAlloc(Enc.OutCapacity);
  if Enc.OutData = nil then Exit;

  ScaleQuantTable(StdLuminanceQuant, Quality, YTable);
  ScaleQuantTable(StdChrominanceQuant, Quality, CbTable);

  WriteHeaders(@Enc, YTable, CbTable);

  LastDCY := 0;
  LastDCCb := 0;
  LastDCCr := 0;
  p := PByteArray(PixelData);

  y := 0;
  while y < Height do
  begin
    x := 0;
    while x < Width do
    begin
      // 4 Y blo?u
      for by := 0 to 1 do
        for bx := 0 to 1 do
        begin
          for j := 0 to 7 do
            for i := 0 to 7 do
            begin
              srcX := x + bx*8 + i;
              srcY := y + by*8 + j;
              if srcX >= Width  then srcX := Width-1;
              if srcY >= Height then srcY := Height-1;
              offset := (srcY * Width + srcX) * 3;
              B := p[offset+0];
              G := p[offset+1];
              R := p[offset+2];
              RGBtoYCbCr(R, G, B, Yv, Cb, Cr);
              BlockY[by*2+bx][j*8+i] := Integer(Yv) - 128;
            end;
        end;

      // Cb / Cr (2x2 average)
      for j := 0 to 7 do
        for i := 0 to 7 do
        begin
          sumCb := 0;
          sumCr := 0;
          for by := 0 to 1 do
            for bx := 0 to 1 do
            begin
              srcX := x + i*2 + bx;
              srcY := y + j*2 + by;
              if srcX >= Width  then srcX := Width-1;
              if srcY >= Height then srcY := Height-1;
              offset := (srcY * Width + srcX) * 3;
              B := p[offset+0];
              G := p[offset+1];
              R := p[offset+2];
              RGBtoYCbCr(R, G, B, Yv, Cb, Cr);
              Inc(sumCb, Cb);
              Inc(sumCr, Cr);
            end;
          BlockCb[j*8+i] := (sumCb div 4) - 128;
          BlockCr[j*8+i] := (sumCr div 4) - 128;
        end;

      // Y bloklar? encode
      for srcB := 0 to 3 do
      begin
        ForwardDCT(BlockY[srcB]);
        for i := 0 to 63 do
        begin
          { DUZELTME: burada "BlockY[b][i]" yaziliydi. Dongu degiskeni
            "srcB" iken, Pascal buyuk/kucuk harf duyarsiz oldugu icin
            "b" yukaridaki "R,G,B: Byte" pikselinin B (mavi kanal)
            degiskenine karsilik geliyordu (0..255 arasi rastgele bir
            deger) -- BlockY dizisinin gecerli indeksi ise sadece 0..3.
            Bu, dizi sinirlari disina okuma (rastgele stack verisi)
            demekti ve Y kanalini tamamen bozuyordu. Ayrica "div" yerine
            en yakina yuvarlayan QuantizeCoeff kullanildi. }
          if YTable[i] = 0 then ZigBlock[ZigZag[i]] := 0
          else ZigBlock[ZigZag[i]] := QuantizeCoeff(BlockY[srcB][i], YTable[i]);
        end;
        EncodeBlock(@Enc, ZigBlock, LastDCY, True);
      end;

      // Cb
      ForwardDCT(BlockCb);
      for i := 0 to 63 do
      begin
        if CbTable[i] = 0 then ZigBlock[ZigZag[i]] := 0
        else ZigBlock[ZigZag[i]] := QuantizeCoeff(BlockCb[i], CbTable[i]);
      end;
      EncodeBlock(@Enc, ZigBlock, LastDCCb, False);

      // Cr
      ForwardDCT(BlockCr);
      for i := 0 to 63 do
      begin
        if CbTable[i] = 0 then ZigBlock[ZigZag[i]] := 0
        else ZigBlock[ZigZag[i]] := QuantizeCoeff(BlockCr[i], CbTable[i]);
      end;
      EncodeBlock(@Enc, ZigBlock, LastDCCr, False);

      Inc(x, 16);
    end;
    Inc(y, 16);
  end;

  FlushBits(@Enc);
  WriteWordBE(@Enc, JPEG_EOI);

  if not Enc.Error then
  begin
    Result  := Enc.OutData;
    OutSize := Enc.OutPos;
  end
  else
  begin
    if Enc.OutData <> nil then FreeMem(Enc.OutData);
    Result := nil;
  end;
end;

procedure JPEG_FreeEncoded(Data: Pointer);
begin
  if Data <> nil then FreeMem(Data);
end;

end.

{ =========================================================
  KernelMath.pas — Matematik Kütüphanesi
  
  İçerik:
  - Temel: Abs, Min, Max, Clamp, Sign
  - Yuvarlama: Round, Floor, Ceil, Trunc
  - Güç/Kök: Sqr, Sqrt, Power, Log2, Log10, Ln
  - Trigonometri: Sin, Cos, Tan, ArcSin, ArcCos, ArcTan
  - Integer Trigonometri (FPU yok, LUT tabanlı)
  - Bölüm/Mod: DivMod, GCD, LCM
  - Bit: BitCount, IsPow2, NextPow2, RotL, RotR
  - İstatistik: Sum, Average, Variance, StdDev
  - Geometri: Distance, Lerp, InRange
  - Sayı teorisi: IsPrime, Factorial, Fibonacci
  ========================================================= }

unit Math;

interface

Uses SysUtils;

const
  PI         = 3.14159265358979;
  PI2        = 6.28318530717959;
  PIHalf     = 1.57079632679490;
  PIQuarter  = 0.78539816339745;
  E_NUM      = 2.71828182845905;
  SQRT2      = 1.41421356237310;
  SQRT3      = 1.73205080756888;
  LN2        = 0.69314718055995;
  LN10       = 2.30258509299405;

  // Sin tablosu hassasiyeti (x10000)
  TRIG_SCALE = 10000;

  MAX_INT    = $7FFFFFFF;
 // MIN_INT    = -$80000000;

type
  TIntArray   = array of Integer;
  TFloatArray = array of Single;

//=============================================================================
// Temel Fonksiyonlar
//=============================================================================

function  AbsI(X: Integer): Integer;
function  AbsF(X: Single): Single;
function  MinI(A, B: Integer): Integer;
function  MaxI(A, B: Integer): Integer;
function  MinF(A, B: Single): Single;
function  MaxF(A, B: Single): Single;
function  ClampI(X, Lo, Hi: Integer): Integer;
function  ClampF(X, Lo, Hi: Single): Single;
function  SignI(X: Integer): Integer;
function  SignF(X: Single): Single;
function  InRange(X, Lo, Hi: Integer): Boolean;
function  InRangeF(X, Lo, Hi: Single): Boolean;

//=============================================================================
// Yuvarlama
//=============================================================================

function  Round(X: Single): Integer;
//function  Floor(X: Single): Integer;
//function  Ceil(X: Single): Integer;
function  Trunc(X: Single): Integer;
function  Frac(X: Single): Single;
function  RoundTo(X: Single; Decimals: Integer): Single;

//=============================================================================
// Güç / Kök
//=============================================================================

function  Sqr(X: Integer): Integer;
function  SqrF(X: Single): Single;
function  Sqrt(X: Single): Single;
function  SqrtI(X: LongWord): LongWord;
function  Power(Base, Exp: Single): Single;
function  PowerI(Base, Exp: Integer): Integer;
function  Log2(X: Single): Single;
function  Log10(X: Single): Single;
function  Ln(X: Single): Single;
function  Exp(X: Single): Single;

//=============================================================================
// Trigonometri (Float)
//=============================================================================

function  Sin(Rad: Single): Single;
function  Cos(Rad: Single): Single;
function  Tan(Rad: Single): Single;
function  ArcSin(X: Single): Single;
function  ArcCos(X: Single): Single;
function  ArcTan(X: Single): Single;
function  ArcTan2(Y, X: Single): Single;
function  Deg2Rad(Deg: Single): Single;
function  Rad2Deg(Rad: Single): Single;
function  Hypot(X, Y: Single): Single;

//=============================================================================
// Trigonometri (Integer, FPU yok — LUT tabanlı)
// Girdi: 0..359 derece, Çıktı: x10000 (TRIG_SCALE)
//=============================================================================

function  SinI(Deg: Integer): Integer;
function  CosI(Deg: Integer): Integer;
function  TanI(Deg: Integer): Integer;

//=============================================================================
// Bit İşlemleri
//=============================================================================

function  BitCount(X: LongWord): Integer;
function  IsPow2(X: LongWord): Boolean;
function  NextPow2(X: LongWord): LongWord;
function  PrevPow2(X: LongWord): LongWord;
function  RotL(X: LongWord; N: Byte): LongWord;
function  RotR(X: LongWord; N: Byte): LongWord;
function  BitSet(X: LongWord; Bit: Byte): LongWord;
function  BitClear(X: LongWord; Bit: Byte): LongWord;
function  BitToggle(X: LongWord; Bit: Byte): LongWord;
function  BitTest(X: LongWord; Bit: Byte): Boolean;
function  HighBit(X: LongWord): Integer;
function  LowBit(X: LongWord): Integer;

//=============================================================================
// Bölüm / Mod
//=============================================================================

procedure DivMod(A, B: Integer; var Q, R: Integer);
function  GCD(A, B: LongWord): LongWord;
function  LCM(A, B: LongWord): LongWord;
function  _Mod(A, B: Integer): Integer;
function  SafeDiv(A, B: Integer; Default: Integer): Integer;

//=============================================================================
// İstatistik
//=============================================================================

//function  SumI(Arr: PInteger; Count: Integer): Integer;
//function  SumF(Arr: PSingle; Count: Integer): Single;
//function  AverageI(Arr: PInteger; Count: Integer): Single;
//function  AverageF(Arr: PSingle; Count: Integer): Single;
//function  MinArr(Arr: PInteger; Count: Integer): Integer;
//function  MaxArr(Arr: PInteger; Count: Integer): Integer;
//function  Variance(Arr: PSingle; Count: Integer): Single;
//function  StdDev(Arr: PSingle; Count: Integer): Single;
//function  Median(Arr: PInteger; Count: Integer): Single;

//=============================================================================
// Geometri / Interpolasyon
//=============================================================================

function  DistanceI(X1, Y1, X2, Y2: Integer): Single;
function  DistanceSqI(X1, Y1, X2, Y2: Integer): Integer;
function  LerpF(A, B, T: Single): Single;
function  LerpI(A, B, T256: Integer): Integer;
function  SmoothStep(Edge0, Edge1, X: Single): Single;
function  MapRange(X, InLo, InHi, OutLo, OutHi: Single): Single;
function  MapRangeI(X, InLo, InHi, OutLo, OutHi: Integer): Integer;

//=============================================================================
// Sayı Teorisi
//=============================================================================

function  IsPrime(N: LongWord): Boolean;
function  Factorial(N: Integer): LongWord;
function  Fibonacci(N: Integer): LongWord;
function  IsEven(N: Integer): Boolean;
function  IsOdd(N: Integer): Boolean;
function  AlignUp(X, Align: LongWord): LongWord;
function  AlignDown(X, Align: LongWord): LongWord;
function  DivRoundUp(A, B: LongWord): LongWord;

function Min(const x, y: LongInt): LongInt;
function Max(const x, y: LongInt): LongInt;
function IfThen(AValue: Boolean; const ATrue: Integer; const AFalse: Integer): Integer; overload;
function IfThen(AValue: Boolean; const ATrue: Single; const AFalse: Single): Single; overload;

implementation

//=============================================================================
// Sin LUT (0..90 derece, x10000)
//=============================================================================

const
  SinLUT: array[0..90] of Integer = (
        0,   174,   348,   523,   697,   871,  1045,  1218,  1391,  1564,
     1736,  1908,  2079,  2249,  2419,  2588,  2756,  2923,  3090,  3255,
     3420,  3583,  3746,  3907,  4067,  4226,  4383,  4539,  4694,  4848,
     5000,  5150,  5299,  5446,  5591,  5735,  5877,  6018,  6156,  6293,
     6427,  6560,  6691,  6819,  6946,  7071,  7193,  7313,  7431,  7547,
     7660,  7771,  7880,  7986,  8090,  8191,  8290,  8386,  8480,  8571,
     8660,  8746,  8829,  8910,  8987,  9063,  9135,  9205,  9271,  9335,
     9396,  9455,  9510,  9562,  9612,  9659,  9702,  9743,  9781,  9816,
     9848,  9876,  9902,  9925,  9945,  9961,  9975,  9986,  9993,  9998,
    10000
  );


function Min(const x, y: LongInt): LongInt;
begin
  if x < y then
    Result := (x)
  else
    Result := (y);
end;

function Max(const x, y: LongInt): LongInt;
begin
  if x > y then
    Result := x
  else
    Result := y;
end;

//=============================================================================
// Temel
//=============================================================================

function AbsI(X: Integer): Integer;
begin
  if X < 0 then Result := -X else Result := X;
end;

function AbsF(X: Single): Single;
begin
  if X < 0 then Result := -X else Result := X;
end;

function MinI(A, B: Integer): Integer;
begin
  if A < B then Result := A else Result := B;
end;

function MaxI(A, B: Integer): Integer;
begin
  if A > B then Result := A else Result := B;
end;

function MinF(A, B: Single): Single;
begin
  if A < B then Result := A else Result := B;
end;

function MaxF(A, B: Single): Single;
begin
  if A > B then Result := A else Result := B;
end;

function ClampI(X, Lo, Hi: Integer): Integer;
begin
  if X < Lo then Result := Lo
  else if X > Hi then Result := Hi
  else Result := X;
end;

function ClampF(X, Lo, Hi: Single): Single;
begin
  if X < Lo then Result := Lo
  else if X > Hi then Result := Hi
  else Result := X;
end;

function SignI(X: Integer): Integer;
begin
  if X > 0 then Result := 1
  else if X < 0 then Result := -1
  else Result := 0;
end;

function SignF(X: Single): Single;
begin
  if X > 0 then Result := 1.0
  else if X < 0 then Result := -1.0
  else Result := 0.0;
end;

function InRange(X, Lo, Hi: Integer): Boolean;
begin
  Result := (X >= Lo) and (X <= Hi);
end;

function InRangeF(X, Lo, Hi: Single): Boolean;
begin
  Result := (X >= Lo) and (X <= Hi);
end;

//=============================================================================
// Yuvarlama
//=============================================================================


function Round(x: Single): LongInt;
asm
    fld x
    fistp Result
end;



function Floor(const x: Single): Integer;
begin
  Result := Round(x);
  if (Result < 0) and (Result < x) then
    Inc(Result)
  else if (Result > 0) and (Result > x) then
    Dec(Result);
end;






function Trunc(x: Single): Integer;
begin
  Result := Floor(x);
end;


{function Floor(X: Single): Integer;
var
  t: Integer;
begin
  t := Trunc(X);
  if X < 0 then
  begin
    if Single(t) <> X then
      Result := t - 1
    else
      Result := t;
  end
  else
    Result := t;
end;

function Ceil(X: Single): Integer;
var
  t: Integer;
begin
  t := Trunc(X);
  if X > 0 then
  begin
    if Single(t) <> X then
      Result := t + 1
    else
      Result := t;
  end
  else
    Result := t;
end; }

function Frac(X: Single): Single;
begin
  Result := X - Trunc(X);
end;

function RoundTo(X: Single; Decimals: Integer): Single;
var
  factor: Single;
  i:      Integer;
begin
  factor := 1.0;
  i := 0;
  while i < Decimals do
  begin
    factor := factor * 10.0;
    Inc(i);
  end;
  Result := Round(X * factor) / factor;
end;

//=============================================================================
// Güç / Kök
//=============================================================================

function Sqr(X: Integer): Integer;
begin
  Result := X * X;
end;

function SqrF(X: Single): Single;
begin
  Result := X * X;
end;

function Sqrt(X: Single): Single;
begin
  if X <= 0 then begin Result := 0; Exit; end;
  asm
    fld  X
    fsqrt
    fstp Result
  end;
end;

function SqrtI(X: LongWord): LongWord;
var
  r, t: LongWord;
begin
  if X = 0 then begin Result := 0; Exit; end;
  // Bit-shift metodu
  r := 0;
  t := $40000000;
  while t > 0 do
  begin
    if (r or t) * (r or t) <= X then
      r := r or t;
    t := t shr 2;
  end;
  Result := r;
end;

function Power(Base, Exp: Single): Single;
begin
  if Base <= 0 then begin Result := 0; Exit; end;
  asm
    fld1
    fld  Exp
    fld  Base
    fyl2x
    fmulp
    f2xm1
    fld1
    faddp
    fstp Result
  end;
end;

function PowerI(Base, Exp: Integer): Integer;
var
  i: Integer;
begin
  if Exp = 0 then begin Result := 1; Exit; end;
  if Exp < 0 then begin Result := 0; Exit; end;
  Result := 1;
  i := 0;
  while i < Exp do
  begin
    Result := Result * Base;
    Inc(i);
  end;
end;

function Ln(X: Single): Single;
begin
  if X <= 0 then begin Result := 0; Exit; end;
  asm
    fldln2
    fld X
    fyl2x
    fstp Result
  end;
end;

function Log2(X: Single): Single;
begin
  if X <= 0 then begin Result := 0; Exit; end;
  asm
    fld1
    fld X
    fyl2x
    fstp Result
  end;
end;

function Log10(X: Single): Single;
begin
  if X <= 0 then begin Result := 0; Exit; end;
  asm
    fldlg2
    fld X
    fyl2x
    fstp Result
  end;
end;

function Exp(X: Single): Single;
begin
  asm
    fld  X
    fldl2e
    fmulp
    fld  st(0)
    frndint
    fxch st(1)
    fsub st(0), st(1)
    f2xm1
    fld1
    faddp
    fscale
    fstp Result
    ffree st(0)
  end;
end;

//=============================================================================
// Trigonometri (Float, FPU)
//=============================================================================

function Sin(Rad: Single): Single;
begin
  asm
    fld  Rad
    fsin
    fstp Result
  end;
end;

function Cos(Rad: Single): Single;
begin
  asm
    fld  Rad
    fcos
    fstp Result
  end;
end;

function Tan(Rad: Single): Single;
begin
  asm
    fld  Rad
    fptan
    fstp st(0)
    fstp Result
  end;
end;

function ArcTan(X: Single): Single;
begin
  asm
    fld  X
    fld1
    fpatan
    fstp Result
  end;
end;

function ArcTan2(Y, X: Single): Single;
begin
  asm
    fld  Y
    fld  X
    fpatan
    fstp Result
  end;
end;

function ArcSin(X: Single): Single;
begin
  if X <= -1.0 then begin Result := -PIHalf; Exit; end;
  if X >= 1.0  then begin Result :=  PIHalf; Exit; end;
  Result := ArcTan2(X, Sqrt(1.0 - X * X));
end;

function ArcCos(X: Single): Single;
begin
  if X <= -1.0 then begin Result := PI;  Exit; end;
  if X >= 1.0  then begin Result := 0.0; Exit; end;
  Result := ArcTan2(Sqrt(1.0 - X * X), X);
end;

function Deg2Rad(Deg: Single): Single;
begin
  Result := Deg * (PI / 180.0);
end;

function Rad2Deg(Rad: Single): Single;
begin
  Result := Rad * (180.0 / PI);
end;

function Hypot(X, Y: Single): Single;
begin
  Result := Sqrt(X * X + Y * Y);
end;

//=============================================================================
// Trigonometri (Integer, LUT tabanlı, FPU gerektirmez)
//=============================================================================

function SinI(Deg: Integer): Integer;
begin
  Deg := Deg mod 360;
  if Deg < 0 then Inc(Deg, 360);

  if Deg <= 90  then Result :=  SinLUT[Deg]
  else if Deg <= 180 then Result :=  SinLUT[180 - Deg]
  else if Deg <= 270 then Result := -SinLUT[Deg - 180]
  else                    Result := -SinLUT[360 - Deg];
end;

function CosI(Deg: Integer): Integer;
begin
  Result := SinI(Deg + 90);
end;

function TanI(Deg: Integer): Integer;
var
  c: Integer;
begin
  c := CosI(Deg);
  if c = 0 then
    Result := MAX_INT
  else
    Result := (SinI(Deg) * TRIG_SCALE) div c;
end;

//=============================================================================
// Bit İşlemleri
//=============================================================================

function BitCount(X: LongWord): Integer;
begin
  Result := 0;
  while X <> 0 do
  begin
    if (X and 1) <> 0 then Inc(Result);
    X := X shr 1;
  end;
end;

function IsPow2(X: LongWord): Boolean;
begin
  Result := (X > 0) and ((X and (X - 1)) = 0);
end;

function NextPow2(X: LongWord): LongWord;
begin
  if X = 0 then begin Result := 1; Exit; end;
  Dec(X);
  X := X or (X shr 1);
  X := X or (X shr 2);
  X := X or (X shr 4);
  X := X or (X shr 8);
  X := X or (X shr 16);
  Result := X + 1;
end;

function PrevPow2(X: LongWord): LongWord;
begin
  X := X or (X shr 1);
  X := X or (X shr 2);
  X := X or (X shr 4);
  X := X or (X shr 8);
  X := X or (X shr 16);
  Result := X - (X shr 1);
end;

function RotL(X: LongWord; N: Byte): LongWord;
begin
  Result := (X shl N) or (X shr (32 - N));
end;

function RotR(X: LongWord; N: Byte): LongWord;
begin
  Result := (X shr N) or (X shl (32 - N));
end;

function BitSet(X: LongWord; Bit: Byte): LongWord;
begin
  Result := X or (1 shl Bit);
end;

function BitClear(X: LongWord; Bit: Byte): LongWord;
begin
  Result := X and not (1 shl Bit);
end;

function BitToggle(X: LongWord; Bit: Byte): LongWord;
begin
  Result := X xor (1 shl Bit);
end;

function BitTest(X: LongWord; Bit: Byte): Boolean;
begin
  Result := (X and (1 shl Bit)) <> 0;
end;

function HighBit(X: LongWord): Integer;
begin
  Result := -1;
  if X = 0 then Exit;
  Result := 0;
  while X > 1 do
  begin
    X := X shr 1;
    Inc(Result);
  end;
end;

function LowBit(X: LongWord): Integer;
begin
  Result := -1;
  if X = 0 then Exit;
  Result := 0;
  while (X and 1) = 0 do
  begin
    X := X shr 1;
    Inc(Result);
  end;
end;

//=============================================================================
// Bölüm / Mod
//=============================================================================

procedure DivMod(A, B: Integer; var Q, R: Integer);
begin
  if B = 0 then begin Q := 0; R := 0; Exit; end;
  Q := A div B;
  R := A mod B;
end;

function GCD(A, B: LongWord): LongWord;
var
  t: LongWord;
begin
  while B <> 0 do
  begin
    t := B;
    B := A mod B;
    A := t;
  end;
  Result := A;
end;

function LCM(A, B: LongWord): LongWord;
var
  g: LongWord;
begin
  g := GCD(A, B);
  if g = 0 then Result := 0
  else Result := (A div g) * B;
end;

function _Mod(A, B: Integer): Integer;
begin
  if B = 0 then begin Result := 0; Exit; end;
  Result := A mod B;
  if (Result < 0) and (B > 0) then
    Inc(Result, B);
end;

function SafeDiv(A, B: Integer; Default: Integer): Integer;
begin
  if B = 0 then Result := Default
  else Result := A div B;
end;

//=============================================================================
// İstatistik
//=============================================================================

{function SumI(Arr: PInteger; Count: Integer): Integer;
var
  i: Integer;
begin
  Result := 0;
  i := 0;
  while i < Count do
  begin
    Inc(Result, Arr[i]);
    Inc(i);
  end;
end;

function SumF(Arr: PSingle; Count: Integer): Single;
var
  i: Integer;
begin
  Result := 0;
  i := 0;
  while i < Count do
  begin
    Result := Result + Arr[i];
    Inc(i);
  end;
end;  

function AverageI(Arr: PInteger; Count: Integer): Single;
begin
  if Count = 0 then begin Result := 0; Exit; end;
  Result := SumI(Arr, Count) / Count;
end;

function AverageF(Arr: PSingle; Count: Integer): Single;
begin
  if Count = 0 then begin Result := 0; Exit; end;
  Result := SumF(Arr, Count) / Count;
end; }

{function MinArr(Arr: PInteger; Count: Integer): Integer;
var
  i: Integer;
begin
  if Count = 0 then begin Result := 0; Exit; end;
  Result := Arr[0];
  i := 1;
  while i < Count do
  begin
    if Arr[i] < Result then Result := Arr[i];
    Inc(i);
  end;
end; 




function StdDev(Arr: PSingle; Count: Integer): Single;
begin
  Result := Sqrt(Variance(Arr, Count));
end;
    }

//=============================================================================
// Geometri / Interpolasyon
//=============================================================================

function DistanceI(X1, Y1, X2, Y2: Integer): Single;
var
  dx, dy: Integer;
begin
  dx := X2 - X1;
  dy := Y2 - Y1;
  Result := Sqrt(dx*dx + dy*dy);
end;

function DistanceSqI(X1, Y1, X2, Y2: Integer): Integer;
var
  dx, dy: Integer;
begin
  dx := X2 - X1;
  dy := Y2 - Y1;
  Result := dx*dx + dy*dy;
end;

function LerpF(A, B, T: Single): Single;
begin
  Result := A + (B - A) * T;
end;

function LerpI(A, B, T256: Integer): Integer;
begin
  Result := A + ((B - A) * T256) div 256;
end;

function SmoothStep(Edge0, Edge1, X: Single): Single;
var
  t: Single;
begin
  if X <= Edge0 then begin Result := 0; Exit; end;
  if X >= Edge1 then begin Result := 1; Exit; end;
  t := (X - Edge0) / (Edge1 - Edge0);
  Result := t * t * (3.0 - 2.0 * t);
end;

function MapRange(X, InLo, InHi, OutLo, OutHi: Single): Single;
begin
  if AbsF(InHi - InLo) < 0.000001 then
  begin
    Result := OutLo;
    Exit;
  end;
  Result := OutLo + (X - InLo) * (OutHi - OutLo) / (InHi - InLo);
end;

function MapRangeI(X, InLo, InHi, OutLo, OutHi: Integer): Integer;
begin
  if InHi = InLo then begin Result := OutLo; Exit; end;
  Result := OutLo + (X - InLo) * (OutHi - OutLo) div (InHi - InLo);
end;

//=============================================================================
// Sayı Teorisi
//=============================================================================

function IsPrime(N: LongWord): Boolean;
var
  i: LongWord;
begin
  if N < 2 then begin Result := False; Exit; end;
  if N = 2 then begin Result := True;  Exit; end;
  if (N and 1) = 0 then begin Result := False; Exit; end;
  i := 3;
  while i * i <= N do
  begin
    if N mod i = 0 then begin Result := False; Exit; end;
    Inc(i, 2);
  end;
  Result := True;
end;

function Factorial(N: Integer): LongWord;
var
  i: Integer;
begin
  Result := 1;
  if N <= 0 then Exit;
  if N > 12  then begin Result := $FFFFFFFF; Exit; end; // overflow
  i := 2;
  while i <= N do
  begin
    Result := Result * LongWord(i);
    Inc(i);
  end;
end;

function Fibonacci(N: Integer): LongWord;
var
  a, b, t: LongWord;
  i:       Integer;
begin
  if N <= 0 then begin Result := 0; Exit; end;
  if N = 1  then begin Result := 1; Exit; end;
  a := 0; b := 1;
  i := 2;
  while i <= N do
  begin
    t := a + b;
    a := b;
    b := t;
    Inc(i);
  end;
  Result := b;
end;

function IsEven(N: Integer): Boolean;
begin
  Result := (N and 1) = 0;
end;

function IsOdd(N: Integer): Boolean;
begin
  Result := (N and 1) <> 0;
end;

function AlignUp(X, Align: LongWord): LongWord;
begin
  if Align = 0 then begin Result := X; Exit; end;
  Result := (X + Align - 1) and not (Align - 1);
end;

function AlignDown(X, Align: LongWord): LongWord;
begin
  if Align = 0 then begin Result := X; Exit; end;
  Result := X and not (Align - 1);
end;

function DivRoundUp(A, B: LongWord): LongWord;
begin
  if B = 0 then begin Result := 0; Exit; end;
  Result := (A + B - 1) div B;
end;

function IfThen(AValue: Boolean; const ATrue: Integer; const AFalse: Integer): Integer; overload;
begin
  if AValue then
    Result := ATrue
  else
    Result := AFalse;
end;



function IfThen(AValue: Boolean; const ATrue: Single; const AFalse: Single): Single; overload;
begin
  if AValue then
    Result := ATrue
  else
    Result := AFalse;
end;




end.

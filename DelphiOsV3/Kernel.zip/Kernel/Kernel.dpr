program Kernel;

{$IMAGEBASE $00100000}
//{$MINSTACKSIZE $4000}
//{$MAXSTACKSIZE $4000}
//{$APPTYPE CONSOLE}



uses
  SysUtils,
  Gdt,
  Idt,
  Task,
  Pit,
  Vesa,
  Intr32,
  Mouse,
  Keyboard,
  Fat32,
  Draw32,
  Math,
  Memory,
  Desktops,
  TaskBar,
  AppLauncher,
  SyscallGUI,
  GUI,
  GUIControls,
  Messages,
  ProcessMgr,
  DirectoryView,
  HDDWindow,
  PaintApp,
  KernelFont,
  ImageLists,
  FileIcons,
  IniFiles,
  Console,
  Pci,
  NetworkDevices,
 RTL8139,
  NE2000,
  WinSocket,
  ImageView,
  MjpegServer,
// WavPlayer,
  //TextEditor,
 // Sounds,
 DLLLoader,
  DrawIcons,
  MemoryWindow,
  ExampleForm,
  Basic ,
  ExeFile;

// =============================================================================
// SAFA KERNEL M�MAR�S� (Sadece KERNEL_MODE Tan�ml�ysa Derlenir)
// =============================================================================





type
  // BIOS kesmeleri i�in gerekli TReg32 yap�s�
  TReg32 = packed record
    EDI, ESI, EBP, ESP, EBX, EDX, ECX, EAX: Cardinal;
    EFLAGS: Cardinal;
    ES, CS, SS, DS, FS, GS: Word;
  end;






  {=============================================================================}
{ Yardimci Fonksiyonlar                                                       }
{=============================================================================}








procedure FormFitScreen(F: PForm; Margin: Integer);
begin
  if F^.Width > SCREEN_WIDTH - Margin * 2 then
    F^.Width := SCREEN_WIDTH - Margin * 2;
  if F^.Height > SCREEN_HEIGHT - Margin * 2 then
    F^.Height := SCREEN_HEIGHT - Margin * 2;
  if F^.Left < Margin then F^.Left := Margin;
  if F^.Top < Margin then F^.Top := Margin;
  if F^.Left + F^.Width > SCREEN_WIDTH - Margin then
    F^.Left := SCREEN_WIDTH - Margin - F^.Width;
  if F^.Top + F^.Height > SCREEN_HEIGHT - Margin then
    F^.Top := SCREEN_HEIGHT - Margin - F^.Height;
end;


procedure Open_Wall_Bmp();
var
  Handle,Size: Integer;
begin
   Handle:= OpenFile('C:\Wall.BMP', FILE_READ);
   if handle >= 0 then
    begin
     Size := FileSize(handle);
     Wall_Data := (MemAlloc(Size));
    if Wall_Data = nil then
    begin
      CloseFile(handle);
      Exit;
    end;
      ReadFile(handle, Wall_Data, Size);
      CloseFile(handle);
    end;
end;




procedure ProcessMessages();
var
  OverForm: Boolean;

begin


 While True do
 begin
  Cls($800080);

 // Move(Wall_Data[0], Screen_Buffer[0], SCREEN_SIZE);

  Desktop_Render;
  TaskBar_Render;

   UpdateTimers;

  WriteInt(250, 40, FreeMemory, clBlack);
  WriteInt(250, 50, GetFreeMemKB, clBlack);
  WriteInt(250, 60, (FreeMemory - GetFreeMemKB), clBlack);

//  WriteStr(450,50,Drives[1].ISOModel);


   // Test_DrawAllIcons(400,50,48);


  WinManager.PaintAll;

  


 //Test_DrawAllIcons(300,10,48);

 // _WriteStr(100,100,'�����',clWhite);

  { ----------------------------------------------------------
    1. MOUSE MOVE (Her zaman ILK - koordinat guncellemesi)
    ---------------------------------------------------------- }
  if MouseState.IsMove then
  begin
    WinManager.MouseMove(MouseState.X, MouseState.Y, 0);
    
   
    if not IsMouseOverAnyForm(MouseState.X, MouseState.Y) then
      Desktop_HandleMouseMove(MouseState.X, MouseState.Y);
  end;


  

  if MouseState.LeftDown then
  begin

    TaskBar_HandleClick(MouseState.X, MouseState.Y);


    WinManager.MouseDown(MouseState.X, MouseState.Y, 1);
  end;


  if MouseState.RightDown then
  begin
    WinManager.MouseDown(MouseState.X, MouseState.Y, 2);
  end;


  if MouseState.LeftUp then
  begin
    WinManager.MouseUp(MouseState.X, MouseState.Y, 1);
    

    if not IsMouseOverAnyForm(MouseState.X, MouseState.Y) then
      Desktop_HandleMouseUp(MouseState.X, MouseState.Y);
  end;


  if MouseState.RightUp then
  begin
    WinManager.MouseUp(MouseState.X, MouseState.Y, 2);
  end;


  if MouseState.DblClick then
  begin
    WinManager.DblClick(MouseState.X, MouseState.Y, 3);
    
    if not IsMouseOverAnyForm(MouseState.X, MouseState.Y) then
      Desktop_HandleDoubleClick(MouseState.X, MouseState.Y);
  end;
       
  { ----------------------------------------------------------
    Ekran guncelleme
    ---------------------------------------------------------- }
  Mouse_DrawCursor;
  Move(Screen_Buffer, Pointer(Vesa_Info.PhysBasePtr)^, SCREEN_SIZE);
  
  { Tum event'leri tek seferde temizle }
  Mouse_ClearEvents;


       asm
         sti;
         hlt
       end;

   Thread_Yield;

   end;
end;




procedure TestDll();
 type
  TAddFunc = function(a, b: Integer): Integer; stdcall;
var
  DLLBase:Integer;
  AddFunc: TAddFunc;
  I:Integer;
   Buff:array[0..31] of Char;
begin
  DLLBase:=LoadLibrary('kernel.dll');
  AddFunc := TAddFunc(GetProcAddress(DLLBase, 'Add'));
  if Assigned(AddFunc) then
  I:= AddFunc(55,60);
   IntToPChar(I,@Buff[0]);
  Showmessage(Buff);  //
  FreeLibrary(DLLBase);


end;




// =============================================================================
// ANA PROGRAM AKI�I
// =============================================================================
begin
    

    Gdt_init();
    Idt_init();
    Pid_init();
    Vesa_Init();
    Fat32_Init();
    Keyboard_Init();
    Mouse_Init(SCREEN_WIDTH,SCREEN_HEIGHT);
    Memory_Init;
    pci_init();
    Task_Init;
    Syscall_Init;
    ImageList_Init();
    Font_Init;
    Draw32_Init(@Screen_Buffer[0],SCREEN_WIDTH,SCREEN_HEIGHT,24);
    Clip_Set(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);

    Desktop_Init(SCREEN_WIDTH,SCREEN_HEIGHT);
    TaskBar_Init(SCREEN_WIDTH);

    AutoDetectAndInitNetworkDevices;

   // InitAllNetworkDrivers;

   // RTL8139_Init();
  //  DLLLoader_Init;

    InitDesktop;

    

    AppLauncher_Init('C:\BIN\');
    AppLauncher_Scan;

    // 3. Desktop iconlarını ekle
    AppLauncher_PopulateDesktop;


    
    ProcessMgr_Init;
   //  Open_Wall_Bmp();


     FreeMemory := GetFreeMemKB;

   
 //  WriteINIFile('Test.ini','Delphi','Os');
   
    // PlayWav('C:\Sounds\Ring01.wav');

    // OpenWavPlayer('C:\Sounds\Ring01.wav');
    
   //  Test1();


// InitApp;
    //  Test2();
   // PlayWav('C:\Sounds\Ring01.wav');

   //OpenPaintApp;

 //CreateExampleForm;


 //TestDll();




     // IntToPChar( DriveCount,str);

    //  Showmessage(PChar(Drives[0].Letter));


 


 // OpenImageViewer('C:\output.jpg');

 // OpenImageViewer('D:\BMP.BMP');

 // DHCPDiscover;

  BeginThread(@ProcessMessages, nil, 'Main',PRIO_HIGH, TF_KERNEL);


   //  OpenMjpegServerForm;

  // HttpServer();

    while True do
    begin

    // WinManager.ProcessMessages();


       asm
         sti;
         hlt
       end;
    end;


  
end.


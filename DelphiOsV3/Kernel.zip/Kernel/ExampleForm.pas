unit ExampleForm;

interface

uses
  SysUtils, GUI, GUIControls;

procedure CreateExampleForm;

implementation

var
  FrmMain: PForm;
  TB: PToolBar;
  MB: PMenuBar;
  TC: PTabControl;
  PageFiles, PageEditor: PPanel;
  LV: PListView;
  MEM: PMemo;
  CB: PComboBox;
  BtnAdd, BtnSave: PButton;
  SB: PStatusBar;
  ItemCounter: Integer;

procedure OnMenuExit(Sender: PObject);
begin
  if FrmMain <> nil then
    WinManager.RemoveForm(FrmMain);
end;

procedure OnToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
begin
  // Örnek: durum çubuğunu güncelle
 // StatusBarSetText(SB, 0, PChar('Toolbar button ' + IntToStr(ButtonIndex) + ' clicked'));
end;

procedure OnAddItemClick(Sender: PObject);
var
  Idx: Integer;
  S: array[0..127] of Char;
begin
 // Inc(ItemCounter);
//  StrFmt(S, 'Item %d', [ItemCounter]);
 // Idx := ListViewAddItem(LV, @S[0], 0);
  // Örnek alt sütun doldurma:
 // ListViewSetSubItem(LV, Idx, 0, PChar('Size: ' + IntToStr(Idx * 10) + ' KB'));
 // StatusBarSetText(SB, 0, PChar('Added ' + @S[0]));
end;

procedure OnComboChange(Sender: PObject);
var
  Txt: PChar;
begin
  // ComboBox'in seçili öğesini al ve status bar'a yaz
  if CB^.ItemIndex >= 0 then
    Txt := CB^.Items^[CB^.ItemIndex]
  else
    Txt := 'None';
  StatusBarSetText(SB, 0, Txt);
end;

procedure OnSaveClick(Sender: PObject);
begin
  // Basit davranış: durum çubuğuna "Saved" yaz
  StatusBarSetText(SB, 0, PChar('Memo saved.'));
end;

procedure FillDemoListView(ALV: PListView);
var
  i: Integer;
  idx: Integer;
  buf: array[0..127] of Char;
begin
  ListViewAddColumn(ALV, 'Name', 260);
  ListViewAddColumn(ALV, 'Info', 120);
  for i := 1 to 6 do
  begin
   // StrFmt(buf, 'File_%d.txt', [i]);


    idx := ListViewAddItem(ALV,'File.txt', 0);
    ListViewSetSubItem(ALV, idx, 0,'2.1 KB');
  end;
end;

procedure CreateExampleForm;
var
  miFile, miExit: PMenuItem;
  btnIdx: Integer;
begin
  ItemCounter := 0;

  // Form
  FrmMain := CreateForm('Example - Components Demo', 60, 40, 700, 480, bsWindow);

  // MenuBar
  MB := CreateMenuBar(PObject(FrmMain), 0, 0, FrmMain^.Width, alTop);
  miFile := CreateMenuItem('File');
  miExit := CreateMenuItem('Exit');
  miExit^.OnClick := @OnMenuExit;
  MenuItemAddSubItem(miFile, miExit);
  MenuBarAddItem(MB, miFile);

  // ToolBar (dock üstte)
  TB := CreateToolBar(PObject(FrmMain), 0, 0, FrmMain^.Width, 28, alTop);
  btnIdx := ToolBarAddButton(TB, 'Add', 60, nil);
  ToolBarAddButton(TB, 'Refresh', 60, nil);
 // TB^.OnClick := @OnToolBarClick;

  // TabControl (client alanı doldursun)
  TC := CreateTabControl(PObject(FrmMain), 0, 0, FrmMain^.Width, FrmMain^.Height - 60, alClient);

  // Sekme 1: Files
  PageFiles := TabControlAddTab(TC, 'Files');
  // ListView oluştur
  LV := CreateListView(PObject(PageFiles), 10, 8, PageFiles^.Width - 20, PageFiles^.Height - 60, alNone);
  ListViewSetViewStyle(LV, 2); // Details
  LV^.HeaderHeight := 20;
  LV^.RowHeight := FONT_H + 6;
  LV^.GridLines := True;
  FillDemoListView(LV);

  // Add button on files page
  BtnAdd := CreateButton(PObject(PageFiles), 'Add Item', 10, PageFiles^.Height - 44, 90, 30, alNone);
  // Buton click için BindMouseDown yerine basit TNotifyEvent kullanmak uygun değil çünkü Button'ın bind mekanizması MouseDown ile yapıldı. Biz, buton tıklamasında List'e eklemek için MouseUp veya MouseDown kullanacağız.
  BtnAdd^.BindMouseUp(@OnAddItemClick);

  // Sekme 2: Editor
  PageEditor := TabControlAddTab(TC, 'Editor');
  MEM := CreateMemo(PObject(PageEditor), 10, 8, PageEditor^.Width - 20, PageEditor^.Height - 120, alNone);
  MemoSetText(MEM, PChar('This is a demo memo.'#13#10'Edit text here...'));

  // ComboBox
  CB := CreateComboBox(PObject(PageEditor), 10, PageEditor^.Height - 100, 200, 22, alNone);
  ComboBoxAddItem(CB, 'Option A');
  ComboBoxAddItem(CB, 'Option B');
  ComboBoxAddItem(CB, 'Option C');
  CB^.FOnChange := @OnComboChange;

  // Save button
  BtnSave := CreateButton(PObject(PageEditor), 'Save', 220, PageEditor^.Height - 100, 80, 26, alNone);
  BtnSave^.BindMouseUp(@OnSaveClick);

  // StatusBar
  SB := CreateStatusBar(PObject(FrmMain), 0, FrmMain^.Height - 22, FrmMain^.Width, alBottom);
  SB^.AddPanel(PChar('Ready'), 200);

  // Baslangic durumlarini hizala
  RelayoutForm(FrmMain);
end;

end.
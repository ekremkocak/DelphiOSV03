Unit ExeFile;

{ =========================================================
  SORUNLAR:
  1. ResolveImports YOK � IAT bo� � ilk d�� fonksiyon �a�r�s�nda crash
  2. ProcessMgr'a kay�t YOK � GetMessage, WndProc, Console �al��maz
  3. Section gap dolgusu eksik (k���k sorun)
  4. ExeWrapper stdcall ile BeginThread uyumsuzlu�u
  ========================================================= }

interface

Uses
  SysUtils, Pit, GUI, GUIControls, Messages, Memory, Task,
  Draw32, Fat32, Math,Console,
  DLLLoader,   { � ResolveImports i�in eklendi }
  ProcessMgr;  { � Process kayd� i�in eklendi }

const
  IMAGE_NUMBEROF_DIRECTORY_ENTRIES = 16;
  IMAGE_DIRECTORY_ENTRY_EXPORT     = 0;
  IMAGE_DIRECTORY_ENTRY_IMPORT     = 1;
  IMAGE_DIRECTORY_ENTRY_BASERELOC  = 5;
  IMAGE_REL_BASED_HIGHLOW          = 3;
  IMAGE_DIRECTORY_ENTRY_RESOURCE   = 2;
  IMAGE_REL_BASED_ABSOLUTE         = 0;

type
  PImageDosHeader = ^TImageDosHeader;
  TImageDosHeader = packed record
    e_magic    : Word;
    e_cblp     : Word;
    e_cp       : Word;
    e_crlc     : Word;
    e_cparhdr  : Word;
    e_minalloc : Word;
    e_maxalloc : Word;
    e_ss       : Word;
    e_sp       : Word;
    e_csum     : Word;
    e_ip       : Word;
    e_cs       : Word;
    e_lfarlc   : Word;
    e_ovno     : Word;
    e_res      : array[0..3] of Word;
    e_oemid    : Word;
    e_oeminfo  : Word;
    e_res2     : array[0..9] of Word;
    _lfanew    : LongInt;
  end;

  PImageFileHeader = ^TImageFileHeader;
  TImageFileHeader = packed record
    Machine              : Word;
    NumberOfSections     : Word;
    TimeDateStamp        : DWORD;
    PointerToSymbolTable : DWORD;
    NumberOfSymbols      : DWORD;
    SizeOfOptionalHeader : Word;
    Characteristics      : Word;
  end;

  PImageDataDirectory = ^TImageDataDirectory;
  TImageDataDirectory = packed record
    VirtualAddress : LongInt;
    Size           : LongInt;
  end;

  TImageOptionalHeader = packed record
    Magic                       : Word;
    MajorLinkerVersion          : Byte;
    MinorLinkerVersion          : Byte;
    SizeOfCode                  : DWORD;
    SizeOfInitializedData       : DWORD;
    SizeOfUninitializedData     : DWORD;
    AddressOfEntryPoint         : DWORD;
    BaseOfCode                  : DWORD;
    BaseOfData                  : DWORD;
    ImageBase                   : DWORD;
    SectionAlignment            : DWORD;
    FileAlignment               : DWORD;
    MajorOperatingSystemVersion : Word;
    MinorOperatingSystemVersion : Word;
    MajorImageVersion           : Word;
    MinorImageVersion           : Word;
    MajorSubsystemVersion       : Word;
    MinorSubsystemVersion       : Word;
    Win32VersionValue           : DWORD;
    SizeOfImage                 : DWORD;
    SizeOfHeaders               : DWORD;
    CheckSum                    : DWORD;
    Subsystem                   : Word;
    DllCharacteristics          : Word;
    SizeOfStackReserve          : DWORD;
    SizeOfStackCommit           : DWORD;
    SizeOfHeapReserve           : DWORD;
    SizeOfHeapCommit            : DWORD;
    LoaderFlags                 : DWORD;
    NumberOfRvaAndSizes         : DWORD;
    DataDirectory : packed array[0..IMAGE_NUMBEROF_DIRECTORY_ENTRIES-1]
                    of TImageDataDirectory;
  end;

  TImageNtHeaders = packed record
    Signature      : DWORD;
    FileHeader     : TImageFileHeader;
    OptionalHeader : TImageOptionalHeader;
  end;
  PImageNtHeaders = ^TImageNtHeaders;

  TISHMisc = packed record
    case Integer of
      0: (PhysicalAddress: DWORD);
      1: (VirtualSize:     DWORD);
  end;

  PImageSectionHeader = ^TImageSectionHeader;
  TImageSectionHeader = packed record
    Name                 : packed array[0..7] of Byte;
    Misc                 : TISHMisc;
    VirtualAddress       : DWORD;
    SizeOfRawData        : DWORD;
    PointerToRawData     : DWORD;
    PointerToRelocations : DWORD;
    PointerToLinenumbers : DWORD;
    NumberOfRelocations  : Word;
    NumberOfLinenumbers  : Word;
    Characteristics      : DWORD;
  end;

  TImageBaseRelocation = packed record
    VirtualAddress : DWORD;
    SizeOfBlock    : DWORD;
  end;
  PImageBaseRelocation = ^TImageBaseRelocation;

procedure OpenExeFile(const FileName: PChar; Params: PChar);

implementation

{ �� Thread ba�latma i�in wrapper ����������������������� }
{ BUG 4 D�ZELT�LD�: stdcall kald�r�ld�.
  BeginThread cdecl/Pascal calling convention bekler.
  Proc: PProcess ge�iriyoruz, ProcessWrapper kullan�yoruz.
  Art�k ExeWrapper kullanm�yoruz � ProcessMgr.ProcessWrapper daha do�ru. }

procedure OpenExeFile(const FileName: PChar; Params: PChar);
var
  F            : Integer;
  FileSize_    : Integer;
  BytesRead    : DWORD;
  DosHeader    : PImageDosHeader;
  NTHeaders    : PImageNtHeaders;
  Sections     : PImageSectionHeader;
  SectionsBase : PImageSectionHeader;  { � d�ng�de ilerleyince reset i�in }
  Reloc        : PImageBaseRelocation;
  EntryW       : PWord;
  FileBuf      : PByteArray;
  ImageBuf     : PByteArray;

  secoff, secsize, rawoff : DWORD;
  RelocRVA, RelocSize, RelocOffset : DWORD;
  OriginalImageBase, Offset, RelocType : DWORD;
  NewImageBasePtr : Pointer;
  i, SecNo, NumEntries : Integer;
  Proc         : PProcess;
  Handle       : Integer;
  NamePtr      : PChar;

  { �� RVA � File Offset �evirici �� }
  function RVAToOffset(RVA: DWORD): DWORD;
  var
    j   : Integer;
    Sec : PImageSectionHeader;
    RawSize : DWORD;
  begin
    Sec := SectionsBase;
    for j := 0 to NTHeaders^.FileHeader.NumberOfSections - 1 do
    begin
      RawSize := Sec^.SizeOfRawData;
      if RawSize = 0 then RawSize := Sec^.Misc.VirtualSize;
      if (RVA >= Sec^.VirtualAddress) and
         (RVA <  Sec^.VirtualAddress + RawSize) then
      begin
        Result := (RVA - Sec^.VirtualAddress) + Sec^.PointerToRawData;
        Exit;
      end;
      Inc(Sec);
    end;
    Result := 0;
  end;

begin
  { �� Dosyay� a� �� }
  F := OpenFile(FileName, FILE_READ);
  if F = INVALID_HANDLE then Exit;

  FileSize_ := FileSize(F);
  if FileSize_ <= 0 then begin CloseFile(F); Exit; end;

  FileBuf := PByteArray(MemAlloc(FileSize_));
  if FileBuf = nil then begin CloseFile(F); Exit; end;

  BytesRead := ReadFile(F, FileBuf, FileSize_);
  if BytesRead = 0 then
  begin
    FreeMem(FileBuf);
    CloseFile(F);
    Exit;
  end;

  { �� DOS ve PE ba�l�k do�rulama �� }
  DosHeader := PImageDosHeader(FileBuf);
  if DosHeader^.e_magic <> $5A4D then
  begin FreeMem(FileBuf); CloseFile(F); Exit; end;

  NTHeaders := PImageNtHeaders(
    NativeUInt(FileBuf) + DosHeader^._lfanew);
  if NTHeaders^.Signature <> $00004550 then
  begin FreeMem(FileBuf); CloseFile(F); Exit; end;

  { �� Image belle�i ay�r (SizeOfImage + Stack) �������������������������
    BUG 2 �NLEM: Sadece SizeOfImage yetmez, stack i�in de alan laz�m.
    ProcessMgr gibi PROCESS_STACK_SIZE ekle. }
  NewImageBasePtr := MemAlloc(
    NTHeaders^.OptionalHeader.SizeOfImage + $10000);  { +64KB stack }
  if NewImageBasePtr = nil then
  begin FreeMem(FileBuf); CloseFile(F); Exit; end;

  FillChar(NewImageBasePtr^,
    NTHeaders^.OptionalHeader.SizeOfImage + $10000, 0);

  ImageBuf := PByteArray(NewImageBasePtr);

  { �� Section ba�lang�� pointer'� hesapla �� }
  SectionsBase := PImageSectionHeader(
    NativeUInt(FileBuf) + DosHeader^._lfanew +
    SizeOf(TImageNtHeaders) - SizeOf(TImageOptionalHeader) +
    NTHeaders^.FileHeader.SizeOfOptionalHeader);

  { �� Header'lar� kopyala �� }
  Move(FileBuf^, ImageBuf^, NTHeaders^.OptionalHeader.SizeOfHeaders);

  { �� Section'lar� kopyala �� }
  Sections := SectionsBase;
  for SecNo := 0 to NTHeaders^.FileHeader.NumberOfSections - 1 do
  begin
    secoff  := Sections^.VirtualAddress;
    secsize := Sections^.SizeOfRawData;
    rawoff  := Sections^.PointerToRawData;

    if (secsize > 0) and (secoff + secsize <= NTHeaders^.OptionalHeader.SizeOfImage) then
      Move(FileBuf[rawoff], ImageBuf[secoff], secsize);

    Inc(Sections);
  end;

  { �� Relocation uygula �� }
  RelocRVA  := NTHeaders^.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress;
  RelocSize := NTHeaders^.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size;
  RelocOffset := RVAToOffset(RelocRVA);
  OriginalImageBase := NTHeaders^.OptionalHeader.ImageBase;

  if (RelocRVA <> 0) and (RelocSize <> 0) and (RelocOffset <> 0) then
  begin
    Reloc := PImageBaseRelocation(NativeUInt(FileBuf) + RelocOffset);
    while Reloc^.SizeOfBlock >= 8 do
    begin
      NumEntries := (Reloc^.SizeOfBlock - SizeOf(TImageBaseRelocation)) div 2;
      EntryW := PWord(NativeUInt(Reloc) + SizeOf(TImageBaseRelocation));

      for i := 0 to NumEntries - 1 do
      begin
        Offset     := EntryW^ and $0FFF;
        RelocType  := EntryW^ shr 12;
        if RelocType = IMAGE_REL_BASED_HIGHLOW then
          PCardinal(@ImageBuf[Reloc^.VirtualAddress + Offset])^ :=
            PCardinal(@ImageBuf[Reloc^.VirtualAddress + Offset])^ +
            (NativeUInt(NewImageBasePtr) - NativeUInt(OriginalImageBase));
        Inc(EntryW);
      end;

      if NativeUInt(Reloc) + Reloc^.SizeOfBlock >=
         NativeUInt(FileBuf) + RelocOffset + RelocSize then Break;
      Reloc := PImageBaseRelocation(NativeUInt(Reloc) + Reloc^.SizeOfBlock);
    end;
  end;

  { �� BUG 1 D�ZELT�LD�: Import tablosunu ��z (IAT patch) ��������������
    Bu olmadan EXE ilk d�� fonksiyonu �a��r�r �a��rmaz crash olur.
    DLLLoader.pas'taki ResolveImports kernel'deki t�m DLL'leri tarar
    ve IAT giri�lerini ger�ek adreslere y�nlendirir. }
  if not ResolveImports(NativeUInt(NewImageBasePtr)) then
  begin
    FreeMem(FileBuf);
    FreeMem(NewImageBasePtr);
    CloseFile(F);
    Exit;
  end;

  { �� Dosyay� kapat ve file buffer'� serbest b�rak �� }
  FreeMem(FileBuf);
  CloseFile(F);

  { �� BUG 2 D�ZELT�LD�: Process'i ProcessMgr'a kaydet �����������������
    ProcessWrapper � ProcessMgr.ProcessCreate ile ayn� kay�t sistemi.
    Manuel kay�t: }
  Proc := PProcess(HeapAlloc(SizeOf(TProcess)));
  if Proc = nil then begin FreeMem(NewImageBasePtr); Exit; end;
  FillChar(Proc^, SizeOf(TProcess), 0);

  Proc^.PID        := NextPID;
  Proc^.State      := psLoading;
  Proc^.BaseAddr   := NativeUInt(NewImageBasePtr);
  Proc^.AllocPtr   := NewImageBasePtr;
  Proc^.ImageSize  := NTHeaders^.OptionalHeader.SizeOfImage;
  Proc^.EntryPoint := NativeUInt(NewImageBasePtr) +
                      NTHeaders^.OptionalHeader.AddressOfEntryPoint;
  Proc^.IsConsole  := NTHeaders^.OptionalHeader.Subsystem =
                      IMAGE_SUBSYSTEM_WINDOWS_CUI;

  { Stack, image'�n hemen ard�nda }
  Proc^.UserStack  := NativeUInt(NewImageBasePtr) +
                      NTHeaders^.OptionalHeader.SizeOfImage + $10000 - 64;

  Proc^.MainForm   := nil;

  { �sim }
  NamePtr := FileName;
  i := 0;
  while (NamePtr[i] <> #0) and (i < 31) do
  begin
    Proc^.Name[i] := NamePtr[i];
    Inc(i);
  end;

  if Params <> nil then
  begin
    i := 0;
    while (Params[i] <> #0) and (i < 255) do
    begin
      Proc^.CmdLine[i] := Params[i];
      Inc(i);
    end;
  end;

  { Listeye ekle }
  ProcessListAdd(Proc);
  Inc(NextPID);

  { Console ise terminal a� }
  if Proc^.IsConsole then
    Proc^.Console := OpenTerminal(Proc^.Name, Proc^.PID);

  { �� Thread ba�lat � ProcessWrapper ProcessMgr'dan kullan �� }
  Handle := BeginThread(
    @ProcessWrapper,   { ProcessMgr.ProcessWrapper � RunExe �a��r�r }
    Proc,
    Proc^.Name,
    PRIO_HIGH,
    TF_KERNEL
  );

  if Handle = -1 then
  begin
    ProcessKill(Proc);
    FreeMem(NewImageBasePtr);
    HeapFree(Proc);
    Exit;
  end;

  Proc^.ThreadHandle := Handle;
  Proc^.State        := psRunning;
end;

end.

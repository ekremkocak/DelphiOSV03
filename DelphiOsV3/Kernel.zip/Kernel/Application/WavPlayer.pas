unit WavPlayer;
{
  Yeni WAV Oynatici � Toolbar + Panel stili
  * Control alani KULLANILMAZ.
  * Tum handler'lar global WavPlayer1'e erisir.
  * SB16 timeout'lu (donma onlenir).
  * DMA buffer 64KB aligned.
}
interface

uses
  SysUtils, GUI, GUIControls, Ports,Task, Pit,Messages, Memory, Draw32, Fat32, Math;

const
  { DMA tablolari � Sounds.pas'tan }
  DmaChannel: array [0..7, 1..3] of Byte =
    ( ($87, $00, $01), ($83, $02, $03), ($81, $04, $05), ($82, $06, $07),
      ($8F, $C0, $C2), ($8B, $C4, $C6), ($89, $C8, $CA), ($8A, $CC, $CE) );

  DmaPort: array [0..7, 1..3] of Byte =
    ( ($0A, $0B, $0C), ($0A, $0B, $0C), ($0A, $0B, $0C), ($0A, $0B, $0C),
      ($D4, $D6, $D8), ($D4, $D6, $D8), ($D4, $D6, $D8), ($D4, $D6, $D8) );



const
  WP_FACE    = $D4D0C8;
  WP_WAVE_BG = $F0F4FF;
  WP_WAVE_C  = $0050A0;
  WP_HILITE  = $0078D7;
  WP_GRAY    = $808080;
  WP_GREEN   = $008000;
  WP_STOP_C  = $880000;
  WP_TEXT    = $000000;

  WP_STATE_IDLE    = 0;
  WP_STATE_PLAYING = 1;
  WP_STATE_PAUSED  = 2;

  SB_BASE   = $220;
  SB_RESET  = $226;
  SB_READ   = $22A;
  SB_WRITE  = $22C;
  SB_STATUS = $22E;

   WAV_BUF_SIZE = 4096;

type
     TSmallintArray = array[0..MaxInt div SizeOf(Smallint)-1] of Smallint;
   PSmallintArray = ^TSmallintArray;


type
  TWavRIFF = packed record
    ChunkID  : array[0..3] of Char;
    ChunkSize: LongWord;
    Format   : array[0..3] of Char;
  end;

  TWavFmt = packed record
    ChunkID       : array[0..3] of Char;
    ChunkSize     : LongWord;
    AudioFormat   : Word;
    NumChannels   : Word;
    SampleRate    : LongWord;
    ByteRate      : LongWord;
    BlockAlign    : Word;
    BitsPerSample : Word;
  end;

  TWavData = packed record
    ChunkID  : array[0..3] of Char;
    ChunkSize: LongWord;
  end;

  PConvBuf = ^TConvBuf;
  TConvBuf = array[0..WAV_BUF_SIZE-1] of SmallInt;

  PWavPlayer = ^TWavPlayer;

  TWavPlayer = object
  private
   Channels     : Integer;
    SampleRate   : LongWord;
    BitsPerSample: Integer;
    TotalSamples : LongWord;
    DataOffset   : LongWord;
    DataSize     : LongWord;
    FilePath     : array[0..MAX_PATH-1] of Char;
    FileLoaded   : Boolean;

    // Dalga sekli
    WaveBuf      : Pointer;
    WaveBufLen   : Integer;

    // Oynatici durumu
    PlayerState  : Integer;
    CurSample    : LongWord;

    // --- SB16 DMA ---
    SbDmaBuf     : Pointer;    // DMA'ya verilen orijinal veri
    SbDmaSize    : LongWord;   // Aktarilan boyut

    { UI }
    FForm        : PForm;
    ToolBar      : PToolBar;
    WavePanel    : PPanel;
    InfoPanel    : PPanel;
    ProgressPanel: PPanel;
    StatusBar    : PStatusBar;

    { SB16 Low-Level }

    { Yardimci }
    procedure SampleWaveform;
    procedure FormatTime(Samples: LongWord; SRate: LongWord; Buf: PChar);
    procedure FormatHz(Hz: LongWord; Buf: PChar);

  public
    procedure DoPlay;
    procedure DoPause;
    procedure DoStop;
    procedure DoSeekToStart;
    procedure DoSeekToEnd;




    // --- SB16 Low-Level (interruptsiz) ---
    procedure SbReset;
    function  SbReady: Boolean;
    procedure SbWrite(b: Byte);
    function  SbRead: Byte;
    procedure SbSpeaker(on: Boolean);
    procedure SbDmaStart8 (buf: Pointer; len: LongWord; rate: Word);
    procedure SbDmaStart16(buf: Pointer; len: LongWord; rate: Word);
    procedure SbStopDma;

    procedure OnToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
    procedure LoadFile(Path: PChar);
    procedure FreeWav;
    procedure Tick;


  end;

procedure OpenWavPlayer(Path: PChar);


var
  WavPlayer1: TWavPlayer;




implementation



{ ============================================================================
   Sounds.pas'tan alinan CALISAN SB16/DSP kodlari
   ============================================================================ }

procedure TWavPlayer.SbReset;
begin
  WritePortB(SB_RESET, 1);
  Delay(5);
  WritePortB(SB_RESET, 0);
  Delay(5);
  SbRead; // 0xAA beklenir
end;

function TWavPlayer.SbReady: Boolean;
begin
  Result := (ReadPortB(SB_STATUS) and $80) = 0;
end;

procedure TWavPlayer.SbWrite(b: Byte);
begin
  while not SbReady do ;
  WritePortB(SB_WRITE, b);
end;

function TWavPlayer.SbRead: Byte;
begin
  while (ReadPortB(SB_STATUS) and $80) = 0 do ;
  Result := ReadPortB(SB_READ);
end;

procedure TWavPlayer.SbSpeaker(on: Boolean);
begin
  if on then SbWrite($D1) else SbWrite($D3);
end;

procedure TWavPlayer.SbStopDma;
begin
  SbWrite($D0); // halt 8-bit
  SbWrite($D5); // halt 16-bit
  SbSpeaker(False);
end;

// --- 8-bit single-cycle DMA (Channel 1) ---
procedure TWavPlayer.SbDmaStart8(buf: Pointer; len: LongWord; rate: Word);
var
  Addr: LongWord;
  LenWords: Word;
  TimeConst: Byte;
begin
  if len = 0 then Exit;
  if len > $FFFF then len := $FFFF; // DMA 16-bit count limit

  Addr := LongWord(buf);
  LenWords := Word(len - 1);

  SbReset;
  SbSpeaker(True);

  // DMA ch1 mask
  WritePortB($0A, $05);
  // clear flip-flop
  WritePortB($0C, $00);
  // mode: single, increment, write, ch1 = $49
  WritePortB($0B, $49);
  // address
  WritePortB($02, Lo(Addr));
  WritePortB($02, Hi(Addr));
  // page
  WritePortB($83, (Addr shr 16) and $FF);
  // count
  WritePortB($03, Lo(LenWords));
  WritePortB($03, Hi(LenWords));
  // unmask ch1
  WritePortB($0A, $01);

  // time constant
  if rate = 0 then rate := 22050;
  TimeConst := 256 - (1000000 div rate);
  SbWrite($40);
  SbWrite(TimeConst);

  // start 8-bit playback
  SbWrite($14);
  SbWrite(Lo(LenWords));
  SbWrite(Hi(LenWords));
end;

// --- 16-bit single-cycle DMA (Channel 5) ---
procedure TWavPlayer.SbDmaStart16(buf: Pointer; len: LongWord; rate: Word);
var
  Addr: LongWord;
  CountWords: Word;
begin
  if len = 0 then Exit;
  if len > $FFFF then len := $FFFF;

  Addr := LongWord(buf);
  CountWords := (len div 2) - 1;

  SbReset;
  SbSpeaker(True);

  // DMA ch5 mask (16-bit controller)
  WritePortB($D4, $05);
  // clear flip-flop
  WritePortB($D8, $00);
  // mode: single, inc, write, ch5 = $55 (%01010101)
  WritePortB($D6, $55);
  // address (word cinsinden, 16-bit DMA)
  WritePortB($C4, Lo((Addr shr 1) and $FFFF));
  WritePortB($C4, Hi((Addr shr 1) and $FFFF));
  // page
  WritePortB($8B, (Addr shr 16) and $FF);
  // count (words - 1)
  WritePortB($C6, Lo(CountWords));
  WritePortB($C6, Hi(CountWords));
  // unmask ch5
  WritePortB($D4, $01);

  // sample rate
  SbWrite($41);
  SbWrite(Hi(rate));
  SbWrite(Lo(rate));

  // 16-bit signed mono playback
  SbWrite($B0);
  SbWrite($10);
  SbWrite(Lo(CountWords));
  SbWrite(Hi(CountWords));
end;

// ============================================================================
//  OYNATICI KONTROLLERI  (SB16 entegreli)
// ============================================================================
procedure TWavPlayer.DoPlay;
var
  FileHandle: Integer;
begin
  if not FileLoaded then Exit;

  // Onceki calmayi temizle
  if PlayerState <> WP_STATE_IDLE then DoStop;

  // DMA bufferi hazirla (max 64KB tek seferde)
  if SbDmaBuf <> nil then begin FreeMem(SbDmaBuf); SbDmaBuf := nil; end;
  SbDmaSize := DataSize;
  if SbDmaSize > $FF00 then SbDmaSize := $FF00; // DMA limit, tek seferde
  if SbDmaSize = 0 then Exit;

  SbDmaBuf := MemAlloc(SbDmaSize);
  if SbDmaBuf = nil then
  begin
    StatusBarSetText(StatusBar, 0, 'DMA bellek yetersiz');
    Exit;
  end;

  // Dosyadan veriyi DMA bufferina kopyala
  FileHandle := OpenFile(@FilePath[0], FILE_READ);
  if FileHandle < 0 then
  begin
    FreeMem(SbDmaBuf); SbDmaBuf := nil;
    Exit;
  end;
  SeekFile(FileHandle, DataOffset, SEEK_SET);
  ReadFile(FileHandle, SbDmaBuf, Integer(SbDmaSize));
  CloseFile(FileHandle);

  // Ses kartinda cal
  PlayerState := WP_STATE_PLAYING;
  CurSample   := 0;

  if BitsPerSample = 8 then
    SbDmaStart8(SbDmaBuf, SbDmaSize, Word(SampleRate))
  else
    SbDmaStart16(SbDmaBuf, SbDmaSize, Word(SampleRate));

 StatusBarSetText(StatusBar, 0, 'Oynatiliyor...');
end;

procedure TWavPlayer.DoPause;
begin
  if PlayerState = WP_STATE_PLAYING then
  begin
    SbWrite($D0); // halt 8-bit
    SbWrite($D5); // halt 16-bit
    PlayerState := WP_STATE_PAUSED;
  StatusBarSetText(StatusBar, 0, 'Duraklatildi');
  end
  else if PlayerState = WP_STATE_PAUSED then
  begin
    SbWrite($D4); // continue 8-bit
    SbWrite($D6); // continue 16-bit
    PlayerState := WP_STATE_PLAYING;
  StatusBarSetText(StatusBar, 0, 'Oynatiliyor...');
  end;
end;

procedure TWavPlayer.DoStop;
begin
  SbStopDma;
  PlayerState := WP_STATE_IDLE;
  CurSample   := 0;
  StatusBarSetText(StatusBar, 0, 'Durduruldu');
end;




// ============================================================================
//  FORMAT / ZAMAN
// ============================================================================
procedure TWavPlayer.FormatTime(Samples: LongWord; SRate: LongWord; Buf: PChar);
var
  S, M: Integer;
  T: array[0..15] of Char;
begin
  if SRate = 0 then begin StrCopy(Buf, '0:00'); Exit; end;
  S := Integer(Samples div SRate);
  M := S div 60;
  S := S mod 60;
  IntToPChar(M, @T[0]);
  StrCopy(Buf, @T[0]);
  StrAppend(Buf, ':');
  if S < 10 then StrAppend(Buf, '0');
  IntToPChar(S, @T[0]);
  StrAppend(Buf, @T[0]);
end;

procedure TWavPlayer.FormatHz(Hz: LongWord; Buf: PChar);
var
  T: array[0..15] of Char;
begin
  IntToPChar(Hz, @T[0]);
  StrCopy(Buf, @T[0]);
  StrAppend(Buf, ' Hz');
end;

// ============================================================================
//  DALGA SEKLI
// ============================================================================
procedure TWavPlayer.SampleWaveform;
type
  PSmallIntArray = ^TSmallIntArray;
  TSmallIntArray = array[0..1024] of SmallInt;
var
  FileHandle: Integer;
  PanelW: Integer;
  I, J: Integer;
  StepSamples: LongWord;
  Off: LongWord;
  TmpBuf: array[0..63] of Byte;
  S16: SmallInt;
  MaxV, MinV: SmallInt;
  RdBytes: Integer;
  Buf: PSmallIntArray;
  Bps, Ch: Integer;
  TmpStep: LongWord;
begin
  if WaveBuf <> nil then begin FreeMem(WaveBuf); WaveBuf := nil; end;
  if not FileLoaded then Exit;

  PanelW := WavePanel^.Width;
  if PanelW <= 0 then PanelW := 400;
  WaveBufLen := PanelW;
  WaveBuf := MemAlloc(WaveBufLen * 2);
  if WaveBuf = nil then Exit;

  Buf := PSmallIntArray(WaveBuf);
  if WaveBufLen <= 0 then WaveBufLen := 1;
  StepSamples := TotalSamples div LongWord(WaveBufLen);
  if StepSamples < 1 then StepSamples := 1;

  FileHandle := OpenFile(@FilePath[0], FILE_READ);
  if FileHandle < 0 then Exit;

  Bps := BitsPerSample div 8; if Bps < 1 then Bps := 1;
  Ch := Channels; if Ch < 1 then Ch := 1;

  for I := 0 to WaveBufLen - 1 do
  begin
    Off := DataOffset + LongWord(I) * StepSamples * LongWord(Ch) * LongWord(Bps);
    SeekFile(FileHandle, Off, SEEK_SET);
    MaxV := 0; MinV := 0;

    if StepSamples > 8 then TmpStep := 8 else TmpStep := StepSamples;
    RdBytes := Integer(TmpStep) * Ch * Bps;
    if RdBytes > 64 then RdBytes := 64;
    if RdBytes < 1 then RdBytes := 1;

    ReadFile(FileHandle, @TmpBuf[0], RdBytes);

    J := 0;
    while J < RdBytes do
    begin
      if BitsPerSample = 16 then
      begin
        S16 := SmallInt(TmpBuf[J] or (TmpBuf[J+1] shl 8));
        Inc(J, 2);
      end
      else
      begin
        S16 := SmallInt(Integer(TmpBuf[J]) - 128) shl 8;
        Inc(J, 1);
      end;
      if Ch = 2 then Inc(J, Bps);
      if S16 > MaxV then MaxV := S16;
      if S16 < MinV then MinV := S16;
    end;

    Buf^[I] := SmallInt((Integer(MaxV) - Integer(MinV)) div 2);
  end;

  CloseFile(FileHandle);
end;

// ============================================================================
//  DOSYA YUKLEME
// ============================================================================
procedure TWavPlayer.LoadFile(Path: PChar);
var
  FileHandle : Integer;
  RIFF   : TWavRIFF;
  Fmt    : TWavFmt;
  ChunkID: array[0..3] of Char;
  ChunkSz: LongWord;
  Pos    : LongWord;
  Found  : Boolean;
  InfoBuf: array[0..63] of Char;
  I      : Integer;
  Block  : LongWord;
begin
  FreeWav;
  StrCopy(@FilePath[0], Path);

  FileHandle := OpenFile(Path, FILE_READ);
  if FileHandle < 0 then
  begin
   StatusBarSetText(StatusBar, 0, 'Dosya acilamadi');
    Exit;
  end;

  ReadFile(FileHandle, @RIFF, SizeOf(TWavRIFF));
  if (RIFF.ChunkID[0]<>'R') or (RIFF.ChunkID[1]<>'I') or
     (RIFF.ChunkID[2]<>'F') or (RIFF.ChunkID[3]<>'F') then
  begin
    CloseFile(FileHandle);
   StatusBarSetText(StatusBar, 0, 'RIFF degil');
    Exit;
  end;
  if (RIFF.Format[0]<>'W') or (RIFF.Format[1]<>'A') or
     (RIFF.Format[2]<>'V') or (RIFF.Format[3]<>'E') then
  begin
    CloseFile(FileHandle);
   StatusBarSetText(StatusBar, 0, 'WAVE degil');
    Exit;
  end;

  Found := False;
  Pos   := 12;
  SeekFile(FileHandle, Pos, SEEK_SET);

  while Pos < LongWord(FileSize(FileHandle)) - 8 do
  begin
    ReadFile(FileHandle, @ChunkID[0], 4);
    ReadFile(FileHandle, @ChunkSz, 4);

    if (ChunkID[0]='f') and (ChunkID[1]='m') and
       (ChunkID[2]='t') and (ChunkID[3]=' ') then
    begin
      ReadFile(FileHandle, @Fmt.AudioFormat,   2);
      ReadFile(FileHandle, @Fmt.NumChannels,   2);
      ReadFile(FileHandle, @Fmt.SampleRate,    4);
      ReadFile(FileHandle, @Fmt.ByteRate,      4);
      ReadFile(FileHandle, @Fmt.BlockAlign,    2);
      ReadFile(FileHandle, @Fmt.BitsPerSample, 2);
      if ChunkSz > 16 then SeekFile(FileHandle, Pos + 8 + ChunkSz, SEEK_SET);
      Channels      := Fmt.NumChannels;
      SampleRate    := Fmt.SampleRate;
      BitsPerSample := Fmt.BitsPerSample;
    end
    else if (ChunkID[0]='d') and (ChunkID[1]='a') and
            (ChunkID[2]='t') and (ChunkID[3]='a') then
    begin
      DataOffset := Pos + 8;
      DataSize   := ChunkSz;
      Found      := True;
    end;

    Inc(Pos, 8 + ChunkSz);
    if ChunkSz mod 2 <> 0 then Inc(Pos);
    SeekFile(FileHandle, Pos, SEEK_SET);
  end;

  CloseFile(FileHandle);

  if not Found then
  begin
  StatusBarSetText(StatusBar, 0, 'data chunk bulunamadi');
    Exit;
  end;

  if Fmt.AudioFormat <> 1 then
  begin
   StatusBarSetText(StatusBar, 0, 'Sadece PCM desteklenir');
    Exit;
  end;

  Block := LongWord(Channels) * LongWord(BitsPerSample div 8);
  if Block > 0 then
    TotalSamples := DataSize div Block
  else
    TotalSamples := 0;

  FileLoaded   := True;
  PlayerState  := WP_STATE_IDLE;
  CurSample    := 0;

  SampleWaveform;

  StrCopy(@InfoBuf[0], 'Yuklendi: ');
  IntToPChar(BitsPerSample, @InfoBuf[StrLen(@InfoBuf[0])]);
  StrAppend(@InfoBuf[0], '-bit');
 StatusBarSetText(StatusBar, 0, @InfoBuf[0]);
end;


procedure TWavPlayer.FreeWav;
begin
  if WaveBuf <> nil then begin FreeMem(WaveBuf); WaveBuf := nil; end;
  if SbDmaBuf <> nil then begin FreeMem(SbDmaBuf); SbDmaBuf := nil; end;
  FileLoaded   := False;
  TotalSamples := 0;
  DataOffset   := 0;
  DataSize     := 0;
  CurSample    := 0;
  PlayerState  := WP_STATE_IDLE;
end;




procedure TWavPlayer.DoSeekToStart;
begin
  CurSample := 0;
  if PlayerState = WP_STATE_PLAYING then
  begin
    DoStop;
    DoPlay;
  end;
end;

procedure TWavPlayer.DoSeekToEnd;
begin
  if TotalSamples > 0 then CurSample := TotalSamples - 1;
end;

// ============================================================================
//  TICK
// ============================================================================
procedure TWavPlayer.Tick;
var
  FrameSamples: LongWord;
begin
  if PlayerState <> WP_STATE_PLAYING then Exit;
  if SampleRate > 0 then FrameSamples := SampleRate div 60 else FrameSamples := 735;
  Inc(CurSample, FrameSamples);
  if CurSample >= TotalSamples then
  begin
    CurSample := 0;
    PlayerState := WP_STATE_IDLE;
    SbSpeaker(False);
  end;
end;

// ============================================================================
//  CIZIM (Global WavPlayer1 kullanir � HICBIR Control kullanimi yok)
// ============================================================================
procedure DrawWavePanel1(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H, CY, X, AmpPx: Integer;
  Buf: PSmallintArray;
  MaxAmp: Integer;
  PosX: Integer;
  Tmp: LongWord;
begin


  W := Sender^.Width;
  H := Sender^.Height;
  CY := AbsY + H div 2;
  MaxAmp := H div 2 - 4;

  KSunken(AbsX, AbsY, W, H, WP_WAVE_BG);
  KLineH(AbsX + 2, CY, W - 4, $C0C8D8);

  if (not WavPlayer1.FileLoaded) or (WavPlayer1.WaveBuf = nil) then
  begin
    KStrCentered(AbsX, CY - FONT_H div 2, W, 'Dosya yuklenmedi', WP_GRAY);
    Exit;
  end;

  Buf := PSmallintArray(WavPlayer1.WaveBuf);
  Clip_Set(AbsX + 2, AbsY + 2, AbsX + W - 3, AbsY + H - 3);
  for X := 0 to MinI(WavPlayer1.WaveBufLen - 1, W - 5) do
  begin
    AmpPx := Integer(Buf^[X]) * MaxAmp div 32767;
    if AmpPx < 0 then AmpPx := -AmpPx;
    if AmpPx < 1 then AmpPx := 1;
    KLineV(AbsX + 2 + X, CY - AmpPx, AmpPx * 2, WP_WAVE_C);
    KFill(AbsX + 2 + X, CY - 1, 1, 2, $002080);
  end;

  if WavPlayer1.TotalSamples > 0 then
  begin
    if WavPlayer1.TotalSamples >= 256 then
      Tmp := ((WavPlayer1.CurSample shr 8) * LongWord(W - 4)) div (WavPlayer1.TotalSamples shr 8)
    else
      Tmp := (WavPlayer1.CurSample * LongWord(W - 4)) div WavPlayer1.TotalSamples;
    PosX := AbsX + 2 + Integer(Tmp);
    KLineV(PosX, AbsY + 2, H - 4, WP_HILITE);
  end;



  Clip_Clear;
end;

procedure DrawWavePanel(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H, CY, X, AmpPx: Integer;
  Buf: PSmallintArray;
  MaxAmp: Integer;
  PosX: Integer;
  Tmp: LongWord;
begin
  W := Sender^.Width;
  H := Sender^.Height;
  CY := AbsY + H div 2;
  MaxAmp := H div 2 - 4;

  KSunken(AbsX, AbsY, W, H, WP_WAVE_BG);
  KLineH(AbsX + 2, CY, W - 4, $C0C8D8);

  if (not WavPlayer1.FileLoaded) or (WavPlayer1.WaveBuf = nil) then
  begin
    KStrCentered(AbsX, CY - FONT_H div 2, W, 'Dosya yuklenmedi', WP_GRAY);
    Exit;
  end;

  Buf := PSmallintArray(WavPlayer1.WaveBuf);
  Clip_Set(AbsX + 2, AbsY + 2, AbsX + W - 3, AbsY + H - 3);
  for X := 0 to MinI(WavPlayer1.WaveBufLen - 1, W - 5) do
  begin
    AmpPx := Integer(Buf^[X]) * MaxAmp div 32767;
    if AmpPx < 0 then AmpPx := -AmpPx;
    if AmpPx < 1 then AmpPx := 1;
    KLineV(AbsX + 2 + X, CY - AmpPx, AmpPx * 2, WP_WAVE_C);
    KFill(AbsX + 2 + X, CY - 1, 1, 2, $002080);
  end;

  { === OYNATMA POZISYONU (Playhead) === }
  if WavPlayer1.TotalSamples > 0 then
  begin
    { Pozisyonu piksele �evir (0..W-4 aras�) }
    if WavPlayer1.TotalSamples >= 256 then
      Tmp := ((WavPlayer1.CurSample shr 8) * LongWord(W - 4)) div (WavPlayer1.TotalSamples shr 8)
    else
      Tmp := (WavPlayer1.CurSample * LongWord(W - 4)) div WavPlayer1.TotalSamples;

    PosX := AbsX + 2 + Integer(Tmp);
    
    { S�n�rlar� a�mas�n }
    if PosX < AbsX + 2 then PosX := AbsX + 2;
    if PosX > AbsX + W - 3 then PosX := AbsX + W - 3;

    { Arkaya yar� saydam koyu g�lge (kontrast) }
    KLineV(PosX - 1, AbsY + 3, H - 6, $003030);

    { Ana �izgi: parlak sar�, 2 piksel kal�n }
    KLineV(PosX,     AbsY + 2, H - 4, $00FFFF);
    KLineV(PosX + 1, AbsY + 2, H - 4, $00FFFF);

    { �st ok / ba�l�k }
    KLineH(PosX - 3, AbsY + 2, 7, $00FFFF);
    KLineH(PosX - 2, AbsY + 3, 5, $00FFFF);

    { Alt ok / kuyruk }
    KLineH(PosX - 3, AbsY + H - 3, 7, $00FFFF);
    KLineH(PosX - 2, AbsY + H - 4, 5, $00FFFF);
  end;

  Clip_Clear;
end;

procedure DrawInfoPanel(Sender: PObject; AbsX, AbsY: Integer);
var

  W, H, Row: Integer;
  Buf: array[0..63] of Char;
  HzBuf: array[0..31] of Char;
begin


  W := Sender^.Width;
  H := Sender^.Height;

  KFill(AbsX, AbsY, W, H, WP_FACE);
  KRect3D(AbsX, AbsY, W, H, True);

  KGradientH(AbsX + 1, AbsY + 1, W - 2, 18, $0A246A, $1084D0);
  KStrCentered(AbsX, AbsY + 1, W, 'WAV BILGISI', $FFFFFF);

  if not WavPlayer1.FileLoaded then
  begin
    KStrCentered(AbsX, AbsY + H div 2, W, 'Dosya yok', WP_GRAY);
    Exit;
  end;

  Row := AbsY + 24;
  WavPlayer1.FormatHz(WavPlayer1.SampleRate, @HzBuf[0]);
  KStr(AbsX + 6, Row, 'Ornekleme :', WP_GRAY);
  KStr(AbsX + W div 2, Row, @HzBuf[0], WP_TEXT);
  Inc(Row, FONT_H + 4);

  KStr(AbsX + 6, Row, 'Kanal     :', WP_GRAY);
  if WavPlayer1.Channels = 1 then KStr(AbsX + W div 2, Row, 'Mono', WP_TEXT)
  else                     KStr(AbsX + W div 2, Row, 'Stereo', WP_TEXT);
  Inc(Row, FONT_H + 4);

  KStr(AbsX + 6, Row, 'Bit derinl:', WP_GRAY);
  IntToPChar(WavPlayer1.BitsPerSample, @Buf[0]);
  StrAppend(@Buf[0], ' bit');
  KStr(AbsX + W div 2, Row, @Buf[0], WP_TEXT);
  Inc(Row, FONT_H + 4);

  KStr(AbsX + 6, Row, 'Sure      :', WP_GRAY);
  WavPlayer1.FormatTime(WavPlayer1.TotalSamples, WavPlayer1.SampleRate, @Buf[0]);
  KStr(AbsX + W div 2, Row, @Buf[0], WP_TEXT);
  Inc(Row, FONT_H + 4);

  KStr(AbsX + 6, Row, 'Veri boyut:', WP_GRAY);
  IntToPChar(WavPlayer1.DataSize, @Buf[0]);
  StrAppend(@Buf[0], ' B');
  KStr(AbsX + W div 2, Row, @Buf[0], WP_TEXT);
  Inc(Row, FONT_H + 8);

  KLineH(AbsX + 4, Row, W - 8, $808080);
  Inc(Row, 4);

  KStr(AbsX + 6, Row, 'Dosya:', WP_GRAY);
  Inc(Row, FONT_H + 2);
  Clip_Set(AbsX + 4, Row, AbsX + W - 4, Row + FONT_H);
  KStr(AbsX + 6, Row, @WavPlayer1.FilePath[0], WP_GRAY);
  Clip_Clear;
end;

procedure DrawProgressPanel(Sender: PObject; AbsX, AbsY: Integer);
var

  W, H: Integer;
  FillW: Integer;
  CurBuf, TotBuf: array[0..15] of Char;
  Tmp: LongWord;
begin

  W := Sender^.Width;
  H := Sender^.Height;

  KFill(AbsX, AbsY, W, H, WP_FACE);
  KLineH(AbsX, AbsY, W, $FFFFFF);

  WavPlayer1.FormatTime(WavPlayer1.CurSample, WavPlayer1.SampleRate, @CurBuf[0]);
  WavPlayer1.FormatTime(WavPlayer1.TotalSamples, WavPlayer1.SampleRate, @TotBuf[0]);
  KStr(AbsX + 4, AbsY + 3, @CurBuf[0], WP_GRAY);
  KStr(AbsX + W - StrLen(@TotBuf[0]) * FONT_W - 4, AbsY + 3, @TotBuf[0], WP_GRAY);

  KSunken(AbsX + 50, AbsY + 4, W - 100, H - 8, $FFFFFF);
  if WavPlayer1.TotalSamples > 0 then
  begin
    if WavPlayer1.TotalSamples >= 256 then
      Tmp := ((WavPlayer1.CurSample shr 8) * LongWord(W - 102)) div (WavPlayer1.TotalSamples shr 8)
    else
      Tmp := (WavPlayer1.CurSample * LongWord(W - 102)) div WavPlayer1.TotalSamples;
    FillW := Integer(Tmp);
    if FillW > 0 then
      KGradientH(AbsX + 51, AbsY + 5, FillW, H - 10, $0A246A, $0078D7);
  end;

  
end;



// ============================================================================
//  OLAYLAR (Global WavPlayer1 � HICBIR Sender^.Control yok)
// ============================================================================
procedure TWavPlayer.OnToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
begin

  case ButtonIndex of
    0: DoPlay;
    1: DoPause;
    2: DoStop;
    3: DoSeekToStart;
    4: DoSeekToEnd;
  end;
end;

procedure OnProgressMouseDown(Sender: PObject; X, Y: Integer; Btn: Byte);
var
  W, RelX: Integer;
begin
  if Btn <> 1 then Exit;

  W := Sender^.Width;
  RelX := X - 50;
  if RelX < 0 then RelX := 0;
  if RelX > W - 100 then RelX := W - 100;
  if (WavPlayer1.TotalSamples > 0) and (W - 100 > 0) then
    WavPlayer1.CurSample := LongWord(RelX) * WavPlayer1.TotalSamples div LongWord(W - 100);
end;

procedure OnWaveKeyDown(Sender: PObject; Key: Word);

begin

  case Key of
    32: if WavPlayer1.PlayerState = WP_STATE_IDLE then WavPlayer1.DoPlay else WavPlayer1.DoPause;
    27: WavPlayer1.DoStop;
  end;
end;


procedure OnWaveClose(Sender: PObject);
begin
   WavPlayer1.FreeWav;
end;


procedure OnWaveMouseDown(Sender: PObject; X, Y: Integer; Btn: Byte);
var
  W: Integer;
begin
  if Btn <> 1 then Exit;
  if WavPlayer1.TotalSamples = 0 then Exit;
  
  W := Sender^.Width;
  if W <= 4 then Exit;
  
  { X koordinat�n� sample de�erine �evir }
  if X < 2 then X := 2;
  if X > W - 3 then X := W - 3;
  
  WavPlayer1.CurSample := LongWord(X - 2) * WavPlayer1.TotalSamples div LongWord(W - 4);
  
  { E�er �al�yorsa durdurup yeni yerden ba�lat }
  if WavPlayer1.PlayerState = WP_STATE_PLAYING then
  begin
    WavPlayer1.DoStop;
    WavPlayer1.DoPlay;
  end;
end;


// ============================================================================
//  FORM OLUSTURMA
// ============================================================================
procedure OpenWavPlayer(Path: PChar);
var
  InfoW: Integer;
begin

   WavPlayer1.WaveBuf       := nil;
   WavPlayer1.WaveBufLen    := 0;
   WavPlayer1.FileLoaded    := False;
   WavPlayer1.PlayerState   := WP_STATE_IDLE;
   WavPlayer1.CurSample     := 0;
   WavPlayer1.TotalSamples  := 0;
   WavPlayer1.FilePath[0]   := #0;
   WavPlayer1.Channels      := 0;
   WavPlayer1.SampleRate    := 0;
   WavPlayer1.BitsPerSample := 0;
   WavPlayer1.SbDmaBuf      := nil;
   WavPlayer1.SbDmaSize     := 0;

   WavPlayer1.FreeWav;

  WavPlayer1.FForm := CreateForm('WAV Oynatici', 300, 200, 640, 480);
  WavPlayer1.FForm^.BindDestroy(@OnWaveClose);

  InfoW := 200;

    { ToolBar }
  WavPlayer1.ToolBar := CreateToolBar(PObject(WavPlayer1.FForm), 0, 0, 640 - InfoW, 32, alTop);
  WavPlayer1.ToolBar^.ShowCaptions := True;
  WavPlayer1.ToolBar^.Flat := True;
  
  { Butonlar: Oynat, Duraklat, Durdur, |<, >| }
  ToolBarAddButton(WavPlayer1.ToolBar, '> Oynat', 70);
  ToolBarAddButton(WavPlayer1.ToolBar, '|| Duraklat', 80);
  ToolBarAddButton(WavPlayer1.ToolBar, 'Durdur', 60);
  ToolBarAddSeparator(WavPlayer1.ToolBar);
  ToolBarAddButton(WavPlayer1.ToolBar, '|< Basa', 60);
  ToolBarAddButton(WavPlayer1.ToolBar, 'Sona >|', 60);
  
  { OnClick handler'� ata - NOT: GUIControls'ta TToolBarButtonClick of object degilse }
  WavPlayer1.ToolBar^.OnClick :=WavPlayer1.OnToolBarClick;


  WavPlayer1.InfoPanel := CreatePanel(PObject(WavPlayer1.FForm), 0, 0, InfoW, 480, alRight);
  WavPlayer1.InfoPanel^.BindPaint(@DrawInfoPanel);


  WavPlayer1.WavePanel := CreatePanel(PObject(WavPlayer1.FForm), 0, 0, 640 - InfoW, 480 - 32 - 26 - 22, alClient);
  WavPlayer1.WavePanel^.BindPaint(@DrawWavePanel);
  WavPlayer1.WavePanel^.BindKeyDown(@OnWaveKeyDown);
  WavPlayer1.WavePanel^.BindMouseDown(@OnWaveMouseDown);


  WavPlayer1.ProgressPanel := CreatePanel(PObject(WavPlayer1.FForm), 0, 0, 640 - InfoW, 26, alBottom);
  WavPlayer1.ProgressPanel^.BindPaint(@DrawProgressPanel);
  WavPlayer1.ProgressPanel^.BindMouseDown(@OnProgressMouseDown);


  WavPlayer1.StatusBar := CreateStatusBar(PObject(WavPlayer1.FForm), 0, 0, 640, alBottom);

   WavPlayer1.StatusBar.AddPanel('Hazir',250);
   WavPlayer1.StatusBar.AddPanel('Wave Play V0.1',250);
  //StatusBarSetText(WavPlayer1.StatusBar, 0, 'Hazir');


  WavPlayer1.LoadFile(Path);




end;


{ ============================================================================
  Thread icinde calisan WAV oynatici
  ============================================================================ }

end.

unit HexEditor;

interface

uses
  SysUtils, GUI, GUIControls, Memory, Draw32, Fat32, Math;

const
  HEX_BYTES_PER_ROW = 16;
  HEX_ROW_H         = FONT_H + 4;
  HEX_MARGIN        = 6;
  HEX_OFF_W         = 72;
  HEX_BYTE_W        = 24;
  HEX_GAP           = 16;
  HEX_ASCII_W       = HEX_BYTES_PER_ROW * FONT_W;
  HEX_MAX_FILE      = $80000;

  VK_LEFT  = $25; VK_RIGHT = $27; VK_UP    = $26; VK_DOWN  = $28;
  VK_HOME  = $24; VK_END   = $23; VK_PRIOR = $21; VK_NEXT  = $22;

  C_HEX_BG      = $00FFFFFF;
  C_HEX_OFF     = $00808080;
  C_HEX_TXT     = $00000000;
  C_HEX_ASCII   = $00006060;
  C_HEX_SEL     = $00B0D0FF;
  C_HEX_CUR     = $000000FF;
  C_HEX_HDR     = $00E0E8F0;
  C_HEX_HDR_TXT = $00004080;

type
  PHexEditor = ^THexEditor;

  THexEditor = object
  private
    FForm: PForm;
    FHexPanel: PObject;
    FInfoPanel: PObject;
    FSplitter: PSplitter;
    FVScroll: PScrollBar;   // GUIControls'tan hazir scrollbar

    FBuf: Pointer;
    FSize: LongWord;
    FPath: array[0..255] of Char;
    FLoaded: Boolean;

    FCursor: LongWord;
    FSelStart: LongWord;
    FSelEnd: LongWord;
    FNibble: Integer;
    FSelecting: Boolean;

    procedure UpdateScrollbars;
    procedure EnsureCursorVisible;
    procedure ByteToHex2(B: Byte; Buf: PChar);
    procedure LongToHex8(L: LongWord; Buf: PChar);
    function  GetByteAt(Offset: LongWord): Byte;
    function  GetHexClientWidth: Integer;
    function  GetHexClientHeight: Integer;
  public
    procedure LoadFile(const Path: PChar);
    procedure CloseFile;
    procedure PaintHex(Sender: PObject; AbsX, AbsY: Integer);
    procedure PaintInfo(Sender: PObject; AbsX, AbsY: Integer);
    procedure OnMouseDown(Sender: PObject; X, Y: Integer; Btn: Byte);
    procedure OnMouseMove(Sender: PObject; X, Y: Integer; Btn: Byte);
    procedure OnMouseUp(Sender: PObject; X, Y: Integer; Btn: Byte);
    procedure OnKeyDown(Sender: PObject; Key: Word);
    procedure OnToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
  end;

procedure OpenHexEditor(const Path: PChar);

var
  HexEditor1: THexEditor;

implementation

procedure THexEditor.ByteToHex2(B: Byte; Buf: PChar);
const HC: array[0..15] of Char = '0123456789ABCDEF';
begin Buf[0] := HC[B shr 4]; Buf[1] := HC[B and $0F]; Buf[2] := #0; end;

procedure THexEditor.LongToHex8(L: LongWord; Buf: PChar);
const HC: array[0..15] of Char = '0123456789ABCDEF';
var I: Integer;
begin for I := 7 downto 0 do begin Buf[I] := HC[L and $0F]; L := L shr 4; end; Buf[8] := #0; end;

function THexEditor.GetByteAt(Offset: LongWord): Byte;
begin Result := PByte(LongWord(FBuf) + Offset)^; end;

function THexEditor.GetHexClientWidth: Integer;
begin
  Result := FHexPanel^.Width;
  if (FVScroll <> nil) and FVScroll^.Visible then Dec(Result, FVScroll^.Width);
  if Result < 0 then Result := 0;
end;

function THexEditor.GetHexClientHeight: Integer;
begin Result := FHexPanel^.Height; if Result < 0 then Result := 0; end;

procedure THexEditor.UpdateScrollbars;
var
  TotalRows, ContentH, ClientH: Integer;
begin
  if FVScroll = nil then Exit;
  if not FLoaded then
  begin
    FVScroll^.Min := 0; FVScroll^.Max := 0; FVScroll^.Position := 0;
    FVScroll^.Visible := False; Exit;
  end;
  TotalRows := Integer((FSize + HEX_BYTES_PER_ROW - 1) div HEX_BYTES_PER_ROW);
  ClientH := GetHexClientHeight;
  ContentH := TotalRows * HEX_ROW_H + HEX_ROW_H + 4;
  FVScroll^.Min := 0;
  if ContentH > ClientH then
  begin
    FVScroll^.Max := ContentH - ClientH;
    FVScroll^.PageSize := ClientH;
    FVScroll^.Visible := True;
  end
  else
  begin
    FVScroll^.Max := 0; FVScroll^.PageSize := ClientH;
    FVScroll^.Position := 0; FVScroll^.Visible := False;
  end;
end;

procedure THexEditor.EnsureCursorVisible;
var
  Row: LongWord; RowY, ClientH: Integer;
begin
  if not FLoaded then Exit;
  Row := FCursor div HEX_BYTES_PER_ROW;
  RowY := Integer(Row) * HEX_ROW_H + HEX_ROW_H + 4;
  ClientH := GetHexClientHeight;
  if RowY < FVScroll^.Position then FVScroll^.Position := RowY
  else if RowY + HEX_ROW_H > FVScroll^.Position + ClientH then
    FVScroll^.Position := RowY + HEX_ROW_H - ClientH;
  if FVScroll^.Position < 0 then FVScroll^.Position := 0;
  if FVScroll^.Position > FVScroll^.Max then FVScroll^.Position := FVScroll^.Max;
end;

procedure THexEditor.LoadFile(const Path: PChar);
var F: Integer; Sz: Integer;
begin
  CloseFile; StrCopy(@FPath[0], Path);
  F := OpenFile(Path, FILE_READ); if F < 0 then Exit;
  Sz := FileSize(F); if Sz > HEX_MAX_FILE then Sz := HEX_MAX_FILE;
  if Sz <= 0 then begin Fat32.CloseFile(F); Exit; end;
  FBuf := MemAlloc(Sz); if FBuf = nil then begin Fat32.CloseFile(F); Exit; end;
  ReadFile(F, FBuf, Sz); Fat32.CloseFile(F);
  FSize := Sz; FLoaded := True; FCursor := 0;
  FSelStart := 0; FSelEnd := 0; FNibble := 0;
  UpdateScrollbars; EnsureCursorVisible;
end;

procedure THexEditor.CloseFile;
begin
  if FBuf <> nil then begin FreeMem(FBuf); FBuf := nil; end;
  FSize := 0; FLoaded := False; FCursor := 0;
  FSelStart := 0; FSelEnd := 0; FPath[0] := #0;
  UpdateScrollbars;
end;

procedure THexEditor.PaintHex(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H, VPos: Integer;
  RowCount, Row, StartRow, EndRow, RowY: Integer;
  OffX, HexX, AsciiX, I: Integer;
  Off: LongWord;
  Buf: array[0..15] of Char;
  ByteVal: Byte;
  SelStart, SelEnd: LongWord;
  IsSel: Boolean;
  CursRow, CursCol: Integer;
  IsCursor: Boolean;
  AsciiCh: Char;
begin
  W := GetHexClientWidth;
  H := GetHexClientHeight;

  KSunken(AbsX, AbsY, FHexPanel^.Width, FHexPanel^.Height, C_HEX_BG);

  if not FLoaded then
  begin
    KStrCentered(AbsX, AbsY + FHexPanel^.Height div 2, FHexPanel^.Width, 'Dosya yuklenmedi', C_HEX_OFF);
    Exit;
  end;

  Clip_Set(AbsX + 2, AbsY + 2, AbsX + W - 1, AbsY + H - 1);
  VPos := FVScroll^.Position;

  KFill(AbsX + 2, AbsY + 2, W - 4, HEX_ROW_H, C_HEX_HDR);
  KLineH(AbsX + 2, AbsY + 2 + HEX_ROW_H, W - 4, $00A0A0A0);

  OffX := HEX_MARGIN;
  HexX := OffX + HEX_OFF_W;
  AsciiX := HexX + HEX_BYTES_PER_ROW * HEX_BYTE_W + HEX_GAP;

  KStr(AbsX + OffX + 4, AbsY + 4, 'Offset', C_HEX_HDR_TXT);
  for I := 0 to HEX_BYTES_PER_ROW - 1 do
  begin
    ByteToHex2(Byte(I), @Buf[0]);
    KStr(AbsX + HexX + I * HEX_BYTE_W, AbsY + 4, @Buf[0], C_HEX_HDR_TXT);
  end;
  KStr(AbsX + AsciiX, AbsY + 4, '0123456789ABCDEF', C_HEX_HDR_TXT);

  RowCount := Integer((FSize + HEX_BYTES_PER_ROW - 1) div HEX_BYTES_PER_ROW);
  StartRow := VPos div HEX_ROW_H; if StartRow < 0 then StartRow := 0;
  EndRow := (VPos + H) div HEX_ROW_H + 1;
  if EndRow >= RowCount then EndRow := RowCount - 1;

  CursRow := Integer(FCursor div HEX_BYTES_PER_ROW);
  CursCol := Integer(FCursor mod HEX_BYTES_PER_ROW);

  for Row := StartRow to EndRow do
  begin
    RowY := AbsY + 4 + HEX_ROW_H + Row * HEX_ROW_H - VPos;
    if RowY > AbsY + H then Break;
    if RowY + HEX_ROW_H < AbsY then Continue;

    Off := LongWord(Row) * HEX_BYTES_PER_ROW;
    LongToHex8(Off, @Buf[0]);
    KStr(AbsX + OffX + 4, RowY + 2, @Buf[0], C_HEX_OFF);

    for I := 0 to HEX_BYTES_PER_ROW - 1 do
    begin
      if Off + LongWord(I) >= FSize then Break;
      ByteVal := GetByteAt(Off + LongWord(I));
      IsCursor := (Row = CursRow) and (I = CursCol);

      if FSelStart <= FSelEnd then begin SelStart := FSelStart; SelEnd := FSelEnd; end
      else begin SelStart := FSelEnd; SelEnd := FSelStart; end;
      IsSel := (Off + LongWord(I) >= SelStart) and (Off + LongWord(I) <= SelEnd) and (SelStart <> SelEnd);

      if IsSel then KFill(AbsX + HexX + I * HEX_BYTE_W - 1, RowY, HEX_BYTE_W, HEX_ROW_H, C_HEX_SEL);
      if IsCursor then
        if FNibble = 0 then KRect(AbsX + HexX + I * HEX_BYTE_W - 1, RowY, 9, HEX_ROW_H, C_HEX_CUR)
        else KRect(AbsX + HexX + I * HEX_BYTE_W + 7, RowY, 9, HEX_ROW_H, C_HEX_CUR);

      ByteToHex2(ByteVal, @Buf[0]);
      KStr(AbsX + HexX + I * HEX_BYTE_W, RowY + 2, @Buf[0], C_HEX_TXT);

      if ByteVal in [32..126] then AsciiCh := Char(ByteVal) else AsciiCh := '.';
      if IsSel then KFill(AbsX + AsciiX + I * FONT_W, RowY, FONT_W, HEX_ROW_H, C_HEX_SEL);
      if IsCursor then KRect(AbsX + AsciiX + I * FONT_W, RowY, FONT_W, HEX_ROW_H, C_HEX_CUR);
      KStr(AbsX + AsciiX + I * FONT_W, RowY + 2, @AsciiCh, C_HEX_ASCII);
    end;
  end;
  Clip_Clear;
end;


procedure Paint_Hex(Sender: PObject; AbsX, AbsY: Integer);
begin
   HexEditor1.PaintHex(Sender, AbsX, AbsY);
end;



procedure THexEditor.PaintInfo(Sender: PObject; AbsX, AbsY: Integer);
var W, H, Row: Integer; Buf: array[0..31] of Char; B: Byte;
begin
  W := Sender^.Width; H := Sender^.Height;
  KFill(AbsX, AbsY, W, H, clBtnFace); KRect3D(AbsX, AbsY, W, H, True);
  Row := AbsY + 4;
  KStr(AbsX + 4, Row, 'Hex Editor v0.3', $00004080);
  Inc(Row, FONT_H + 6); KLineH(AbsX + 4, Row, W - 8, $808080); Inc(Row, 6);
  if not FLoaded then begin KStr(AbsX + 4, Row, 'Dosya: (yok)', C_HEX_OFF); Exit; end;
  KStr(AbsX + 4, Row, 'Dosya:', C_HEX_OFF); Inc(Row, FONT_H + 2);
  Clip_Set(AbsX + 4, Row, AbsX + W - 4, Row + FONT_H);
  KStr(AbsX + 4, Row, @FPath[0], C_HEX_TXT); Clip_Clear; Inc(Row, FONT_H + 6);
  KStr(AbsX + 4, Row, 'Boyut:', C_HEX_OFF);
  IntToPChar(Integer(FSize), @Buf[0]); StrAppend(@Buf[0], ' B');
  KStr(AbsX + 50, Row, @Buf[0], C_HEX_TXT); Inc(Row, FONT_H + 4);
  KStr(AbsX + 4, Row, 'Imlec:', C_HEX_OFF);
  LongToHex8(FCursor, @Buf[0]); KStr(AbsX + 50, Row, @Buf[0], C_HEX_TXT); Inc(Row, FONT_H + 4);
  if FSize > 0 then
  begin
    B := GetByteAt(FCursor);
    KStr(AbsX + 4, Row, 'Byte:', C_HEX_OFF);
    ByteToHex2(B, @Buf[0]); KStr(AbsX + 50, Row, @Buf[0], C_HEX_TXT); Inc(Row, FONT_H + 4);
    KStr(AbsX + 4, Row, 'Dec:', C_HEX_OFF);
    IntToPChar(Integer(B), @Buf[0]); KStr(AbsX + 50, Row, @Buf[0], C_HEX_TXT); Inc(Row, FONT_H + 4);
    KStr(AbsX + 4, Row, 'Bin:', C_HEX_OFF);
    Buf[0] := Char(Ord('0') + ((B shr 7) and 1)); Buf[1] := Char(Ord('0') + ((B shr 6) and 1));
    Buf[2] := Char(Ord('0') + ((B shr 5) and 1)); Buf[3] := Char(Ord('0') + ((B shr 4) and 1));
    Buf[4] := Char(Ord('0') + ((B shr 3) and 1)); Buf[5] := Char(Ord('0') + ((B shr 2) and 1));
    Buf[6] := Char(Ord('0') + ((B shr 1) and 1)); Buf[7] := Char(Ord('0') + (B and 1)); Buf[8] := #0;
    KStr(AbsX + 50, Row, @Buf[0], C_HEX_TXT);
  end;
end;

procedure Paint_Info(Sender: PObject; AbsX, AbsY: Integer);
begin
  HexEditor1.PaintInfo(Sender, AbsX, AbsY);
end;


procedure THexEditor.OnMouseDown(Sender: PObject; X, Y: Integer; Btn: Byte);
var VPos, Row, Col: Integer; Off: LongWord; HexX: Integer;
begin
  if Btn <> 1 then Exit; if not FLoaded then Exit;
  if (X > GetHexClientWidth) or (Y > GetHexClientHeight) then Exit;
  VPos := FVScroll^.Position;
  if Y < HEX_ROW_H + 4 then Exit;
  Row := (Y + VPos - HEX_ROW_H - 4) div HEX_ROW_H; if Row < 0 then Row := 0;
  HexX := HEX_MARGIN + HEX_OFF_W;
  if (X < HexX) or (X >= HexX + HEX_BYTES_PER_ROW * HEX_BYTE_W) then Exit;
  Col := (X - HexX) div HEX_BYTE_W;
  if Col < 0 then Col := 0; if Col >= HEX_BYTES_PER_ROW then Col := HEX_BYTES_PER_ROW - 1;
  Off := LongWord(Row) * HEX_BYTES_PER_ROW + LongWord(Col);
  if Off >= FSize then begin if FSize = 0 then Exit; Off := FSize - 1; end;
  FCursor := Off; FNibble := 0; FSelStart := Off; FSelEnd := Off; FSelecting := True;
  EnsureCursorVisible;
end;

procedure THexEditor.OnMouseMove(Sender: PObject; X, Y: Integer; Btn: Byte);
var VPos, Row, Col: Integer; Off: LongWord; HexX: Integer;
begin
  if not FSelecting then Exit; if not FLoaded then Exit;
  if (X > GetHexClientWidth) or (Y > GetHexClientHeight) then Exit;
  VPos := FVScroll^.Position;
  Row := (Y + VPos - HEX_ROW_H - 4) div HEX_ROW_H; if Row < 0 then Row := 0;
  HexX := HEX_MARGIN + HEX_OFF_W;
  Col := (X - HexX) div HEX_BYTE_W;
  if Col < 0 then Col := 0; if Col >= HEX_BYTES_PER_ROW then Col := HEX_BYTES_PER_ROW - 1;
  Off := LongWord(Row) * HEX_BYTES_PER_ROW + LongWord(Col);
  if Off >= FSize then Off := FSize - 1;
  FCursor := Off; FSelEnd := Off; EnsureCursorVisible;
end;

procedure THexEditor.OnMouseUp(Sender: PObject; X, Y: Integer; Btn: Byte);
begin FSelecting := False; end;

{
procedure THexEditor.OnKeyDown(Sender: PObject; Key: Word);
var NewCur: LongWord; ByteVal, NibbleVal: Byte;
begin
  if not FLoaded then Exit; NewCur := FCursor;
  case Key of
    VK_LEFT:  if FNibble = 1 then FNibble := 0 else if NewCur > 0 then begin Dec(NewCur); FNibble := 1; end;
    VK_RIGHT: if FNibble = 0 then FNibble := 1 else if NewCur < FSize - 1 then begin Inc(NewCur); FNibble := 0; end;
    VK_UP:    if NewCur >= HEX_BYTES_PER_ROW then Dec(NewCur, HEX_BYTES_PER_ROW);
    VK_DOWN:  if NewCur + HEX_BYTES_PER_ROW < FSize then Inc(NewCur, HEX_BYTES_PER_ROW);
    VK_HOME:  begin NewCur := (NewCur div HEX_BYTES_PER_ROW) * HEX_BYTES_PER_ROW; FNibble := 0; end;
    VK_END:   begin NewCur := (NewCur div HEX_BYTES_PER_ROW) * HEX_BYTES_PER_ROW + HEX_BYTES_PER_ROW - 1;
                if NewCur >= FSize then NewCur := FSize - 1; FNibble := 1; end;
    VK_PRIOR: if NewCur >= LongWord(GetHexClientHeight div HEX_ROW_H * HEX_BYTES_PER_ROW) then
                Dec(NewCur, LongWord(GetHexClientHeight div HEX_ROW_H * HEX_BYTES_PER_ROW)) else NewCur := 0;
    VK_NEXT:  begin Inc(NewCur, LongWord(GetHexClientHeight div HEX_ROW_H * HEX_BYTES_PER_ROW));
                if NewCur >= FSize then NewCur := FSize - 1; end;
  else
    if (Key >= Byte('0')) and (Key <= Byte('9')) then NibbleVal := Key - Byte('0')
    else if (Key >= Byte('A')) and (Key <= Byte('F')) then NibbleVal := 10 + Key - Byte('A')
    else if (Key >= Byte('a')) and (Key <= Byte('f')) then NibbleVal := 10 + Key - Byte('a')
    else Exit;
    ByteVal := GetByteAt(FCursor);
    if FNibble = 0 then begin ByteVal := (ByteVal and $0F) or (NibbleVal shl 4); FNibble := 1; end
    else begin ByteVal := (ByteVal and $F0) or NibbleVal; FNibble := 0; if FCursor < FSize - 1 then Inc(NewCur); end;
    PByte(LongWord(FBuf) + FCursor)^ := ByteVal;
  end;
  if NewCur <> FCursor then begin FCursor := NewCur; FSelStart := FCursor; FSelEnd := FCursor; end;
  EnsureCursorVisible;
end; }


procedure THexEditor.OnKeyDown(Sender: PObject; Key: Word);
var
  NewCur: LongWord;
  ByteVal, NibbleVal: Byte;
begin
  if not FLoaded then Exit;
  NewCur := FCursor;

  // === NAVIGASYON (Virtual Keys, $00-$FF) ===
  if Key = VK_LEFT then
  begin
    if FNibble = 1 then FNibble := 0
    else if NewCur > 0 then begin Dec(NewCur); FNibble := 1; end;
  end
  else if Key = VK_RIGHT then
  begin
    if FNibble = 0 then FNibble := 1
    else if NewCur < FSize - 1 then begin Inc(NewCur); FNibble := 0; end;
  end
  else if Key = VK_UP then
  begin
    if NewCur >= HEX_BYTES_PER_ROW then Dec(NewCur, HEX_BYTES_PER_ROW);
  end
  else if Key = VK_DOWN then
  begin
    if NewCur + HEX_BYTES_PER_ROW < FSize then Inc(NewCur, HEX_BYTES_PER_ROW);
  end
  else if Key = VK_HOME then
  begin
    NewCur := (NewCur div HEX_BYTES_PER_ROW) * HEX_BYTES_PER_ROW;
    FNibble := 0;
  end
  else if Key = VK_END then
  begin
    NewCur := (NewCur div HEX_BYTES_PER_ROW) * HEX_BYTES_PER_ROW + HEX_BYTES_PER_ROW - 1;
    if NewCur >= FSize then NewCur := FSize - 1;
    FNibble := 1;
  end
  else if Key = VK_PRIOR then
  begin
    if NewCur >= LongWord(GetHexClientHeight div HEX_ROW_H * HEX_BYTES_PER_ROW) then
      Dec(NewCur, LongWord(GetHexClientHeight div HEX_ROW_H * HEX_BYTES_PER_ROW))
    else
      NewCur := 0;
  end
  else if Key = VK_NEXT then
  begin
    Inc(NewCur, LongWord(GetHexClientHeight div HEX_ROW_H * HEX_BYTES_PER_ROW));
    if NewCur >= FSize then NewCur := FSize - 1;
  end

  // === HEX DUZENLEME ($100 ofsetli karakterler) ===
  else if (Key >= $100 + Byte('0')) and (Key <= $100 + Byte('9')) then
  begin
    NibbleVal := Key - ($100 + Byte('0'));
    ByteVal := GetByteAt(FCursor);
    if FNibble = 0 then
    begin
      ByteVal := (ByteVal and $0F) or (NibbleVal shl 4);
      FNibble := 1;
    end
    else
    begin
      ByteVal := (ByteVal and $F0) or NibbleVal;
      FNibble := 0;
      if FCursor < FSize - 1 then Inc(NewCur);
    end;
    PByte(LongWord(FBuf) + FCursor)^ := ByteVal;
  end
  else if (Key >= $100 + Byte('A')) and (Key <= $100 + Byte('F')) then
  begin
    NibbleVal := 10 + Key - ($100 + Byte('A'));
    ByteVal := GetByteAt(FCursor);
    if FNibble = 0 then
    begin
      ByteVal := (ByteVal and $0F) or (NibbleVal shl 4);
      FNibble := 1;
    end
    else
    begin
      ByteVal := (ByteVal and $F0) or NibbleVal;
      FNibble := 0;
      if FCursor < FSize - 1 then Inc(NewCur);
    end;
    PByte(LongWord(FBuf) + FCursor)^ := ByteVal;
  end
  else if (Key >= $100 + Byte('a')) and (Key <= $100 + Byte('f')) then
  begin
    NibbleVal := 10 + Key - ($100 + Byte('a'));
    ByteVal := GetByteAt(FCursor);
    if FNibble = 0 then
    begin
      ByteVal := (ByteVal and $0F) or (NibbleVal shl 4);
      FNibble := 1;
    end
    else
    begin
      ByteVal := (ByteVal and $F0) or NibbleVal;
      FNibble := 0;
      if FCursor < FSize - 1 then Inc(NewCur);
    end;
    PByte(LongWord(FBuf) + FCursor)^ := ByteVal;
  end

  else
    Exit;

  if NewCur <> FCursor then
  begin
    FCursor := NewCur;
    FSelStart := FCursor;
    FSelEnd := FCursor;
  end;
  EnsureCursorVisible;
end;

procedure _OnKeyDown(Sender: PObject; Key: Word);
begin
   HexEditor1.OnKeyDown(Sender, Key);
end;




procedure _OnMouseDown(Sender: PObject; X, Y: Integer; Btn: Byte);
begin
   HexEditor1.OnMouseDown(Sender,X, Y, Btn);
end;

procedure _OnMouseMove(Sender: PObject; X, Y: Integer; Btn: Byte);
begin
   HexEditor1.OnMouseMove(Sender,X, Y, Btn);
end;

procedure _OnMouseUp(Sender: PObject; X, Y: Integer; Btn: Byte);
begin
   HexEditor1.OnMouseUp(Sender,X, Y, Btn);
end;

procedure THexEditor.OnToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
begin
  case ButtonIndex of
     1: CloseFile;
  end;
end;

procedure OpenHexEditor(const Path: PChar);
var TB: PToolBar;
begin
  with HexEditor1 do
  begin
    FBuf := nil; FSize := 0; FLoaded := False; FCursor := 0;
    FSelStart := 0; FSelEnd := 0; FNibble := 0; FSelecting := False;
    FPath[0] := #0; FVScroll := nil;

    FForm := CreateForm('Hex Editor', 100, 80, 720, 480);
    FForm^.Color := clBtnFace;

    TB := CreateToolBar(PObject(FForm), 0, 0, 720, 32, alTop);
    TB^.ShowCaptions := True; TB^.Flat := True;
    ToolBarAddButton(TB, 'Ac', 50);
    ToolBarAddButton(TB, 'Kapat', 60);
    ToolBarAddButton(TB, 'Kaydet', 60);
    ToolBarAddSeparator(TB);
    ToolBarAddButton(TB, 'Git...', 60);
    TB^.OnClick := OnToolBarClick;

    FHexPanel := CreatePanel(PObject(FForm), 0, 0, 540, 448, alLeft);
    FHexPanel^.BindPaint(@Paint_Hex);
    FHexPanel^.BindMouseDown(@_OnMouseDown);
    FHexPanel^.BindMouseMove(@_OnMouseMove);
    FHexPanel^.BindMouseUp(@_OnMouseUp);
    FHexPanel^.BindKeyDown(@_OnKeyDown);
    FHexPanel^.CanFocus := True;
    FHexPanel^.TabStop := True;

    // GUIControls'taki hazir ScrollBar (panel icinde, sagda)
    FVScroll := CreateScrollBar(PObject(FHexPanel), 0, 0, 16, 200, alRight);
    FVScroll^.Min := 0; FVScroll^.Max := 0; FVScroll^.Position := 0;

    FSplitter := CreateSplitter(PObject(FForm), 0, 0, 10, False, alLeft);
    FSplitter^.FControl := FHexPanel;

    FInfoPanel := CreatePanel(PObject(FForm), 0, 0, 180, 480, alClient);
    FInfoPanel^.BindPaint(@Paint_Info);

    if (Path <> nil) and (Path[0] <> #0) then LoadFile(Path) else UpdateScrollbars;
  end;
end;

end.

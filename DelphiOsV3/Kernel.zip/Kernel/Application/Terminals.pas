unit Terminals;

interface

uses
  SysUtils, GUI, GUIControls, Memory, Draw32, Fat32, Math, ProcessMgr;

const
  MAX_CMD_HISTORY = 16;
  MAX_CMD_LEN = 256;

type
  PTerminal = ^TTerminal;
  TTerminal = object
  private
    FForm: PForm;
    FMemo: PMemo;
    FStatusBar: PStatusBar;
    FToolBar: PToolBar;
    FCurrentDir: array[0..MAX_PATH-1] of Char;
    FHistory: array[0..MAX_CMD_HISTORY-1] of array[0..MAX_CMD_LEN-1] of Char;
    FHistoryCount: Integer;
    FHistoryIndex: Integer;
    FTextColor: LongWord;
    procedure PrintLn(const Text: PChar);
    procedure PrintPrompt;
    function GetLine(Memo: PMemo; Line: Integer; Buf: PChar; MaxLen: Integer): Integer;
    procedure ExecuteCommand(const CmdLine: PChar);
    procedure ParseCmd(const CmdLine: PChar; var Cmd, Args: PChar);
    procedure AddHistory(const Cmd: PChar);
    // Komutlar
    procedure CmdHelp;
    procedure CmdDir(const Args: PChar);
    procedure CmdCd(const Args: PChar);
    procedure CmdMkDir(const Args: PChar);
    procedure CmdRm(const Args: PChar; IsDir: Boolean);
    procedure CmdCat(const Args: PChar);
    procedure CmdEcho(const Args: PChar);
    procedure CmdPwd;
    procedure CmdCls;
    procedure CmdMem;
    procedure CmdDisk;
    procedure CmdPs;
    procedure CmdKill(const Args: PChar);
    procedure CmdExec(const Args: PChar);
    procedure CmdVer;
    procedure CmdDate;
    procedure CmdColor(const Args: PChar);
  public
    procedure Init;
    procedure DoClose;
    procedure ToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
  end;

procedure OpenTerminal;

procedure TerminalFormDestroy(Sender: PObject);
procedure TerminalMemoKeyDown(Sender: PObject; Key: Word);

var
  Terminal1: TTerminal;

implementation

uses Messages;

{-----------------------------------------------------------------------------}
{ Yardimci }
{-----------------------------------------------------------------------------}
procedure StrTrimLeft(S: PChar);
var
  P: PChar;
begin
  if S = nil then Exit;
  P := S;
  while (P^ = ' ') or (P^ = #9) do Inc(P);
  if P <> S then StrCopy(S, P);
end;

procedure StrUpperInPlace(S: PChar);
var
  P: PChar;
begin
  P := S;
  while P^ <> #0 do
  begin
    if (P^ >= 'a') and (P^ <= 'z') then
      P^ := Char(Ord(P^) - 32);
    Inc(P);
  end;
end;

function StrEqualI(const S1, S2: PChar): Boolean;
var
  P1, P2: PChar;
  C1, C2: Char;
begin
  Result := False;
  if (S1 = nil) or (S2 = nil) then Exit;
  P1 := S1; P2 := S2;
  while True do
  begin
    C1 := P1^; C2 := P2^;
    if (C1 >= 'a') and (C1 <= 'z') then C1 := Char(Ord(C1) - 32);
    if (C2 >= 'a') and (C2 <= 'z') then C2 := Char(Ord(C2) - 32);
    if C1 <> C2 then Exit;
    if C1 = #0 then Break;
    Inc(P1); Inc(P2);
  end;
  Result := True;
end;

{-----------------------------------------------------------------------------}
{ TTerminal }
{-----------------------------------------------------------------------------}
procedure TTerminal.Init;
var
  TB: PToolBar;
begin
  FForm := nil; FMemo := nil; FStatusBar := nil; FToolBar := nil;
  StrCopy(@FCurrentDir[0], 'C:\');
  FHistoryCount := 0;
  FHistoryIndex := 0;
  FTextColor := $0000FF00;

  FForm := CreateForm('Terminal', 100, 80, 700, 500);
  FForm^.Color := $00000000;
  FForm^.BindDestroy(@TerminalFormDestroy);

  { Toolbar }
  TB := CreateToolBar(PObject(FForm), 0, 0, 700, 32, alTop);
  TB^.ShowCaptions := True;
  TB^.Flat := True;
  ToolBarAddButton(TB, 'Temizle', 60);
  ToolBarAddSeparator(TB);
  ToolBarAddButton(TB, 'Kapat', 50);
  TB^.OnClick :=ToolBarClick;
  FToolBar := TB;

  { Memo }
  FMemo := CreateMemo(PObject(FForm), 0, 0, 700, 436, alClient);
  FMemo^.Color := $00000000;
  FMemo^.CanFocus := True;           { <-- EKLENDI }
  FMemo^.TabStop := True;            { <-- EKLENDI }
  FMemo^.BindKeyDown(@TerminalMemoKeyDown);

  { StatusBar }
  FStatusBar := CreateStatusBar(PObject(FForm), 0, 0, 700, alBottom);
  FStatusBar^.AddPanel('Terminal Hazir', 500);

  PrintLn('OS Terminal [Version 1.0]');
  PrintLn('(c) 2026 OS Developer. All rights reserved.');
  PrintLn('');
  PrintLn('Yardim icin HELP yazin.');
  PrintLn('');
  PrintPrompt;
end;

procedure TTerminal.DoClose;
begin
  if FForm <> nil then
    WinManager.RemoveForm(PForm(FForm));
end;

procedure TTerminal.PrintLn(const Text: PChar);
begin
  MemoAddLine(FMemo, Text);
  if FMemo^.LineCount > 200 then
  begin
    MemoClear(FMemo);
    PrintLn('--- Ekran temizlendi ---');
  end;
end;

procedure TTerminal.PrintPrompt;
var
  Prompt: array[0..MAX_PATH+3] of Char;
begin
  Prompt[0] := #0;
  StrAppend(@Prompt[0], @FCurrentDir[0]);
  StrAppend(@Prompt[0], '> ');
  MemoAddLine(FMemo, @Prompt[0]);

  { Caret son satirin sonuna (prompt'tan hemen sonra) }
  FMemo^.CaretY := FMemo^.LineCount - 1;
  FMemo^.CaretX := StrLen(@Prompt[0]);
end;

function TTerminal.GetLine(Memo: PMemo; Line: Integer; Buf: PChar; MaxLen: Integer): Integer;
var
  P: PChar;
  I: Integer;
begin
  Result := 0;
  if (Line < 0) or (Line >= Memo^.LineCount) then Exit;
  P := Memo^.Lines^[Line];
  I := 0;
  while (P[I] <> #0) and (I < MaxLen - 1) do
  begin
    Buf[I] := P[I];
    Inc(I);
  end;
  Buf[I] := #0;
  Result := I;
end;

procedure TTerminal.AddHistory(const Cmd: PChar);
var
  I: Integer;
begin
  if (Cmd = nil) or (Cmd[0] = #0) then Exit;
  if FHistoryCount < MAX_CMD_HISTORY then
  begin
    StrCopy(@FHistory[FHistoryCount][0], Cmd);
    Inc(FHistoryCount);
  end
  else
  begin
    for I := 0 to MAX_CMD_HISTORY - 2 do
      StrCopy(@FHistory[I][0], @FHistory[I+1][0]);
    StrCopy(@FHistory[MAX_CMD_HISTORY-1][0], Cmd);
  end;
  FHistoryIndex := FHistoryCount;
end;

procedure TTerminal.ParseCmd(const CmdLine: PChar; var Cmd, Args: PChar);
var
  P: PChar;
begin
  Cmd := nil;
  Args := nil;
  if CmdLine = nil then Exit;

  P := CmdLine;
  while (P^ = ' ') or (P^ = #9) do Inc(P);

  Cmd := P;
  while (P^ <> #0) and (P^ <> ' ') and (P^ <> #9) do Inc(P);

  if P^ <> #0 then
  begin
    P^ := #0;
    Inc(P);
    while (P^ = ' ') or (P^ = #9) do Inc(P);
  end;

  Args := P;
end;

{-----------------------------------------------------------------------------}
{ KOMUT OKUMA � Duzeltilmis: CaretY tabanli }
{-----------------------------------------------------------------------------}
procedure TTerminal.ExecuteCommand(const CmdLine: PChar);
var
  CmdBuf: array[0..MAX_CMD_LEN-1] of Char;
  ArgsBuf: array[0..MAX_CMD_LEN-1] of Char;
  Cmd, Args: PChar;
begin
  if (CmdLine = nil) or (CmdLine[0] = #0) then Exit;

  StrCopy(@CmdBuf[0], CmdLine);
  ParseCmd(@CmdBuf[0], Cmd, Args);

  if Cmd = nil then Exit;
  StrUpperInPlace(Cmd);

  if StrEqualI(Cmd, 'HELP') or StrEqualI(Cmd, '?') then
    CmdHelp
  else if StrEqualI(Cmd, 'DIR') or StrEqualI(Cmd, 'LS') then
    CmdDir(Args)
  else if StrEqualI(Cmd, 'CD') or StrEqualI(Cmd, 'CHDIR') then
    CmdCd(Args)
  else if StrEqualI(Cmd, 'MKDIR') or StrEqualI(Cmd, 'MD') then
    CmdMkDir(Args)
  else if StrEqualI(Cmd, 'DEL') or StrEqualI(Cmd, 'RM') then
    CmdRm(Args, False)
  else if StrEqualI(Cmd, 'RMDIR') or StrEqualI(Cmd, 'RD') then
    CmdRm(Args, True)
  else if StrEqualI(Cmd, 'TYPE') or StrEqualI(Cmd, 'CAT') then
    CmdCat(Args)
  else if StrEqualI(Cmd, 'ECHO') then
    CmdEcho(Args)
  else if StrEqualI(Cmd, 'PWD') then
    CmdPwd
  else if StrEqualI(Cmd, 'CLS') or StrEqualI(Cmd, 'CLEAR') then
    CmdCls
  else if StrEqualI(Cmd, 'MEM') then
    CmdMem
  else if StrEqualI(Cmd, 'DISK') or StrEqualI(Cmd, 'DF') then
    CmdDisk
  else if StrEqualI(Cmd, 'PS') then
    CmdPs
  else if StrEqualI(Cmd, 'KILL') then
    CmdKill(Args)
  else if StrEqualI(Cmd, 'EXEC') or StrEqualI(Cmd, 'RUN') then
    CmdExec(Args)
  else if StrEqualI(Cmd, 'VER') then
    CmdVer
  else if StrEqualI(Cmd, 'DATE') then
    CmdDate
  else if StrEqualI(Cmd, 'COLOR') then
    CmdColor(Args)
  else if StrEqualI(Cmd, 'EXIT') or StrEqualI(Cmd, 'QUIT') then
    DoClose
  else
  begin
    PrintLn('Bilinmeyen komut. Yardim icin HELP yazin.');
  end;
end;

{-----------------------------------------------------------------------------}
{ Event: Memo KeyDown � TEMEL DUZELTME BURADA }
{-----------------------------------------------------------------------------}
procedure TerminalMemoKeyDown(Sender: PObject; Key: Word);
var
  LastLine: Integer;
  LineBuf: array[0..MAX_CMD_LEN-1] of Char;
  PromptLen: Integer;
  CmdStart: PChar;
  I: Integer;
  P: PChar;
begin
  { === ENTER: Komut calistir === }
  if Key = VK_RETURN then
  begin
    { CaretY = kullanicinin yazdigi satir (henuz yeni satira gecilmedi) }
    LastLine := Terminal1.FMemo^.CaretY;
    if LastLine < 0 then LastLine := 0;
    if LastLine >= Terminal1.FMemo^.LineCount then
      LastLine := Terminal1.FMemo^.LineCount - 1;

    Terminal1.GetLine(Terminal1.FMemo, LastLine, @LineBuf[0], MAX_CMD_LEN);

    { Eger satir bos veya sadece newline ise BIR UST satiri dene }
    if (LineBuf[0] = #0) or (LineBuf[0] = #13) or (LineBuf[0] = #10) then
    begin
      if LastLine > 0 then Dec(LastLine);
      Terminal1.GetLine(Terminal1.FMemo, LastLine, @LineBuf[0], MAX_CMD_LEN);
    end;

    { Prompt'u ayikla: "C:\> " uzunlugu }
    PromptLen := StrLen(@Terminal1.FCurrentDir[0]) + 2;
    if StrLen(@LineBuf[0]) <= PromptLen then
    begin
      { Sadece prompt, bos komut }
      Terminal1.PrintPrompt;
      Exit;
    end;

    { Komut kismi = prompt sonrasi }
    CmdStart := @LineBuf[PromptLen];

    { Calistir }
    Terminal1.AddHistory(CmdStart);
    Terminal1.ExecuteCommand(CmdStart);
    Terminal1.PrintPrompt;
    Exit;
  end;

  { === YUKARI: History geri === }
  if Key = VK_UP then
  begin
    if Terminal1.FHistoryCount = 0 then Exit;
    if Terminal1.FHistoryIndex > 0 then Dec(Terminal1.FHistoryIndex);

    { Mevcut prompt satirini bul }
    LastLine := Terminal1.FMemo^.CaretY;
    if LastLine >= Terminal1.FMemo^.LineCount then
      LastLine := Terminal1.FMemo^.LineCount - 1;

    { Satirin sadece prompt kismini koru }
    LineBuf[0] := #0;
    StrAppend(@LineBuf[0], @Terminal1.FCurrentDir[0]);
    StrAppend(@LineBuf[0], '> ');
    StrAppend(@LineBuf[0], @Terminal1.FHistory[Terminal1.FHistoryIndex][0]);

    { Memo satirini guncelle: eski satiri sil, yeniyi yaz }
    { Basit yontem: caretX'i prompt sonuna getir, gerisini silmeye calis }
    Terminal1.FMemo^.Lines^[LastLine] := @LineBuf[0];
    Terminal1.FMemo^.CaretX := StrLen(@LineBuf[0]);
    Exit;
  end;

  { === ASAGI: History ileri === }
  if Key = VK_DOWN then
  begin
    if Terminal1.FHistoryCount = 0 then Exit;
    if Terminal1.FHistoryIndex < Terminal1.FHistoryCount - 1 then
      Inc(Terminal1.FHistoryIndex);

    LastLine := Terminal1.FMemo^.CaretY;
    if LastLine >= Terminal1.FMemo^.LineCount then
      LastLine := Terminal1.FMemo^.LineCount - 1;

    LineBuf[0] := #0;
    StrAppend(@LineBuf[0], @Terminal1.FCurrentDir[0]);
    StrAppend(@LineBuf[0], '> ');
    StrAppend(@LineBuf[0], @Terminal1.FHistory[Terminal1.FHistoryIndex][0]);

    Terminal1.FMemo^.Lines^[LastLine] := @LineBuf[0];
    Terminal1.FMemo^.CaretX := StrLen(@LineBuf[0]);
    Exit;
  end;

  { === ESC: Iptal === }
  if Key = VK_ESCAPE then
  begin
    Terminal1.PrintLn('^C');
    Terminal1.PrintPrompt;
    Exit;
  end;
end;

{-----------------------------------------------------------------------------}
{ Komut Implementasyonlari }
{-----------------------------------------------------------------------------}
procedure TTerminal.CmdHelp;
begin
  PrintLn('');
  PrintLn('  KOMUT LISTESI:');
  PrintLn('  ---------------------------------------------------');
  PrintLn('  DIR/LS        Dizin listele');
  PrintLn('  CD            Dizin degistir');
  PrintLn('  MKDIR/MD      Yeni dizin olustur');
  PrintLn('  DEL/RM        Dosya sil');
  PrintLn('  RMDIR/RD      Dizin sil');
  PrintLn('  TYPE/CAT      Dosya icerigini goster');
  PrintLn('  ECHO          Metin yazdir');
  PrintLn('  PWD           Mevcut dizin');
  PrintLn('  CLS/CLEAR     Ekrani temizle');
  PrintLn('  MEM           Bellek kullanimi');
  PrintLn('  DISK/DF       Disk bilgisi');
  PrintLn('  PS            Surec listesi');
  PrintLn('  KILL          Surec sonlandir');
  PrintLn('  EXEC/RUN      Program calistir');
  PrintLn('  VER           Versiyon');
  PrintLn('  COLOR         Renk degistir (0-F)');
  PrintLn('  EXIT/QUIT     Terminali kapat');
  PrintLn('  ---------------------------------------------------');
  PrintLn('');
end;

procedure TTerminal.CmdDir(const Args: PChar);
var
  SearchPath: array[0..MAX_PATH-1] of Char;
  FindH: Integer;
  SR: TSearchRec;
  Count: Integer;
  TotalSize: LongWord;
  Buf: array[0..127] of Char;
  DirStr: PChar;
begin
  Count := 0;
  TotalSize := 0;

  SearchPath[0] := #0;
  StrAppend(@SearchPath[0], @FCurrentDir[0]);

  if (Args <> nil) and (Args[0] <> #0) then
  begin
    if (Args[1] = ':') and (Args[2] = '\') then
      StrCopy(@SearchPath[0], Args)
    else
    begin
      StrAppend(@SearchPath[0], Args);
    end;
  end;

  FindH := FindFirst(@SearchPath[0], '*', 0, @SR);
  if FindH < 0 then
  begin
    PrintLn('Dizin bulunamadi veya bos.');
    Exit;
  end;

  PrintLn('');
  PrintLn('  DIR          Boyut          Ad');
  PrintLn('  ------------ -------------- --------------------');

  repeat
    if SR.IsDir then
      DirStr := '<DIR>        '
    else
    begin
      Buf[0] := #0;
      IntToPChar(SR.FileSize, @Buf[0]);
      while StrLen(@Buf[0]) < 14 do
      begin
        Move(Buf[0], Buf[1], StrLen(@Buf[0])+1);
        Buf[0] := ' ';
      end;
      DirStr := @Buf[0];
    end;

    Buf[0] := #0;
    StrAppend(@Buf[0], '  ');
    StrAppend(@Buf[0], DirStr);
    StrAppend(@Buf[0], ' ');
    StrAppend(@Buf[0], @SR.Name[0]);
    PrintLn(@Buf[0]);

    if not SR.IsDir then Inc(TotalSize, SR.FileSize);
    Inc(Count);
  until not FindNext(FindH, @SR);

  FindClose(FindH);

  Buf[0] := #0;
  IntToPChar(Count, @Buf[0]);
  StrAppend(@Buf[0], ' adet    ');
  IntToPChar(TotalSize, @Buf[StrLen(@Buf[0])]);
  StrAppend(@Buf[0], ' bayt');
  PrintLn(@Buf[0]);
  PrintLn('');
end;

procedure TTerminal.CmdCd(const Args: PChar);
var
  NewPath: array[0..MAX_PATH-1] of Char;
  Entry: TDirEntry;
  I: Integer;
begin
  if (Args = nil) or (Args[0] = #0) then
  begin
    PrintLn(@FCurrentDir[0]);
    Exit;
  end;

  if StrEqualI(Args, '..') then
  begin
    NewPath[0] := #0;
    StrAppend(@NewPath[0], @FCurrentDir[0]);
    if StrLen(@NewPath[0]) > 3 then
    begin
      I := StrLen(@NewPath[0]) - 1;
      while (I > 0) and (NewPath[I] <> '\') do Dec(I);
      if I > 0 then NewPath[I+1] := #0;
      if I = 0 then StrCopy(@NewPath[0], 'C:\');
    end;
    StrCopy(@FCurrentDir[0], @NewPath[0]);
    Exit;
  end;

  if StrEqualI(Args, '\') then
  begin
    StrCopy(@FCurrentDir[0], 'C:\');
    Exit;
  end;

  NewPath[0] := #0;
  if (Args[1] = ':') and (Args[2] = '\') then
    StrCopy(@NewPath[0], Args)
  else
  begin
    StrAppend(@NewPath[0], @FCurrentDir[0]);
    if FCurrentDir[StrLen(@FCurrentDir[0])-1] <> '\' then
      StrAppend(@NewPath[0], '\');
    StrAppend(@NewPath[0], Args);
  end;

  if FAT32_ResolvePath(0, @NewPath[0], @Entry) then
  begin
    if (Entry.Attr and ATTR_DIRECTORY) <> 0 then
    begin
      StrCopy(@FCurrentDir[0], @NewPath[0]);
      if FCurrentDir[StrLen(@FCurrentDir[0])-1] <> '\' then
        StrAppend(@FCurrentDir[0], '\');
    end
    else
      PrintLn('Hata: Bu bir dizin degil.');
  end
  else
    PrintLn('Hata: Dizin bulunamadi.');
end;

procedure TTerminal.CmdMkDir(const Args: PChar);
var
  FullPath: array[0..MAX_PATH-1] of Char;
begin
  if (Args = nil) or (Args[0] = #0) then
  begin
    PrintLn('Kullanim: MKDIR <dizin_adi>');
    Exit;
  end;

  FullPath[0] := #0;
  StrAppend(@FullPath[0], @FCurrentDir[0]);
  if FCurrentDir[StrLen(@FCurrentDir[0])-1] <> '\' then
    StrAppend(@FullPath[0], '\');
  StrAppend(@FullPath[0], Args);

  if MakeDir(@FullPath[0]) then
    PrintLn('Dizin olusturuldu.')
  else
    PrintLn('Hata: Dizin olusturulamadi.');
end;

procedure TTerminal.CmdRm(const Args: PChar; IsDir: Boolean);
var
  FullPath: array[0..MAX_PATH-1] of Char;
begin
  if (Args = nil) or (Args[0] = #0) then
  begin
    if IsDir then PrintLn('Kullanim: RMDIR <dizin>')
    else PrintLn('Kullanim: DEL <dosya>');
    Exit;
  end;

  FullPath[0] := #0;
  StrAppend(@FullPath[0], @FCurrentDir[0]);
  if FCurrentDir[StrLen(@FCurrentDir[0])-1] <> '\' then
    StrAppend(@FullPath[0], '\');
  StrAppend(@FullPath[0], Args);

  if IsDir then
    PrintLn('Klasor silme henuz desteklenmiyor.')
  else if DeleteFile(@FullPath[0]) then
    PrintLn('Silindi.')
  else
    PrintLn('Hata: Dosya silinemedi.');
end;

procedure TTerminal.CmdCat(const Args: PChar);
var
  FullPath: array[0..MAX_PATH-1] of Char;
  FHandle: Integer;
  Size: LongWord;
  Buf: PChar;
  BytesRead: LongWord;
  LineBuf: array[0..79] of Char;
  I: Integer;
  P: PChar;
begin
  if (Args = nil) or (Args[0] = #0) then
  begin
    PrintLn('Kullanim: TYPE <dosya>');
    Exit;
  end;

  FullPath[0] := #0;
  StrAppend(@FullPath[0], @FCurrentDir[0]);
  if FCurrentDir[StrLen(@FCurrentDir[0])-1] <> '\' then
    StrAppend(@FullPath[0], '\');
  StrAppend(@FullPath[0], Args);

  FHandle := OpenFile(@FullPath[0], FILE_READ);
  if FHandle < 0 then
  begin
    PrintLn('Hata: Dosya acilamadi.');
    Exit;
  end;

  Size := FileSize(FHandle);
  if Size = 0 then
  begin
    CloseFile(FHandle);
    PrintLn('[Bos dosya]');
    Exit;
  end;

  Buf := PChar(MemAlloc(Size + 1));
  if Buf = nil then
  begin
    CloseFile(FHandle);
    PrintLn('Hata: Bellek yetersiz.');
    Exit;
  end;

  BytesRead := ReadFile(FHandle, Buf, Size);
  CloseFile(FHandle);
  Buf[BytesRead] := #0;

  P := Buf; I := 0;
  while P^ <> #0 do
  begin
    if (P^ = #13) or (P^ = #10) then
    begin
      LineBuf[I] := #0;
      if I > 0 then PrintLn(@LineBuf[0]);
      I := 0;
      if (P^ = #13) and ((P+1)^ = #10) then Inc(P);
    end
    else if I < 79 then
    begin
      LineBuf[I] := P^;
      Inc(I);
    end;
    Inc(P);
  end;
  if I > 0 then begin LineBuf[I] := #0; PrintLn(@LineBuf[0]); end;

  FreeMem(Buf);
end;

procedure TTerminal.CmdEcho(const Args: PChar);
begin
  if (Args = nil) or (Args[0] = #0) then
    PrintLn('')
  else
    PrintLn(Args);
end;

procedure TTerminal.CmdPwd;
begin
  PrintLn(@FCurrentDir[0]);
end;

procedure TTerminal.CmdCls;
begin
  MemoClear(FMemo);
end;

procedure TTerminal.CmdMem;
var
  Buf: array[0..127] of Char;
begin
  PrintLn('');
  PrintLn('  BELLEK DURUMU:');
  PrintLn('  -------------------------------');
  Buf[0] := #0; StrAppend(@Buf[0], '  Toplam: ');
  IntToPChar(GetTotalMemKB, @Buf[StrLen(@Buf[0])]); StrAppend(@Buf[0], ' KB');
  PrintLn(@Buf[0]);
  Buf[0] := #0; StrAppend(@Buf[0], '  Kullanilan: ');
  IntToPChar(GetUsedMemKB, @Buf[StrLen(@Buf[0])]); StrAppend(@Buf[0], ' KB');
  PrintLn(@Buf[0]);
  Buf[0] := #0; StrAppend(@Buf[0], '  Bos: ');
  IntToPChar(GetFreeMemKB, @Buf[StrLen(@Buf[0])]); StrAppend(@Buf[0], ' KB');
  PrintLn(@Buf[0]);
  Buf[0] := #0; StrAppend(@Buf[0], '  Kullanim: %');
  IntToPChar(GetMemoryUsagePercent, @Buf[StrLen(@Buf[0])]);
  PrintLn(@Buf[0]);
  PrintLn('');
end;

{-----------------------------------------------------------------------------}
{ Komut: DISK / DF }
{-----------------------------------------------------------------------------}
procedure TTerminal.CmdDisk;
var
  Info: TDriveSpaceInfo;
  Buf: array[0..127] of Char;
begin
  PrintLn('');
  PrintLn('  DISK BILGISI:');
  PrintLn('  -------------------------------');

  if not FAT32_GetDriveSpace(0, Info) then
  begin
    PrintLn('  Disk bilgisi alinamadi.');
    Exit;
  end;

  Buf[0] := #0;
  StrAppend(@Buf[0], '  Surucu: ');
  Buf[StrLen(@Buf[0])] := Info.DriveLetter;
  Buf[StrLen(@Buf[0])+1] := #0;
  StrAppend(@Buf[0], ':\');
  PrintLn(@Buf[0]);

  Buf[0] := #0;
  StrAppend(@Buf[0], '  Toplam: ');
  IntToPChar(Info.TotalMB, @Buf[StrLen(@Buf[0])]);
  StrAppend(@Buf[0], ' MB');
  PrintLn(@Buf[0]);

  Buf[0] := #0;
  StrAppend(@Buf[0], '  Bos: ');
  IntToPChar(Info.FreeMB, @Buf[StrLen(@Buf[0])]);
  StrAppend(@Buf[0], ' MB');
  PrintLn(@Buf[0]);

  Buf[0] := #0;
  StrAppend(@Buf[0], '  Kullanilan: ');
  IntToPChar(Info.UsedMB, @Buf[StrLen(@Buf[0])]);
  StrAppend(@Buf[0], ' MB');
  PrintLn(@Buf[0]);
  PrintLn('');
end;

{-----------------------------------------------------------------------------}
{ Komut: PS }
{-----------------------------------------------------------------------------}
procedure TTerminal.CmdPs;
begin
  PrintLn('');
  PrintLn('  SUREC LISTESI:');
  PrintLn('  -------------------------------');
  PrintLn('  (Process Manager entegrasyonu gerekiyor)');
  PrintLn('');
end;

{-----------------------------------------------------------------------------}
{ Komut: KILL }
{-----------------------------------------------------------------------------}
procedure TTerminal.CmdKill(const Args: PChar);
begin
  if (Args = nil) or (Args[0] = #0) then
  begin
    PrintLn('Kullanim: KILL <PID>');
    Exit;
  end;
  PrintLn('Surec sonlandirma henuz entegre edilmedi.');
end;

{-----------------------------------------------------------------------------}
{ Komut: EXEC / RUN }
{-----------------------------------------------------------------------------}
procedure TTerminal.CmdExec(const Args: PChar);
var
  FullPath: array[0..MAX_PATH-1] of Char;
  FHandle: Integer;
  Size: LongWord;
  ExeBuf: Pointer;
  Proc: PProcess;
begin
  if (Args = nil) or (Args[0] = #0) then
  begin
    PrintLn('Kullanim: EXEC <program.exe>');
    Exit;
  end;

  FullPath[0] := #0;
  if (Args[1] = ':') and (Args[2] = '\') then
    StrCopy(@FullPath[0], Args)
  else
  begin
    StrAppend(@FullPath[0], @FCurrentDir[0]);
    if FCurrentDir[StrLen(@FCurrentDir[0])-1] <> '\' then
      StrAppend(@FullPath[0], '\');
    StrAppend(@FullPath[0], Args);
  end;

  FHandle := OpenFile(@FullPath[0], FILE_READ);
  if FHandle < 0 then
  begin
    PrintLn('Hata: Program bulunamadi.');
    Exit;
  end;

  Size := FileSize(FHandle);
  ExeBuf := MemAlloc(Size);
  if ExeBuf = nil then
  begin
    CloseFile(FHandle);
    PrintLn('Hata: Bellek yetersiz.');
    Exit;
  end;

  ReadFile(FHandle, ExeBuf, Size);
  CloseFile(FHandle);

  Proc := ProcessCreate(ExeBuf, Size, Args);
  if Proc <> nil then
  begin
    PrintLn('Program baslatildi.');
  end
  else
  begin
    PrintLn('Hata: Program baslatilamadi.');
    FreeMem(ExeBuf);
  end;
end;

{-----------------------------------------------------------------------------}
{ Komut: VER }
{-----------------------------------------------------------------------------}
procedure TTerminal.CmdVer;
begin
  PrintLn('');
  PrintLn('  OS Terminal Version 1.0');
  PrintLn('  Kernel Version 1.0.0 (Build 2026)');
  PrintLn('  FAT32 File System Driver');
  PrintLn('');
end;

{-----------------------------------------------------------------------------}
{ Komut: DATE / TIME }
{-----------------------------------------------------------------------------}
procedure TTerminal.CmdDate;
begin
  PrintLn('Sistem saati: (PIT entegrasyonu gerekiyor)');
end;

{-----------------------------------------------------------------------------}
{ Komut: COLOR }
{-----------------------------------------------------------------------------}
procedure TTerminal.CmdColor(const Args: PChar);
begin
  if (Args = nil) or (Args[0] = #0) then
  begin
    PrintLn('Kullanim: COLOR <0-F>');
    PrintLn('  0=Siyah 1=Mavi 2=Yesil 3=Camgobegi');
    PrintLn('  4=Kirmizi 5=Mor 6=Kahve 7=Beyaz');
    Exit;
  end;

  case Args[0] of
    '0': FTextColor := $00000000;
    '1': FTextColor := $00FF0000;
    '2': FTextColor := $0000FF00;
    '3': FTextColor := $00FFFF00;
    '4': FTextColor := $000000FF;
    '5': FTextColor := $00FF00FF;
    '6': FTextColor := $000088FF;
    '7': FTextColor := $00FFFFFF;
  else
    FTextColor := $0000FF00;
  end;
  PrintLn('Renk degistirildi.');
end;

{-----------------------------------------------------------------------------}
{ Event: Memo KeyDown }
{-----------------------------------------------------------------------------}
procedure TerminalMemoKeyDown1(Sender: PObject; Key: Word);
var
  LastLine: Integer;
  LineBuf: array[0..MAX_CMD_LEN-1] of Char;
  PromptLen: Integer;
  CmdStart: PChar;
  I: Integer;
begin
  { Enter: Komut calistir }
  if Key = VK_RETURN then
  begin
    LastLine := Terminal1.FMemo^.LineCount - 1;
    if LastLine < 0 then Exit;

    Terminal1.GetLine(Terminal1.FMemo, LastLine, @LineBuf[0], MAX_CMD_LEN);

    { Prompt'u ayikla (C:\> ) }
    PromptLen := StrLen(@Terminal1.FCurrentDir[0]) + 2; { "> " }
    if StrLen(@LineBuf[0]) <= PromptLen then
    begin
      Terminal1.PrintPrompt;
      Exit;
    end;

    CmdStart := @LineBuf[PromptLen];

    { Komutu calistir }
    Terminal1.AddHistory(CmdStart);
    Terminal1.ExecuteCommand(CmdStart);
    Terminal1.PrintPrompt;
    Exit;
  end;

  { Yukari: History }
  if Key = VK_UP then
  begin
    if Terminal1.FHistoryCount = 0 then Exit;
    if Terminal1.FHistoryIndex > 0 then
      Dec(Terminal1.FHistoryIndex);

    LastLine := Terminal1.FMemo^.LineCount - 1;
    if LastLine < 0 then Exit;

    { Mevcut satiri prompt + history ile degistir }
    Terminal1.GetLine(Terminal1.FMemo, LastLine, @LineBuf[0], MAX_CMD_LEN);
    LineBuf[StrLen(@Terminal1.FCurrentDir[0]) + 2] := #0;
    StrAppend(@LineBuf[0], @Terminal1.FHistory[Terminal1.FHistoryIndex][0]);

    { Memo satirini guncelle - basit yontem: sil ve yeniden ekle }
    Terminal1.FMemo^.CaretY := LastLine;
    Terminal1.FMemo^.CaretX := 0;
    { Not: Memo satir silme yoksa, caret'i sona goturup ustune yaz }
    Terminal1.FMemo^.CaretX := StrLen(@LineBuf[0]);
    Exit;
  end;

  { Asagi: History }
  if Key = VK_DOWN then
  begin
    if Terminal1.FHistoryCount = 0 then Exit;
    if Terminal1.FHistoryIndex < Terminal1.FHistoryCount - 1 then
      Inc(Terminal1.FHistoryIndex);

    LastLine := Terminal1.FMemo^.LineCount - 1;
    if LastLine < 0 then Exit;

    Terminal1.GetLine(Terminal1.FMemo, LastLine, @LineBuf[0], MAX_CMD_LEN);
    LineBuf[StrLen(@Terminal1.FCurrentDir[0]) + 2] := #0;
    StrAppend(@LineBuf[0], @Terminal1.FHistory[Terminal1.FHistoryIndex][0]);
    Terminal1.FMemo^.CaretX := StrLen(@LineBuf[0]);
    Exit;
  end;

  { ESC: Satir iptal, yeni prompt }
  if Key = VK_ESCAPE then
  begin
    Terminal1.PrintLn('^C');
    Terminal1.PrintPrompt;
    Exit;
  end;

  { Tab: Otomatik tamamlama (basit) }
  if Key = VK_TAB then
  begin
    { Gelecek versiyonlarda eklenebilir }
    Exit;
  end;
end;

{-----------------------------------------------------------------------------}
{ Event: Toolbar Click }
{-----------------------------------------------------------------------------}
procedure TTerminal.ToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
begin
  case ButtonIndex of
    0: Terminal1.CmdCls;      { Temizle }
    2: Terminal1.DoClose;     { Kapat (ayirac sonrasi) }
  end;
end;

{-----------------------------------------------------------------------------}
{ Event: Form Destroy }
{-----------------------------------------------------------------------------}
procedure TerminalFormDestroy(Sender: PObject);
begin
  Terminal1.FForm := nil;
  Terminal1.FMemo := nil;
  Terminal1.FStatusBar := nil;
  Terminal1.FToolBar := nil;
end;

{-----------------------------------------------------------------------------}
{ Fabrika }
{-----------------------------------------------------------------------------}
procedure OpenTerminal;
begin
  Terminal1.Init;
end;

end.

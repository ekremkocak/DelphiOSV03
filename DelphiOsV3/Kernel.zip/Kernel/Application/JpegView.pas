{ =========================================================
  JpegView.pas � JPEG Image Viewer (Kernel) - FIXED
  
  �zellikler:
  - JPEG Baseline DCT decoding
  - Zoom + Scroll (ImageView gibi)
  - YCbCr to RGB conversion
  - Progressive display
  ========================================================= }

unit JpegView;

interface

uses
  SysUtils, Memory, Draw32, Vesa, GUI, Math, GUIControls, Fat32, Messages,
  JPEGDecoder, ImageView; 


implementation



end.


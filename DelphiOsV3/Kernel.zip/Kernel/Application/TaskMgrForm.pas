unit TaskMgrForm;

interface

uses
  SysUtils, Memory, Draw32, Fat32,Vesa, GUI,ProcessMgr, GUIControls, Messages;


function  CreateProcessListForm: Boolean;
procedure ProcessListRefresh(Form: PForm);

implementation

const
  { --- Yerlesim sabitleri (DirectoryView.pas / Messages.pas ile tutarli) --- }
  PL_TOOLBAR_H = 34;
  PL_STATUS_H  = 34;
  PL_MARGIN    = 10;
  PL_BTN_W     = 100;
  PL_BTN_H     = 24;
  PL_BTN_GAP   = 8;

  { -----------------------------------------------------------------------
    VARSAYIM / DOGRULANMADI:
    GUIControls'daki ListView gorunum-modu sabitleri elimde yok. Bildigim
    tek referans DirectoryView.pas'taki yorum: "1 = Icon mode". Rapor
    (sutunlu/detay) modu icin en olasi deger asagida VS_REPORT olarak
    tanimlandi. Eger goruntu Icon/List modunda acilirsa, TEK YAPMANIZ
    GEREKEN bu sabiti (0, 2 veya 3) deneyerek dogru degeri bulmak.
    Ayni sekilde ListViewAddColumn da dogrulanmamis bir fonksiyondur -
    boyle bir fonksiyon yoksa asagidaki PLCreateColumns cagrisini silmeniz
    yeterli; satirlar zaten tek bir bicimlendirilmis metin (PadAppend ile
    hizalanmis) olarak eklendigi icin sutun basliklari olmasa da veriler
    dogru ve okunakli gorunmeye devam eder.
    ----------------------------------------------------------------------- }
  VS_REPORT = 2;

  COL_PID_W   = 6;    { karakter genisligi (PadAppend icin) }
  COL_NAME_W  = 22;
  COL_STATE_W = 14;
  COL_MEM_W   = 12;

type
  PProcessListData = ^TProcessListData;
  TProcessListData = record
    LV          : PListView;
    MyTimer     : PTimer;
    BtnRefresh  : PButton;
    BtnKill     : PButton;
    LblCount    : PLabel;
    LblSelected : PLabel;
    SelectedPID : Integer;
    { LV^.Items sadece goruntulenen METNI tutar; satirin gercek PID'ini
      geri cikarabilmek icin ayni sirada PID'leri burada saklıyoruz. }
    RowPID      : array[0..MAX_PROCESS-1] of Integer;
    RowCount    : Integer;
  end;

{=============================================================================}
{ Kucuk yardimcilar                                                          }
{=============================================================================}

{ Src'yi Dest'in sonuna ekler, ardindan Width'e tamamlanana kadar bosluk
  ekler - boylece tek satirlik metin sutunlar halinde hizali gorunur
  (sabit genislikli sistem fontu varsayimiyla). }
procedure PadAppend(Dest: PChar; const Src: PChar; Width: Integer);
var
  L, i: Integer;
begin
  StrAppend(Dest, Src);
  L := StrLen(Src);
  i := L;
  while i < Width do
  begin
    StrAppend(Dest, ' ');
    Inc(i);
  end;
end;

function StateName(S: TProcessState): PChar;
begin
  case S of
    psEmpty:   Result := 'Bos';
    psLoading: Result := 'Yukleniyor';
    psRunning: Result := 'Calisiyor';
    psZombie:  Result := 'Zombi';
  else
    Result := 'Bilinmiyor';
  end;
end;

procedure FormatMemSize(Bytes: LongWord; Buf: PChar);
begin
  if Bytes < 1024 then
    StrCopy(Buf, '< 1 KB')
  else if Bytes < 1024 * 1024 then
  begin
    IntToPChar(Bytes div 1024, Buf);
    StrAppend(Buf, ' KB');
  end
  else
  begin
    IntToPChar(Bytes div (1024 * 1024), Buf);
    StrAppend(Buf, ' MB');
  end;
end;

{=============================================================================}
{ Gorsel (DirectoryView.pas / Messages.pas ile ayni stil)                    }
{=============================================================================}

procedure PLToolbarDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;
  KGradientV(AbsX, AbsY, W, H, $00F0EEE4, $00C8C4B8);
  KLineH(AbsX, AbsY, W, $00FCFCF8);
  KLineH(AbsX, AbsY + H - 1, W, cl3DShadow);
end;

{ Arac cubugundaki "Toplam Islem: N" gomulu (sunken) bilgi kutusu }
procedure PLCountBarDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;
  KFill(AbsX, AbsY, W, H, clWhite);
  KRect3D(AbsX, AbsY, W, H, False);
end;

procedure PLStatusDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;
  KFill(AbsX, AbsY, W, H, clBtnFace);
  KLineH(AbsX, AbsY, W, clWhite);
  KLineH(AbsX, AbsY + 1, W, cl3DShadow);
end;

{=============================================================================}
{ Sutun basliklari (VARSAYIM - bkz. yukaridaki VS_REPORT notu)               }
{=============================================================================}

procedure PLCreateColumns(LV: PListView);
begin
  { GUIControls'da ListViewAddColumn dogrulanamadi. Boyle bir fonksiyon
    yoksa bu prosedurun govdesini silin / cagrisini kaldirin - veri
    satirlari yine de PadAppend ile hizalanmis tek metin olarak dogru
    gorunmeye devam eder. }
  ListViewAddColumn(LV, 'PID',    50);
  ListViewAddColumn(LV, 'Ad',     170);
  ListViewAddColumn(LV, 'Durum',  100);
  ListViewAddColumn(LV, 'Bellek', 90);
  ListViewAddColumn(LV, 'Thread', 70);
end;

{=============================================================================}
{ Listeyi doldurma                                                           }
{=============================================================================}

procedure ProcessListRefresh(Form: PForm);
var
  Data: PProcessListData;
  P: PProcess;
  line: array[0..255] of Char;
  numBuf: array[0..15] of Char;
  memBuf: array[0..31] of Char;
  cntBuf: array[0..47] of Char;
  idx: Integer;
begin
  if Form = nil then Exit;
  Data := PProcessListData(Form^.Control);
  if Data = nil then Exit;

  ListViewClear(Data^.LV);
  Data^.RowCount := 0;

  idx := 0;
  P := ProcessListHead;
  while (P <> nil) and (idx < MAX_PROCESS) do
  begin
    line[0] := #0;

    IntToPChar(P^.PID, @numBuf[0]);
    PadAppend(@line[0], @numBuf[0], COL_PID_W);

    PadAppend(@line[0], @P^.Name[0], COL_NAME_W);

    PadAppend(@line[0], StateName(P^.State), COL_STATE_W);

    FormatMemSize(P^.ImageSize, @memBuf[0]);
    PadAppend(@line[0], @memBuf[0], COL_MEM_W);

    IntToPChar(P^.ThreadHandle, @numBuf[0]);
    StrAppend(@line[0], @numBuf[0]);

    ListViewAddItem(Data^.LV, @line[0]);

    Data^.RowPID[idx] := P^.PID;
    Inc(idx);
    Inc(Data^.RowCount);

    P := P^.Next;
  end;

  { Toplam sayac }
  if Data^.LblCount <> nil then
  begin
    cntBuf[0] := #0;
    StrAppend(@cntBuf[0], 'Toplam Islem: ');
    IntToPChar(ProcessCount, @numBuf[0]);
    StrAppend(@cntBuf[0], @numBuf[0]);
    Data^.LblCount^.Caption[0] := #0;
    StrAppend(@Data^.LblCount^.Caption[0], @cntBuf[0]);
  end;

  { Secili process artik listede yoksa (bu arada sonlandiysa) secimi temizle }
  if (Data^.SelectedPID <> 0) and (ProcessFindByPID(Data^.SelectedPID) = nil) then
  begin
    Data^.SelectedPID := 0;
    if Data^.LblSelected <> nil then
      StrCopy(@Data^.LblSelected^.Caption[0], 'Secili: -');
    if Data^.BtnKill <> nil then
      Data^.BtnKill^.Enabled := False;
  end;

  RelayoutForm(Form);
end;

{=============================================================================}
{ Secim yardimcisi                                                            }
{=============================================================================}

function PLResolveSelectedPID(Data: PProcessListData): Integer;
var
  Sel: Integer;
begin
  Result := 0;
  if Data = nil then Exit;
  if Data^.LV = nil then Exit;

  Sel := Data^.LV^.ItemIndex;
  if (Sel < 0) or (Sel >= Data^.RowCount) then Exit;

  Result := Data^.RowPID[Sel];
end;

procedure PLUpdateSelectionLabel(F: PForm; Data: PProcessListData);
var
  P: PProcess;
  buf: array[0..96] of Char;
  numBuf: array[0..15] of Char;
begin
  if Data = nil then Exit;
  if Data^.LblSelected = nil then Exit;

  if Data^.SelectedPID = 0 then
  begin
    StrCopy(@Data^.LblSelected^.Caption[0], 'Secili: -');
    if Data^.BtnKill <> nil then Data^.BtnKill^.Enabled := False;
    Exit;
  end;

  P := ProcessFindByPID(Data^.SelectedPID);

  buf[0] := #0;
  StrAppend(@buf[0], 'Secili: PID ');
  IntToPChar(Data^.SelectedPID, @numBuf[0]);
  StrAppend(@buf[0], @numBuf[0]);
  if P <> nil then
  begin
    StrAppend(@buf[0], '  -  ');
    StrAppend(@buf[0], @P^.Name[0]);
    StrAppend(@buf[0], '  (');
    StrAppend(@buf[0], StateName(P^.State));
    StrAppend(@buf[0], ')');
  end;

  Data^.LblSelected^.Caption[0] := #0;
  StrAppend(@Data^.LblSelected^.Caption[0], @buf[0]);

  if Data^.BtnKill <> nil then
    Data^.BtnKill^.Enabled := (P <> nil);
end;

{=============================================================================}
{ ListView olaylari                                                          }
{=============================================================================}

procedure PLListClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PProcessListData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PProcessListData(F^.Control);
  if Data = nil then Exit;

  Data^.SelectedPID := PLResolveSelectedPID(Data);
  PLUpdateSelectionLabel(F, Data);
end;

{ Cift tiklama: secili process'i (dogrulama sorarak) hemen sonlandirir -
  DirectoryView/OpenDlg'deki "cift tik = eylem" alaligkanligiyla tutarli }
procedure PLListDblClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PProcessListData;
  P: PProcess;
  msg: array[0..160] of Char;
  numBuf: array[0..15] of Char;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PProcessListData(F^.Control);
  if Data = nil then Exit;

  Data^.SelectedPID := PLResolveSelectedPID(Data);
  PLUpdateSelectionLabel(F, Data);

  if Data^.SelectedPID = 0 then Exit;
  P := ProcessFindByPID(Data^.SelectedPID);
  if P = nil then Exit;

  msg[0] := #0;
  StrAppend(@msg[0], '"');
  StrAppend(@msg[0], @P^.Name[0]);
  StrAppend(@msg[0], '" (PID ');
  IntToPChar(Data^.SelectedPID, @numBuf[0]);
  StrAppend(@msg[0], @numBuf[0]);
  StrAppend(@msg[0], ') sonlandirilsin mi?');

 // if MessageDlg(@msg[0], mtConfirmation, [mbYes, mbNo]) = mrYes then
  begin
    ProcessKillByPID(Data^.SelectedPID);
    Data^.SelectedPID := 0;
    ProcessListRefresh(F);
  end;
end;

{=============================================================================}
{ Buton olaylari                                                             }
{=============================================================================}

procedure PLRefreshClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  ProcessListRefresh(F);
end;

procedure PLKillClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PProcessListData;
  P: PProcess;
  msg: array[0..160] of Char;
  numBuf: array[0..15] of Char;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PProcessListData(F^.Control);
  if Data = nil then Exit;
  if Data^.SelectedPID = 0 then Exit;

  P := ProcessFindByPID(Data^.SelectedPID);
  if P = nil then Exit;

  msg[0] := #0;
  StrAppend(@msg[0], '"');
  StrAppend(@msg[0], @P^.Name[0]);
  StrAppend(@msg[0], '" (PID ');
  IntToPChar(Data^.SelectedPID, @numBuf[0]);
  StrAppend(@msg[0], @numBuf[0]);
  StrAppend(@msg[0], ') sonlandirilsin mi? Bu islem geri alinamaz.');

 // if MessageDlg(@msg[0], mtConfirmation, [mbYes, mbNo]) = mrYes then
  begin
    ProcessKillByPID(Data^.SelectedPID);
    Data^.SelectedPID := 0;
    ProcessListRefresh(F);
  end;
end;

{=============================================================================}
{ Bellek temizligi                                                            }
{=============================================================================}

procedure ProcessListFormDestroy(Sender: PObject);
var
  F: PForm;
  Data: PProcessListData;
begin
  F := PForm(Sender);
  if F = nil then Exit;

  Data := PProcessListData(F^.Control);
  if Data <> nil then
  begin
    FreeMem(Data);
    F^.Control := nil;
  end;
end;


procedure TimerBlink(Sender: PObject);
var
  F: PForm;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  ProcessListRefresh(F);
end;

{=============================================================================}
{ Ana Fonksiyon: Process List formu olusturma                                }
{=============================================================================}

function CreateProcessListForm: Boolean;
var
  F: PForm;
  Data: PProcessListData;
  Toolbar, CountBar, StatusBar: PPanel;
  LV: PListView;
  Btn: PButton;
  bx, by: Integer;
begin
  Result := False;

  F := CreateForm('Islem Yoneticisi', 260, 160, 640, 420);
  if F = nil then Exit;
  F^.BorderStyle := bsWindow;
  F^.ShowSysButtons := True;
  F^.Color := clBtnFace;
  F^.BindDestroy(@ProcessListFormDestroy);

  { --- Data blogu --- }
  Data := PProcessListData(MemAlloc(SizeOf(TProcessListData)));
  FillChar(Data^, SizeOf(TProcessListData), #0);
  Data^.SelectedPID := 0;
  Data^.RowCount := 0;

  F^.Control := PObject(Data);

  { --- Toolbar (alTop): Yenile / Sonlandir + toplam sayac --- }
  Toolbar := CreatePanel(PObject(F), 0, 0, 0, PL_TOOLBAR_H, alTop);
  Toolbar^.Color := $00D4D0C8;
  Toolbar^.BorderWidth := 0;
  Toolbar^.ShowCaption := False;
  Toolbar^.BindPaint(@PLToolbarDraw);

  by := (PL_TOOLBAR_H - PL_BTN_H) div 2;
  bx := PL_MARGIN;

  Btn := CreateButton(PObject(Toolbar), 'Yenile', bx, by, PL_BTN_W, PL_BTN_H, alNone);
  Btn^.BindMouseUp(@PLRefreshClick);
  Data^.BtnRefresh := Btn;
  Inc(bx, PL_BTN_W + PL_BTN_GAP);

  Btn := CreateButton(PObject(Toolbar), 'Sonlandir', bx, by, PL_BTN_W, PL_BTN_H, alNone);
  Btn^.BindMouseUp(@PLKillClick);
  Btn^.Enabled := False;   { hicbir sey secili degilken pasif baslar }
  Data^.BtnKill := Btn;
  Inc(bx, PL_BTN_W + PL_BTN_GAP + 10);

  { Toplam islem sayaci: gomulu kutu, kalan tum genisligi kaplar }
  CountBar := CreatePanel(PObject(Toolbar), bx, (PL_TOOLBAR_H - 22) div 2,
                          Toolbar^.Width - bx - PL_MARGIN, 22, alNone);
  CountBar^.BorderWidth := 0;
  CountBar^.ShowCaption := False;
  CountBar^.BindPaint(@PLCountBarDraw);

  Data^.LblCount := CreateLabel(PObject(CountBar), 'Toplam Islem: 0', 8, 3,
                                CountBar^.Width - 16, 16, alNone);
  Data^.LblCount^.Transparent := True;

  { --- ListView (alClient) - REPORT / detay modu --- }
  LV := CreateListView(PObject(F), 0, 0, 0, 0, alClient);
  ListViewSetViewStyle(LV, VS_REPORT);
  LV^.GridLines := True;
  LV^.BorderWidth := 1;
  LV^.BorderColor := cl3DDkShadow;
  Data^.LV := LV;

  PLCreateColumns(LV);

  LV^.BindMouseDown(@PLListClick);
  LV^.BindDblClick(@PLListDblClick);

  { --- Alt durum cubugu: secili process bilgisi --- }
  StatusBar := CreatePanel(PObject(F), 0, 0, 0, PL_STATUS_H, alBottom);
  StatusBar^.Color := clBtnFace;
  StatusBar^.BorderWidth := 0;
  StatusBar^.ShowCaption := False;
  StatusBar^.BindPaint(@PLStatusDraw);

  Data^.LblSelected := CreateLabel(PObject(StatusBar), 'Secili: -',
                       PL_MARGIN, (PL_STATUS_H - FONT_H) div 2,
                       StatusBar^.Width - 2 * PL_MARGIN, 20, alNone);
  Data^.LblSelected^.Transparent := True;


  Data^.MyTimer := CreateTimer(PObject(F), 500);  // 500 ms
  Data^.MyTimer^.OnTimer := @TimerBlink;
  Data^.MyTimer^.Enabled := True;

  { Ilk listeyi doldur }
  ProcessListRefresh(F);

  Result := True;
end;

end.

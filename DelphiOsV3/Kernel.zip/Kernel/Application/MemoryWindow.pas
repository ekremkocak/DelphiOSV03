unit MemoryWindow;
{
  Bellek Durum Penceresi � Modern Dark Dashboard
  Yeni TForm t�retme yap�s�na uygun (TypeSize + InitForm + Method Pointer)
  G�sterim: Byte (birincil) + MB (ikincil)
}
interface

uses SysUtils, GUI, Draw32, Fat32, Memory, Vesa, Math;

const
  GRAPH_HISTORY_SIZE = 60;

  MC_BG       = $0D1B2A;
  MC_CARD     = $1B2A3C;
  MC_CARD2    = $162232;
  MC_BORDER   = $2E4057;
  MC_BORDER2  = $1F3347;
  MC_ACCENT   = $4DA6FF;
  MC_ACCENT2  = $1A6EBE;
  MC_GREEN    = $2ECC71;
  MC_GREEN2   = $1A7A43;
  MC_ORANGE   = $F39C12;
  MC_ORANGE2  = $A06010;
  MC_RED      = $E74C3C;
  MC_RED2     = $8B1A10;
  MC_WHITE    = $ECF0F1;
  MC_SILVER   = $95A5A6;
  MC_DARK     = $4A5568;
  MC_GRAPHBG  = $080E18;
  MC_GRID     = $162030;
  MC_LINEHIGH = $60FFD0;

type
  PMemoryForm = ^TMemoryForm;
  TMemoryForm = object
  private
    FForm         : PForm;
    FHistory      : array[0..GRAPH_HISTORY_SIZE - 1] of Byte;
    FTotalMB      : LongWord;
    FUsedMB       : LongWord;
    FFreeMB       : LongWord;
    FTotalBytes   : LongWord;
    FUsedBytes    : LongWord;
    FFreeBytes    : LongWord;
    FPercent      : Integer;

    function  UsageColor: LongWord;
    function  UsageColorDark: LongWord;
    function  UsageColorForVal(Val: Byte): LongWord;

    procedure FormatMB(MB: LongWord; Buf: PChar);
    procedure FormatBytes(Bytes: LongWord; Buf: PChar);
    procedure FormatPct(Pct: Integer; Buf: PChar);

    procedure DrawRAMIcon    (X, Y: Integer);
    procedure DrawMemoryInfo (X, Y, W, OX: Integer);
    procedure DrawStatCard   (X, Y, W, H: Integer;
                              ALabel, AValueMB, AValueBytes: PChar;
                              AColor, ADarkColor: LongWord);
    procedure DrawUsageBar   (X, Y, W, H: Integer);
    procedure DrawRingGauge  (X, Y, Size: Integer);
    procedure DrawMemGraph   (X, Y, W, H: Integer);
    procedure DrawSeparator  (X, Y, W: Integer);
    procedure DrawFooter     (X, Y, W: Integer);
  public
    procedure InitMemoryForm;
    procedure UpdateStats;
    procedure Draw(Sender: PObject; OX, OY: Integer);
  end;

var
  MemForm: TMemoryForm;

  procedure OpenMemoryForm();

implementation

// =============================================================================
// RENK & FORMAT YARDIMCILARI
// =============================================================================

function TMemoryForm.UsageColor: LongWord;
begin
  if FPercent >= 80 then Result := MC_RED
  else if FPercent >= 60 then Result := MC_ORANGE
  else Result := MC_GREEN;
end;

function TMemoryForm.UsageColorDark: LongWord;
begin
  if FPercent >= 80 then Result := MC_RED2
  else if FPercent >= 60 then Result := MC_ORANGE2
  else Result := MC_GREEN2;
end;

function TMemoryForm.UsageColorForVal(Val: Byte): LongWord;
begin
  if Val >= 80 then Result := MC_RED
  else if Val >= 60 then Result := MC_ORANGE
  else Result := MC_GREEN;
end;



procedure TMemoryForm.FormatMB(MB: LongWord; Buf: PChar);
var
  Tmp: array[0..31] of Char;
  I: Integer;
begin

  IntToPChar(MB, Tmp);
  I := 0;
  while Tmp[I] <> #0 do begin Buf[I] := Tmp[I]; Inc(I); end;
  Buf[I] := ' '; Inc(I);
  Buf[I] := 'M'; Inc(I);
  Buf[I] := 'B'; Inc(I);
  Buf[I] := #0;
end;

procedure TMemoryForm.FormatBytes(Bytes: LongWord; Buf: PChar);
var
  Tmp: array[0..31] of Char;
  I: Integer;
begin
  IntToPChar(Bytes, @Tmp[0]);
  I := 0;
  while Tmp[I] <> #0 do begin Buf[I] := Tmp[I]; Inc(I); end;
  Buf[I] := ' '; Inc(I);
  Buf[I] := 'B'; Inc(I);
  Buf[I] := #0;
end;

procedure TMemoryForm.FormatPct(Pct: Integer; Buf: PChar);
var
  Tmp: array[0..15] of Char;
  I: Integer;
begin
  IntToPChar(Pct, @Tmp[0]);
  I := 0;
  while Tmp[I] <> #0 do begin Buf[I] := Tmp[I]; Inc(I); end;
  Buf[I] := '%'; Inc(I);
  Buf[I] := #0;
end;

// =============================================================================
// RAM �UBUK �KONU (80 � 40 piksel)
// =============================================================================
procedure TMemoryForm.DrawRAMIcon(X, Y: Integer);
var
  I: Integer;
  CX: Integer;
  BytesBuf: array[0..31] of Char;
begin
  // PCB
  KFill(X, Y + 8, 80, 24, $1A4020);
  KRect(X, Y + 8, 80, 24, $2A6030);
  KLineH(X + 1, Y + 9, 78, $2A8040);

  // Bellek �ipleri (8 adet)
  for I := 0 to 7 do
  begin
    CX := X + 4 + I * 9;
    KFill(CX, Y + 4, 7, 16, $303840);
    KRect(CX, Y + 4, 7, 16, $4A5868);
    KLineH(CX + 1, Y + 5, 5, $5A6878);
    // Bacaklar (alt)
    KFill(CX + 1, Y + 20, 1, 4, $808080);
    KFill(CX + 3, Y + 20, 1, 4, $808080);
    KFill(CX + 5, Y + 20, 1, 4, $808080);
    // Bacaklar (�st)
    KFill(CX + 1, Y + 2, 1, 2, $808080);
    KFill(CX + 3, Y + 2, 1, 2, $808080);
    KFill(CX + 5, Y + 2, 1, 2, $808080);
  end;

  // Alt�n kontak �eridi
  KFill(X + 2, Y + 32, 76, 6, $C8A020);
  KRect(X + 2, Y + 32, 76, 6, $A08010);
  for I := 0 to 18 do
    KFill(X + 4 + I * 4, Y + 32, 2, 6, $E0C040);
  KLineH(X + 2, Y + 33, 76, $F0E080);

  // Bellek boyutu (Byte olarak g�ster)
  FormatBytes(FTotalBytes, @BytesBuf[0]);
  KStr(X + 2, Y - 2, @BytesBuf[0], MC_ACCENT);

  // Aktivite LED
  if FPercent > 50 then
    KFill(X + 72, Y + 10, 5, 5, MC_GREEN)
  else
    KFill(X + 72, Y + 10, 5, 5, $004020);
  KRect(X + 72, Y + 10, 5, 5, $008040);
end;

// =============================================================================
// BA�LIK B�LG� ALANI
// =============================================================================
procedure TMemoryForm.DrawMemoryInfo(X, Y, W, OX: Integer);
var
  PctBuf: array[0..15] of Char;
  StatusText: PChar;
  StatusColor: LongWord;
begin
  KStr(X + 92, Y + 2,  'SISTEM BELLEGI', MC_DARK);
  KStr(X + 92, Y + 14, 'RAM', MC_ACCENT);
  KStr(X + 92, Y + 30, 'DDR4  |  Cift Kanalli', MC_SILVER);

  FormatPct(FPercent, @PctBuf[0]);
  StatusColor := UsageColor;

  if FPercent >= 80 then StatusText := 'KRiTiK'
  else if FPercent >= 60 then StatusText := 'UYARI'
  else StatusText := 'NORMAL';

  KFill(OX + W - 80, Y + 6, 72, 20, UsageColorDark);
  KRect(OX + W - 80, Y + 6, 72, 20, StatusColor);
  KStrCentered(OX + W - 80, Y + 11, 72, StatusText, StatusColor);
  KStrCentered(OX + W - 80, Y + 30, 72, @PctBuf[0], MC_WHITE);
end;

// =============================================================================
// STAT KART � MB + Byte �ift sat�rl�
// =============================================================================
procedure TMemoryForm.DrawStatCard(X, Y, W, H: Integer;
                                    ALabel, AValueMB, AValueBytes: PChar;
                                    AColor, ADarkColor: LongWord);
begin
  KFill(X, Y, W, H, MC_CARD);
  KRect(X, Y, W, H, MC_BORDER);

  KFill(X+1, Y+1, 3, H-2, AColor);
  KFill(X+2, Y+1, 1, H-2, ADarkColor);

  KFill(X, Y, 1, 1, MC_BG); KFill(X+W-1, Y, 1, 1, MC_BG);
  KFill(X, Y+H-1, 1, 1, MC_BG); KFill(X+W-1, Y+H-1, 1, 1, MC_BG);

  KGradientH(X+4, Y+1, W-5, 2, $10FFFFFF, MC_CARD);

  KStr(X+10, Y+6, ALabel, MC_DARK);
  KStr(X+10, Y+20, AValueMB, MC_WHITE);      // MB b�y�k
  KStr(X+10, Y+38, AValueBytes, AColor);     // Byte k���k

  KLineH(X+10, Y+36, W-20, MC_BORDER2);
end;

// =============================================================================
// KULLANIM �UBU�U
// =============================================================================
procedure TMemoryForm.DrawUsageBar(X, Y, W, H: Integer);
var
  FillW: Integer;
  C, CD: LongWord;
  ThreshX: Integer;
begin
  C  := UsageColor;
  CD := UsageColorDark;
  FillW := ((W - 2) * FPercent) div 100;

  KFill(X, Y, W, H, MC_GRAPHBG);
  KRect(X, Y, W, H, MC_BORDER);
  KFill(X+1, Y+1, W-2, H-2, $101820);

  if FillW > 0 then begin
    KGradientH(X+1, Y+1, FillW, H-2, CD, C);
    KLineH(X+1, Y+1, FillW, $30FFFFFF);
    KLineH(X+1, Y+H-2, FillW, CD);
  end;

  ThreshX := X + 1 + ((W - 2) * 80) div 100;
  KLineV(ThreshX, Y, H, $FF4040);
  KFill(ThreshX - 1, Y - 4, 3, 4, $FF4040);
end;

// =============================================================================
// HALKA G�STERGE
// =============================================================================
procedure TMemoryForm.DrawRingGauge(X, Y, Size: Integer);
var
  Outer, Mid, RX, RY, RW, RH: Integer;
  Ring, TotalPx, UsedPx, Fill: Integer;
  C: LongWord;
  PctBuf: array[0..7] of Char;
begin
  C     := UsageColor;
  Outer := Size;
  Mid   := Size div 2;

  KFill(X, Y, Outer, Outer, MC_CARD2);
  KRect(X, Y, Outer, Outer, MC_BORDER);

  KFill(X+6, Y+6, Outer-12, Outer-12, MC_GRID);
  KRect(X+6, Y+6, Outer-12, Outer-12, MC_BORDER);

  Ring := 8;
  RX := X+6; RY := Y+6; RW := Outer-12; RH := Outer-12;
  TotalPx := 2*(RW+RH)-4;
  UsedPx  := (TotalPx * FPercent) div 100;

  Fill := MinI(UsedPx, RH);
  if Fill > 0 then KFill(RX+RW-Ring, RY, Ring, Fill, C);
  Dec(UsedPx, RH);

  if UsedPx > 0 then begin
    Fill := MinI(UsedPx, RW);
    KFill(RX+RW-Fill, RY+RH-Ring, Fill, Ring, C);
    Dec(UsedPx, RW);
  end;

  if UsedPx > 0 then begin
    Fill := MinI(UsedPx, RH);
    KFill(RX, RY+RH-Fill, Ring, Fill, C);
    Dec(UsedPx, RH);
  end;

  if UsedPx > 0 then begin
    Fill := MinI(UsedPx, RW);
    KFill(RX, RY, Fill, Ring, C);
  end;

  KFill(RX+Ring, RY+Ring, RW-2*Ring, RH-2*Ring, MC_CARD2);

  FormatPct(FPercent, @PctBuf[0]);
  KStrCentered(X, Y+Mid-12, Outer, @PctBuf[0], C);
  KStrCentered(X, Y+Mid+2,  Outer, 'RAM', MC_DARK);
end;

// =============================================================================
// BELLEK GE�M�� GRAF���
// =============================================================================
procedure TMemoryForm.DrawMemGraph(X, Y, W, H: Integer);
var
  I, GX, GY, GW, GH: Integer;
  AxisW, GridY: Integer;
  X1, Y1, X2, Y2: Integer;
  Val: Byte;
  StepX: Integer;
  Buf: array[0..7] of Char;
  PX: Integer;
  FillH: Integer;
  LastX, LastY: Integer;
begin
  AxisW := 28;
  GX := X + AxisW + 4;
  GY := Y + 2;
  GW := W - AxisW - 8;
  GH := H - 22;

  KFill(X, Y, W, H, MC_GRAPHBG);
  KRect(X, Y, W, H, MC_BORDER2);

  KFill(X, Y, 2, 1, MC_BG); KFill(X, Y, 1, 2, MC_BG);
  KFill(X+W-2, Y, 2, 1, MC_BG); KFill(X+W-1, Y, 1, 2, MC_BG);
  KFill(X, Y+H-1, 2, 1, MC_BG); KFill(X, Y+H-2, 1, 2, MC_BG);
  KFill(X+W-2, Y+H-1, 2, 1, MC_BG); KFill(X+W-1, Y+H-2, 1, 2, MC_BG);

  for I := 0 to 4 do begin
    GridY := GY + GH - (GH * I * 25) div 100;
    KLineH(GX, GridY, GW, MC_GRID);
    IntToPChar(I * 25, @Buf[0]);
    KStr(X + 2, GridY - 5, @Buf[0], MC_DARK);
  end;

  for I := 1 to 5 do
    KLineV(GX + (I * GW) div 6, GY, GH, MC_GRID);

  for I := 0 to GRAPH_HISTORY_SIZE - 1 do begin
    Val := FHistory[I];
    if Val > 0 then begin
      PX := GX + (I * GW) div (GRAPH_HISTORY_SIZE - 1);
      FillH := (Val * GH) div 100;
      KGradientV(PX, GY + GH - FillH,
                 MaxI(1, GW div (GRAPH_HISTORY_SIZE - 1) + 1), FillH,
                 UsageColorForVal(Val) and $80FFFFFF,
                 MC_GRAPHBG);
    end;
  end;

  StepX := GW div (GRAPH_HISTORY_SIZE - 1);
  for I := 0 to GRAPH_HISTORY_SIZE - 2 do begin
    if (FHistory[I] = 0) and (FHistory[I+1] = 0) then Continue;
    X1 := GX + I * StepX;
    Y1 := GY + GH - (Integer(FHistory[I])   * GH) div 100;
    X2 := GX + (I+1) * StepX;
    Y2 := GY + GH - (Integer(FHistory[I+1]) * GH) div 100;
    KLine(X1, Y1,   X2, Y2,   MC_LINEHIGH);
    KLine(X1, Y1+1, X2, Y2+1, UsageColorForVal(FHistory[I]));
  end;

  LastX := GX + (GRAPH_HISTORY_SIZE-1) * StepX;
  LastY := GY + GH - (Integer(FHistory[GRAPH_HISTORY_SIZE-1]) * GH) div 100;
  KFill(LastX-2, LastY-2, 5, 5, MC_WHITE);
  KFill(LastX-1, LastY-1, 3, 3, MC_LINEHIGH);
  KLineH(LastX-2, LastY, 4, MC_LINEHIGH);

  KLineH(GX, GY+GH, GW, MC_BORDER);

  KStr(GX, Y+H-14, 'Son 60 olcum', MC_DARK);
  KStr(GX+GW-50, Y+H-14, 'CANLI', MC_LINEHIGH);
end;

// =============================================================================
// AYIRICI & ALTBILGI
// =============================================================================
procedure TMemoryForm.DrawSeparator(X, Y, W: Integer);
begin
  KLineH(X, Y, W, MC_BORDER2);
  KLineH(X, Y+1, W, $0A1220);
end;

procedure TMemoryForm.DrawFooter(X, Y, W: Integer);
begin
  KFill(X, Y, W, 20, MC_CARD2);
  KLineH(X, Y, W, MC_BORDER2);
  KStr(X+8, Y+5, 'Cift Kanal  |  ECC Yok', MC_SILVER);
  KStr(X+W-110, Y+5, 'DDR4-3200 MHz', MC_DARK);
end;

// =============================================================================
// ANA DRAW
// =============================================================================
procedure TMemoryForm.Draw(Sender: PObject; OX, OY: Integer);
var

  CW, CH: Integer;
  MBBuf:    array[0..31] of Char;
  BytesBuf: array[0..31] of Char;
  PctBuf:   array[0..15] of Char;
  CardX, CardW: Integer;
  ThreshX: Integer;
begin

  CW := Sender^.Width;
  CH := Sender^.Height - HEADER_HEIGHT;

  // 1. ARKA PLAN
  KFill(OX, OY, CW, CH, MC_BG);
  KGradientV(OX, OY, CW, 40, $1A2A3A, MC_BG);

  // 2. BA�LIK
  DrawRAMIcon(OX + 8, OY + 16);
  DrawMemoryInfo(OX + 8, OY + 10, CW - 10, OX);
  DrawSeparator(OX + 4, OY + 76, CW - 8);

  // 3. HALKA + STAT KARTLAR
  DrawRingGauge(OX + 8, OY + 84, 96);

  CardX := OX + 116;
  CardW := (CW - 124) div 3 - 4;

  // Toplam RAM
  FormatMB(FTotalMB, @MBBuf[0]);
  FormatBytes(FTotalBytes, @BytesBuf[0]);
  DrawStatCard(CardX, OY + 84, CardW, 96,
               'TOPLAM RAM', @MBBuf[0], @BytesBuf[0],
               MC_ACCENT, MC_ACCENT2);

  // Kullan�lan
  Inc(CardX, CardW + 4);
  FormatMB(FUsedMB, @MBBuf[0]);
  FormatBytes(FUsedBytes, @BytesBuf[0]);
  DrawStatCard(CardX, OY + 84, CardW, 96,
               'KULLANILAN', @MBBuf[0], @BytesBuf[0],
               UsageColor, UsageColorDark);

  // Bo�
  Inc(CardX, CardW + 4);
  FormatMB(FFreeMB, @MBBuf[0]);
  FormatBytes(FFreeBytes, @BytesBuf[0]);
  DrawStatCard(CardX, OY + 84, CardW, 96,
               'BOS RAM', @MBBuf[0], @BytesBuf[0],
               MC_GREEN, MC_GREEN2);

  DrawSeparator(OX + 4, OY + 186, CW - 8);

  // 4. KULLANIM �UBU�U
  KStr(OX + 8, OY + 194, 'RAM KULLANIMI', MC_SILVER);
  FormatPct(FPercent, @PctBuf[0]);
  KStr(OX + CW - 88, OY + 194, @PctBuf[0], UsageColor);

  DrawUsageBar(OX + 8, OY + 208, CW - 16, 16);

  FormatMB(FUsedMB, @MBBuf[0]);
  KStr(OX + 8, OY + 228, @MBBuf[0], UsageColor);
  KStr(OX + 8 + 72, OY + 228, 'kullaniliyor', MC_DARK);

  FormatMB(FFreeMB, @MBBuf[0]);
  KStr(OX + CW - 90, OY + 228, @MBBuf[0], MC_GREEN);
  KStr(OX + CW - 90 - 22, OY + 228, 'bos', MC_DARK);

  ThreshX := OX + 8 + ((CW - 16) * 80) div 100;
  KStr(ThreshX - 16, OY + 196, '%80', $FF4040);

  DrawSeparator(OX + 4, OY + 244, CW - 8);

  // 5. GRAF�K
  KStr(OX + 8, OY + 250, 'RAM KULLANIM GECMISI', MC_SILVER);
  DrawMemGraph(OX + 4, OY + 264, CW - 8, 120);

  // 6. ALTBILGI
  DrawFooter(OX, OY + CH - 20, CW);
end;

// =============================================================================
// INIT & UPDATESTATS
// =============================================================================


procedure TMemoryForm.UpdateStats;
var I: Integer;
begin
  FTotalMB := GetTotalMemMB;
  FUsedMB  := GetUsedMemMB;
  FFreeMB  := GetFreeMemMB;
  FPercent := GetMemoryUsagePercent;

  { Byte �evirisi � 32-bit s�n�r�: 4GB+ sistemlerde ta�ar! }
  FTotalBytes := FTotalMB * 1024 * 1024;
  FUsedBytes  := FUsedMB  * 1024 * 1024;
  FFreeBytes  := FFreeMB  * 1024 * 1024;

  { Ge�mi� grafi�i sola kayd�r }
  for I := 0 to GRAPH_HISTORY_SIZE - 2 do
    FHistory[I] := FHistory[I + 1];
  FHistory[GRAPH_HISTORY_SIZE - 1] := Byte(FPercent);
end;






// =============================================================================
// INIT & UPDATESTATS
// =============================================================================

procedure MemoryForm_Draw(Sender: PObject; OX, OY: Integer);
begin
   MemForm.UpdateStats;
   MemForm.Draw(Sender,OX, OY+ HEADER_HEIGHT);
end;



procedure TMemoryForm.InitMemoryForm;
var I: Integer;
begin

 // TypeSize := SizeOf(TMemoryForm);

  FTotalMB := 0; FUsedMB := 0; FFreeMB := 0;
  FTotalBytes := 0; FUsedBytes := 0; FFreeBytes := 0;
  FPercent := 0;

  for I := 0 to GRAPH_HISTORY_SIZE - 1 do FHistory[I] := 0;

  UpdateStats;
end;

procedure OpenMemoryForm();

begin

   MemForm.InitMemoryForm;
  MemForm.FForm :=CreateForm('RAM Durumu', (Surface.Width  - 460) div 2,
                      (Surface.Height - 420) div 2,
                      460, 420);


  if MemForm.FForm = nil then begin  Exit; end;

   MemForm.FForm^.BindPaint(@MemoryForm_Draw);


 
  MemForm.UpdateStats;
end;


end.
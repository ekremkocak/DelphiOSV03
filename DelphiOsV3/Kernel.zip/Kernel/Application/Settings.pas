unit Settings;

{ ============================================================
  Sistem Ayarlari Formu (Gelistirilmis Versiyon)
  - Masaustu rengi (7 on-tanimli tema)
  - Net surucu adi
  - Kullanici adi ve Sifre
  - Dil secimi (Turkce, Ingilizce, Almanca)
  - Ekran cozunurlugu
  - Ses seviyesi
  - Otomatik Guncelleme
  - Tema mod (Acik/Koyu)
  - Font boyutu
  - SYSTEM.INI ye kaydet / yukle
  ============================================================ }

interface

uses
  SysUtils, GUI, GUIControls, Draw32, IniFiles, Memory;

procedure OpenSettings;

implementation

type
  TSettingsData = Object
  public
    Form: PForm;
    Tab: PTabControl;
    PageGeneral: PPanel;
    PageNetwork: PPanel;
    PageUser: PPanel;
    PageDisplay: PPanel;
    PageSound: PPanel;
    PageAdvanced: PPanel;

    { Genel }
    CmbColor: PComboBox;
    PnlPreview: PPanel;
    CmbTheme: PComboBox;
    CmbLanguage: PComboBox;
    CmbFontSize: PComboBox;

    { Ag }
    EdtDriver: PEdit;
    EdtGateway: PEdit;
    EdtDNS: PEdit;

    { Kullanici }
    EdtUsername: PEdit;
    EdtPassword: PEdit;
    EdtPasswordConfirm: PEdit;
    ChkAutoLogin: PCheckBox;

    { Ekran }
    CmbResolution: PComboBox;
    CmbRefreshRate: PComboBox;
    ChkVSync: PCheckBox;

    { Ses }
    SldVolume: PScrollBar;
    ChkMute: PCheckBox;
    LblVolumeValue: PLabel;

    { Gelismis }
    ChkAutoUpdate: PCheckBox;
    ChkDebugMode: PCheckBox;
    ChkCacheClear: PCheckBox;

    BtnSave: PButton;
    BtnCancel: PButton;
    BtnDefault: PButton;

    Status: PStatusBar;
  end;

var
  SD: TSettingsData;

const
  { Renkler }
  COLOR_NAMES: array[0..6] of PChar = (
    'Mavi (Varsayilan)', 'Yesil', 'Kirmizi', 'Gri', 'Mor', 'Turuncu', 'Siyah'
  );
  COLOR_TABLE: array[0..6] of LongWord = (
    $000000FF,   // 0: Mavi   (BGR)
    $0000FF00,   // 1: Yesil
    $00FF0000,   // 2: Kirmizi
    $00808080,   // 3: Gri
    $00FF00FF,   // 4: Mor
    $00FF8000,   // 5: Turuncu
    $00000000    // 6: Siyah
  );

  { Temalar }
  THEME_NAMES: array[0..1] of PChar = (
    'Acik Tema',
    'Koyu Tema'
  );

  { Diller }
  LANGUAGE_NAMES: array[0..2] of PChar = (
    'Turkce',
    'English',
    'Deutsch'
  );

  LANGUAGE_CODES: array[0..2] of PChar = (
    'TR_tr',
    'EN_en',
    'DE_de'
  );

  { Font Boyutlari }
  FONT_SIZES: array[0..4] of PChar = (
    'Kucuk (8pt)',
    'Normal (10pt)',
    'Orta (12pt)',
    'Buyuk (14pt)',
    'Cok Buyuk (16pt)'
  );

  { Ekran Cozunurlugu }
  RESOLUTION_OPTIONS: array[0..4] of PChar = (
    '640x480',
    '800x600',
    '1024x768',
    '1280x1024',
    '1600x1200'
  );

  { Yenileme Hizi }
  REFRESH_RATES: array[0..3] of PChar = (
    '60 Hz',
    '75 Hz',
    '85 Hz',
    '100 Hz'
  );

{-----------------------------------------------------------------------------}
{ Yardimci: PChar -> Integer }
{-----------------------------------------------------------------------------}
function StrToIntDef(S: PChar; Default: Integer): Integer;
var
  Sign, I: Integer;
begin
  Result := Default;
  if S = nil then Exit;
  Sign := 1; I := 0;
  if S[0] = '-' then begin Sign := -1; I := 1; end;
  while (S[I] >= '0') and (S[I] <= '9') do
  begin
    Result := Result * 10 + (Ord(S[I]) - Ord('0'));
    Inc(I);
  end;
  if I = 0 then Result := Default else Result := Result * Sign;
end;

{-----------------------------------------------------------------------------}
{ Yardimci: Integer -> PChar }
{-----------------------------------------------------------------------------}

{-----------------------------------------------------------------------------}
{ Sifre Validation }
{-----------------------------------------------------------------------------}
function IsValidPassword(P: PChar): Boolean;
var
  I, Len: Integer;
begin
  Result := False;
  if P = nil then Exit;
  
  Len := 0;
  while P[Len] <> #0 do Inc(Len);
  
  if Len < 6 then Exit;  { En az 6 karakter }
  Result := True;
end;

{-----------------------------------------------------------------------------}
{ Cizim: Renk onizleme paneli }
{-----------------------------------------------------------------------------}
procedure PreviewPaint(Sender: PObject; AbsX, AbsY: Integer);
begin
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, Sender^.Color);
  KRect(AbsX, AbsY, Sender^.Width, Sender^.Height, clBlack);
end;

{-----------------------------------------------------------------------------}
{ Olay: ComboBox Renk degisince onizlemeyi guncelle }
{-----------------------------------------------------------------------------}
procedure OnColorChange(Sender: PObject);
var
  Idx: Integer;
begin
  Idx := PComboBox(Sender)^.ItemIndex;
  if (Idx >= 0) and (Idx <= High(COLOR_TABLE)) then
    SD.PnlPreview^.Color := COLOR_TABLE[Idx];
end;

{-----------------------------------------------------------------------------}
{ Olay: Volume ScrollBar degisince }
{-----------------------------------------------------------------------------}
procedure OnVolumeChange(Sender: PObject);
var
  Volume: Integer;
  VolumeStr: array[0..15] of Char;
begin
  Volume := PScrollBar(Sender)^.Position;
  IntToPChar(Volume, @VolumeStr[0]);
 StrCopy(@SD.LblVolumeValue^.Caption[0], @VolumeStr[0]);
end;

{-----------------------------------------------------------------------------}
{ Olay: Kaydet butonu }
{-----------------------------------------------------------------------------}
procedure OnSaveClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  Buf: array[0..255] of Char;
  Driver: array[0..255] of Char;
  Username: array[0..127] of Char;
  Password: array[0..127] of Char;
  PasswordConfirm: array[0..127] of Char;
  MsgBuf: array[0..255] of Char;
begin
  { Sifre dogrulama }
  EditGetText(SD.EdtPassword, Password, 127);
  EditGetText(SD.EdtPasswordConfirm, PasswordConfirm, 127);
  
  { Sifreler eslesmezse }
  if (Password[0] <> #0) or (PasswordConfirm[0] <> #0) then
  begin
    if StrCmp(Password, PasswordConfirm) <> 0 then
    begin
      StatusBarSetText(SD.Status, 0, 'HATA: Sifreler eslesmedi!');
      Exit;
    end;
  end;

  { Sifre gecerliligini kontrol et }
  if (Password[0] <> #0) and not IsValidPassword(@Password[0]) then
  begin
    StatusBarSetText(SD.Status, 0, 'HATA: Sifre en az 6 karakter olmali!');
    Exit;
  end;

  { GENEL }
  IntToPChar(SD.CmbColor^.ItemIndex, @Buf[0]);
  WriteINIFile('SYSTEMS.INI', 'DesktopColor', @Buf[0]);

  IntToPChar(SD.CmbTheme^.ItemIndex, @Buf[0]);
  WriteINIFile('SYSTEMS.INI', 'ThemeMode', @Buf[0]);

  IntToPChar(SD.CmbLanguage^.ItemIndex, @Buf[0]);
  WriteINIFile('SYSTEMS.INI', 'Language', @Buf[0]);

  IntToPChar(SD.CmbFontSize^.ItemIndex, @Buf[0]);
  WriteINIFile('SYSTEMS.INI', 'FontSize', @Buf[0]);

  { NETWORK }
  EditGetText(SD.EdtDriver, Driver, 255);
  WriteINIFile('SYSTEMS.INI', 'NetDriver', @Driver[0]);

  EditGetText(SD.EdtGateway, Driver, 255);
  WriteINIFile('SYSTEMS.INI', 'Gateway', @Driver[0]);

  EditGetText(SD.EdtDNS, Driver, 255);
  WriteINIFile('SYSTEMS.INI', 'DNS', @Driver[0]);

  { KULLANICI }
  EditGetText(SD.EdtUsername, Username, 127);
  WriteINIFile('SYSTEMS.INI', 'Username', @Username[0]);

  if Password[0] <> #0 then
    WriteINIFile('SYSTEMS.INI', 'Password', @Password[0]);

  if SD.ChkAutoLogin^.Checked then
    WriteINIFile('SYSTEMS.INI', 'AutoLogin', 'Yes')
  else
    WriteINIFile('SYSTEMS.INI', 'AutoLogin', 'No');

  { EKRAN }
  IntToPChar(SD.CmbResolution^.ItemIndex, @Buf[0]);
  WriteINIFile('SYSTEMS.INI', 'Resolution', @Buf[0]);

  IntToPChar(SD.CmbRefreshRate^.ItemIndex, @Buf[0]);
  WriteINIFile('SYSTEMS.INI', 'RefreshRate', @Buf[0]);

  if SD.ChkVSync^.Checked then
    WriteINIFile('SYSTEMS.INI', 'VSync', 'Yes')
  else
    WriteINIFile('SYSTEMS.INI', 'VSync', 'No');

  { SES }
  IntToPChar(PScrollBar(SD.SldVolume)^.Position, @Buf[0]);
  WriteINIFile('SYSTEMS.INI', 'Volume', @Buf[0]);

  if SD.ChkMute^.Checked then
    WriteINIFile('SYSTEMS.INI', 'Mute', 'Yes')
  else
    WriteINIFile('SYSTEMS.INI', 'Mute', 'No');

  { GELISMIS }
 // if CheckBoxGetState(SD.ChkAutoUpdate) then
  if SD.ChkAutoUpdate^.Checked then
    WriteINIFile('SYSTEMS.INI', 'AutoUpdate', 'Yes')
  else
    WriteINIFile('SYSTEMS.INI', 'AutoUpdate', 'No');

  if CheckBoxGetState(SD.ChkDebugMode) then
    WriteINIFile('SYSTEMS.INI', 'DebugMode', 'Yes')
  else
    WriteINIFile('SYSTEMS.INI', 'DebugMode', 'No');

  StatusBarSetText(SD.Status, 0, 'Ayarlar SYSTEM.INI ye kaydedildi. Basarili!');
end;

{-----------------------------------------------------------------------------}
{ Olay: Iptal butonu }
{-----------------------------------------------------------------------------}
procedure OnCancelClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
begin
  if Btn <> 1 then Exit;
  WinManager.RemoveForm(SD.Form);
  SD.Form := nil;
end;

{-----------------------------------------------------------------------------}
{ Olay: Varsayilan butonu }
{-----------------------------------------------------------------------------}
procedure OnDefaultClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  Buf: array[0..63] of Char;
begin
  if Btn <> 1 then Exit;

  { GENEL }
  SD.CmbColor^.ItemIndex := 0;
  SD.PnlPreview^.Color := COLOR_TABLE[0];
  SD.CmbTheme^.ItemIndex := 0;
  SD.CmbLanguage^.ItemIndex := 0;
  SD.CmbFontSize^.ItemIndex := 1;

  { NETWORK }
  EditSetText(SD.EdtDriver, 'RTL8139');
  EditSetText(SD.EdtGateway, '192.168.1.1');
  EditSetText(SD.EdtDNS, '8.8.8.8');

  { KULLANICI }
  EditSetText(SD.EdtUsername, 'Kullanici');
  EditSetText(SD.EdtPassword, '');
  EditSetText(SD.EdtPasswordConfirm, '');
  CheckBoxSetState(SD.ChkAutoLogin, False);

  { EKRAN }
  SD.CmbResolution^.ItemIndex := 2;
  SD.CmbRefreshRate^.ItemIndex := 0;
  CheckBoxSetState(SD.ChkVSync, True);

  { SES }
  PScrollBar(SD.SldVolume)^.Position := 75;
  CheckBoxSetState(SD.ChkMute, False);

  { GELISMIS }
  CheckBoxSetState(SD.ChkAutoUpdate, True);
  CheckBoxSetState(SD.ChkDebugMode, False);

  StatusBarSetText(SD.Status, 0, 'Varsayilan ayarlar yuklendi.');
end;

{-----------------------------------------------------------------------------}
{ Sayfalar Olusturma }
{-----------------------------------------------------------------------------}

procedure CreateGeneralPage;
var
  GrpDisplay, GrpLocalization: PGroupBox;
  Lbl: PLabel;
  I: Integer;
begin
  { --- Goruntu Grubu --- }
  GrpDisplay := CreateGroupBox(PObject(SD.PageGeneral),
                 'Goruntu Ayarlari', 12, 12, 460, 160, alNone);

  Lbl := CreateLabel(PObject(GrpDisplay), 'Tema Rengi:', 16, 32, 90, 20, alNone);
  SD.CmbColor := CreateComboBox(PObject(GrpDisplay), 110, 30, 180, 22, alNone);
  for I := 0 to High(COLOR_NAMES) do
    ComboBoxAddItem(SD.CmbColor, COLOR_NAMES[I]);
  SD.CmbColor^.FOnChange := @OnColorChange;

  Lbl := CreateLabel(PObject(GrpDisplay), 'Onizleme:', 16, 68, 90, 20, alNone);
  SD.PnlPreview := CreatePanel(PObject(GrpDisplay), 110, 60, 80, 24, alNone);
  SD.PnlPreview^.Color := COLOR_TABLE[0];
  SD.PnlPreview^.BindPaint(@PreviewPaint);

  Lbl := CreateLabel(PObject(GrpDisplay), 'Tema Modu:', 16, 104, 90, 20, alNone);
  SD.CmbTheme := CreateComboBox(PObject(GrpDisplay), 110, 102, 180, 22, alNone);
  for I := 0 to High(THEME_NAMES) do
    ComboBoxAddItem(SD.CmbTheme, THEME_NAMES[I]);

  { --- Yerelestirme Grubu --- }
  GrpLocalization := CreateGroupBox(PObject(SD.PageGeneral),
                 'Yerelestirme', 12, 180, 460, 150, alNone);

  Lbl := CreateLabel(PObject(GrpLocalization), 'Dil:', 16, 32, 90, 20, alNone);
  SD.CmbLanguage := CreateComboBox(PObject(GrpLocalization), 110, 30, 180, 22, alNone);
  for I := 0 to High(LANGUAGE_NAMES) do
    ComboBoxAddItem(SD.CmbLanguage, LANGUAGE_NAMES[I]);

  Lbl := CreateLabel(PObject(GrpLocalization), 'Font Boyutu:', 16, 68, 90, 20, alNone);
  SD.CmbFontSize := CreateComboBox(PObject(GrpLocalization), 110, 66, 180, 22, alNone);
  for I := 0 to High(FONT_SIZES) do
    ComboBoxAddItem(SD.CmbFontSize, FONT_SIZES[I]);
end;

procedure CreateNetworkPage;
var
  GrpNetwork: PGroupBox;
  Lbl: PLabel;
begin
  GrpNetwork := CreateGroupBox(PObject(SD.PageNetwork),
                 'Ag Surucusu', 12, 12, 460, 140, alNone);

  Lbl := CreateLabel(PObject(GrpNetwork), 'Surucu Adi:', 16, 32, 90, 20, alNone);
  SD.EdtDriver := CreateEdit(PObject(GrpNetwork), 110, 30, 200, 22, alNone);
  EditSetText(SD.EdtDriver, 'RTL8139');

  Lbl := CreateLabel(PObject(GrpNetwork), 'Gateway:', 16, 68, 90, 20, alNone);
  SD.EdtGateway := CreateEdit(PObject(GrpNetwork), 110, 66, 200, 22, alNone);
  EditSetText(SD.EdtGateway, '192.168.1.1');

  Lbl := CreateLabel(PObject(GrpNetwork), 'DNS:', 16, 104, 90, 20, alNone);
  SD.EdtDNS := CreateEdit(PObject(GrpNetwork), 110, 102, 200, 22, alNone);
  EditSetText(SD.EdtDNS, '8.8.8.8');
end;

procedure CreateUserPage;
var
  GrpUser: PGroupBox;
  Lbl: PLabel;
begin
  GrpUser := CreateGroupBox(PObject(SD.PageUser),
                 'Kullanici Bilgileri', 12, 12, 460, 200, alNone);

  Lbl := CreateLabel(PObject(GrpUser), 'Kullanici Adi:', 16, 32, 90, 20, alNone);
  SD.EdtUsername := CreateEdit(PObject(GrpUser), 110, 30, 200, 22, alNone);
  EditSetText(SD.EdtUsername, 'Kullanici');

  Lbl := CreateLabel(PObject(GrpUser), 'Sifre:', 16, 68, 90, 20, alNone);
  SD.EdtPassword := CreateEdit(PObject(GrpUser), 110, 66, 200, 22, alNone);
  SD.EdtPassword^.PasswordChar := '*';

  Lbl := CreateLabel(PObject(GrpUser), 'Sifre Tekrar:', 16, 104, 90, 20, alNone);
  SD.EdtPasswordConfirm := CreateEdit(PObject(GrpUser), 110, 102, 200, 22, alNone);
  SD.EdtPasswordConfirm^.PasswordChar := '*';

  SD.ChkAutoLogin := CreateCheckBox(PObject(GrpUser), 'Otomatik Giris Yap', 
                                     16, 140, 200, 20, alNone);
end;

procedure CreateDisplayPage;
var
  GrpDisplay: PGroupBox;
  Lbl: PLabel;
  I: Integer;
begin
  GrpDisplay := CreateGroupBox(PObject(SD.PageDisplay),
                 'Ekran Ayarlari', 12, 12, 460, 160, alNone);

  Lbl := CreateLabel(PObject(GrpDisplay), 'Cozunurluk:', 16, 32, 90, 20, alNone);
  SD.CmbResolution := CreateComboBox(PObject(GrpDisplay), 110, 30, 180, 22, alNone);
  for I := 0 to High(RESOLUTION_OPTIONS) do
    ComboBoxAddItem(SD.CmbResolution, RESOLUTION_OPTIONS[I]);

  Lbl := CreateLabel(PObject(GrpDisplay), 'Yenileme Hizi:', 16, 68, 90, 20, alNone);
  SD.CmbRefreshRate := CreateComboBox(PObject(GrpDisplay), 110, 66, 180, 22, alNone);
  for I := 0 to High(REFRESH_RATES) do
    ComboBoxAddItem(SD.CmbRefreshRate, REFRESH_RATES[I]);

  SD.ChkVSync := CreateCheckBox(PObject(GrpDisplay), 'V-Sync Etkinlestir', 
                                16, 104, 200, 20, alNone);
end;

procedure CreateSoundPage;
var
  GrpSound: PGroupBox;
  Lbl: PLabel;
  VolumeStr: array[0..15] of Char;
begin
  GrpSound := CreateGroupBox(PObject(SD.PageSound),
                 'Ses Ayarlari', 12, 12, 460, 140, alNone);

  Lbl := CreateLabel(PObject(GrpSound), 'Ses Seviyesi:', 16, 32, 90, 20, alNone);
  SD.SldVolume := CreateScrollBar(PObject(GrpSound), 110, 30, 200, 18, alNone);
  PScrollBar(SD.SldVolume)^.Min := 0;
  PScrollBar(SD.SldVolume)^.Max := 100;
  PScrollBar(SD.SldVolume)^.Position := 75;
//  PScrollBar(SD.SldVolume)^.FOnChange := @OnVolumeChange;

  IntToPChar(75, @VolumeStr[0]);
  SD.LblVolumeValue := CreateLabel(PObject(GrpSound), @VolumeStr[0], 
                                    320, 32, 40, 20, alNone);

  SD.ChkMute := CreateCheckBox(PObject(GrpSound), 'Sesi Kapat', 
                               16, 68, 200, 20, alNone);
end;

procedure CreateAdvancedPage;
var
  GrpAdvanced: PGroupBox;
begin
  GrpAdvanced := CreateGroupBox(PObject(SD.PageAdvanced),
                 'Gelismis Ayarlar', 12, 12, 460, 160, alNone);

  SD.ChkAutoUpdate := CreateCheckBox(PObject(GrpAdvanced), 'Otomatik Guncelle', 
                                     16, 32, 300, 20, alNone);
  CheckBoxSetState(SD.ChkAutoUpdate, True);

  SD.ChkDebugMode := CreateCheckBox(PObject(GrpAdvanced), 'Hata Ayiklama Modu', 
                                    16, 68, 300, 20, alNone);

  SD.ChkCacheClear := CreateCheckBox(PObject(GrpAdvanced), 'Cikisda Ondbellegiyi Temizle', 
                                     16, 104, 300, 20, alNone);
  CheckBoxSetState(SD.ChkCacheClear, True);
end;

{-----------------------------------------------------------------------------}
{ Form Olusturma }
{-----------------------------------------------------------------------------}
procedure OpenSettings;
var
  PnlButtons: PPanel;
  Buf: array[0..63] of Char;
  Idx: Integer;
begin
  { --- Form --- }
  SD.Form := CreateForm('Sistem Ayarlari', 80, 60, 600, 450, bsDialog);
  SD.Form^.ShowSysButtons := True;

  { --- TabControl (alClient) --- }
  SD.Tab := CreateTabControl(PObject(SD.Form), 0, 0, 600, 380, alClient);
  
  SD.PageGeneral := TabControlAddTab(SD.Tab, 'Genel');
  SD.PageNetwork := TabControlAddTab(SD.Tab, 'Ag');
  SD.PageUser := TabControlAddTab(SD.Tab, 'Kullanici');
  SD.PageDisplay := TabControlAddTab(SD.Tab, 'Ekran');
  SD.PageSound := TabControlAddTab(SD.Tab, 'Ses');
  SD.PageAdvanced := TabControlAddTab(SD.Tab, 'Gelismis');

  { Sayfalar Olustur }
  CreateGeneralPage;
  CreateNetworkPage;
  CreateUserPage;
  CreateDisplayPage;
  CreateSoundPage;
  CreateAdvancedPage;

  { === ALT BUTON ALANI === }
  PnlButtons := CreatePanel(PObject(SD.Form), 0, 0, 600, 40, alBottom);
  PnlButtons^.Color := clBtnFace;
  PnlButtons^.BorderWidth := 0;

  SD.BtnSave := CreateButton(PObject(PnlButtons), 'Kaydet', 280, 8, 80, 24, alNone);
  SD.BtnSave^.BindMouseUp(@OnSaveClick);

  SD.BtnCancel := CreateButton(PObject(PnlButtons), 'Iptal', 370, 8, 80, 24, alNone);
  SD.BtnCancel^.BindMouseUp(@OnCancelClick);

  SD.BtnDefault := CreateButton(PObject(PnlButtons), 'Varsayilan', 460, 8, 100, 24, alNone);
  SD.BtnDefault^.BindMouseUp(@OnDefaultClick);

  { === STATUS BAR === }
  SD.Status := CreateStatusBar(PObject(SD.Form), 0, 0, 600, alBottom);
  SD.Status^.AddPanel('Hazir', 500);

  { === INI'DEN AYARLARI YUKLE === }
  
  { Renk }
  if ReadINIFile('SYSTEMS.INI', 'DesktopColor', @Buf[0]) then
  begin
    Idx := StrToIntDef(@Buf[0], 0);
    if (Idx < 0) or (Idx > High(COLOR_TABLE)) then Idx := 0;
    SD.CmbColor^.ItemIndex := Idx;
    SD.PnlPreview^.Color := COLOR_TABLE[Idx];
  end;

  { Tema Modu }
  if ReadINIFile('SYSTEMS.INI', 'ThemeMode', @Buf[0]) then
  begin
    Idx := StrToIntDef(@Buf[0], 0);
    if (Idx >= 0) and (Idx <= High(THEME_NAMES)) then
      SD.CmbTheme^.ItemIndex := Idx;
  end;

  { Dil }
  if ReadINIFile('SYSTEMS.INI', 'Language', @Buf[0]) then
  begin
    Idx := StrToIntDef(@Buf[0], 0);
    if (Idx >= 0) and (Idx <= High(LANGUAGE_NAMES)) then
      SD.CmbLanguage^.ItemIndex := Idx;
  end;

  { Font Boyutu }
  if ReadINIFile('SYSTEMS.INI', 'FontSize', @Buf[0]) then
  begin
    Idx := StrToIntDef(@Buf[0], 1);
    if (Idx >= 0) and (Idx <= High(FONT_SIZES)) then
      SD.CmbFontSize^.ItemIndex := Idx;
  end;

  { Network Surucusu }
  if ReadINIFile('SYSTEMS.INI', 'NetDriver', @Buf[0]) then
    EditSetText(SD.EdtDriver, @Buf[0]);

  if ReadINIFile('SYSTEMS.INI', 'Gateway', @Buf[0]) then
    EditSetText(SD.EdtGateway, @Buf[0]);

  if ReadINIFile('SYSTEMS.INI', 'DNS', @Buf[0]) then
    EditSetText(SD.EdtDNS, @Buf[0]);

  { Kullanici }
  if ReadINIFile('SYSTEMS.INI', 'Username', @Buf[0]) then
    EditSetText(SD.EdtUsername, @Buf[0]);

  if ReadINIFile('SYSTEMS.INI', 'AutoLogin', @Buf[0]) then
    if (Buf[0] = 'Y') or (Buf[0] = 'y') then
      CheckBoxSetState(SD.ChkAutoLogin, True);

  { Ekran }
  if ReadINIFile('SYSTEMS.INI', 'Resolution', @Buf[0]) then
  begin
    Idx := StrToIntDef(@Buf[0], 2);
    if (Idx >= 0) and (Idx <= High(RESOLUTION_OPTIONS)) then
      SD.CmbResolution^.ItemIndex := Idx;
  end;

  if ReadINIFile('SYSTEMS.INI', 'RefreshRate', @Buf[0]) then
  begin
    Idx := StrToIntDef(@Buf[0], 0);
    if (Idx >= 0) and (Idx <= High(REFRESH_RATES)) then
      SD.CmbRefreshRate^.ItemIndex := Idx;
  end;

  if ReadINIFile('SYSTEMS.INI', 'VSync', @Buf[0]) then
    if (Buf[0] = 'Y') or (Buf[0] = 'y') then
      CheckBoxSetState(SD.ChkVSync, True);

  { Ses }
  if ReadINIFile('SYSTEMS.INI', 'Volume', @Buf[0]) then
  begin
    Idx := StrToIntDef(@Buf[0], 75);
    if (Idx >= 0) and (Idx <= 100) then
      PScrollBar(SD.SldVolume)^.Position := Idx;
  end;

  if ReadINIFile('SYSTEMS.INI', 'Mute', @Buf[0]) then
    if (Buf[0] = 'Y') or (Buf[0] = 'y') then
      CheckBoxSetState(SD.ChkMute, True);

  { Gelismis }
  if ReadINIFile('SYSTEMS.INI', 'AutoUpdate', @Buf[0]) then
    if (Buf[0] = 'Y') or (Buf[0] = 'y') then
      CheckBoxSetState(SD.ChkAutoUpdate, True);

  if ReadINIFile('SYSTEMS.INI', 'DebugMode', @Buf[0]) then
    if (Buf[0] = 'Y') or (Buf[0] = 'y') then
      CheckBoxSetState(SD.ChkDebugMode, True);
end;

end.


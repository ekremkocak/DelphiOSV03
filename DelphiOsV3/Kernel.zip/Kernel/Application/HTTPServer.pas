
{ =========================================================
  HTTPServerForm.pas � HTTP Server GUI Form

  �zellikler:
  - Start / Stop butonlar�
  - Durum label'� (RUNNING / STOPPED)
  - Log paneli (ba�lant� zaman, IP, port, method, path)
  - Non-blocking accept (PollServer)
  - Thread veya polling deste�i

  Kullan�m:
  1. uses b�l�m�ne HTTPServerForm ekle
  2. OpenHTTPServerForm �a��r
  3. E�er thread yoksa: kendi idle loop'unda PollServer �a��r
  ========================================================= }
  
Unit HTTPServer;

interface

uses
  SysUtils, Fat32,Memory,Task, Draw32, Vesa, GUI, GUIControls, WinSocket,Pit,RTL8139,Math,
  JPEGEncoder,NetworkDevices;

const
  SERVER_PORT = 80;
// SERVER_IP   = '10.0.2.15';
  MAX_LOG_LINES = 100;
  LOG_LINE_LEN  = 128;



const
  HTML: PChar =
    '<!DOCTYPE html>'#10+
    '<html lang="tr">'#10+
    '<head>'#10+
    '  <meta charset="UTF-8">'#10+
    '  <meta name="viewport" content="width=device-width, initial-scale=1.0">'#10+
    '  <title>🚀 Pascal HTTP Server</title>'#10+
    '  <style>'#10+
    '    * { margin: 0; padding: 0; box-sizing: border-box; }'#10+
    '    body {'#10+
    '      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;'#10+
    '      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);'#10+
    '      min-height: 100vh;'#10+
    '      color: #e0e0e0;'#10+
    '      display: flex;'#10+
    '      justify-content: center;'#10+
    '      align-items: center;'#10+
    '      padding: 20px;'#10+
    '    }'#10+
    '    .container {'#10+
    '      max-width: 800px;'#10+
    '      width: 100%;'#10+
    '      background: rgba(255,255,255,0.05);'#10+
    '      backdrop-filter: blur(10px);'#10+
    '      border-radius: 20px;'#10+
    '      padding: 40px;'#10+
    '      border: 1px solid rgba(255,255,255,0.1);'#10+
    '      box-shadow: 0 8px 32px rgba(0,0,0,0.3);'#10+
    '    }'#10+
    '    h1 {'#10+
    '      text-align: center;'#10+
    '      font-size: 2.5em;'#10+
    '      margin-bottom: 10px;'#10+
    '      background: linear-gradient(90deg, #e94560, #ff6b6b);'#10+
    '      -webkit-background-clip: text;'#10+
    '      -webkit-text-fill-color: transparent;'#10+
    '    }'#10+
    '    .subtitle {'#10+
    '      text-align: center;'#10+
    '      color: #888;'#10+
    '      margin-bottom: 30px;'#10+
    '      font-size: 1.1em;'#10+
    '    }'#10+
    '    .info-grid {'#10+
    '      display: grid;'#10+
    '      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));'#10+
    '      gap: 15px;'#10+
    '      margin-bottom: 30px;'#10+
    '    }'#10+
    '    .info-card {'#10+
    '      background: rgba(255,255,255,0.08);'#10+
    '      padding: 20px;'#10+
    '      border-radius: 12px;'#10+
    '      border-left: 4px solid #e94560;'#10+
    '      transition: transform 0.3s, box-shadow 0.3s;'#10+
    '    }'#10+
    '    .info-card:hover {'#10+
    '      transform: translateY(-5px);'#10+
    '      box-shadow: 0 10px 25px rgba(233,69,96,0.2);'#10+
    '    }'#10+
    '    .info-card h3 {'#10+
    '      color: #e94560;'#10+
    '      font-size: 0.9em;'#10+
    '      text-transform: uppercase;'#10+
    '      letter-spacing: 1px;'#10+
    '      margin-bottom: 8px;'#10+
    '    }'#10+
    '    .info-card p {'#10+
    '      font-size: 1.2em;'#10+
    '      font-weight: 600;'#10+
    '    }'#10+
    '    .status-badge {'#10+
    '      display: inline-block;'#10+
    '      padding: 5px 15px;'#10+
    '      border-radius: 20px;'#10+
    '      font-size: 0.85em;'#10+
    '      font-weight: 600;'#10+
    '    }'#10+
    '    .status-online {'#10+
    '      background: rgba(46,204,113,0.2);'#10+
    '      color: #2ecc71;'#10+
    '    }'#10+
    '    .interactive-section {'#10+
    '      margin-top: 30px;'#10+
    '      padding: 25px;'#10+
    '      background: rgba(255,255,255,0.03);'#10+
    '      border-radius: 15px;'#10+
    '    }'#10+
    '    .interactive-section h2 {'#10+
    '      color: #e94560;'#10+
    '      margin-bottom: 20px;'#10+
    '      font-size: 1.4em;'#10+
    '    }'#10+
    '    .btn {'#10+
    '      background: linear-gradient(135deg, #e94560, #c0392b);'#10+
    '      color: white;'#10+
    '      border: none;'#10+
    '      padding: 12px 30px;'#10+
    '      border-radius: 25px;'#10+
    '      cursor: pointer;'#10+
    '      font-size: 1em;'#10+
    '      font-weight: 600;'#10+
    '      transition: all 0.3s;'#10+
    '      margin: 5px;'#10+
    '    }'#10+
    '    .btn:hover {'#10+
    '      transform: scale(1.05);'#10+
    '      box-shadow: 0 5px 20px rgba(233,69,96,0.4);'#10+
    '    }'#10+
    '    .counter-display {'#10+
    '      font-size: 3em;'#10+
    '      text-align: center;'#10+
    '      margin: 20px 0;'#10+
    '      color: #e94560;'#10+
    '      font-weight: 700;'#10+
    '      text-shadow: 0 0 20px rgba(233,69,96,0.3);'#10+
    '    }'#10+
    '    .color-box {'#10+
    '      width: 100%;'#10+
    '      height: 100px;'#10+
    '      border-radius: 12px;'#10+
    '      margin-top: 15px;'#10+
    '      transition: background 0.5s;'#10+
    '      display: flex;'#10+
    '      align-items: center;'#10+
    '      justify-content: center;'#10+
    '      font-weight: 600;'#10+
    '    }'#10+
    '    .footer {'#10+
    '      text-align: center;'#10+
    '      margin-top: 30px;'#10+
    '      color: #666;'#10+
    '      font-size: 0.9em;'#10+
    '    }'#10+
    '    @keyframes pulse {'#10+
    '      0%, 100% { opacity: 1; }'#10+
    '      50% { opacity: 0.5; }'#10+
    '    }'#10+
    '    .pulse {'#10+
    '      animation: pulse 2s infinite;'#10+
    '    }'#10+
    '  </style>'#10+
    '</head>'#10+
    '<body>'#10+
    '  <div class="container">'#10+
    '    <h1>🚀 Pascal HTTP Server</h1>'#10+
    '    <p class="subtitle">WinSocket.pas ile yazılmış özel TCP/IP yığını üzerinde çalışıyor</p>'#10+
    '    '#10+
    '    <div class="info-grid">'#10+
    '      <div class="info-card">'#10+
    '        <h3>Server Durumu</h3>'#10+
    '        <p><span class="status-badge status-online pulse">● ÇEVRİMİÇİ</span></p>'#10+
    '      </div>'#10+
    '      <div class="info-card">'#10+
    '        <h3>Protokol</h3>'#10+
    '        <p>HTTP/1.1 over TCP</p>'#10+
    '      </div>'#10+
    '      <div class="info-card">'#10+
    '        <h3>Dil</h3>'#10+
    '        <p>Free Pascal (FPC)</p>'#10+
    '      </div>'#10+
    '      <div class="info-card">'#10+
    '        <h3>Stack</h3>'#10+
    '        <p>Özel TCP/IP (WinSocket)</p>'#10+
    '      </div>'#10+
    '    </div>'#10+
    '    '#10+
    '    <div class="interactive-section">'#10+
    '      <h2>🎮 Etkileşimli Bölüm</h2>'#10+
    '      <p style="text-align:center; margin-bottom:15px;">Aşağıdaki butonlar JavaScript ile çalışır (client-side):</p>'#10+
    '      '#10+
    '      <div class="counter-display" id="counter">0</div>'#10+
    '      <div style="text-align:center;">'#10+
    '        <button class="btn" onclick="increment()">➕ Arttır</button>'#10+
    '        <button class="btn" onclick="decrement()">➖ Azalt</button>'#10+
    '        <button class="btn" onclick="resetCounter()">🔄 Sıfırla</button>'#10+
    '      </div>'#10+
    '      '#10+
    '      <div style="margin-top:25px; text-align:center;">'#10+
    '        <p style="margin-bottom:10px;">Renk Değiştirici:</p>'#10+
    '        <button class="btn" onclick="changeColor("#e94560")">Kırmızı</button>'#10+
    '        <button class="btn" onclick="changeColor("#3498db")">Mavi</button>'#10+
    '        <button class="btn" onclick="changeColor("#2ecc71")">Yeşil</button>'#10+
    '        <button class="btn" onclick="changeColor("#f39c12")">Turuncu</button>'#10+
    '        <button class="btn" onclick="changeColor("#9b59b6")">Mor</button>'#10+
    '      </div>'#10+
    '      <div class="color-box" id="colorBox" style="background:#e94560;">'#10+
    '        Renk Kutusu'#10+
    '      </div>'#10+
    '    </div>'#10+
    '    '#10+
    '    <div class="footer">'#10+
    '      <p>© 2026 Pascal TCP/IP Stack | <span id="clock"></span></p>'#10+
    '    </div>'#10+
    '  </div>'#10+
    '  '#10+
    '  <script>'#10+
    '    let count = 0;'#10+
    '    '#10+
    '    function increment() {'#10+
    '      count++;'#10+
    '      updateCounter();'#10+
    '    }'#10+
    '    '#10+
    '    function decrement() {'#10+
    '      count--;'#10+
    '      updateCounter();'#10+
    '    }'#10+
    '    '#10+
    '    function resetCounter() {'#10+
    '      count = 0;'#10+
    '      updateCounter();'#10+
    '    }'#10+
    '    '#10+
    '    function updateCounter() {'#10+
    '      const el = document.getElementById("counter");'#10+
    '      el.textContent = count;'#10+
    '      el.style.transform = "scale(1.2)";'#10+
    '      setTimeout(() => el.style.transform = "scale(1)", 150);'#10+
    '    }'#10+
    '    '#10+
    '    function changeColor(color) {'#10+
    '      const box = document.getElementById("colorBox");'#10+
    '      box.style.background = color;'#10+
    '      box.style.boxShadow = `0 0 30px ${color}40`;'#10+
    '    }'#10+
    '    '#10+
    '    function updateClock() {'#10+
    '      const now = new Date();'#10+
    '      document.getElementById("clock").textContent = now.toLocaleTimeString("tr-TR");'#10+
    '    }'#10+
    '    '#10+
    '    setInterval(updateClock, 1000);'#10+
    '    updateClock();'#10+
    '  </script>'#10+
    '</body>'#10+
    '</html>';

 HDR_200: PChar =
    'HTTP/1.1 200 OK'#13#10+
    'Content-Type: text/html; charset=utf-8'#13#10+
    'Connection: close'#13#10+
    'Content-Length: %d'#13#10+
    'Cache-Control: no-cache'#13#10+
    'Server: Pascal-HTTP/1.0'#13#10+
    #13#10;

  // 404 Header template
  HDR_404: PChar = 
    'HTTP/1.1 404 Not Found'#13#10+
    'Content-Type: text/html; charset=utf-8'#13#10+
    'Connection: close'#13#10+
    'Content-Length: %d'#13#10+
    'Server: Pascal-HTTP/1.0'#13#10+
    #13#10;

  // JSON Header template
  HDR_JSON: PChar = 
    'HTTP/1.1 200 OK'#13#10+
    'Content-Type: application/json; charset=utf-8'#13#10+
    'Connection: close'#13#10+
    'Content-Length: %d'#13#10+
    'Server: Pascal-HTTP/1.0'#13#10+
    #13#10;

   // 404 Body
  BODY_404: PChar = 
    '<!DOCTYPE html><html><head><title>404</title></head>'#10+
    '<body style="font-family:sans-serif; text-align:center; padding-top:100px;">'#10+
    '<h1 style="font-size:4em; color:#e74c3c;">404</h1>'#10+
    '<p>Sayfa bulunamadi.</p>'#10+
    '</body></html>';

  // JSON Body
  BODY_JSON: PChar = '{"status":"ok","server":"Pascal-HTTP","version":"1.0"}';

  const
  // HTML Sayfalar� (sadece PChar olarak)
  HTML_HOME_1 = '<!DOCTYPE html>'#13#10 +
                '<html>'#13#10 +
                '<head>'#13#10 +
                '<meta charset="UTF-8">'#13#10 +
                '<title>Web Sunucu</title>'#13#10 +
                '<style>'#13#10 +
                'body { font-family: Arial; margin: 40px; background: #f0f0f0; }'#13#10 +
                'h1 { color: #333; }'#13#10 +
                '.container { background: white; padding: 20px; border-radius: 5px; }'#13#10 +
                'a { color: #0066cc; text-decoration: none; }'#13#10 +
                'a:hover { text-decoration: underline; }'#13#10 +
                '</style>'#13#10 +
                '</head>'#13#10 +
                '<body>'#13#10 +
                '<div class="container">'#13#10 +
                '<h1>Ho�geldiniz!</h1>'#13#10 +
                '<p>Delphi Kernel Web Sunucusu</p>'#13#10 +
                '<p>IP: 10.0.2.15 | Port: 80</p>'#13#10 +
                '<h2>Sayfalar:</h2>'#13#10 +
                '<ul>'#13#10 +
                '<li><a href="/">Anasayfa</a></li>'#13#10 +
                '<li><a href="/hakkinda">Hakk�nda</a></li>'#13#10 +
                '<li><a href="/status">Durum</a></li>'#13#10 +
                '<li><a href="/mjpeg">Canl� MJPEG Stream</a></li>'#13#10 +
                '</ul>'#13#10 +
                '</div>'#13#10 +
                '</body>'#13#10 +
                '</html>';

   HTML_ABOUT = '<html>'#13#10 +
               '<head>'#13#10 +
               '<meta charset="UTF-8">'#13#10 +
               '<title>Hakk�nda</title>'#13#10 +
               '<style>'#13#10 +
               'body { font-family: Arial; margin: 40px; background: #f0f0f0; }'#13#10 +
               '.container { background: white; padding: 20px; border-radius: 5px; }'#13#10 +
               'a { color: #0066cc; }'#13#10 +
               '</style>'#13#10 +
               '</head>'#13#10 +
               '<body>'#13#10 +
               '<div class="container">'#13#10 +
               '<h1>Hakk�nda</h1>'#13#10 +
               '<p>Bu web sunucu Delphi kernel modunda yaz�lm��t�r.</p>'#13#10 +
               '<p>TCP/IP �zerinden HTTP hizmeti sunmaktad�r.</p>'#13#10 +
               '<p><a href="/">� Geri D�n</a></p>'#13#10 +
               '</div>'#13#10 +
               '</body>'#13#10 +
               '</html>';


   // MJPEG Stream Header (Connection KAPATILMAZ, stream a��k kal�r)
  HDR_MJPEG: PChar =
    'HTTP/1.1 200 OK'#13#10+
    'Content-Type: multipart/x-mixed-replace; boundary=myboundary'#13#10+
    'Cache-Control: no-cache, private'#13#10+
    'Pragma: no-cache'#13#10+
    'Server: Pascal-MJPEG/1.0'#13#10+
    #13#10;

  FRAME_HEADER: PChar =
    '--myboundary'#13#10+
    'Content-Type: image/bmp'#13#10+
    'Content-Length: %d'#13#10+
    #13#10;


type
  PHTTPServerData = ^THTTPServerData;
  THTTPServerData = Object
  public
    ServerSock: PSocket;
    IsRunning: Boolean;
    ThreadID: LongWord;

    // GUI Controls
    BtnStart: PButton;
    BtnStop: PButton;
    LblStatus: PLabel;
    LblPort: PLabel;
    LogPanel: PPanel;

    JpegBuf: PByteArray;
    JpegSize: Integer;

    // Log buffer
    LogLines: array[0..MAX_LOG_LINES-1] of array[0..LOG_LINE_LEN-1] of Char;
    LogCount: Integer;
    procedure StreamMJPEG(ClientSock: PSocket);
    procedure CaptureFrameToJpeg();
    procedure HandleClient(ClientSock: PSocket);
    procedure AddLog(const Msg: PChar);
    procedure StartServer();
    procedure StopServer();
  end;

procedure OpenHTTPServerForm;
procedure PollServer;

var
  HTTPServerData1:THTTPServerData;

implementation

type

  TBitmapFileHeader = packed record
    bfType: Word;        // 'BM' ($4D42)
    bfSize: LongWord;    // Toplam dosya boyutu
    bfReserved1: Word;   // 0
    bfReserved2: Word;   // 0
    bfOffBits: LongWord; // Piksel verisinin ba�lad��� konum (54 byte)
  end;

  TBitmapInfoHeader = packed record
    biSize: LongWord;          // Ba�l�k boyutu (40 byte)
    biWidth: LongInt;          // Geni�lik
    biHeight: LongInt;         // Y�kseklik (Negatif = Top-Down)
    biPlanes: Word;            // 1
    biBitCount: Word;          // Pixel ba��na bit (24-bit)
    biCompression: LongWord;   // 0 (S�k��t�rmas�z)
    biSizeImage: LongWord;     // Piksel veri boyutu
    biXPelsPerMeter: LongInt;  // 0
    biYPelsPerMeter: LongInt;  // 0
    biClrUsed: LongWord;       // 0
    biClrImportant: LongWord;  // 0
  end;

{=============================================================================
  LOG HELPERS
=============================================================================}

procedure THTTPServerData.AddLog(const Msg: PChar);
var
  i: Integer;
  TimeBuf: array[0..15] of Char;
  FullMsg: array[0..LOG_LINE_LEN-1] of Char;
begin


  // Build: "[HH:MM:SS] Msg"
  // TimeToStr yoksa sabit string kullan
  StrCopy(@FullMsg[0], '[');
  // Saat bilgisi yoksa atla
  StrAppend(@FullMsg[0], Msg);

  if LogCount < MAX_LOG_LINES then
  begin
    StrCopy(@LogLines[LogCount][0], @FullMsg[0]);
    Inc(LogCount);
  end
  else
  begin
    // Shift up
    for i := 0 to MAX_LOG_LINES - 2 do
      StrCopy(@LogLines[i][0], @LogLines[i+1][0]);
    StrCopy(@LogLines[MAX_LOG_LINES-1][0], @FullMsg[0]);
  end;

  // Redraw log panel
  if LogPanel <> nil then
    RelayoutForm(PForm(LogPanel^.Parent));
end;

{=============================================================================
  NON-BLOCKING ACCEPT
=============================================================================}



{=============================================================================
  HTTP REQUEST PARSER
=============================================================================}

function ParseHTTPMethod(const Request: PChar): PChar;
var
  i: Integer;
  Method: array[0..7] of Char;
begin
  i := 0;
  while (Request[i] <> ' ') and (Request[i] <> #0) and (i < 7) do
  begin
    Method[i] := Request[i];
    Inc(i);
  end;
  Method[i] := #0;
  Result := StrNew(@Method[0]);
end;

function ParseHTTPPath(const Request: PChar): PChar;
var
  i, j: Integer;
  Path: array[0..255] of Char;
begin
  // Skip method
  i := 0;
  while (Request[i] <> ' ') and (Request[i] <> #0) do Inc(i);
  if Request[i] = ' ' then Inc(i);

  // Read path
  j := 0;
  while (Request[i] <> ' ') and (Request[i] <> #0) and (Request[i] <> #13) and (j < 255) do
  begin
    Path[j] := Request[i];
    Inc(i);
    Inc(j);
  end;
  Path[j] := #0;

  Result := StrNew(@Path[0]);
end;


{=============================================================================
  HANDLE CLIENT (with logging)
=============================================================================}

function FastIntToPChar(Val: Integer; Dest: PChar): Integer;
var
  Buf: array[0..11] of Char;
  I, Len, Digit: Integer;
  IsNegative: Boolean;
begin
  if Val = 0 then
  begin
    Dest[0] := '0';
    Result:=1;
    Exit;
  end;

  IsNegative := Val < 0;
  if IsNegative then Val := -Val;

  I := 0;
  while Val > 0 do
  begin
    Digit := Val mod 10;
    Buf[I] := Char(Ord('0') + Digit);
    Inc(I);
    Val := Val div 10;
  end;

  Len := 0;
  if IsNegative then
  begin
    Dest[Len] := '-';
    Inc(Len);
  end;

  // Tersi y�nde kopyala (basamak s�ras�n� d�zelt)
  while I > 0 do
  begin
    Dec(I);
    Dest[Len] := Buf[I];
    Inc(Len);
  end;

  Result := Len;
end;

// RTL ba��ms�z PChar formatlama (Yaz�lan toplam karakter say�s�n� d�ner)
function SimpleFormatPChar(Dest: PChar; Template: PChar; ContentLength: Integer): Integer;
var
  Src, Dst: PChar;
  NumLen: Integer;
begin
  Src := Template;
  Dst := Dest;

  while Src^ <> #0 do
  begin
    // '%d' deseni yakaland� m�?
    if (Src^ = '%') and ((Src + 1)^ = 'd') then
    begin
      Inc(Src, 2); // '%d' karakterlerini atla
      NumLen := FastIntToPChar(ContentLength, Dst); // Say�y� yaz
      Inc(Dst, NumLen); // Pointer'� yaz�lan basamak kadar kayd�r
    end
    else
    begin
      Dst^ := Src^;
      Inc(Dst);
      Inc(Src);
    end;
  end;

  Dst^ := #0; // Null-terminator ekle
  Result := Dst - Dest; // Toplam yaz�lan karakter uzunlu�u
end;


function ScreenToRGB(var RGBBuffer: PByteArray; Width, Height: Integer): Integer;
var
  RowSize, i, j, Offset, BufOffset: Integer;
  SrcX, SrcY: Integer;
  ScaleX, ScaleY: Single;
  R, G, B: Byte;
begin
  RowSize := (Width * 3 + 3) and not 3;
  Result := RowSize * Height;

  RGBBuffer := PByteArray(MemAlloc(Result));
  if RGBBuffer = nil then
  begin
    Result := 0;
    Exit;
  end;

  BufOffset := 0;

  ScaleX := SCREEN_WIDTH / Width;
  ScaleY := SCREEN_HEIGHT / Height;

  // BMP format nda sat rlar a a  dan yukar ya yaz l r
 for i := 0 to Height - 1 do  // ters de il, d z y n
 begin
  for j := 0 to Width - 1 do
  begin
    SrcX := Trunc(j * ScaleX);
    SrcY := Trunc(i * ScaleY); // ekran n d z taraf

    Offset := (SrcY * SCREEN_WIDTH + SrcX) * 3;

    B := Screen_Buffer[Offset];
    G := Screen_Buffer[Offset + 1];
    R := Screen_Buffer[Offset + 2];

    RGBBuffer[BufOffset + j * 3 + 0] := R;
    RGBBuffer[BufOffset + j * 3 + 1] := G;
    RGBBuffer[BufOffset + j * 3 + 2] := B; // JPEG i in RGB s ras 
  end;

  // Padding (JPEG i in genelde gerek yok ama istersen s f rla)
  for j := Width * 3 to RowSize - 1 do
    RGBBuffer[BufOffset + j] := 0;

  Inc(BufOffset, RowSize);
 end;
end;




procedure THTTPServerData.CaptureFrameToJpeg();
var
 PixelData: PByteArray;
 PixelSize: Integer;
begin

 ScreenToRGB(PixelData,200 ,200);
 JpegSize := JPEG_Encode_Stream(PixelData,200,200,75,JpegBuf);

 FreeMem(PixelData);
end;


function ScreenToBMPBuffer(out BMPBuffer: Pointer; out BMPSize: Integer; Width, Height: Integer): Boolean;
var
  FileHeader: TBmpFileHeader;
  InfoHeader: TBmpInfoHeader;
  RowSize, PixelDataSize, HeadersSize: Integer;
  PixelOffset, BufOffset, i, j: Integer;
  ByteBuf: PByteArray;
  SrcX, SrcY, Offset: Integer;
  ScaleX, ScaleY: Single;
  R, G, B: Byte;
begin
  Result := False;
  BMPBuffer := nil;
  BMPSize := 0;

  // 24-bit BMP i�in 4-byte sat�r hizalama (Padding) hesab�
  RowSize := (Width * 3 + 3) and not 3;
  PixelDataSize := RowSize * Height;
  HeadersSize := SizeOf(TBmpFileHeader) + SizeOf(TBmpInfoHeader); // 54 Byte
  BMPSize := HeadersSize + PixelDataSize;

  // T�m BMP (Header + Pikseller) i�in bellek ay�rma (MemAlloc veya GetMem)
  BMPBuffer:=MemAlloc( BMPSize);
  if BMPBuffer = nil then Exit;

  ByteBuf := PByteArray(BMPBuffer);

  // 1. File Header Haz�rl���
  FillChar(FileHeader, SizeOf(FileHeader), 0);
  FileHeader.bfType := $4D42; // 'BM'
  FileHeader.bfOffBits := HeadersSize;
  FileHeader.bfSize := BMPSize;

  // 2. Info Header Haz�rl���
  FillChar(InfoHeader, SizeOf(InfoHeader), 0);
  InfoHeader.biSize := SizeOf(TBmpInfoHeader); // 40
  InfoHeader.biWidth := Width;
  InfoHeader.biHeight := Height; // Pozitif: Bottom-up BMP
  InfoHeader.biPlanes := 1;
  InfoHeader.biBitCount := 24;
  InfoHeader.biSizeImage := PixelDataSize;

  // Header'lar� tamponun ba�lang�c�na kopyala
  Move(FileHeader, ByteBuf^[0], SizeOf(FileHeader));
  Move(InfoHeader, ByteBuf^[SizeOf(FileHeader)], SizeOf(InfoHeader));

  // 3. Screen_Buffer'dan Okuma ve �l�ekleme
  ScaleX := SCREEN_WIDTH / Width;
  ScaleY := SCREEN_HEIGHT / Height;
  PixelOffset := HeadersSize;

  for i := 0 to Height - 1 do
  begin
    BufOffset := PixelOffset + (i * RowSize);

    for j := 0 to Width - 1 do
    begin
      SrcX := Trunc(j * ScaleX);
      SrcY := Trunc(i * ScaleY);

      Offset := (SrcY * SCREEN_WIDTH + SrcX) * 3;

      // Screen_Buffer'dan piksel de�erlerini al
      B := Screen_Buffer[Offset];
      G := Screen_Buffer[Offset + 1];
      R := Screen_Buffer[Offset + 2];

      // BMP format� BGR (Blue-Green-Red) s�ras�n� bekler
      ByteBuf^[BufOffset + j * 3 + 0] := B;
      ByteBuf^[BufOffset + j * 3 + 1] := G;
      ByteBuf^[BufOffset + j * 3 + 2] := R;
    end;

    // Sat�r sonundaki dolgu (padding) baytlar�n� s�f�rla
    for j := Width * 3 to RowSize - 1 do
      ByteBuf^[BufOffset + j] := 0;
  end;

  Result := True;
end;




function VesaToBMPBuffer(out BMPBuffer: Pointer; out BMPSize: Integer; Width, Height: Integer): Boolean;
var
  FileHeader: TBitmapFileHeader;
  InfoHeader: TBitmapInfoHeader;
  RowSize, PixelDataSize, HeadersSize: Integer;
  PixelOffset, BufOffset, i, j: Integer;
  ByteBuf: PByteArray;
  LFB: PByteArray;
  SrcX, SrcY, Offset: Integer;
  ScaleX, ScaleY: Single;
  R, G, B: Byte;
  ScreenWidth, ScreenHeight, Pitch: Integer;
begin
  Result := False;
  BMPBuffer := nil;
  BMPSize := 0;

  // Physical Framebuffer Adresi Kontrol�
  if (Vesa_Info.PhysBasePtr = 0) then Exit;

  // Ekran parametreleri (24-bit veya 32-bit VESA modlar� i�in)
  ScreenWidth := Vesa_Info.XResolution;
  ScreenHeight := Vesa_Info.YResolution;
  
  // Sat�r ad�m� (BytesPerScanLine varsa onu kullan, yoksa geni�lik * bayt hesab� yap)
  if Vesa_Info.BytesPerScanLine <> 0 then
    Pitch := Vesa_Info.BytesPerScanLine
  else
    Pitch := ScreenWidth * (Vesa_Info.BitsPerPixel div 8);

  LFB := PByteArray(Pointer(Vesa_Info.PhysBasePtr));

  // 24-bit BMP i�in 4-byte sat�r hizalama (Padding) hesab�
  RowSize := (Width * 3 + 3) and not 3;
  PixelDataSize := RowSize * Height;
  HeadersSize := SizeOf(TBitmapFileHeader) + SizeOf(TBitmapInfoHeader); // 54 Byte
  BMPSize := HeadersSize + PixelDataSize;

  // Bellek Ay�rma (MemAlloc veya GetMem)
  GetMem(BMPBuffer, BMPSize);
  if BMPBuffer = nil then Exit;

  ByteBuf := PByteArray(BMPBuffer);

  // 1. File Header Haz�rl���
  FillChar(FileHeader, SizeOf(FileHeader), 0);
  FileHeader.bfType := $4D42; // 'BM'
  FileHeader.bfOffBits := HeadersSize;
  FileHeader.bfSize := BMPSize;

  // 2. Info Header Haz�rl���
  FillChar(InfoHeader, SizeOf(InfoHeader), 0);
  InfoHeader.biSize := SizeOf(TBitmapInfoHeader); // 40
  InfoHeader.biWidth := Width;
  
  // !!! RESM� D�Z ��ZMEK ���N Y�KSEKL��� NEGAT�F YAPIYORUZ !!!
  InfoHeader.biHeight := -Height; 
  
  InfoHeader.biPlanes := 1;
  InfoHeader.biBitCount := 24;
  InfoHeader.biSizeImage := PixelDataSize;

  // Header'lar� tamponun ba�lang�c�na kopyala
  Move(FileHeader, ByteBuf^[0], SizeOf(FileHeader));
  Move(InfoHeader, ByteBuf^[SizeOf(FileHeader)], SizeOf(InfoHeader));

  // 3. VESA LFB'den Okuma ve �l�ekleme
  ScaleX := ScreenWidth / Width;
  ScaleY := ScreenHeight / Height;
  PixelOffset := HeadersSize;

  for i := 0 to Height - 1 do
  begin
    BufOffset := PixelOffset + (i * RowSize);

    for j := 0 to Width - 1 do
    begin
      SrcX := Trunc(j * ScaleX);
      SrcY := Trunc(i * ScaleY);

      // Pitch (BytesPerScanLine) kullanarak LFB offset hesaplama
      if Vesa_Info.BitsPerPixel = 32 then
      begin
        // 32-bit VESA (BGRA / BGR0)
        Offset := (SrcY * Pitch) + (SrcX * 4);
        B := LFB^[Offset];
        G := LFB^[Offset + 1];
        R := LFB^[Offset + 2];
      end
      else
      begin
        // 24-bit VESA (BGR)
        Offset := (SrcY * Pitch) + (SrcX * 3);
        B := LFB^[Offset];
        G := LFB^[Offset + 1];
        R := LFB^[Offset + 2];
      end;

      // BMP format�na BGR s�ras�nda yaz
      ByteBuf^[BufOffset + j * 3 + 0] := B;
      ByteBuf^[BufOffset + j * 3 + 1] := G;
      ByteBuf^[BufOffset + j * 3 + 2] := R;
    end;

    // 4-Byte Sat�r Dolgusu (Padding)
    for j := Width * 3 to RowSize - 1 do
      ByteBuf^[BufOffset + j] := 0;
  end;

  Result := True;
end;

function CreateRandomBMPBuffer(out BMPBuffer: Pointer; out BMPSize: Integer; Width, Height: Integer): Boolean;
var
  FileHeader:TBMPFileHeader;
  InfoHeader: TBmpInfoHeader;
  RowSize, PixelDataSize, HeadersSize: Integer;
  PixelOffset, BufOffset, i, j: Integer;
  ByteBuf: PByteArray;
begin
  Result := False;
  BMPBuffer := nil;
  BMPSize := 0;

  // 24-bit BMP i�in 4-byte sat�r hizalama (Padding) hesab�
  RowSize := (Width * 3 + 3) and not 3;
  PixelDataSize := RowSize * Height;
  HeadersSize := SizeOf(TBmpFileHeader) + SizeOf(TBmpInfoHeader); // 54 Byte
  BMPSize := HeadersSize + PixelDataSize;

  // T�m BMP (Header + Pikseller) i�in tek par�a bellek ay�rma
  BMPBuffer:=MemAlloc( BMPSize);
  if BMPBuffer = nil then Exit;

  ByteBuf := PByteArray(BMPBuffer);

  // 1. File Header Haz�rl���
  FillChar(FileHeader, SizeOf(FileHeader), 0);
  FileHeader.bfType := $4D42; // 'BM'
  FileHeader.bfOffBits := HeadersSize;
  FileHeader.bfSize := BMPSize;

  // 2. Info Header Haz�rl���
  FillChar(InfoHeader, SizeOf(InfoHeader), 0);
  InfoHeader.biSize := SizeOf(TBmpInfoHeader); // 40
  InfoHeader.biWidth := Width;
  InfoHeader.biHeight := Height; // Pozitif: Bottom-up BMP
  InfoHeader.biPlanes := 1;
  InfoHeader.biBitCount := 24;
  InfoHeader.biSizeImage := PixelDataSize;

  // Header'lar� tamponun ba�lang�c�na kopyala
  Move(FileHeader, ByteBuf^[0], SizeOf(FileHeader));
  Move(InfoHeader, ByteBuf^[SizeOf(FileHeader)], SizeOf(InfoHeader));

  // 3. Piksel Verisini Rastgele Doldurma
 // Randomize;
  PixelOffset := HeadersSize; // Pikseller header'lardan hemen sonra ba�lar

  for i := 0 to Height - 1 do
  begin
    BufOffset := PixelOffset + (i * RowSize);

    for j := 0 to Width - 1 do
    begin
      ByteBuf^[BufOffset + j * 3 + 0] := Random(256); // Blue (B)
      ByteBuf^[BufOffset + j * 3 + 1] := Random(256); // Green (G)
      ByteBuf^[BufOffset + j * 3 + 2] := Random(256); // Red (R)
    end;

    // Sat�r sonundaki dolgu (padding) baytlar�n� s�f�rla
    for j := Width * 3 to RowSize - 1 do
      ByteBuf^[BufOffset + j] := 0;
  end;

  Result := True;
end;


procedure THTTPServerData.StreamMJPEG(ClientSock: PSocket);
var
  FrameHdrBuf: array[0..255] of Char;
  FrameHdrLen: Integer;
  IPStr: array[0..15] of Char;
  LogBuf: array[0..LOG_LINE_LEN-1] of Char;
begin
  if ClientSock = nil then Exit;

  IPToPCharSimple(ClientSock^.RemoteAddr, @IPStr[0], SizeOf(IPStr));

  StrCopy(@LogBuf[0], 'Stream START: ');
  StrAppend(@LogBuf[0], @IPStr[0]);
  AddLog(@LogBuf[0]);

  { MJPEG HTTP header }
  if send(ClientSock, HDR_MJPEG, StrLen(HDR_MJPEG), 0) = SOCKET_ERROR then
  begin
    close(ClientSock);
    Exit;
  end;

  while IsRunning do
  begin
    {========================================================
      EN �NEML� KISIM:
      Gelen FIN/RST paketlerini TCP stack'e i�let.
    ========================================================}
   // PollAllAdapters;

    { PollAllAdapters sonras� State de�i�mi� olabilir }
    if ClientSock = nil then
      Break;

    if ClientSock^.State <> SS_ESTABLISHED then
      Break;

    { JPEG olu�tur }
    JpegSize := 0;

    VesaToBMPBuffer(
      Pointer(JpegBuf),
      JpegSize,
      320,
      200
    );

    if JpegSize <= 0 then
    begin
      Thread_Yield;
      Continue;
    end;

    { Frame header }
    FrameHdrLen :=
      SimpleFormatPChar(
        @FrameHdrBuf[0],
        FRAME_HEADER,
        JpegSize
      );

    if send(
         ClientSock,
         @FrameHdrBuf[0],
         FrameHdrLen,
         0
       ) = SOCKET_ERROR then
      Break;

    { JPEG }
    if send(
         ClientSock,
         @JpegBuf[0],
         JpegSize,
         0
       ) = SOCKET_ERROR then
      Break;

    { Frame CRLF }
    if send(
         ClientSock,
         #13#10,
         2,
         0
       ) = SOCKET_ERROR then
      Break;

    FreeMem(JpegBuf);
    JpegBuf := nil;

    Thread_Yield;
  end;

  StrCopy(@LogBuf[0], 'Stream END: ');
  StrAppend(@LogBuf[0], @IPStr[0]);
  AddLog(@LogBuf[0]);

  { Soket h�l� bu fonksiyon taraf�ndan kullan�labiliyorsa kapat }
  if ClientSock <> nil then
    close(ClientSock);
end;


{

procedure THTTPServerData.StreamMJPEG(ClientSock: PSocket);
var
 // JpegBuf: array[0..65535] of Byte;   // 64KB frame buffer (VGA i�in yeterli)
 // JpegSize: Integer;
  FrameHdrBuf: array[0..255] of Char;
  FrameHdrLen: Integer;
  IPStr: array[0..15] of Char;
  LogBuf: array[0..LOG_LINE_LEN-1] of Char;
begin
  if ClientSock = nil then Exit;

  // �zleyici say�s�n� art�r
 // Inc(StreamClientCount);
  IPToPCharSimple(ClientSock^.RemoteAddr, @IPStr[0], SizeOf(IPStr));
  StrCopy(@LogBuf[0], 'Stream START: ');
  StrAppend(@LogBuf[0], @IPStr[0]);
  AddLog(@LogBuf[0]);

  // MJPEG HTTP header g�nder (Connection: close YOK! Stream a��k kalacak)
   if  send(ClientSock, HDR_MJPEG, StrLen(HDR_MJPEG), 0)  = SOCKET_ERROR then Exit;
                  // 
   while IsRunning and (ClientSock^.State = SS_ESTABLISHED) do
   begin

    //  PollAllAdapters;

    // Soket kapand�ysa veya istemci ba�lant�y� kestiyse ��k
    if ClientSock^.State <> SS_ESTABLISHED then Break;

     VesaToBMPBuffer(pointer(JpegBuf), JpegSize, 320, 200);

    if JpegSize <= 0 then
    begin
      // Frame haz�r de�ilse bekle (PIT/Delay kullanabilirsin)
      Thread_Yield;
      Continue;
    end;

    // 2) Boundary + Content-Length header g�nder
    FrameHdrLen := SimpleFormatPChar(@FrameHdrBuf[0], FRAME_HEADER, JpegSize);
    if send(ClientSock, @FrameHdrBuf[0], FrameHdrLen, 0) = SOCKET_ERROR then Break;

    // 3) JPEG binary data g�nder
    if send(ClientSock, @JpegBuf[0], JpegSize, 0) = SOCKET_ERROR then Break;

    // 4) Frame sonu CRLF
    if send(ClientSock, #13#10, 2, 0) = SOCKET_ERROR then Break;


    FreeMem(JpegBuf);

    // FPS kontrol� (~15 fps = 66ms). Kendi Delay rutinin varsa onu kullan.
    // �rnek: Delay(66); veya Pit_Sleep(66);
    Thread_Yield;
  end;

  // �zleyici ayr�ld�
 // Dec(StreamClientCount);
  StrCopy(@LogBuf[0], 'Stream END: ');
  StrAppend(@LogBuf[0], @IPStr[0]);
  AddLog(@LogBuf[0]);

  close(ClientSock);
end;


{
procedure THTTPServerData.StreamMJPEG(ClientSock: PSocket);
var
 // JpegBuf: array[0..65535] of Byte;   // 64KB frame buffer (VGA i�in yeterli)
 // JpegSize: Integer;
  FrameHdrBuf: array[0..255] of Char;
  FrameHdrLen: Integer;
  IPStr: array[0..15] of Char;
  LogBuf: array[0..LOG_LINE_LEN-1] of Char;
begin
  if ClientSock = nil then Exit;

  // �zleyici say�s�n� art�r
 // Inc(StreamClientCount);
  IPToPCharSimple(ClientSock^.RemoteAddr, @IPStr[0], SizeOf(IPStr));
  StrCopy(@LogBuf[0], 'Stream START: ');
  StrAppend(@LogBuf[0], @IPStr[0]);
  AddLog(@LogBuf[0]);

  // MJPEG HTTP header g�nder (Connection: close YOK! Stream a��k kalacak)
   if  send(ClientSock, HDR_MJPEG, StrLen(HDR_MJPEG), 0)  = SOCKET_ERROR then Exit;
                  // and (ClientSock^.State = SS_ESTABLISHED)
   while IsRunning  do
   begin

      PollAllAdapters;

    // Soket kapand�ysa veya istemci ba�lant�y� kestiyse ��k
    if ClientSock^.State <> SS_ESTABLISHED then Break;

     VesaToBMPBuffer(pointer(JpegBuf), JpegSize, 320, 200);

    if JpegSize <= 0 then
    begin
      // Frame haz�r de�ilse bekle (PIT/Delay kullanabilirsin)
      Thread_Yield;
      Continue;
    end;

    // 2) Boundary + Content-Length header g�nder
    FrameHdrLen := SimpleFormatPChar(@FrameHdrBuf[0], FRAME_HEADER, JpegSize);
    if send(ClientSock, @FrameHdrBuf[0], FrameHdrLen, 0) = SOCKET_ERROR then Break;

    // 3) JPEG binary data g�nder
    if send(ClientSock, @JpegBuf[0], JpegSize, 0) = SOCKET_ERROR then Break;

    // 4) Frame sonu CRLF
    if send(ClientSock, #13#10, 2, 0) = SOCKET_ERROR then Break;


    FreeMem(JpegBuf);

    // FPS kontrol� (~15 fps = 66ms). Kendi Delay rutinin varsa onu kullan.
    // �rnek: Delay(66); veya Pit_Sleep(66);
    Thread_Yield;
  end;

  // �zleyici ayr�ld�
 // Dec(StreamClientCount);
  StrCopy(@LogBuf[0], 'Stream END: ');
  StrAppend(@LogBuf[0], @IPStr[0]);
  AddLog(@LogBuf[0]);

  close(ClientSock);
end;

 }

procedure THTTPServerData.HandleClient(ClientSock: PSocket);
var
  RequestBuffer: array[0..4095] of Char;
  BytesRead: Integer;
  Method, Path: PChar;
  Body: PChar;
  HdrTpl: PChar;
  BodyLen: Integer;
  HdrBuf: array[0..1023] of Char;
  HdrLen: Integer;
  LogBuf: array[0..LOG_LINE_LEN-1] of Char;
  IPStr: array[0..15] of Char;
  PortStr: array[0..7] of Char;
begin
  if (ClientSock = nil)  then Exit;

  // Read request
  FillChar(RequestBuffer, SizeOf(RequestBuffer), 0);
  BytesRead := recv(ClientSock, @RequestBuffer[0], SizeOf(RequestBuffer) - 1);

  if BytesRead <= 0 then
  begin
    close(ClientSock);
    Exit;
  end;

  RequestBuffer[BytesRead] := #0;

  // Parse
  Method := ParseHTTPMethod(@RequestBuffer[0]);
  Path := ParseHTTPPath(@RequestBuffer[0]);

  // Log: "[IP:PORT] METHOD PATH"
  IPToPCharSimple(ClientSock^.RemoteAddr, @IPStr[0], SizeOf(IPStr));
  SysUtils.IntToPChar(ClientSock^.RemotePort, @PortStr[0]);

  StrCopy(@LogBuf[0], '[');
  StrAppend(@LogBuf[0], @IPStr[0]);
  StrAppend(@LogBuf[0], ':');
  StrAppend(@LogBuf[0], @PortStr[0]);
  StrAppend(@LogBuf[0], '] ');
  StrAppend(@LogBuf[0], Method);
  StrAppend(@LogBuf[0], ' ');
  StrAppend(@LogBuf[0], Path);
  AddLog(@LogBuf[0]);

  // Route handling
  if (StrCmp(Path, '/') = 0) or (StrCmp(Path, '/index.html') = 0) then
  begin
    Body := HTML_HOME_1;
    HdrTpl := HDR_200;
  end
  else
   if StrCmp(Path, '/mjpeg') = 0 then
  begin
    // MJPEG stream: ba�lant�y� burada y�net, normal response g�nderme
    StrDispose(Method);
    StrDispose(Path);
    StreamMJPEG(ClientSock);
    Exit;
  end
  else
  if (StrCmp(Path, '/hakkinda') = 0) then
  begin
    Body := HTML_ABOUT;
    HdrTpl := HDR_200;
  end
  else
  if (StrCmp(Path, '/status') = 0) then
  begin
    Body := HTML_ABOUT;
    HdrTpl := HDR_200;
  end
  else if StrCmp(Path, '/api/status') = 0 then
  begin
    Body := BODY_JSON;
    HdrTpl := HDR_JSON;
  end
  else
  begin
    Body := BODY_404;
    HdrTpl := HDR_404;
  end;

  // Send response
  BodyLen := StrLen(Body);
  HdrLen := SimpleFormatPChar(@HdrBuf[0], HdrTpl, BodyLen);

  send(ClientSock, @HdrBuf[0], HdrLen,  0);
  send(ClientSock, Body,       BodyLen, 0);

  StrDispose(Method);
  StrDispose(Path);
  close(ClientSock);
end;

{=============================================================================
  SERVER THREAD
=============================================================================}



{=============================================================================
  START / STOP
=============================================================================}


procedure ServerThreadFunc();
var
  ServerAddr: TSocketAddr;
  ClientSock: PSocket;
  ClientAddr: TSocketAddr;
  ClientAddrLen: Integer;
begin
  HTTPServerData1.AddLog('Server thread started');

   if HTTPServerData1.IsRunning then Exit;

  HTTPServerData1.ServerSock := socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if HTTPServerData1.ServerSock = nil then
  begin
    HTTPServerData1.AddLog('ERROR: socket() failed');
    Exit;
  end;

  ServerAddr.sin_family := AF_INET;
  ServerAddr.sin_port := SERVER_PORT;
  ServerAddr.sin_addr := inet_addr(SERVER_IP);

  if bind(HTTPServerData1.ServerSock, ServerAddr, SizeOf(TSocketAddr)) <> 0 then
  begin
    HTTPServerData1.AddLog('ERROR: bind() failed');
    FreeSocket(HTTPServerData1.ServerSock);
    HTTPServerData1.ServerSock := nil;
    Exit;
  end;

  if listen(HTTPServerData1.ServerSock, 5) <> 0 then
  begin
    HTTPServerData1.AddLog('ERROR: listen() failed');
    FreeSocket(HTTPServerData1.ServerSock);
    HTTPServerData1.ServerSock := nil;
    Exit;
  end;

  HTTPServerData1.IsRunning := True;
  StrCopy(@HTTPServerData1.LblStatus^.Caption[0], 'Status: RUNNING');
  HTTPServerData1.AddLog('Server started on 10.0.2.15:80');

  while HTTPServerData1.IsRunning do
  begin
    ClientSock := accept(HTTPServerData1.ServerSock, @ClientAddr, @ClientAddrLen);

    if ClientSock <> nil then
    begin
      HTTPServerData1.HandleClient(ClientSock);
    end;

    Thread_Yield;
  end;


  Close(HTTPServerData1.ServerSock);
  HTTPServerData1.AddLog('Server durduruldu.');
end;

procedure THTTPServerData.StartServer();
begin
   HTTPServerData1.ThreadID := BeginThread(@ServerThreadFunc, @HTTPServerData1, 'Http Server',PRIO_HIGH, TF_KERNEL);
   
   if HTTPServerData1.ThreadID=INVALID_HANDLE Then
      HTTPServerData1.AddLog('Threading not available � use PollServer()');
end;

procedure THTTPServerData.StopServer();
begin
  if not IsRunning then Exit;

  IsRunning := False;

  if ServerSock <> nil then
  begin
    close(ServerSock);
   // ServerSock := nil;
  end;


  Thread_Kill(ThreadID);

  StrCopy(@LblStatus^.Caption[0], 'Status: STOPPED');
  AddLog( 'Server stopped');
end;

{=============================================================================
  POLL SERVER (for non-threaded mode)
  Call this from your idle loop or timer
=============================================================================}

procedure PollServer;
var
  Data: PHTTPServerData;
  ClientSock: PSocket;
begin
  // Find the server form and its data
  // This is a simplified version � in practice you'd store Data globally
  // or iterate through forms
end;

{=============================================================================
  GUI EVENT HANDLERS
=============================================================================}

procedure BtnStartClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
begin



 HTTPServerData1.StartServer();
end;

procedure BtnStopClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
begin
  HTTPServerData1.StopServer();
end;

procedure BtnClearClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
begin


  HTTPServerData1.LogCount := 0;
 // RelayoutForm(F);
end;

{=============================================================================
  LOG PANEL DRAW
=============================================================================}

procedure LogPanelDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  Panel: PPanel;

  i: Integer;
  y: Integer;
  LineH: Integer;
  LineY: Integer;
  StartIdx: Integer;
  VisibleLines: Integer;
begin
  Panel := PPanel(Sender);

  // Background
  KFill(AbsX, AbsY, Panel^.Width, Panel^.Height, $00FFFFFF);

  // Border
  KRect(AbsX, AbsY, Panel^.Width, Panel^.Height, $00808080);

  LineH := FONT_H + 2;
  VisibleLines := (Panel^.Height - 8) div LineH;
  if VisibleLines < 1 then VisibleLines := 1;

  // Show last N lines (scroll to bottom)
  if HTTPServerData1.LogCount <= VisibleLines then
    StartIdx := 0
  else
    StartIdx := HTTPServerData1.LogCount - VisibleLines;

  y := AbsY + 4;
  for i := StartIdx to HTTPServerData1.LogCount - 1 do
  begin
    if y + LineH > AbsY + Panel^.Height - 4 then Break;

    // Alternate row colors
    if (i mod 2) = 0 then
      KFill(AbsX + 2, y, Panel^.Width - 4, LineH, $00F8F8F8)
    else
      KFill(AbsX + 2, y, Panel^.Width - 4, LineH, $00FFFFFF);

    KStr(AbsX + 6, y, @HTTPServerData1.LogLines[i][0], $00000000);
    y := y + LineH;
  end;
end;

{=============================================================================
  FORM DESTROY
=============================================================================}

procedure HTTPServerFormDestroy(Sender: PObject);
begin


  if HTTPServerData1.IsRunning then
    HTTPServerData1.StopServer();



end;

{=============================================================================
  OPEN FORM
=============================================================================}

procedure OpenHTTPServerForm;
var
  F: PForm;
   FileHandle: Integer;
  Toolbar: PPanel;
  Btn: PButton;
  LogArea: PPanel;
begin
  F := CreateForm('HTTP Server', 80, 60, 700, 500);
  if F = nil then Exit;

  F^.BorderStyle := bsWindow;
  F^.ShowSysButtons := True;
  F^.Color := clBtnFace;
  F^.BindDestroy(@HTTPServerFormDestroy);


  HTTPServerData1.IsRunning := False;
  HTTPServerData1.LogCount := 0;




 {  FileHandle := OpenFile('D:\output.jpg', FILE_READ);
  if FileHandle < 0 then Exit;

  HTTPServerData1.JpegSize := FileSize(FileHandle);
  if HTTPServerData1.JpegSize = 0 then
  begin
    CloseFile(FileHandle);
    Exit;
  end;

  HTTPServerData1.JpegBuf := (MemAlloc(HTTPServerData1.JpegSize));
  if HTTPServerData1.JpegBuf = nil then
  begin
    CloseFile(FileHandle);
    Exit;
  end;

  ReadFile(FileHandle, HTTPServerData1.JpegBuf, HTTPServerData1.JpegSize);

  CloseFile(FileHandle);

 }



  { --- Toolbar (Top) --- }
  Toolbar := CreatePanel(PObject(F), 0, 0, 0, 44, alTop);
  Toolbar^.Color := clBtnFace;
  Toolbar^.BorderWidth := 0;

  // Start Button
  HTTPServerData1.BtnStart := CreateButton(PObject(Toolbar), 'Start', 8, 8, 70, 28, alNone);
  HTTPServerData1.BtnStart^.BindMouseUp(@BtnStartClick);

  // Stop Button
  HTTPServerData1.BtnStop := CreateButton(PObject(Toolbar), 'Stop', 86, 8, 70, 28, alNone);
  HTTPServerData1.BtnStop^.BindMouseUp(@BtnStopClick);

  // Clear Button
  Btn := CreateButton(PObject(Toolbar), 'Clear', 164, 8, 70, 28, alNone);
  Btn^.BindMouseUp(@BtnClearClick);

  // Status Label
  HTTPServerData1.LblStatus := CreateLabel(PObject(Toolbar), 'Status: STOPPED', 250, 12, 150, 20, alNone);

  // Port Label
  HTTPServerData1.LblPort := CreateLabel(PObject(Toolbar), SERVER_IP, 420, 12, 200, 20, alNone);

  { --- Log Panel (Client area) --- }
  LogArea := CreatePanel(PObject(F), 0, 0, 0, 0, alClient);
  LogArea^.Color := $00FFFFFF;
  LogArea^.BorderWidth := 1;
  LogArea^.BorderColor := $00808080;
  LogArea^.BindPaint(@LogPanelDraw);
  HTTPServerData1.LogPanel := LogArea;

  // Initial log
  HTTPServerData1.AddLog('HTTP Server ready. Click Start to begin.');
end;

end.

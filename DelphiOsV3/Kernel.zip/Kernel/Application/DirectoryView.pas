unit DirectoryView;

interface

uses
  SysUtils, Memory, Draw32, Fat32,Vesa,Math, GUI, GUIControls, Messages,
  DrawIcons;

const
  FT_FOLDER = 0;
  FT_EXE    = 1;
  FT_BMP    = 2;
  FT_TXT    = 3;
  FT_PAS    = 4;
  FT_OTHER  = 5;
  FT_WAVE   = 6;
  FT_CP8    = 7;
  FT_JPG    = 8;


type
  TDirViewExecuteProc = procedure(const FileName, FilePath: PChar; FileType: Integer);

  PDirViewData = ^TDirViewData;
  TDirViewData = record
    CurrentPath: array[0..255] of Char;
    LV: PListView;
    EdSearch: PEdit;
    EdFileName: PEdit;
    FilterCombo: PComboBox;
    InfoPanel: PPanel;
    LblInfoName, LblInfoSize, LblInfoType, LblInfoDate: PLabel;
    BtnBack, BtnForward, BtnUp, BtnRefresh: PButton;
    LblPath: PLabel;
    History: array[0..15] of array[0..255] of Char;
    HistoryPos, HistoryCount: Integer;
    FilterPattern: array[0..15] of Char;
    SearchText: array[0..63] of Char;
    OnExecute: TDirViewExecuteProc;
    { --- Gorsel bilesenler (ikon kutusu vb.) --- }
    IconPanel: PPanel;
    CurrentFileType: Integer;   { -1 = secim yok }
  end;

function CreateDirectoryView(const StartPath: PChar): Boolean;
procedure DirectoryViewRefresh(Form: PForm);
function DirectoryViewGetSelectedFile(Form: PForm): PChar;
function DirectoryViewGetSelectedPath(Form: PForm): PChar;
function DetectFileType(const Name: PChar; IsDir: Boolean=False): Integer;

implementation

Uses ImageView,WavPlayer,Sounds,HexEditor,TextEditor,GameChip8,ExeFile;


const
  { --- Yerlesim sabitleri (oranli / tutarli boslukla)  --- }
  DV_TOOLBAR_H  = 34;   { ust arac cubugu yuksekligi }
  DV_STATUS_H   = 34;   { alt durum cubugu yuksekligi }
  DV_INFO_W     = 190;  { sag bilgi panelinin sabit genisligi }
  DV_MARGIN     = 10;   { genel kenar bosluğu }
  DV_BTN_W      = 30;   { arac cubugu buton genisligi }
  DV_BTN_H      = 24;   { arac cubugu buton yuksekligi }
  DV_BTN_GAP    = 4;    { butonlar arasi bosluk }
  DV_ICON_BOX   = 64;   { bilgi panelindeki buyuk ikon kutusu boyutu }
  DV_HEADER_H   = 24;   { bilgi paneli baslik cubugu yuksekligi }

{=============================================================================}
{ Yardimci: Dosya uzantisi & tip belirleme                                    }
{=============================================================================}

function GetFileExt(const Name: PChar): PChar;
var
  i, len: Integer;
begin
  Result := nil;
  len := StrLen(Name);
  for i := len - 1 downto 0 do
    if Name[i] = '.' then
    begin
      Result := @Name[i + 1];
      Exit;
    end;
end;

function UpCh(Ch: Char): Char;
begin
  if (Ch >= 'a') and (Ch <= 'z') then
    Result := Chr(Ord(Ch) - 32)
  else
    Result := Ch;
end;

function StrIEqual(P1, P2: PChar): Boolean;
begin
  Result := False;
  while (P1^ <> #0) and (P2^ <> #0) do
  begin
    if (P1^ <> P2^) and (Abs(Ord(P1^) - Ord(P2^)) <> 32) then Exit;
    Inc(P1); Inc(P2);
  end;
  Result := (P1^ = #0) and (P2^ = #0);
end;

function DetectFileType(const Name: PChar; IsDir: Boolean=False): Integer;
var
  Ext: PChar;
begin
  if IsDir then begin Result := FT_FOLDER; Exit; end;
  Ext := GetFileExt(Name);
  if Ext = nil then begin Result := FT_OTHER; Exit; end;
  if StrIEqual(Ext, 'EXE') then Result := FT_EXE
  else if StrIEqual(Ext, 'BMP') then Result := FT_BMP
  else if StrIEqual(Ext, 'TXT') then Result := FT_TXT
  else if StrIEqual(Ext, 'INI') then Result := FT_TXT
  else if StrIEqual(Ext, 'PAS') then Result := FT_PAS
  else if StrIEqual(Ext, 'WAV') then Result := FT_WAVE
  else if StrIEqual(Ext, 'CP8') then Result := FT_CP8
  else if StrIEqual(Ext, 'JPG') then Result := FT_JPG
  else Result := FT_OTHER;
end;

function FileTypeName(Typ: Integer): PChar;
begin
  case Typ of
    FT_FOLDER: Result := 'Klasor';
    FT_EXE:    Result := 'Uygulama';
    FT_BMP:    Result := 'Resim (BMP)';
    FT_JPG:    Result := 'Resim (JPG)';
    FT_WAVE:   Result := 'Muzik';
    FT_TXT:    Result := 'Metin Belgesi';
    FT_PAS:    Result := 'Pascal Kaynak Kodu';
    FT_CP8:    Result := 'Games';
  else
    Result := 'Bilinmiyor';
  end;
end;

procedure FormatSize(Bytes: LongWord; Buf: PChar);
begin
  if Bytes < 1024 then
    StrCopy(Buf, '< 1 KB')
  else if Bytes < 1024 * 1024 then
  begin
    IntToPChar(Bytes div 1024, Buf);
    StrAppend(Buf, ' KB');
  end
  else
  begin
    IntToPChar(Bytes div (1024 * 1024), Buf);
    StrAppend(Buf, ' MB');
  end;
end;

procedure DirViewUpdatePathLabel(Data: PDirViewData);
begin
  if (Data = nil) or (Data^.LblPath = nil) then Exit;
  if Data^.CurrentPath[0] = #0 then
    StrCopy(@Data^.LblPath^.Caption[0], 'Bilgisayarim')
  else
  begin
    Data^.LblPath^.Caption[0] := #0;
    StrAppend(@Data^.LblPath^.Caption[0], @Data^.CurrentPath[0]);
  end;
end;

{ Bilgi panelini "hicbir sey secili degil" durumuna sifirlar - klasor
  degistirildiginde eski secim bilgisiyle kafa karistirmamak icin }
procedure DirViewClearInfoPanel(Data: PDirViewData);
begin
  if Data = nil then Exit;
  Data^.CurrentFileType := -1;
  if Data^.LblInfoName <> nil then StrCopy(@Data^.LblInfoName^.Caption[0], 'Bir oge secin');
  if Data^.LblInfoSize <> nil then StrCopy(@Data^.LblInfoSize^.Caption[0], '');
  if Data^.LblInfoType <> nil then StrCopy(@Data^.LblInfoType^.Caption[0], '');
  if Data^.LblInfoDate <> nil then StrCopy(@Data^.LblInfoDate^.Caption[0], '');
end;

{=============================================================================}
{ Toolbar & Navigasyon                                                        }
{=============================================================================}

procedure DirViewToolbarDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;

  KGradientV(AbsX, AbsY, W, H, $00F0EEE4, $00C8C4B8);
  KLineH(AbsX, AbsY, W, $00FCFCF8);                 { ust ince parlama }
  KLineH(AbsX, AbsY + H - 1, W, cl3DShadow);         { alt golge cizgisi }
end;

{ Arac cubugundaki adres/yol kutusu: gomulu (sunken) kutu + kucuk klasor ikonu }
procedure DirViewPathBarDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;

  KFill(AbsX, AbsY, W, H, clWhite);
  KRect3D(AbsX, AbsY, W, H, False);   { False = gomulu gorunum }

  { kucuk klasor simgesi }
  KFill(AbsX + 5, AbsY + 5, 3, 3, $0060A0F0);
  KFill(AbsX + 4, AbsY + 7, 15, 10, $0060A0F0);
  KRect(AbsX + 4, AbsY + 7, 15, 10, $00305078);
end;

{ Sag bilgi paneli icin gradyanli baslik cubugu }
procedure DirViewInfoHeaderDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  W, H: Integer;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;

  KGradientH(AbsX, AbsY, W, H, $00807860, $00504838);
  KStrCentered(AbsX, AbsY + (H - FONT_H) div 2, W, 'DOSYA BILGISI', clWhite);
  KLineH(AbsX, AbsY + H - 1, W, cl3DDkShadow);
end;

{ Secili ogenin turune gore basit, cizilmis bir ikon gosterir }
procedure DirViewFileIconDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  F: PForm;
  Data: PDirViewData;
  Typ, W, H, cx, cy: Integer;
   IsDriveView: Boolean;
begin
  W := PPanel(Sender)^.Width;
  H := PPanel(Sender)^.Height;

  Typ := -1;
  IsDriveView := False;
  F := FindRootForm(Sender);
  if F <> nil then
  begin
    Data := PDirViewData(F^.Control);
    if Data <> nil then
    begin
      Typ := Data^.CurrentFileType;
      IsDriveView := Data^.CurrentPath[0] = #0;
    end;
  end;


  { Kart (golgeli, yuvarlatilmis arka plan) }
  KRoundRect(AbsX, AbsY, W, H, 8, cl3DShadow, clWhite);

  cx := AbsX + (W div 2);
  cy := AbsY + (H div 2);


   if IsDriveView and (Typ <> -1) then
  begin
    { Disk kutusu }
    KFill(AbsX + 12, AbsY + 18, W - 24, H - 32, $00C0C0C0);
    KRect(AbsX + 12, AbsY + 18, W - 24, H - 32, $00808080);
    { Disk �st� (kapak) }
    KFill(AbsX + 18, AbsY + 10, W - 36, 12, $00606060);
    KRect(AbsX + 18, AbsY + 10, W - 36, 12, $00404040);
    { LED ����� }
    KFillCircle(AbsX + W - 22, AbsY + H - 22, 3, $0000FF00);
    Exit;
  end;

  case Typ of
    FT_FOLDER:
      begin
        KFill(AbsX + 10, AbsY + 16, 20, 8, $0060A0F0);
        KRect(AbsX + 10, AbsY + 16, 20, 8, $00305078);
        KFill(AbsX + 10, AbsY + 22, W - 20, H - 32, $0070B0FF);
        KRect(AbsX + 10, AbsY + 22, W - 20, H - 32, $00305078);
      end;
    FT_EXE:
      begin
        KRoundRect(AbsX + 14, AbsY + 14, W - 28, H - 28, 6, $00305078, $00909090);
        KFillCircle(cx, cy, 10, $00404040);
        KCircle(cx, cy, 10, clWhite);
      end;
    FT_BMP,FT_JPG:
      begin
        KRect(AbsX + 12, AbsY + 14, W - 24, H - 28, $00305078);
        KFill(AbsX + 13, AbsY + 15, W - 26, H - 30, $00E8F0FF);
        KFillCircle(AbsX + 22, AbsY + 26, 4, $0000C0FF);
        KFillTriangle(AbsX + 16, AbsY + H - 16, AbsX + W - 16, AbsY + H - 16,
                      cx, AbsY + 24, $0040A040);
      end;
    FT_TXT:
      begin
        KFill(AbsX + 16, AbsY + 12, W - 32, H - 24, clWhite);
        KRect(AbsX + 16, AbsY + 12, W - 32, H - 24, cl3DShadow);
        KLineH(AbsX + 22, AbsY + 22, W - 44, cl3DShadow);
        KLineH(AbsX + 22, AbsY + 30, W - 44, cl3DShadow);
        KLineH(AbsX + 22, AbsY + 38, W - 44, cl3DShadow);
      end;
    FT_PAS:
      begin
        KFill(AbsX + 16, AbsY + 12, W - 32, H - 24, $00FFF4E0);
        KRect(AbsX + 16, AbsY + 12, W - 32, H - 24, $00806020);
        KStrCentered(AbsX + 16, cy - (FONT_H div 2), W - 32, 'PAS', $00806020);
      end;
    FT_OTHER:
      begin
        KFill(AbsX + 16, AbsY + 12, W - 32, H - 24, clWhite);
        KRect(AbsX + 16, AbsY + 12, W - 32, H - 24, cl3DShadow);
      end;

     FT_CP8:
      begin
        KFill(AbsX + 16, AbsY + 12, W - 32, H - 24, clWhite);
        KRect(AbsX + 16, AbsY + 12, W - 32, H - 24, cl3DShadow);
      end;

  else
    begin
      { Secim yok: soluk, notrmuz bir kutu }
      KRect(AbsX + 16, AbsY + 16, W - 32, H - 32, cl3DLight);
    end;
  end;
end;


procedure DirViewUpdateNavButtons(Data: PDirViewData);
begin
  if Data = nil then Exit;
  if Data^.BtnBack    <> nil then Data^.BtnBack^.Enabled    := Data^.HistoryPos > 0;
  if Data^.BtnForward <> nil then Data^.BtnForward^.Enabled := Data^.HistoryPos < Data^.HistoryCount - 1;
  if Data^.BtnUp      <> nil then Data^.BtnUp^.Enabled      := Data^.CurrentPath[0] <> #0;
end;


function DirViewMatchesSearch(Data: PDirViewData; Name: PChar): Boolean;
var
  SLen, NLen, I, J: Integer;
  Match: Boolean;
begin
  if Data = nil then begin Result := False; Exit; end;

  SLen := StrLen(@Data^.SearchText[0]);
  if SLen = 0 then begin Result := True; Exit; end;

  NLen := StrLen(Name);
  if NLen < SLen then begin Result := False; Exit; end;

  Result := False;
  for I := 0 to NLen - SLen do
  begin
    Match := True;
    for J := 0 to SLen - 1 do
      if UpCh(Name[I + J]) <> UpCh(Data^.SearchText[J]) then
      begin
        Match := False;
        Break;
      end;
    if Match then
    begin
      Result := True;
      Exit;
    end;
  end;
end;




procedure DirectoryViewRefresh(Form: PForm);
var
  Data: PDirViewData;
  hFind: Integer;
  rec: TSearchRec;
  pathBuf: array[0..255] of Char;
  patt: array[0..31] of Char;
  searchLen: Integer;
  I:Integer;
  DriveLabel: array[0..15] of Char;
  ImgIndex:Integer;
begin
 if Form = nil then Exit;
  Data := PDirViewData(Form^.Control);
  if Data = nil then Exit;

  ListViewClear(Data^.LV);
  searchLen := StrLen(@Data^.SearchText[0]);

  { =========================================================
    S�R�C� L�STES� MODU (CurrentPath = '')
    ========================================================= }
  if Data^.CurrentPath[0] = #0 then
  begin
    for I := 0 to DriveCount - 1 do
    begin
      if Drives[I].Present then
      begin
        DriveLabel[0] := Drives[I].Letter;
        DriveLabel[1] := ':';
        DriveLabel[2] := '\';
        DriveLabel[3] := #0;

        if Drives[I].FileSystem=FS_FAT32 then
           ImgIndex:=Ord(itHDD)
        else
           ImgIndex:=Ord(itCDROM);

        if DirViewMatchesSearch(Data, @DriveLabel[0]) then
          ListViewAddItem(Data^.LV, @DriveLabel[0],ImgIndex ); // 2 = s�r�c� image index  itCDROM
      end;
    end;
    DirViewUpdatePathLabel(Data);
    DirViewUpdateNavButtons(Data);
    DirViewClearInfoPanel(Data);
    RelayoutForm(Form);
    Exit;
  end;

  { --- A�a��daki mevcut kodunuz aynen kal�yor --- }
  StrCopy(@pathBuf[0], @Data^.CurrentPath[0]);
  if pathBuf[StrLen(pathBuf)-1] <> '\' then
    StrAppend(@pathBuf[0], '\');

  { === 1. Dizinleri listele (her zaman tumu, arama dahil)'*' === }
 // StrCopy(@patt[0], );
  hFind := FindFirst(@pathBuf[0], @Data^.FilterPattern[0], ATTR_DIRECTORY or $3F, @rec);
  if hFind >= 0 then
  begin
    repeat
      if rec.IsDir and (rec.Name[0] <> '.') then
      begin
          if DirViewMatchesSearch(Data, rec.Name) then
          ListViewAddItem(Data^.LV, rec.Name,ord(itFolder));   //IfThen(rec.IsDir,1,0)
      end;
    until not FindNext(hFind, @rec);
    FindClose(hFind);
  end;

  // === 2. Dosyalari listele (filtre + arama uygula) ===
  StrCopy(@patt[0], @Data^.FilterPattern[0]);
  hFind := FindFirst(@pathBuf[0], @patt[0], 0, @rec);
  if hFind >= 0 then
  begin
    repeat
      if not rec.IsDir then
      begin
         if DirViewMatchesSearch(Data, rec.Name) then
          ListViewAddItem(Data^.LV, rec.Name,-1);  //  IfThen(rec.IsDir,1,0)IfThen(rec.IsDir,1,0)
      end;
    until not FindNext(hFind, @rec);
    FindClose(hFind);
  end;

  { Guncelle }
  DirViewUpdatePathLabel(Data);
  DirViewUpdateNavButtons(Data);
  DirViewClearInfoPanel(Data);    { yeni klasorde eski secim bilgisini gosterme }
  RelayoutForm(Form);
end;

function DirectoryViewGetSelectedFile(Form: PForm): PChar;
var
  Data: PDirViewData;
  Sel: Integer;
begin
  Result := nil;
  if Form = nil then Exit;
  Data := PDirViewData(Form^.Control);
  if Data = nil then Exit;
  if Data^.LV = nil then Exit;
  
  Sel := Data^.LV^.ItemIndex;
  if Sel < 0 then Exit;
  if Data^.LV^.Items = nil then Exit;
  if Data^.LV^.Items^[Sel] = nil then Exit;
  
  Result := Data^.LV^.Items^[Sel];
end;

function DirectoryViewGetSelectedPath(Form: PForm): PChar;
var
  Data: PDirViewData;
  SelName: PChar;
begin
  Result := nil;
  if Form = nil then Exit;
  Data := PDirViewData(Form^.Control);
  if Data = nil then Exit;
  
  SelName := DirectoryViewGetSelectedFile(Form);
  if SelName = nil then Exit;
  
  { Tam yol olustur }
  StrCopy(@Data^.SearchText[0], @Data^.CurrentPath[0]);  { gecici olarak SearchText kullan }
  if Data^.SearchText[StrLen(@Data^.SearchText[0])-1] <> '\' then
    StrAppend(@Data^.SearchText[0], '\');
  StrAppend(@Data^.SearchText[0], SelName);
  
  Result := @Data^.SearchText[0];
end;


{=============================================================================}
{ DirectoryView.pas  -  Tamamlanmis Kod                                       }
{=============================================================================}

procedure DirViewAddToHistory(Data: PDirViewData; const Path: PChar);
begin
  if Data = nil then Exit;
  if Data^.HistoryPos < Data^.HistoryCount - 1 then
    Data^.HistoryCount := Data^.HistoryPos + 1;
  if Data^.HistoryCount < 16 then
  begin
    StrCopy(@Data^.History[Data^.HistoryCount][0], Path);
    Inc(Data^.HistoryCount);
    Inc(Data^.HistoryPos);
  end
  else
  begin
    Move(Data^.History[1], Data^.History[0], 15 * 256);
    StrCopy(@Data^.History[15][0], Path);
    Data^.HistoryPos := 15;
  end;
end;

{ --- Buton Click Handlerlari --- }

procedure DirViewGoBack(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PDirViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PDirViewData(F^.Control);
  if Data = nil then Exit;
  if Data^.HistoryPos <= 0 then Exit;
  Dec(Data^.HistoryPos);
  StrCopy(@Data^.CurrentPath[0], @Data^.History[Data^.HistoryPos][0]);
  DirectoryViewRefresh(F);
end;

procedure DirViewGoForward(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PDirViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PDirViewData(F^.Control);
  if Data = nil then Exit;
  if Data^.HistoryPos >= Data^.HistoryCount - 1 then Exit;
  Inc(Data^.HistoryPos);
  StrCopy(@Data^.CurrentPath[0], @Data^.History[Data^.HistoryPos][0]);
  DirectoryViewRefresh(F);
end;

procedure DirViewGoUp(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PDirViewData;
  newPath: array[0..255] of Char;
  len: Integer;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PDirViewData(F^.Control);
  if Data = nil then Exit;

  StrCopy(@newPath[0], @Data^.CurrentPath[0]);
  len := StrLen(newPath);

  { S�r�c� k�k�ndeyse (C:\, D:\) � S�r�c� listesine d�n }
  if (len > 0) and (len <= 3) and (newPath[1] = ':') then
  begin
    Data^.CurrentPath[0] := #0;
    DirViewAddToHistory(Data, @Data^.CurrentPath[0]);
    DirectoryViewRefresh(F);
    Exit;
  end;

  if len > 1 then
  begin
    if newPath[len-1] = '\' then begin newPath[len-1] := #0; Dec(len); end;
    while (len > 1) and (newPath[len-1] <> '\') do
    begin
      newPath[len-1] := #0;
      Dec(len);
    end;
  end;

  if StrCmp(@newPath[0], @Data^.CurrentPath[0]) <> 0 then
  begin
    StrCopy(@Data^.CurrentPath[0], @newPath[0]);
    DirViewAddToHistory(Data, @Data^.CurrentPath[0]);
    DirectoryViewRefresh(F);
  end;
end;

procedure DirViewRefreshBtn(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PDirViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PDirViewData(F^.Control);
  if Data = nil then Exit;
  DirectoryViewRefresh(F);
end;

{ --- Arama & Filtre --- }




{ Her tus basisinda anlik arama (Enter beklenmez) }
procedure DirViewSearchKey(Sender: PObject; Key: Word);
var
  F: PForm;
  Data: PDirViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PDirViewData(F^.Control);
  if Data = nil then Exit;

  { Edit'teki metni SearchText'e kopyala ve hemen listeyi yenile }
  StrCopy(@Data^.SearchText[0], @PEdit(Sender)^.Text[0]);
  DirectoryViewRefresh(F);
end;

{ Buyuk/kucuk harf duyarsiz substring arama }


procedure DirViewFilterChanged(Sender: PObject);
var
  CB: PComboBox;
  F: PForm;
  Data: PDirViewData;
begin
  CB := PComboBox(Sender);
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PDirViewData(F^.Control);
  if Data = nil then Exit;

  case CB^.ItemIndex of
    0: StrCopy(@Data^.FilterPattern[0], '*');
    1: StrCopy(@Data^.FilterPattern[0], '*.TXT');
    2: StrCopy(@Data^.FilterPattern[0], '*.EXE');
    3: StrCopy(@Data^.FilterPattern[0], '*.BMP');
    4: StrCopy(@Data^.FilterPattern[0], '*.PAS');
    
  else
    StrCopy(@Data^.FilterPattern[0], '*');
  end;
  DirectoryViewRefresh(F);
end;

{ --- Bilgi Paneli Guncelleme --- }

procedure DirViewUpdateInfoPanel(Data: PDirViewData);
var
  SelName: PChar;
  Typ: Integer;
  IsDir: Boolean;
  SizeStr: array[0..31] of Char;
  entry: TDirEntry;
  fullPath: array[0..255] of Char;
  Resolved: Boolean;
  DriveIdx: Integer;
  Info: TDriveSpaceInfo;
begin
  if (Data = nil) or (Data^.LV = nil) or (Data^.LV^.ItemIndex < 0) then Exit;

  SelName := Data^.LV^.Items^[Data^.LV^.ItemIndex];
  if SelName = nil then Exit;

  StrCopy(@Data^.LblInfoName^.Caption[0], SelName);


  { =========================================================
    S�R�C� L�STES� MODU � Disk bilgisi g�ster
    ========================================================= }
  if Data^.CurrentPath[0] = #0 then
  begin
    Data^.CurrentFileType := -1; // �zel ikon i�in

    DriveIdx := FAT32_GetDriveFromPath(SelName);
    if DriveIdx >= 0 then
    begin
      if Drives[DriveIdx].FileSystem = FS_FAT32 then
      begin
        if FAT32_GetDriveSpace(DriveIdx, Info) then
        begin
          StrCopy(@Data^.LblInfoSize^.Caption[0], 'Kapasite: ');
          IntToPChar(Info.TotalMB, @SizeStr[0]);
          StrAppend(@Data^.LblInfoSize^.Caption[0], @SizeStr[0]);
          StrAppend(@Data^.LblInfoSize^.Caption[0], ' MB');
        end
        else
          StrCopy(@Data^.LblInfoSize^.Caption[0], 'Kapasite: --');
        StrCopy(@Data^.LblInfoType^.Caption[0], 'Tur: Yerel Disk (FAT32)');
      end
      else if Drives[DriveIdx].FileSystem = FS_ISO9660 then
      begin
         StrCopy(@Data^.LblInfoSize^.Caption[0], 'Kapasite: ');
          IntToPChar(Info.TotalMB, @SizeStr[0]);
          StrAppend(@Data^.LblInfoSize^.Caption[0], @SizeStr[0]);
        StrCopy(@Data^.LblInfoType^.Caption[0], 'Tur: CD-ROM (ISO 9660)');
      end
      else
      begin
        StrCopy(@Data^.LblInfoSize^.Caption[0], 'Kapasite: --');
        StrCopy(@Data^.LblInfoType^.Caption[0], 'Tur: Bilinmiyor');
      end;
    end;
    if Data^.LblInfoDate <> nil then StrCopy(@Data^.LblInfoDate^.Caption[0], '');
    Exit;
  end;






  StrCopy(@fullPath[0], @Data^.CurrentPath[0]);
  if fullPath[StrLen(fullPath)-1] <> '\' then StrAppend(@fullPath[0], '\');
  StrAppend(@fullPath[0], SelName);

  { ONEMLI: entry mutlaka sifirlanir - FAT32_ResolvePath basarisiz olursa
    entry.Attr baslatilmamis (cop) veri olarak kalip yanlis dosya turu/ikon
    gosterilmesine yol aciyordu. }
  FillChar(entry, SizeOf(entry), #0);
  Resolved := FAT32_ResolvePath(0, @fullPath[0], @entry);
  IsDir := Resolved and ((entry.Attr and ATTR_DIRECTORY) <> 0);

  { Tur SADECE BIR KEZ hesaplanir, hem etikette hem ikon panelinde ayni deger kullanilir }
  Typ := DetectFileType(SelName, IsDir);
  Data^.CurrentFileType := Typ;

  if not Resolved then
    StrCopy(@Data^.LblInfoSize^.Caption[0], 'Boyut: --')
  else if Typ = FT_FOLDER then
    StrCopy(@Data^.LblInfoSize^.Caption[0], 'Boyut: --')
  else
  begin
    FormatSize(entry.FileSize, @SizeStr[0]);
    StrCopy(@Data^.LblInfoSize^.Caption[0], 'Boyut: ');
    StrAppend(@Data^.LblInfoSize^.Caption[0], @SizeStr[0]);
  end;

  StrCopy(@Data^.LblInfoType^.Caption[0], 'Tur: ');
  StrAppend(@Data^.LblInfoType^.Caption[0], FileTypeName(Typ));

  if Data^.EdFileName <> nil then
    EditSetText(Data^.EdFileName, SelName);
end;

{ --- ListView Olaylari --- }

procedure DirViewListClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  LV: PListView;
  F: PForm;
  Data: PDirViewData;
begin
  LV := PListView(Sender);
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PDirViewData(F^.Control);
  if Data = nil then Exit;

  if LV^.ItemIndex >= 0 then
    DirViewUpdateInfoPanel(Data);
end;

procedure DirViewListDblClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  LV: PListView;
  F: PForm;
  Data: PDirViewData;
  Sel: Integer;
  selName: PChar;
  newPath: array[0..255] of Char;
  entry: TDirEntry;
  fullPath: array[0..255] of Char;
begin
  LV := PListView(Sender);
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PDirViewData(F^.Control);
  if Data = nil then Exit;

  Sel := LV^.ItemIndex;
  if Sel < 0 then Exit;
  selName := LV^.Items^[Sel];
  if selName = nil then Exit;

   if Data^.CurrentPath[0] = #0 then
  begin
    StrCopy(@Data^.CurrentPath[0], selName); // �rn: "C:\"
    DirViewAddToHistory(Data, @Data^.CurrentPath[0]);
    DirectoryViewRefresh(F);
    Exit;
  end;


  { [..] ust dizin }
  if StrCmp(selName, '[..]') = 0 then
  begin
    StrCopy(@newPath[0], @Data^.CurrentPath[0]);
    if StrLen(newPath) > 1 then
    begin
      if newPath[StrLen(newPath)-1] = '\' then newPath[StrLen(newPath)-1] := #0;
      while (StrLen(newPath) > 1) and (newPath[StrLen(newPath)-1] <> '\') do
        newPath[StrLen(newPath)-1] := #0;
      if newPath[StrLen(newPath)-1] <> '\' then StrAppend(@newPath[0], '\');
    end;
    StrCopy(@Data^.CurrentPath[0], @newPath[0]);
    DirViewAddToHistory(Data, @Data^.CurrentPath[0]);
    DirectoryViewRefresh(F);
    Exit;
  end;

  { Klasor mu? }
  StrCopy(@newPath[0], @Data^.CurrentPath[0]);
  if newPath[StrLen(newPath)-1] <> '\' then StrAppend(@newPath[0], '\');
  StrAppend(@newPath[0], selName);

  if FAT32_ResolvePath(0, @newPath[0], @entry) then
  begin
    if (entry.Attr and ATTR_DIRECTORY) <> 0 then
    begin
      StrCopy(@Data^.CurrentPath[0], @newPath[0]);
      DirViewAddToHistory(Data, @Data^.CurrentPath[0]);
      DirectoryViewRefresh(F);
      Exit;
    end;
  end;

  { Dosya -> Calistir veya bilgi guncelle }
  StrCopy(@fullPath[0], @newPath[0]);
  if Assigned (Data^.OnExecute) then
    Data^.OnExecute(selName, @fullPath[0], DetectFileType(selName, False));
end;

{=============================================================================}
{ Ana Fonksiyon: DirectoryView Olusturma                                        }
{=============================================================================}


procedure DirViewExecuteProc(const FileName, FilePath: PChar; FileType: Integer);
begin

  case FileType of
    FT_WAVE: OpenWavPlayer(FilePath);   // PlayWav(FilePath);   //
    FT_BMP,FT_JPG: OpenImageViewer(FilePath);
    FT_OTHER:OpenHexEditor(FilePath);
    FT_TXT :OpenTextEditor(FilePath);
    FT_CP8 :OpenGames(FilePath);
    FT_EXE : OpenExeFile(FilePath,FilePath);

  else
    OpenDlg('Open Dialog', 'C:\');
  end;


END;

procedure FileDialogDestroy(Sender: PObject);
var
  F: PForm;
  Data: PDirViewData;
begin

   

  F := PForm(Sender);
  if F = nil then Exit;
  Data := PDirViewData(F^.Control);
  if Data = nil then Exit;
     FreeMem(Data);

   
end;


function CreateDirectoryView(const StartPath: PChar): Boolean;
var
  F: PForm;
  Data: PDirViewData;
  MainPanel, LeftPanel, RightPanel, BottomPanel, Toolbar, PathBar, HeaderPanel, IconBox: PPanel;
  LV: PListView;
  Ed: PEdit;
  CB: PComboBox;
  Btn: PButton;
  bx, by, infoY: Integer;
begin
  Result := False;

  F := CreateForm('Directory View', 300, 200, 800, 500);
  if F = nil then Exit;
  F^.BorderStyle := bsWindow;
  F^.ShowSysButtons := True;
  F^.Color := clBtnFace;
  F^.BindDestroy(@FileDialogDestroy);

  { --- Data blogu --- }
  Data := PDirViewData(MemAlloc(SizeOf(TDirViewData)));
  FillChar(Data^, SizeOf(TDirViewData), #0);
  if (StartPath <> nil) and (StartPath[0] <> #0) then
    StrCopy(@Data^.CurrentPath[0], StartPath)
  else
    Data^.CurrentPath[0] := #0;  // S�r�c� listesi modu
  Data^.HistoryPos := 0;
  Data^.HistoryCount := 1;
  StrCopy(@Data^.History[0][0], @Data^.CurrentPath[0]);
  StrCopy(@Data^.FilterPattern[0], '*');
  Data^.SearchText[0] := #0;
  Data^.OnExecute := DirViewExecuteProc;
  Data^.CurrentFileType := -1;

  F^.Control := PObject(Data);

  { --- Toolbar (alTop): geri/ileri/yukari/yenile + adres cubugu --- }
  Toolbar := CreatePanel(PObject(F), 0, 0, 0, DV_TOOLBAR_H, alTop);
  Toolbar^.Color := $00D4D0C8;
  Toolbar^.BorderWidth := 0;
  Toolbar^.ShowCaption := False;
  Toolbar^.BindPaint(@DirViewToolbarDraw);

  by := (DV_TOOLBAR_H - DV_BTN_H) div 2;
  bx := DV_MARGIN;

  Btn := CreateButton(PObject(Toolbar), '<', bx, by, DV_BTN_W, DV_BTN_H, alNone);
  Btn^.BindMouseUp(@DirViewGoBack);
  Data^.BtnBack := Btn;
  Inc(bx, DV_BTN_W + DV_BTN_GAP);

  Btn := CreateButton(PObject(Toolbar), '>', bx, by, DV_BTN_W, DV_BTN_H, alNone);
  Btn^.BindMouseUp(@DirViewGoForward);
  Data^.BtnForward := Btn;
  Inc(bx, DV_BTN_W + DV_BTN_GAP + 10);   { bir sonraki gruptan once ince bosluk }

  Btn := CreateButton(PObject(Toolbar), #24, bx, by, DV_BTN_W, DV_BTN_H, alNone);
  Btn^.BindMouseUp(@DirViewGoUp);
  Data^.BtnUp := Btn;
  Inc(bx, DV_BTN_W + DV_BTN_GAP);

  Btn := CreateButton(PObject(Toolbar), 'R', bx, by, DV_BTN_W, DV_BTN_H, alNone);
  Btn^.BindMouseUp(@DirViewRefreshBtn);
  Data^.BtnRefresh := Btn;
  Inc(bx, DV_BTN_W + DV_BTN_GAP + 8);

  { Adres cubugu: gomulu kutu + klasor ikonu, kalan tum genisligi kaplar }
  PathBar := CreatePanel(PObject(Toolbar), bx, (DV_TOOLBAR_H - 22) div 2,
                         Toolbar^.Width - bx - DV_MARGIN, 22, alNone);
  PathBar^.BorderWidth := 0;
  PathBar^.ShowCaption := False;
  PathBar^.BindPaint(@DirViewPathBarDraw);

  Data^.LblPath := CreateLabel(PObject(PathBar), '', 24, 3,
                               PathBar^.Width - 30, 16, alNone);
  Data^.LblPath^.Transparent := True;

  { --- Ana Panel (alClient) ikiye bol: Sol(ListView) + Sag(Bilgi) --- }
  MainPanel := CreatePanel(PObject(F), 0, 0, 0, 0, alClient);
  MainPanel^.Color := clBtnFace;
  MainPanel^.BorderWidth := 0;

  { Sol: ListView + Arama + Filtre }
  LeftPanel := CreatePanel(PObject(MainPanel), 0, 0, 0, 0, alClient);
  LeftPanel^.Color := clBtnFace;
  LeftPanel^.BorderWidth := 0;

  { Arama Edit (alTop) }
  Ed := CreateEdit(PObject(LeftPanel), 0, 0, 0, 24, alTop);
  EditSetText(Ed, '');
  Ed^.BindKeyDown(@DirViewSearchKey);
  Data^.EdSearch := Ed;

  { Filtre Combo (alTop) }
  CB := CreateComboBox(PObject(LeftPanel), 0, 0, 0, 22, alTop);
  ComboBoxAddItem(CB, 'Tum Dosyalar (*.*)');
  ComboBoxAddItem(CB, 'Metin Dosyalari (*.txt)');
  ComboBoxAddItem(CB, 'Programlar (*.exe)');
  ComboBoxAddItem(CB, 'Resimler (*.bmp)');
  ComboBoxAddItem(CB, 'Pascal Kaynaklari (*.pas)');
  CB^.ItemIndex := 0;
  CB^.FOnChange := @DirViewFilterChanged;
  Data^.FilterCombo := CB;

  { ListView (alClient) }
  LV := CreateListView(PObject(LeftPanel), 0, 0, 0, 0, alClient);
  ListViewSetViewStyle(LV, 1);  { Icon mode }
  LV^.IconSize := 48;
  LV^.RowHeight := LV^.IconSize + FONT_H + 10;
  LV^.GridLines := False;
  LV^.BorderWidth := 1;
  LV^.BorderColor := cl3DDkShadow;
  Data^.LV := LV;

  LV^.BindMouseDown(@DirViewListClick);
  LV^.BindDblClick(@DirViewListDblClick);

  { Sag: Bilgi Paneli (alRight, sabit genislik) }
  RightPanel := CreatePanel(PObject(MainPanel), 0, 0, DV_INFO_W, 0, alRight);
  RightPanel^.Color := $00F0F0F0;
  RightPanel^.BorderWidth := 1;
  RightPanel^.BorderColor := cl3DDkShadow;

  { Baslik cubugu (gradyanli) }
  HeaderPanel := CreatePanel(PObject(RightPanel), 0, 0, DV_INFO_W - 2, DV_HEADER_H, alNone);
  HeaderPanel^.BorderWidth := 0;
  HeaderPanel^.ShowCaption := False;
  HeaderPanel^.BindPaint(@DirViewInfoHeaderDraw);

  { Buyuk ikon kutusu - secilen ogenin turune gore cizilir, yatayda ortali }
  IconBox := CreatePanel(PObject(RightPanel),
                         (DV_INFO_W - DV_ICON_BOX) div 2, DV_HEADER_H + DV_MARGIN,
                         DV_ICON_BOX, DV_ICON_BOX, alNone);
  IconBox^.BorderWidth := 0;
  IconBox^.ShowCaption := False;
  IconBox^.Color := $00F0F0F0;
  IconBox^.BindPaint(@DirViewFileIconDraw);
  Data^.IconPanel := IconBox;

  infoY := DV_HEADER_H + DV_MARGIN + DV_ICON_BOX + DV_MARGIN;

  Data^.LblInfoName := CreateLabel(PObject(RightPanel), 'Bir oge secin',
                       DV_MARGIN, infoY, DV_INFO_W - 2*DV_MARGIN, 34, alNone);
  Data^.LblInfoName^.Transparent := True;
  Data^.LblInfoName^.Alignment := 1;   { ortali }
  Inc(infoY, 38);

  Data^.LblInfoSize := CreateLabel(PObject(RightPanel), '',
                       DV_MARGIN, infoY, DV_INFO_W - 2*DV_MARGIN, 20, alNone);
  Data^.LblInfoSize^.Transparent := True;
  Inc(infoY, 22);

  Data^.LblInfoType := CreateLabel(PObject(RightPanel), '',
                       DV_MARGIN, infoY, DV_INFO_W - 2*DV_MARGIN, 20, alNone);
  Data^.LblInfoType^.Transparent := True;
  Inc(infoY, 22);

  Data^.LblInfoDate := CreateLabel(PObject(RightPanel), '',
                       DV_MARGIN, infoY, DV_INFO_W - 2*DV_MARGIN, 20, alNone);
  Data^.LblInfoDate^.Transparent := True;

  { --- Alt Panel: secili dosya adi gostergesi --- }
  BottomPanel := CreatePanel(PObject(F), 0, 0, 0, DV_STATUS_H, alBottom);
  BottomPanel^.Color := clBtnFace;
  BottomPanel^.BorderWidth := 0;
  BottomPanel^.ShowCaption := False;
  BottomPanel^.BindPaint(@DirViewToolbarDraw);   { ust gradyanla ayni stil, tutarlilik icin }

  CreateLabel(PObject(BottomPanel), 'Secili:', DV_MARGIN, (DV_STATUS_H - FONT_H) div 2,
              50, 20, alNone);
  Ed := CreateEdit(PObject(BottomPanel), DV_MARGIN + 50, (DV_STATUS_H - 22) div 2,
                   BottomPanel^.Width - (2*DV_MARGIN + 50), 22, alNone);
  Ed^.ReadOnly := True;
  Data^.EdFileName := Ed;

  { Ilk listeyi doldur }
  DirectoryViewRefresh(F);

  Result := True;
end;




end.

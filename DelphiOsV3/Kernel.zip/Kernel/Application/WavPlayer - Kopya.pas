unit WavPlayer;
{
  WAV Oynatici � Delphi 7 Uyumlu, clBtnFace Tema
  Desteklenen: 8-bit mono/stereo, 16-bit mono/stereo, PCM
  Ozellikler: Dalga sekli, sure, pozisyon cubugu
  Yeni: SB16 8/16-bit DMA playback (interruptsiz)
}
interface
uses SysUtils, GUI, GUIControls, Ports,Pit,Memory, Draw32, Fat32, Math;

const
  WP_FACE    = $D4D0C8;
  WP_FACE2   = $C8C4BC;
  WP_FACE3   = $E0DDD8;
  WP_WINDOW  = $FFFFFF;
  WP_BORDER  = $808080;
  WP_TEXT    = $000000;
  WP_GRAY    = $808080;
  WP_GRAY2   = $606060;
  WP_CAP1    = $0A246A;
  WP_CAP2    = $1084D0;
  WP_HILITE  = $0078D7;
  WP_GREEN   = $008000;
  WP_WAVE_C  = $0050A0;   // Dalga cizgi rengi
  WP_WAVE_BG = $F0F4FF;   // Dalga arka plan
  WP_DISABL  = $A0A0A0;
  WP_PLAY_C  = $006600;   // Play dugme rengi
  WP_STOP_C  = $880000;   // Stop dugme rengi

  // Oynatici durumlari
  WP_STATE_IDLE    = 0;
  WP_STATE_PLAYING = 1;
  WP_STATE_PAUSED  = 2;

  WAV_BUF_SIZE = 4096;

  // --- SB16 Portlari ---
  SB_BASE   = $220;
  SB_RESET  = $226;
  SB_READ   = $22A;
  SB_WRITE  = $22C;
  SB_STATUS = $22E;
  
type
     TSmallintArray = array[0..MaxInt div SizeOf(Smallint)-1] of Smallint;
   PSmallintArray = ^TSmallintArray;


type
  TWavRIFF = packed record
    ChunkID  : array[0..3] of Char;
    ChunkSize: LongWord;
    Format   : array[0..3] of Char;
  end;

  TWavFmt = packed record
    ChunkID       : array[0..3] of Char;
    ChunkSize     : LongWord;
    AudioFormat   : Word;
    NumChannels   : Word;
    SampleRate    : LongWord;
    ByteRate      : LongWord;
    BlockAlign    : Word;
    BitsPerSample : Word;
  end;

  TWavData = packed record
    ChunkID  : array[0..3] of Char;
    ChunkSize: LongWord;
  end;

  PConvBuf = ^TConvBuf;
  TConvBuf = array[0..WAV_BUF_SIZE-1] of SmallInt;

  PWavPlayer = ^TWavPlayer;
  TWavPlayer = object
  private
    // WAV bilgisi
    Channels     : Integer;
    SampleRate   : LongWord;
    BitsPerSample: Integer;
    TotalSamples : LongWord;
    DataOffset   : LongWord;
    DataSize     : LongWord;
    FilePath     : array[0..MAX_PATH-1] of Char;
    FileLoaded   : Boolean;

    // Dalga sekli
    WaveBuf      : Pointer;
    WaveBufLen   : Integer;

    // Oynatici durumu
    PlayerState  : Integer;
    CurSample    : LongWord;

    // --- SB16 DMA ---
    SbDmaBuf     : Pointer;    // DMA'ya verilen orijinal veri
    SbDmaSize    : LongWord;   // Aktarilan boyut

    // UI
    WavePanel    : PPanel;
    InfoPanel    : PPanel;
    CtrlPanel    : PPanel;
    ProgressBar  : PPanel;
    StatusBar    : PStatusBar;
    VolumeBar    : PScrollBar;

    // Cizim

    procedure DrawProgressBar(Sender: PObject; OX, OY: Integer);
    procedure SampleWaveform;
    procedure FormatTime(Samples: LongWord; SRate: LongWord; Buf: PChar);
    procedure FormatHz(Hz: LongWord; Buf: PChar);
    function  CtrlBtnAt(X: Integer): Integer;

    // Oynatici kontrolleri
    procedure DoPlay;
    procedure DoPause;
    procedure DoStop;

    // --- SB16 Low-Level (interruptsiz) ---
    function SbReset: Boolean;
    function  SbReady: Boolean;
    procedure SbWrite(b: Byte);
    function  SbRead: Byte;
    procedure SbSpeaker(on: Boolean);
    procedure SbDmaStart8 (buf: Pointer; len: LongWord; rate: Word);
    procedure SbDmaStart16(buf: Pointer; len: LongWord; rate: Word);
    procedure SbStopDma;

  public
    FForm         : PForm;

    procedure LoadFile(Path: PChar);
    procedure FreeWav;


    procedure OnVolChange(Sender: PObject; NewVal: Integer);

    procedure Tick;
  end;

procedure OpenWavPlayer(Path: PChar);


var
  WavPlayer1:PWavPlayer;

implementation

// ============================================================================
//  YARDIMCI: Zaman / Frekans formatlama
// ============================================================================
procedure TWavPlayer.FormatTime(Samples: LongWord; SRate: LongWord; Buf: PChar);
var S, M: Integer; T: array[0..15] of Char;
begin
  if SRate = 0 then begin StrCopy(Buf,'0:00'); Exit; end;
  S := Integer(Samples div SRate);
  M := S div 60;
  S := S mod 60;
  IntToPChar(M, @T[0]);
  StrCopy(Buf, @T[0]);
  StrAppend(Buf, ':');
  if S < 10 then StrAppend(Buf, '0');
  IntToPChar(S, @T[0]);
  StrAppend(Buf, @T[0]);
end;

procedure TWavPlayer.FormatHz(Hz: LongWord; Buf: PChar);
var T: array[0..15] of Char;
begin
  IntToPChar(Hz, @T[0]);
  StrCopy(Buf, @T[0]);
  StrAppend(Buf, ' Hz');
end;

// ============================================================================
//  DALGA SEKLI ORNEKLEME  (lldiv kullanmaz, tum bolumeler LongWord)
// ============================================================================
procedure TWavPlayer.SampleWaveform;
type
  PSmallIntArray=^TSmallIntArray;
  TSmallIntArray=array[0..1024] of SmallInt;
var
  Handle     : Integer;
  PanelW     : Integer;
  I, J       : Integer;
  StepSamples: LongWord;
  Off        : LongWord;
  TmpBuf     : array[0..63] of Byte;
  S16        : SmallInt;
  MaxV, MinV : SmallInt;
  RdBytes    : Integer;
  Buf        : PSmallIntArray;
  Bps        : Integer;
  Ch         : Integer;
  TmpStep    : LongWord;
begin
  if WaveBuf <> nil then begin FreeMem(WaveBuf); WaveBuf := nil; end;
  if not FileLoaded then Exit;

  PanelW := WavePanel^.Width;
  if PanelW <= 0 then PanelW := 400;
  WaveBufLen := PanelW;
  WaveBuf    := MemAlloc(WaveBufLen * 2);
  if WaveBuf = nil then Exit;

  Buf := PSmallIntArray(WaveBuf);

  if WaveBufLen <= 0 then WaveBufLen := 1;
  StepSamples := TotalSamples div LongWord(WaveBufLen);
  if StepSamples < 1 then StepSamples := 1;

  Handle := OpenFile(@FilePath[0], FILE_READ);
  if Handle < 0 then Exit;

  Bps := BitsPerSample div 8; if Bps < 1 then Bps := 1;
  Ch  := Channels;            if Ch  < 1 then Ch  := 1;

  for I := 0 to WaveBufLen-1 do
  begin
    Off := DataOffset + LongWord(I) * StepSamples * LongWord(Ch) * LongWord(Bps);
    SeekFile(Handle, Off, SEEK_SET);
    MaxV := 0; MinV := 0;

    if StepSamples > 8 then TmpStep := 8 else TmpStep := StepSamples;
    RdBytes := Integer(TmpStep) * Ch * Bps;
    if RdBytes > 64 then RdBytes := 64;
    if RdBytes < 1 then RdBytes := 1;

    ReadFile(Handle, @TmpBuf[0], RdBytes);

    J := 0;
    while J < RdBytes do
    begin
      if BitsPerSample = 16 then
      begin
        S16 := SmallInt(TmpBuf[J] or (TmpBuf[J+1] shl 8));
        Inc(J, 2);
      end
      else
      begin
        S16 := SmallInt(Integer(TmpBuf[J]) - 128) shl 8;
        Inc(J, 1);
      end;
      if Ch = 2 then Inc(J, Bps);

      if S16 > MaxV then MaxV := S16;
      if S16 < MinV then MinV := S16;
    end;

    Buf^[I] := SmallInt((Integer(MaxV) - Integer(MinV)) div 2);
  end;

  CloseFile(Handle);
end;

// ============================================================================
//  WAV DOSYA YUKLEME  (lldiv kullanmaz)
// ============================================================================
procedure TWavPlayer.LoadFile(Path: PChar);
var
  FileHandle : Integer;
  RIFF   : TWavRIFF;
  Fmt    : TWavFmt;
  ChunkID: array[0..3] of Char;
  ChunkSz: LongWord;
  Pos    : LongWord;
  Found  : Boolean;
  InfoBuf: array[0..63] of Char;
  I      : Integer;
  Block  : LongWord;
begin
  FreeWav;
  StrCopy(@FilePath[0], Path);

  FileHandle := OpenFile(Path, FILE_READ);
  if FileHandle < 0 then
  begin
   // StatusBar^.SetPanelText(0, 'Dosya acilamadi');
    Exit;
  end;

  ReadFile(FileHandle, @RIFF, SizeOf(TWavRIFF));
  if (RIFF.ChunkID[0]<>'R') or (RIFF.ChunkID[1]<>'I') or
     (RIFF.ChunkID[2]<>'F') or (RIFF.ChunkID[3]<>'F') then
  begin
    CloseFile(FileHandle);
   // StatusBar^.SetPanelText(0, 'RIFF degil');
    Exit;
  end;
  if (RIFF.Format[0]<>'W') or (RIFF.Format[1]<>'A') or
     (RIFF.Format[2]<>'V') or (RIFF.Format[3]<>'E') then
  begin
    CloseFile(FileHandle);
   // StatusBar^.SetPanelText(0, 'WAVE degil');
    Exit;
  end;

  Found := False;
  Pos   := 12;
  SeekFile(FileHandle, Pos, SEEK_SET);

  while Pos < LongWord(FileSize(FileHandle)) - 8 do
  begin
    ReadFile(FileHandle, @ChunkID[0], 4);
    ReadFile(FileHandle, @ChunkSz, 4);

    if (ChunkID[0]='f') and (ChunkID[1]='m') and
       (ChunkID[2]='t') and (ChunkID[3]=' ') then
    begin
      ReadFile(FileHandle, @Fmt.AudioFormat,   2);
      ReadFile(FileHandle, @Fmt.NumChannels,   2);
      ReadFile(FileHandle, @Fmt.SampleRate,    4);
      ReadFile(FileHandle, @Fmt.ByteRate,      4);
      ReadFile(FileHandle, @Fmt.BlockAlign,    2);
      ReadFile(FileHandle, @Fmt.BitsPerSample, 2);
      if ChunkSz > 16 then SeekFile(FileHandle, Pos + 8 + ChunkSz, SEEK_SET);
      Channels      := Fmt.NumChannels;
      SampleRate    := Fmt.SampleRate;
      BitsPerSample := Fmt.BitsPerSample;
    end
    else if (ChunkID[0]='d') and (ChunkID[1]='a') and
            (ChunkID[2]='t') and (ChunkID[3]='a') then
    begin
      DataOffset := Pos + 8;
      DataSize   := ChunkSz;
      Found      := True;
    end;

    Inc(Pos, 8 + ChunkSz);
    if ChunkSz mod 2 <> 0 then Inc(Pos);
    SeekFile(FileHandle, Pos, SEEK_SET);
  end;

  CloseFile(FileHandle);

  if not Found then
  begin
   // StatusBar^.SetPanelText(0, 'data chunk bulunamadi');
    Exit;
  end;

  if Fmt.AudioFormat <> 1 then
  begin
   // StatusBar^.SetPanelText(0, 'Sadece PCM desteklenir');
    Exit;
  end;

  Block := LongWord(Channels) * LongWord(BitsPerSample div 8);
  if Block > 0 then
    TotalSamples := DataSize div Block
  else
    TotalSamples := 0;

  FileLoaded   := True;
  PlayerState  := WP_STATE_IDLE;
  CurSample    := 0;

  SampleWaveform;

  StrCopy(@InfoBuf[0], 'Yuklendi: ');
  IntToPChar(BitsPerSample, @InfoBuf[StrLen(@InfoBuf[0])]);
  StrAppend(@InfoBuf[0], '-bit');
//  StatusBar^.SetPanelText(0, @InfoBuf[0]);
end;

procedure TWavPlayer.FreeWav;
begin
  if WaveBuf <> nil then begin FreeMem(WaveBuf); WaveBuf := nil; end;
  if SbDmaBuf <> nil then begin FreeMem(SbDmaBuf); SbDmaBuf := nil; end;
  FileLoaded   := False;
  TotalSamples := 0;
  DataOffset   := 0;
  DataSize     := 0;
  CurSample    := 0;
  PlayerState  := WP_STATE_IDLE;
end;

// ============================================================================
//  SB16 LOW-LEVEL  (interruptsiz, polling)
// ============================================================================
function TWavPlayer.SbReset: Boolean;
var
  b: Byte;
begin
  WritePortB(SB_RESET, 1);
  Delay(5);
  WritePortB(SB_RESET, 0);
  Delay(5);
  b := SbRead;
  Result := (b = $AA);  // Kart varsa 0xAA d�ner
end;

function TWavPlayer.SbReady: Boolean;
var
  Timeout: Integer;
begin
  Timeout := 10000;
  repeat
    Result := (ReadPortB(SB_STATUS) and $80) = 0;
    if Result then Exit;
    Dec(Timeout);
  until Timeout <= 0;
  Result := False;  // Timeout: kart yok veya me�gul
end;


procedure TWavPlayer.SbWrite(b: Byte);
var
  Timeout: Integer;
begin
  Timeout := 10000;
  while not SbReady do
  begin
    Dec(Timeout);
    if Timeout <= 0 then Exit;  // Kart yoksa buradan ��k
  end;
  WritePortB(SB_WRITE, b);
end;

function TWavPlayer.SbRead: Byte;
var
  Timeout: Integer;
begin
  Timeout := 10000;
  while (ReadPortB(SB_STATUS) and $80) = 0 do
  begin
    Dec(Timeout);
    if Timeout <= 0 then begin Result := 0; Exit; end;
  end;
  Result := ReadPortB(SB_READ);
end;


procedure TWavPlayer.SbSpeaker(on: Boolean);
begin
  if on then SbWrite($D1) else SbWrite($D3);
end;

procedure TWavPlayer.SbStopDma;
begin
  SbWrite($D0); // halt 8-bit
  SbWrite($D5); // halt 16-bit
  SbSpeaker(False);
end;

// --- 8-bit single-cycle DMA (Channel 1) ---
procedure TWavPlayer.SbDmaStart8(buf: Pointer; len: LongWord; rate: Word);
var
  Addr: LongWord;
  LenWords: Word;
  TimeConst: Byte;
begin
  if len = 0 then Exit;
  if len > $FFFF then len := $FFFF; // DMA 16-bit count limit

  Addr := LongWord(buf);
  LenWords := Word(len - 1);

  SbReset;
  SbSpeaker(True);

  // DMA ch1 mask
  WritePortB($0A, $05);
  // clear flip-flop
  WritePortB($0C, $00);
  // mode: single, increment, write, ch1 = $49
  WritePortB($0B, $49);
  // address
  WritePortB($02, Lo(Addr));
  WritePortB($02, Hi(Addr));
  // page
  WritePortB($83, (Addr shr 16) and $FF);
  // count
  WritePortB($03, Lo(LenWords));
  WritePortB($03, Hi(LenWords));
  // unmask ch1
  WritePortB($0A, $01);

  // time constant
  if rate = 0 then rate := 22050;
  TimeConst := 256 - (1000000 div rate);
  SbWrite($40);
  SbWrite(TimeConst);

  // start 8-bit playback
  SbWrite($14);
  SbWrite(Lo(LenWords));
  SbWrite(Hi(LenWords));
end;

// --- 16-bit single-cycle DMA (Channel 5) ---
procedure TWavPlayer.SbDmaStart16(buf: Pointer; len: LongWord; rate: Word);
var
  Addr: LongWord;
  CountWords: Word;
begin
  if len = 0 then Exit;
  if len > $FFFF then len := $FFFF;

  Addr := LongWord(buf);
  CountWords := (len div 2) - 1;

  SbReset;
  SbSpeaker(True);

  // DMA ch5 mask (16-bit controller)
  WritePortB($D4, $05);
  // clear flip-flop
  WritePortB($D8, $00);
  // mode: single, inc, write, ch5 = $55 (%01010101)
  WritePortB($D6, $55);
  // address (word cinsinden, 16-bit DMA)
  WritePortB($C4, Lo((Addr shr 1) and $FFFF));
  WritePortB($C4, Hi((Addr shr 1) and $FFFF));
  // page
  WritePortB($8B, (Addr shr 16) and $FF);
  // count (words - 1)
  WritePortB($C6, Lo(CountWords));
  WritePortB($C6, Hi(CountWords));
  // unmask ch5
  WritePortB($D4, $01);

  // sample rate
  SbWrite($41);
  SbWrite(Hi(rate));
  SbWrite(Lo(rate));

  // 16-bit signed mono playback
  SbWrite($B0);
  SbWrite($10);
  SbWrite(Lo(CountWords));
  SbWrite(Hi(CountWords));
end;

// ============================================================================
//  OYNATICI KONTROLLERI  (SB16 entegreli)
// ============================================================================
procedure TWavPlayer.DoPlay;
var
  FileHandle: Integer;
begin
  if not FileLoaded then Exit;

  { --- �NCEK� �ALMAYI TEM�ZLE --- }
  if PlayerState <> WP_STATE_IDLE then DoStop;

  { --- SB16 KONTROL�: Kart var m�? --- }
  if not SbReset then
  begin
    // �stersen StatusBar'e yaz: 'Ses karti bulunamadi'
    Exit;
  end;

  { --- DMA BUFFER HAZIRLA --- }
  if SbDmaBuf <> nil then begin FreeMem(SbDmaBuf); SbDmaBuf := nil; end;
  SbDmaSize := DataSize;
  if SbDmaSize > $FF00 then SbDmaSize := $FF00;
  if SbDmaSize = 0 then Exit;

  SbDmaBuf := MemAlloc(SbDmaSize);
  if SbDmaBuf = nil then Exit;

  { --- DOSYADAN OKU --- }
  FileHandle := OpenFile(@FilePath[0], FILE_READ);
  if FileHandle < 0 then
  begin
    FreeMem(SbDmaBuf); SbDmaBuf := nil;
    Exit;
  end;
  SeekFile(FileHandle, DataOffset, SEEK_SET);
  ReadFile(FileHandle, SbDmaBuf, Integer(SbDmaSize));
  CloseFile(FileHandle);

  { --- �AL --- }
  PlayerState := WP_STATE_PLAYING;
  CurSample   := 0;

  if BitsPerSample = 8 then
    SbDmaStart8(SbDmaBuf, SbDmaSize, Word(SampleRate))
  else
    SbDmaStart16(SbDmaBuf, SbDmaSize, Word(SampleRate));
end;

procedure TWavPlayer.DoPause;
begin
  if PlayerState = WP_STATE_PLAYING then
  begin
    SbWrite($D0); // halt 8-bit
    SbWrite($D5); // halt 16-bit
    PlayerState := WP_STATE_PAUSED;
   // StatusBar^.SetPanelText(0, 'Duraklatildi');
  end
  else if PlayerState = WP_STATE_PAUSED then
  begin
    SbWrite($D4); // continue 8-bit
    SbWrite($D6); // continue 16-bit
    PlayerState := WP_STATE_PLAYING;
   // StatusBar^.SetPanelText(0, 'Oynatiliyor...');
  end;
end;

procedure TWavPlayer.DoStop;
begin
  SbStopDma;
  PlayerState := WP_STATE_IDLE;
  CurSample   := 0;
 // StatusBar^.SetPanelText(0, 'Durduruldu');
end;

// ============================================================================
//  UI HIT-TEST
// ============================================================================
function TWavPlayer.CtrlBtnAt(X: Integer): Integer;
begin
  Result := -1;
  if (X >= 8)   and (X < 56)  then Result := 0
  else if (X >= 60)  and (X < 120) then Result := 1
  else if (X >= 124) and (X < 172) then Result := 2
  else if (X >= 176) and (X < 224) then Result := 3;
end;

// ============================================================================
//  CIZIM METODLARI
// ============================================================================
procedure DrawWavePanel(Sender: PObject; OX, OY: Integer);
var
  F: PWavPlayer;
  W, H, CY, X, AmpPx: Integer;
  Buf: PSmallIntArray;
  MaxAmp: Integer;
  PosX: Integer;
  Tmp: LongWord;
begin
  F := PWavPlayer(Sender^.Control);
  W := Sender^.Width;
  H := Sender^.Height;

  KSunken(OX, OY, W, H, WP_WAVE_BG);
  CY := OY + H div 2;
  MaxAmp := H div 2 - 4;

  KLineH(OX+2, CY, W-4, $C0C8D8);

  if (not F^.FileLoaded) or (F^.WaveBuf = nil) then
  begin
    KStrCentered(OX, CY - FONT_H div 2, W, 'Dosya yuklenmedi', WP_GRAY);
    Exit;
  end;

  Buf := PSmallIntArray(F^.WaveBuf);

  Clip_Set(OX+2, OY+2, OX+W-3, OY+H-3);
  for X := 0 to MinI(F^.WaveBufLen-1, W-5) do
  begin
    AmpPx := Integer(Buf^[X]) * MaxAmp div 32767;
    if AmpPx < 0 then AmpPx := -AmpPx;
    if AmpPx < 1 then AmpPx := 1;
    KLineV(OX+2+X, CY - AmpPx, AmpPx*2, WP_WAVE_C);
    KFill(OX+2+X, CY-1, 1, 2, $002080);
  end;

  if F^.TotalSamples > 0 then
  begin
    if F^.TotalSamples >= 256 then
      Tmp := ((F^.CurSample shr 8) * LongWord(W-4)) div (F^.TotalSamples shr 8)
    else
      Tmp := (F^.CurSample * LongWord(W-4)) div F^.TotalSamples;
    PosX := OX + 2 + Integer(Tmp);
    KLineV(PosX, OY+2, H-4, WP_HILITE);
  end;

  Clip_Clear;
end;

procedure DrawInfoPanel(Sender: PObject; OX, OY: Integer);
var
  F: PWavPlayer;
  W, H: Integer;
  Buf: array[0..63] of Char;
  HzBuf: array[0..31] of Char;
  Row: Integer;
begin
  F := PWavPlayer(Sender^.Control);
  W := Sender^.Width;
  H := Sender^.Height;

  KFill(OX, OY, W, H, WP_FACE);
  KRect3D(OX, OY, W, H, True);

  KGradientH(OX+1, OY+1, W-2, 18, WP_CAP1, WP_CAP2);
  KStrCentered(OX, OY+1, W, 'WAV BILGISI', $FFFFFF);

  if not F^.FileLoaded then
  begin
    KStrCentered(OX, OY+H div 2, W, 'Dosya yok', WP_GRAY);
    Exit;
  end;

  Row := OY + 24;

  F^.FormatHz(F^.SampleRate, @HzBuf[0]);
  KStr(OX+6, Row, 'Ornekleme :', WP_GRAY2);
  KStr(OX+W div 2, Row, @HzBuf[0], WP_TEXT);
  Inc(Row, FONT_H + 4);

  KStr(OX+6, Row, 'Kanal     :', WP_GRAY2);
  if F^.Channels = 1 then KStr(OX+W div 2, Row, 'Mono', WP_TEXT)
  else                     KStr(OX+W div 2, Row, 'Stereo', WP_TEXT);
  Inc(Row, FONT_H + 4);

  KStr(OX+6, Row, 'Bit derinl:', WP_GRAY2);
  IntToPChar(F^.BitsPerSample, @Buf[0]);
  StrAppend(@Buf[0], ' bit');
  KStr(OX+W div 2, Row, @Buf[0], WP_TEXT);
  Inc(Row, FONT_H + 4);

  KStr(OX+6, Row, 'Sure      :', WP_GRAY2);
  F^.FormatTime(F^.TotalSamples, F^.SampleRate, @Buf[0]);
  KStr(OX+W div 2, Row, @Buf[0], WP_TEXT);
  Inc(Row, FONT_H + 4);

  KStr(OX+6, Row, 'Veri boyut:', WP_GRAY2);
  IntToPChar(F^.DataSize, @Buf[0]);
  StrAppend(@Buf[0], ' B');
  KStr(OX+W div 2, Row, @Buf[0], WP_TEXT);
  Inc(Row, FONT_H + 8);

  KLineH(OX+4, Row, W-8, WP_BORDER);
  Inc(Row, 4);

  KStr(OX+6, Row, 'Dosya:', WP_GRAY2);
  Inc(Row, FONT_H + 2);
  Clip_Set(OX+4, Row, OX+W-4, Row+FONT_H);
  KStr(OX+6, Row, @F^.FilePath[0], WP_GRAY2);
  Clip_Clear;
end;

procedure DrawCtrlPanel(Sender: PObject; OX, OY: Integer);
var
  F: PWavPlayer;
  W, H: Integer;
  IsPlaying: Boolean;
begin
  F := PWavPlayer(Sender^.Control);
  W := Sender^.Width;
  H := Sender^.Height;
  IsPlaying := F^.PlayerState = WP_STATE_PLAYING;

  KFill(OX, OY, W, H, WP_FACE);
  KLineH(OX, OY, W, $FFFFFF);
  KLineH(OX, OY+H-1, W, WP_BORDER);

  // |< Basa don
  KButton3D(OX+8, OY+4, 48, H-8, False, WP_FACE);
  KStr(OX+16, OY+(H-FONT_H) div 2, '|<', WP_TEXT);

  // > Oynat / || Duraklat
  if IsPlaying then
    KButton3D(OX+60, OY+4, 60, H-8, True, WP_FACE2)
  else
    KButton3D(OX+60, OY+4, 60, H-8, False, WP_FACE);
  KFill(OX+60, OY+4, 60, H-8, ifThen( IsPlaying , $E0FFE0 , WP_FACE));
  if IsPlaying then
    KStrCentered(OX+60, OY+(H-FONT_H) div 2, 60, '|| Dur.', WP_GREEN)
  else
    KStrCentered(OX+60, OY+(H-FONT_H) div 2, 60, '> Oynat', WP_GREEN);

  // | | Durdur
  KButton3D(OX+124, OY+4, 48, H-8, False, WP_FACE);
  KFill(OX+130, OY+(H-10) div 2, 8, 8, $880000);
  KStr(OX+140, OY+(H-FONT_H) div 2, 'Dur', $880000);

  // >| Sona don
  KButton3D(OX+176, OY+4, 48, H-8, False, WP_FACE);
  KStr(OX+185, OY+(H-FONT_H) div 2, '>|', WP_TEXT);

  // Ayirici
  KLineV(OX+228, OY+4, H-8, WP_BORDER);

  // Ses duzey etiketi
  KStr(OX+238, OY+(H-FONT_H) div 2, 'Ses:', WP_GRAY2);
end;

procedure TWavPlayer.DrawProgressBar(Sender: PObject; OX, OY: Integer);
var
  F: PWavPlayer;
  W, H: Integer;
  FillW: Integer;
  CurBuf, TotBuf: array[0..15] of Char;
  Tmp: LongWord;
begin
  F := PWavPlayer(Sender^.Control);
  W := Sender^.Width;
  H := Sender^.Height;

  KFill(OX, OY, W, H, WP_FACE);
  KLineH(OX, OY, W, $FFFFFF);

  F^.FormatTime(F^.CurSample, F^.SampleRate, @CurBuf[0]);
  F^.FormatTime(F^.TotalSamples, F^.SampleRate, @TotBuf[0]);
  KStr(OX+4, OY+3, @CurBuf[0], WP_GRAY2);
  KStr(OX+W - StrLen(@TotBuf[0])*FONT_W - 4, OY+3, @TotBuf[0], WP_GRAY2);

  KSunken(OX+40, OY+4, W-80, H-8, WP_WINDOW);
  if F^.TotalSamples > 0 then
  begin
    if F^.TotalSamples >= 256 then
      Tmp := ((F^.CurSample shr 8) * LongWord(W-82)) div (F^.TotalSamples shr 8)
    else
      Tmp := (F^.CurSample * LongWord(W-82)) div F^.TotalSamples;
    FillW := Integer(Tmp);
    if FillW > 0 then
      KGradientH(OX+41, OY+5, FillW, H-10, WP_CAP1, WP_HILITE);
  end;
end;

// ============================================================================
//  OLAY ISLEYICILERI
// ============================================================================
procedure OnCtrlDown(Sender: PObject; X, Y: Integer; Btn: Byte);
begin end;

procedure OnCtrlUp(Sender: PObject; X, Y: Integer; Btn: Byte);
var F: PWavPlayer; Idx: Integer;
begin
  F   := PWavPlayer(Sender^.Control);
  Idx := F^.CtrlBtnAt(X);
  case Idx of
    0: begin F^.CurSample := 0; end;
    1: if F^.PlayerState = WP_STATE_IDLE then F^.DoPlay
       else F^.DoPause;
    2: F^.DoStop;
    3: begin
         if F^.TotalSamples > 0 then
           F^.CurSample := F^.TotalSamples - 1;
       end;
  end;
end;

procedure OnProgDown(Sender: PObject; X, Y: Integer; Btn: Byte);
var F: PWavPlayer; W, RelX: Integer;
begin
  F   := PWavPlayer(Sender^.Control);
  W   := Sender^.Width;
  RelX := X - 40;
  if RelX < 0 then RelX := 0;
  if RelX > W-80 then RelX := W-80;
  if (F^.TotalSamples > 0) and (W-80 > 0) then
    F^.CurSample := LongWord(RelX) * F^.TotalSamples div LongWord(W-80);
end;

procedure TWavPlayer.OnVolChange(Sender: PObject; NewVal: Integer);
begin
  // Ses karti mixer volume: Master volume = $22, sol/ayri ayarlanabilir
  // WritePortB(SB_BASE + $04, $22);
  // WritePortB(SB_BASE + $05, (NewVal shl 3) or (NewVal shr 2));
end;

procedure OnKeyDown(Sender: PObject; Key: Word);
var
  F: PWavPlayer;
begin
  F := PWavPlayer(Sender^.Control);
  case Key of
    32: if F^.PlayerState = WP_STATE_IDLE then F^.DoPlay
        else F^.DoPause;
    27: F^.DoStop;
  end;
end;

procedure TWavPlayer.Tick;
var FrameSamples: LongWord;
begin
  if PlayerState <> WP_STATE_PLAYING then Exit;

  if SampleRate > 0 then
    FrameSamples := SampleRate div 60
  else
    FrameSamples := 735;
  Inc(CurSample, FrameSamples);
  if CurSample >= TotalSamples then
  begin
    CurSample   := 0;
    PlayerState := WP_STATE_IDLE;
    SbSpeaker(False);
   // StatusBar^.SetPanelText(0, 'Tamamlandi');
  end;
end;

// ============================================================================
//  INIT
// ============================================================================

{
procedure TWavPlayer.InitWavPlayer(ALeft, ATop, AWidth, AHeight: Integer);
var InfoW: Integer;
begin
  InitForm(ALeft, ATop, AWidth, AHeight, AWidth, AHeight, 'WAV Oynatici');
  TypeSize      := SizeOf(TWavPlayer);
  WaveBuf       := nil;
  WaveBufLen    := 0;
  FileLoaded    := False;
  PlayerState   := WP_STATE_IDLE;
  CurSample     := 0;
  TotalSamples  := 0;
  FilePath[0]   := #0;
  Channels      := 0;
  SampleRate    := 0;
  BitsPerSample := 0;
  SbDmaBuf      := nil;
  SbDmaSize     := 0;

  InfoW := 200;

  InfoPanel := PPanel(KAlloc(SizeOf(TPanel)));
  InfoPanel^.InitPanel(0, 0, InfoW, AHeight, False);
  InfoPanel^.Align   := alRight;
  InfoPanel^.OnPaint := DrawInfoPanel;
  AddChild(PObject(InfoPanel));

  StatusBar := PStatusBar(KAlloc(SizeOf(TStatusBar)));
  StatusBar^.InitStatusBar(22);
  StatusBar^.AddPanel('Hazir', 300);
  AddChild(PObject(StatusBar));

  CtrlPanel := PPanel(KAlloc(SizeOf(TPanel)));
  CtrlPanel^.InitPanel(0, 0, AWidth - InfoW, 38, False);
  CtrlPanel^.Align       := alBottom;
  CtrlPanel^.OnPaint     := DrawCtrlPanel;
  CtrlPanel^.OnMouseDown := OnCtrlDown;
  CtrlPanel^.OnMouseUp   := OnCtrlUp;
  AddChild(PObject(CtrlPanel));

  VolumeBar := PScrollBar(KAlloc(SizeOf(TScrollBar)));
  VolumeBar^.InitScrollBar(0, 0, 100, 12, sbHorizontal);
  VolumeBar^.SetMin(0); VolumeBar^.SetMax(100);
  VolumeBar^.SetPosition(80);
  VolumeBar^.OnChange := OnVolChange;
  CtrlPanel^.AddChild(PObject(VolumeBar)); 

  ProgressBar := PPanel(KAlloc(SizeOf(TPanel)));
  ProgressBar^.InitPanel(0, 0, AWidth - InfoW, 26, False);
  ProgressBar^.Align       := alBottom;
  ProgressBar^.OnPaint     := DrawProgressBar;
  ProgressBar^.OnMouseDown := OnProgDown;
  AddChild(PObject(ProgressBar));

  WavePanel := PPanel(KAlloc(SizeOf(TPanel)));
  WavePanel^.InitPanel(0, 0, AWidth - InfoW, AHeight - 38 - 26 - 22, False);
  WavePanel^.Align      := alClient;
  WavePanel^.OnPaint    := DrawWavePanel;
  WavePanel^.OnKeyDown  := OnKeyDown;
  AddChild(PObject(WavePanel));
end;  }

procedure OpenWavPlayer(Path: PChar);
var
  InfoW: Integer;

begin
    WavPlayer1 := PWavPlayer(MemAlloc(SizeOf(TWavPlayer)));


  WavPlayer1^.FForm := CreateForm('WAV Oynatici', 100, 80, 660, 380);

  WavPlayer1^.WaveBuf       := nil;
  WavPlayer1^.WaveBufLen    := 0;
  WavPlayer1^.FileLoaded    := False;
  WavPlayer1^.PlayerState   := WP_STATE_IDLE;
  WavPlayer1^.CurSample     := 0;
  WavPlayer1^.TotalSamples  := 0;
  WavPlayer1^.FilePath[0]   := #0;
  WavPlayer1^.Channels      := 0;
  WavPlayer1^.SampleRate    := 0;
  WavPlayer1^.BitsPerSample := 0;
  WavPlayer1^.SbDmaBuf      := nil;
  WavPlayer1^.SbDmaSize     := 0;

  InfoW := 200;

   WavPlayer1^.InfoPanel := CreatePanel(PObject(WavPlayer1^.FForm), 0, 0, InfoW, 380,alRight);
   WavPlayer1^.InfoPanel^.BindPaint(@DrawInfoPanel);
   WavPlayer1^.InfoPanel^.Control:=WavPlayer1;

    WavPlayer1^.CtrlPanel := CreatePanel(PObject(WavPlayer1^.FForm),0, 0, 660 - InfoW, 38,alBottom);
    WavPlayer1^.CtrlPanel^.BindPaint(@DrawCtrlPanel);
    WavPlayer1^.CtrlPanel^.BindMouseDown(@OnCtrlDown);
    WavPlayer1^.CtrlPanel^.BindMouseUp(@OnCtrlUp);
    WavPlayer1^.CtrlPanel^.Control:=WavPlayer1;

    WavPlayer1^.WavePanel := CreatePanel(PObject(WavPlayer1^.FForm),0, 0, 660 - InfoW, 380 - 38 - 26 - 22,alClient);
    WavPlayer1^.WavePanel^.BindPaint(@DrawWavePanel);
    WavPlayer1^.WavePanel^.BindKeyDown(@OnKeyDown);
    WavPlayer1^.WavePanel^.Control:=WavPlayer1;


  WavPlayer1^.LoadFile(Path);


end;

end.

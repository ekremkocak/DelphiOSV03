unit FormNetAdapter;

interface

uses
  SysUtils, Memory, Draw32, GUI, GUIControls, NetworkDevices;

type
  PFormNetAdapter = ^TFormNetAdapter;
  TFormNetAdapter = object
  public
    // GUI Bile�enleri
    lvAdapters:  PListView;
    pnlButtons:  PPanel;
    btnAdd:      PButton;
    btnDelete:   PButton;
    btnStart:    PButton;
    btnStop:     PButton;
    btnSelect:   PButton;
    sbStatus:    PStatusBar;
  end;

{ Form Olu�turma Fonksiyonu }
function CreateNetAdapterForm: Boolean;
procedure LoadNetworkAdapters(Form: PFormNetAdapter);

implementation

{ ============================================================================ }
{ Yard�mc� D�n��t�r�c� Fonksiyonlar                                           }
{ ============================================================================ }


procedure MacToStr(const Mac: array of Byte; var OutStr: array of Char);
const
  HexChars: array[0..15] of Char = '0123456789ABCDEF';
var
  I, Pos: Integer;
begin
  Pos := 0;
  for I := 0 to 5 do
  begin
    // �st 4 bit (High Nibble)
    OutStr[Pos] := HexChars[Mac[I] shr 4];
    Inc(Pos);

    // Alt 4 bit (Low Nibble)
    OutStr[Pos] := HexChars[Mac[I] and $0F];
    Inc(Pos);

    // Son bayt de�ilse iki nokta ekle
    if I < 5 then
    begin
      OutStr[Pos] := ':';
      Inc(Pos);
    end;
  end;

  // Null terminator
  OutStr[Pos] := #0;
end;

{ ============================================================================ }
{ Ger�ek Verileri Y�kleme                                                      }
{ ============================================================================ }

procedure LoadNetworkAdapters(Form: PFormNetAdapter);
var
  I, Idx: Integer;
  MacBuf: array[0..31] of Char;
  AdapterName: PChar;
  SpeedStr: PChar;
begin
  if (Form = nil) or (Form^.lvAdapters = nil) then Exit;

  // Temizle
  ListViewClear(Form^.lvAdapters);

  // E�er hi� donan�m alg�lanmad�ysa tekrar tara
  if NetAdapterCount = 0 then
    AutoDetectAndInitNetworkDevices;

  if NetAdapterCount = 0 then
  begin
    if Form^.sbStatus <> nil then
      StatusBarSetText(Form^.sbStatus, 0, 'Sistemde ba�l� a� kart� bulunamad�.');
    Exit;
  end;

  for I := 0 to NetAdapterCount - 1 do
  begin
    // Kart Tipine g�re �sim ve H�z De�erlendirmesi
    case NetAdapters[I].AdapterType of
      natRTL8139:
        begin
          AdapterName := 'Realtek RTL8139 Ethernet';
          SpeedStr    := '100 Mbps';
        end;
      natNE2000:
        begin
          AdapterName := 'NE2000 PCI Ethernet';
          SpeedStr    := '10 Mbps';
        end;
    else
      AdapterName := 'Bilinmeyen A� Kart�';
      SpeedStr    := 'Bilinmiyor';
    end;

    // MAC Adresini D�n��t�r
    MacToStr(NetAdapters[I].MacAddr, MacBuf);

    // Listeye Ekle
    Idx := ListViewAddItem(Form^.lvAdapters, AdapterName, 0);
    
    // IP Adresi (Varsay�lan veya Statik IP g�sterimi)
    ListViewSetSubItem(Form^.lvAdapters, Idx, 0, '192.168.1.50'); 
    
    // MAC Adresi
    ListViewSetSubItem(Form^.lvAdapters, Idx, 1, MacBuf); 
    
    // Durum
    if NetAdapters[I].Active then
      ListViewSetSubItem(Form^.lvAdapters, Idx, 2, 'Aktif')
    else
      ListViewSetSubItem(Form^.lvAdapters, Idx, 2, 'Durduruldu');

    // H�z
    ListViewSetSubItem(Form^.lvAdapters, Idx, 3, SpeedStr);
  end;

  if Form^.sbStatus <> nil then
    StatusBarSetText(Form^.sbStatus, 0, 'A� ba�da�t�r�c�lar� listelendi.');
end;

{ ============================================================================ }
{ Event Handlers (Olay Y�neticileri)                                          }
{ ============================================================================ }

procedure DoAddAdapter(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  Form: PFormNetAdapter;
begin
  Form := PFormNetAdapter(FindRootForm(Sender)^.Control);
  if (Form = nil) then Exit;

  // Yeniden A� Cihazlar�n� Tara
  AutoDetectAndInitNetworkDevices;
  LoadNetworkAdapters(Form);

  if Form^.sbStatus <> nil then
    StatusBarSetText(Form^.sbStatus, 0, 'Donan�m taramas� yap�ld� ve liste g�ncellendi.');
end;

procedure DoDeleteAdapter(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  Form: PFormNetAdapter;
  SelIdx: Integer;
begin
  Form := PFormNetAdapter(FindRootForm(Sender)^.Control);
  if (Form = nil) or (Form^.lvAdapters = nil) then Exit;

  SelIdx := Form^.lvAdapters^.ItemIndex;
  if (SelIdx < 0) or (SelIdx >= NetAdapterCount) then
  begin
    if Form^.sbStatus <> nil then
      StatusBarSetText(Form^.sbStatus, 0, 'L�tfen listeden bir kart se�in!');
    Exit;
  end;

  // Ger�ek donan�m� pasife al�p listeden kald�r
  NetAdapters[SelIdx].Active := False;
  
  if Form^.sbStatus <> nil then
    StatusBarSetText(Form^.sbStatus, 0, 'A� kart� devre d��� b�rak�ld�.');

  LoadNetworkAdapters(Form);
end;

procedure DoStartAdapter(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  Form: PFormNetAdapter;
  SelIdx: Integer;
begin
  Form := PFormNetAdapter(FindRootForm(Sender)^.Control);
  if (Form = nil) or (Form^.lvAdapters = nil) then Exit;

  SelIdx := Form^.lvAdapters^.ItemIndex;
  if (SelIdx >= 0) and (SelIdx < NetAdapterCount) then
  begin
    // Donan�m� Aktif Et
    NetAdapters[SelIdx].Active := True;
    
    ListViewSetSubItem(Form^.lvAdapters, SelIdx, 2, 'Aktif');
    
    if Form^.sbStatus <> nil then
      StatusBarSetText(Form^.sbStatus, 0, 'A� ba�da�t�r�c�s� ba�lat�ld� (Active = True).');
  end
  else if Form^.sbStatus <> nil then
    StatusBarSetText(Form^.sbStatus, 0, 'L�tfen bir a� kart� se�in.');
end;

procedure DoStopAdapter(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  Form: PFormNetAdapter;
  SelIdx: Integer;
begin
  Form := PFormNetAdapter(FindRootForm(Sender)^.Control);
  if (Form = nil) or (Form^.lvAdapters = nil) then Exit;

  SelIdx := Form^.lvAdapters^.ItemIndex;
  if (SelIdx >= 0) and (SelIdx < NetAdapterCount) then
  begin
    // Donan�m� Pasif Et (Packet Polling ve Send durur)
    NetAdapters[SelIdx].Active := False;
    
    ListViewSetSubItem(Form^.lvAdapters, SelIdx, 2, 'Durduruldu');
    
    if Form^.sbStatus <> nil then
      StatusBarSetText(Form^.sbStatus, 0, 'A� ba�da�t�r�c�s� durduruldu (Active = False).');
  end
  else if Form^.sbStatus <> nil then
    StatusBarSetText(Form^.sbStatus, 0, 'L�tfen bir a� kart� se�in.');
end;

procedure DoSelectAdapter(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  Form: PFormNetAdapter;
  SelIdx: Integer;
  Msg: array[0..127] of Char;
begin
  Form := PFormNetAdapter(FindRootForm(Sender)^.Control);
  if (Form = nil) or (Form^.lvAdapters = nil) then Exit;

  SelIdx := Form^.lvAdapters^.ItemIndex;
  if (SelIdx >= 0) and (SelIdx < NetAdapterCount) then
  begin
    // Varsay�lan Etkin A� Kart� Olarak Se�
    NetAdapterIndex := SelIdx;

    StrCopy(Msg, 'Varsay�lan A� Kart� De�i�tirildi: Adapt�r #');
    Msg[StrLen(Msg)] := Char(Ord('0') + SelIdx);
    Msg[StrLen(Msg) + 1] := #0;

    if Form^.sbStatus <> nil then
      StatusBarSetText(Form^.sbStatus, 0, Msg);
  end
  else if Form^.sbStatus <> nil then
    StatusBarSetText(Form^.sbStatus, 0, 'Se�ili bir kart yok.');
end;

{ ============================================================================ }
{ Form Olu�turma ve Yap�land�rma                                               }
{ ============================================================================ }

function CreateNetAdapterForm: Boolean;
var
  F:    PForm;
  Data: PFormNetAdapter;
begin
  Result := False;

  // 1. Form Bellek Tahsisi
  Data := PFormNetAdapter(MemAlloc(SizeOf(TFormNetAdapter)));
  if Data = nil then Exit;
  FillChar(Data^, SizeOf(TFormNetAdapter), #0);

  F := CreateForm('A� Ba�da�t�r�c�lar� (NetAdapter Manager)', 260, 160, 640, 420);
  if F = nil then
  begin
    FreeMem(Data);
    Exit;
  end;

  F^.BorderStyle := bsWindow;
  F^.ShowSysButtons := True;
  F^.Color := clBtnFace;
  F^.Control := PObject(Data);

  // 2. Alt Panel (Butonlar ��in - Align: alBottom)
  Data^.pnlButtons := CreatePanel(PObject(F), 0, 0, 640, 45, alBottom);

  // Butonlar
  Data^.btnAdd := CreateButton(PObject(Data^.pnlButtons), 'Rescan', 10, 8, 75, 28);
  Data^.btnAdd^.BindMouseUp(@DoAddAdapter);

  Data^.btnDelete := CreateButton(PObject(Data^.pnlButtons), 'Disable', 90, 8, 75, 28);
  Data^.btnDelete^.BindMouseUp(@DoDeleteAdapter);

  Data^.btnStart := CreateButton(PObject(Data^.pnlButtons), 'Start', 170, 8, 75, 28);
  Data^.btnStart^.BindMouseUp(@DoStartAdapter);

  Data^.btnStop := CreateButton(PObject(Data^.pnlButtons), 'Stop', 250, 8, 75, 28);
  Data^.btnStop^.BindMouseUp(@DoStopAdapter);

  Data^.btnSelect := CreateButton(PObject(Data^.pnlButtons), 'Select Active', 330, 8, 100, 28);
  Data^.btnSelect^.BindMouseUp(@DoSelectAdapter);

  // 3. Durum �ubu�u (Status Bar - Align: alBottom)
  Data^.sbStatus := CreateStatusBar(PObject(F), 0, 0, 640, alBottom);
  StatusBarSetText(Data^.sbStatus, 0, 'Haz�r.');

  // 4. Ana ListView (A� Kartlar� Listesi - Align: alClient)
  Data^.lvAdapters := CreateListView(PObject(F), 0, 0, 640, 200, alClient);
  ListViewSetViewStyle(Data^.lvAdapters, 2); // 2 = Details
  Data^.lvAdapters^.GridLines := True;

  // ListView S�tunlar�
  ListViewAddColumn(Data^.lvAdapters, 'A� Ba�da�t�r�c�s�', 200);
  ListViewAddColumn(Data^.lvAdapters, 'IP Adresi', 110);
  ListViewAddColumn(Data^.lvAdapters, 'MAC Adresi', 140);
  ListViewAddColumn(Data^.lvAdapters, 'Durum', 80);
  ListViewAddColumn(Data^.lvAdapters, 'H�z', 70);

  // Ger�ek A� Kartlar�n� Y�kle
  LoadNetworkAdapters(Data);

  Result := True;
end;

end.

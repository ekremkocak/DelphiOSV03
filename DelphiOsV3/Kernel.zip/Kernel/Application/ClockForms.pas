unit ClockForms;

interface

uses
  SysUtils, Memory, Draw32, Vesa, GUI, GUIControls, Math, Messages;

{=============================================================================}
{ Analog + Dijital Saat Formu                                                 }
{=============================================================================}

type
  PClockData = ^TClockData;
  TClockData = record
    Hour, Minute, Second: Byte;
    DigitalPanel: PPanel;
    AnalogPanel: PPanel;
    MyTimer     : PTimer;
  end;

  procedure OpenClockForm;
  procedure ClockTick;  { Timer'dan / main loop'tan saniyede 1 �a��r�n }

implementation

  Uses TaskBar;

var
  ClockFormPtr: PForm = nil;

{-----------------------------------------------------------------------------}
{ TODO: Buray� kendi RTC / Sistem saatinizle de�i�tirin                       }
{-----------------------------------------------------------------------------}
procedure GetCurrentTime1(var H, M, S: Integer);
begin
  { �rnek de�erler. Ger�ek kod: RTC port okuma, BIOS time, NTP vb. }
  H := 10; M := 30; S := 45;
end;

{-----------------------------------------------------------------------------}
{ Dijital Saat �izimi (�st panel)                                             }
{-----------------------------------------------------------------------------}
procedure DigitalPanelDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  Panel: PPanel;
  Data: PClockData;
  F: PForm;
  W, H: Integer;
  TimeStr: array[0..15] of Char;
  Hr, Mn, Sc: Integer;
begin
  Panel := PPanel(Sender);
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PClockData(F^.Control);
  if Data = nil then Exit;

  W := Panel^.Width;
  H := Panel^.Height;

  { Koyu ye�il-siyah arka plan }
  KFill(AbsX, AbsY, W, H, $00002020);

  Hr := Data^.Hour;
  Mn := Data^.Minute;
  Sc := Data^.Second;

  { HH:MM:SS � manuel format (IntToStr ba��ml�l��� yok) }
  TimeStr[0] := Char(48 + (Hr div 10));
  TimeStr[1] := Char(48 + (Hr mod 10));
  TimeStr[2] := ':';
  TimeStr[3] := Char(48 + (Mn div 10));
  TimeStr[4] := Char(48 + (Mn mod 10));
  TimeStr[5] := ':';
  TimeStr[6] := Char(48 + (Sc div 10));
  TimeStr[7] := Char(48 + (Sc mod 10));
  TimeStr[8] := #0;

  { Ortalanm�� ye�il dijital saat }
  KStrCentered(AbsX, AbsY + (H - FONT_H) div 2, W, @TimeStr[0], $0000FF00);
end;

{-----------------------------------------------------------------------------}
{ Analog Saat �izimi (alt panel)                                              }
{-----------------------------------------------------------------------------}
procedure AnalogPanelDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  Panel: PPanel;
  Data: PClockData;
  F: PForm;
  W, H, CX, CY, R: Integer;
  i: Integer;
  Angle: Double;
  x1, y1, x2, y2: Integer;
  Hr, Mn, Sc: Integer;
begin


  Panel := PPanel(Sender);
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PClockData(F^.Control);
  if Data = nil then Exit;

  W := Panel^.Width;
  H := Panel^.Height;
  CX := AbsX + W div 2;
  CY := AbsY + H div 2;

  { Yar��ap: dar olan kenara g�re }
  if W < H then R := W div 2 - 20 else R := H div 2 - 20;
  if R < 20 then R := 20;

  { Siyah arka plan }
  KFill(AbsX, AbsY, W, H, $00000000);

  { Kadran �emberi (beyaz �er�eve) }
  KCircle(CX, CY, R, $00FFFFFF);
  { E�er KCircleFill yoksa alttaki sat�r� silin: }
  KFillCircle(CX, CY, R - 1, $00101010);

  { Saat i�aretleri (12 adet) }
  for i := 0 to 11 do
  begin
    Angle := (i * 30 - 90) * Pi / 180;
    if (i mod 3) = 0 then
    begin
      { 12, 3, 6, 9 � uzun ve beyaz }
      x1 := CX + Round((R - 20) * Cos(Angle));
      y1 := CY + Round((R - 20) * Sin(Angle));
      x2 := CX + Round((R - 5) * Cos(Angle));
      y2 := CY + Round((R - 5) * Sin(Angle));
      KLine(x1, y1, x2, y2, $00FFFFFF);
    end
    else
    begin
      { Ara saatler � k�sa ve gri }
      x1 := CX + Round((R - 12) * Cos(Angle));
      y1 := CY + Round((R - 12) * Sin(Angle));
      x2 := CX + Round((R - 5) * Cos(Angle));
      y2 := CY + Round((R - 5) * Sin(Angle));
      KLine(x1, y1, x2, y2, $00888888);
    end;
  end;

  { Dakika i�aretleri (60 adet k�sa �izgi) }
  for i := 0 to 59 do
  begin
    if (i mod 5) <> 0 then
    begin
      Angle := (i * 6 - 90) * Pi / 180;
      x1 := CX + Round((R - 8) * Cos(Angle));
      y1 := CY + Round((R - 8) * Sin(Angle));
      x2 := CX + Round((R - 5) * Cos(Angle));
      y2 := CY + Round((R - 5) * Sin(Angle));
      KLine(x1, y1, x2, y2, $00444444);
    end;
  end;

  { �bre a��lar� }
  Hr := Data^.Hour mod 12;
  Mn := Data^.Minute;
  Sc := Data^.Second;

  { Saat ibresi � k�sa, beyaz }
  Angle := (Hr * 30.0 + Mn * 0.5 - 90.0) * Pi / 180.0;
  x2 := CX + Round((R * 50 div 100) * Cos(Angle));
  y2 := CY + Round((R * 50 div 100) * Sin(Angle));
  KLine(CX, CY, x2, y2, $00FFFFFF);

  { Dakika ibresi � orta, beyaz }
  Angle := (Mn * 6.0 + Sc * 0.1 - 90.0) * Pi / 180.0;
  x2 := CX + Round((R * 75 div 100) * Cos(Angle));
  y2 := CY + Round((R * 75 div 100) * Sin(Angle));
  KLine(CX, CY, x2, y2, $00FFFFFF);

  { Saniye ibresi � uzun, k�rm�z� }
  Angle := (Sc * 6.0 - 90.0) * Pi / 180.0;
  x2 := CX + Round((R * 90 div 100) * Cos(Angle));
  y2 := CY + Round((R * 90 div 100) * Sin(Angle));
  KLine(CX, CY, x2, y2, $000000FF);

  { Merkez noktas� (k�rm�z�) � KCircleFill yoksa KCircle kullan�n }
  KFillCircle(CX, CY, 5, $000000FF);
end;

{-----------------------------------------------------------------------------}
{ Form kapan�nca belle�i temizle                                              }
{-----------------------------------------------------------------------------}
procedure ClockFormDestroy(Sender: PObject);
var
  F: PForm;
  Data: PClockData;
begin
  F := PForm(Sender);
  if F = nil then Exit;
  Data := PClockData(F^.Control);
  if Data <> nil then FreeMem(Data);
  F^.Control := nil;
  if ClockFormPtr = F then ClockFormPtr := nil;
end;


procedure TimerBlink(Sender: PObject);
var
  F: PForm;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  ClockTick;
end;


{-----------------------------------------------------------------------------}
{ Saat Formunu A�                                                             }
{-----------------------------------------------------------------------------}
procedure OpenClockForm;
var
  F: PForm;
  Data: PClockData;
begin
  if ClockFormPtr <> nil then Exit;  { Zaten a��ksa tekrar a�ma }

  F := CreateForm('Clock', 120, 100, 420, 520);
  if F = nil then Exit;

  F^.BorderStyle := bsWindow;
  F^.ShowSysButtons := True;
  F^.Color := clBtnFace;
  F^.BindDestroy(@ClockFormDestroy);

  Data := PClockData(MemAlloc(SizeOf(TClockData)));
  FillChar(Data^, SizeOf(TClockData), #0);
  F^.Control := PObject(Data);
  ClockFormPtr := F;

  { �stte dijital saat }
  Data^.DigitalPanel := CreatePanel(PObject(F), 0, 0, 0, 60, alTop);
  Data^.DigitalPanel^.Color := $00002020;
  Data^.DigitalPanel^.BorderWidth := 1;
  Data^.DigitalPanel^.BorderColor := $00444444;
  Data^.DigitalPanel^.BindPaint(@DigitalPanelDraw);

  { Altta analog saat }
  Data^.AnalogPanel := CreatePanel(PObject(F), 0, 0, 0, 0, alClient);
  Data^.AnalogPanel^.Color := $00000000;
  Data^.AnalogPanel^.BorderWidth := 1;
  Data^.AnalogPanel^.BorderColor := $00444444;
  Data^.AnalogPanel^.BindPaint(@AnalogPanelDraw);


  Data^.MyTimer := CreateTimer(PObject(F), 500);  // 500 ms
  Data^.MyTimer^.OnTimer := @TimerBlink;
  Data^.MyTimer^.Enabled := True;

  { �lk de�erleri al }
  GetRTCTime(Data^.Hour, Data^.Minute, Data^.Second);
end;

{-----------------------------------------------------------------------------}
{ Bu prosed�r� timer'�n�zdan / ana d�ng�n�zden �a��r�n                        }
{-----------------------------------------------------------------------------}
procedure ClockTick;
var
  Data: PClockData;
  H, M, S: Byte;
begin
  if ClockFormPtr = nil then Exit;

  Data := PClockData(ClockFormPtr^.Control);
  if Data = nil then Exit;

//  GetCurrentTime(H, M, S);

  GetRTCTime(H, M, S);

  { Sadece de�i�ti�inde yeniden �iz � bo�a CPU yakma }
  if (H <> Data^.Hour) or (M <> Data^.Minute) or (S <> Data^.Second) then
  begin
    Data^.Hour   := H;
    Data^.Minute := M;
    Data^.Second := S;
    RelayoutForm(ClockFormPtr);
  end;
end;

end.
unit ImageView;

interface

uses
  SysUtils, Memory, Draw32, Vesa, GUI, Math, GUIControls, Fat32, Messages,
  DirectoryView,JPEGDecoder,JPEGEncoder;

{type
  PByteArray = ^TByteArray;
  TByteArray = array[0..0] of Byte; }


 




type
  PImageViewData = ^TImageViewData;
  TImageViewData = record
    FilePath: array[0..255] of Char;
    RGBData: PByteArray;              { R,G,B,R,G,B... }
    BitmapWidth: Integer;
    BitmapHeight: Integer;
    Zoom: Integer;
    ImagePanel: PPanel;
    HScroll: PScrollBar;
    VScroll: PScrollBar;
    LblZoom: PLabel;
  end;

procedure OpenImageViewer(const FilePath: PChar);
procedure ImageViewUpdateScrollbars(Data: PImageViewData);
procedure ImagePanelDraw(Sender: PObject; AbsX, AbsY: Integer);

implementation

procedure UpdateZoomLabel(Data: PImageViewData);
var
  buf: array[0..15] of Char;
begin
  if Data^.LblZoom = nil then Exit;
  StrCopy(@Data^.LblZoom^.Caption[0], 'Zoom: ');
  IntToPChar(Data^.Zoom, @buf[0]);
  StrAppend(@Data^.LblZoom^.Caption[0], @buf[0]);
  StrAppend(@Data^.LblZoom^.Caption[0], '%');
end;

procedure ImageViewUpdateScrollbars(Data: PImageViewData);
var
  PanelW, PanelH, DrawW, DrawH: Integer;
begin
  if (Data = nil) or (Data^.ImagePanel = nil) then Exit;

  PanelW := Data^.ImagePanel^.Width;
  PanelH := Data^.ImagePanel^.Height;

  DrawW := Data^.BitmapWidth * Data^.Zoom div 100;
  DrawH := Data^.BitmapHeight * Data^.Zoom div 100;

  if Data^.HScroll <> nil then
  begin
    Data^.HScroll^.Max := MaxI(0, DrawW - PanelW);
    Data^.HScroll^.PageSize := PanelW;
    if Data^.HScroll^.Position > Data^.HScroll^.Max then
      ScrollBar_SetPosition(Data^.HScroll, Data^.HScroll^.Max);
  end;

  if Data^.VScroll <> nil then
  begin
    Data^.VScroll^.Max := MaxI(0, DrawH - PanelH);
    Data^.VScroll^.PageSize := PanelH;
    if Data^.VScroll^.Position > Data^.VScroll^.Max then
      ScrollBar_SetPosition(Data^.VScroll, Data^.VScroll^.Max);
  end;
end;



function LoadBMP(const FilePath: PChar; out Width, Height: Integer; out Pixels: PByteArray): Boolean;
var
  FH: TBMPFileHeader;
  IH: TBMPInfoHeader;
  F: Integer;
  FileSize, ReadBytes: LongWord;
  FileBuf: PByteArray;      // <-- Tum dosya bu tampona cekilecek
  SrcRowSize, DstRowSize: Integer;
  y, x: Integer;
  SrcOff, DstOff: LongWord;
  B, G, R: Byte;
begin
  Result := False;
  Pixels := nil;
  Width := 0; Height := 0;

  F := OpenFile(FilePath, FILE_READ);
  if F < 0 then Exit;

  { --- 1. Header oku --- }
  if ReadFile(F, @FH, SizeOf(FH)) <> SizeOf(FH) then begin CloseFile(F); Exit; end;
  if FH.bfType <> $4D42 then begin CloseFile(F); Exit; end;

  if ReadFile(F, @IH, SizeOf(IH)) <> SizeOf(IH) then begin CloseFile(F); Exit; end;
  if IH.biSize < 40 then begin CloseFile(F); Exit; end;
  if IH.biCompression <> 0 then begin CloseFile(F); Exit; end;

  Width  := IH.biWidth;
  Height := Abs(IH.biHeight);
  if (Width <= 0) or (Height <= 0) then begin CloseFile(F); Exit; end;

  { --- 2. Tum dosyayi tek seferde RAM'e al --- }
  FileSize := FH.bfSize;
  if FileSize < FH.bfOffBits then begin CloseFile(F); Exit; end;

  FileBuf := PByteArray(MemAlloc(FileSize));
  if FileBuf = nil then begin CloseFile(F); Exit; end;

  SeekFile(F, 0, SEEK_SET);
  ReadBytes := ReadFile(F, FileBuf, FileSize);
  CloseFile(F);

  if ReadBytes < FH.bfOffBits then begin FreeMem(FileBuf); Exit; end;

  { --- 3. Pixel bufferi ayir (D�ZELTME: Geni�lik * Y�kseklik * 3 bayt) --- }
  DstRowSize := Width * 3; // Hizalamas�z, ham kernel sat�r geni�li�i
  Pixels := PByteArray(MemAlloc(Width * Height * 3));
  if Pixels = nil then begin FreeMem(FileBuf); Exit; end;

  { --- 4. Bellekten bellege cevir (FileBuf -> Pixels) --- }
  if IH.biBitCount = 24 then
  begin
    SrcRowSize := ((Width * 3) + 3) and not 3; // BMP dosyas�ndaki 4 byte hizalamas�
    for y := 0 to Height - 1 do
    begin
      SrcOff := FH.bfOffBits + LongWord(Height - 1 - y) * SrcRowSize;
      
      // D�ZELTME: Hedef buffer art�k yukar�dan a�a��ya (Top-Down) ve 3 bayt ad�ml�
      DstOff := LongWord(y) * LongWord(DstRowSize);
      
      for x := 0 to Width - 1 do
      begin
        R := FileBuf[SrcOff + x * 3];
        G := FileBuf[SrcOff + x * 3 + 1];
        B := FileBuf[SrcOff + x * 3 + 2];
        
        Pixels[DstOff + x * 3]     := B;
        Pixels[DstOff + x * 3 + 1] := G;
        Pixels[DstOff + x * 3 + 2] := R;
      end;
    end;
  end
  else if IH.biBitCount = 32 then
  begin
    SrcRowSize := Width * 4;
    for y := 0 to Height - 1 do
    begin
      SrcOff := FH.bfOffBits + LongWord(Height - 1 - y) * SrcRowSize;
      DstOff := LongWord(y) * LongWord(DstRowSize);
      
      for x := 0 to Width - 1 do
      begin
        // 32 bitlik kaynaktan (B,G,R,A) ilk 3 rengi al�p 24 bitlik hedefe (B,G,R) yaz�yoruz
        R := FileBuf[SrcOff + x * 4];
        G := FileBuf[SrcOff + x * 4 + 1];
        B := FileBuf[SrcOff + x * 4 + 2];

        Pixels[DstOff + x * 3]     := B;
        Pixels[DstOff + x * 3 + 1] := G;
        Pixels[DstOff + x * 3 + 2] := R;
      end;
    end;
  end
  else
  begin
    FreeMem(Pixels); Pixels := nil;
    FreeMem(FileBuf);
    Exit;
  end;

  FreeMem(FileBuf);
  Result := True;
end;


procedure ImagePanelDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  Panel: PPanel;
  Data: PImageViewData;
  F: PForm;
  PanelW, PanelH: Integer;
  OffsetX, OffsetY: Integer;
  StartX, StartY, EndX, EndY: Integer;
  sx, sy, px, py: Integer;
  srcX, srcY: Integer;
  ZoomedSize: Integer;
  ScreenBase: LongWord;
  SrcOff: LongWord;
  DstPtr32: PLongWordArray;
  DstPtr24: PByteArray;
  R, G, B: Byte;
begin
  Panel := PPanel(Sender);
  F := FindRootForm(Sender);
  if (F = nil) or (Panel = nil) then Exit;

  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;

  PanelW := Panel^.Width - 16;
  PanelH := Panel^.Height - 16;
  if PanelW < 1 then Exit;
  if PanelH < 1 then Exit;

  KFill(AbsX, AbsY, PanelW, PanelH, $00E0E0E0);

  if (Data^.RGBData = nil) or
     (Data^.BitmapWidth <= 0) or
     (Data^.BitmapHeight <= 0) then
  begin
    KStrCentered(AbsX, AbsY + (PanelH - FONT_H) div 2,
                 PanelW, 'Resim yuklenemedi', clGray);
    Exit;
  end;

  OffsetX := 0;
  OffsetY := 0;
  if Data^.HScroll <> nil then OffsetX := Data^.HScroll^.Position;
  if Data^.VScroll <> nil then OffsetY := Data^.VScroll^.Position;

  { Gorunen kaynak araligi. Kaynak koordinati integer tabanli. }
  StartX := OffsetX * 100 div Data^.Zoom;
  StartY := OffsetY * 100 div Data^.Zoom;
  EndX := (OffsetX + PanelW) * 100 div Data^.Zoom + 1;
  EndY := (OffsetY + PanelH) * 100 div Data^.Zoom + 1;

  if StartX < 0 then StartX := 0;
  if StartY < 0 then StartY := 0;
  if EndX >= Data^.BitmapWidth then EndX := Data^.BitmapWidth - 1;
  if EndY >= Data^.BitmapHeight then EndY := Data^.BitmapHeight - 1;

  ScreenBase := LongWord(@Screen_Buffer[0]);

  {==============================================================}
  { ZOOM >= 100 : nearest-neighbor buyutme                      }
  {==============================================================}
  if Data^.Zoom >= 100 then
  begin
    ZoomedSize := Data^.Zoom div 100;
    if ZoomedSize < 1 then ZoomedSize := 1;

    for sy := StartY to EndY do
    begin
      py := sy * Data^.Zoom div 100 - OffsetY;
      if py + ZoomedSize <= 0 then Continue;
      if py >= PanelH then Break;

      for sx := StartX to EndX do
      begin
        px := sx * Data^.Zoom div 100 - OffsetX;

        if px + ZoomedSize <= 0 then Continue;
        if px >= PanelW then Continue;

        SrcOff := (LongWord(sy) * LongWord(Data^.BitmapWidth) +
                   LongWord(sx)) * 3;

        R := Data^.RGBData[SrcOff];
        G := Data^.RGBData[SrcOff + 1];
        B := Data^.RGBData[SrcOff + 2];

        if SCREEN_DEPTH = 4 then
        begin
          for srcY := 0 to ZoomedSize - 1 do
          begin
            if (py + srcY < 0) or (py + srcY >= PanelH) then Continue;

            DstPtr32 := PLongWordArray(
              ScreenBase +
              LongWord((AbsY + py + srcY) * SCREEN_WIDTH + AbsX) * 4);

            for srcX := 0 to ZoomedSize - 1 do
            begin
              if (px + srcX >= 0) and (px + srcX < PanelW) then
                DstPtr32[px + srcX] :=
                  (LongWord(R) shl 16) or
                  (LongWord(G) shl 8) or
                  LongWord(B);
            end;
          end;
        end
        else
        begin
          for srcY := 0 to ZoomedSize - 1 do
          begin
            if (py + srcY < 0) or (py + srcY >= PanelH) then Continue;

            DstPtr24 := PByteArray(
              ScreenBase +
              LongWord((AbsY + py + srcY) * SCREEN_WIDTH + AbsX) * 3);

            for srcX := 0 to ZoomedSize - 1 do
            begin
              if (px + srcX >= 0) and (px + srcX < PanelW) then
              begin
                { Ekran 24-bit buffer'i BGR kabul ediyor. }
                DstPtr24[(px + srcX) * 3]     := B;
                DstPtr24[(px + srcX) * 3 + 1] := G;
                DstPtr24[(px + srcX) * 3 + 2] := R;
              end;
            end;
          end;
        end;
      end;
    end;
  end

  {==============================================================}
  { ZOOM < 100 : nearest-neighbor kucultme                       }
  {==============================================================}
  else
  begin
    for py := 0 to PanelH - 1 do
    begin
      sy := (py + OffsetY) * 100 div Data^.Zoom;
      if (sy < 0) or (sy >= Data^.BitmapHeight) then Continue;

      if SCREEN_DEPTH = 4 then
      begin
        DstPtr32 := PLongWordArray(
          ScreenBase +
          LongWord((AbsY + py) * SCREEN_WIDTH + AbsX) * 4);

        for px := 0 to PanelW - 1 do
        begin
          sx := (px + OffsetX) * 100 div Data^.Zoom;
          if (sx < 0) or (sx >= Data^.BitmapWidth) then Continue;

          SrcOff := (LongWord(sy) * LongWord(Data^.BitmapWidth) +
                     LongWord(sx)) * 3;

          R := Data^.RGBData[SrcOff];
          G := Data^.RGBData[SrcOff + 1];
          B := Data^.RGBData[SrcOff + 2];

          DstPtr32[px] :=
            (LongWord(R) shl 16) or
            (LongWord(G) shl 8) or
            LongWord(B);
        end;
      end
      else
      begin
        DstPtr24 := PByteArray(
          ScreenBase +
          LongWord((AbsY + py) * SCREEN_WIDTH + AbsX) * 3);

        for px := 0 to PanelW - 1 do
        begin
          sx := (px + OffsetX) * 100 div Data^.Zoom;
          if (sx < 0) or (sx >= Data^.BitmapWidth) then Continue;

          SrcOff := (LongWord(sy) * LongWord(Data^.BitmapWidth) +
                     LongWord(sx)) * 3;

          R := Data^.RGBData[SrcOff];
          G := Data^.RGBData[SrcOff + 1];
          B := Data^.RGBData[SrcOff + 2];

          DstPtr24[px * 3]     := B;
          DstPtr24[px * 3 + 1] := G;
          DstPtr24[px * 3 + 2] := R;
        end;
      end;
    end;
  end;
end;

procedure ImageScrollChanged(Sender: PObject);
var
  F: PForm;
begin
  F := FindRootForm(Sender);
  if F <> nil then RelayoutForm(F);
end;

procedure BtnZoomInClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PImageViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;

  if Data^.Zoom < 400 then
  begin
    Data^.Zoom := Data^.Zoom + 25;
    ImageViewUpdateScrollbars(Data);
    UpdateZoomLabel(Data);
    RelayoutForm(F);
  end;
end;

procedure BtnZoomOutClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PImageViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;

  if Data^.Zoom > 25 then
  begin
    Data^.Zoom := Data^.Zoom - 25;
    ImageViewUpdateScrollbars(Data);
    UpdateZoomLabel(Data);
    RelayoutForm(F);
  end;
end;

procedure BtnZoom100Click(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PImageViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;

  Data^.Zoom := 100;

  if Data^.HScroll <> nil then
    ScrollBar_SetPosition(Data^.HScroll, 0);
  if Data^.VScroll <> nil then
    ScrollBar_SetPosition(Data^.VScroll, 0);

  ImageViewUpdateScrollbars(Data);
  UpdateZoomLabel(Data);
  RelayoutForm(F);
end;

procedure BtnZoomFitClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PImageViewData;
  Z1, Z2: Integer;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;
  if Data^.ImagePanel = nil then Exit;

  if (Data^.BitmapWidth <= 0) or (Data^.BitmapHeight <= 0) then Exit;

  Z1 := Data^.ImagePanel^.Width * 100 div Data^.BitmapWidth;
  Z2 := Data^.ImagePanel^.Height * 100 div Data^.BitmapHeight;

  if Z1 < Z2 then Data^.Zoom := Z1
  else Data^.Zoom := Z2;

  if Data^.Zoom < 25 then Data^.Zoom := 25;
  if Data^.Zoom > 400 then Data^.Zoom := 400;

  if Data^.HScroll <> nil then
    ScrollBar_SetPosition(Data^.HScroll, 0);
  if Data^.VScroll <> nil then
    ScrollBar_SetPosition(Data^.VScroll, 0);

  ImageViewUpdateScrollbars(Data);
  UpdateZoomLabel(Data);
  RelayoutForm(F);
end;

procedure BtnCloseClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
begin
  F := FindRootForm(Sender);
  { Form'un kapanmasi mevcut WindowManager tarafina birakiliyor. }
end;

procedure ImageViewDestroy(Sender: PObject);
var
  F: PForm;
  Data: PImageViewData;
begin
  F := PForm(Sender);
  if F = nil then Exit;

  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;

  if Data^.RGBData <> nil then
  begin
    FreeMem(Data^.RGBData);
    Data^.RGBData := nil;
  end;

  FreeMem(Data);
  F^.Control := nil;
end;


function EndsWithJPEG(FileName: PChar): Boolean;
var len: Integer;
begin
  Result := False;
  len := StrLen(FileName);
  if len < 5 then Exit;
  
  // .JPG veya .JPEG
  Result := ((FileName[len-4] = '.') or (FileName[len-4] = '.')) and
            ((FileName[len-3] = 'J') or (FileName[len-3] = 'j')) and
            ((FileName[len-2] = 'P') or (FileName[len-2] = 'p')) and
            ((FileName[len-1] = 'G') or (FileName[len-1] = 'g'));
end;


procedure OpenImageViewer(const FilePath: PChar);
var
  F: PForm;
  Data: PImageViewData;
  Toolbar: PPanel;
  Btn: PButton;
  W, H: Integer;
  Pixels: PByteArray;
  OutPixels: Pointer;
  OutSize: Integer;
  JF:Integer;
begin

  case DetectFileType(FilePath) of
    FT_JPG:begin

     Pixels:= JPEG_LoadFromFile(FilePath, W, H);

     if not FileExists('C:\Test.jpg') then
     begin
       JPEG_Encode('C:\Test.jpg',Pixels,W,H,75);
    end;
    end;
    //  if not LoadJPEG(FilePath, W, H, Pixels) then Exit;
    FT_BMP:
      if not LoadBMP(FilePath, W, H, Pixels) then Exit;

  end;

  F := CreateForm('Image Viewer', 120, 100, 700, 520);
  if F = nil then
  begin
    if Pixels <> nil then FreeMem(Pixels);
    Exit;
  end;

  F^.BorderStyle := bsWindow;
  F^.ShowSysButtons := True;
  F^.Position := poScreenCenter;
  F^.Color := clBtnFace;
  F^.BindDestroy(@ImageViewDestroy);

  Data := PImageViewData(MemAlloc(SizeOf(TImageViewData)));
  if Data = nil then
  begin
    if Pixels <> nil then FreeMem(Pixels);
    Exit;
  end;

  FillChar(Data^, SizeOf(TImageViewData), #0);

  StrCopy(@Data^.FilePath[0], FilePath);
  Data^.RGBData := Pixels;
  Data^.BitmapWidth := W;
  Data^.BitmapHeight := H;
  Data^.Zoom := 100;

  F^.Control := PObject(Data);

  Toolbar := CreatePanel(PObject(F), 0, 0, 0, 36, alTop);
  Toolbar^.Color := clBtnFace;
  Toolbar^.BorderWidth := 0;

  Btn := CreateButton(PObject(Toolbar), '+', 8, 6, 28, 24, alNone);
  Btn^.BindMouseUp(@BtnZoomInClick);

  Btn := CreateButton(PObject(Toolbar), '-', 40, 6, 28, 24, alNone);
  Btn^.BindMouseUp(@BtnZoomOutClick);

  Btn := CreateButton(PObject(Toolbar), '100', 72, 6, 36, 24, alNone);
  Btn^.BindMouseUp(@BtnZoom100Click);

  Btn := CreateButton(PObject(Toolbar), 'Fit', 112, 6, 36, 24, alNone);
  Btn^.BindMouseUp(@BtnZoomFitClick);

  Btn := CreateButton(PObject(Toolbar), 'X', 156, 6, 28, 24, alNone);
  Btn^.BindMouseUp(@BtnCloseClick);

  Data^.LblZoom :=
    CreateLabel(PObject(Toolbar), 'Zoom: 100%', 200, 10, 100, 20, alNone);

  Data^.VScroll := CreateScrollBar(PObject(F), 0, 0, 16, 100, alRight);
  Data^.VScroll^.Min := 0;
  Data^.VScroll^.Max := 0;
  Data^.VScroll^.PageSize := 100;
  Data^.VScroll^.SmallChange := 10;

  Data^.HScroll := CreateScrollBar(PObject(F), 0, 0, 100, 16, alBottom);
  Data^.HScroll^.Min := 0;
  Data^.HScroll^.Max := 0;
  Data^.HScroll^.PageSize := 100;
  Data^.HScroll^.SmallChange := 10;

  Data^.ImagePanel := CreatePanel(PObject(F), 0, 0, 0, 0, alClient);
  Data^.ImagePanel^.Color := $00E0E0E0;
  Data^.ImagePanel^.BorderWidth := 1;
  Data^.ImagePanel^.BorderColor := cl3DDkShadow;
  Data^.ImagePanel^.BindPaint(@ImagePanelDraw);

  ImageViewUpdateScrollbars(Data);
  UpdateZoomLabel(Data);
end;

end.

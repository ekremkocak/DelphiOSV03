unit PaintApp;

interface

uses
  SysUtils, GUI, GUIControls, Memory, Draw32, Math;

type
  TPaintTool = (ptPen, ptLine, ptRect, ptFillRect, ptEllipse, ptEraser);

  PDrawCmd = ^TDrawCmd;
  TDrawCmd = record
    Next: PDrawCmd;
    Tool: TPaintTool;
    Color: LongWord;
    PenWidth: Integer;
    X1, Y1, X2, Y2: Integer;
  end;

  PPaintApp = ^TPaintApp;
  TPaintApp = object
  private
    FForm: PForm;
    FCanvasPanel: PObject;
    FColorBar: PObject;
    FStatusBar: PStatusBar;
    FToolBar: PToolBar;
    FCmdList: PDrawCmd;
    FCmdLast: PDrawCmd;
    FCurrentTool: TPaintTool;
    FCurrentColor: LongWord;
    FPenWidth: Integer;
    FDrawing: Boolean;
    FStartX, FStartY: Integer;
    FLastX, FLastY: Integer;
    
    procedure UpdateStatus;
  public
    procedure Init;
    procedure DoClose;
    procedure ClearCanvas;
    procedure SetTool(Tool: TPaintTool);
    procedure SetColor(Color: LongWord);
    procedure SetPenWidth(Width: Integer);
    procedure RedrawCanvas(Sender: PPanel; X, Y: Integer);
    procedure OnPaintToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
  end;

procedure OpenPaintApp; 

procedure PaintAppFormDestroy(Sender: PObject);

var
  PaintApp1: TPaintApp;

implementation

const
  COLOR_BAR_HEIGHT = 24;
  COLORS: array[0..15] of LongWord = (
    $00000000, $00000080, $00008000, $00008080, $00800000, $00800080, $00808000, $00808080,
    $00C0C0C0, $000000FF, $0000FF00, $0000FFFF, $00FF0000, $00FF00FF, $00FFFF00, $00FFFFFF
  );

{-----------------------------------------------------------------------------}
{ Yardimci: Hex renk stringi }
{-----------------------------------------------------------------------------}
procedure ColorToHex(Color: LongWord; Buf: PChar);
const
  HexChars: array[0..15] of Char = '0123456789ABCDEF';
var
  I: Integer;
begin
  for I := 5 downto 0 do
  begin
    Buf[5-I] := HexChars[(Color shr (I*4)) and $F];
  end;
  Buf[6] := #0;
end;

{-----------------------------------------------------------------------------}
{ Komut Listesi Yonetimi }
{-----------------------------------------------------------------------------}
procedure AddDrawCmd(Tool: TPaintTool; Color: LongWord; PenW, X1, Y1, X2, Y2: Integer);
var
  Cmd: PDrawCmd;
begin
  Cmd := PDrawCmd(MemAlloc(SizeOf(TDrawCmd)));
  FillChar(Cmd^, SizeOf(TDrawCmd), 0);
  Cmd^.Tool := Tool;
  Cmd^.Color := Color;
  Cmd^.PenWidth := PenW;
  Cmd^.X1 := X1;
  Cmd^.Y1 := Y1;
  Cmd^.X2 := X2;
  Cmd^.Y2 := Y2;
  
  if PaintApp1.FCmdLast <> nil then
    PaintApp1.FCmdLast^.Next := Cmd
  else
    PaintApp1.FCmdList := Cmd;
  PaintApp1.FCmdLast := Cmd;
end;

procedure FreeDrawCmds;
var
  Cmd, Next: PDrawCmd;
begin
  Cmd := PaintApp1.FCmdList;
  while Cmd <> nil do
  begin
    Next := Cmd^.Next;
    FreeMem(Cmd);
    Cmd := Next;
  end;
  PaintApp1.FCmdList := nil;
  PaintApp1.FCmdLast := nil;
end;

{-----------------------------------------------------------------------------}
{ TPaintApp }
{-----------------------------------------------------------------------------}
procedure TPaintApp.Init;
begin
 { FForm := nil;
  FCanvasPanel := nil;
  FColorBar := nil;
  FStatusBar := nil;
  FToolBar := nil; }
  FCmdList := nil;
  FCmdLast := nil;
  FCurrentTool := ptPen;
  FCurrentColor := clBlack;
  FPenWidth := 2;
  FDrawing := False;
end;

procedure TPaintApp.UpdateStatus;
var
  Buf: array[0..127] of Char;
  ToolStr: PChar;
  HexBuf: array[0..7] of Char;
begin
  if FStatusBar = nil then Exit;
  
  case FCurrentTool of
    ptPen: ToolStr := 'Kalem';
    ptLine: ToolStr := 'Cizgi';
    ptRect: ToolStr := 'Kare';
    ptFillRect: ToolStr := 'Doldur';
    ptEllipse: ToolStr := 'Daire';
    ptEraser: ToolStr := 'Silgi';
  else
    ToolStr := '?';
  end;
  
  Buf[0] := #0;
  StrAppend(@Buf[0], 'Alet: ');
  StrAppend(@Buf[0], ToolStr);
  StrAppend(@Buf[0], ' | Kalinlik: ');
  IntToPChar(FPenWidth, @Buf[StrLen(@Buf[0])]);
  StrAppend(@Buf[0], ' | Renk: $');
  ColorToHex(FCurrentColor, @HexBuf[0]);
  StrAppend(@Buf[0], @HexBuf[0]);
  
  StatusBarSetText(FStatusBar, 0, @Buf[0]);
end;

procedure TPaintApp.DoClose;
begin
  if FForm <> nil then
    WinManager.RemoveForm(PForm(FForm));
end;

procedure TPaintApp.ClearCanvas;
begin
  FreeDrawCmds;
  if FCanvasPanel <> nil then
    KFill(FCanvasPanel^.AbsLeft, FCanvasPanel^.AbsTop, 
          FCanvasPanel^.Width, FCanvasPanel^.Height, clWhite);
end;

procedure TPaintApp.SetTool(Tool: TPaintTool);
begin
  FCurrentTool := Tool;
  UpdateStatus;
end;

procedure TPaintApp.SetColor(Color: LongWord);
begin
  FCurrentColor := Color;
  if FColorBar <> nil then
    FColorBar^.FirePaint(0, 0);  { Renk cubugunu yeniden ciz }
  UpdateStatus;
end;

procedure TPaintApp.SetPenWidth(Width: Integer);
begin
  if Width < 1 then Width := 1;
  if Width > 10 then Width := 10;
  FPenWidth := Width;
  UpdateStatus;
end;

procedure TPaintApp.RedrawCanvas(Sender: PPanel; X, Y: Integer);
var
  Cmd: PDrawCmd;
  AX, AY, X1, Y1, X2, Y2, W, H, CX, CY, RX, RY: Integer;
begin
  if FCanvasPanel = nil then Exit;
  
  AX := X;
  AY := Y;
  
  { Canvas arka plan - kagit beyazi }
  KFill(AX, AY, FCanvasPanel^.Width, FCanvasPanel^.Height, clWhite);
  
  { Tum komutlari ciz }
  Cmd := FCmdList;
  while Cmd <> nil do
  begin
    X1 := AX + Cmd^.X1;
    Y1 := AY + Cmd^.Y1;
    X2 := AX + Cmd^.X2;
    Y2 := AY + Cmd^.Y2;
    
    case Cmd^.Tool of
      ptPen, ptLine:
        KLine(X1, Y1, X2, Y2, Cmd^.Color);
        
      ptRect:
        begin
          W := Abs(Cmd^.X2 - Cmd^.X1);
          H := Abs(Cmd^.Y2 - Cmd^.Y1);
          KRect(AX + Min(Cmd^.X1, Cmd^.X2), AY + Min(Cmd^.Y1, Cmd^.Y2), W, H, Cmd^.Color);
        end;
        
      ptFillRect:
        begin
          W := Abs(Cmd^.X2 - Cmd^.X1);
          H := Abs(Cmd^.Y2 - Cmd^.Y1);
          KFill(AX + Min(Cmd^.X1, Cmd^.X2), AY + Min(Cmd^.Y1, Cmd^.Y2), W, H, Cmd^.Color);
        end;
        
      ptEllipse:
        begin
          RX := Abs(Cmd^.X2 - Cmd^.X1) div 2;
          RY := Abs(Cmd^.Y2 - Cmd^.Y1) div 2;
          CX := AX + (Cmd^.X1 + Cmd^.X2) div 2;
          CY := AY + (Cmd^.Y1 + Cmd^.Y2) div 2;
          { KEllipse yoksa KCircle ile veya elips cizen ozel bir dongu ile degistir }
          KEllipse(CX, CY, RX, RY, Cmd^.Color);
        end;
        
      ptEraser:
        KFill(X1 - 4, Y1 - 4, 8, 8, clWhite);
    end;
    Cmd := Cmd^.Next;
  end;
end;

{-----------------------------------------------------------------------------}
{ Canvas Mouse Olaylari }
{-----------------------------------------------------------------------------}
procedure CanvasMouseDown(Sender: PObject; X, Y: Integer; Btn: Byte);
begin
  if Btn <> 1 then Exit;
  PaintApp1.FDrawing := True;
  PaintApp1.FStartX := X;
  PaintApp1.FStartY := Y;
  PaintApp1.FLastX := X;
  PaintApp1.FLastY := Y;
end;

procedure CanvasMouseMove(Sender: PObject; X, Y: Integer; Btn: Byte);
var
  AX, AY: Integer;
begin
  if not PaintApp1.FDrawing then Exit;
  
  AX := Sender^.AbsLeft;
  AY := Sender^.AbsTop;
  
  case PaintApp1.FCurrentTool of
    ptPen:
      begin
        AddDrawCmd(ptPen, PaintApp1.FCurrentColor, PaintApp1.FPenWidth,
                   PaintApp1.FLastX, PaintApp1.FLastY, X, Y);
        KLine(AX + PaintApp1.FLastX, AY + PaintApp1.FLastY,
              AX + X, AY + Y, PaintApp1.FCurrentColor);
        PaintApp1.FLastX := X;
        PaintApp1.FLastY := Y;
      end;
      
    ptEraser:
      begin
        AddDrawCmd(ptEraser, clWhite, PaintApp1.FPenWidth, X, Y, X, Y);
        KFill(AX + X - 4, AY + Y - 4, 8, 8, clWhite);
      end;
  end;
end;

procedure CanvasMouseUp(Sender: PPanel; X, Y: Integer; Btn: Byte);
begin
  if not PaintApp1.FDrawing then Exit;
  PaintApp1.FDrawing := False;
  
  { Tek nokta tiklama (hic surukleme olmadiysa) sekil ciziminde iptal }
  if (PaintApp1.FCurrentTool <> ptPen) and (PaintApp1.FCurrentTool <> ptEraser) then
    if (X = PaintApp1.FStartX) and (Y = PaintApp1.FStartY) then Exit;
  
  case PaintApp1.FCurrentTool of
    ptLine:
      AddDrawCmd(ptLine, PaintApp1.FCurrentColor, PaintApp1.FPenWidth,
                 PaintApp1.FStartX, PaintApp1.FStartY, X, Y);
                 
    ptRect:
      AddDrawCmd(ptRect, PaintApp1.FCurrentColor, PaintApp1.FPenWidth,
                 PaintApp1.FStartX, PaintApp1.FStartY, X, Y);
                 
    ptFillRect:
      AddDrawCmd(ptFillRect, PaintApp1.FCurrentColor, PaintApp1.FPenWidth,
                 PaintApp1.FStartX, PaintApp1.FStartY, X, Y);
                 
    ptEllipse:
      AddDrawCmd(ptEllipse, PaintApp1.FCurrentColor, PaintApp1.FPenWidth,
                 PaintApp1.FStartX, PaintApp1.FStartY, X, Y);
  end;
  
  { Sekil cizimlerinde tum canvas'i yeniden ciz (duzgun gorunum) }
  if PaintApp1.FCurrentTool <> ptPen then
    PaintApp1.RedrawCanvas(Sender,X,Y);
end;

{-----------------------------------------------------------------------------}
{ Renk Cubugu: Gorsel + Etkilesim }
{-----------------------------------------------------------------------------}
procedure ColorBarPaint(Sender: PPanel; AX, AY: Integer);
var
  I: Integer;
begin
  { 3D arka plan }
  KFill(AX, AY, Sender^.Width, Sender^.Height, $00D4D0C8);
  KRect(AX, AY, Sender^.Width, Sender^.Height, clGray);
  KLineH(AX + 1, AY + 1, Sender^.Width - 2, clWhite);
  KLineV(AX + 1, AY + 1, Sender^.Height - 2, clWhite);
  
  { 16 renk karesi }
  for I := 0 to 15 do
  begin
    { Golge/derinlik efekti }
    KFill(AX + 5 + I * 22, AY + 4, 18, 18, clBlack);
    KFill(AX + 4 + I * 22, AY + 3, 18, 18, clWhite);
    
    { Renk kutusu }
    KFill(AX + 4 + I * 22, AY + 3, 17, 17, COLORS[I]);
    
    { Secili renk vurgusu - basik 3D cerceve }
    if COLORS[I] = PaintApp1.FCurrentColor then
    begin
      KRect(AX + 3 + I * 22, AY + 2, 19, 19, clBlack);
      KLineH(AX + 4 + I * 22, AY + 3, 17, clWhite);
      KLineV(AX + 4 + I * 22, AY + 3, 17, clWhite);
      KLineH(AX + 4 + I * 22, AY + 19, 17, clGray);
      KLineV(AX + 20 + I * 22, AY + 3, 17, clGray);
    end
    else
    begin
      KRect(AX + 4 + I * 22, AY + 3, 17, 17, clGray);
    end;
  end;
end;

procedure ColorBarMouseDown(Sender: PPanel; X, Y: Integer; Btn: Byte);
var
  I: Integer;
begin
  if Btn <> 1 then Exit;
  I := (X - 4) div 22;
  if (I >= 0) and (I <= 15) then
    PaintApp1.SetColor(COLORS[I]);
end;

{-----------------------------------------------------------------------------}
{ Canvas Panel OnPaint - Form yenilendiginde cizimleri koru }
{-----------------------------------------------------------------------------}
procedure CanvasPanelPaint(Sender: PPanel; AX, AY: Integer);
begin
  PaintApp1.RedrawCanvas(Sender,AX, AY);
end;

{-----------------------------------------------------------------------------}
{ Toolbar Click Handler }
{-----------------------------------------------------------------------------}
procedure TPaintApp.OnPaintToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
begin
  case ButtonIndex of
    0: SetTool(ptPen);
    1: SetTool(ptLine);
    2: SetTool(ptRect);
    3: SetTool(ptFillRect);
    4: SetTool(ptEllipse);
    5: SetTool(ptEraser);
    6: SetPenWidth(PaintApp1.FPenWidth + 1);  { Kalinlik + }
    7: SetPenWidth(PaintApp1.FPenWidth - 1);  { Kalinlik - }
    9: ClearCanvas;   { Ayirac sonrasi Temizle }
    11: DoClose;      { Ayirac sonrasi Kapat }
  end;
end;

procedure PaintAppFormDestroy(Sender: PObject);
begin
  FreeDrawCmds;
 { PaintApp1.FForm := nil;
  PaintApp1.FCanvasPanel := nil;
  PaintApp1.FColorBar := nil;
  PaintApp1.FStatusBar := nil;
  PaintApp1.FToolBar := nil; }
end;

{-----------------------------------------------------------------------------}
{ Fabrika }
{-----------------------------------------------------------------------------}
procedure OpenPaintApp;
begin
  with PaintApp1 do
  begin
    Init;
    
    FForm := CreateForm('Resim Editoru', 80, 60, 800, 600);
    FForm^.Color := clBtnFace;
    FForm^.BindDestroy(@PaintAppFormDestroy);
    

    FToolBar := CreateToolBar(PObject(FForm), 0, 0, 800, 36, alTop);
    FToolBar^.ShowCaptions := True;
    FToolBar^.Flat := False;
    ToolBarAddButton(FToolBar, 'Kalem', 50);
    ToolBarAddButton(FToolBar, 'Cizgi', 50);
    ToolBarAddButton(FToolBar, 'Kare', 50);
    ToolBarAddButton(FToolBar, 'Doldur', 50);
    ToolBarAddButton(FToolBar, 'Daire', 50);
    ToolBarAddButton(FToolBar, 'Silgi', 50);
    ToolBarAddSeparator(FToolBar);
    ToolBarAddButton(FToolBar, 'Kalin+', 50);
    ToolBarAddButton(FToolBar, 'Kalin-', 50);
    ToolBarAddSeparator(FToolBar);
    ToolBarAddButton(FToolBar, 'Temizle', 60);
    ToolBarAddSeparator(FToolBar);
    ToolBarAddButton(FToolBar, 'Kapat', 50); 
    FToolBar^.OnClick := OnPaintToolBarClick;

     

    FColorBar := CreatePanel(PObject(FForm), 0, 0, 800, COLOR_BAR_HEIGHT + 6, alTop);
    FColorBar^.Color := $00D4D0C8;
    FColorBar^.BindPaint(@ColorBarPaint);
    FColorBar^.BindMouseDown(@ColorBarMouseDown);


    FStatusBar := CreateStatusBar(PObject(FForm), 0, 0, 800, alBottom);
    FStatusBar^.AddPanel('Hazir', 500);
     
  
    FCanvasPanel := CreatePanel(PObject(FForm), 0, 0, 800, 400, alClient);
    FCanvasPanel^.Color := clWhite;
    FCanvasPanel^.BorderWidth := 2;
    FCanvasPanel^.BorderColor := clGray;
    FCanvasPanel^.BindPaint(@CanvasPanelPaint);
    FCanvasPanel^.BindMouseDown(@CanvasMouseDown);
    FCanvasPanel^.BindMouseMove(@CanvasMouseMove);
    FCanvasPanel^.BindMouseUp(@CanvasMouseUp);

   
    UpdateStatus;
  end;
end;

end.

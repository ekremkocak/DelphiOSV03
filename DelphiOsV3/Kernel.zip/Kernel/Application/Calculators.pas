unit Calculators;

interface

uses
  SysUtils, GUI, GUIControls, Memory, Draw32;

type
  PCalculator = ^TCalculator;
  TCalculator = object
  public
    FForm        : PForm;
    DisplayPanel : PPanel;
    
    DisplayStr   : array[0..31] of Char;
    Value1       : Integer;
    Value2       : Integer;
    Op           : Char; // '+', '-', '*', '/', #0
    NewInput     : Boolean;

    procedure Init;
    procedure Clear;
    procedure AppendDigit(D: Char);
    procedure SetOperator(O: Char);
    procedure Compute;
  end;

procedure OpenCalculator();

var
  Calc1: TCalculator;

   BtnLabels: array[0..15] of PChar = (
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    'C', '0', '=', '+'
  );

implementation

{ Yard�mc� String D�n��t�r�c�ler }
procedure IntToCalcStr(Val: Integer; Buffer: PChar);
var
  Temp: array[0..31] of Char;
  i, j, Len: Integer;
  IsNeg: Boolean;
begin
  if Val = 0 then
  begin
    Buffer[0] := '0';
    Buffer[1] := #0;
    Exit;
  end;
  
  IsNeg := Val < 0;
  if IsNeg then Val := -Val;
  
  Len := 0;
  while Val > 0 do
  begin
    Temp[Len] := Char(Ord('0') + (Val mod 10));
    Val := Val div 10;
    Inc(Len);
  end;
  
  j := 0;
  if IsNeg then
  begin
    Buffer[0] := '-';
    Inc(j);
  end;
  
  for i := Len - 1 downto 0 do
  begin
    Buffer[j] := Temp[i];
    Inc(j);
  end;
  Buffer[j] := #0;
end;

function CalcStrToInt(Str: PChar): Integer;
var
  i: Integer;
  Res: Integer;
  IsNeg: Boolean;
begin
  Res := 0;
  i := 0;
  IsNeg := False;
  if Str[0] = '-' then
  begin
    IsNeg := True;
    Inc(i);
  end;
  while Str[i] <> #0 do
  begin
    if (Str[i] >= '0') and (Str[i] <= '9') then
      Res := Res * 10 + (Ord(Str[i]) - Ord('0'));
    Inc(i);
  end;
  if IsNeg then Res := -Res;
  Result := Res;
end;

{ TCalculator Metotlar� }
procedure TCalculator.Init;
begin
  DisplayStr[0] := '0';
  DisplayStr[1] := #0;
  Value1 := 0;
  Value2 := 0;
  Op := #0;
  NewInput := True;
end;

procedure TCalculator.Clear;
begin
  Init;
end;

procedure TCalculator.AppendDigit(D: Char);
var
  Len: Integer;
begin
  if NewInput then
  begin
    DisplayStr[0] := D;
    DisplayStr[1] := #0;
    NewInput := False;
  end
  else
  begin
    Len := StrLen(@DisplayStr[0]);
    if (Len = 1) and (DisplayStr[0] = '0') then
    begin
      DisplayStr[0] := D;
    end
    else if Len < 18 then
    begin
      DisplayStr[Len] := D;
      DisplayStr[Len + 1] := #0;
    end;
  end;
end;

procedure TCalculator.SetOperator(O: Char);
begin
  if Op <> #0 then Compute;
  Value1 := CalcStrToInt(@DisplayStr[0]);
  Op := O;
  NewInput := True;
end;

procedure TCalculator.Compute;
var
  Res: Integer;
begin
  if Op = #0 then Exit;
  Value2 := CalcStrToInt(@DisplayStr[0]);
  Res := 0;
  
  case Op of
    '+': Res := Value1 + Value2;
    '-': Res := Value1 - Value2;
    '*': Res := Value1 * Value2;
    '/': if Value2 <> 0 then Res := Value1 div Value2 else Res := 0;
  end;

  IntToCalcStr(Res, @DisplayStr[0]);
  Value1 := Res;
  Op := #0;
  NewInput := True;
end;

{ Ekran ve Buton Olaylar� }
procedure DrawDisplay(Sender: PPanel; AbsX, AbsY: Integer);
var
  StrW, TextX: Integer;
begin
  // G�sterge Arka Plan� (Koyu Dijital Ekran)
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, $00202020);
  KRect(AbsX, AbsY, Sender^.Width, Sender^.Height, $00808080);

  // Metni Sa� Sa�a Hizalama Hesab� (Karakter ba�� ~8px)
  StrW := StrLen(@Calc1.DisplayStr[0]) * 8;
  TextX := AbsX + Sender^.Width - StrW - 12;
  if TextX < AbsX + 5 then TextX := AbsX + 5;

  KStr(TextX, AbsY + (Sender^.Height div 2) - 4, @Calc1.DisplayStr[0], $0000FF00); // Ye�il Dijital Yaz�
end;

procedure OnBtnClick(Sender: PObject; X, Y: Integer; Btn: Byte);
var
  Btn1: PButton;
  Cap: Char;
begin
  Btn1 := PButton(Sender);
  Cap := Btn1^.Caption[0];

  case Cap of
    '0'..'9': Calc1.AppendDigit(Cap);
    '+', '-', '*', '/': Calc1.SetOperator(Cap);
    '=': Calc1.Compute;
    'C': Calc1.Clear;
  end;
end;

procedure OpenCalculator();
var
  Row, Col: Integer;
  BtnX, BtnY, BtnW, BtnH, Gap: Integer;

  BtnObj: PButton;
  Idx: Integer;
begin
  Calc1.Init;

  // 220x290 boyutunda Form olu�tur
  Calc1.FForm := CreateForm('Hesap Makinesi', 250, 150, 220, 300, bsDialog);

  // 1. �st Ekran Paneli
  Calc1.DisplayPanel := CreatePanel(PObject(Calc1.FForm), 10, 20, 200, 40, alTop);
  Calc1.DisplayPanel^.BindPaint(@DrawDisplay);

  // 2. Buton Izgaras� (4x4 Tu� Tak�m�)
  BtnW := 42;
  BtnH := 40;
  Gap  := 10;

  for Row := 0 to 3 do
  begin
    for Col := 0 to 3 do
    begin
      Idx := (Row * 4) + Col;
      BtnX := 10 + Col * (BtnW + Gap);
      BtnY := 80 + Row * (BtnH + Gap);

      BtnObj := CreateButton(PObject(Calc1.FForm), BtnLabels[Idx], BtnX, BtnY, BtnW, BtnH);
      BtnObj^.BindMouseDown(@OnBtnClick);
    end;
  end;
end;

end.
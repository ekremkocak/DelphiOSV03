unit TextEditor;

interface

uses
  SysUtils, GUI, GUIControls, Memory,Mouse, Draw32, Fat32, Math;

const
  TE_MAX_PATH = 256;

type
  PTextEditor = ^TTextEditor;

  TTextEditor = object
  private
    FForm: PForm;
    FPopupMenu:PPopupMenu;
    
    FStatusBar: PStatusBar;
    FFileName: array[0..TE_MAX_PATH-1] of Char;
    FModified: Boolean;

    procedure SetModified(Value: Boolean);
    procedure UpdateStatus;
    function  GetTextBuf: PChar;
  public
    FMemo: PMemo;
    procedure LoadFile(const Path: PChar);
    procedure SaveFile;
    procedure NewFile;
    
    procedure DoOpen;
    procedure DoSave;
    procedure DoNew;
    procedure DoClose;
    procedure OnTextEditorToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
    property Modified: Boolean read FModified write SetModified;
  end;

procedure OpenTextEditor(const Path: PChar);

procedure TextEditorMemoKeyDown(Sender: PObject; Key: Word);
procedure TextEditorFormDestroy(Sender: PObject);

var
  TextEditor1: TTextEditor;

implementation

 Uses Messages;

{-----------------------------------------------------------------------------}
{ Yardimci }
{-----------------------------------------------------------------------------}

function MemoGetText(Memo: PMemo): PChar;
var
  TotalLen, I, LineLen: Integer;
  Dest: PChar;
begin
  TotalLen := 0;
  for I := 0 to Memo^.LineCount - 1 do
  begin
    Inc(TotalLen, MemoLineLength(Memo, I));
    if I < Memo^.LineCount - 1 then Inc(TotalLen, 2); // #13#10
  end;
  
  Result := PChar(MemAlloc(TotalLen + 1));
  if Result = nil then Exit;
  
  Dest := Result;
  for I := 0 to Memo^.LineCount - 1 do
  begin
    LineLen := MemoLineLength(Memo, I);
    if LineLen > 0 then
    begin
      Move(Memo^.Lines^[I]^, Dest^, LineLen);
      Inc(Dest, LineLen);
    end;
    if I < Memo^.LineCount - 1 then
    begin
      Dest^ := #13; Inc(Dest);
      Dest^ := #10; Inc(Dest);
    end;
  end;
  Dest^ := #0;
end;

{-----------------------------------------------------------------------------}
{ TTextEditor }
{-----------------------------------------------------------------------------}

procedure TTextEditor.SetModified(Value: Boolean);
begin
  FModified := Value;
  UpdateStatus;
end;

procedure TTextEditor.UpdateStatus;
var
  Buf: array[0..63] of Char;
begin
  if FStatusBar = nil then Exit;
  
  // Panel 0: Dosya adi
  if FFileName[0] <> #0 then
    StatusBarSetText(FStatusBar, 0, @FFileName[0])
  else
    StatusBarSetText(FStatusBar, 0, 'Yeni Belge');
  
  // Panel 1: Satir / Sutun
  Buf[0] := #0;
  StrAppend(@Buf[0], 'Sat: ');
  IntToPChar(FMemo^.CaretY + 1, @Buf[StrLen(@Buf[0])]);
  StrAppend(@Buf[0], ', Kol: ');
  IntToPChar(FMemo^.CaretX + 1, @Buf[StrLen(@Buf[0])]);
  StatusBarSetText(FStatusBar, 1, @Buf[0]);
  
  // Panel 2: Durum
  if FModified then
    StatusBarSetText(FStatusBar, 2, 'Degistirildi')
  else
    StatusBarSetText(FStatusBar, 2, 'Hazir');
end;

function TTextEditor.GetTextBuf: PChar;
begin
  Result := MemoGetText(FMemo);
end;

procedure TTextEditor.LoadFile(const Path: PChar);
var
  F: Integer;
  Size: Integer;
  Buf: PChar;
begin
  if FMemo = nil then Exit;
  
  F := OpenFile(Path, FILE_READ);
  if F < 0 then
  begin
    StatusBarSetText(FStatusBar, 0, 'Dosya acilamadi');
    Exit;
  end;
  
  Size := FileSize(F);
  Buf := PChar(MemAlloc(Size + 1));
  if Buf <> nil then
  begin
    ReadFile(F, Buf, Size);
    Buf[Size] := #0;
    MemoSetText(FMemo, Buf);
    FreeMem(Buf);
    StrCopy(@FFileName[0], Path);
    Modified := False;
  end;
  CloseFile(F);
end;

procedure TTextEditor.SaveFile;
var
  Text: PChar;
  F: Integer;
begin
  if FMemo = nil then Exit;
  if FFileName[0] = #0 then
  begin
    DoSave; // Farkli kaydet dialogu ac
    Exit;
  end;
  
  Text := GetTextBuf;
  if Text = nil then Exit;
  
  F := OpenFile(@FFileName[0], FILE_WRITE or FILE_CREATE);
  if F >= 0 then
  begin
    WriteFile(F, Text, StrLen(Text));
    CloseFile(F);
    Modified := False;
  end;
  FreeMem(Text);
end;

procedure TTextEditor.NewFile;
begin
  if FMemo = nil then Exit;
  MemoClear(FMemo);
  MemoAddLine(FMemo, '');
  FFileName[0] := #0;
  Modified := False;
 // FForm^.Caption := 'Metin Editoru';
end;

procedure TTextEditor.DoOpen;
var
  Path: PChar;
begin
  if FModified then SaveFile;
  
  Path := InputBox('Dosya Ac', 'Dosya yolu:', 'C:\');
  if (Path <> nil) and (Path[0] <> #0) then
  begin
    LoadFile(Path);
   // FForm^.Caption := @FFileName[0];
  end;
end;

procedure TTextEditor.DoSave;
var
  Path: PChar;
  Text: PChar;
  F: Integer;
begin
  if FFileName[0] = #0 then
  begin
    Path := InputBox('Kaydet', 'Dosya adi:', 'C:\yeni.txt');
    if (Path = nil) or (Path[0] = #0) then Exit;
    StrCopy(@FFileName[0], Path);
   // FForm^.Caption := @FFileName[0];
  end;
  
  Text := GetTextBuf;
  if Text = nil then Exit;
  
  F := OpenFile(@FFileName[0], FILE_WRITE or FILE_CREATE);
  if F >= 0 then
  begin
    WriteFile(F, Text, StrLen(Text));
    CloseFile(F);
    Modified := False;
  end;
  FreeMem(Text);
end;

procedure TTextEditor.DoNew;
begin
  if FModified then SaveFile;
  NewFile;
end;

procedure TTextEditor.DoClose;
begin
  if FForm <> nil then
    WinManager.RemoveForm(PForm(FForm));
end;

{-----------------------------------------------------------------------------}
{ Global olay handler'lari (of object degil) }
{-----------------------------------------------------------------------------}

procedure TTextEditor.OnTextEditorToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
begin
  case ButtonIndex of
    0: DoNew;
    1: DoOpen;
    2: DoSave;
    4: DoClose;  // Index 3 ayirac, 4 Kapat
  end;
end;

procedure TextEditorMemoKeyDown(Sender: PObject; Key: Word);
begin
  // Zincirleme calisir: once MemoKeyDown, sonra bu handler calisir.
  // Sadece duzenleme tuslarinda Modified bayragini guncelle.
  if (Key >= $100 + 32) or (Key = VK_BACK) or (Key = VK_DELETE) or
     (Key = VK_RETURN) or (Key = VK_TAB) then
  begin
    TextEditor1.Modified := True;
  end;
  
  // Caret hareketlerinde de status guncelle
  TextEditor1.UpdateStatus;
end;

procedure TextEditorFormDestroy(Sender: PObject);
begin
  // Form yok edilirken temizlik
  TextEditor1.FForm := nil;
  TextEditor1.FMemo := nil;
  TextEditor1.FStatusBar := nil;
end;

procedure OnPopupCut(Item: PPopupMenuItem);
begin
  MemoCut(TextEditor1.FMemo);
end;

procedure OnPopupCopy(Item: PPopupMenuItem);
begin
  MemoCopy(TextEditor1.FMemo);
end;

procedure OnPopupPaste(Item: PPopupMenuItem);
begin
 MemoPaste(TextEditor1.FMemo);
end;

procedure OnPopupSelectAll(Item: PPopupMenuItem);
begin
 MemoSelectAll(TextEditor1.FMemo);
end;

procedure OnMouseDown(Sender: PObject; X, Y: Integer; Btn: Byte);
begin
 if Btn=2 then
     TextEditor1.FPopupMenu^.Show(MouseState.X, MouseState.Y);
end;

{-----------------------------------------------------------------------------}
{ Fabrika }
{-----------------------------------------------------------------------------}

procedure OpenTextEditor(const Path: PChar);
var
  TB: PToolBar;
begin
  with TextEditor1 do
  begin
    FForm := nil; FMemo := nil; FStatusBar := nil;
    FFileName[0] := #0;
    FModified := False;

    FForm := CreateForm('Metin Editoru', 120, 100, 640, 480);
    FForm^.Color := clBtnFace;

    FForm^.BindDestroy(@TextEditorFormDestroy);


   FPopupMenu := MemAlloc(SizeOf(TPopupMenu));
   FillChar(FPopupMenu^, SizeOf(TPopupMenu), #0);
   FPopupMenu^.ItemHeight := FONT_H + 6;
   FPopupMenu^.AddItem('Kes', @OnPopupCut);
   FPopupMenu^.AddItem('Kopyala', @OnPopupCopy);
   FPopupMenu^.AddItem('Yap�st�r', @OnPopupPaste);
   FPopupMenu^.AddItem('Tumunu Sec', @OnPopupSelectAll);
   FPopupMenu^.AddSeparator;
   FPopupMenu^.AddItem('Sil', nil, False);  { Pasif (gri) ��e }




    // Toolbar
    TB := CreateToolBar(PObject(FForm), 0, 0, 640, 40, alTop);
    TB^.ShowCaptions := True;
    TB^.Flat := True;
    ToolBarAddButton(TB, 'Yeni', 50);
    ToolBarAddButton(TB, 'Ac', 50);
    ToolBarAddButton(TB, 'Kaydet', 60);
    ToolBarAddSeparator(TB);
    ToolBarAddButton(TB, 'Kapat', 60);
    TB^.OnClick := OnTextEditorToolBarClick;

    // Memo (client alanini doldurur)
    FMemo := CreateMemo(PObject(FForm), 0, 0, 640, 416, alClient);
    // Memo'nun kendi KeyDown'ina ek olarak bizim status guncelleyici:
    FMemo^.BindKeyDown(@TextEditorMemoKeyDown);
    FMemo^.BindMouseDown(@OnMouseDown);




    // StatusBar
    FStatusBar := CreateStatusBar(PObject(FForm), 0, 0, 640, alBottom);
    FStatusBar^.AddPanel('Yeni Belge', 250);
    FStatusBar^.AddPanel('Sat: 1, Kol: 1', 150);
    FStatusBar^.AddPanel('Hazir', 100);

    // Baslangic
    if (Path <> nil) and (Path[0] <> #0) then
    begin
      LoadFile(Path);
      StrCopy(FForm^.Caption, @FFileName[0]);
    end
    else
    begin
      NewFile;
    end;
    
  end;

 
end;

end.

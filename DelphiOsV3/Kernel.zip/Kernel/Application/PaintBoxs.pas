unit PaintBoxs;

interface

uses
  SysUtils, GUI, GUIControls, Memory, Draw32, Fat32, Math, ProcessMgr;

const
  MAX_SHAPES = 1000;

  // Renk Tan�mlar� ($00RRGGBB)
  COLOR_BLACK   = $00000000;
  COLOR_RED     = $00FF0000;
  COLOR_GREEN   = $0000FF00;
  COLOR_BLUE    = $000000FF;
  COLOR_YELLOW  = $00FFFF00;
  COLOR_WHITE   = $00FFFFFF;

type
  TDrawingMode = (dmLine, dmRectangle, dmCircle, dmFree,dmEraser);
  
  PShape = ^TShape;
  TShape = record
    ShapeType: TDrawingMode;
    X1, Y1, X2, Y2: Integer;
    Color: LongWord;
  end;

  PPaintBox = ^TPaintBox;
  TPaintBox = object
  public
    FForm        : PForm;
    ToolBar      : PToolBar;
    StatusBar    : PStatusBar;
    Panel        : PPanel;
    ColorBar    : PPanel;
    Shapes       : array[0..MAX_SHAPES-1] of TShape;
    ShapeCount   : Integer;
    
    DrawingMode  : TDrawingMode;
    CurrentColor : LongWord;
    
    IsDrawing    : Boolean;
    StartX, StartY: Integer;
    CurrentX, CurrentY: Integer;
    
    procedure OnToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
  end;

procedure OpenPaintBox();

var
  PaintBox1: TPaintBox;

implementation

const
  COLOR_BAR_HEIGHT = 24;
  COLORS: array[0..15] of LongWord = (
    $00000000, $00000080, $00008000, $00008080, $00800000, $00800080, $00808000, $00808080,
    $00C0C0C0, $000000FF, $0000FF00, $0000FFFF, $00FF0000, $00FF00FF, $00FFFF00, $00FFFFFF
  );

procedure TPaintBox.OnToolBarClick(Sender: PToolBar; ButtonIndex: Integer);
begin
  case ButtonIndex of
    { �izim Modlar� }
    0: PaintBox1.DrawingMode := dmLine;
    1: PaintBox1.DrawingMode := dmRectangle;
    2: PaintBox1.DrawingMode := dmCircle;
    3: PaintBox1.DrawingMode := dmFree;
    4: PaintBox1.DrawingMode := dmEraser;
  end;
end;

function GetMin(A, B: Integer): Integer;
begin
  if A < B then Result := A else Result := B;
end;

function GetAbs(Value: Integer): Integer;
begin
  if Value < 0 then Result := -Value else Result := Value;
end;

procedure DrawPanel(Sender: PPanel; AbsX, AbsY: Integer);
var
  i: Integer;
  shape: PShape;
  centerX, centerY, radius: Integer;
  rectX, rectY, rectW, rectH: Integer;
begin
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, $00FFFFFF);
  KRect(AbsX, AbsY, Sender^.Width, Sender^.Height, $00000000);

  for i := 0 to PaintBox1.ShapeCount - 1 do
  begin
    shape := @PaintBox1.Shapes[i];
    
    case shape^.ShapeType of
      dmLine, dmFree:
      begin
        KLine(shape^.X1 + AbsX, shape^.Y1 + AbsY, 
              shape^.X2 + AbsX, shape^.Y2 + AbsY, 
              shape^.Color);
      end;

      dmEraser:begin
          KFill(shape^.X1 - 4, shape^.Y1 - 4, 8, 8, clWhite);
      end;
      
      dmRectangle:
      begin
        rectX := GetMin(shape^.X1, shape^.X2) + AbsX;
        rectY := GetMin(shape^.Y1, shape^.Y2) + AbsY;
        rectW := GetAbs(shape^.X2 - shape^.X1);
        rectH := GetAbs(shape^.Y2 - shape^.Y1);
        
        KRect(rectX, rectY, rectW, rectH, shape^.Color);
      end;
      
      dmCircle:
      begin
        centerX := ((shape^.X1 + shape^.X2) div 2) + AbsX;
        centerY := ((shape^.Y1 + shape^.Y2) div 2) + AbsY;
        radius := (GetAbs(shape^.X2 - shape^.X1) + GetAbs(shape^.Y2 - shape^.Y1)) div 4;
        
        if radius > 0 then
          KArc(centerX, centerY, radius, shape^.Color);
      end;
    end;
  end;

  // Canl� �nizleme
  if PaintBox1.IsDrawing then
  begin
    case PaintBox1.DrawingMode of
      dmLine:
      begin
        KLine(PaintBox1.StartX + AbsX, PaintBox1.StartY + AbsY, 
              PaintBox1.CurrentX + AbsX, PaintBox1.CurrentY + AbsY, 
              PaintBox1.CurrentColor);
      end;


      dmEraser:begin
        rectX := GetMin(PaintBox1.StartX, PaintBox1.CurrentX) + AbsX;
        rectY := GetMin(PaintBox1.StartY, PaintBox1.CurrentY) + AbsY;

        KRect(rectX, rectY,8, 8, clWhite);

      end;
      
      dmRectangle:
      begin
        rectX := GetMin(PaintBox1.StartX, PaintBox1.CurrentX) + AbsX;
        rectY := GetMin(PaintBox1.StartY, PaintBox1.CurrentY) + AbsY;
        rectW := GetAbs(PaintBox1.CurrentX - PaintBox1.StartX);
        rectH := GetAbs(PaintBox1.CurrentY - PaintBox1.StartY);

        KRect(rectX, rectY, rectW, rectH, PaintBox1.CurrentColor);
      end;
      
      dmCircle:
      begin
        centerX := ((PaintBox1.StartX + PaintBox1.CurrentX) div 2) + AbsX;
        centerY := ((PaintBox1.StartY + PaintBox1.CurrentY) div 2) + AbsY;
        radius := (GetAbs(PaintBox1.CurrentX - PaintBox1.StartX) + GetAbs(PaintBox1.CurrentY - PaintBox1.StartY)) div 4;
        
        if radius > 0 then
          KArc(centerX, centerY, radius, PaintBox1.CurrentColor);
      end;
    end;
  end;
end;

procedure OnMouseDown(Sender: PObject; X, Y: Integer; Btn: Byte);
begin
  PaintBox1.IsDrawing := True;
  PaintBox1.StartX := X;
  PaintBox1.StartY := Y;
  PaintBox1.CurrentX := X;
  PaintBox1.CurrentY := Y;
end;

procedure OnMouseMove(Sender: PObject; X, Y: Integer; Btn: Byte);
var
  shape: PShape;
begin
  if not PaintBox1.IsDrawing then Exit;

  PaintBox1.CurrentX := X;
  PaintBox1.CurrentY := Y;

  if PaintBox1.DrawingMode = dmFree then
  begin
    if PaintBox1.ShapeCount < MAX_SHAPES then
    begin
      shape := @PaintBox1.Shapes[PaintBox1.ShapeCount];
      shape^.ShapeType := dmFree;
      shape^.X1 := PaintBox1.StartX;
      shape^.Y1 := PaintBox1.StartY;
      shape^.X2 := X;
      shape^.Y2 := Y;
      shape^.Color := PaintBox1.CurrentColor;
      
      Inc(PaintBox1.ShapeCount);
      
      PaintBox1.StartX := X;
      PaintBox1.StartY := Y;
    end;
  end;
end;

procedure OnMouseUp(Sender: PObject; X, Y: Integer; Btn: Byte);
var
  shape: PShape;
begin
  if not PaintBox1.IsDrawing then Exit;

  if (PaintBox1.DrawingMode <> dmFree) and (PaintBox1.ShapeCount < MAX_SHAPES) then
  begin
    shape := @PaintBox1.Shapes[PaintBox1.ShapeCount];
    shape^.ShapeType := PaintBox1.DrawingMode;
    shape^.X1 := PaintBox1.StartX;
    shape^.Y1 := PaintBox1.StartY;
    shape^.X2 := X;
    shape^.Y2 := Y;
    shape^.Color := PaintBox1.CurrentColor;
    
    Inc(PaintBox1.ShapeCount);
  end;
  
  PaintBox1.IsDrawing := False;
end;


procedure ColorBarPaint(Sender: PPanel; AX, AY: Integer);
var
  I: Integer;
begin
  { 3D arka plan }
  KFill(AX, AY, Sender^.Width, Sender^.Height, $00D4D0C8);
  KRect(AX, AY, Sender^.Width, Sender^.Height, clGray);
  KLineH(AX + 1, AY + 1, Sender^.Width - 2, clWhite);
  KLineV(AX + 1, AY + 1, Sender^.Height - 2, clWhite);
  
  { 16 renk karesi }
  for I := 0 to 15 do
  begin
    { Golge/derinlik efekti }
    KFill(AX + 5 + I * 22, AY + 4, 18, 18, clBlack);
    KFill(AX + 4 + I * 22, AY + 3, 18, 18, clWhite);
    
    { Renk kutusu }
    KFill(AX + 4 + I * 22, AY + 3, 17, 17, COLORS[I]);
    
    { Secili renk vurgusu - basik 3D cerceve }
    if COLORS[I] = PaintBox1.CurrentColor then
    begin
      KRect(AX + 3 + I * 22, AY + 2, 19, 19, clBlack);
      KLineH(AX + 4 + I * 22, AY + 3, 17, clWhite);
      KLineV(AX + 4 + I * 22, AY + 3, 17, clWhite);
      KLineH(AX + 4 + I * 22, AY + 19, 17, clGray);
      KLineV(AX + 20 + I * 22, AY + 3, 17, clGray);
    end
    else
    begin
      KRect(AX + 4 + I * 22, AY + 3, 17, 17, clGray);
    end;
  end;
end;

procedure ColorBarMouseDown(Sender: PPanel; X, Y: Integer; Btn: Byte);
var
  I: Integer;
begin
  if Btn <> 1 then Exit;
  I := (X - 4) div 22;
  if (I >= 0) and (I <= 15) then
   PaintBox1.CurrentColor :=(COLORS[I]);
end;




procedure OpenPaintBox();
begin
  PaintBox1.DrawingMode := dmFree;
  PaintBox1.CurrentColor := COLOR_BLACK;
  PaintBox1.IsDrawing := False;
  PaintBox1.ShapeCount := 0;

  PaintBox1.FForm := CreateForm('PaintBox / Cizim', 300, 200, 640, 480);

  { ToolBar ve Butonlar }
  PaintBox1.ToolBar := CreateToolBar(PObject(PaintBox1.FForm), 0, 0, 640, 32, alTop);
  PaintBox1.ToolBar^.ShowCaptions := True;
  PaintBox1.ToolBar^.Flat := True;
  
  // �ekil Butonlar� (Index 0..3)
  ToolBarAddButton(PaintBox1.ToolBar, 'Cizgi', 50);
  ToolBarAddButton(PaintBox1.ToolBar, 'Kutu', 45);
  ToolBarAddButton(PaintBox1.ToolBar, 'Daire', 45);
  ToolBarAddButton(PaintBox1.ToolBar, 'Serbest', 55);
  ToolBarAddButton(PaintBox1.ToolBar, 'Sil', 55);
  


  PaintBox1.ToolBar^.OnClick := PaintBox1.OnToolBarClick;


   PaintBox1.ColorBar := CreatePanel(PObject(PaintBox1.FForm), 0, 0, 800, COLOR_BAR_HEIGHT + 6, alTop);
   PaintBox1.ColorBar^.Color := $00D4D0C8;
   PaintBox1.ColorBar^.BindPaint(@ColorBarPaint);
   PaintBox1.ColorBar^.BindMouseDown(@ColorBarMouseDown);

  { Panel }
  PaintBox1.Panel := CreatePanel(PObject(PaintBox1.FForm), 0, 0, 640, 480 - 32 - 26, alClient);
  PaintBox1.Panel^.BindPaint(@DrawPanel);

  PaintBox1.Panel^.BindMouseDown(@OnMouseDown);
  PaintBox1.Panel^.BindMouseMove(@OnMouseMove);
  PaintBox1.Panel^.BindMouseUp(@OnMouseUp);

  { Status Bar }
  PaintBox1.StatusBar := CreateStatusBar(PObject(PaintBox1.FForm), 0, 0, 640, alBottom);
  PaintBox1.StatusBar.AddPanel('Hazir', 250);
  PaintBox1.StatusBar.AddPanel('PaintBox V0.2', 250);
end;

end.

{ =========================================================
  MJPEGServer.pas � Motion JPEG Stream Server
  ========================================================= }

Unit MjpegServer;

interface

uses
  SysUtils, Memory, Task, Draw32,Fat32, Vesa, GUI, GUIControls, WinSocket, Pit, RTL8139,JPEGEncoder;

const
  SERVER_PORT   = 80;
  SERVER_IP     = '0.0.0.0';   // T�m interface'lerden dinle (INADDR_ANY)
  MAX_LOG_LINES = 100;
  LOG_LINE_LEN  = 128;
  MJPEG_FPS     = 15;          // Stream FPS (milisaniye: 1000/15 ? 66ms)

const
  // --- Statik HTML (mevcut sayfalar) ---
  HTML: PChar =
    '<!DOCTYPE html>'#10+
    '<html lang="tr">'#10+
    '<head>'#10+
    '  <meta charset="UTF-8">'#10+
    '  <title>?? Pascal MJPEG Server</title>'#10+
    '  <style>'#10+
    '    body { font-family: sans-serif; background:#1a1a2e; color:#eee; display:flex; flex-direction:column; align-items:center; padding:20px; }'#10+
    '    h1 { background: linear-gradient(90deg,#e94560,#ff6b6b); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }'#10+
    '    .cam { border:3px solid #e94560; border-radius:12px; width:640px; height:480px; background:#000; }'#10+
    '    .info { margin-top:15px; color:#888; }'#10+
    '  </style>'#10+
    '</head>'#10+
    '<body>'#10+
    '  <h1>?? Live MJPEG Stream</h1>'#10+
    '  <img class="cam" src="/mjpeg" alt="Kamera">'#10+
    '  <p class="info">Pascal TCP/IP Stack �zerinden MJPEG stream</p>'#10+
    '</body>'#10+
    '</html>';

  HDR_200: PChar =
    'HTTP/1.1 200 OK'#13#10+
    'Content-Type: text/html; charset=utf-8'#13#10+
    'Connection: close'#13#10+
    'Content-Length: %d'#13#10+
    'Cache-Control: no-cache'#13#10+
    'Server: Pascal-MJPEG/1.0'#13#10+
    #13#10;

  HDR_404: PChar =
    'HTTP/1.1 404 Not Found'#13#10+
    'Content-Type: text/html; charset=utf-8'#13#10+
    'Connection: close'#13#10+
    'Content-Length: %d'#13#10+
    'Server: Pascal-MJPEG/1.0'#13#10+
    #13#10;

  HDR_JSON: PChar =
    'HTTP/1.1 200 OK'#13#10+
    'Content-Type: application/json; charset=utf-8'#13#10+
    'Connection: close'#13#10+
    'Content-Length: %d'#13#10+
    'Server: Pascal-MJPEG/1.0'#13#10+
    #13#10;

  // MJPEG Stream Header (Connection KAPATILMAZ, stream a��k kal�r)
  HDR_MJPEG: PChar =
    'HTTP/1.1 200 OK'#13#10+
    'Content-Type: multipart/x-mixed-replace; boundary=myboundary'#13#10+
    'Cache-Control: no-cache, private'#13#10+
    'Pragma: no-cache'#13#10+
    'Server: Pascal-MJPEG/1.0'#13#10+
    #13#10;

  FRAME_HEADER: PChar =
    '--myboundary'#13#10+
    'Content-Type: image/jpeg'#13#10+
    'Content-Length: %d'#13#10+
    #13#10;

  BODY_404: PChar =
    '<!DOCTYPE html><html><head><title>404</title></head>'#10+
    '<body style="font-family:sans-serif; text-align:center; padding-top:100px;">'#10+
    '<h1 style="font-size:4em; color:#e74c3c;">404</h1>'#10+
    '<p>Sayfa bulunamadi.</p>'#10+
    '</body></html>';

  BODY_JSON: PChar = '{"status":"ok","server":"Pascal-MJPEG","version":"1.0","stream":"/mjpeg"}';

  HTML_HOME_1 = '<!DOCTYPE html>'#13#10 +
                '<html>'#13#10 +
                '<head>'#13#10 +
                '<meta charset="UTF-8">'#13#10 +
                '<title>Web Sunucu</title>'#13#10 +
                '<style>'#13#10 +
                'body { font-family: Arial; margin: 40px; background: #f0f0f0; }'#10+
                'h1 { color: #333; }'#10+
                '.container { background: white; padding: 20px; border-radius: 5px; }'#10+
                'a { color: #0066cc; text-decoration: none; }'#10+
                '</style>'#13#10 +
                '</head>'#13#10 +
                '<body>'#13#10 +
                '<div class="container">'#13#10 +
                '<h1>Ho�geldiniz!</h1>'#13#10 +
                '<p>Delphi Kernel MJPEG Sunucusu</p>'#10+
                '<p><a href="/mjpeg">?? Canl� MJPEG Stream</a></p>'#10+
                '</div>'#13#10 +
                '</body>'#13#10 +
                '</html>';

  HTML_ABOUT = '<html><head><meta charset="UTF-8"><title>Hakk�nda</title></head>'#10+
               '<body style="font-family:Arial;margin:40px"><h1>Hakk�nda</h1>'#10+
               '<p>MJPEG Stream Server</p><p><a href="/">� Geri D�n</a></p></body></html>';


type
  PMjpegServerData = ^TMjpegServerData;
  TMjpegServerData = Object
  public
    ServerSock: PSocket;
    IsRunning: Boolean;
    ThreadID: LongWord;
    StreamClientCount: Integer;  // Aktif izleyici say�s�

    // GUI Controls
    BtnStart: PButton;
    BtnStop: PButton;
    LblStatus: PLabel;
    LblPort: PLabel;
    LblClients: PLabel;
    LogPanel: PPanel;

    // Log buffer
    LogLines: array[0..MAX_LOG_LINES-1] of array[0..LOG_LINE_LEN-1] of Char;
    LogCount: Integer;

    JpegBuf: PByteArray;
    JpegSize: Integer;

    procedure HandleClient(ClientSock: PSocket);
    procedure StreamMJPEG(ClientSock: PSocket);
    procedure AddLog(const Msg: PChar);
    procedure StartServer();
    procedure StopServer();
  end;

procedure OpenMjpegServerForm;
procedure PollServer;

var
  MjpegServerData1: TMjpegServerData;

implementation

{=============================================================================
  LOG HELPERS
=============================================================================}

procedure TMjpegServerData.AddLog(const Msg: PChar);
var
  i: Integer;
  FullMsg: array[0..LOG_LINE_LEN-1] of Char;
begin
  StrCopy(@FullMsg[0], '[');
  StrAppend(@FullMsg[0], Msg);

  if LogCount < MAX_LOG_LINES then
  begin
    StrCopy(@LogLines[LogCount][0], @FullMsg[0]);
    Inc(LogCount);
  end
  else
  begin
    for i := 0 to MAX_LOG_LINES - 2 do
      StrCopy(@LogLines[i][0], @LogLines[i+1][0]);
    StrCopy(@LogLines[MAX_LOG_LINES-1][0], @FullMsg[0]);
  end;

  if LogPanel <> nil then
    RelayoutForm(PForm(LogPanel^.Parent));
end;

{=============================================================================
  INTEGER TO PChar (RTL ba��ms�z)
=============================================================================}

function FastIntToPChar(Val: Integer; Dest: PChar): Integer;
var
  Buf: array[0..11] of Char;
  I, Len, Digit: Integer;
  IsNegative: Boolean;
begin
  if Val = 0 then
  begin
    Dest[0] := '0';
    Result := 1;
    Exit;
  end;

  IsNegative := Val < 0;
  if IsNegative then Val := -Val;

  I := 0;
  while Val > 0 do
  begin
    Digit := Val mod 10;
    Buf[I] := Char(Ord('0') + Digit);
    Inc(I);
    Val := Val div 10;
  end;

  Len := 0;
  if IsNegative then
  begin
    Dest[Len] := '-';
    Inc(Len);
  end;

  while I > 0 do
  begin
    Dec(I);
    Dest[Len] := Buf[I];
    Inc(Len);
  end;

  Result := Len;
end;

function SimpleFormatPChar(Dest: PChar; Template: PChar; ContentLength: Integer): Integer;
var
  Src, Dst: PChar;
  NumLen: Integer;
begin
  Src := Template;
  Dst := Dest;

  while Src^ <> #0 do
  begin
    if (Src^ = '%') and ((Src + 1)^ = 'd') then
    begin
      Inc(Src, 2);
      NumLen := FastIntToPChar(ContentLength, Dst);
      Inc(Dst, NumLen);
    end
    else
    begin
      Dst^ := Src^;
      Inc(Dst);
      Inc(Src);
    end;
  end;

  Dst^ := #0;
  Result := Dst - Dest;
end;

{=============================================================================
  HTTP REQUEST PARSER
=============================================================================}

function ParseHTTPMethod(const Request: PChar): PChar;
var
  i: Integer;
  Method: array[0..7] of Char;
begin
  i := 0;
  while (Request[i] <> ' ') and (Request[i] <> #0) and (i < 7) do
  begin
    Method[i] := Request[i];
    Inc(i);
  end;
  Method[i] := #0;
  Result := StrNew(@Method[0]);
end;

function ParseHTTPPath(const Request: PChar): PChar;
var
  i, j: Integer;
  Path: array[0..255] of Char;
begin
  i := 0;
  while (Request[i] <> ' ') and (Request[i] <> #0) do Inc(i);
  if Request[i] = ' ' then Inc(i);

  j := 0;
  while (Request[i] <> ' ') and (Request[i] <> #0) and (Request[i] <> #13) and (j < 255) do
  begin
    Path[j] := Request[i];
    Inc(i);
    Inc(j);
  end;
  Path[j] := #0;

  Result := StrNew(@Path[0]);
end;

{=============================================================================
  JPEG FRAME CAPTURE (SEN�N DOLDURMAN GEREKEN KISIM)
  Bu fonksiyon VESA/Draw32 framebuffer'dan JPEG �retip Buffer'a yazar.
  D�nen de�er: JPEG boyutu (byte). Hata/veri yoksa 0 d�ner.
=============================================================================}

function CaptureFrameToJpeg11(Buffer: Pointer; MaxSize: Integer): Integer;
begin
  // TODO: Burada VESA ekran�n� okuyup JPEG'e �evirmelisin.
  // �rnek: ScreenBuffer'dan JPEG encode et -> Buffer'a kopyala
  // �imdilik dummy data d�nd�r�yor (ger�ek implementasyonda kald�r)
  Result := 0;
end;

{=============================================================================
  MJPEG STREAM (S�rekli frame g�nderir)
=============================================================================}

procedure TMjpegServerData.StreamMJPEG(ClientSock: PSocket);
var
 // JpegBuf: array[0..65535] of Byte;   // 64KB frame buffer (VGA i�in yeterli)
 // JpegSize: Integer;
  FrameHdrBuf: array[0..255] of Char;
  FrameHdrLen: Integer;
  IPStr: array[0..15] of Char;
  LogBuf: array[0..LOG_LINE_LEN-1] of Char;
begin
  if ClientSock = nil then Exit;

  // �zleyici say�s�n� art�r
  Inc(StreamClientCount);
  IPToPCharSimple(ClientSock^.RemoteAddr, @IPStr[0], SizeOf(IPStr));
  StrCopy(@LogBuf[0], 'Stream START: ');
  StrAppend(@LogBuf[0], @IPStr[0]);
  AddLog(@LogBuf[0]);

  // MJPEG HTTP header g�nder (Connection: close YOK! Stream a��k kalacak)
  send(ClientSock, HDR_MJPEG, StrLen(HDR_MJPEG), 0);

  while IsRunning do
  begin
    // 1) Frame'i al (JPEG olarak)
   // JpegSize := CaptureFrameToJpeg(@JpegBuf[0], SizeOf(JpegBuf));
    if JpegSize <= 0 then
    begin
      // Frame haz�r de�ilse bekle (PIT/Delay kullanabilirsin)
      Thread_Yield;
      Continue;
    end;

    // 2) Boundary + Content-Length header g�nder
    FrameHdrLen := SimpleFormatPChar(@FrameHdrBuf[0], FRAME_HEADER, JpegSize);
    if send(ClientSock, @FrameHdrBuf[0], FrameHdrLen, 0) < 0 then Break;

    // 3) JPEG binary data g�nder
    if send(ClientSock, @JpegBuf[0], JpegSize, 0) < 0 then Break;

    // 4) Frame sonu CRLF
    if send(ClientSock, #13#10, 2, 0) < 0 then Break;

    // FPS kontrol� (~15 fps = 66ms). Kendi Delay rutinin varsa onu kullan.
    // �rnek: Delay(66); veya Pit_Sleep(66);
    Thread_Yield;
  end;

  // �zleyici ayr�ld�
  Dec(StreamClientCount);
  StrCopy(@LogBuf[0], 'Stream END: ');
  StrAppend(@LogBuf[0], @IPStr[0]);
  AddLog(@LogBuf[0]);

  close(ClientSock);
end;

{=============================================================================
  HANDLE CLIENT (Normal HTTP + MJPEG Stream)
=============================================================================}

procedure TMjpegServerData.HandleClient(ClientSock: PSocket);
var
  RequestBuffer: array[0..4095] of Char;
  BytesRead: Integer;
  Method, Path: PChar;
  Body: PChar;
  HdrTpl: PChar;
  BodyLen: Integer;
  HdrBuf: array[0..1023] of Char;
  HdrLen: Integer;
  LogBuf: array[0..LOG_LINE_LEN-1] of Char;
  IPStr: array[0..15] of Char;
  PortStr: array[0..7] of Char;
begin
  if ClientSock = nil then Exit;

  FillChar(RequestBuffer, SizeOf(RequestBuffer), 0);
  BytesRead := recv(ClientSock, @RequestBuffer[0], SizeOf(RequestBuffer) - 1);

  if BytesRead <= 0 then
  begin
    close(ClientSock);
    Exit;
  end;

  RequestBuffer[BytesRead] := #0;

  Method := ParseHTTPMethod(@RequestBuffer[0]);
  Path := ParseHTTPPath(@RequestBuffer[0]);

  // Log
  IPToPCharSimple(ClientSock^.RemoteAddr, @IPStr[0], SizeOf(IPStr));
  SysUtils.IntToPChar(ClientSock^.RemotePort, @PortStr[0]);
  StrCopy(@LogBuf[0], '[');
  StrAppend(@LogBuf[0], @IPStr[0]);
  StrAppend(@LogBuf[0], ':');
  StrAppend(@LogBuf[0], @PortStr[0]);  // d�zeltme: LogBuf olmal�
  StrAppend(@LogBuf[0], '] ');
  StrAppend(@LogBuf[0], Method);
  StrAppend(@LogBuf[0], ' ');
  StrAppend(@LogBuf[0], Path);
  AddLog(@LogBuf[0]);

  // --- ROUTING ---
  if StrCmp(Path, '/mjpeg') = 0 then
  begin
    // MJPEG stream: ba�lant�y� burada y�net, normal response g�nderme
    StrDispose(Method);
    StrDispose(Path);
    StreamMJPEG(ClientSock);
    Exit;
  end
  else if (StrCmp(Path, '/') = 0) or (StrCmp(Path, '/index.html') = 0) then
  begin
    Body := HTML_HOME_1;
    HdrTpl := HDR_200;
  end
  else if StrCmp(Path, '/hakkinda') = 0 then
  begin
    Body := HTML_ABOUT;
    HdrTpl := HDR_200;
  end
  else if StrCmp(Path, '/api/status') = 0 then
  begin
    Body := BODY_JSON;
    HdrTpl := HDR_JSON;
  end
  else
  begin
    Body := BODY_404;
    HdrTpl := HDR_404;
  end;

  // Normal HTTP response (Connection: close)
  BodyLen := StrLen(Body);
  HdrLen := SimpleFormatPChar(@HdrBuf[0], HdrTpl, BodyLen);

  send(ClientSock, @HdrBuf[0], HdrLen, 0);
  send(ClientSock, Body, BodyLen, 0);

  StrDispose(Method);
  StrDispose(Path);
  close(ClientSock);
end;

{=============================================================================
  SERVER THREAD
=============================================================================}

procedure ServerThreadFunc();
var
  ServerAddr: TSocketAddr;
  ClientSock: PSocket;
  ClientAddr: TSocketAddr;
  ClientAddrLen: Integer;
begin
  MjpegServerData1.AddLog('Server thread started');

  if MjpegServerData1.IsRunning then Exit;

  MjpegServerData1.ServerSock := socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if MjpegServerData1.ServerSock = nil then
  begin
    MjpegServerData1.AddLog('ERROR: socket() failed');
    Exit;
  end;

  ServerAddr.sin_family := AF_INET;
  ServerAddr.sin_port := SERVER_PORT;
  ServerAddr.sin_addr := inet_addr(SERVER_IP);

  if bind(MjpegServerData1.ServerSock, ServerAddr, SizeOf(TSocketAddr)) <> 0 then
  begin
    MjpegServerData1.AddLog('ERROR: bind() failed');
    FreeSocket(MjpegServerData1.ServerSock);
    MjpegServerData1.ServerSock := nil;
    Exit;
  end;

  if listen(MjpegServerData1.ServerSock, 5) <> 0 then
  begin
    MjpegServerData1.AddLog('ERROR: listen() failed');
    FreeSocket(MjpegServerData1.ServerSock);
    MjpegServerData1.ServerSock := nil;
    Exit;
  end;

  MjpegServerData1.IsRunning := True;
  StrCopy(@MjpegServerData1.LblStatus^.Caption[0], 'Status: RUNNING');
  MjpegServerData1.AddLog('Server started on port 80');

  while MjpegServerData1.IsRunning do
  begin
    ClientAddrLen := SizeOf(TSocketAddr);
    ClientSock := accept(MjpegServerData1.ServerSock, @ClientAddr, @ClientAddrLen);

    if ClientSock <> nil then
    begin
      MjpegServerData1.HandleClient(ClientSock);
    end;

    Thread_Yield;
  end;

  if MjpegServerData1.ServerSock <> nil then
  begin
    close(MjpegServerData1.ServerSock);
    MjpegServerData1.ServerSock := nil;
  end;

  MjpegServerData1.AddLog('Server durduruldu.');
end;

{=============================================================================
  START / STOP
=============================================================================}

procedure TMjpegServerData.StartServer();
begin
  if IsRunning then Exit;

  ThreadID := BeginThread(@ServerThreadFunc, @MjpegServerData1, 'MJPEG Server', PRIO_HIGH, TF_KERNEL);

  if ThreadID = INVALID_HANDLE then
    AddLog('Threading not available � use PollServer()');
end;

procedure TMjpegServerData.StopServer();
begin
  if not IsRunning then Exit;

  IsRunning := False;

  if ServerSock <> nil then
  begin
    close(ServerSock);
    ServerSock := nil;
  end;

  if ThreadID <> INVALID_HANDLE then
    Thread_Kill(ThreadID);

  StreamClientCount := 0;
  StrCopy(@LblStatus^.Caption[0], 'Status: STOPPED');
  AddLog('Server stopped');
end;

{=============================================================================
  POLL SERVER (Non-threaded mode i�in idle loop'tan �a��r)
=============================================================================}

procedure PollServer;
var
  ClientSock: PSocket;
  ClientAddr: TSocketAddr;
  ClientAddrLen: Integer;
begin
  if not MjpegServerData1.IsRunning then Exit;
  if MjpegServerData1.ServerSock = nil then Exit;

  ClientAddrLen := SizeOf(TSocketAddr);
  ClientSock := accept(MjpegServerData1.ServerSock, @ClientAddr, @ClientAddrLen);

  if ClientSock <> nil then
  begin
    MjpegServerData1.HandleClient(ClientSock);
  end;
end;

{=============================================================================
  GUI EVENT HANDLERS
=============================================================================}

procedure BtnStartClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
begin
  MjpegServerData1.StartServer();
end;

procedure BtnStopClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
begin
  MjpegServerData1.StopServer();
end;

procedure BtnClearClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
begin
  MjpegServerData1.LogCount := 0;
  if MjpegServerData1.LogPanel <> nil then
    RelayoutForm(PForm(MjpegServerData1.LogPanel^.Parent));
end;

{=============================================================================
  LOG PANEL DRAW
=============================================================================}

procedure LogPanelDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  Panel: PPanel;
  i: Integer;
  y: Integer;
  LineH: Integer;
  StartIdx: Integer;
  VisibleLines: Integer;
begin
  Panel := PPanel(Sender);

  KFill(AbsX, AbsY, Panel^.Width, Panel^.Height, $00FFFFFF);
  KRect(AbsX, AbsY, Panel^.Width, Panel^.Height, $00808080);

  LineH := FONT_H + 2;
  VisibleLines := (Panel^.Height - 8) div LineH;
  if VisibleLines < 1 then VisibleLines := 1;

  if MjpegServerData1.LogCount <= VisibleLines then
    StartIdx := 0
  else
    StartIdx := MjpegServerData1.LogCount - VisibleLines;

  y := AbsY + 4;
  for i := StartIdx to MjpegServerData1.LogCount - 1 do
  begin
    if y + LineH > AbsY + Panel^.Height - 4 then Break;

    if (i mod 2) = 0 then
      KFill(AbsX + 2, y, Panel^.Width - 4, LineH, $00F8F8F8)
    else
      KFill(AbsX + 2, y, Panel^.Width - 4, LineH, $00FFFFFF);

    KStr(AbsX + 6, y, @MjpegServerData1.LogLines[i][0], $00000000);
    y := y + LineH;
  end;
end;

{=============================================================================
  FORM DESTROY
=============================================================================}

procedure MjpegServerFormDestroy(Sender: PObject);
begin
  if MjpegServerData1.IsRunning then
    MjpegServerData1.StopServer();
end;

{=============================================================================
  OPEN FORM
=============================================================================}

procedure OpenMjpegServerForm;
var
  F: PForm;
  Toolbar: PPanel;
  Btn: PButton;
  LogArea: PPanel;
  FileHandle: Integer;
begin
  F := CreateForm('MJPEG Server', 80, 60, 700, 500);
  if F = nil then Exit;

  F^.BorderStyle := bsWindow;
  F^.ShowSysButtons := True;
  F^.Color := clBtnFace;
  F^.BindDestroy(@MjpegServerFormDestroy);

  MjpegServerData1.IsRunning := False;
  MjpegServerData1.LogCount := 0;
  MjpegServerData1.StreamClientCount := 0;


   FileHandle := OpenFile('D:\output.jpg', FILE_READ);
  if FileHandle < 0 then Exit;

  MjpegServerData1.JpegSize := FileSize(FileHandle);
  if MjpegServerData1.JpegSize = 0 then
  begin
    CloseFile(FileHandle);
    Exit;
  end;

  MjpegServerData1.JpegBuf := (MemAlloc(MjpegServerData1.JpegSize));
  if MjpegServerData1.JpegBuf = nil then
  begin
    CloseFile(FileHandle);
    Exit;
  end;

  ReadFile(FileHandle, MjpegServerData1.JpegBuf, MjpegServerData1.JpegSize);

  CloseFile(FileHandle);






  { --- Toolbar --- }
  Toolbar := CreatePanel(PObject(F), 0, 0, 0, 44, alTop);
  Toolbar^.Color := clBtnFace;
  Toolbar^.BorderWidth := 0;

  MjpegServerData1.BtnStart := CreateButton(PObject(Toolbar), 'Start', 8, 8, 70, 28, alNone);
  MjpegServerData1.BtnStart^.BindMouseUp(@BtnStartClick);

  MjpegServerData1.BtnStop := CreateButton(PObject(Toolbar), 'Stop', 86, 8, 70, 28, alNone);
  MjpegServerData1.BtnStop^.BindMouseUp(@BtnStopClick);

  Btn := CreateButton(PObject(Toolbar), 'Clear', 164, 8, 70, 28, alNone);
  Btn^.BindMouseUp(@BtnClearClick);

  MjpegServerData1.LblStatus := CreateLabel(PObject(Toolbar), 'Status: STOPPED', 250, 12, 120, 20, alNone);
  MjpegServerData1.LblPort := CreateLabel(PObject(Toolbar), 'Port: 80', 380, 12, 80, 20, alNone);
  MjpegServerData1.LblClients := CreateLabel(PObject(Toolbar), 'Clients: 0', 470, 12, 100, 20, alNone);

  { --- Log Panel --- }
  LogArea := CreatePanel(PObject(F), 0, 0, 0, 0, alClient);
  LogArea^.Color := $00FFFFFF;
  LogArea^.BorderWidth := 1;
  LogArea^.BorderColor := $00808080;
  LogArea^.BindPaint(@LogPanelDraw);
  MjpegServerData1.LogPanel := LogArea;

  MjpegServerData1.AddLog('MJPEG Server ready. Click Start to begin.');
  MjpegServerData1.AddLog('Stream URL: http://<ip>/mjpeg');
end;

end.

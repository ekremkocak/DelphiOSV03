unit WebBrowserForm;

{ =========================================================
  WebBrowserForm.pas � Basit Text Web Browser (OOP Refactored)
  ========================================================= }

{$H+}

interface

uses
  SysUtils, Pit, Memory, Draw32, Vesa, Math, GUI, GUIControls,Messages, WinSocket, RTL8139;

const
  MAX_RENDER_LINES = 500;
  MAX_LINKS        = 64;
  LINE_BUF_LEN     = 256;
  HTTP_BUF_SIZE    = 8192;
  HTTP_TIMEOUT     = 3000;

  COL_TEXT    = $00E0E0E0;
  COL_LINK    = $00FFAA00;
  COL_BOLD    = $00FFFFFF;
  COL_HEADING = $00FFFF80;
  COL_BG      = $00101020;

type
  TRenderLine = record
    Text: array[0..LINE_BUF_LEN-1] of Char;
    Color: LongWord;
    IsLink: Boolean;
    LinkURL: array[0..255] of Char;
  end;

  TLinkInfo = record
    URL: array[0..255] of Char;
    X, Y, W, H: Integer;
    LineIndex: Integer;
  end;

  PBrowserData = ^TBrowserData;
  TBrowserData = object
    FForm        : PForm;
    EdtURL: PEdit;
    ContentPanel: PPanel;
    VScroll: PScrollBar;
    StatusBar    : PStatusBar;
    Lines: array[0..MAX_RENDER_LINES-1] of TRenderLine;
    LineCount: Integer;
    Links: array[0..MAX_LINKS-1] of TLinkInfo;
    LinkCount: Integer;
    CurrentURL: array[0..255] of Char;

    PanelAbsX : Integer;
    PanelAbsY : Integer;

    // Metot Tan�mlar�

    procedure ParseURL(const URL: PChar; out Host: PChar; out Path: PChar);
    function HTTPGet(const Host: PChar; const Path: PChar; out Body: PChar; out BodyLen: Integer): Boolean;
    procedure ParseHTML(const HTML: PChar);
    procedure DrawContent(Sender:PPanel;AbsX, AbsY: Integer);
    procedure Navigate;
  end;

procedure OpenWebBrowserForm;
procedure BtnGoClick(Sender: PObject; AX, AY: Integer; Btn: Byte);


var
  BrowserData1:TBrowserData;

implementation


function EncodeDNSHostname(Hostname: PChar; Buffer: PChar; BufSize: Integer): Integer;
var
  i, j: Integer;
  labelLen: Integer;
  labelStart: Integer;
begin
  Result := 0;
  if (Hostname = nil) or (Buffer = nil) or (BufSize < 2) then Exit;
  
  i := 0;
  j := 1;  // �lk byte label length i�in
  labelStart := 0;
  labelLen := 0;
  
  // Hostname'i parse et ve encode et
  while (Hostname[i] <> #0) and (j < BufSize - 1) do
  begin
    if Hostname[i] = '.' then
    begin
      // Label length'i yaz
      Buffer[labelStart] := Char(labelLen);
      
      // Yeni label i�in haz�rlan
      labelStart := j;
      labelLen := 0;
      Inc(j);
    end
    else
    begin
      // Karakteri yaz
      Buffer[j] := Hostname[i];
      Inc(j);
      Inc(labelLen);
    end;
    
    Inc(i);
  end;
  
  // Son label'� bitir
  if labelLen > 0 then
  begin
    Buffer[labelStart] := Char(labelLen);
  end;
  
  // Root label
  if j < BufSize then
  begin
    Buffer[j] := #0;
    Inc(j);
  end;
  
  Result := j;
end;


function ParseDNSName(Response: PByteArray; Offset: Integer; out IPAddress: LongWord): Boolean;
var
  i: Integer;
  answerOffset: Integer;
  answerType: Word;
  answerClass: Word;
  answerTTL: LongWord;
  dataLen: Word;
  rdataOffset: Integer;
begin
  Result := False;
  IPAddress := 0;
  
  if Response = nil then Exit;
  
  answerOffset := Offset;
  
  // DNS Name (pointer veya label olabilir)
  // E�er pointer ise (high 2 bit = 11), offset'i hesapla
  if (Response[answerOffset] and $C0) = $C0 then
  begin
    // Pointer: offset'i ka��r ve atla (2 byte)
    Inc(answerOffset, 2);
  end
  else
  begin
    // Label: null byte'a kadar ilerleme
    while (Response[answerOffset] <> 0) do
    begin
      Inc(answerOffset);
    end;
    Inc(answerOffset);  // Null byte'� atla
  end;
  
  // Type kontrol� (2 byte)
  answerType := (Word(Response[answerOffset]) shl 8) or Word(Response[answerOffset + 1]);
  Inc(answerOffset, 2);
  
  // Class kontrol� (2 byte)
  answerClass := (Word(Response[answerOffset]) shl 8) or Word(Response[answerOffset + 1]);
  Inc(answerOffset, 2);
  
  // TTL (4 byte)
  answerTTL := (LongWord(Response[answerOffset]) shl 24) or 
               (LongWord(Response[answerOffset + 1]) shl 16) or
               (LongWord(Response[answerOffset + 2]) shl 8) or
               LongWord(Response[answerOffset + 3]);
  Inc(answerOffset, 4);
  
  // Data length (2 byte)
  dataLen := (Word(Response[answerOffset]) shl 8) or Word(Response[answerOffset + 1]);
  Inc(answerOffset, 2);
  
  // Type: A (1) - IPv4 adresi
  if answerType = 1 then
  begin
    if dataLen = 4 then
    begin
      // IPv4 adresi (4 byte)
      IPAddress := (LongWord(Response[answerOffset]) shl 24) or
                   (LongWord(Response[answerOffset + 1]) shl 16) or
                   (LongWord(Response[answerOffset + 2]) shl 8) or
                   LongWord(Response[answerOffset + 3]);
      Result := True;
    end;
  end;
end;


function GetDNSAnswerCount(Response: PByteArray): Word;
begin
  if Response = nil then
  begin
    Result := 0;
    Exit;
  end;
  
  // Answer RRs say�s� (offset 6-7)
  Result := (Word(Response[6]) shl 8) or Word(Response[7]);
end;

procedure DNSQuery(hostname: PChar);
var
  sockfd: PSocket;
  dns_server: TSocketAddr;
  query: array[0..512] of Byte;
  response: array[0..512] of Byte;
  queryLen: Integer;
  ret: Integer;
  encodedHostname: array[0..255] of Byte;
  encodedLen: Integer;
  ipStr: array[0..15] of Char;
  resolvedIP: LongWord;
  i: Integer;
  msgStr: array[0..255] of Char;
  answerCount: Word;
  answerOffset: Integer;
begin
  sockfd := socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if sockfd = nil then
  begin
    COM1_WriteStr('UDP Socket olusturulamadi');
    Exit;
  end;
  
  // Yerel adres ayarla
  sockfd^.LocalAddr := inet_addr('10.0.2.15');
  sockfd^.LocalPort := Rand(64511) + 1024;
  
  // DNS server (Google DNS: 8.8.8.8)
  dns_server.sin_family := AF_INET;
  dns_server.sin_port := 53;
  dns_server.sin_addr := inet_addr('8.8.8.8');
  
  // DNS query packet olu�tur
  FillChar(query, SizeOf(query), 0);
  
  // DNS Header
  PWord(@query[0])^ := htons(Rand($FFFF));  // Transaction ID
  PWord(@query[2])^ := htons($0100);        // Flags: standard query, recursion desired
  PWord(@query[4])^ := htons(1);            // Questions: 1
  PWord(@query[6])^ := htons(0);            // Answer RRs: 0
  PWord(@query[8])^ := htons(0);            // Authority RRs: 0
  PWord(@query[10])^ := htons(0);           // Additional RRs: 0
  
  queryLen := 12;
  
  // Hostname'i DNS format�nda encode et
  // �rnek: "google.com" � 6google3com0
  FillChar(encodedHostname, SizeOf(encodedHostname), 0);
  encodedLen := EncodeDNSHostname(hostname, PChar(@encodedHostname[0]), SizeOf(encodedHostname));
  
  // Encoded hostname'i query'ye kopyala
  if encodedLen > 0 then
  begin
    i := 0;
    while (i < encodedLen) and (queryLen < SizeOf(query) - 4) do
    begin
      query[queryLen] := encodedHostname[i];
      Inc(queryLen);
      Inc(i);
    end;
  end;
  
  // Type: A (1 = IPv4 address record)
  if queryLen + 4 <= SizeOf(query) then
  begin
    PWord(@query[queryLen])^ := htons(1);     // Type: A
    Inc(queryLen, 2);
    PWord(@query[queryLen])^ := htons(1);     // Class: IN
    Inc(queryLen, 2);
  end;
  
  // G�nder
  COM1_WriteStr( 'DNS Query gonderiliyor: ');
  COM1_WriteStr( hostname);

  sendto(sockfd, PChar(@query[0]), queryLen, 0, @dns_server, SizeOf(TSocketAddr));



  // Response bekle (timeout: 3 saniye)
  FillChar(response, SizeOf(response), 0);
  ret := recvfrom(sockfd, @response[0], 512, 0, @dns_server, nil);
  
  if ret > 0 then
  begin
   COM1_WriteStr( 'DNS Response alindi! (');   //    + IntToStr(ret) + ' byte)'
    
    // Answer say�s�n� bul
    answerCount := GetDNSAnswerCount(@response[0]);
  COM1_WriteStr( 'Cevap sayisi: ');   //    + IntToStr(answerCount)
    
    // Answer section offset'i hesapla (query section'dan sonra)
    // Basit ��z�m: query section'un sonundan ba�la
    answerOffset := 12;  // Header sonras�
    
    // Question section'u atla (hostname + type + class)
    i := 0;
    while (i < 512) and (response[answerOffset] <> 0) do
    begin
      Inc(answerOffset);
      Inc(i);
      if i > 255 then Break;  // Sonsuz loop korumas�
    end;
    Inc(answerOffset);  // Null byte
    Inc(answerOffset, 4);  // Type ve Class
    
    // Answer section'u parse et
    if ParseDNSName(@response[0], answerOffset, resolvedIP) then
    begin
      // IP'yi string'e �evir
      IPToPCharSimple(resolvedIP, @ipStr[0], SizeOf(ipStr));
      
      COM1_WriteStr( 'IP Adresi Bulundu:');
     COM1_WriteStr(@ipStr[0]);
    end
    else
    begin
      COM1_WriteStr( 'IP adresi parse edilemedi');
    end;
  end
  else
  begin
   COM1_WriteStr( 'DNS Response alinamadi (timeout)');
  end;
  
  FreeSocket(sockfd);
  COM1_WriteStr( '---');
end;

{=============================================================================}
{ HELPER FUNCTIONS                                                            }
{=============================================================================}


function StrPos(const Str, SubStr: PChar): PChar;
var
  i, j: Integer;
  Found: Boolean;
begin
  Result := nil;
  if (Str = nil) or (SubStr = nil) then Exit;
  i := 0;
  while Str[i] <> #0 do
  begin
    if Str[i] = SubStr[0] then
    begin
      Found := True;
      j := 0;
      while SubStr[j] <> #0 do
      begin
        if Str[i + j] <> SubStr[j] then
        begin
          Found := False;
          Break;
        end;
        Inc(j);
      end;
      if Found then
      begin
        Result := @Str[i];
        Exit;
      end;
    end;
    Inc(i);
  end;
end;

function StrPos1(haystack, needle: PChar): PChar;
var
  i, j: Integer;
  found: Boolean;
begin
  Result := nil;
  if (haystack = nil) or (needle = nil) then Exit;
  
  i := 0;
  while haystack[i] <> #0 do
  begin
    j := 0;
    found := True;
    
    while needle[j] <> #0 do
    begin
      if haystack[i + j] <> needle[j] then
      begin
        found := False;
        Break;
      end;
      Inc(j);
    end;
    
    if found and (needle[0] <> #0) then
    begin
      Result := @haystack[i];
      Exit;
    end;
    
    Inc(i);
  end;
end;


{=============================================================================}
{ TBrowserData METHODS                                                        }
{=============================================================================}


procedure TBrowserData.ParseURL(const URL: PChar; out Host: PChar; out Path: PChar);
var
  p: PChar;
  i, j: Integer;
  HostBuf: array[0..255] of Char;
  PathBuf: array[0..255] of Char;
begin
  p := URL;
  if StrPos(p, 'http://') = p then
    Inc(p, 7)
  else if StrPos(p, 'https://') = p then
    Inc(p, 8);

  i := 0;
  while (p[i] <> #0) and (p[i] <> '/') do
  begin
    HostBuf[i] := p[i];
    Inc(i);
  end;
  HostBuf[i] := #0;

  if p[i] = '/' then
  begin
    j := 0;
    while p[i + j] <> #0 do
    begin
      PathBuf[j] := p[i + j];
      Inc(j);
    end;
    PathBuf[j] := #0;
  end
  else
  begin
    PathBuf[0] := '/';
    PathBuf[1] := #0;
  end;

  Host := StrNew(@HostBuf[0]);
  Path := StrNew(@PathBuf[0]);
end;

function FindHeaderEnd(Buffer: PByteArray; BufferLen: Integer; out BodyPtr: PChar): Integer;
var
  i: Integer;
begin
  Result := -1;     // Bulunamad� varsay�lan de�eri
  BodyPtr := nil;
  
  if (Buffer = nil) or (BufferLen < 4) then Exit;

  for i := 0 to BufferLen - 4 do
  begin
    // 1. Standart CRLF CRLF (#13#10#13#10) Kontrol�
    if (Buffer^[i]   = 13) and (Buffer^[i+1] = 10) and
       (Buffer^[i+2] = 13) and (Buffer^[i+3] = 10) then
    begin
      Result := i + 4;               // Header uzunlu�u (Byte olarak)
      BodyPtr := PChar(@Buffer^[i + 4]); // Body'nin ba�lad��� adresi d�nd�r
      Exit;
    end;

    // 2. Alternatif LF LF (#10#10) Kontrol�
    if (Buffer^[i] = 10) and (Buffer^[i+1] = 10) then
    begin
      Result := i + 2;               // Header uzunlu�u
      BodyPtr := PChar(@Buffer^[i + 2]);
      Exit;
    end;
  end;
end;

function TBrowserData.HTTPGet(const Host: PChar; const Path: PChar;
                              out Body: PChar; out BodyLen: Integer): Boolean;
var
  Sock: PSocket;
  Addr: TSocketAddr;
  Request: array[0..1023] of Char;
  Response: array[0..HTTP_BUF_SIZE-1] of Byte;
  BytesRead, TotalRead: Integer;
  HeaderEnd: PChar;
  timeout: Integer;

  HeaderLen: Integer;
  BodyStartPtr: PChar;
begin
  Result := False;
  Body := nil;
  BodyLen := 0;

  Sock := socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if Sock = nil then Exit;

  Addr.sin_family := AF_INET;
  // Port numaras�n� varsay�lan olarak HTTP (80) portuna ayarlay�n (Veya htons kullan�n)
  Addr.sin_port := 8080;
  // Dinamik olarak parametreden gelen Host adresini kullan�n
  Addr.sin_addr := inet_addr(Host);

  if Addr.sin_addr = 0 then
  begin
    close(Sock);
    Exit;
  end;

  if connect(Sock, Addr, SizeOf(TSocketAddr)) <> 0 then
  begin
    close(Sock);
    Exit;
  end;

  // HTTP Request haz�rl���
  StrCopy(@Request[0], 'GET ');
  StrAppend(@Request[0], Path);
  StrAppend(@Request[0], ' HTTP/1.1'#13#10'Host: ');
  StrAppend(@Request[0], Host);
  StrAppend(@Request[0], #13#10'User-Agent: PascalBrowser/1.0'#13#10);
  StrAppend(@Request[0], 'Accept: text/html'#13#10);
  StrAppend(@Request[0], 'Connection: close'#13#10#13#10);

  if send(Sock, @Request[0], StrLen(@Request[0]), 0) = SOCKET_ERROR then
  begin
    close(Sock);
    Exit;
  end;

  TotalRead := 0;
  timeout := HTTP_TIMEOUT;
  FillChar(Response, SizeOf(Response), 0);

  // ALIM D�NG�S� D�ZELTMES�
  repeat
    BytesRead := recv(Sock, @Response[TotalRead], HTTP_BUF_SIZE - TotalRead - 1);
    if BytesRead > 0 then
    begin
      Inc(TotalRead, BytesRead);
    end
    else if BytesRead = 0 then
    begin
      // Sunucu TCP FIN g�nderdi, ba�lant� d�zg�n �ekilde kapand�.
      // Veri al�m� bitti, d�ng�den hemen ��k.
      Break; 
    end;
    
    // E�er bloklamayan (non-blocking) soket yap�s� kullan�yorsan�z paket al�m�n� ve zaman a��m�n� i�leyin:
    // RTL8139ReceivePacket;
    // Delay(10);
    Dec(timeout, 10);

  until timeout <= 0;

  close(Sock);

  Response[TotalRead] := 0;

 // Header sonunu bul (Result = HeaderUzunlu�u, BodyStartPtr = Body Adresi)
  HeaderLen := FindHeaderEnd(@Response[0], TotalRead, BodyStartPtr);

  if (HeaderLen > 0) and (BodyStartPtr <> nil) then
  begin
    // Art�k kesin olarak buraya girecektir
    BodyLen := TotalRead - HeaderLen;
    if BodyLen >= 0 then
    begin
      // Body verisini kopyala/ay�r
      Body := StrNew(BodyStartPtr);
      Result := True;
    end;
  end
  else
  begin
    // Ba�l�k sonu bulunamad�ysa (�rn: Paket eksik/yar�m geldiyse)
    Result := False;
  end;
end;



procedure TBrowserData.ParseHTML(const HTML: PChar);
var
  p: PChar;
  LineBuf: array[0..LINE_BUF_LEN-1] of Char;
  LinePos: Integer;
  CurrColor: LongWord;
  CurrIsLink: Boolean;
  CurrLinkURL: array[0..255] of Char;
  InBold: Boolean;
  InHeading: Integer;
  InStyle: Boolean;
  InScript: Boolean;

  procedure FlushLine;
  begin
    if (LinePos > 0) and (LineCount < MAX_RENDER_LINES) then
    begin
      LineBuf[LinePos] := #0;
      StrCopy(@Lines[LineCount].Text[0], @LineBuf[0]);
      Lines[LineCount].Color := CurrColor;
      Lines[LineCount].IsLink := CurrIsLink;
      if CurrIsLink then
        StrCopy(@Lines[LineCount].LinkURL[0], @CurrLinkURL[0]);
      Inc(LineCount);
    end;
    LinePos := 0;
  end;

  procedure AddChar(ch: Char);
  begin
    if LinePos < LINE_BUF_LEN - 1 then
    begin
      LineBuf[LinePos] := ch;
      Inc(LinePos);
    end;
  end;

  procedure ParseTag;
  var
    j, k: Integer;
    TagBuf: array[0..63] of Char;
    IsEndTag: Boolean;
  begin
    IsEndTag := p^ = '/';
    if IsEndTag then Inc(p);

    j := 0;
    while (p^ <> #0) and (p^ <> '>') and (p^ <> ' ') and (j < 63) do
    begin
      if (p^ >= 'A') and (p^ <= 'Z') then
        TagBuf[j] := Char(Ord(p^) + 32)
      else
        TagBuf[j] := p^;
      Inc(j);
      Inc(p);
    end;
    TagBuf[j] := #0;

    // href parse (sadece <a ...> a��l�� tag'inde)
    if (StrCmp(@TagBuf[0], 'a') = 0) and not IsEndTag then
    begin
      while (p^ <> #0) and (p^ <> '>') do
      begin
        if (p^ = 'h') and ((p+1)^ = 'r') and ((p+2)^ = 'e') and ((p+3)^ = 'f') then
        begin
          Inc(p, 4);
          while (p^ <> #0) and (p^ <> '=') do Inc(p);
          if p^ = '=' then Inc(p);
          while (p^ <> #0) and ((p^ = ' ') or (p^ = '"') or (p^ = #39)) do Inc(p);
          k := 0;
          while (p^ <> #0) and (p^ <> '"') and (p^ <> #39) and (p^ <> '>') and (p^ <> ' ') and (k < 255) do
          begin
            CurrLinkURL[k] := p^;
            Inc(k);
            Inc(p);
          end;
          CurrLinkURL[k] := #0;
        end
        else
          Inc(p);
      end;
    end;

    while (p^ <> #0) and (p^ <> '>') do Inc(p);
    if p^ = '>' then Inc(p);

    if IsEndTag then
    begin
      if (StrCmp(@TagBuf[0], 'style') = 0) then
      begin
        InStyle := False;
        FlushLine;
        Exit;
      end
      else if (StrCmp(@TagBuf[0], 'script') = 0) then
      begin
        InScript := False;
        FlushLine;
        Exit;
      end
      else if (StrCmp(@TagBuf[0], 'a') = 0) then
      begin
        { D�ZELTME 1: Link sat�r�n� kaydet, sonra kapat }
        FlushLine;
        CurrIsLink := False;
        CurrColor := COL_TEXT;
        if InBold then CurrColor := COL_BOLD;
      end
      else if (StrCmp(@TagBuf[0], 'b') = 0) or (StrCmp(@TagBuf[0], 'strong') = 0) then
      begin
        InBold := False;
        if not CurrIsLink then CurrColor := COL_TEXT;
      end
      else if (StrCmp(@TagBuf[0], 'h1') = 0) or (StrCmp(@TagBuf[0], 'h2') = 0) or
              (StrCmp(@TagBuf[0], 'h3') = 0) or (StrCmp(@TagBuf[0], 'h4') = 0) or
              (StrCmp(@TagBuf[0], 'h5') = 0) or (StrCmp(@TagBuf[0], 'h6') = 0) then
      begin
        InHeading := 0;
        if not CurrIsLink and not InBold then CurrColor := COL_TEXT;
      end
      else if (StrCmp(@TagBuf[0], 'p') = 0) or (StrCmp(@TagBuf[0], 'div') = 0) then
      begin
        FlushLine;
      end;
    end
    else
    begin
      if (StrCmp(@TagBuf[0], 'style') = 0) then
      begin
        InStyle := True;
        FlushLine;
        Exit;
      end
      else if (StrCmp(@TagBuf[0], 'script') = 0) then
      begin
        InScript := True;
        FlushLine;
        Exit;
      end
      else if (StrCmp(@TagBuf[0], 'br') = 0) then
      begin
        FlushLine;
      end
      else if (StrCmp(@TagBuf[0], 'p') = 0) or (StrCmp(@TagBuf[0], 'div') = 0) then
      begin
        FlushLine;
      end
      else if (StrCmp(@TagBuf[0], 'a') = 0) then
      begin
        { D�ZELTME 2: �nceki metni kaydet, sonra yeni link ba�lat }
        if LinePos > 0 then FlushLine;
        CurrIsLink := True;
        CurrColor := COL_LINK;
      end
      else if (StrCmp(@TagBuf[0], 'b') = 0) or (StrCmp(@TagBuf[0], 'strong') = 0) then
      begin
        InBold := True;
        if not CurrIsLink then CurrColor := COL_BOLD;
      end
      else if (StrCmp(@TagBuf[0], 'h1') = 0) or (StrCmp(@TagBuf[0], 'h2') = 0) or
              (StrCmp(@TagBuf[0], 'h3') = 0) then
      begin
        InHeading := 1;
        FlushLine;
        CurrColor := COL_HEADING;
      end
      else if (StrCmp(@TagBuf[0], 'hr') = 0) or (StrCmp(@TagBuf[0], 'li') = 0) or
              (StrCmp(@TagBuf[0], 'tr') = 0) then
      begin
        FlushLine;
      end;
    end;
  end;

begin
  LineCount := 0;
  LinkCount := 0;
  p := HTML;
  LinePos := 0;
  CurrColor := COL_TEXT;
  CurrIsLink := False;
  InBold := False;
  InHeading := 0;
  InStyle := False;
  InScript := False;
  CurrLinkURL[0] := #0;

  while p^ <> #0 do
  begin
    if InStyle or InScript then
    begin
      if p^ = '<' then
      begin
        Inc(p);
        ParseTag;
      end
      else
        Inc(p);
      Continue;
    end;

    if p^ = '<' then
    begin
      Inc(p);
      ParseTag;
    end
    else if (p^ = #13) or (p^ = #10) then
    begin
      if p^ = #13 then
      begin
        Inc(p);
        if p^ = #10 then Inc(p);
      end
      else
        Inc(p);
      if LinePos > 0 then FlushLine;
    end
    else
    begin
      AddChar(p^);
      Inc(p);
    end;
  end;

  FlushLine;
end;

procedure TBrowserData.DrawContent(Sender:PPanel;AbsX, AbsY: Integer);
var
  i, y, LineH, TextW: Integer;
begin
  KFill(AbsX, AbsY, Sender^.Width, Sender^.Height, COL_BG);

  LineH := FONT_H + 4;

  // TEST: Scroll tamamen devre d���, t�m sat�rlar 0'dan ba�lar
  LinkCount := 0;

  for i := 0 to LineCount - 1 do
  begin
    // Sat�r Y'sini direkt hesapla: AbsY + �st bo�luk + (sat�r no * y�kseklik)
    y := AbsY + 8 + (i * LineH);
    
    if y > AbsY + Sender^.Height then Break;

    KStr(AbsX + 8, y, @Lines[i].Text[0], Lines[i].Color);

    if Lines[i].IsLink and (LinkCount < MAX_LINKS) then
    begin
      TextW := StrLen(@Lines[i].Text[0]) * FONT_W;

      Links[LinkCount].X := 8;          // Relative X (sol bo�luk)
      Links[LinkCount].Y := 8 + (i * LineH);  // Relative Y (scroll yok!)
      Links[LinkCount].W := TextW;
      Links[LinkCount].H := LineH;
      Links[LinkCount].LineIndex := i;
      StrCopy(@Links[LinkCount].URL[0], @Lines[i].LinkURL[0]);
      Inc(LinkCount);
    end;
  end;
end;

procedure ContentPanelMouseDown(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  i: Integer;
begin

  for i := 0 to BrowserData1.LinkCount - 1 do
  begin
    // DEBUG: Her linkin Y koordinat�n� g�ster (ilk 5 link)


    if (AX >= BrowserData1.Links[i].X) and 
       (AX < BrowserData1.Links[i].X + BrowserData1.Links[i].W) and
       (AY >= BrowserData1.Links[i].Y) and 
       (AY < BrowserData1.Links[i].Y + BrowserData1.Links[i].H) then
    begin
      // T�klanan linkin URL'sini g�ster (ekran�n ortas�na)

      // Veya Navigate �a��r:
       StrCopy(@BrowserData1.CurrentURL[0], @BrowserData1.Links[i].URL[0]);
       StrCopy(@BrowserData1.EdtURL^.Text[0], @BrowserData1.Links[i].URL[0]);
       BrowserData1.Navigate;
      Exit;
    end;
  end;
end;

procedure TBrowserData.Navigate;
var
  Host, Path, Body: PChar;
  BodyLen: Integer;
  StatusBuf: array[0..255] of Char;
begin
  // URL'yi edit kutusundan al
  StrCopy(@CurrentURL[0], @EdtURL^.Text[0]);
  if CurrentURL[0] = #0 then Exit;



  StrCopy(@StatusBuf[0], 'Loading: ');
  StrAppend(@StatusBuf[0], @CurrentURL[0]);
  StatusBarSetText(StatusBar, 0, @StatusBuf[0]);
  if FForm <> nil then RelayoutForm(FForm);

  ParseURL(@CurrentURL[0], Host, Path);

  if HTTPGet(Host, Path, Body, BodyLen) then
  begin
    ParseHTML(Body);
    StrDispose(Body);

    StrCopy(@StatusBuf[0], 'Done: ');
    StrAppend(@StatusBuf[0], @CurrentURL[0]);
    StrAppend(@StatusBuf[0], ' (');
    SysUtils.IntToPChar(LineCount, @StatusBuf[StrLen(@StatusBuf[0])]);
    StrAppend(@StatusBuf[0], ' lines)');

    StatusBarSetText(StatusBar, 0, @StatusBuf[0]);
  end
  else
  begin
    LineCount := 0;
    StrCopy(@Lines[0].Text[0], 'Failed to load page.');
    Lines[0].Color := $000000FF;
    Lines[0].IsLink := False;
    LineCount := 1;

    StrCopy(@StatusBuf[0], 'Error: Could not connect to ');
    StrAppend(@StatusBuf[0], Host);

    StatusBarSetText(StatusBar, 0, @StatusBuf[0]);
  end;


  StatusBarSetText(StatusBar, 0, @StatusBuf[0]);
  if FForm <> nil then RelayoutForm(FForm);

  StrDispose(Host);
  StrDispose(Path);
end;

{=============================================================================}
{ GUI EVENT BRIDGE FUNCTIONS                                                  }
{=============================================================================}

procedure ContentPanelDraw(Sender: PPanel; AbsX, AbsY: Integer);
begin
  BrowserData1.DrawContent(Sender,AbsX, AbsY);
end;




procedure BtnGoClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
begin
   BrowserData1.Navigate;
end;

procedure BrowserFormDestroy(Sender: PObject);
begin

end;

{=============================================================================}
{ OPEN FORM                                                                   }
{=============================================================================}

procedure OpenWebBrowserForm;
var

  Toolbar: PPanel;
  Btn: PButton;
  ContentArea: PPanel;
begin

  //  DNSQuery('www.google.com');



  FillChar(BrowserData1, SizeOf(TBrowserData), 0);

  BrowserData1.FForm := CreateForm('Web Browser', 40, 40, 760, 560);
  if BrowserData1.FForm = nil then Exit;

  BrowserData1.FForm^.BorderStyle := bsWindow;
  BrowserData1.FForm^.ShowSysButtons := True;
  BrowserData1.FForm^.Color := clBtnFace;
  BrowserData1.FForm^.BindDestroy(@BrowserFormDestroy);


  BrowserData1.LineCount := 0;
  BrowserData1.LinkCount := 0;

  { --- Toolbar --- }
  Toolbar := CreatePanel(PObject(BrowserData1.FForm), 0, 0, 0, 36, alTop);
  Toolbar^.Color := clBtnFace;
  Toolbar^.BorderWidth := 0;

  // URL Edit
  BrowserData1.EdtURL := CreateEdit(PObject(Toolbar), 8, 6, 500, 24, alNone);
  EditSetText(BrowserData1.EdtURL, '127.0.0.1');

  // Go Button
  Btn := CreateButton(PObject(Toolbar), 'Go', 516, 6, 50, 24, alNone);
  Btn^.BindMouseDown(@BtnGoClick);



  { --- Content Area --- }
  ContentArea := CreatePanel(PObject(BrowserData1.FForm), 0, 0, 0, 0, alClient);
  ContentArea^.Color := COL_BG;
  ContentArea^.BorderWidth := 1;
  ContentArea^.BorderColor := $00404040;
  ContentArea^.BindPaint(@ContentPanelDraw);
  ContentArea^.BindMouseDown(@ContentPanelMouseDown);
  BrowserData1.ContentPanel := ContentArea;

  { --- Scrollbar --- }
  BrowserData1.VScroll := CreateScrollBar(PObject(ContentArea), 0, 0, 16, 100, alRight);
  BrowserData1.VScroll^.Min := 0;
  BrowserData1.VScroll^.Max := 0;
  BrowserData1.VScroll^.PageSize := 100;
  BrowserData1.VScroll^.Position:=0;
  BrowserData1.VScroll^.SmallChange := FONT_H + 4;


  { Status Bar }
  BrowserData1.StatusBar := CreateStatusBar(PObject(BrowserData1.FForm), 0, 0, 640, alBottom);
  BrowserData1.StatusBar.AddPanel('Hazir', 450);
  BrowserData1.StatusBar.AddPanel('WebBrowser V0.2', 250);

  // Welcome message
  StrCopy(@BrowserData1.Lines[0].Text[0], 'Welcome to Pascal Web Browser');
  BrowserData1.Lines[0].Color := COL_HEADING;
  BrowserData1.Lines[0].IsLink := False;
  
  StrCopy(@BrowserData1.Lines[1].Text[0], '');
  BrowserData1.Lines[1].Color := COL_TEXT;
  
  StrCopy(@BrowserData1.Lines[2].Text[0], 'Enter a URL and click Go');
  StrCopy(@BrowserData1.Lines[2].LinkURL[0], 'www.google.com');
  BrowserData1.Lines[2].Color := COL_TEXT;
  BrowserData1.Lines[2].IsLink := True;
  
  StrCopy(@BrowserData1.Lines[3].Text[0], 'Example: 10.0.2.15 or 127.0.0.1');
  BrowserData1.Lines[3].Color := COL_LINK;
  BrowserData1.Lines[3].IsLink := False;
  
  BrowserData1.LineCount := 4;


end;

end.

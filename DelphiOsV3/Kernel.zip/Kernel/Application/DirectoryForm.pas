unit DirectoryForm;

interface

uses
  SysUtils, Fat32, GUI, Draw32, Memory, Vesa, Component;

const
  ICON_FOLDER = 0;
  ICON_IMAGE  = 1;
  ICON_AUDIO  = 2;
  ICON_TEXT   = 3;
  ICON_EXE    = 4;
  ICON_FILE   = 5;
  FONT_H      = 8;
  FONT_W      = 8;

  // �� Classic Windows Renk Paleti ��������������������������������������
  CL_FACE     = $D4D0C8;   // clBtnFace
  CL_FACE2    = $C8C4BC;   // Biraz daha koyu (panel ic)
  CL_FACE3    = $E0DDD8;   // Biraz daha acik
  CL_WINDOW   = $FFFFFF;   // clWindow (liste, edit arkaplan)
  CL_WINTEXT  = $000000;   // clWindowText
  CL_BTNTEXT  = $000000;   // clBtnText
  CL_GRAY     = $808080;   // clBtnShadow / gri metin
  CL_GRAY2    = $606060;   // Daha koyu gri
  CL_HILITE   = $0078D7;   // Secim mavisi
  CL_HILTEXT  = $FFFFFF;   // Secim uzerinde metin
  CL_CAP1     = $0A246A;   // Pencere baslik gradyani sol
  CL_CAP2     = $1084D0;   // Pencere baslik gradyani sag
  CL_BORDER   = $808080;   // 3D kenarl�k
  CL_BORDER2  = $A0A0A0;   // Ince kenarl�k
  CL_DISABLED = $A0A0A0;   // Devre disi metin

  // Ikon renkleri (klasik � koyu)
  CL_IC_FOLDER = $C07800;   // Koyu alt�n
  CL_IC_IMAGE  = $0050A0;   // Koyu mavi
  CL_IC_AUDIO  = $008040;   // Koyu yesil
  CL_IC_TEXT   = $404040;   // Koyu gri
  CL_IC_EXE    = $6A0080;   // Mor
  CL_IC_FILE   = $606060;   // Gri

  // Toolbar
  TB_H   = 30;
  TB_BH  = 22;
  TB_PAD = 4;
  LEFT_W = 180;

  TB_BACK        = 0;
  TB_FORWARD     = 1;
  TB_UP          = 2;
  TB_REFRESH     = 3;
  TB_HOME        = 4;
  TB_VIEW_ICON   = 5;
  TB_VIEW_LIST   = 6;
  TB_VIEW_DETAIL = 7;
  TB_COUNT       = 8;

type
  TTBBtn = record
    X, W   : Integer;
    Cap    : array[0..15] of Char;
    Enabled: Boolean;
  end;

  PDirectoryForm = ^TDirectoryForm;
  TDirectoryForm = object(TForm)
  private
    TBPanel    : PPanel;
    AddrPanel  : PPanel;
    LeftPanel  : PPanel;
    Splitter   : PSplitter;
    ClientPanel: PPanel;
    ListView   : PListView;
    SearchEdit : PEdit;
    StatusBar  : PStatusBar;

    TBBtns   : array[0..TB_COUNT-1] of TTBBtn;
    TBHot    : Integer;
    TBPress  : Integer;

    CurrentPath : array[0..MAX_PATH-1] of Char;
    History     : array[0..31, 0..MAX_PATH-1] of Char;
    HistoryIdx  : Integer;
    HistoryCnt  : Integer;

    SelName     : array[0..MAX_PATH-1] of Char;
    SelSizeStr  : array[0..31] of Char;
    SelTypeStr  : array[0..31] of Char;
    SelExtStr   : array[0..7] of Char;
    SelIconIdx  : Integer;
    SelIsDir    : Boolean;
    SelItemCount: Integer;
    SearchText  : array[0..63] of Char;

    procedure BuildToolbarBtns();
    procedure LoadDirectory(APath: PChar; SaveHist: Boolean);
    procedure GoBack;
    procedure GoForward;
    procedure GoUp;
    procedure GoHome;
    procedure ExecuteItem(Name: PChar);
    procedure UpdateLeftPanel;
    procedure UpdateStatusBar;
    procedure ApplySearch;
    function  GetIconIdx(Name: PChar; Attr: Byte): Integer;
    function  GetIconColor(Idx: Integer): LongWord;
    function  GetTypeStr(Idx: Integer): PChar;
    procedure GetExt(Name, OutExt: PChar);
    procedure FormatSize(Bytes: LongWord; Buf: PChar);
    procedure TBBtnAt(X: Integer; out BtnIdx: Integer);
    function  MatchesSearch(Name: PChar): Boolean;

   // procedure DrawToolBar  (Sender: PObject; OX, OY: Integer);
   // procedure DrawAddrBar  (Sender: PObject; OX, OY: Integer);
   // procedure DrawLeftPanel(Sender: PObject; OX, OY: Integer);
    procedure DrawBigIcon  (X, Y, Sz, Idx: Integer);
    procedure DrawFolderIcon(X, Y, Sz: Integer);
    procedure DrawImageIcon (X, Y, Sz: Integer);
    procedure DrawAudioIcon (X, Y, Sz: Integer);
    procedure DrawTextIcon  (X, Y, Sz: Integer);
    procedure DrawExeIcon   (X, Y, Sz: Integer);
    procedure DrawFileIcon  (X, Y, Sz: Integer);
  public

   // procedure OnTBDown(Sender: PObject; X, Y: Integer; Btn: Byte);
   // procedure OnTBUp  (Sender: PObject; X, Y: Integer; Btn: Byte);
   // procedure OnTBMove(Sender: PObject; X, Y: Integer; Btn: Byte);
   // procedure OnLVSel (Sender: PObject);
   // procedure OnLVDbl (Sender: PObject; X, Y: Integer; Btn: Byte);
   // procedure OnSearch(Sender: PObject; Key: Word);
  end;

procedure OpenDirectoryBrowser(RootPath: PChar);

var
  DirectoryForm1:PDirectoryForm;

implementation

// =============================================================================
// YOL YARDIMCILARI
// =============================================================================

procedure ConcatPath(Base, Child, Dest: PChar);
var L: Integer;
begin
  StrCopy(Dest, Base);
  L := StrLen(Dest);
  if (L > 0) and (Dest[L-1] <> '\') then
  begin
    Dest[L]   := '\';
    Dest[L+1] := #0;
  end;
  StrAppend(Dest, Child);
end;

procedure GetParentPath(Path, Dest: PChar);
var I, Last: Integer;
begin
  StrCopy(Dest, Path);
  I    := StrLen(Dest) - 1;
  Last := -1;
  if (I > 0) and (Dest[I] = '\') then Dec(I);
  while I >= 0 do
  begin
    if Dest[I] = '\' then begin Last := I; Break; end;
    Dec(I);
  end;
  if Last >= 0 then
  begin
    if (Last = 2) and (Dest[1] = ':') then
      Dest[Last+1] := #0
    else
      Dest[Last] := #0;
  end;
end;

function IsDir(Attr: Byte): Boolean;
begin
  Result := (Attr and ATTR_DIRECTORY) <> 0;
end;

function UpCh(C: Char): Char;
begin
  if (C >= 'a') and (C <= 'z') then Result := Char(Ord(C) - 32)
  else Result := C;
end;

// =============================================================================
// RENK & TIP YARDIMCILARI
// =============================================================================

function TDirectoryForm.GetIconColor(Idx: Integer): LongWord;
begin
  case Idx of
    ICON_FOLDER: Result := CL_IC_FOLDER;
    ICON_IMAGE:  Result := CL_IC_IMAGE;
    ICON_AUDIO:  Result := CL_IC_AUDIO;
    ICON_TEXT:   Result := CL_IC_TEXT;
    ICON_EXE:    Result := CL_IC_EXE;
  else           Result := CL_IC_FILE;
  end;
end;

function TDirectoryForm.GetTypeStr(Idx: Integer): PChar;
begin
  case Idx of
    ICON_FOLDER: Result := 'Klasor';
    ICON_IMAGE:  Result := 'Resim Dosyasi';
    ICON_AUDIO:  Result := 'Ses Dosyasi';
    ICON_TEXT:   Result := 'Metin Belgesi';
    ICON_EXE:    Result := 'Program';
  else           Result := 'Dosya';
  end;
end;

procedure TDirectoryForm.GetExt(Name, OutExt: PChar);
var I, L, Dot: Integer;
begin
  OutExt[0] := #0;
  L   := StrLen(Name);
  Dot := -1;
  for I := L-1 downto 0 do
    if Name[I] = '.' then begin Dot := I; Break; end;
  if Dot < 0 then Exit;
  I := 0;
  while (Dot+I < L) and (I < 7) do
  begin
    OutExt[I] := UpCh(Name[Dot+I]);
    Inc(I);
  end;
  OutExt[I] := #0;
end;

function TDirectoryForm.GetIconIdx(Name: PChar; Attr: Byte): Integer;
var Ext: array[0..7] of Char;
begin
  if IsDir(Attr) then begin Result := ICON_FOLDER; Exit; end;
  GetExt(Name, @Ext[0]);
  if (StrCmp(@Ext[0],'.BMP')=0) or (StrCmp(@Ext[0],'.RAW')=0) or
     (StrCmp(@Ext[0],'.PNG')=0) or (StrCmp(@Ext[0],'.JPG')=0) then
    Result := ICON_IMAGE
  else if (StrCmp(@Ext[0],'.WAV')=0) or (StrCmp(@Ext[0],'.MP3')=0) or
          (StrCmp(@Ext[0],'.OGG')=0) then
    Result := ICON_AUDIO
  else if (StrCmp(@Ext[0],'.TXT')=0) or (StrCmp(@Ext[0],'.PAS')=0) or
          (StrCmp(@Ext[0],'.LOG')=0) or (StrCmp(@Ext[0],'.INI')=0) then
    Result := ICON_TEXT
  else if (StrCmp(@Ext[0],'.EXE')=0) or (StrCmp(@Ext[0],'.BIN')=0) or
          (StrCmp(@Ext[0],'.COM')=0) then
    Result := ICON_EXE
  else
    Result := ICON_FILE;
end;

procedure TDirectoryForm.FormatSize(Bytes: LongWord; Buf: PChar);
var T: array[0..31] of Char; I: Integer;
begin
  if Bytes >= 1024*1024 then
  begin
    IntToPChar(Bytes div (1024*1024), @T[0]);
    I := StrLen(@T[0]);
    T[I]:=' '; T[I+1]:='M'; T[I+2]:='B'; T[I+3]:=#0;
  end
  else if Bytes >= 1024 then
  begin
    IntToPChar(Bytes div 1024, @T[0]);
    I := StrLen(@T[0]);
    T[I]:=' '; T[I+1]:='K'; T[I+2]:='B'; T[I+3]:=#0;
  end
  else
  begin
    IntToPChar(Bytes, @T[0]);
    I := StrLen(@T[0]);
    T[I]:=' '; T[I+1]:='B'; T[I+2]:=#0;
  end;
  StrCopy(Buf, @T[0]);
end;

function TDirectoryForm.MatchesSearch(Name: PChar): Boolean;
var SLen, NLen, I, J: Integer; Match: Boolean;
begin
  SLen := StrLen(@SearchText[0]);
  if SLen = 0 then begin Result := True; Exit; end;
  NLen   := StrLen(Name);
  Result := False;
  for I := 0 to NLen - SLen do
  begin
    Match := True;
    for J := 0 to SLen-1 do
      if UpCh(Name[I+J]) <> UpCh(SearchText[J]) then
      begin
        Match := False;
        Break;
      end;
    if Match then begin Result := True; Exit; end;
  end;
end;

// =============================================================================
// BUYUK DOSYA IKONLARI � Klasik / Acik Arka Plan
// =============================================================================

procedure TDirectoryForm.DrawFolderIcon(X, Y, Sz: Integer);
var T, I, LineY: Integer;
begin
  T := Sz * 28 div 100;

  // Klasor govdesi (alt�n sar�)
  KFill(X, Y+T, Sz, Sz-T, $C07800);
  KRect(X, Y+T, Sz, Sz-T, $804000);
  // Tab (ust sol)
  KFill(X, Y+T, Sz*45 div 100, T, $D08800);
  KRect(X, Y+T, Sz*45 div 100, T, $804000);
  // Ust parlaklik
  KLineH(X+1, Y+T+1, Sz*44 div 100 - 1, $F0C840);
  KLineH(X+1, Y+T+3, Sz-2, $E09820);
  // Ic alan (acik)
  KFill(X+3, Y+T+5, Sz-6, Sz-T-8, $F0C860);
  // Icerideki dosya cizgileri
  for I := 0 to 3 do
  begin
    LineY := Y + T + 10 + I * 7;
    KLineH(X+7, LineY, Sz-14, $C08000);
    KLineH(X+7, LineY+1, Sz-14, $D09000);
  end;
  // Alt golge
  KLineH(X+1, Y+Sz-1, Sz-2, $804000);
end;

procedure TDirectoryForm.DrawImageIcon(X, Y, Sz: Integer);
var SkyH, GroundY, MX, MY, MH, MW, I, SnowH: Integer;
begin
  SkyH    := Sz * 55 div 100;
  GroundY := Y + 2 + SkyH;

  // Beyaz cerceve
  KFill(X, Y, Sz, Sz, CL_WINDOW);
  KRect(X, Y, Sz, Sz, CL_IC_IMAGE);
  KLineH(X+1, Y+1, Sz-2, $D0E8FF);

  // Gokyuzu
  KGradientV(X+2, Y+2, Sz-4, SkyH, $87CEEB, $4682B4);
  // Zemin
  KFill(X+2, GroundY, Sz-4, Sz-4-SkyH, $5A8040);
  KLineH(X+2, GroundY, Sz-4, $2ECC71);

  // Dag
  MX := X + Sz div 2;
  MY := Y + 4;
  MH := SkyH - 6;
  for I := 0 to MH div 2 do
  begin
    MW := I * 2 + 2;
    KLineH(MX - MW div 2, MY + MH - I, MW, $7090B0);
  end;
  // Kar
  SnowH := MH div 6;
  for I := 0 to SnowH do
  begin
    MW := I + 2;
    KLineH(MX - MW div 2, MY + I, MW, CL_WINDOW);
  end;

  // Gunes
  KFill(X + Sz*70 div 100, Y+6, 9, 9, $FFD700);
  KRect(X + Sz*70 div 100, Y+6, 9, 9, $C08000);
end;

procedure TDirectoryForm.DrawAudioIcon(X, Y, Sz: Integer);
var C, NC: LongWord; I, WX, WH, WY, NX, NY: Integer;
begin
  C  := $008040;
  NC := $00A050;

  // clBtnFace arkaplan
  KFill(X, Y, Sz, Sz, CL_FACE);
  KRect(X, Y, Sz, Sz, C);

  // Ust parlaklik
  KLineH(X+1, Y+1, Sz-2, CL_FACE3);

  // Dalga cubuklar�
  for I := 0 to 3 do
  begin
    WX := X + Sz div 5 + I * (Sz div 5);
    if I mod 2 = 0 then WH := Sz div 4
    else                 WH := Sz div 4 + Sz div 6;
    WY := Y + (Sz - WH) div 2;
    KFill(WX, WY, 5, WH, C);
    KFill(WX+1, WY+1, 3, WH-2, NC);
    // Kenarl�k golge
    KLineH(WX, WY+WH-1, 5, $004020);
  end;

  // Nota sembolu (sag ust)
  NX := X + Sz*58 div 100;
  NY := Y + 8;
  // Not basi
  KFill(NX,    NY + Sz div 3,     9, 6, C);
  KFill(NX+13, NY + Sz div 4,     9, 6, C);
  // Not sapi
  KFill(NX+8,  NY,                2, Sz div 3 + 4, C);
  KFill(NX+21, NY,                2, Sz div 4 + 4, C);
  // Baglas
  KLineH(NX+8, NY,   15, C);
  KLineH(NX+8, NY+2, 15, C);
end;

procedure TDirectoryForm.DrawTextIcon(X, Y, Sz: Integer);
var FX, LY, LW, I: Integer;
begin
  // Beyaz kagit
  KFill(X, Y, Sz, Sz, CL_WINDOW);
  KRect(X, Y, Sz, Sz, CL_GRAY);

  // Katlanmis kose (sag ust)
  FX := X + Sz*68 div 100;
  KFill(FX, Y, Sz-(FX-X), Sz*32 div 100, CL_FACE2);
  for I := 0 to Sz*32 div 100 do
    KLineH(FX, Y+I, I, CL_WINDOW);
  KLineH(FX, Y + Sz*32 div 100, Sz-(FX-X), CL_GRAY);
  KLineV(FX, Y, Sz*32 div 100, CL_GRAY);

  // Metin satirlari
  for I := 0 to 5 do
  begin
    LY := Y + 10 + I * (Sz - 20) div 6;
    if I < 5 then LW := Sz - 12
    else          LW := Sz * 50 div 100;
    KFill(X+5, LY, LW, 2, $808080);
  end;
  // Baslik (koyu)
  KFill(X+5, Y+8, Sz*55 div 100, 4, $303030);
end;

procedure TDirectoryForm.DrawExeIcon(X, Y, Sz: Integer);
var C: LongWord; CX, CY, R, I: Integer;
begin
  C  := $6A0080;
  CX := X + Sz div 2;
  CY := Y + Sz div 2;
  R  := Sz div 4;

  // clBtnFace arkaplan
  KFill(X, Y, Sz, Sz, CL_FACE);
  KRect(X, Y, Sz, Sz, C);
  KLineH(X+1, Y+1, Sz-2, CL_FACE3);

  // Disli dis (8 yon)
  KFill(CX-2, CY-R-4, 4, 6, C);
  KFill(CX-2, CY+R-1, 4, 6, C);
  KFill(CX-R-4, CY-2, 6, 4, C);
  KFill(CX+R-1, CY-2, 6, 4, C);
  KFill(CX-R+1, CY-R+1, 4, 4, C);
  KFill(CX+R-5, CY-R+1, 4, 4, C);
  KFill(CX-R+1, CY+R-5, 4, 4, C);
  KFill(CX+R-5, CY+R-5, 4, 4, C);
  // Cember katmanlar�
  for I := 0 to 5 do
  begin
    KLineH(CX-R+I, CY-R+I,   2*R-I*2, C);
    KLineH(CX-R+I, CY+R-I-1, 2*R-I*2, C);
  end;
  // Ic bosluk (ac�k)
  KFill(CX-R+4, CY-R+4, 2*R-8, 2*R-8, CL_FACE);
  // Merkez nokta
  KFill(CX-3, CY-3, 6, 6, $9030B0);
  KFill(CX-1, CY-1, 2, 2, CL_FACE);
end;

procedure TDirectoryForm.DrawFileIcon(X, Y, Sz: Integer);
var FX, FY: Integer;
begin
  // Genel dosya: beyaz dokuman
  KFill(X, Y, Sz, Sz, CL_WINDOW);
  KRect(X, Y, Sz, Sz, CL_GRAY);
  FX := X + Sz*65 div 100;
  FY := Y + Sz*30 div 100;
  // Katlanmis kose
  KFill(FX, Y, Sz-(FX-X), FY-Y, CL_FACE2);
  KLineH(FX, FY, Sz-(FX-X), CL_GRAY);
  KLineV(FX, Y, FY-Y, CL_GRAY);
  // Uzanti
  if SelExtStr[0] <> #0 then
    KStrCentered(X, Y + Sz*60 div 100, Sz, @SelExtStr[0], CL_GRAY2);
end;

procedure TDirectoryForm.DrawBigIcon(X, Y, Sz, Idx: Integer);
begin
  case Idx of
    ICON_FOLDER: DrawFolderIcon(X, Y, Sz);
    ICON_IMAGE:  DrawImageIcon(X, Y, Sz);
    ICON_AUDIO:  DrawAudioIcon(X, Y, Sz);
    ICON_TEXT:   DrawTextIcon(X, Y, Sz);
    ICON_EXE:    DrawExeIcon(X, Y, Sz);
  else           DrawFileIcon(X, Y, Sz);
  end;
end;

// =============================================================================
// TOOLBAR BUTON TANIMLARI
// =============================================================================

procedure TDirectoryForm.BuildToolbarBtns();
var
  X:Integer;

  procedure AddBtn(Idx: Integer; Cap: PChar; W: Integer);
  begin
    TBBtns[Idx].X := X;
    TBBtns[Idx].W := W;
    StrCopy(@TBBtns[Idx].Cap[0], Cap);
    TBBtns[Idx].Enabled := True;
    Inc(X, W + 2);
  end;

begin
  X := 4;
  AddBtn(TB_BACK,        '< Geri',  60);
  AddBtn(TB_FORWARD,     'ileri >',  60);
  Inc(X, 6);
  AddBtn(TB_UP,          '^ Ust',    52);
  AddBtn(TB_REFRESH,     'Yenile',   56);
  AddBtn(TB_HOME,        'Ev',       40);
  Inc(X, 10);
  AddBtn(TB_VIEW_ICON,   'Ikonlar',  58);
  AddBtn(TB_VIEW_LIST,   'Liste',    48);
  AddBtn(TB_VIEW_DETAIL, 'Detay',    48);
end;

procedure TDirectoryForm.TBBtnAt(X: Integer; out BtnIdx: Integer);
var I: Integer;
begin
  BtnIdx := -1;
  for I := 0 to TB_COUNT-1 do
    if (X >= TBBtns[I].X) and (X < TBBtns[I].X + TBBtns[I].W) then
    begin
      BtnIdx := I;
      Exit;
    end;
end;

// =============================================================================
// TOOLBAR CIZIMI � Classic 3D Windows look
// =============================================================================

procedure DrawToolBar(Sender: PObject; OX, OY: Integer);
var
  F: PDirectoryForm;
  I, BX, BY: Integer;
  IsHot, IsPress, IsEnabled: Boolean;
  TxtColor: LongWord;
begin
  F  := PDirectoryForm(Sender^.Parent);
  BY := OY + TB_PAD;

  // Arka plan: klasik clBtnFace, ust/alt kenarl�k
  KFill(OX, OY, Sender^.Width, TB_H, CL_FACE);
  // Ust parlaklik, alt golge (3D toolbar)
  KLineH(OX, OY, Sender^.Width, $FFFFFF);
  KLineH(OX, OY + TB_H - 2, Sender^.Width, CL_BORDER);
  KLineH(OX, OY + TB_H - 1, Sender^.Width, $404040);

  for I := 0 to TB_COUNT-1 do
  begin
    BX        := OX + F^.TBBtns[I].X;
    IsHot     := (I = F^.TBHot);
    IsPress   := (I = F^.TBPress);
    IsEnabled := F^.TBBtns[I].Enabled;

    if not IsEnabled then
    begin
      // Devre disi: duz arkaplan, gri metin
      KFill(BX, BY, F^.TBBtns[I].W, TB_BH, CL_FACE);
    end
    else if IsPress then
    begin
      // Basilmis: sunken 3D
      KSunken(BX, BY, F^.TBBtns[I].W, TB_BH, CL_FACE2);
    end
    else if IsHot then
    begin
      // Uzerinde: raised 3D + hafif renkli ic
      KFill(BX, BY, F^.TBBtns[I].W, TB_BH, CL_FACE3);
      KRect3D(BX, BY, F^.TBBtns[I].W, TB_BH, True);
    end
    else
    begin
      // Normal: duz
      KFill(BX, BY, F^.TBBtns[I].W, TB_BH, CL_FACE);
    end;

    if not IsEnabled then     TxtColor := CL_DISABLED
    else if IsPress then      TxtColor := CL_BTNTEXT
    else                      TxtColor := CL_BTNTEXT;

    KStrCentered(BX, BY + (TB_BH - FONT_H) div 2,
                 F^.TBBtns[I].W, @F^.TBBtns[I].Cap[0], TxtColor);
  end;

  // Geri/ileri gri (devre disi gorunum)
  if F^.HistoryIdx <= 1 then
  begin
    KFill(OX + F^.TBBtns[TB_BACK].X, BY, F^.TBBtns[TB_BACK].W, TB_BH, CL_FACE);
    KStrCentered(OX + F^.TBBtns[TB_BACK].X, BY + (TB_BH - FONT_H) div 2,
                 F^.TBBtns[TB_BACK].W, @F^.TBBtns[TB_BACK].Cap[0], CL_DISABLED);
  end;
  if F^.HistoryIdx >= F^.HistoryCnt then
  begin
    KFill(OX + F^.TBBtns[TB_FORWARD].X, BY, F^.TBBtns[TB_FORWARD].W, TB_BH, CL_FACE);
    KStrCentered(OX + F^.TBBtns[TB_FORWARD].X, BY + (TB_BH - FONT_H) div 2,
                 F^.TBBtns[TB_FORWARD].W, @F^.TBBtns[TB_FORWARD].Cap[0], CL_DISABLED);
  end;
end;

// =============================================================================
// ADRES CUBUGU � Klasik sunken edit gorunumu
// =============================================================================

procedure DrawAddrBar(Sender: PObject; OX, OY: Integer);
var
  F: PDirectoryForm;
  Path: PChar;
  PLen, I, CX, SegStart, SegLen, J, SW: Integer;
  SegBuf: array[0..MAX_PATH-1] of Char;
begin
  F    := PDirectoryForm(Sender^.Parent);
  Path := @F^.CurrentPath[0];

  // Arkaplan: clBtnFace
  KFill(OX, OY, Sender^.Width, Sender^.Height, CL_FACE);
  // Ust kenarl�k (toolbar alt kenarligi ile ayni)
  KLineH(OX, OY, Sender^.Width, CL_FACE3);
  KLineH(OX, OY + Sender^.Height - 1, Sender^.Width, CL_BORDER);

  // Sunken adres alani cercevesi
  KSunken(OX + 2, OY + 2, Sender^.Width - 174, Sender^.Height - 4, CL_WINDOW);

  // Ok simgesi
  KStr(OX + 6, OY + 4, '>', CL_GRAY2);

  // Breadcrumb segmentleri
  CX       := OX + 20;
  PLen     := StrLen(Path);
  SegStart := 0;

  for I := 0 to PLen do
  begin
    if (Path[I] = '\') or (Path[I] = '/') or (Path[I] = #0) then
    begin
      SegLen := I - SegStart;
      if SegLen > 0 then
      begin
        for J := 0 to SegLen-1 do
          SegBuf[J] := Path[SegStart+J];
        SegBuf[SegLen] := #0;

        SW := SegLen * FONT_W + 6;
        KStr(CX + 2, OY + 4, @SegBuf[0], CL_WINTEXT);
        Inc(CX, SW);

        if Path[I] <> #0 then
        begin
          KStr(CX, OY + 4, '>', CL_GRAY);
          Inc(CX, FONT_W + 2);
        end;
      end;
      SegStart := I + 1;
    end;
  end;

  // "Ara:" etiketi (SearchEdit solunda)
  KStr(Sender^.Width - 192, OY + 4, 'Ara:', CL_GRAY2);
end;

// =============================================================================
// SOL BILGI PANELI � Classic clBtnFace
// =============================================================================

procedure DrawLeftPanel(Sender: PObject; OX, OY: Integer);
var
  F: PDirectoryForm;
  W, H, IY, IconSz, BadgeW, TypeLenPx: Integer;
  C: LongWord;
  CountBuf: array[0..31] of Char;
  TypeLabel: PChar;
begin
  F      := PDirectoryForm(Sender^.Parent);
  W      := Sender^.Width;
  H      := Sender^.Height;
  IconSz := 64;

  // Arka plan: clBtnFace + sag kenarda ince 3D cizgi
  KFill(OX, OY, W, H, CL_FACE);
  KLineV(OX + W - 2, OY, H, CL_BORDER);
  KLineV(OX + W - 1, OY, H, $FFFFFF);

  // Baslik seridi (klasik mavi gradyan � Windows title bar gibi)
  KGradientH(OX, OY, W, 20, CL_CAP1, CL_CAP2);
  KStr(OX+6, OY+2, 'DOSYA BILGISI', $FFFFFF);
  KLineH(OX, OY+20, W, $404040);
  KLineH(OX, OY+21, W, $808080);

  if F^.SelName[0] = #0 then
  begin
    KStrCentered(OX, OY + H div 2 - FONT_H, W, '(Secim yok)', CL_GRAY);
    Exit;
  end;

  // Buyuk ikon (ortali) � beyaz kare uzerinde
  IY := OY + 30;
  KFill(OX + (W - IconSz - 4) div 2, IY - 2, IconSz + 4, IconSz + 4, CL_WINDOW);
  KRect3D(OX + (W - IconSz - 4) div 2, IY - 2, IconSz + 4, IconSz + 4, False);
  F^.DrawBigIcon(OX + (W - IconSz) div 2, IY, IconSz, F^.SelIconIdx);

  // Tip rozeti (renkli)
  C         := F^.GetIconColor(F^.SelIconIdx);
  TypeLabel := F^.GetTypeStr(F^.SelIconIdx);
  TypeLenPx := StrLen(TypeLabel) * FONT_W + 10;
  BadgeW    := TypeLenPx;
  KFill(OX + (W - BadgeW) div 2, IY + IconSz + 6, BadgeW, 14, CL_FACE2);
  KRect(OX + (W - BadgeW) div 2, IY + IconSz + 6, BadgeW, 14, C);
  KStrCentered(OX, IY + IconSz + 6, W, TypeLabel, C);

  // Dosya adi
  IY := IY + IconSz + 26;
  KLineH(OX+6, IY, W-12, CL_BORDER);
  Inc(IY, 4);
  Clip_Set(OX+4, IY, OX+W-4, IY+FONT_H);
  KStr(OX+8, IY, @F^.SelName[0], CL_WINTEXT);
  Clip_Clear;
  Inc(IY, FONT_H + 8);

  // Detaylar (sunken panel icinde)
  KSunken(OX+4, IY, W-8, 64, CL_WINDOW);
  Inc(IY, 4);

  KStr(OX+8, IY, 'Boyut :', CL_GRAY2);
  KStr(OX + W - StrLen(@F^.SelSizeStr[0])*FONT_W - 8,
       IY, @F^.SelSizeStr[0], CL_WINTEXT);
  Inc(IY, FONT_H + 4);

  KLineH(OX+6, IY, W-12, CL_BORDER2);
  Inc(IY, 4);

  KStr(OX+8, IY, 'Tur   :', CL_GRAY2);
  KStr(OX+8, IY + FONT_H + 2, @F^.SelTypeStr[0], C);
  Inc(IY, FONT_H*2 + 10);

  // Klasor icerik sayisi
  if F^.SelIsDir then
  begin
    KSunken(OX+4, IY, W-8, 36, CL_WINDOW);
    Inc(IY, 4);
    KStr(OX+8, IY, 'Icerik:', CL_GRAY2);
    Inc(IY, FONT_H + 2);
    IntToPChar(F^.SelItemCount, @CountBuf[0]);
    StrAppend(@CountBuf[0], ' oge');
    KStr(OX+8, IY, @CountBuf[0], CL_WINTEXT);
  end;

  // Yol (en altta)
  IY := OY + H - 56;
  KLineH(OX+6, IY, W-12, CL_BORDER);
  Inc(IY, 4);
  KStr(OX+8, IY, 'Konum:', CL_GRAY2);
  Inc(IY, FONT_H + 2);
  Clip_Set(OX+4, IY, OX+W-4, IY + FONT_H*2);
  KStr(OX+8, IY, @F^.CurrentPath[0], CL_GRAY2);
  Clip_Clear;
end;

// =============================================================================
// DIZIN YUKLEME
// =============================================================================

procedure TDirectoryForm.LoadDirectory(APath: PChar; SaveHist: Boolean);
var
  FH: Integer;
  FD: TFindData;
  Count: Integer;
  SzBuf: array[0..31] of Char;
  ListItem:PListItem;
  ListIndex:Integer;
begin
  StrCopy(@CurrentPath[0], APath);

  if SaveHist then
  begin
    if HistoryIdx < 31 then Inc(HistoryIdx);
    StrCopy(@History[HistoryIdx][0], CurrentPath);
    HistoryCnt := HistoryIdx;
  end;

  TBBtns[TB_BACK].Enabled    := HistoryIdx > 1;
  TBBtns[TB_FORWARD].Enabled := HistoryIdx < HistoryCnt;
  TBBtns[TB_UP].Enabled      := StrLen(APath) > 3;

  ListView_Clear(ListView);
  Count := 0;

  FH := FindFirst(CurrentPath, '*', ATTR_DIRECTORY or $3F, @FD);
  if FH >= 0 then
  begin
    repeat
      if not MatchesSearch(@FD.Name[0]) then Continue;
       ListIndex:= ListView_AddItem(ListView,@FD.Name[0]);

       ListItem:=ListView^.Items[ListIndex];
       ListItem^.ImageIndex:=  GetIconIdx(@FD.Name[0],FD.Attr);

      if IsDir(FD.Attr) then
      begin
        ListItem^.Tag:=0;
      end
      else
      begin
        ListItem^.Tag:=1;
      end;

      Inc(Count);
    until not FindNext(FH, @FD);
    FindClose(FH);
  end;

  SelItemCount := Count;
  SelName[0]   := #0;
  SelIconIdx   := ICON_FOLDER;
  UpdateStatusBar;
end;

// =============================================================================
// NAVIGASYON
// =============================================================================

procedure TDirectoryForm.GoBack;
begin
  if HistoryIdx > 1 then
  begin
    Dec(HistoryIdx);
    LoadDirectory(@History[HistoryIdx][0], False);
  end;
end;

procedure TDirectoryForm.GoForward;
begin
  if HistoryIdx < HistoryCnt then
  begin
    Inc(HistoryIdx);
    LoadDirectory(@History[HistoryIdx][0], False);
  end;
end;

procedure TDirectoryForm.GoUp;
var ParentPath: array[0..MAX_PATH-1] of Char;
begin
  GetParentPath(@CurrentPath[0], @ParentPath[0]);
  if StrLen(@ParentPath[0]) > 0 then
    LoadDirectory(@ParentPath[0], True);
end;

procedure TDirectoryForm.GoHome;
begin
  LoadDirectory('C:\', True);
end;

procedure TDirectoryForm.ExecuteItem(Name: PChar);
var Ext: array[0..7] of Char; Full: array[0..MAX_PATH-1] of Char;
begin
  ConcatPath(@CurrentPath[0], Name, @Full[0]);
  GetExt(Name, @Ext[0]);
 { if (StrCmp(@Ext[0],'.BMP')=0) or (StrCmp(@Ext[0],'.RAW')=0) then
    OpenImageViewer(@Full[0])
  else if StrCmp(@Ext[0],'.WAV')=0 then
    OpenWavPlayer(@Full[0])
  else if StrCmp(@Ext[0],'.TXT')=0 then
    ShowMessage('Metin aciliyor...')
  else if StrCmp(@Ext[0],'.EXE')=0 then
    ShowMessage('Program baslatiliyor...'); }
end;

// =============================================================================
// DURUM GUNCELLEMELERI
// =============================================================================

procedure TDirectoryForm.UpdateLeftPanel;
var Idx: Integer;
begin
  Idx := ListView^.ItemIndex;
  if Idx < 0 then begin SelName[0] := #0; Exit; end;
  StrCopy(@SelName[0], ListView^.Items[Idx].Caption);
  GetExt(@SelName[0], @SelExtStr[0]);
 { SelIsDir := StrCmp(ListView^.SelectedText(2), 'Dizin') = 0;
  if SelIsDir then
  begin
    StrCopy(@SelSizeStr[0], '--');
    StrCopy(@SelTypeStr[0], 'Klasor');
    SelIconIdx := ICON_FOLDER;
  end
  else
  begin
    StrCopy(@SelSizeStr[0], ListView^.SelectedText(1));
    SelIconIdx := GetIconIdx(@SelName[0], 0);
    StrCopy(@SelTypeStr[0], GetTypeStr(SelIconIdx));
  end; }
end;

procedure TDirectoryForm.UpdateStatusBar;
var Buf: array[0..63] of Char;
begin
 { IntToPChar(SelItemCount, @Buf[0]);
  StrAppend(@Buf[0], ' oge');
  StatusBar^.SetPanelText(0, @Buf[0]);
  if SelName[0] <> #0 then
  begin
    StrCopy(@Buf[0], 'Secili: ');
    StrAppend(@Buf[0], @SelName[0]);
    StatusBar^.SetPanelText(1, @Buf[0]);
  end
  else
    StatusBar^.SetPanelText(1, 'Hicbir sey secilmedi'); }
end;

procedure TDirectoryForm.ApplySearch;
begin
 SearchText[0] := #0;
  if SearchEdit <> nil then
    Edit_GetText(SearchEdit, SearchText,63);
  //  StrCopy(@SearchText[0], SearchEdit^.GetText);
  LoadDirectory(@CurrentPath[0], False);
end;

// =============================================================================
// OLAY ISLEYICILERI
// =============================================================================

procedure OnTBDown(Sender: PObject; X, Y: Integer; Btn: Byte);
var F: PDirectoryForm; BIdx: Integer;
begin
  F := PDirectoryForm(Sender^.Parent);
  X:=X-F^.Left;
  Y:=Y-F^.Top;
  F^.TBBtnAt(X, BIdx);
  if (BIdx >= 0) and F^.TBBtns[BIdx].Enabled then
  begin
    F^.TBPress    := BIdx;

  end;
end;

procedure OnTBUp(Sender: PObject; X, Y: Integer; Btn: Byte);
var F: PDirectoryForm; BIdx: Integer;
begin
  F := PDirectoryForm(Sender^.Parent);
  X:=X-F^.Left;
  Y:=Y-F^.Top;
  F^.TBBtnAt(X, BIdx);
  if (BIdx >= 0) and (BIdx = F^.TBPress) and F^.TBBtns[BIdx].Enabled then
    case BIdx of
      TB_BACK:        F^.GoBack;
      TB_FORWARD:     F^.GoForward;
      TB_UP:          F^.GoUp;
      TB_REFRESH:     F^.LoadDirectory(@F^.CurrentPath[0], False);
      TB_HOME:        F^.GoHome;
      TB_VIEW_ICON:   F^.ListView^.ViewStyle:=(1);
      TB_VIEW_LIST:   F^.ListView^.ViewStyle:=(0);
      TB_VIEW_DETAIL: F^.ListView^.ViewStyle:=(2);
    end;
  F^.TBPress    := -1;

end;

procedure OnTBMove(Sender: PObject; X, Y: Integer; Btn: Byte);
var F: PDirectoryForm; BIdx: Integer;
begin
  F := PDirectoryForm(Sender^.Parent);
  X:=X-F^.Left;
  Y:=Y-F^.Top;
  F^.TBBtnAt(X, BIdx);
  if (BIdx >= 0) and F^.TBBtns[BIdx].Enabled then F^.TBHot := BIdx
  else F^.TBHot := -1;
end;

procedure OnLVSel(Sender: PObject);
var F: PDirectoryForm;
begin
  F := PDirectoryForm(Sender^.Parent);
  F^.UpdateLeftPanel;
  F^.UpdateStatusBar;
end;

procedure OnLVDbl(Sender: PObject; X, Y: Integer; Btn: Byte);
var
  F: PDirectoryForm;

  NewPath: array[0..MAX_PATH-1] of Char;
  ListItem:PListItem;
begin
  F := PDirectoryForm(Sender^.Parent);
  if F^.ListView^.ItemIndex < 0 then Exit;

  ListItem:=F^.ListView^.Items[ F^.ListView^.ItemIndex];


  if ListItem^.Tag = 0 then
  begin
    ConcatPath(@F^.CurrentPath[0], ListItem^.Caption, @NewPath[0]);
    F^.LoadDirectory(@NewPath[0], True);
  end
  else
    F^.ExecuteItem(ListItem^.Caption);
end;

procedure OnSearch(Sender: PObject; Key: Word);
var F: PDirectoryForm;
begin
  F := PDirectoryForm(Sender^.Parent);
  F^.ApplySearch;
end;


{---------------------------------------------------------------------------}
{  A�MA FONKS�YONU                                                          }
{---------------------------------------------------------------------------}




procedure OpenDirectoryBrowser(RootPath: PChar);
var
  W, H: Integer;
begin
  W := 720;
  H := 520;

  DirectoryForm1 := PDirectoryForm(Form_CreateEx(DesktopObj,
    (Surface.Width - W) div 2,
    (Surface.Height - H) div 2,
    W, H,
    'Dosya Yoneticisi',
    SizeOf(TDirectoryForm)));

  if DirectoryForm1 = nil then Exit;

  DirectoryForm1^.HistoryIdx    := 0;
  DirectoryForm1^.HistoryCnt    := 0;
  DirectoryForm1^.TBHot         := -1;
  DirectoryForm1^.TBPress       := -1;
  DirectoryForm1^.SearchText[0] := #0;
  DirectoryForm1^.SelName[0]    := #0;
  DirectoryForm1^.SelItemCount  := 0;
  DirectoryForm1^.SelIconIdx    := ICON_FOLDER;
  DirectoryForm1^.BuildToolbarBtns();
  


  // 1. Toolbar
  DirectoryForm1^.TBPanel :=  Panel_Create(DirectoryForm1,0, 0, DirectoryForm1^.Width, TB_H);

  DirectoryForm1^.TBPanel^.Align       := alTop;
  DirectoryForm1^.TBPanel^.OnPaint:=  @DrawToolBar;
  DirectoryForm1^.TBPanel^.OnMouseDown := @OnTBDown;
  DirectoryForm1^.TBPanel^.OnMouseUp   := @OnTBUp;
  DirectoryForm1^.TBPanel^.OnMouseMove := @OnTBMove;
  // 2. Adres + Arama cubugu

 DirectoryForm1^.AddrPanel:=Panel_Create(DirectoryForm1,0, 0, DirectoryForm1^.Width, 26);
 DirectoryForm1^.AddrPanel^.Align   := alTop;
// DirectoryForm1^.AddrPanel^.OnPaint := @DrawAddrBar;


  DirectoryForm1^.SearchEdit :=  Edit_Create(DirectoryForm1^.AddrPanel, DirectoryForm1^.AddrPanel^.Width - 172, 4, 160, 18);
  Edit_SetText(DirectoryForm1^.SearchEdit,'C:\');
  DirectoryForm1^.SearchEdit^.Align     :=  alRight;
  DirectoryForm1^.SearchEdit^.OnKeyDown := @OnSearch;


  DirectoryForm1^.LeftPanel := Panel_Create(DirectoryForm1,0, 0, LEFT_W, DirectoryForm1^.Height);

  DirectoryForm1^.LeftPanel^.Align   := alLeft;
  DirectoryForm1^.LeftPanel^.OnPaint := DrawLeftPanel;

  DirectoryForm1^.Splitter := Splitter_Create(DirectoryForm1, 0, 0, 4, 0);



  DirectoryForm1^.ListView := ListView_Create(DirectoryForm1, 0, 0, 100, 100);
  DirectoryForm1^.ListView^.Align := alClient;
  DirectoryForm1^.ListView^.ViewStyle := 2;        { 2 = Icon modu }
  DirectoryForm1^.ListView^.ItemWidth := 80;
  DirectoryForm1^.ListView^.ItemHeight := 64;
  DirectoryForm1^.ListView^.OnClick := OnLVSel;
  DirectoryForm1^.ListView^.OnDblClick  := OnLVDbl;


  DirectoryForm1^.StatusBar := StatusBar_Create(DirectoryForm1, 0, 0, W, 22);
  DirectoryForm1^.StatusBar^.Align := alBottom;
  StatusBar_AddPanel(DirectoryForm1^.StatusBar, 'Hazir', 350, 0);
  StatusBar_AddPanel(DirectoryForm1^.StatusBar, '0', 80, 2);



   DirectoryForm1^.LoadDirectory(RootPath, True);

end;




end.

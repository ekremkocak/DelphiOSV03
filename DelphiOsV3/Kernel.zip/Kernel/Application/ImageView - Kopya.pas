unit ImageView;

interface

uses
  SysUtils, Memory, Draw32, Vesa, GUI,Math, GUIControls, Fat32,Messages,
  JPEGDecoder;

{=============================================================================}
{ BMP Image Viewer - Zoom + Scroll                                            }
{=============================================================================}
type
  PLongWordArray =^TLongWordArray;
  TLongWordArray = array[0..0] of LongWord;


type
  TBMPFileHeader = packed record
    bfType: Word;
    bfSize: LongWord;
    bfReserved1: Word;
    bfReserved2: Word;
    bfOffBits: LongWord;
  end;

  TBMPInfoHeader = packed record
    biSize: LongWord;
    biWidth: LongInt;
    biHeight: LongInt;
    biPlanes: Word;
    biBitCount: Word;
    biCompression: LongWord;
    biSizeImage: LongWord;
    biXPelsPerMeter: LongInt;
    biYPelsPerMeter: LongInt;
    biClrUsed: LongWord;
    biClrImportant: LongWord;
  end;

  PImageViewData = ^TImageViewData;
  TImageViewData = record
    FilePath: array[0..255] of Char;
    BitmapData: PLongWordArray;
    BitmapWidth: Integer;
    BitmapHeight: Integer;
    Zoom: Integer;
    ImagePanel: PPanel;
    HScroll: PScrollBar;
    VScroll: PScrollBar;
    LblZoom: PLabel;
  end;

  procedure OpenImageViewer(const FilePath: PChar);
  procedure ImageViewUpdateScrollbars(Data: PImageViewData);
  procedure ImagePanelDraw(Sender: PObject; AbsX, AbsY: Integer);
implementation



{-----------------------------------------------------------------------------}
{ BMP Yukleme (24-bit ve 32-bit destekli)                                     }
{ NOT: Eger sisteminizde standart AssignFile/Reset calismiyorsa,              }
{      Fat32 unit'inizin FileOpen/FileRead/FileClose rutinlerini kullanin.    }
{-----------------------------------------------------------------------------}

{=============================================================================}
{ HIZLI BMP YUKLEYICI - Tam dosyayi tek seferde buffer'a alir                 }
{=============================================================================}
function LoadBMP(const FilePath: PChar; out Width, Height: Integer; out Pixels: PLongWordArray): Boolean;
var
  FH: TBMPFileHeader;
  IH: TBMPInfoHeader;
  F: Integer;
  FileSize, ReadBytes: LongWord;
  FileBuf: PByteArray;      // <-- Tum dosya bu tampona cekilecek
  SrcRowSize: Integer;
  y, x: Integer;
  DstRow: PLongWordArray;
  B, G, R: Byte;
  SrcOff: LongWord;
begin
  Result := False;
  Pixels := nil;
  Width := 0; Height := 0;

  F := OpenFile(FilePath, FILE_READ);
  if F < 0 then Exit;

  { --- 1. Header oku --- }
  if ReadFile(F, @FH, SizeOf(FH)) <> SizeOf(FH) then begin CloseFile(F); Exit; end;
  if FH.bfType <> $4D42 then begin CloseFile(F); Exit; end;

  if ReadFile(F, @IH, SizeOf(IH)) <> SizeOf(IH) then begin CloseFile(F); Exit; end;
  if IH.biSize < 40 then begin CloseFile(F); Exit; end;
  if IH.biCompression <> 0 then begin CloseFile(F); Exit; end;

  Width  := IH.biWidth;
  Height := Abs(IH.biHeight);
  if (Width <= 0) or (Height <= 0) then begin CloseFile(F); Exit; end;

  { --- 2. Tum dosyayi tek seferde RAM'e al (Seek yok, tek ReadFile!) --- }
  FileSize := FH.bfSize;
  if FileSize < FH.bfOffBits then begin CloseFile(F); Exit; end;

  FileBuf := PByteArray(MemAlloc(FileSize));
  if FileBuf = nil then begin CloseFile(F); Exit; end;

  SeekFile(F, 0, SEEK_SET);
  ReadBytes := ReadFile(F, FileBuf, FileSize);
  CloseFile(F);

  if ReadBytes < FH.bfOffBits then begin FreeMem(FileBuf); Exit; end;

  { --- 3. Pixel bufferi ayir --- }
  Pixels := PLongWordArray(MemAlloc(Width * Height * SizeOf(LongWord)));
  if Pixels = nil then begin FreeMem(FileBuf); Exit; end;

  { --- 4. Bellekten bellege cevir (FileBuf -> Pixels) --- }
  if IH.biBitCount = 24 then
  begin
    SrcRowSize := ((Width * 3) + 3) and not 3;
    for y := 0 to Height - 1 do
    begin
      SrcOff := FH.bfOffBits + LongWord(Height - 1 - y) * SrcRowSize;
      DstRow := PLongWordArray(LongWord(Pixels) + LongWord(y * Width * 4));
      for x := 0 to Width - 1 do
      begin
        B := FileBuf[SrcOff + x * 3];
        G := FileBuf[SrcOff + x * 3 + 1];
        R := FileBuf[SrcOff + x * 3 + 2];
        DstRow[x] := (R shl 16) or (G shl 8) or B;
      end;
    end;
  end
  else if IH.biBitCount = 32 then
  begin
    SrcRowSize := Width * 4;
    for y := 0 to Height - 1 do
    begin
      SrcOff := FH.bfOffBits + LongWord(Height - 1 - y) * SrcRowSize;
      DstRow := PLongWordArray(LongWord(Pixels) + LongWord(y * Width * 4));
      Move(FileBuf[SrcOff], DstRow^, SrcRowSize);
    end;
  end
  else
  begin
    FreeMem(Pixels); Pixels := nil;
    FreeMem(FileBuf);
    Exit;
  end;

  FreeMem(FileBuf);
  Result := True;
end;

{-----------------------------------------------------------------------------}
{ Yardimci: Zoom label guncelle                                               }
{-----------------------------------------------------------------------------}
procedure UpdateZoomLabel(Data: PImageViewData);
var
  buf: array[0..15] of Char;
begin
  if Data^.LblZoom = nil then Exit;
  StrCopy(@Data^.LblZoom^.Caption[0], 'Zoom: ');
  IntToPChar(Data^.Zoom, @buf[0]);
  StrAppend(@Data^.LblZoom^.Caption[0], @buf[0]);
  StrAppend(@Data^.LblZoom^.Caption[0], '%');
end;

{-----------------------------------------------------------------------------}
{ Scrollbar sinirlari ve page size guncelle                                   }
{-----------------------------------------------------------------------------}
procedure ImageViewUpdateScrollbars(Data: PImageViewData);
var
  PanelW, PanelH: Integer;
  DrawW, DrawH: Integer;
begin
  if Data^.ImagePanel = nil then Exit;
  PanelW := Data^.ImagePanel^.Width;
  PanelH := Data^.ImagePanel^.Height;

  DrawW := Data^.BitmapWidth * Data^.Zoom div 100;
  DrawH := Data^.BitmapHeight * Data^.Zoom div 100;

  if Data^.HScroll <> nil then
  begin
    Data^.HScroll^.Max := MaxI(0, DrawW - PanelW);
    Data^.HScroll^.PageSize := PanelW;
    if Data^.HScroll^.Position > Data^.HScroll^.Max then
      ScrollBar_SetPosition(Data^.HScroll, Data^.HScroll^.Max);
  end;

  if Data^.VScroll <> nil then
  begin
    Data^.VScroll^.Max := MaxI(0, DrawH - PanelH);
    Data^.VScroll^.PageSize := PanelH;
    if Data^.VScroll^.Position > Data^.VScroll^.Max then
      ScrollBar_SetPosition(Data^.VScroll, Data^.VScroll^.Max);
  end;
end;

{-----------------------------------------------------------------------------}
{ Image Panel Cizimi (Stretch + Offset)                                       }
{-----------------------------------------------------------------------------}

procedure ImagePanelDraw(Sender: PObject; AbsX, AbsY: Integer);
var
  Panel: PPanel;
  Data: PImageViewData;
  F: PForm;
  PanelW, PanelH: Integer;
  OffsetX, OffsetY: Integer;
  StartX, StartY, EndX, EndY: Integer;
  sx, sy: Integer;
  px, py: Integer;
  c: LongWord;
  ZoomedSize: Integer;
  SrcPtr: PLongWordArray;        // Kaynak bitmap'te gezen pointer
  DstPtr32: PLongWordArray;      // Hedef: 32-bit Screen_Buffer
  DstPtr24: PByteArray;          // Hedef: 24-bit Screen_Buffer
  ScreenBase: LongWord;     // Screen_Buffer[0]'in adresi
  k, j: Integer;
  R, G, B: Byte;
begin
  Panel := PPanel(Sender);
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;

  PanelW := Panel^.Width - 16;
  PanelH := Panel^.Height - 16;

  { Arkaplan }
  KFill(AbsX, AbsY, PanelW, PanelH, $00E0E0E0);

  if (Data^.BitmapData = nil) or (Data^.BitmapWidth <= 0) then
  begin
    KStrCentered(AbsX, AbsY + (PanelH - FONT_H) div 2, PanelW, 'Resim yuklenemedi', clGray);
    Exit;
  end;

  OffsetX := 0; OffsetY := 0;
  if Data^.HScroll <> nil then OffsetX := Data^.HScroll^.Position;
  if Data^.VScroll <> nil then OffsetY := Data^.VScroll^.Position;

  { Gorunur bolge (kaynak koordinatlari) }
  StartY := OffsetY * 100 div Data^.Zoom;
  EndY   := (OffsetY + PanelH) * 100 div Data^.Zoom + 1;
  if StartY < 0 then StartY := 0;
  if EndY >= Data^.BitmapHeight then EndY := Data^.BitmapHeight - 1;

  StartX := OffsetX * 100 div Data^.Zoom;
  EndX   := (OffsetX + PanelW) * 100 div Data^.Zoom + 1;
  if StartX < 0 then StartX := 0;
  if EndX >= Data^.BitmapWidth then EndX := Data^.BitmapWidth - 1;

  { Screen_Buffer'in baslangic adresi (sabit, hesaplamayi hizlandirir) }
  ScreenBase := LongWord(@Screen_Buffer[0]);

  { ================================================================ }
  { ZOOM >= 100 : Blok cizim, dogrudan Screen_Buffer'a yazar         }
  { ================================================================ }
  if Data^.Zoom >= 100 then
  begin
    ZoomedSize := Data^.Zoom div 100;

    for sy := StartY to EndY do
    begin
      py := AbsY + (sy * Data^.Zoom div 100) - OffsetY;
      if py + ZoomedSize <= 0 then Continue;
      if py >= PanelH then Break;

      { Kaynak satirin baslangici }
      SrcPtr := PLongWordArray(LongWord(Data^.BitmapData) + LongWord(sy * Data^.BitmapWidth * 4));

      { Ayni kaynak satirini ZoomedSize kadar alt alta ciz }
      for k := 0 to ZoomedSize - 1 do
      begin
        if (py + k < 0) or (py + k >= PanelH) then Continue;

        if SCREEN_DEPTH = 4 then
        begin
          { 32-bit hedef satir pointer'i }
          DstPtr32 := PLongWordArray(ScreenBase + LongWord((AbsY + py + k) * SCREEN_WIDTH + AbsX) * 4);
          
          for sx := StartX to EndX do
          begin
            px := (sx * Data^.Zoom div 100) - OffsetX;
            if (px < 0) or (px >= PanelW) then Continue;
            
            c := SrcPtr[sx];
            { Yatayda ZoomedSize kadar ayni rengi tekrarla }
            for j := 0 to ZoomedSize - 1 do
              if px + j < PanelW then
                DstPtr32[px + j] := c;
          end;
        end
        else
        begin
          { 24-bit hedef satir pointer'i (BGR siralamasi) }
          DstPtr24 := PByteArray(ScreenBase + LongWord((AbsY + py + k) * SCREEN_WIDTH + AbsX) * 3);
          
          for sx := StartX to EndX do
          begin
            px := (sx * Data^.Zoom div 100) - OffsetX;
            if (px < 0) or (px >= PanelW) then Continue;
            
            c := SrcPtr[sx];
            B := Byte(c);
            G := Byte(c shr 8);
            R := Byte(c shr 16);
            
            { Yatayda ZoomedSize kadar BGR tekrarla }
            for j := 0 to ZoomedSize - 1 do
              if px + j < PanelW then
              begin
                DstPtr24[(px + j) * 3]     := B;
                DstPtr24[(px + j) * 3 + 1] := G;
                DstPtr24[(px + j) * 3 + 2] := R;
              end;
          end;
        end;
      end;
    end;
  end
  { ================================================================ }
  { ZOOM < 100 : Atlama (Decimation), dogrudan Screen_Buffer         }
  { ================================================================ }
  else
  begin
    for sy := StartY to EndY do
    begin
      py := AbsY + (sy * Data^.Zoom div 100) - OffsetY;
      if (py < 0) or (py >= PanelH) then Continue;

      SrcPtr := PLongWordArray(LongWord(Data^.BitmapData) + LongWord(sy * Data^.BitmapWidth * 4));

      if SCREEN_DEPTH = 4 then
      begin
        DstPtr32 := PLongWordArray(ScreenBase + LongWord((AbsY + py) * SCREEN_WIDTH + AbsX) * 4);
        for sx := StartX to EndX do
        begin
          px := (sx * Data^.Zoom div 100) - OffsetX;
          if (px < 0) or (px >= PanelW) then Continue;
          DstPtr32[px] := SrcPtr[sx];
        end;
      end
      else
      begin
        DstPtr24 := PByteArray(ScreenBase + LongWord((AbsY + py) * SCREEN_WIDTH + AbsX) * 3);
        for sx := StartX to EndX do
        begin
          px := (sx * Data^.Zoom div 100) - OffsetX;
          if (px < 0) or (px >= PanelW) then Continue;
          
          c := SrcPtr[sx];
          DstPtr24[px * 3]     := Byte(c);        // B
          DstPtr24[px * 3 + 1] := Byte(c shr 8);  // G
          DstPtr24[px * 3 + 2] := Byte(c shr 16); // R
        end;
      end;
    end;
  end;
end;

{-----------------------------------------------------------------------------}
{ Scroll degisince sadece yeniden ciz                                         }
{-----------------------------------------------------------------------------}
procedure ImageScrollChanged(Sender: PObject);
var
  F: PForm;
begin
  F := FindRootForm(Sender);
  if F <> nil then RelayoutForm(F);
end;

{-----------------------------------------------------------------------------}
{ Buton Click Handlerlari                                                     }
{-----------------------------------------------------------------------------}
procedure BtnZoomInClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PImageViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;
  if Data^.Zoom < 400 then
  begin
    Data^.Zoom := Data^.Zoom + 25;
    ImageViewUpdateScrollbars(Data);
    UpdateZoomLabel(Data);
    RelayoutForm(F);
  end;
end;

procedure BtnZoomOutClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PImageViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;
  if Data^.Zoom > 25 then
  begin
    Data^.Zoom := Data^.Zoom - 25;
    ImageViewUpdateScrollbars(Data);
    UpdateZoomLabel(Data);
    RelayoutForm(F);
  end;
end;

procedure BtnZoom100Click(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PImageViewData;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;
  Data^.Zoom := 100;
  if Data^.HScroll <> nil then ScrollBar_SetPosition(Data^.HScroll, 0);
  if Data^.VScroll <> nil then ScrollBar_SetPosition(Data^.VScroll, 0);
  ImageViewUpdateScrollbars(Data);
  UpdateZoomLabel(Data);
  RelayoutForm(F);
end;

procedure BtnZoomFitClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
  Data: PImageViewData;
  Z1, Z2: Integer;
begin
  F := FindRootForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;
  if Data^.ImagePanel = nil then Exit;

  Z1 := Data^.ImagePanel^.Width  * 100 div Data^.BitmapWidth;
  Z2 := Data^.ImagePanel^.Height * 100 div Data^.BitmapHeight;
  if Z1 < Z2 then Data^.Zoom := Z1 else Data^.Zoom := Z2;
  if Data^.Zoom < 25 then Data^.Zoom := 25;
  if Data^.Zoom > 400 then Data^.Zoom := 400;

  if Data^.HScroll <> nil then ScrollBar_SetPosition(Data^.HScroll, 0);
  if Data^.VScroll <> nil then ScrollBar_SetPosition(Data^.VScroll, 0);
  ImageViewUpdateScrollbars(Data);
  UpdateZoomLabel(Data);
  RelayoutForm(F);
end;

procedure BtnCloseClick(Sender: PObject; AX, AY: Integer; Btn: Byte);
var
  F: PForm;
begin
  F := FindRootForm(Sender);
 // if F <> nil then FreeObject(PObject(F));
end;

{-----------------------------------------------------------------------------}
{ Form yok edilirken bitmap bellegini temizle                                 }
{-----------------------------------------------------------------------------}
procedure ImageViewDestroy(Sender: PObject);
var
  F: PForm;
  Data: PImageViewData;
begin
  F := PForm(Sender);
  if F = nil then Exit;
  Data := PImageViewData(F^.Control);
  if Data = nil then Exit;
  if Data^.BitmapData <> nil then
  begin
    FreeMem(Data^.BitmapData);
    Data^.BitmapData := nil;
  end;
  FreeMem(Data);
  F^.Control := nil;
end;


function LoadJPEG(const FilePath: PChar; out Width, Height: Integer;
                  out Pixels: PLongWordArray): Boolean;
var
  PixelData: Pointer;
begin
  Result := False;
 if not LoadJpegFile(FilePath,PixelData, Width, Height) then exit;

  if (PixelData = nil) or (Width <= 0) or (Height <= 0) then Exit;

  Pixels := PLongWordArray(PixelData);
  Result := True;
end;


{-----------------------------------------------------------------------------}
{ Acilis: OpenImageViewer                                                     }
{-----------------------------------------------------------------------------}
procedure OpenImageViewer(const FilePath: PChar);
var
  F: PForm;
  Data: PImageViewData;
  Toolbar: PPanel;
  Btn: PButton;
  W, H: Integer;
  Pixels: PLongWordArray;
begin
 // if not LoadBMP(FilePath, W, H, Pixels) then Exit;

  if not LoadJPEG(FilePath, W, H, Pixels) then Exit;

  F := CreateForm('Image Viewer', 120, 100, 700, 520);
  if F = nil then Exit;
  F^.BorderStyle := bsWindow;
  F^.ShowSysButtons := True;
  F^.Position:=poScreenCenter;
  F^.Color := clBtnFace;
  F^.BindDestroy(@ImageViewDestroy);
 // FormCenterScreen(F);

  Data := PImageViewData(MemAlloc(SizeOf(TImageViewData)));
  FillChar(Data^, SizeOf(TImageViewData), #0);
  StrCopy(@Data^.FilePath[0], FilePath);
  Data^.BitmapData := Pixels;
  Data^.BitmapWidth := W;
  Data^.BitmapHeight := H;
  Data^.Zoom := 100;

  F^.Control := PObject(Data);

  { --- Toolbar --- }
  Toolbar := CreatePanel(PObject(F), 0, 0, 0, 36, alTop);
  Toolbar^.Color := clBtnFace;
  Toolbar^.BorderWidth := 0;

  Btn := CreateButton(PObject(Toolbar), '+',   8, 6, 28, 24, alNone);
  Btn^.BindMouseUp(@BtnZoomInClick);
  Btn := CreateButton(PObject(Toolbar), '-',  40, 6, 28, 24, alNone);
  Btn^.BindMouseUp(@BtnZoomOutClick);
  Btn := CreateButton(PObject(Toolbar), '100',72, 6, 36, 24, alNone);
  Btn^.BindMouseUp(@BtnZoom100Click);
  Btn := CreateButton(PObject(Toolbar), 'Fit',112, 6, 36, 24, alNone);
  Btn^.BindMouseUp(@BtnZoomFitClick);
  Btn := CreateButton(PObject(Toolbar), 'X',  156, 6, 28, 24, alNone);
  Btn^.BindMouseUp(@BtnCloseClick);

  Data^.LblZoom := CreateLabel(PObject(Toolbar), 'Zoom: 100%', 200, 10, 100, 20, alNone);

  { --- Scrollbars --- }
  Data^.VScroll := CreateScrollBar(PObject(F), 0, 0, 16, 100, alRight);
  Data^.VScroll^.Min := 0;
  Data^.VScroll^.Max := 0;
  Data^.VScroll^.PageSize := 100;
  Data^.VScroll^.SmallChange := 10;
 // Data^.VScroll^.OnChange := @ImageScrollChanged;

  Data^.HScroll := CreateScrollBar(PObject(F), 0, 0, 100, 16, alBottom);
  Data^.HScroll^.Min := 0;
  Data^.HScroll^.Max := 0;
  Data^.HScroll^.PageSize := 100;
  Data^.HScroll^.SmallChange := 10;
 // Data^.HScroll^.OnChange := @ImageScrollChanged;

  { --- Image Panel --- }
  Data^.ImagePanel := CreatePanel(PObject(F), 0, 0, 0, 0, alClient);
  Data^.ImagePanel^.Color := $00E0E0E0;
  Data^.ImagePanel^.BorderWidth := 1;
  Data^.ImagePanel^.BorderColor := cl3DDkShadow;
  Data^.ImagePanel^.BindPaint(@ImagePanelDraw);

  ImageViewUpdateScrollbars(Data);
end;



end.

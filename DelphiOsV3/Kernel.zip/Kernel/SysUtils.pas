{ =========================================================
  StrUtils.pas — PChar String Kütüphanesi
  
  İçerik:
  - Uzunluk: StrLen, StrSize
  - Kopyalama: StrCopy, StrCopyN, StrAppend, StrAppendN
  - Karşılaştırma: StrCmp, StrCmpI, StrCmpN, StrEqual
  - Arama: StrPos, StrRPos, StrChr, StrRChr, StrStr
  - Dönüşüm: StrUpper, StrLower, StrTrim, StrTrimL, StrTrimR
  - Kontrol: StrIsEmpty, StrStartsWith, StrEndsWith, StrContains
  - Bölme: StrSplit, StrToken, StrLeft, StrRight, StrMid
  - Sayı: IntToStr, StrToInt, FloatToStr, StrToFloat
  - Hex: IntToHex, HexToInt
  - Format: StrFill, StrPadL, StrPadR, StrCenter
  - Char: IsDigit, IsAlpha, IsAlNum, IsSpace, IsUpper, IsLower
  - Değiştirme: StrReplace, StrDelete, StrInsert
  - Çeşitli: StrRev, StrRepeat, StrCount, StrWordCount
  ========================================================= }

unit SysUtils;

interface

const
  STR_MAX = 4096;
  MAX_PATH = 256;
 
  clBlack = $000000;
  clMaroon = $000080;
  clGreen = $008000;
  clOlive = $008080;
  clNavy = $800000;
  clPurple = $800080;
  clTeal = $808000;
  clGray = $808080;
  clSilver = $C0C0C0;
  clRed = $FF0000;
  clLime = $00FF00;
  clYellow = $FFFF00;
  clBlue = $0000FF;
  clFuchsia = $FF00FF;
  clAqua = $00FFFF;
  clWhite = $FFFFFF;
  clMoneyGreen = $C0DCC0;
  clSkyBlue = $F0CAA6;
  clCream = $F0FBFF;
  clMedGray = $A4A0A0;
  clNone = $1FFFFFFF;
  clBtnFace = $FFF0F0F0;

  C_FORM_BG    = $00ECECEC;

 const
  COM1_BASE = $3F8;


  type
  TPageDirectory = array[0..1023] of LongWord;
  PPageDirectory = ^TPageDirectory;

  
  PPCharArray   = ^TPCharArray;
  TPCharArray   = array[0..$FFFFFF] of PChar;

  PIntegerArray = ^TIntegerArray;
  TIntegerArray = array[0..$FFFFFF] of Integer;


  type
  DWord      = Cardinal;
  PInteger   = ^Integer;
  PSingle    = ^Single;
  PDWORD     = ^DWORD;
  PLongWord  = ^LongWord;
  PCardinal  = ^Cardinal;
  TColor     = Cardinal;
  PString    = ^string;
  Void       = ^LongInt;
  PPointer   = ^Pointer;

  PtrUInt    =  LongWord;
  PByteArray = ^TByteArray;
  TByteArray = array[0..$FFFFFF] of Byte;


  

  PLongWordArray = ^TLongWordArray;
  TLongWordArray = array[0..$FFFFFF] of LongWord;


  PCharArray = ^TCharArray;
  TCharArray = array[0..$FFFFFF] of Char;

  QWord = UInt64;

type
  PPoint = ^TPoint;
  TPoint = packed record
    X: Longint;
    Y: Longint;
  end;

  PRect = ^TRect;
  TRect = packed record
    case Integer of
      0: (Left, Top, Right, Bottom,Width,Height: Longint);
      1: (TopLeft, BottomRight: TPoint);
      2: (X, Y, W,H: Longint);
  end;

  PRectangle = ^TRectangle;
  TRectangle = packed record
    Left, Top, Width, Height: Integer;
  end;

   type
  TBMPFileHeader = packed record
    bfType: Word;
    bfSize: LongWord;
    bfReserved1: Word;
    bfReserved2: Word;
    bfOffBits: LongWord;
  end;

  TBMPInfoHeader = packed record
    biSize: LongWord;
    biWidth: LongInt;
    biHeight: LongInt;
    biPlanes: Word;
    biBitCount: Word;
    biCompression: LongWord;
    biSizeImage: LongWord;
    biXPelsPerMeter: LongInt;
    biYPelsPerMeter: LongInt;
    biClrUsed: LongWord;
    biClrImportant: LongWord;
  end;



  

//=============================================================================
// Uzunluk
//=============================================================================

function  StrLen(S: PChar): Integer;
function  StrSize(S: PChar): Integer;     // Len + null terminator

//=============================================================================
// Kopyalama / Ekleme
//=============================================================================
function StrLComp(const Str1, Str2: PChar; MaxLen: Cardinal): Integer; assembler;
function StrLCopy(Dest: PChar; const Source: PChar; MaxLen: Cardinal): PChar; assembler;
procedure StrCopy(Dest, Src: PChar);
procedure StrCopyN(Dest, Src: PChar; N: Integer);
procedure StrAppend(Dest, Src: PChar);
procedure StrCat(Dest, Src: PChar);
procedure StrAppendN(Dest, Src: PChar; N: Integer);
procedure StrAppendChar(Dest: PChar; Ch: Char);

//=============================================================================
// Karşılaştırma
//=============================================================================

function  StrCmp(S1, S2: PChar): Integer;       // <0, 0, >0
function  StrCmpI(S1, S2: PChar): Integer; Overload;  // Case-insensitive
//function  StrCmpI(S1, S2: PChar): Boolean; Overload;
function  StrCmpN(S1, S2: PChar; N: Integer): Integer;
function  StrCmpNI(S1, S2: PChar; N: Integer): Integer;
function  StrEqual(S1, S2: PChar): Boolean;
function  StrEqualI(S1, S2: PChar): Boolean;

//=============================================================================
// Arama
//=============================================================================

function  StrPos(Haystack, Needle: PChar): Integer;   // -1 = bulunamadı
function  StrPosI(Haystack, Needle: PChar): Integer;
function  StrRPos(Haystack, Needle: PChar): Integer;
function  StrChr(S: PChar; Ch: Char): PChar;
function  StrRChr(S: PChar; Ch: Char): PChar;
function  StrIndexOf(S: PChar; Ch: Char): Integer;
function  StrLastIndexOf(S: PChar; Ch: Char): Integer;

//=============================================================================
// Dönüşüm
//=============================================================================
function StrUpChar( ch : Char ) : Char;
procedure StrUpper(S: PChar);
procedure StrLower(S: PChar);
function  StrToUpper(Ch: Char): Char;
function  StrToLower(Ch: Char): Char;
procedure StrTrim(S: PChar);
procedure StrTrimL(S: PChar);
procedure StrTrimR(S: PChar);
procedure StrReverse(S: PChar);
function UpCase(Str: PChar): PChar;


//=============================================================================
// Kontrol
//=============================================================================

function  StrIsEmpty(S: PChar): Boolean;
function  StrIsBlank(S: PChar): Boolean;
function  StrStartsWith(S, Prefix: PChar): Boolean;
function  StrStartsWithI(S, Prefix: PChar): Boolean;
function  StrEndsWith(S, Suffix: PChar): Boolean;
function  StrEndsWithI(S, Suffix: PChar): Boolean;
function  StrContains(Haystack, Needle: PChar): Boolean;
function  StrContainsI(Haystack, Needle: PChar): Boolean;
function  StrIsNumeric(S: PChar): Boolean;
function  StrIsAlpha(S: PChar): Boolean;
function  StrIsAlNum(S: PChar): Boolean;

//=============================================================================
// Alt String
//=============================================================================

procedure StrLeft(Dest, Src: PChar; N: Integer);
procedure StrRight(Dest, Src: PChar; N: Integer);
procedure StrMid(Dest, Src: PChar; Start, Len: Integer);
function  StrToken(Src: PChar; Delim: Char; var Pos: Integer;
                    Dest: PChar): Boolean;
function  StrSplit(Src: PChar; Delim: Char;
                    Tokens:array of  PChar; MaxTokens: Integer): Integer;

//=============================================================================
// Sayı Dönüşümleri
//=============================================================================
procedure IntToPChar(Value: LongWord; Buffer: PChar);
procedure IntToStr32(Value: LongWord; var Buf: array of Char);
procedure StrIntToStr(Val: Integer; Buf: PChar);
procedure StrUIntToStr(Val: LongWord; Buf: PChar);
function  StrToInt(S: PChar): Integer;
function  StrToIntDef(S: PChar; Default: Integer): Integer;
function  StrTryToInt(S: PChar; var Val: Integer): Boolean;
//procedure StrInt64ToStr(Val: Int64; Buf: PChar);
//procedure StrFloatToStr(Val: Single; Decimals: Integer; Buf: PChar);
//function  StrToFloat(S: PChar): Single;
//function  StrTryToFloat(S: PChar; var Val: Single): Boolean;

//=============================================================================
// Hex
//=============================================================================

procedure StrIntToHex(Val: LongWord; Digits: Integer; Buf: PChar);
function  StrHexToInt(S: PChar): LongWord;
procedure StrByteToHex(Val: Byte; Buf: PChar);
procedure StrWordToHex(Val: Word; Buf: PChar);
procedure StrDWordToHex(Val: LongWord; Buf: PChar);

//=============================================================================
// Format / Pad
//=============================================================================

procedure StrFill(Dest: PChar; Ch: Char; Count: Integer);
procedure StrPadLeft(Dest, Src: PChar; Width: Integer; Fill: Char);
procedure StrPadRight(Dest, Src: PChar; Width: Integer; Fill: Char);
procedure StrCenter(Dest, Src: PChar; Width: Integer; Fill: Char);
procedure StrRepeat(Dest, Src: PChar; Count: Integer);
function  StrCountChar(S: PChar; Ch: Char): Integer;
function  StrWordCount(S: PChar): Integer;

//=============================================================================
// Değiştirme
//=============================================================================

function  StrReplace(Src, Find, Repl, Dest: PChar; MaxLen: Integer): Integer;
procedure StrDeleteAt(S: PChar; Start, Count: Integer);
procedure StrInsert(S, Sub: PChar; Pos: Integer; MaxLen: Integer);

//=============================================================================
// Char Yardımcıları
//=============================================================================

function  Chr_IsDigit(Ch: Char): Boolean;
function  Chr_IsHexDigit(Ch: Char): Boolean;
function  Chr_IsAlpha(Ch: Char): Boolean;
function  Chr_IsAlNum(Ch: Char): Boolean;
function  Chr_IsSpace(Ch: Char): Boolean;
function  Chr_IsUpper(Ch: Char): Boolean;
function  Chr_IsLower(Ch: Char): Boolean;
function  Chr_IsPrint(Ch: Char): Boolean;
function  Chr_HexVal(Ch: Char): Byte;

//=============================================================================
// Çeşitli
//=============================================================================

procedure StrFromChar(Dest: PChar; Ch: Char);
procedure StrConcat(Dest, S1, S2: PChar);
function  StrHashDJB2(S: PChar): LongWord;
function  StrHashFNV1A(S: PChar): LongWord;

procedure FillChar(var Dest; count: Integer; Value:Byte);  Overload;
procedure FillChar(var Dest; count: Integer; Value: Char);  Overload;
procedure CopyMemory(Destination, Source:Pointer; dwSize:LongWord);
procedure Move(const Source; var Dest; count: Integer);

procedure StrFree(s: PChar);
function StrAlloc(len: Integer): PChar;

procedure MemSet(P: Pointer; Value: Byte; Size: LongWord);

//procedure StrAppend(dest, src: PChar);

procedure MemCopy(Dest, Src: Pointer; Size: LongWord);
//procedure MemSet(P: Pointer; Value: Byte; Size: LongWord);

procedure DebugPrint(s: PChar);
procedure COM1_WriteChar(c: Char);

function PtInRect(X, Y, AX, AY, AWidth, AHeight: Integer): Boolean; OverLoad;
function PtInRect(const Rect: TRect; const X, Y: Integer): Boolean; OverLoad;
function Rect(Left, Top, Right, Bottom: Integer): TRect;

function Random(MaxRand: Integer): Integer; OverLoad;
function Random(MinRand, MaxRand: Integer): Integer; OverLoad;

procedure COM1_WriteStr(s: PChar);
procedure WriteErrorCode(ErrorCode:Integer);

function StrNew(const S: PChar): PChar;
procedure StrDispose(S: PChar);

implementation

Uses
    Ports,Memory;
    
var
  Rand: Integer = 1;

procedure WriteErrorCode(ErrorCode:Integer);
var
 Str:Array[0..32] of Char;
begin
 IntToPChar(ErrorCode,str);
  COM1_WriteStr(str);

   COM1_WriteChar(#13);
  COM1_WriteChar(#10);
end;


procedure COM1_WriteChar(c: Char);
begin
  // THRE bit set olana kadar bekle
  while (ReadPortB(COM1_BASE + 5) and $20) = 0 do ;
  WritePortB(COM1_BASE, Ord(c));
end;

procedure COM1_WriteStr(s: PChar);
var
  i: Integer;
begin
  i := 0;
  while s[i] <> #0 do
  begin
    COM1_WriteChar(s[i]);
    Inc(i);
  end;

  COM1_WriteChar(#13);
  COM1_WriteChar(#10);
end;




procedure DebugPrint(s: PChar);
var
  i: Integer;
begin
  i := 0;
  while s[i] <> #0 do
  begin
    COM1_WriteChar(s[i]);
    Inc(i);
  end;

  COM1_WriteChar(#13);
  COM1_WriteChar(#10);
end;

procedure IntToStr32(Value: LongWord; var Buf: array of Char);
var
  i, j: Integer;
  Tmp: array[0..15] of Char;
begin
  i := 0;
  if Value = 0 then
  begin
    Buf[0] := '0';
    Buf[1] := #0;
    Exit;
  end;
  while Value > 0 do
  begin
    Tmp[i] := Char(Byte('0') + (Value mod 10));
    Value := Value div 10;
    Inc(i);
  end;
  // Ters �evirerek as�l buffer'a aktar
  for j := 0 to i - 1 do
    Buf[j] := Tmp[i - 1 - j];
  Buf[i] := #0;
end;



procedure IntToPChar(Value: LongWord; Buffer: PChar);
var
  Temp: array[0..15] of Char;
  i, j, Digits: Integer;
begin
  if Value = 0 then
  begin
    Buffer[0] := '0';
    Buffer[1] := #0;
    Exit;
  end;

  Digits := 0;
  while Value > 0 do
  begin
    Temp[Digits] := Char(48 + (Value mod 10));
    Value := Value div 10;
    Inc(Digits);
  end;

  // Ters �evirip Buffer'a yaz
  j := 0;
  for i := Digits - 1 downto 0 do
  begin
    Buffer[j] := Temp[i];
    Inc(j);
  end;
  Buffer[j] := #0;
end;


function Random(MaxRand: Integer): Integer;  OverLoad;
begin
  Rand := Rand * 1103515245 + 12345;
  Result := abs((Rand div 65536) mod MaxRand);
end;

function Random(MinRand, MaxRand: Integer): Integer; OverLoad;
begin
  Rand := Rand * 1103515245 + 12345;
  Result := MinRand + abs((Rand div 65536) mod (MaxRand - MinRand + 1));
end;


function Rect(Left, Top, Right, Bottom: Integer): TRect;
begin
  Result.Left := Left;
  Result.Top := Top;
  Result.Bottom := Bottom;
  Result.Right := Right;
end;




function PtInRect(X, Y, AX, AY, AWidth, AHeight: Integer): Boolean; OverLoad;
begin
  Result := (X >= AX) and (X <= AX + AWidth) and
            (Y >= AY) and (Y <= AY + AHeight);
end;


function PtInRect(const Rect: TRect; const X, Y: Integer): Boolean; OverLoad;
begin
  Result := (X >= Rect.Left) and (X < Rect.Right) and (Y >= Rect.Top)
    and (Y < Rect.Bottom);
end;

function Bounds(ALeft, ATop, AWidth, AHeight: Integer): TRect;
begin
  with Result do
  begin
    Left := ALeft;
    Top := ATop;
    Right := ALeft + AWidth;
    Bottom := ATop + AHeight;
  end;
end;


function StrAlloc(len: Integer): PChar;
begin
  Result := MemAlloc(len + 1);
  if Result <> nil then
    FillChar(Result^, len + 1, 0);
end;

procedure StrFree(s: PChar);
begin
  if s <> nil then FreeMem(s);
end;


function StrNew(const S: PChar): PChar;
var
  Len: Integer;
begin
  if S = nil then
    Result := nil
  else
  begin
    Len := StrLen(S) + 1;
    Result := MemAlloc(Len);
    if Result <> nil then
      Move(S^, Result^, Len);
  end;
end;

procedure StrDispose(S: PChar);
begin
  if S <> nil then
    FreeMem(S);
end;


procedure MemSet(P: Pointer; Value: Byte; Size: LongWord);
var
  i: LongWord;
  B: PByte;
begin
  B := PByte(P);
  i := 0;
  while i < Size do
  begin
    B^ := Value;
    Inc(B);
    Inc(i);
  end;
end;

procedure MemCopy(Dest, Src: Pointer; Size: LongWord);
var
  i: LongWord;
  D: PByte;
  S: PByte;
begin
  D := PByte(Dest);
  S := PByte(Src);
  i := 0;
  while i < Size do
  begin
    D^ := S^;
    Inc(D);
    Inc(S);
    Inc(i);
  end;
end;

procedure FillChar(var Dest; count: Integer; Value:Byte);  Overload;
var
  I: Integer;
  P: PChar;
begin
  P := PChar(@Dest);
  for I := count - 1 downto 0 do
    P[I] := Char(Value);
end;

procedure FillChar(var Dest; count: Integer; Value: Char);  Overload;
var
  I: Integer;
  P: PChar;
begin
  P := PChar(@Dest);
  for I := count - 1 downto 0 do
    P[I] := Value;
end;

procedure CopyMemory(Destination, Source:Pointer; dwSize:LongWord);
asm
  PUSH ECX
  PUSH ESI
  PUSH EDI
  MOV EDI, Destination
  MOV ESI, Source
  MOV ECX, dwSize
  REP MOVSB
  POP EDI
  POP ESI
  POP ECX
end;

procedure Move(const Source; var Dest; count: Integer);
var
  S, D: PChar;
  I: Integer;
begin
  S := PChar(@Source);
  D := PChar(@Dest);
  if S = D then
    Exit;
  if Cardinal(D) > Cardinal(S) then
    for I := count - 1 downto 0 do
      D[I] := S[I]
  else
    for I := 0 to count - 1 do
      D[I] := S[I];
end;


//=============================================================================
// Char Yardımcıları (impl önce — diğerleri kullanır)
//=============================================================================

function Chr_IsDigit(Ch: Char): Boolean;
begin
  Result := (Ch >= '0') and (Ch <= '9');
end;

function Chr_IsHexDigit(Ch: Char): Boolean;
begin
  Result := ((Ch >= '0') and (Ch <= '9')) or
            ((Ch >= 'A') and (Ch <= 'F')) or
            ((Ch >= 'a') and (Ch <= 'f'));
end;

function Chr_IsAlpha(Ch: Char): Boolean;
begin
  Result := ((Ch >= 'A') and (Ch <= 'Z')) or
            ((Ch >= 'a') and (Ch <= 'z'));
end;

function Chr_IsAlNum(Ch: Char): Boolean;
begin
  Result := Chr_IsAlpha(Ch) or Chr_IsDigit(Ch);
end;

function Chr_IsSpace(Ch: Char): Boolean;
begin
  Result := (Ch = ' ') or (Ch = #9) or (Ch = #13) or
            (Ch = #10) or (Ch = #12) or (Ch = #11);
end;

function Chr_IsUpper(Ch: Char): Boolean;
begin
  Result := (Ch >= 'A') and (Ch <= 'Z');
end;

function Chr_IsLower(Ch: Char): Boolean;
begin
  Result := (Ch >= 'a') and (Ch <= 'z');
end;

function Chr_IsPrint(Ch: Char): Boolean;
begin
  Result := (Ord(Ch) >= 32) and (Ord(Ch) <= 126);
end;

function Chr_HexVal(Ch: Char): Byte;
begin
  if (Ch >= '0') and (Ch <= '9') then Result := Ord(Ch) - Ord('0')
  else if (Ch >= 'A') and (Ch <= 'F') then Result := Ord(Ch) - Ord('A') + 10
  else if (Ch >= 'a') and (Ch <= 'f') then Result := Ord(Ch) - Ord('a') + 10
  else Result := 0;
end;

function StrToUpper(Ch: Char): Char;
begin
  if Chr_IsLower(Ch) then
    Result := Char(Ord(Ch) - 32)
  else
    Result := Ch;
end;

function StrToLower(Ch: Char): Char;
begin
  if Chr_IsUpper(Ch) then
    Result := Char(Ord(Ch) + 32)
  else
    Result := Ch;
end;

function UpChar( ch : Char ) : Char;
begin
  Result := ch;
  case Result of
    'a'..'z':  Dec(Result, Ord('a') - Ord('A'));
  end;
end;


function UpCase(Str: PChar): PChar;
var
  r: cardinal;
begin
  result := Str;
  for r := 0 to StrLen(result) do
    if result[r] in ['a'..'z'] then
      Dec(result[r], Ord('a') - Ord('A'));

end;


//=============================================================================
// Uzunluk
//=============================================================================

function StrLen(S: PChar): Integer;
begin
  Result := 0;
  if S = nil then Exit;
  while S[Result] <> #0 do Inc(Result);
end;

function StrSize(S: PChar): Integer;
begin
  Result := StrLen(S) + 1;
end;

//=============================================================================
// Kopyalama / Ekleme
//=============================================================================

function StrLComp(const Str1, Str2: PChar; MaxLen: Cardinal): Integer; assembler;
asm
        PUSH    EDI
        PUSH    ESI
        PUSH    EBX
        MOV     EDI,EDX
        MOV     ESI,EAX
        MOV     EBX,ECX
        XOR     EAX,EAX
        OR      ECX,ECX
        JE      @@1
        REPNE   SCASB
        SUB     EBX,ECX
        MOV     ECX,EBX
        MOV     EDI,EDX
        XOR     EDX,EDX
        REPE    CMPSB
        MOV     AL,[ESI-1]
        MOV     DL,[EDI-1]
        SUB     EAX,EDX
@@1:    POP     EBX
        POP     ESI
        POP     EDI
end;


function StrLCopy(Dest: PChar; const Source: PChar; MaxLen: Cardinal): PChar; assembler;
asm
        PUSH    EDI
        PUSH    ESI
        PUSH    EBX
        MOV     ESI,EAX
        MOV     EDI,EDX
        MOV     EBX,ECX
        XOR     AL,AL
        TEST    ECX,ECX
        JZ      @@1
        REPNE   SCASB
        JNE     @@1
        INC     ECX
@@1:    SUB     EBX,ECX
        MOV     EDI,ESI
        MOV     ESI,EDX
        MOV     EDX,EDI
        MOV     ECX,EBX
        SHR     ECX,2
        REP     MOVSD
        MOV     ECX,EBX
        AND     ECX,3
        REP     MOVSB
        STOSB
        MOV     EAX,EDX
        POP     EBX
        POP     ESI
        POP     EDI
end;


procedure StrCopy(Dest, Src: PChar);
var
  i: Integer;
begin
  if (Dest = nil) or (Src = nil) then Exit;
  i := 0;
  while Src[i] <> #0 do
  begin
    Dest[i] := Src[i];
    Inc(i);
  end;
  Dest[i] := #0;
end;

procedure StrCopyN(Dest, Src: PChar; N: Integer);
var
  i: Integer;
begin
  if (Dest = nil) or (Src = nil) or (N <= 0) then Exit;
  i := 0;
  while (Src[i] <> #0) and (i < N) do
  begin
    Dest[i] := Src[i];
    Inc(i);
  end;
  Dest[i] := #0;
end;


procedure StrCat(Dest, Src: PChar);
var
  i, j: Integer;
begin
  if (Dest = nil) or (Src = nil) then Exit;
  i := StrLen(Dest);
  j := 0;
  while Src[j] <> #0 do
  begin
    Dest[i] := Src[j];
    Inc(i); Inc(j);
  end;
  Dest[i] := #0;
end;

procedure StrAppend(Dest, Src: PChar);
var
  i, j: Integer;
begin
  if (Dest = nil) or (Src = nil) then Exit;
  i := StrLen(Dest);
  j := 0;
  while Src[j] <> #0 do
  begin
    Dest[i] := Src[j];
    Inc(i); Inc(j);
  end;
  Dest[i] := #0;
end;

procedure StrAppendN(Dest, Src: PChar; N: Integer);
var
  i, j: Integer;
begin
  if (Dest = nil) or (Src = nil) or (N <= 0) then Exit;
  i := StrLen(Dest);
  j := 0;
  while (Src[j] <> #0) and (j < N) do
  begin
    Dest[i] := Src[j];
    Inc(i); Inc(j);
  end;
  Dest[i] := #0;
end;

procedure StrAppendChar(Dest: PChar; Ch: Char);
var
  i: Integer;
begin
  if Dest = nil then Exit;
  i := StrLen(Dest);
  Dest[i]   := Ch;
  Dest[i+1] := #0;
end;

//=============================================================================
// Karşılaştırma
//=============================================================================

function StrCmp(S1, S2: PChar): Integer;
var
  i: Integer;
begin
  Result := 0;
  if (S1 = nil) and (S2 = nil) then Exit;
  if S1 = nil then begin Result := -1; Exit; end;
  if S2 = nil then begin Result :=  1; Exit; end;
  i := 0;
  while (S1[i] <> #0) and (S2[i] <> #0) do
  begin
    if S1[i] <> S2[i] then
    begin
      Result := Ord(S1[i]) - Ord(S2[i]);
      Exit;
    end;
    Inc(i);
  end;
  Result := Ord(S1[i]) - Ord(S2[i]);
end;



function StrCmpI(S1, S2: PChar): Integer; OverLoad;
var
  i:   Integer;
  c1, c2: Char;
begin
  Result := 0;
  if (S1 = nil) and (S2 = nil) then Exit;
  if S1 = nil then begin Result := -1; Exit; end;
  if S2 = nil then begin Result :=  1; Exit; end;
  i := 0;
  while (S1[i] <> #0) and (S2[i] <> #0) do
  begin
    c1 := StrToUpper(S1[i]);
    c2 := StrToUpper(S2[i]);
    if c1 <> c2 then
    begin
      Result := Ord(c1) - Ord(c2);
      Exit;
    end;
    Inc(i);
  end;
  Result := Ord(StrToUpper(S1[i])) - Ord(StrToUpper(S2[i]));
end;

function StrCmpN(S1, S2: PChar; N: Integer): Integer;
var
  i: Integer;
begin
  Result := 0;
  if N <= 0 then Exit;
  i := 0;
  while (i < N) and (S1[i] <> #0) and (S2[i] <> #0) do
  begin
    if S1[i] <> S2[i] then
    begin
      Result := Ord(S1[i]) - Ord(S2[i]);
      Exit;
    end;
    Inc(i);
  end;
  if i < N then
    Result := Ord(S1[i]) - Ord(S2[i]);
end;

function StrCmpNI(S1, S2: PChar; N: Integer): Integer;
var
  i:   Integer;
  c1, c2: Char;
begin
  Result := 0;
  if N <= 0 then Exit;
  i := 0;
  while (i < N) and (S1[i] <> #0) and (S2[i] <> #0) do
  begin
    c1 := StrToUpper(S1[i]);
    c2 := StrToUpper(S2[i]);
    if c1 <> c2 then
    begin
      Result := Ord(c1) - Ord(c2);
      Exit;
    end;
    Inc(i);
  end;
  if i < N then
    Result := Ord(StrToUpper(S1[i])) - Ord(StrToUpper(S2[i]));
end;

function StrEqual(S1, S2: PChar): Boolean;
begin
  Result := StrCmp(S1, S2) = 0;
end;

function StrEqualI(S1, S2: PChar): Boolean;
begin
  Result := StrCmpI(S1, S2) = 0;
end;

//=============================================================================
// Arama
//=============================================================================

function StrPos(Haystack, Needle: PChar): Integer;
var
  hLen, nLen: Integer;
  i, j:       Integer;
begin
  Result := -1;
  if (Haystack = nil) or (Needle = nil) then Exit;
  hLen := StrLen(Haystack);
  nLen := StrLen(Needle);
  if (nLen = 0) or (nLen > hLen) then Exit;

  i := 0;
  while i <= hLen - nLen do
  begin
    j := 0;
    while (j < nLen) and (Haystack[i+j] = Needle[j]) do Inc(j);
    if j = nLen then begin Result := i; Exit; end;
    Inc(i);
  end;
end;

function StrPosI(Haystack, Needle: PChar): Integer;
var
  hLen, nLen: Integer;
  i, j:       Integer;
begin
  Result := -1;
  if (Haystack = nil) or (Needle = nil) then Exit;
  hLen := StrLen(Haystack);
  nLen := StrLen(Needle);
  if (nLen = 0) or (nLen > hLen) then Exit;

  i := 0;
  while i <= hLen - nLen do
  begin
    j := 0;
    while (j < nLen) and
          (StrToUpper(Haystack[i+j]) = StrToUpper(Needle[j])) do Inc(j);
    if j = nLen then begin Result := i; Exit; end;
    Inc(i);
  end;
end;

function StrRPos(Haystack, Needle: PChar): Integer;
var
  hLen, nLen: Integer;
  i, j:       Integer;
begin
  Result := -1;
  if (Haystack = nil) or (Needle = nil) then Exit;
  hLen := StrLen(Haystack);
  nLen := StrLen(Needle);
  if (nLen = 0) or (nLen > hLen) then Exit;

  i := hLen - nLen;
  while i >= 0 do
  begin
    j := 0;
    while (j < nLen) and (Haystack[i+j] = Needle[j]) do Inc(j);
    if j = nLen then begin Result := i; Exit; end;
    Dec(i);
  end;
end;

function StrChr(S: PChar; Ch: Char): PChar;
begin
  Result := nil;
  if S = nil then Exit;
  while S^ <> #0 do
  begin
    if S^ = Ch then begin Result := S; Exit; end;
    Inc(S);
  end;
end;

function StrRChr(S: PChar; Ch: Char): PChar;
var
  last: PChar;
begin
  Result := nil;
  last   := nil;
  if S = nil then Exit;
  while S^ <> #0 do
  begin
    if S^ = Ch then last := S;
    Inc(S);
  end;
  Result := last;
end;

function StrIndexOf(S: PChar; Ch: Char): Integer;
var
  i: Integer;
begin
  Result := -1;
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    if S[i] = Ch then begin Result := i; Exit; end;
    Inc(i);
  end;
end;

function StrLastIndexOf(S: PChar; Ch: Char): Integer;
var
  i, last: Integer;
begin
  Result := -1;
  last   := -1;
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    if S[i] = Ch then last := i;
    Inc(i);
  end;
  Result := last;
end;

//=============================================================================
// Dönüşüm
//=============================================================================

procedure StrUpper(S: PChar);
var
  i: Integer;
begin
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    S[i] := StrToUpper(S[i]);
    Inc(i);
  end;
end;

function StrUpChar( ch : Char ) : Char;
begin
  Result := ch;
  case Result of
    'a'..'z':  Dec(Result, Ord('a') - Ord('A'));
  end;
end;


procedure StrLower(S: PChar);
var
  i: Integer;
begin
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    S[i] := StrToLower(S[i]);
    Inc(i);
  end;
end;

procedure StrTrimL(S: PChar);
var
  i, j: Integer;
begin
  if S = nil then Exit;
  i := 0;
  while Chr_IsSpace(S[i]) do Inc(i);
  if i = 0 then Exit;
  j := 0;
  while S[i] <> #0 do
  begin
    S[j] := S[i];
    Inc(i); Inc(j);
  end;
  S[j] := #0;
end;

procedure StrTrimR(S: PChar);
var
  i: Integer;
begin
  if S = nil then Exit;
  i := StrLen(S) - 1;
  while (i >= 0) and Chr_IsSpace(S[i]) do
  begin
    S[i] := #0;
    Dec(i);
  end;
end;

procedure StrTrim(S: PChar);
begin
  StrTrimR(S);
  StrTrimL(S);
end;

procedure StrReverse(S: PChar);
var
  i, j: Integer;
  t:    Char;
begin
  if S = nil then Exit;
  i := 0;
  j := StrLen(S) - 1;
  while i < j do
  begin
    t := S[i]; S[i] := S[j]; S[j] := t;
    Inc(i); Dec(j);
  end;
end;

//=============================================================================
// Kontrol
//=============================================================================

function StrIsEmpty(S: PChar): Boolean;
begin
  Result := (S = nil) or (S[0] = #0);
end;

function StrIsBlank(S: PChar): Boolean;
var
  i: Integer;
begin
  Result := True;
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    if not Chr_IsSpace(S[i]) then begin Result := False; Exit; end;
    Inc(i);
  end;
end;

function StrStartsWith(S, Prefix: PChar): Boolean;
var
  pLen: Integer;
begin
  pLen := StrLen(Prefix);
  Result := StrCmpN(S, Prefix, pLen) = 0;
end;

function StrStartsWithI(S, Prefix: PChar): Boolean;
var
  pLen: Integer;
begin
  pLen := StrLen(Prefix);
  Result := StrCmpNI(S, Prefix, pLen) = 0;
end;

function StrEndsWith(S, Suffix: PChar): Boolean;
var
  sLen, sfLen: Integer;
begin
  Result := False;
  sLen  := StrLen(S);
  sfLen := StrLen(Suffix);
  if sfLen > sLen then Exit;
  Result := StrCmpN(@S[sLen - sfLen], Suffix, sfLen) = 0;
end;

function StrEndsWithI(S, Suffix: PChar): Boolean;
var
  sLen, sfLen: Integer;
begin
  Result := False;
  sLen  := StrLen(S);
  sfLen := StrLen(Suffix);
  if sfLen > sLen then Exit;
  Result := StrCmpNI(@S[sLen - sfLen], Suffix, sfLen) = 0;
end;

function StrContains(Haystack, Needle: PChar): Boolean;
begin
  Result := StrPos(Haystack, Needle) >= 0;
end;

function StrContainsI(Haystack, Needle: PChar): Boolean;
begin
  Result := StrPosI(Haystack, Needle) >= 0;
end;

function StrIsNumeric(S: PChar): Boolean;
var
  i:       Integer;
  hasDot:  Boolean;
  hasSign: Boolean;
begin
  Result  := False;
  hasDot  := False;
  hasSign := False;
  if StrIsEmpty(S) then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    if (S[i] = '+') or (S[i] = '-') then
    begin
      if hasSign or (i > 0) then Exit;
      hasSign := True;
    end
    else if S[i] = '.' then
    begin
      if hasDot then Exit;
      hasDot := True;
    end
    else if not Chr_IsDigit(S[i]) then
      Exit;
    Inc(i);
  end;
  Result := i > 0;
end;

function StrIsAlpha(S: PChar): Boolean;
var
  i: Integer;
begin
  Result := False;
  if StrIsEmpty(S) then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    if not Chr_IsAlpha(S[i]) then Exit;
    Inc(i);
  end;
  Result := True;
end;

function StrIsAlNum(S: PChar): Boolean;
var
  i: Integer;
begin
  Result := False;
  if StrIsEmpty(S) then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    if not Chr_IsAlNum(S[i]) then Exit;
    Inc(i);
  end;
  Result := True;
end;

//=============================================================================
// Alt String
//=============================================================================

procedure StrLeft(Dest, Src: PChar; N: Integer);
begin
  StrCopyN(Dest, Src, N);
end;

procedure StrRight(Dest, Src: PChar; N: Integer);
var
  len: Integer;
begin
  len := StrLen(Src);
  if N >= len then
    StrCopy(Dest, Src)
  else
    StrCopy(Dest, @Src[len - N]);
end;

procedure StrMid(Dest, Src: PChar; Start, Len: Integer);
var
  sLen: Integer;
begin
  sLen := StrLen(Src);
  if Start >= sLen then begin Dest[0] := #0; Exit; end;
  if Start + Len > sLen then Len := sLen - Start;
  StrCopyN(Dest, @Src[Start], Len);
end;

function StrToken(Src: PChar; Delim: Char; var Pos: Integer;
                   Dest: PChar): Boolean;
var
  start: Integer;
begin
  Result := False;
  if Src = nil then Exit;

  // Başa boş delimiterleri atla
  while (Src[Pos] <> #0) and (Src[Pos] = Delim) do Inc(Pos);
  if Src[Pos] = #0 then Exit;

  start := Pos;
  while (Src[Pos] <> #0) and (Src[Pos] <> Delim) do Inc(Pos);

  StrMid(Dest, Src, start, Pos - start);
  if Src[Pos] = Delim then Inc(Pos);
  Result := True;
end;

function StrSplit(Src: PChar; Delim: Char;
                    Tokens:array of PChar; MaxTokens: Integer): Integer;
var
  pos:    Integer;
  buf:    array[0..255] of Char;
  count:  Integer;
begin
  Result := 0;
  count  := 0;
  pos    := 0;

  while StrToken(Src, Delim, pos, @buf[0]) and (count < MaxTokens) do
  begin
    if Tokens[count] <> nil then
      StrCopy(Tokens[count], @buf[0]);
    Inc(count);
  end;

  Result := count;
end;

//=============================================================================
// Sayı Dönüşümleri
//=============================================================================

procedure StrIntToStr(Val: Integer; Buf: PChar);
var
  tmp: array[0..19] of Char;
  d:   Integer;
  len: Integer;
  neg: Boolean;
begin
  neg := Val < 0;
  if neg then Val := -Val;

  d := 0;
  if Val = 0 then
  begin
    Buf[0] := '0'; Buf[1] := #0;
    Exit;
  end;

  while Val > 0 do
  begin
    tmp[d] := Char(Ord('0') + (Val mod 10));
    Inc(d);
    Val := Val div 10;
  end;

  len := 0;
  if neg then begin Buf[len] := '-'; Inc(len); end;
  while d > 0 do
  begin
    Dec(d);
    Buf[len] := tmp[d];
    Inc(len);
  end;
  Buf[len] := #0;
end;

procedure StrUIntToStr(Val: LongWord; Buf: PChar);
var
  tmp: array[0..19] of Char;
  d, len: Integer;
begin
  if Val = 0 then begin Buf[0] := '0'; Buf[1] := #0; Exit; end;
  d := 0;
  while Val > 0 do
  begin
    tmp[d] := Char(Ord('0') + Integer(Val mod 10));
    Inc(d);
    Val := Val div 10;
  end;
  len := 0;
  while d > 0 do
  begin
    Dec(d);
    Buf[len] := tmp[d];
    Inc(len);
  end;
  Buf[len] := #0;
end;

function StrToInt(S: PChar): Integer;
var
  i:   Integer;
  neg: Boolean;
begin
  Result := 0;
  if S = nil then Exit;
  i   := 0;
  neg := False;

  while Chr_IsSpace(S[i]) do Inc(i);

  if S[i] = '-' then begin neg := True; Inc(i); end
  else if S[i] = '+' then Inc(i);

  while Chr_IsDigit(S[i]) do
  begin
    Result := Result * 10 + (Ord(S[i]) - Ord('0'));
    Inc(i);
  end;

  if neg then Result := -Result;
end;

function StrToIntDef(S: PChar; Default: Integer): Integer;
begin
  if StrIsEmpty(S) or not StrIsNumeric(S) then
    Result := Default
  else
    Result := StrToInt(S);
end;

function StrTryToInt(S: PChar; var Val: Integer): Boolean;
begin
  Result := not StrIsEmpty(S) and StrIsNumeric(S);
  if Result then Val := StrToInt(S);
end;
{
procedure StrInt64ToStr(Val: Int64; Buf: PChar);
var
  tmp: array[0..22] of Char;
  d, len: Integer;
  neg:    Boolean;
begin
  neg := Val < 0;
  if neg then Val := -Val;

  if Val = 0 then begin Buf[0] := '0'; Buf[1] := #0; Exit; end;

  d := 0;
  while Val > 0 do
  begin
    tmp[d] := Char(Ord('0') + Integer(Val mod 10));
    Inc(d);
    Val := Val div 10;
  end;

  len := 0;
  if neg then begin Buf[len] := '-'; Inc(len); end;
  while d > 0 do
  begin
    Dec(d);
    Buf[len] := tmp[d];
    Inc(len);
  end;
  Buf[len] := #0;
end;

procedure StrFloatToStr(Val: Single; Decimals: Integer; Buf: PChar);
var
  intPart:  Integer;
  fracPart: Integer;
  factor:   Integer;
  i:        Integer;
  neg:      Boolean;
  tmp:      array[0..31] of Char;
begin
  neg := Val < 0;
  if neg then Val := -Val;

  factor := 1;
  i := 0;
  while i < Decimals do begin factor := factor * 10; Inc(i); end;

  intPart  := Math_Trunc(Val);
  fracPart := Math_Round((Val - intPart) * factor);

  if fracPart >= factor then
  begin
    Inc(intPart);
    fracPart := 0;
  end;

  if neg then
  begin
    Buf[0] := '-';
    StrIntToStr(intPart, @tmp[0]);
    StrCopy(@Buf[1], @tmp[0]);
  end
  else
    StrIntToStr(intPart, Buf);

  if Decimals > 0 then
  begin
    StrAppendChar(Buf, '.');

    // Sıfır pad'li frac
    i := StrLen(Buf);
    Buf[i + Decimals] := #0;
    Dec(Decimals);
    while Decimals >= 0 do
    begin
      Buf[i + Decimals] := Char(Ord('0') + fracPart mod 10);
      fracPart := fracPart div 10;
      Dec(Decimals);
    end;
  end;
end;

function StrToFloat(S: PChar): Single;
var
  i:      Integer;
  neg:    Boolean;
  intP:   Integer;
  fracP:  Single;
  div10:  Single;
begin
  Result := 0;
  if S = nil then Exit;
  i   := 0;
  neg := False;

  while Chr_IsSpace(S[i]) do Inc(i);
  if S[i] = '-' then begin neg := True; Inc(i); end
  else if S[i] = '+' then Inc(i);

  intP := 0;
  while Chr_IsDigit(S[i]) do
  begin
    intP := intP * 10 + (Ord(S[i]) - Ord('0'));
    Inc(i);
  end;

  fracP := 0;
  div10 := 0.1;
  if S[i] = '.' then
  begin
    Inc(i);
    while Chr_IsDigit(S[i]) do
    begin
      fracP := fracP + (Ord(S[i]) - Ord('0')) * div10;
      div10 := div10 * 0.1;
      Inc(i);
    end;
  end;

  Result := intP + fracP;
  if neg then Result := -Result;
end;

function StrTryToFloat(S: PChar; var Val: Single): Boolean;
begin
  Result := not StrIsEmpty(S) and StrIsNumeric(S);
  if Result then Val := StrToFloat(S);
end;  }

//=============================================================================
// Hex
//=============================================================================

const
  HexChars: array[0..15] of Char = '0123456789ABCDEF';

procedure StrIntToHex(Val: LongWord; Digits: Integer; Buf: PChar);
var
  i: Integer;
begin
  if Digits <= 0 then Digits := 8;
  Buf[Digits] := #0;
  i := Digits - 1;
  while i >= 0 do
  begin
    Buf[i] := HexChars[Val and $F];
    Val := Val shr 4;
    Dec(i);
  end;
end;

function StrHexToInt(S: PChar): LongWord;
var
  i: Integer;
begin
  Result := 0;
  if S = nil then Exit;
  i := 0;

  // "0x" veya "0X" prefix
  if (S[0] = '0') and ((S[1] = 'x') or (S[1] = 'X')) then
    Inc(i, 2);

  while Chr_IsHexDigit(S[i]) do
  begin
    Result := (Result shl 4) or Chr_HexVal(S[i]);
    Inc(i);
  end;
end;

procedure StrByteToHex(Val: Byte; Buf: PChar);
begin
  StrIntToHex(Val, 2, Buf);
end;

procedure StrWordToHex(Val: Word; Buf: PChar);
begin
  StrIntToHex(Val, 4, Buf);
end;

procedure StrDWordToHex(Val: LongWord; Buf: PChar);
begin
  StrIntToHex(Val, 8, Buf);
end;

//=============================================================================
// Format / Pad
//=============================================================================

procedure StrFill(Dest: PChar; Ch: Char; Count: Integer);
var
  i: Integer;
begin
  i := 0;
  while i < Count do
  begin
    Dest[i] := Ch;
    Inc(i);
  end;
  Dest[Count] := #0;
end;

procedure StrPadLeft(Dest, Src: PChar; Width: Integer; Fill: Char);
var
  sLen, pad: Integer;
  i:         Integer;
begin
  sLen := StrLen(Src);
  pad  := Width - sLen;
  if pad <= 0 then begin StrCopy(Dest, Src); Exit; end;
  i := 0;
  while i < pad do begin Dest[i] := Fill; Inc(i); end;
  StrCopy(@Dest[pad], Src);
end;

procedure StrPadRight(Dest, Src: PChar; Width: Integer; Fill: Char);
var
  sLen, pad: Integer;
begin
  sLen := StrLen(Src);
  StrCopy(Dest, Src);
  pad := Width - sLen;
  if pad <= 0 then Exit;
  StrFill(@Dest[sLen], Fill, pad);
end;

procedure StrCenter(Dest, Src: PChar; Width: Integer; Fill: Char);
var
  sLen, total, left, right: Integer;
begin
  sLen  := StrLen(Src);
  total := Width - sLen;
  if total <= 0 then begin StrCopy(Dest, Src); Exit; end;
  left  := total div 2;
  right := total - left;
  StrFill(Dest, Fill, left);
  StrCopy(@Dest[left], Src);
  StrFill(@Dest[left + sLen], Fill, right);
end;

procedure StrRepeat(Dest, Src: PChar; Count: Integer);
var
  sLen, i: Integer;
begin
  sLen := StrLen(Src);
  i    := 0;
  while i < Count do
  begin
    StrCopy(@Dest[i * sLen], Src);
    Inc(i);
  end;
  Dest[Count * sLen] := #0;
end;

function StrCountChar(S: PChar; Ch: Char): Integer;
var
  i: Integer;
begin
  Result := 0;
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    if S[i] = Ch then Inc(Result);
    Inc(i);
  end;
end;

function StrWordCount(S: PChar): Integer;
var
  i:      Integer;
  inWord: Boolean;
begin
  Result := 0;
  if S = nil then Exit;
  i      := 0;
  inWord := False;
  while S[i] <> #0 do
  begin
    if Chr_IsSpace(S[i]) then
      inWord := False
    else
    begin
      if not inWord then Inc(Result);
      inWord := True;
    end;
    Inc(i);
  end;
end;

//=============================================================================
// Değiştirme
//=============================================================================

function StrReplace(Src, Find, Repl, Dest: PChar; MaxLen: Integer): Integer;
var
  fLen, rLen, sLen: Integer;
  i, j, d:          Integer;
begin
  Result := 0;
  fLen   := StrLen(Find);
  rLen   := StrLen(Repl);
  sLen   := StrLen(Src);
  i      := 0;
  d      := 0;

  if fLen = 0 then
  begin
    StrCopyN(Dest, Src, MaxLen - 1);
    Exit;
  end;

  while (i <= sLen - fLen) and (d < MaxLen - 1) do
  begin
    if StrCmpN(@Src[i], Find, fLen) = 0 then
    begin
      j := 0;
      while (j < rLen) and (d < MaxLen - 1) do
      begin
        Dest[d] := Repl[j];
        Inc(d); Inc(j);
      end;
      Inc(i, fLen);
      Inc(Result);
    end
    else
    begin
      Dest[d] := Src[i];
      Inc(d); Inc(i);
    end;
  end;

  // Kalan karakterler
  while (i < sLen) and (d < MaxLen - 1) do
  begin
    Dest[d] := Src[i];
    Inc(d); Inc(i);
  end;
  Dest[d] := #0;
end;

procedure StrDeleteAt(S: PChar; Start, Count: Integer);
var
  sLen, i: Integer;
begin
  sLen := StrLen(S);
  if Start >= sLen then Exit;
  if Start + Count > sLen then Count := sLen - Start;
  i := Start;
  while i + Count <= sLen do
  begin
    S[i] := S[i + Count];
    Inc(i);
  end;
end;

procedure StrInsert(S, Sub: PChar; Pos: Integer; MaxLen: Integer);
var
  sLen, subLen: Integer;
  i:            Integer;
begin
  sLen   := StrLen(S);
  subLen := StrLen(Sub);

  if Pos > sLen then Pos := sLen;
  if sLen + subLen >= MaxLen then Exit;

  // Sağa kaydır
  i := sLen;
  while i >= Pos do
  begin
    S[i + subLen] := S[i];
    Dec(i);
  end;

  // Sub'u yerleştir
  i := 0;
  while i < subLen do
  begin
    S[Pos + i] := Sub[i];
    Inc(i);
  end;
end;

//=============================================================================
// Çeşitli
//=============================================================================

procedure StrFromChar(Dest: PChar; Ch: Char);
begin
  Dest[0] := Ch;
  Dest[1] := #0;
end;

procedure StrConcat(Dest, S1, S2: PChar);
begin
  StrCopy(Dest, S1);
  StrAppend(Dest, S2);
end;

function StrHashDJB2(S: PChar): LongWord;
var
  i: Integer;
begin
  Result := 5381;
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    Result := ((Result shl 5) + Result) + Ord(S[i]);
    Inc(i);
  end;
end;

function StrHashFNV1A(S: PChar): LongWord;
var
  i: Integer;
begin
  Result := $811C9DC5;
  if S = nil then Exit;
  i := 0;
  while S[i] <> #0 do
  begin
    Result := Result xor LongWord(Ord(S[i]));
    Result := Result * $01000193;
    Inc(i);
  end;
end;

end.

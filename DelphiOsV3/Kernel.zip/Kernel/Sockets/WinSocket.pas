unit WinSocket;

{ =========================================================
  WinSocket.pas — TCP/IP Stack Unit (FULL VERSION)

  Özellikler:
  - TCP/UDP Socket API (Berkeley-style)
  - TCP State Machine (3-way handshake, close)
  - Circular Receive Buffer (4096 bytes)
  - DHCP Client (UDP tabanlı)
  - DNS Query Client (UDP tabanlı)
  - ARP, IP, TCP, UDP Packet Processing
  - Checksum hesaplama (IP/TCP/UDP)
  - Byte Order dönüşümleri (htons, htonl, ntohs, ntohl)
  ========================================================= }



interface

uses
  SysUtils,Memory,Pit,Messages;

{=============================================================================
  CONSTANTS
=============================================================================}

const
  // Address families
  AF_INET = 2;

  // Socket types
  SOCK_STREAM = 1;
  SOCK_DGRAM  = 2;

  // Protocols
  IPPROTO_TCP = 6;
  IPPROTO_UDP = 17;

  // Error
  SOCKET_ERROR = -1;

  // Buffer
  MAX_RECV_BUFFER = 4096;

  // TCP flags
  TCP_FLAG_FIN = $01;
  TCP_FLAG_SYN = $02;
  TCP_FLAG_RST = $04;
  TCP_FLAG_PSH = $08;
  TCP_FLAG_ACK = $10;
  TCP_FLAG_URG = $20;

  // Header sizes
  ETH_HEADER_SIZE  = 14;
  IP_HEADER_SIZE   = 20;
  TCP_HEADER_SIZE  = 20;
  UDP_HEADER_SIZE  = 8;
  MaxPacketSize    = 1514;

  // DHCP
  BOOTPC_PORT = 68;
  BOOTPS_PORT = 67;
  BROADCAST_IP = $FFFFFFFF;

  DHCP_MAGIC_COOKIE_0 = 99;
  DHCP_MAGIC_COOKIE_1 = 130;
  DHCP_MAGIC_COOKIE_2 = 83;
  DHCP_MAGIC_COOKIE_3 = 99;

  DHCP_OPTION_MSG_TYPE = 53;
  DHCP_OPTION_REQ_LIST = 55;
  DHCP_OPTION_SUBNET   = 1;
  DHCP_OPTION_ROUTER   = 3;
  DHCP_OPTION_DNS      = 6;
  DHCP_OPTION_DOMAIN   = 15;
  DHCP_OPTION_SERVERID = 54;
  DHCP_OPTION_END      = 255;
  DHCP_OPTION_PAD      = 0;

  DHCP_MSG_DISCOVER = 1;
  DHCP_MSG_OFFER    = 2;
  DHCP_MSG_REQUEST  = 3;
  DHCP_MSG_ACK      = 5;




{=============================================================================
  TYPES
=============================================================================}

type
  { TCP Connection States }
  TTCPState = (
    SS_CLOSED,
    SS_LISTEN,
    SS_SYN_SENT,
    SS_SYN_RECEIVED,
    SS_ESTABLISHED,
    SS_FIN_WAIT_1,
    SS_FIN_WAIT_2,
    SS_CLOSE_WAIT,
    SS_CLOSING,
    SS_LAST_ACK,
    SS_TIME_WAIT
  );



  type
  TMacAddress = array[0..5] of Byte;
  TIPAddress = array[0..3] of Byte;

type

  PArpPacket=^TArpPacket;
  TArpPacket = packed record
    HardwareType: Word;
    ProtocolType: Word;
    HardwareSize: Byte;
    ProtocolSize: Byte;
    Opcode: Word;
    SrcMAC: array[0..5] of Byte;
    SrcIP: array[0..3] of Byte;
    DstMAC: array[0..5] of Byte;
    DstIP: array[0..3] of Byte;
  end;

  TArpTableEntry = record
    IpAddr: TIPAddress;
    MacAddr: TMacAddress;
  end;


  { Ethernet Header }
  TEthernetHeader = packed record
    DstMAC: array[0..5] of Byte;
    SrcMAC: array[0..5] of Byte;
    EthType: Word;
  end;

  { IP Header }
  TIPHeader = packed record
    VerIHL: Byte;
    TOS: Byte;
    TotalLength: Word;
    ID: Word;
    FlagsFragment: Word;
    TTL: Byte;
    Protocol: Byte;
    HeaderChecksum: Word;
    SrcIP: LongWord;
    DestIP: LongWord;
  end;

  { TCP Header }
  TTCPHeader = packed record
    SrcPort: Word;
    DestPort: Word;
    SeqNum: LongWord;
    AckNum: LongWord;
    DataOffset: Byte;
    Flags: Byte;
    Window: Word;
    Checksum: Word;
    UrgentPtr: Word;
  end;

  { UDP Header }
  TUDPHeader = packed record
    SrcPort: Word;
    DestPort: Word;
    Length: Word;
    Checksum: Word;
  end;


  TSocketType = (SOCK_STREAM_TYPE, SOCK_DGRAM_TYPE);
  TSocketProtocol = (IPPROTO_TCP_TYPE, IPPROTO_UDP_TYPE);

  { Socket Address }
  PSocketAddr = ^TSocketAddr;
  TSocketAddr = packed record
    sin_family: Word;
    sin_port: Word;
    sin_addr: LongWord;
  end;


  { Socket Structure }
  PSocket = ^TSocket;
  TSocket = record
    LocalAddr: LongWord;
    LocalPort: Word;
    RemoteAddr: LongWord;
    RemotePort: Word;
    SeqNum: LongWord;
    AckNum: LongWord;
    State: TTCPState;
    SocketType: TSocketType;
    SocketProtocol: TSocketProtocol;

    // Receive Buffer (Circular)
    RecvBuffer: array[0..MAX_RECV_BUFFER-1] of Byte;
    RecvHead: Integer;
    RecvTail: Integer;
    RecvCount: Integer;

    Next, Prev: PSocket;
  end;

  { DHCP Message }
  TDHCPMessage = packed record
    op, htype, hlen, hops: Byte;
    xid: LongWord;
    secs, flags: Word;
    ciaddr, yiaddr, siaddr, giaddr: LongWord;
    chaddr: array[0..15] of Byte;
    sname: array[0..63] of Byte;
    file_: array[0..127] of Byte;
    options: array[0..311] of Byte;
  end;


  type
  PDNSHeader=^TDNSHeader;
  TDNSHeader = record
    ID: Word; // Sorgu kimli i
    Flags: Word; // Bayraklar (sorgu: $0100)
    QDCount: Word; // Soru say s 
    ANCount: Word; // Yan t say s 
    NSCount: Word; // Yetki say s 
    ARCount: Word; // Ek kay t say s 
  end;





  TDNSAnswer = packed record
    Name: array[0..255] of Char;  // Alan ad�
    AType: Word;                  // 1=A, 5=CNAME, vb.
    AClass: Word;                   // 1=IN
    TTL: Cardinal;
    RDLength: Word;
    IP: Cardinal;                 // A kayd� i�in IP (network byte order)
  end;

 { PByteArray = ^TByteArray;
  TByteArray = array[0..MaxInt-1] of Byte;}

{=============================================================================
  GLOBAL VARIABLES
=============================================================================}

var
  SocketList: PSocket=nil;
  gDhcpXID: LongWord=0;

  SERVER_IP:PChar= '10.0.2.15';
  DHCP_IP:PChar='8.8.8.8';

{=============================================================================
  NETWORK / HARDWARE STUBS (User must implement or link)
=============================================================================}


function  Rand(Max: LongWord): LongWord;

{=============================================================================
  UTILITY FUNCTIONS
=============================================================================}

function  inet_addr(ip: PChar): LongWord;
procedure IPToPChar(IP: LongWord; Buffer: PChar; BufSize: Integer);
procedure IPToPCharSimple(IP: LongWord; Buffer: PChar; BufSize: Integer);
//function  IntToPChar(Value: LongWord): PChar;

{=============================================================================
  BYTE ORDER
=============================================================================}

function  htons(hostshort: Word): Word;
function  ntohs(netshort: Word): Word;
function  htonl(hostlong: LongWord): LongWord;
function  ntohl(netlong: LongWord): LongWord;

{=============================================================================
  CHECKSUM
=============================================================================}

function  CalcChecksum(Data: PWord; Length: Integer): Word;
function  TCPChecksum(SourceIP, DestIP: LongWord;
                       var TCPHeader: TTCPHeader;
                       TCPData: PByte; DataLen: Integer): Word;
function  UDPChecksum(SourceIP, DestIP: LongWord;
                       UDPHeader: TUDPHeader;
                       UDPData: PByte; DataLen: Integer): Word;

{=============================================================================
  PACKET SENDERS
=============================================================================}

procedure SendTCPPacket(srcIP, destIP: LongWord; srcPort, destPort: Word;
                        seqNum, ackNum: LongWord; flags: Byte;
                        data: PByteArray; dataLen: Integer);
procedure SendUDPPacket(srcIP, destIP: LongWord; srcPort, destPort: Word;
                        data: PByteArray; size: Integer);

{=============================================================================
  SOCKET MANAGEMENT
=============================================================================}

function  AllocSocket: PSocket;
procedure FreeSocket(Sock: PSocket);
function  FindSocketByAddr(LocalPort, RemotePort: Word;
                           RemoteAddr: LongWord): PSocket;
function  FindListenSocket(LocalPort: Word): PSocket;

{=============================================================================
  BERKELEY SOCKET API
=============================================================================}

function  socket(domain: Word; socketType: Integer; socketProtocol: Integer): PSocket;
function  bind(sockfd: PSocket; addr: TSocketAddr; addrlen: Integer): Integer;
function  listen(sockfd: PSocket; backlog: Integer): Integer;
function  connect(sockfd: PSocket; addr: TSocketAddr; addrlen: Integer): Integer;
function  accept(sockfd: PSocket; addr: PSocketAddr; addrlen: PInteger): PSocket;
function  send(sockfd: PSocket; buf: PChar; len: Integer; flags: Integer): Integer;
function  recv(sockfd: PSocket; Buffer: PByteArray; BufSize: Integer): Integer;
function  recvfrom(sockfd: PSocket; Buffer: PByteArray; BufSize: Integer;
                   flags: Integer; from: PSocketAddr; fromlen: PInteger): Integer;
function  sendto(sockfd: PSocket; buf: PChar; len: Integer; flags: Integer;
                 to_addr: PSocketAddr; tolen: Integer): Integer;
function  close(sockfd: PSocket): Integer;


{=============================================================================
  PACKET PROCESSING
=============================================================================}

procedure Arp_ProcessPacket(EthernetHeader: TEthernetHeader; Packet: array of byte; Len: Integer);

procedure TCP_ProcessPacket(var IPHeader: TIPHeader; var TCPHeader: TTCPHeader;
                            Data: PByteArray; DataLen: Integer);
procedure UDP_ProcessPacket(IPHeader: TIPHeader; UDPHeader: TUDPHeader;
                            Data: PByteArray; DataLen: Integer);
procedure ParsePacket(packet: array of Byte; PacketLength: Integer);



{=============================================================================
  DHCP CLIENT
=============================================================================}

procedure DHCPDiscover;

{=============================================================================
  DNS CLIENT
=============================================================================}



{=============================================================================
  UDP EXAMPLES
=============================================================================}

procedure UDPClient;
procedure UDPServer;
procedure UDPBroadcast;




implementation

Uses
  NetworkDevices,
  RTL8139,
  NE2000;

{=============================================================================
  NETWORK / HARDWARE STUBS
  These are platform-dependent and must be linked to actual drivers.
=============================================================================}






function Rand(Max: LongWord): LongWord;
begin
  Result := Random(Max);
end;


{=============================================================================
  UTILITY FUNCTIONS
=============================================================================}

function inet_addr(ip: PChar): LongWord;
var
  octets: array[0..3] of Byte;
  i, j, octetValue: Integer;
begin
  j := 0;
  for i := 0 to 3 do begin
    octetValue := 0;
    while (ip[j] <> #0) and (ip[j] <> '.') do begin
      octetValue := octetValue * 10 + (Ord(ip[j]) - Ord('0'));
      Inc(j);
    end;
    Inc(j);
    octets[i] := octetValue;
  end;
  Result := (octets[0] shl 24) or (octets[1] shl 16) or (octets[2] shl 8) or octets[3];
end;


procedure IPToPChar(IP: LongWord; Buffer: PChar; BufSize: Integer);
var
  Octets: array[0..3] of Byte;
  i, pos: Integer;
  Temp: Integer;
  digits: array[0..2] of Char;
  dcount: Integer;
begin
  if (Buffer = nil) or (BufSize < 16) then Exit;

  Octets[0] := Byte((IP shr 24) and $FF);
  Octets[1] := Byte((IP shr 16) and $FF);
  Octets[2] := Byte((IP shr 8) and $FF);
  Octets[3] := Byte(IP and $FF);

  pos := 0;
  for i := 0 to 3 do
  begin
    Temp := Octets[i];
    dcount := 0;

    if Temp = 0 then
    begin
      digits[0] := '0';
      dcount := 1;
    end
    else
    begin
      while Temp > 0 do
      begin
        digits[dcount] := Char(Byte('0') + (Temp mod 10));
        Temp := Temp div 10;
        Inc(dcount);
      end;
      // Reverse digits
      case dcount of
        2: begin
             Temp := Ord(digits[0]);
             digits[0] := digits[1];
             digits[1] := Char(Temp);
           end;
        3: begin
             Temp := Ord(digits[0]);
             digits[0] := digits[2];
             digits[2] := Char(Temp);
           end;
      end;
    end;

    // Copy to buffer
    Temp := 0;
    while (Temp < dcount) and (pos < BufSize - 1) do
    begin
      Buffer[pos] := digits[Temp];
      Inc(pos);
      Inc(Temp);
    end;

    if (i < 3) and (pos < BufSize - 1) then
    begin
      Buffer[pos] := '.';
      Inc(pos);
    end;
  end;

  Buffer[pos] := #0;
end;

procedure IPToPCharSimple(IP: LongWord; Buffer: PChar; BufSize: Integer);
var
  a, b, c, d: Byte;
  pos: Integer;
begin
  if (Buffer = nil) or (BufSize < 16) then Exit;

  a := Byte((IP shr 24) and $FF);
  b := Byte((IP shr 16) and $FF);
  c := Byte((IP shr 8) and $FF);
  d := Byte(IP and $FF);

  pos := 0;

  if a >= 100 then begin Buffer[pos] := Char(Byte('0') + (a div 100)); Inc(pos); a := a mod 100; end;
  if a >= 10  then begin Buffer[pos] := Char(Byte('0') + (a div 10));  Inc(pos); a := a mod 10;  end;
  Buffer[pos] := Char(Byte('0') + a); Inc(pos);
  Buffer[pos] := '.'; Inc(pos);

  if b >= 100 then begin Buffer[pos] := Char(Byte('0') + (b div 100)); Inc(pos); b := b mod 100; end;
  if b >= 10  then begin Buffer[pos] := Char(Byte('0') + (b div 10));  Inc(pos); b := b mod 10;  end;
  Buffer[pos] := Char(Byte('0') + b); Inc(pos);
  Buffer[pos] := '.'; Inc(pos);

  if c >= 100 then begin Buffer[pos] := Char(Byte('0') + (c div 100)); Inc(pos); c := c mod 100; end;
  if c >= 10  then begin Buffer[pos] := Char(Byte('0') + (c div 10));  Inc(pos); c := c mod 10;  end;
  Buffer[pos] := Char(Byte('0') + c); Inc(pos);
  Buffer[pos] := '.'; Inc(pos);

  if d >= 100 then begin Buffer[pos] := Char(Byte('0') + (d div 100)); Inc(pos); d := d mod 100; end;
  if d >= 10  then begin Buffer[pos] := Char(Byte('0') + (d div 10));  Inc(pos); d := d mod 10;  end;
  Buffer[pos] := Char(Byte('0') + d); Inc(pos);
  Buffer[pos] := #0;
end;


{=============================================================================
  BYTE ORDER
=============================================================================}

function htons(hostshort: Word): Word;
begin
  Result := ((hostshort and $FF) shl 8) or ((hostshort shr 8) and $FF);
end;

function ntohs(netshort: Word): Word;
begin
  Result := htons(netshort);
end;

function htonl(hostlong: LongWord): LongWord;
begin
  Result := ((hostlong and $FF) shl 24) or
            (((hostlong shr 8) and $FF) shl 16) or
            (((hostlong shr 16) and $FF) shl 8) or
            ((hostlong shr 24) and $FF);
end;

function ntohl(netlong: LongWord): LongWord;
begin
  Result := htonl(netlong);
end;

{=============================================================================
  CHECKSUM
=============================================================================}

function CalcChecksum(Data: PWord; Length: Integer): Word;
var
  Sum: LongWord;
begin
  Sum := 0;
  while Length > 1 do
  begin
    Sum := Sum + Data^;
    Inc(Data);
    Dec(Length, 2);
  end;

  if Length = 1 then
    Sum := Sum + PByte(Data)^;

  Sum := (Sum shr 16) + (Sum and $FFFF);
  Sum := Sum + (Sum shr 16);

  Result := not Word(Sum);
end;

function TCPChecksum(SourceIP, DestIP: LongWord;
                       var TCPHeader: TTCPHeader;
                       TCPData: PByte; DataLen: Integer): Word;
var
  PseudoHeader: array[0..11] of Byte;
  ChecksumBuffer: array[0..MaxPacketSize - 1] of Byte;
  Index: Integer;
begin
  FillChar(PseudoHeader, SizeOf(PseudoHeader), #0);

  PLongWord(@PseudoHeader[0])^ := htonl(SourceIP);
  PLongWord(@PseudoHeader[4])^ := htonl(DestIP);
  PseudoHeader[8] := 0;
  PseudoHeader[9] := 6;
  PWord(@PseudoHeader[10])^ := htons(TCP_HEADER_SIZE + DataLen);

  Index := 0;
  Move(PseudoHeader, ChecksumBuffer[Index], SizeOf(PseudoHeader));
  Inc(Index, SizeOf(PseudoHeader));

  Move(TCPHeader, ChecksumBuffer[Index], TCP_HEADER_SIZE);
  Inc(Index, TCP_HEADER_SIZE);

  if (TCPData <> nil) and (DataLen > 0) then
  begin
    Move(TCPData^, ChecksumBuffer[Index], DataLen);
    Inc(Index, DataLen);
  end;

  Result := CalcChecksum(PWord(@ChecksumBuffer[0]), Index);
end;

function UDPChecksum(SourceIP, DestIP: LongWord;
                       UDPHeader: TUDPHeader;
                       UDPData: PByte; DataLen: Integer): Word;
var
  PseudoHeader: array[0..11] of Byte;
  ChecksumBuffer: array[0..MaxPacketSize - 1] of Byte;
  Index: Integer;
begin
  FillChar(PseudoHeader, SizeOf(PseudoHeader), #0);

  PLongWord(@PseudoHeader[0])^ := htonl(SourceIP);
  PLongWord(@PseudoHeader[4])^ := htonl(DestIP);
  PseudoHeader[8] := 0;
  PseudoHeader[9] := 17;
  PWord(@PseudoHeader[10])^ := htons(UDP_HEADER_SIZE + DataLen);

  Index := 0;
  Move(PseudoHeader, ChecksumBuffer[Index], SizeOf(PseudoHeader));
  Inc(Index, SizeOf(PseudoHeader));

  Move(UDPHeader, ChecksumBuffer[Index], UDP_HEADER_SIZE);
  Inc(Index, UDP_HEADER_SIZE);

  if (UDPData <> nil) and (DataLen > 0) then
  begin
    Move(UDPData^, ChecksumBuffer[Index], DataLen);
    Inc(Index, DataLen);
  end;

  Result := CalcChecksum(PWord(@ChecksumBuffer[0]), Index);
end;

{=============================================================================
  PACKET SENDERS
=============================================================================}

procedure SendTCPPacket(srcIP, destIP: LongWord; srcPort, destPort: Word;
                        seqNum, ackNum: LongWord; flags: Byte;
                        data: PByteArray; dataLen: Integer);
var
  ethHeader: TEthernetHeader;
  ipHeader: TIPHeader;
  tcpHeader: TTCPHeader;
  tcpPacket: array[0..MaxPacketSize - 1] of Byte;
  packetSize: Integer;
begin
  packetSize := ETH_HEADER_SIZE + IP_HEADER_SIZE + TCP_HEADER_SIZE + dataLen;

  // Ethernet
  FillChar(ethHeader, ETH_HEADER_SIZE, #0);
  FillChar(ethHeader.DstMAC[0], 6, $FF);
  GetMacAddr(ethHeader.SrcMAC);
  ethHeader.EthType := htons($0800);

  // IP
  FillChar(ipHeader, IP_HEADER_SIZE, #0);
  ipHeader.VerIHL := $45;
  ipHeader.TTL := 64;
  ipHeader.Protocol := 6;
  ipHeader.SrcIP := htonl(srcIP);
  ipHeader.DestIP := htonl(destIP);
  ipHeader.TotalLength := htons(IP_HEADER_SIZE + TCP_HEADER_SIZE + dataLen);
  ipHeader.HeaderChecksum := 0;
  ipHeader.HeaderChecksum := CalcChecksum(@ipHeader, IP_HEADER_SIZE);

  // TCP
  FillChar(tcpHeader, TCP_HEADER_SIZE, #0);
  tcpHeader.SrcPort := htons(srcPort);
  tcpHeader.DestPort := htons(destPort);
  tcpHeader.SeqNum := htonl(seqNum);
  tcpHeader.AckNum := htonl(ackNum);
  tcpHeader.DataOffset := (TCP_HEADER_SIZE div 4) shl 4;
  tcpHeader.Flags := flags;
  tcpHeader.Window := htons(8192);
  tcpHeader.Checksum := 0;

  if (data <> nil) and (dataLen > 0) then
    tcpHeader.Checksum := TCPChecksum(srcIP, destIP, tcpHeader, @data^[0], dataLen)
  else
    tcpHeader.Checksum := TCPChecksum(srcIP, destIP, tcpHeader, nil, 0);

  // Build packet
  FillChar(tcpPacket, packetSize, #0);
  Move(ethHeader, tcpPacket[0], ETH_HEADER_SIZE);
  Move(ipHeader, tcpPacket[ETH_HEADER_SIZE], IP_HEADER_SIZE);
  Move(tcpHeader, tcpPacket[ETH_HEADER_SIZE + IP_HEADER_SIZE], TCP_HEADER_SIZE);

  if (data <> nil) and (dataLen > 0) then
    Move(data^[0], tcpPacket[ETH_HEADER_SIZE + IP_HEADER_SIZE + TCP_HEADER_SIZE], dataLen);



  NetAdapters[NetAdapterIndex].SendPacket(@tcpPacket[0], packetSize);

 // if RTL8139Dev.Active then
  //  RTL8139SendPacket(@tcpPacket[0], packetSize);
end;

procedure SendUDPPacket(srcIP, destIP: LongWord; srcPort, destPort: Word;
                        data: PByteArray; size: Integer);
var
  udpHeader: TUDPHeader;
  ipHeader: TIPHeader;
  ethHeader: TEthernetHeader;
  packet: array[0..MaxPacketSize - 1] of Byte;
  dataSize, packetSize: Integer;
begin
  dataSize := size;
  packetSize := ETH_HEADER_SIZE + IP_HEADER_SIZE + UDP_HEADER_SIZE + dataSize;

  // Ethernet header
  FillChar(ethHeader.DstMAC[0], 6, $FF);
  GetMacAddr(ethHeader.SrcMAC);
  ethHeader.EthType := htons($0800);

  // IP header
  FillChar(ipHeader, IP_HEADER_SIZE, #0);
  ipHeader.VerIHL := $45;
  ipHeader.TTL := 64;
  ipHeader.Protocol := 17;
  ipHeader.SrcIP := htonl(srcIP);
  ipHeader.DestIP := htonl(destIP);
  ipHeader.TotalLength := htons(IP_HEADER_SIZE + UDP_HEADER_SIZE + dataSize);
  ipHeader.HeaderChecksum := 0;
  ipHeader.HeaderChecksum := CalcChecksum(@ipHeader, IP_HEADER_SIZE);

  // UDP header
  FillChar(udpHeader, UDP_HEADER_SIZE, #0);
  udpHeader.SrcPort := htons(srcPort);
  udpHeader.DestPort := htons(destPort);
  udpHeader.Length := htons(UDP_HEADER_SIZE + dataSize);
  udpHeader.Checksum := UDPChecksum(srcIP, destIP, udpHeader, @data^[0], size);

  // Build packet
  FillChar(packet, packetSize, #0);
  Move(ethHeader, packet[0], ETH_HEADER_SIZE);
  Move(ipHeader, packet[ETH_HEADER_SIZE], IP_HEADER_SIZE);
  Move(udpHeader, packet[ETH_HEADER_SIZE + IP_HEADER_SIZE], UDP_HEADER_SIZE);
  if data <> nil then
    Move(data^[0], packet[ETH_HEADER_SIZE + IP_HEADER_SIZE + UDP_HEADER_SIZE], dataSize);


   NetAdapters[NetAdapterIndex].SendPacket(@packet[0], packetSize);

  //if RTL8139Dev.Active then
  //  RTL8139SendPacket(@packet[0], packetSize);
end;

{=============================================================================
  SOCKET MANAGEMENT
=============================================================================}

function AllocSocket: PSocket;
begin
  Result := PSocket(MemAlloc(SizeOf(TSocket)));
  if Result = nil then Exit;

  FillChar(Result^, SizeOf(TSocket), 0);

  Result^.Next := SocketList;
  Result^.Prev := nil;

  if SocketList <> nil then
    SocketList^.Prev := Result;

  SocketList := Result;
end;

procedure FreeSocket(Sock: PSocket);
begin
  if Sock = nil then Exit;

  if Sock^.Prev <> nil then
    Sock^.Prev^.Next := Sock^.Next
  else
    SocketList := Sock^.Next;

  if Sock^.Next <> nil then
    Sock^.Next^.Prev := Sock^.Prev;

  FreeMem(Sock);
end;

function FindSocketByAddr(LocalPort, RemotePort: Word;
                          RemoteAddr: LongWord): PSocket;
var
  Sock: PSocket;
begin
  Result := nil;
  Sock := SocketList;

  while Sock <> nil do
  begin
    if Sock^.State = SS_SYN_SENT then
    begin
      if (Sock^.LocalPort = LocalPort) and
         (Sock^.RemotePort = RemotePort) then
      begin
        Result := Sock;
        Exit;
      end;
    end
    else
    begin
      if (Sock^.LocalPort = LocalPort) and
         (Sock^.RemotePort = RemotePort) and
         (Sock^.RemoteAddr = RemoteAddr) then
      begin
        Result := Sock;
        Exit;
      end;
    end;

    Sock := Sock^.Next;
  end;
end;

function FindListenSocket(LocalPort: Word): PSocket;
var
  Sock: PSocket;
begin
  Result := nil;
  Sock := SocketList;

  while Sock <> nil do
  begin
    if (Sock^.State = SS_LISTEN) and
       (Sock^.LocalPort = LocalPort) then
    begin
      Result := Sock;
      Exit;
    end;

    Sock := Sock^.Next;
  end;
end;

{=============================================================================
  BERKELEY SOCKET API
=============================================================================}

function socket(domain: Word; socketType: Integer; socketProtocol: Integer): PSocket;
begin
  Result := nil;
  if domain <> AF_INET then Exit;

  Result := AllocSocket;
  if Result = nil then Exit;

  if socketType = SOCK_STREAM then
    Result^.SocketType := SOCK_STREAM_TYPE
  else
    Result^.SocketType := SOCK_DGRAM_TYPE;

  if socketProtocol = IPPROTO_TCP then
    Result^.SocketProtocol := IPPROTO_TCP_TYPE
  else
    Result^.SocketProtocol := IPPROTO_UDP_TYPE;

  Result^.State := SS_CLOSED;
  Result^.LocalAddr := $0A00020F;  // 10.0.2.15 (host byte order)
end;

function bind(sockfd: PSocket; addr: TSocketAddr; addrlen: Integer): Integer;
begin
  Result := SOCKET_ERROR;
  if sockfd = nil then Exit;

  sockfd^.LocalPort := addr.sin_port;
  sockfd^.LocalAddr := addr.sin_addr;

  Result := 0;
end;

function listen(sockfd: PSocket; backlog: Integer): Integer;
begin
  Result := SOCKET_ERROR;
  if sockfd = nil then Exit;

  sockfd^.State := SS_LISTEN;
  Result := 0;
end;

function connect(sockfd: PSocket; addr: TSocketAddr; addrlen: Integer): Integer;
var
  timeout: Integer;
begin
  Result := SOCKET_ERROR;
  if sockfd = nil then Exit;

  sockfd^.RemoteAddr := addr.sin_addr;
  sockfd^.RemotePort := addr.sin_port;

  if sockfd^.LocalPort = 0 then
    sockfd^.LocalPort := 49152 + Rand(16384);

  sockfd^.SeqNum := Rand($FFFFFFFF);
  sockfd^.AckNum := 0;
  sockfd^.State := SS_SYN_SENT;

  // Send SYN
  SendTCPPacket(sockfd^.LocalAddr, sockfd^.RemoteAddr,
                sockfd^.LocalPort, sockfd^.RemotePort,
                sockfd^.SeqNum, sockfd^.AckNum,
                TCP_FLAG_SYN, nil, 0);

  // Wait for SYN-ACK
  timeout := 5000;
  while (timeout > 0) and (sockfd^.State = SS_SYN_SENT) do
  begin
   // RTL8139ReceivePacket;
     PollAllAdapters;
    Delay(1);
    Dec(timeout);
  end;

  if sockfd^.State = SS_ESTABLISHED then
    Result := 0
  else
  begin
    FreeSocket(sockfd);
    Result := SOCKET_ERROR;
  end;
end;

function accept(sockfd: PSocket; addr: PSocketAddr; addrlen: PInteger): PSocket;
var
  timeout: Integer;
  Sock: PSocket;
begin
  Result := nil;
  if (sockfd = nil) or (sockfd^.State <> SS_LISTEN) then Exit;

  timeout := 60000;
  while timeout > 0 do
  begin
   // RTL8139ReceivePacket;
     PollAllAdapters;

    Sock := SocketList;
    while Sock <> nil do
    begin
      if (Sock^.State = SS_ESTABLISHED) and
         (Sock^.LocalPort = sockfd^.LocalPort) and
         (Sock <> sockfd) then
      begin
        if addr <> nil then
        begin
          addr^.sin_family := AF_INET;
          addr^.sin_port := Sock^.RemotePort;
          addr^.sin_addr := Sock^.RemoteAddr;
        end;

        Result := Sock;
        Exit;
      end;

      Sock := Sock^.Next;
    end;

    Delay(1);
    Dec(timeout);
  end;
end;


const
  MAX_TCP_PAYLOAD = 1460;  // 1514 - 20(IP) - 20(TCP) - 14(Ethernet) = 1460


function send(sockfd: PSocket; buf: PChar; len: Integer; flags: Integer): Integer;
var
  Offset    : Integer;
  ChunkSize : Integer;
  Sent      : Integer;
begin
  Result := SOCKET_ERROR;
  if (sockfd = nil) or (buf = nil) or (len <= 0) then Exit;

  Offset := 0;
  Sent   := 0;

  while Offset < len do
  begin
   //  PollAllAdapters;

    // Soket kapanm��sa veya kopmu�sa derhal d�ng�den ��k!
    if sockfd^.State <> SS_ESTABLISHED then
    begin
      Result := SOCKET_ERROR;
      Exit;
    end;

    ChunkSize := len - Offset;
    if ChunkSize > MAX_TCP_PAYLOAD then
      ChunkSize := MAX_TCP_PAYLOAD;

    SendTCPPacket(
      sockfd^.LocalAddr,  sockfd^.RemoteAddr,
      sockfd^.LocalPort,  sockfd^.RemotePort,
      sockfd^.SeqNum,     sockfd^.AckNum,
      TCP_FLAG_PSH or TCP_FLAG_ACK,
      PByteArray(buf + Offset),
      ChunkSize
    );

    sockfd^.SeqNum := sockfd^.SeqNum + ChunkSize;
    Offset         := Offset + ChunkSize;
    Sent           := Sent   + ChunkSize;

    // Gelen ACK / FIN / RST paketlerini i�lemek i�in a� kart�n� yokla
  //  PollAllAdapters;
  end;

  Result := Sent;
end;

function send1(sockfd: PSocket; buf: PChar; len: Integer; flags: Integer): Integer;
var
  Offset    : Integer;
  ChunkSize : Integer;
  Sent      : Integer;
begin
  Result := SOCKET_ERROR;
  if (sockfd = nil) or (buf = nil) or (len <= 0) then Exit;
  if sockfd^.State <> SS_ESTABLISHED then Exit;

  Offset := 0;
  Sent   := 0;

  while Offset < len do
  begin
    // Bu turda ka� byte g�nderilecek?
    ChunkSize := len - Offset;
    if ChunkSize > MAX_TCP_PAYLOAD then
      ChunkSize := MAX_TCP_PAYLOAD;

    SendTCPPacket(
      sockfd^.LocalAddr,  sockfd^.RemoteAddr,
      sockfd^.LocalPort,  sockfd^.RemotePort,
      sockfd^.SeqNum,     sockfd^.AckNum,
      TCP_FLAG_PSH or TCP_FLAG_ACK,
      PByteArray(buf + Offset),   // <-- offset ile kayd�r
      ChunkSize
    );

    sockfd^.SeqNum := sockfd^.SeqNum + ChunkSize;
    Offset         := Offset + ChunkSize;
    Sent           := Sent   + ChunkSize;

    // Al�c�ya nefes ald�r � ACK bekle (basit gecikme)
    // Ger�ek implementasyonda ACK beklenir, biz poll ediyoruz
   // RTL8139ReceivePacket;
   // Delay(2);
  end;

  Result := Sent;
end;




function recv(sockfd: PSocket; Buffer: PByteArray; BufSize: Integer): Integer;
var
  timeout: Integer;
  CopyLen, i: Integer;
begin
  Result := SOCKET_ERROR;
  if sockfd = nil then Exit;
  
  case sockfd^.SocketProtocol of
    IPPROTO_TCP_TYPE:
    begin
      if sockfd^.State <> SS_ESTABLISHED then Exit;
      
      // *** WAIT FOR DATA ***
       timeout := 2000;
       while (sockfd^.RecvCount = 0) and (timeout > 0) do
       begin
        // RTL8139ReceivePacket;
         PollAllAdapters;

         Delay(1);
         Dec(timeout);
      end;
      
      if sockfd^.RecvCount = 0 then
      begin
        Result := 0;
        Exit;
      end;
      
      // *** RecvBuffer'dan kopyala ***
      CopyLen := BufSize;
      if CopyLen > sockfd^.RecvCount then
        CopyLen := sockfd^.RecvCount;
      
      for i := 0 to CopyLen - 1 do
      begin
        Buffer^[i] := sockfd^.RecvBuffer[sockfd^.RecvTail];
        sockfd^.RecvTail := (sockfd^.RecvTail + 1) mod 4096;
      end;
      
      sockfd^.RecvCount := sockfd^.RecvCount - CopyLen;
      Result := CopyLen;
    end;
    
    IPPROTO_UDP_TYPE:
    begin
      // *** WAIT FOR DATA ***
      timeout := 2000;
      while (sockfd^.RecvCount = 0) and (timeout > 0) do
      begin
       // RTL8139ReceivePacket;
        PollAllAdapters;

        Delay(1);
        Dec(timeout);
     end;
      
      if sockfd^.RecvCount = 0 then
      begin
        Result := 0;
        Exit;
      end;
      
      // *** RecvBuffer'dan kopyala ***
      CopyLen := BufSize;
      if CopyLen > sockfd^.RecvCount then
        CopyLen := sockfd^.RecvCount;
      
      for i := 0 to CopyLen - 1 do
      begin
        Buffer^[i] := sockfd^.RecvBuffer[sockfd^.RecvTail];
        sockfd^.RecvTail := (sockfd^.RecvTail + 1) mod 4096;
      end;
      
      sockfd^.RecvCount := sockfd^.RecvCount - CopyLen;
      Result := CopyLen; 

      
    end;
  end;
end;





function recvfrom(sockfd: PSocket;Buffer: PByteArray; BufSize: Integer;
                  flags: Integer; from: PSocketAddr; fromlen: PInteger): Integer;
var
  timeout: Integer;
  CopyLen, i: Integer;
begin
  Result := SOCKET_ERROR;
  if sockfd = nil then Exit;
  if sockfd^.SocketProtocol <> IPPROTO_UDP_TYPE then Exit;

  timeout := 2000;
  while (sockfd^.RecvCount = 0) and (timeout > 0) do
  begin
   // RTL8139ReceivePacket;
    PollAllAdapters;
    Delay(1);
    Dec(timeout);
  end;

  if sockfd^.RecvCount = 0 then
  begin
    Result := 0;
    Exit;
  end;

  if (from <> nil) and (fromlen <> nil) then
  begin
    from^.sin_family := AF_INET;
    from^.sin_addr := sockfd^.RemoteAddr;
    from^.sin_port := sockfd^.RemotePort;
    fromlen^ := SizeOf(TSocketAddr);
  end;

  CopyLen := BufSize;
  if CopyLen > sockfd^.RecvCount then
    CopyLen := sockfd^.RecvCount;

  for i := 0 to CopyLen - 1 do
  begin
    Buffer^[i] := sockfd^.RecvBuffer[sockfd^.RecvTail];
    sockfd^.RecvTail := (sockfd^.RecvTail + 1) mod MAX_RECV_BUFFER;
  end;

  sockfd^.RecvCount := sockfd^.RecvCount - CopyLen;
  Result := CopyLen;
end;

function sendto(sockfd: PSocket; buf: PChar; len: Integer; flags: Integer;
                to_addr: PSocketAddr; tolen: Integer): Integer;
begin
  Result := SOCKET_ERROR;
  if (sockfd = nil) or (to_addr = nil) then Exit;
  if sockfd^.SocketProtocol <> IPPROTO_UDP_TYPE then Exit;

  SendUDPPacket(sockfd^.LocalAddr, to_addr^.sin_addr,
                sockfd^.LocalPort, to_addr^.sin_port,
                @buf[0], len);

  Result := len;
end;

function close(sockfd: PSocket): Integer;
begin
  Result := SOCKET_ERROR;
  if sockfd = nil then Exit;

  if sockfd^.State = SS_ESTABLISHED then
  begin
    SendTCPPacket(sockfd^.LocalAddr, sockfd^.RemoteAddr,
                  sockfd^.LocalPort, sockfd^.RemotePort,
                  sockfd^.SeqNum, sockfd^.AckNum,
                  TCP_FLAG_FIN or TCP_FLAG_ACK, nil, 0);
    sockfd^.State := SS_FIN_WAIT_1;
  end
  else
  begin
    FreeSocket(sockfd);
  end;

  Result := 0;
end;

{=============================================================================
  TCP PACKET PROCESSING
=============================================================================}


procedure Arp_ProcessPacket(EthernetHeader: TEthernetHeader; Packet: array of byte; Len: Integer);
const
  ARP_REQUEST = $0001;
  ARP_REPLY = $0002;
  HARDWARE_TYPE_ETHERNET = $0001;
  ETHERNET_TYPE_IP = $0800;
var
  ARPHeader: TArpPacket;
  ResponsePacket: array[0..MaxPacketSize - 1] of Byte;
  RequesterMAC: array[0..5] of Byte;
  RequesterIP: TIPAddress;
  MyIP: TIPAddress;
  MyMAC: array[0..5] of Byte;
begin
  if ntohs(EthernetHeader.EthType) <> $0806 then
    Exit;

  FillChar(ARPHeader, SizeOf(ARPHeader), #0);
  Move(Packet[ETH_HEADER_SIZE], ARPHeader, SizeOf(TArpPacket));

  // IP adresi kontrol 
  MyIP[0] := 10;
  MyIP[1] := 0;
  MyIP[2] := 2;
  MyIP[3] := 15;

  if (ntohs(ARPHeader.Opcode) = ARP_REQUEST) and (StrCmpN(@ARPHeader.DstIP, @MyIP, 4)=0) then begin
    move(ARPHeader.SrcMAC, RequesterMAC, 6);
    move(ARPHeader.SrcIP, RequesterIP, 4);
    GetMacAddr(MyMAC);

    // ARP cevab n  olu tur
    FillChar(ARPHeader, SizeOf(ARPHeader), #0);
    ARPHeader.hardwaretype := htons(HARDWARE_TYPE_ETHERNET);
    ARPHeader.ProtocolType := htons(ETHERNET_TYPE_IP);
    ARPHeader.HardwareSize := 6;
    ARPHeader.ProtocolSize := 4;
    ARPHeader.Opcode := htons(ARP_REPLY);

    move(MyMAC, ARPHeader.SrcMAC, 6);
    move(MyIP, ARPHeader.SrcIP, 4);
    move(RequesterMAC, ARPHeader.DstMAC, 6);
    move(RequesterIP, ARPHeader.DstIP, 4);

    // Ethernet ba l   
    move(MyMAC, EthernetHeader.SrcMac, 6);
    move(RequesterMAC, EthernetHeader.DstMac, 6);
    EthernetHeader.EthType := htons($0806);

    // Paketi haz rla ve g nder
    Move(EthernetHeader, ResponsePacket[0], ETH_HEADER_SIZE);
    Move(ARPHeader, ResponsePacket[ETH_HEADER_SIZE], SizeOf(TArpPacket));



   NetAdapters[NetAdapterIndex].SendPacket(@ResponsePacket[0], ETH_HEADER_SIZE + SizeOf(TArpPacket));

   // if RTL8139Dev.Active  then
    //  RTL8139SendPacket(@ResponsePacket[0], ETH_HEADER_SIZE + SizeOf(TArpPacket));


  end;
end;


procedure TCP_ProcessPacket(var IPHeader: TIPHeader; var TCPHeader: TTCPHeader;
                            Data: PByteArray; DataLen: Integer);
var
  Sock, NewSock: PSocket;
  RemoteIP: LongWord;
  LocalPort, RemotePort: Word;
  i: Integer;
begin
  RemoteIP := ntohl(IPHeader.SrcIP);
  LocalPort := ntohs(TCPHeader.DestPort);
  RemotePort := ntohs(TCPHeader.SrcPort);

  Sock := FindSocketByAddr(LocalPort, RemotePort, RemoteIP);

  if Sock = nil then
    Sock := FindListenSocket(LocalPort);

  if Sock = nil then Exit;

  case Sock^.State of
    SS_LISTEN:
    begin
      if (TCPHeader.Flags and TCP_FLAG_SYN) <> 0 then
      begin
        NewSock := AllocSocket;
        if NewSock = nil then Exit;

        NewSock^.SocketType := Sock^.SocketType;
        NewSock^.SocketProtocol := Sock^.SocketProtocol;
        NewSock^.LocalAddr := Sock^.LocalAddr;
        NewSock^.LocalPort := Sock^.LocalPort;
        NewSock^.RemoteAddr := RemoteIP;
        NewSock^.RemotePort := RemotePort;
        NewSock^.AckNum := ntohl(TCPHeader.SeqNum) + 1;
        NewSock^.SeqNum := Rand($FFFFFFFF);

        SendTCPPacket(NewSock^.LocalAddr, NewSock^.RemoteAddr,
                      NewSock^.LocalPort, NewSock^.RemotePort,
                      NewSock^.SeqNum, NewSock^.AckNum,
                      TCP_FLAG_SYN or TCP_FLAG_ACK, nil, 0);

        NewSock^.State := SS_SYN_RECEIVED;
        Inc(NewSock^.SeqNum);
      end;
    end;

    SS_SYN_SENT:
    begin
      if (TCPHeader.Flags and (TCP_FLAG_SYN or TCP_FLAG_ACK)) =
         (TCP_FLAG_SYN or TCP_FLAG_ACK) then
      begin
        Sock^.AckNum := ntohl(TCPHeader.SeqNum) + 1;
        Sock^.SeqNum := ntohl(TCPHeader.AckNum);

        SendTCPPacket(Sock^.LocalAddr, Sock^.RemoteAddr,
                      Sock^.LocalPort, Sock^.RemotePort,
                      Sock^.SeqNum, Sock^.AckNum,
                      TCP_FLAG_ACK, nil, 0);

        Sock^.State := SS_ESTABLISHED;
      end;
    end;

    SS_SYN_RECEIVED:
    begin
      if (TCPHeader.Flags and TCP_FLAG_ACK) <> 0 then
      begin
        Sock^.SeqNum := ntohl(TCPHeader.AckNum);
        Sock^.State := SS_ESTABLISHED;
      end;
    end;

    SS_ESTABLISHED:
    begin

       // 1. �stemciden RST (Reset) gelmi�se soketi hemen kapat ve temizle
     if (TCPHeader.Flags and TCP_FLAG_RST) <> 0 then
     begin
       Sock^.State := SS_CLOSED;
       Exit;
     end;

      // 2. �stemciden normal FIN (Finish) gelmi�se
      if (TCPHeader.Flags and TCP_FLAG_FIN) <> 0 then
      begin
        Sock^.AckNum := ntohl(TCPHeader.SeqNum) + 1;

        SendTCPPacket(Sock^.LocalAddr, Sock^.RemoteAddr,
                      Sock^.LocalPort, Sock^.RemotePort,
                      Sock^.SeqNum, Sock^.AckNum,
                      TCP_FLAG_ACK, nil, 0);

        Sock^.State := SS_CLOSE_WAIT;

        SendTCPPacket(Sock^.LocalAddr, Sock^.RemoteAddr,
                      Sock^.LocalPort, Sock^.RemotePort,
                      Sock^.SeqNum, Sock^.AckNum,
                      TCP_FLAG_FIN or TCP_FLAG_ACK, nil, 0);

        Sock^.State := SS_LAST_ACK;
        Inc(Sock^.SeqNum);
        Exit;
      end;


     

      if (TCPHeader.Flags and TCP_FLAG_PSH) <> 0 then
      begin
        for i := 0 to DataLen - 1 do
        begin
          if Sock^.RecvCount < MAX_RECV_BUFFER then
          begin
            Sock^.RecvBuffer[Sock^.RecvHead] := Data^[i];
            Sock^.RecvHead := (Sock^.RecvHead + 1) mod MAX_RECV_BUFFER;
            Inc(Sock^.RecvCount);
          end;
        end;

        Sock^.AckNum := ntohl(TCPHeader.SeqNum) + DataLen;

        SendTCPPacket(Sock^.LocalAddr, Sock^.RemoteAddr,
                      Sock^.LocalPort, Sock^.RemotePort,
                      Sock^.SeqNum, Sock^.AckNum,
                      TCP_FLAG_ACK, nil, 0);
      end;


    end;

    SS_FIN_WAIT_1:
    begin
      if (TCPHeader.Flags and TCP_FLAG_ACK) <> 0 then
        Sock^.State := SS_FIN_WAIT_2;
    end;

    SS_FIN_WAIT_2:
    begin
      if (TCPHeader.Flags and TCP_FLAG_FIN) <> 0 then
      begin
        Sock^.AckNum := ntohl(TCPHeader.SeqNum) + 1;

        SendTCPPacket(Sock^.LocalAddr, Sock^.RemoteAddr,
                      Sock^.LocalPort, Sock^.RemotePort,
                      Sock^.SeqNum, Sock^.AckNum,
                      TCP_FLAG_ACK, nil, 0);

        Sock^.State := SS_TIME_WAIT;
      end;
    end;

    SS_LAST_ACK:
    begin
      if (TCPHeader.Flags and TCP_FLAG_ACK) <> 0 then
      begin
        FreeSocket(Sock);
      end;
    end;


  end;
end;

{=============================================================================
  UDP PACKET PROCESSING
=============================================================================}

procedure UDP_ProcessPacket(IPHeader: TIPHeader; UDPHeader: TUDPHeader;
                            Data: PByteArray; DataLen: Integer);
var
  Sock: PSocket;
  LocalPort, RemotePort: Word;
  RemoteIP: LongWord;
  i: Integer;
begin
  LocalPort := ntohs(UDPHeader.DestPort);
  RemotePort := ntohs(UDPHeader.SrcPort);
  RemoteIP := ntohl(IPHeader.SrcIP);

  Sock := SocketList;
  while Sock <> nil do
  begin
    if (Sock^.SocketProtocol = IPPROTO_UDP_TYPE) and
       (Sock^.LocalPort = LocalPort) then
    begin
      Sock^.RemoteAddr := RemoteIP;
      Sock^.RemotePort := RemotePort;

      for i := 0 to DataLen - 1 do
      begin
        if Sock^.RecvCount < MAX_RECV_BUFFER then
        begin
          Sock^.RecvBuffer[Sock^.RecvHead] := Data^[i];
          Sock^.RecvHead := (Sock^.RecvHead + 1) mod MAX_RECV_BUFFER;
          Inc(Sock^.RecvCount);
        end;
      end;

      Exit;
    end;
    Sock := Sock^.Next;
  end;
end;

{=============================================================================
  PACKET PARSER
=============================================================================}

procedure ParsePacket(packet: array of Byte; PacketLength: Integer);
var
  EthHeader: TEthernetHeader;
  IPHeader: TIPHeader;
  TCPHeader: TTCPHeader;
  UDPHeader: TUDPHeader;
  ip_header_length: Byte;
  tcp_header_length: Byte;
  data_offset: Integer;
  data_length: Integer;

begin
 Move(packet[0], EthHeader, SizeOf(TEthernetHeader));

   case ntohs(EthHeader.EthType) of
    $0806: // ARP
      Arp_ProcessPacket(EthHeader, packet, PacketLength);

    $0800: // IPv4
    begin
      Move(packet[SizeOf(TEthernetHeader)],IPHeader, SizeOf(TIPHeader));
      ip_header_length := (IPHeader.VerIHL and $0F) * 4;



      if IPHeader.Protocol = 6 then
      begin
        Move(packet[SizeOf(TEthernetHeader) + ip_header_length], TCPHeader, SizeOf(TTCPHeader));
        tcp_header_length := (packet[SizeOf(TEthernetHeader) + ip_header_length + 12] shr 4) * 4;
        data_offset := SizeOf(TEthernetHeader) + ip_header_length + tcp_header_length;
        data_length := PacketLength - data_offset;

         if data_length > 0 then
         begin
           TCP_ProcessPacket(IPHeader,TCPHeader,@packet[data_offset],data_length-4);
         end;
      end
      else
      //---------------------------------------------------------------
       if IPHeader.Protocol = 17 then // UDP
       begin
        Move(packet[SizeOf(TEthernetHeader) + ip_header_length],UDPHeader, SizeOf(TUDPHeader));
        data_offset := SizeOf(TEthernetHeader) + ip_header_length + SizeOf(TUDPHeader);
        data_length := ntohs(UDPHeader.Length) - SizeOf(TUDPHeader);
        if data_length > 0 then
        begin
           UDP_ProcessPacket(IPHeader, UDPHeader, @packet[data_offset], data_length);
        end;

      end;


      //----------------------------------------------------------------------

  end;

 end;

end;

{=============================================================================
  DHCP CLIENT
=============================================================================}

procedure ParseDHCPOptions(const buffer: array of Byte; bufLen: Integer;
                             out dnsServers: array of LongWord; 
                             out dnsCount: Integer);
var
  offset: Integer;
  code, len: Byte;
  idx: Integer;
begin
  dnsCount := 0;
  
  // Option'lar offset 240'tan ba�lar (236 byte header + 4 byte magic cookie)
  offset := 240;
  
  while offset < bufLen do
  begin
    code := buffer[offset];
    
    if code = 0 then 
    begin
      Inc(offset);  // Pad byte, atla
      Continue;
    end;
    
    if code = 255 then Break;  // End option, bitir
    
    if offset + 1 >= bufLen then Break;
    len := buffer[offset + 1];
    
    // Ta�ma kontrol�
    if offset + 2 + len > bufLen then Break;
    
    if code = 6 then // DNS Servers (Option 6)
    begin
      idx := 0;
      while (idx + 3 < len) and (dnsCount < Length(dnsServers)) do
      begin
        // Network byte order'dan host order'a �evir
        dnsServers[dnsCount] := ntohl(PLongWord(@buffer[offset + 2 + idx])^);
        Inc(dnsCount);
        Inc(idx, 4);  // Her DNS IP'si 4 byte
      end;
    end;
    // �sterseniz di�er option'lar� da burada yakalayabilirsiniz:
    // code = 1 -> Subnet Mask, code = 3 -> Router, code = 15 -> Domain Name
    
    Inc(offset, 2 + len);
  end;
end;

procedure DHCPDiscover;
var
  sockfd: PSocket;
  dhcp_server: TSocketAddr;
  discover_msg: TDHCPMessage;
  buffer: array[0..511] of Byte;
  ret: Integer;
  offeredIP: LongWord;
  ipStr: array[0..15] of Char;
  macAddr: array[0..5] of Byte;
  optPos: Integer;

  dnsServers: array[0..3] of LongWord;  // En fazla 4 DNS
  dnsCount: Integer;
  i: Integer;
begin
  sockfd := socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if sockfd = nil then Exit;

  sockfd^.LocalAddr := $00000000;
  sockfd^.LocalPort := BOOTPC_PORT;

  dhcp_server.sin_family := AF_INET;
  dhcp_server.sin_port := BOOTPS_PORT;
  dhcp_server.sin_addr := BROADCAST_IP;

  // Build DHCP DISCOVER
  FillChar(discover_msg, SizeOf(discover_msg), 0);
  discover_msg.op := 1;
  discover_msg.htype := 1;
  discover_msg.hlen := 6;
  discover_msg.hops := 0;
  discover_msg.xid := Rand($FFFFFFFF);
  discover_msg.secs := 0;
  discover_msg.flags := htons($8000); // Broadcast flag

  GetMacAddr(macAddr);
  Move(macAddr[0], discover_msg.chaddr[0], 6);

  // Magic Cookie
  discover_msg.options[0] := DHCP_MAGIC_COOKIE_0;
  discover_msg.options[1] := DHCP_MAGIC_COOKIE_1;
  discover_msg.options[2] := DHCP_MAGIC_COOKIE_2;
  discover_msg.options[3] := DHCP_MAGIC_COOKIE_3;

  optPos := 4;
  // Message Type: DISCOVER
  discover_msg.options[optPos] := DHCP_OPTION_MSG_TYPE;
  discover_msg.options[optPos+1] := 1;
  discover_msg.options[optPos+2] := DHCP_MSG_DISCOVER;
  Inc(optPos, 3);

  // Parameter Request List
  discover_msg.options[optPos] := DHCP_OPTION_REQ_LIST;
  discover_msg.options[optPos+1] := 4;
  discover_msg.options[optPos+2] := DHCP_OPTION_SUBNET;
  discover_msg.options[optPos+3] := DHCP_OPTION_ROUTER;
  discover_msg.options[optPos+4] := DHCP_OPTION_DNS;
  discover_msg.options[optPos+5] := DHCP_OPTION_DOMAIN;
  Inc(optPos, 6);

  // End
  discover_msg.options[optPos] := DHCP_OPTION_END;

  // Send
  sendto(sockfd, @discover_msg, 240 + optPos + 1, 0,
         @dhcp_server, SizeOf(TSocketAddr));

  // Wait for OFFER
  FillChar(buffer, SizeOf(buffer), 0);
  ret := recv(sockfd, @buffer[0], 512);

  if ret > 0 then
  begin
    offeredIP := PLongWord(@buffer[16])^;
  // IPToPCharSimple(offeredIP, @ipStr[0], SizeOf(ipStr));
    IPToPCharSimple(ntohl(offeredIP), SERVER_IP, 16);




     ParseDHCPOptions(buffer, ret, dnsServers, dnsCount);

   // COM1_WriteStr(IntToPChar(dnsCount));
    for i := 0 to dnsCount - 1 do
    begin
      IPToPCharSimple(dnsServers[i], DHCP_IP, 16);
      COM1_WriteStr(DHCP_IP);
    end;

  end;

  FreeSocket(sockfd);
end;



{=============================================================================
  UDP EXAMPLES
=============================================================================}

procedure UDPClient;
var
  sockfd: PSocket;
  server_addr: TSocketAddr;
  buffer: array[0..255] of Byte;
  msg: PChar;
  ret: Integer;
begin
  sockfd := socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if sockfd = nil then
  begin
    COM1_WriteStr('UDP Socket failed');
    Exit;
  end;

  sockfd^.LocalAddr := inet_addr('10.0.2.15');
  sockfd^.LocalPort := 1024 + Rand(64511);

  server_addr.sin_family := AF_INET;
  server_addr.sin_port := 5678;
  server_addr.sin_addr := inet_addr('127.0.0.1');

  COM1_WriteStr('UDP Client: Sending to 127.0.0.1:5678');

  msg := 'Hello UDP Server!';
  ret := sendto(sockfd, msg, StrLen(msg), 0, @server_addr, SizeOf(TSocketAddr));

  if ret = SOCKET_ERROR then
  begin
    COM1_WriteStr('UDP Send failed');
    FreeSocket(sockfd);
    Exit;
  end;

  COM1_WriteStr('UDP: Data sent!');

  FillChar(buffer, SizeOf(buffer), 0);
  ret := recv(sockfd, @buffer[0], 255);

  if ret > 0 then
  begin
    buffer[ret] := 0;
    COM1_WriteStr(PChar(@buffer[0]));
  end
  else
  begin
    COM1_WriteStr('UDP: No response');
  end;

  FreeSocket(sockfd);
  COM1_WriteStr('UDP Client done');
end;

procedure UDPServer;
var
  serverSock: PSocket;
  bind_addr: TSocketAddr;
  client_addr: TSocketAddr;
  addrlen: Integer;
  buffer: array[0..1023] of Byte;
  recvLen: Integer;
  response: PChar;
begin
  serverSock := socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if serverSock = nil then
  begin
    COM1_WriteStr('UDP Server: Socket failed');
    Exit;
  end;

  bind_addr.sin_family := AF_INET;
  bind_addr.sin_port := 7070;
  bind_addr.sin_addr := inet_addr('10.0.2.15');

  if bind(serverSock, bind_addr, SizeOf(TSocketAddr)) <> 0 then
  begin
    COM1_WriteStr('UDP Server: Bind failed');
    FreeSocket(serverSock);
    Exit;
  end;

  COM1_WriteStr('UDP Server listening: 10.0.2.15:7070');

  while True do
  begin
   // RTL8139ReceivePacket;
     PollAllAdapters;
    FillChar(buffer, SizeOf(buffer), 0);
    addrlen := SizeOf(TSocketAddr);

    recvLen := recvfrom(serverSock, @buffer[0], 1023, 0, @client_addr, @addrlen);

    if recvLen > 0 then
    begin
      buffer[recvLen] := 0;
      COM1_WriteStr('From client: ');
      COM1_WriteStr(PChar(@buffer[0]));

      response := 'UDP Server: Message received!';
      sendto(serverSock, response, StrLen(response), 0, @client_addr, addrlen);
      COM1_WriteStr('UDP Server: Response sent');
    end
    else
    begin
      Delay(10);
    end;
  end;

  FreeSocket(serverSock);
end;

procedure UDPBroadcast;
var
  sockfd: PSocket;
  broadcast_addr: TSocketAddr;
  msg: PChar;
  timeout: LongWord;
  buffer: array[0..255] of Byte;
  from: TSocketAddr;
  fromlen: Integer;
  ret: Integer;
begin
  sockfd := socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if sockfd = nil then Exit;

  sockfd^.LocalAddr := inet_addr('10.0.2.15');
  sockfd^.LocalPort := 1024 + Rand(64511);

  broadcast_addr.sin_family := AF_INET;
  broadcast_addr.sin_port := 9999;
  broadcast_addr.sin_addr := inet_addr('255.255.255.255');

  msg := 'DISCOVERY: Who is there?';
  sendto(sockfd, msg, StrLen(msg), 0, @broadcast_addr, SizeOf(TSocketAddr));

  COM1_WriteStr('Broadcast sent!');

  timeout := 10000;
  while timeout > 0 do
  begin
    FillChar(buffer, SizeOf(buffer), 0);
    fromlen := SizeOf(TSocketAddr);

    ret := recvfrom(sockfd, @buffer[0], 255, 0, @from, @fromlen);

    if ret > 0 then
    begin
      buffer[ret] := 0;
      COM1_WriteStr('Response: ');
      COM1_WriteStr(PChar(@buffer[0]));
    end;
    PollAllAdapters;
   // RTL8139ReceivePacket;
    Delay(10);
    Dec(timeout, 10);
  end;

  FreeSocket(sockfd);
end;

{=============================================================================
  INITIALIZATION
=============================================================================}

initialization
  SocketList := nil;
  gDhcpXID := 0;


end.

unit NetworkDevices;

interface

uses
  SysUtils,IDT,Ports,Pci,WinSocket, Memory, Fat32,
  RTL8139,NE2000;


const
  MAX_NET_ADAPTERS = 8;

type
  TNetAdapterType = (natUnknown, natRTL8139, natNE2000);

  // S�r�c�ye �zel fonksiyon tipleri
  TSendPacketProc = procedure(data: PByteArray; len: Integer);
  TReceivePacketFunc = function(): Boolean;

  TNetAdapterInfo = record
    Active: Boolean;
    AdapterType: TNetAdapterType;
    IO_Base: Word;
    IRQ: Byte;
    MacAddr: array[0..5] of Byte;
    
    // S�r�c� fonksiyon g�stericileri
    SendPacket: TSendPacketProc;
    ReceivePacket: TReceivePacketFunc;
  end;





 type
  TDriverProbeFunc = function(Dev: PPciDevice): Boolean;

  TRegisteredDriver = record
    DriverName: PChar;
    Probe: TDriverProbeFunc;
  end;


var
   NetAdapters: array[0..MAX_NET_ADAPTERS - 1] of TNetAdapterInfo;
   NetAdapterCount: Integer = 0;
   NetAdapterIndex: Integer = 0;


  procedure AutoDetectAndInitNetworkDevices;
  procedure PollAllAdapters;
  function GetMacAddr(out SrcMacAddr: array of byte):Boolean;
  procedure RegisterNetAdapter(AType: TNetAdapterType; AIOBase: Word; AIRQ: Byte;
  AMac: array of Byte; ASendProc: TSendPacketProc; ARecvFunc: TReceivePacketFunc);


implementation


// RTL8139 ve NE2000 i�in Probe (Tespit) Fonksiyonlar�
function Probe_RTL8139(Dev: PPciDevice): Boolean;
begin
  // Vendor ve Device ID kontrol�
  Result := (Dev^.VendorID = $10EC) and (Dev^.DeviceID = $8139);
end;

function Probe_NE2000(Dev: PPciDevice): Boolean;
begin
  Result := ((Dev^.VendorID = $1050) and (Dev^.DeviceID = $0940)) or
            ((Dev^.VendorID = $10EC) and (Dev^.DeviceID = $8029));
end;



procedure AutoDetectAndInitNetworkDevices;
var
  Dev: PPciDevice;
begin
  NetAdapterCount := 0;

  // PCI cihaz listesini dola�
  Dev := PciDeviceList;
  while Dev <> nil do
  begin
    // Sadece Network / Ethernet Controller olan PCI cihazlar�n� yakala
    if (Dev^.ClassCode = $02) and (Dev^.SubClass = $00) then
    begin
      
      // 1. RTL8139 mu?
      if Probe_RTL8139(Dev) then
      begin
        if RTL8139_Init(Dev) then // RTL8139 ba�lat[cite: 1]
        begin
          RegisterNetAdapter(
            natRTL8139,
            RTL8139Dev.io_base,
            RTL8139Dev.irq_num,
            RTL8139Dev.mac_addr,
            @RTL8139SendPacket,
            @RTL8139ReceivePacket
          );
        end;
      end;
      
      // 2. NE2000 mi?
     // else
      if Probe_NE2000(Dev) then
      begin
        if NE2000_Init(Dev) then // NE2000 ba�lat[cite: 2]
        begin
          RegisterNetAdapter(
            natNE2000,
            NE2000Dev.IO_Base,
            NE2000Dev.irq_num,
            NE2000Dev.mac_addr,
            @NE2000_SendPacket,
            nil
          );
        end;
      end
      
      // 3. Tan�nmayan/S�r�c�s� Yaz�lmam�� A� Kart�
      else
      begin
        // Burada cihaz�n Ethernet oldu�unu bildi�iniz halde s�r�c�s� olmad���n� raporlayabilirsiniz:
        // System.Log('Bilinmeyen A� Kart� Bulundu: Vendor=' + Hex(Dev^.VendorID) + ' Device=' + Hex(Dev^.DeviceID));
      end;

    end;

    Dev := Dev^.Next;
  end;
end;


procedure RegisterNetAdapter(AType: TNetAdapterType; AIOBase: Word; AIRQ: Byte;
  AMac: array of Byte; ASendProc: TSendPacketProc; ARecvFunc: TReceivePacketFunc);
begin
  if NetAdapterCount >= MAX_NET_ADAPTERS then Exit;

  with NetAdapters[NetAdapterCount] do
  begin
    Active := True;
    AdapterType := AType;
    IO_Base := AIOBase;
    IRQ := AIRQ;
    Move(AMac[0], MacAddr[0], 6);
    SendPacket := ASendProc;
    ReceivePacket := ARecvFunc;
  end;

  Inc(NetAdapterCount);
end;


procedure BroadcastSend(AdapterIndex: Integer; Data: PByteArray; Len: Integer);
begin
  if (AdapterIndex >= 0) and (AdapterIndex < NetAdapterCount) then
  begin
    if Assigned(NetAdapters[AdapterIndex].SendPacket) then
      NetAdapters[AdapterIndex].SendPacket(Data, Len);
  end;
end;


procedure PollAllAdapters;
var
  i: Integer;
begin
  for i := 0 to NetAdapterCount - 1 do
  begin
    if NetAdapters[i].Active and Assigned(NetAdapters[i].ReceivePacket) then
    begin
      NetAdapters[i].ReceivePacket();
    end;
  end;
end;

function GetMacAddr(out SrcMacAddr: array of byte):Boolean;
begin
  Move(NetAdapters[NetAdapterIndex].MacAddr[0], SrcMacAddr[0], 6);
  Result:=True;
end;







end.
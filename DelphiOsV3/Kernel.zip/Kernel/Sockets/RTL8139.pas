unit RTL8139;

interface

uses
  SysUtils,IDT,Ports,Pci,WinSocket, Memory, Fat32;

  const
  TSAD_array: array[0..3] of Byte = ($20, $24, $28, $2C);
  TSD_array: array[0..3] of Byte = ($10, $14, $18, $1C);



 type
  TRTL8139Receive=Procedure();
  TRTL8139Dev = record
    Active: Boolean;
    bar_type: Byte;
    IO_Base: Word;
    mem_base: LongWord;
    eeprom_exist: Integer;
    mac_addr: array[0..5] of Byte;
    rx_buffer: array[0..8192 + 16 + 1500 - 1] of Byte;
    tx_cur: Integer;
    Irq_Num: Byte;
    UsePolling: Boolean;
  end;
  PRTL8139Dev = ^TRTL8139Dev;



var
  RTL8139Dev:TRTL8139Dev;
  current_packet_ptr: Integer = 0;
  current_packet_ptr1: Integer = 0;



  function  RTL8139_Init(Dev: PPciDevice):Boolean;
  function RTL8139ReceivePacket():Boolean;
  procedure RTL8139SendPacket(data:PByteArray; len:Integer);
 
 

implementation

function htonl(hostlong: LongWord): LongWord;
begin
  Result :=
      ((hostlong and $ff) shl 24)
          or ((hostlong and $ff00) shl 8)
          or ((hostlong and $ff0000) shr 8)
          or ((hostlong and $ff000000) shr 24);
end;

function ntohl(Value: LongWord): LongWord;
begin
  Result :=
      ((Value and $FF000000) shr 24)
          or ((Value and $00FF0000) shr 8)
          or ((Value and $0000FF00) shl 8)
          or ((Value and $000000FF) shl 24);
end;

function htons(hostshort: Word): Word;
begin
  Result := ((hostshort and $FF) shl 8) or ((hostshort and $FF00) shr 8);
end;

function ntohs(netshort: Word): Word;
begin
  Result := htons(netshort);
end;

function PCharToIP(ip: pchar): LongWord;
var
  octets: array[0..3] of Byte;
  i, j, octetValue: Integer;
begin
  j := 0;
  for i := 0 to 3 do begin
    octetValue := 0;
    while (ip[j] <> #0) and (ip[j] <> '.') do begin
      octetValue := octetValue * 10 + (Ord(ip[j]) - Ord('0'));
      Inc(j);
    end;
    Inc(j); // '.' karakterini ge 
    octets[i] := octetValue;
  end;

  // Oktetleri birle tir
  Result := (octets[0] shl 24) or (octets[1] shl 16) or (octets[2] shl 8) or octets[3];

end;




procedure ReadMacAddr;
var
  mac_part1: DWord;
  mac_part2: Word;
begin
  mac_part1 :=ReadPortD(RTL8139Dev.io_base + $00);
  mac_part2 := ReadPortW(RTL8139Dev.io_base + $04);
  RTL8139Dev.mac_addr[0] := mac_part1 and $FF;
  RTL8139Dev.mac_addr[1] := (mac_part1 shr 8) and $FF;
  RTL8139Dev.mac_addr[2] := (mac_part1 shr 16) and $FF;
  RTL8139Dev.mac_addr[3] := (mac_part1 shr 24) and $FF;
  RTL8139Dev.mac_addr[4] := mac_part2 and $FF;
  RTL8139Dev.mac_addr[5] := (mac_part2 shr 8) and $FF;
end;









function RTL8139ReceivePacket():Boolean;
var
  RX_Buffer: PByte;
  packetstatus: Word;
  packetlength: Word;
  packet: array[0..1518-1] of Byte;
  EthHeader: TEthernetHeader;

  ip_header_length: Integer;
  tcp_header_length: Integer;

  data_offset, data_length: Integer;

  IPHeader:TIPHeader;
  TCPHeader:TTCPHeader;
  UDPHeader:TUDPHeader;
begin
  Result:=False;



  while((ReadPortB(RTL8139Dev.io_base + $37) and (1 shl 0)) = 0) do
  begin

  // RX buffer'daki mevcut konumu g steren pointer'  ayarla
   RX_Buffer :=@RTL8139Dev.rx_buffer[current_packet_ptr];

  // Paket durumu ve uzunlu unu oku
  packetStatus := PWord(RX_Buffer)^; //  lk 2 byte paket durumu
  Inc(RX_Buffer, 2);
  packetLength := PWord(RX_Buffer)^; // Sonraki 2 byte paket uzunlu u
  Inc(RX_Buffer, 2);


   // Paket boyutunu s n rland r
  if packetlength > 1518 then
    packetlength := 1518;


  FillChar(packet,SizeOf(Packet),#0);
  // Paket verilerini `packet` dizisine kopyala
  Move(RX_Buffer^, packet[0], packetlength);

  ParsePacket(packet,packetlength);

 


// current_packet_ptr'  g ncelle
  current_packet_ptr := (current_packet_ptr + packetlength + 4 + 3) and (not 3); // $FFFF;
  if current_packet_ptr > 8192 then
    current_packet_ptr := current_packet_ptr - 8192;

  // RTL8139'un CAPR (Current Address of Packet Read) register' n  g ncelle
  WritePortW(RTL8139Dev.io_base + $38, current_packet_ptr - 16);

  WritePortW(RTL8139Dev.io_base + $3E, 1);
  ReadPortW(RTL8139Dev.io_base + $3E);
  Result:=True;
  end;

end;


procedure RTL8139SendPacket(data:PByteArray; len:Integer);
var
   transfer_data:array[0..1518-1] of byte;
   transfer_address: Dword;
begin
  if len< 1518 then
  begin

    FillChar(transfer_data,SizeOf(transfer_data),#0);
    Move(data[0], transfer_data[0], len);
    transfer_address := Dword(@transfer_data);

    WritePortD(RTL8139Dev.io_base + TSAD_array[RTL8139Dev.tx_cur], transfer_address);
    WritePortD(RTL8139Dev.io_base + TSD_array[RTL8139Dev.tx_cur],len);


    Inc(RTL8139Dev.tx_cur);
    if RTL8139Dev.tx_cur > 3 then
       RTL8139Dev.tx_cur := 0;
  end;


end;





procedure RTL8139Handler;
var
  Status: Word;
begin
  Status := ReadPortW(RTL8139Dev.io_base + $3E);
  WritePortW(RTL8139Dev.io_base + $3E, $05);
  // Paket g nderim durumunu kontrol et
  if (status and $04) <> 0 then
  begin
    //Paketmsg := 'Paket g nderildi';

  end;

  // Paket al m durumunu kontrol et
  if (status and $01) <> 0 then
  begin
   // Paketmsg := 'Paket alindi';



    if RTL8139Dev.Active then
    begin
     // if not RTL8139Dev.UsePolling then
       //  RTL8139ReceivePacket();
       RTL8139Dev.UsePolling := True;
    end;
  end;

 // RTL8139Dev.UsePolling := False;
end;


function FindRTL8139Device: PPciDevice;
var
  Dev: PPciDevice;
begin
  Dev := PciDeviceList;
  while Dev <> nil do
  begin
    if (Dev^.VendorID = $10EC) and (Dev^.DeviceID = $8139) then
    begin
      Result := Dev;
      Exit;
    end;
    Dev := Dev^.Next;
  end;
  Result := nil;
end;






function  RTL8139_Init(Dev: PPciDevice):Boolean;
var
 // Dev: PPciDevice;
  IOBase: Word;
  IRQ: Byte;
  str:pchar;
  ConfigData: DWord;
begin
   Result:=False;
 // Dev := FindRTL8139Device;
  if Dev = nil then Exit;

  FillChar(RTL8139Dev, SizeOf(TRTL8139Dev), #0);
  RTL8139Dev.io_base := Dev^.Bars[0] and $FFFC;
  RTL8139Dev.irq_num := Dev^.IRQ;

  ConfigData := ReadPCIConfigDword(Dev^.Bus, Dev^.Dev, Dev^.Func, $04);
  if (ConfigData and (1 shl 2)) = 0 then
  begin
    ConfigData := ConfigData or (1 shl 2);
    WritePCIConfigDword(Dev^.Bus, Dev^.Dev, Dev^.Func, $04, ConfigData);
  end;

    WritePortB(RTL8139Dev.io_base + $52, $0);
    WritePortB(RTL8139Dev.io_base + $37, $10);

    while (ReadPortB(RTL8139Dev.io_base + $37) and $10) <> 0 do ; // Do nothing here...


    FillChar(RTL8139Dev.rx_buffer, SizeOf(RTL8139Dev.rx_buffer), #0);
    WritePortD(RTL8139Dev.io_base + $30, DWord(@RTL8139Dev.rx_buffer));

    WritePortD(RTL8139Dev.io_base + $38, 0);
    WritePortD(RTL8139Dev.io_base + $3A, 0);

    WritePortW(RTL8139Dev.io_base + $3C, $0005); // TOK ve ROK bitlerini ayarla
    WritePortD(RTL8139Dev.io_base + $44, $F or (1 shl 7)); // WRAP bit
    WritePortB(RTL8139Dev.io_base + $37, $0C); // RE ve TE bitlerini ayarla



    RegisterISR(32 + RTL8139Dev.irq_num, @RTL8139Handler);
    
    ReadMacAddr;
    RTL8139Dev.Active:=True;
    Result:=True;
  
end;





end.

unit NE2000;

interface

uses
  SysUtils,IDT,Ports,Pci,WinSocket, Memory, Fat32;

const
  REG_CR       = 0;   // Command Register
  REG_PSTART   = 1;   // Page Start Register (Receive Buffer Start Page)
  REG_PSTOP    = 2;   // Page Stop Register (Receive Buffer End Page)
  REG_BNRY     = 3;   // Boundary Pointer (Receive buffer's read pointer)
  REG_TSR      = 4;   // Transmit Status Register
  REG_TPSR     = 4;   // Transmit Page Start Register
  REG_TBCR0    = 5;   // Transmit Byte Count Register 0 (low byte)
  REG_NCR      = 5;   // Number of Collisions Register (read-only)
  REG_TBCR1    = 6;   // Transmit Byte Count Register 1 (high byte)
  REG_ISR      = 7;   // Interrupt Status Register
  REG_CURR     = 7;   // Current Page Register (page 1)
  REG_RSAR0    = 8;   // Remote Start Address Register 0
  REG_RDMA0    = 8;   // DMA port (read/write)
  REG_RSAR1    = 9;   // Remote Start Address Register 1
  REG_RDMA1    = 9;
  REG_RBCR0    = 10;  // Remote Byte Count Register 0
  REG_RBCR1    = 11;  // Remote Byte Count Register 1
  REG_RSR      = 12;  // Receive Status Register
  REG_RCR      = 12;  // Receive Configuration Register
  REG_TCR      = 13;  // Transmit Configuration Register
  REG_TALLY_FAE= 13;  // Tally counter for FAE errors
  REG_DCR      = 14;  // Data Configuration Register
  REG_TALLY_CRC= 14;  // Tally counter for CRC errors
  REG_IMR      = 15;  // Interrupt Mask Register
  REG_TALLY_MISS=15;  // Tally counter for missed packets

  REG_IOPORT   = 16;  // IO base offset (not used as register)

  NE_RESET     = $1F; // Reset port offset (used to reset card)
  NE_DATA      = $10; // Data port offset (DMA data transfer)

  TX_BUFFER_PAGE = $40;  // Transmit buffer page (where TX begins)
  RX_PAGE_START  = $46;  // Start page of receive buffer
  RX_PAGE_STOP   = $80;  // End page of receive buffer

  DCR= $58;

  REG_PAR0 = $01;



  E8390_STOP =1;
  E8390_START =2;
  E8390_TRANS =4;
  E8390_RREAD =8;
  E8390_RWRITE =$10;
  E8390_NODMA=$20;

  E8390_PAGE0	=$00;

  E8390_PAGE1	=$40;
  E8390_PAGE2	=$80;


type

  TNE2000Dev = record
    Active: Boolean;
    IO_Base: Word;
    Irq_Num: Byte;
    mac_addr: TMacAddress;
    NextPacket: LongInt;
    NextRXPage: Byte;
  end;





var

  NE2000Dev: TNE2000Dev;


  function NE2000_Init(Dev: PPciDevice):Boolean;
  procedure NE2000_SendPacket(Data: PByteArray; Length: Integer);
  function NE2000_ReceivePacket(): Word;


implementation


procedure NE2000_SendPacket(Data: PByteArray; Length: Integer);

var
 I: LongInt;
begin

  WritePortB(NE2000Dev.IO_Base+REG_RBCR0 , Length and $ff );
  WritePortB(NE2000Dev.IO_Base+REG_RBCR1, Length shr 8);
  WritePortB(NE2000Dev.IO_Base+REG_RSAR0, 0);
  WritePortB(NE2000Dev.IO_Base+REG_RSAR1,TX_BUFFER_PAGE);
  WritePortB(NE2000Dev.IO_Base+REG_CR, E8390_RWRITE or E8390_START);

  // TODO : we are not checking if the packet size is longer that the buffer!!
  for I := 0 to (Length-1) do
    WritePortB(NE2000Dev.IO_Base+NE_DATA, Data[I]);

  WritePortB(NE2000Dev.IO_Base+REG_TPSR, TX_BUFFER_PAGE);
  WritePortB(NE2000Dev.IO_Base+REG_TBCR0, Length);
  WritePortB(NE2000Dev.IO_Base+REG_TBCR1, Length shr 8);
  WritePortB(NE2000Dev.IO_Base+REG_CR,E8390_NODMA or E8390_TRANS or E8390_START);
end;





function NE2000_ReceivePacket(): Word;
var
  Curr: Byte;
  Data: Array[0..MaxPacketSize-1] of byte;
  rsr, Next, Count, Len: LongInt;

begin
  WritePortB(NE2000Dev.IO_Base+REG_CR ,E8390_START or E8390_NODMA or $40);
  curr := ReadPortB(NE2000Dev.IO_Base+REG_CURR);
  WritePortB(NE2000Dev.IO_Base+REG_CR ,E8390_START or E8390_NODMA);


  while curr <> NE2000Dev.NextPacket do
  begin
    WritePortB( NE2000Dev.IO_Base+REG_RBCR0,4);
    WritePortB(NE2000Dev.IO_Base+REG_RBCR1,0);
    WritePortB( NE2000Dev.IO_Base+REG_RSAR0,0);
    WritePortB(NE2000Dev.IO_Base+REG_RSAR1, NE2000Dev.NextPacket);
    WritePortB(NE2000Dev.IO_Base+REG_CR,E8390_RREAD or E8390_START);
    rsr:= ReadPortB(NE2000Dev.IO_Base+NE_DATA);
    Next:= ReadPortB(NE2000Dev.IO_Base+NE_DATA);
    Len:= ReadPortB(NE2000Dev.IO_Base+NE_DATA);
    Len:= Len + ReadPortB(NE2000Dev.IO_Base+NE_DATA) shl 8;
    Len := Len - 4;
    WritePortB(NE2000Dev.IO_Base+REG_ISR,$40);
    if (rsr and 31 = 1) and (Next >= RX_PAGE_START) and (Next <= RX_PAGE_STOP) and (Len <= 1532) then
    begin


        WritePortB(NE2000Dev.IO_Base+REG_RBCR0,Len );
        WritePortB(NE2000Dev.IO_Base+REG_RBCR1, Len shr 8);
        WritePortB(NE2000Dev.IO_Base+REG_RSAR0, 4);
        WritePortB(NE2000Dev.IO_Base+REG_RSAR1, NE2000Dev.NextPacket);
        WritePortB( NE2000Dev.IO_Base+REG_CR,E8390_RREAD or E8390_START);
        for Count := 0 to Len-1 do
          Data[Count] := ReadPortB(NE2000Dev.IO_Base+NE_DATA);

         ParsePacket(Data,Len);


      WritePortB(NE2000Dev.IO_Base+REG_ISR,$40 );
      if Next = RX_PAGE_STOP then
        NE2000Dev.NextPacket := RX_PAGE_START
      else
        NE2000Dev.NextPacket := Next;
     ParsePacket(Data,Len);
    end;
    if NE2000Dev.NextPacket = RX_PAGE_START then
      WritePortB(NE2000Dev.IO_Base+REG_BNRY, RX_PAGE_STOP-1)
    else
      WritePortB(NE2000Dev.IO_Base+REG_BNRY,NE2000Dev.NextPacket-1 );

    WritePortB(NE2000Dev.IO_Base+REG_CR,E8390_START or E8390_NODMA or $40 );
    curr := ReadPortB(NE2000Dev.IO_Base+REG_CURR);
    WritePortB(NE2000Dev.IO_Base+REG_CR ,E8390_START or E8390_NODMA);
  end;
end;








procedure NE2000_IRQHandler;
var
  status: Byte;
begin

  // ISR register'  oku (hangi olay kesme olu turmu ?)
  status := ReadPortB(NE2000Dev.IO_Base + $07);


  // PRX: Receive Packet
  if ((status and $01) <> 0)   then
  begin
     WritePortB(NE2000Dev.IO_Base + $07,status);
     if   NE2000Dev.Active then

    NE2000_ReceivePacket; // Paket al ve i le
  //  WriteLn1('Paket al nd ');

  end;

  // PTX: Packet Transmitted
  if (status and $02) <> 0 then
  begin
      WritePortB(NE2000Dev.IO_Base + $07, status);
    //  WriteLn1('Paket g derildi');
    // Gerekirse log veya bayrak koy: paket g nderimi tamam
  end;

  // RXE: Receive Error
  if (status and $04) <> 0 then
  begin
    // Hata durumlar n  logla
   // WriteLn1('Receive Error');
  end;

  // TXE: Transmit Error
  if (status and $08) <> 0 then
  begin
    // G nderim hatas 
    // WriteLn1('Transmit Error');
  end;

  // OVW: FIFO overflow
  if (status and $40) <> 0 then
  begin
    //  ok h zl  al m   FIFO ta t 
    //WriteLn1('FIFO overflow');

  end;



end;


function FindNE2000Device: PPciDevice;
var
  Dev: PPciDevice;
begin
  Dev := PciDeviceList;
  while Dev <> nil do
  begin
    if ((Dev^.VendorID = $1050) and (Dev^.DeviceID = $0940)) or
       ((Dev^.VendorID = $10EC) and (Dev^.DeviceID = $8029)) then
    begin
      Result := Dev;
      Exit;
    end;
    Dev := Dev^.Next;
  end;
  Result := nil;
end;



function NE2000_Init(Dev: PPciDevice):Boolean;
var
  ConfigData: DWord;
  I: LongInt;
  Buffer: array[0..31] of Byte;
  //Dev: PPciDevice;
begin
  Result:=False;

 // Dev := FindNE2000Device;
  if Dev = nil then Exit;
  FillChar(NE2000Dev, SizeOf(NE2000Dev), #0);

  NE2000Dev.IO_Base := Dev^.Bars[0] and $FFFC;
  NE2000Dev.irq_num := Dev^.IRQ;

  WritePortB(NE2000Dev.IO_Base + NE_RESET, ReadPortB(NE2000Dev.IO_Base + NE_RESET));
  while (ReadPortB(NE2000Dev.IO_Base + REG_ISR) and $80) = 0 do ;

  WritePortB(NE2000Dev.IO_Base + REG_ISR, $FF);
  WritePortB(NE2000Dev.IO_Base + REG_CR, $21);
  WritePortB(NE2000Dev.IO_Base + REG_DCR, dcr);
  WritePortB(NE2000Dev.IO_Base + REG_RBCR0, $20);
  WritePortB(NE2000Dev.IO_Base + REG_RBCR1, 0);
  WritePortB(NE2000Dev.IO_Base + REG_RSAR0, 0);
  WritePortB(NE2000Dev.IO_Base + REG_RSAR1, 0);
  WritePortB(NE2000Dev.IO_Base + REG_CR, E8390_RREAD or E8390_START);
  WritePortB(NE2000Dev.IO_Base + REG_RCR, $0E);
  WritePortB(NE2000Dev.IO_Base + REG_TCR, 4);

  for I := 0 to 31 do
      Buffer[I] := ReadPortB(NE2000Dev.IO_Base + REG_IOPORT);

  WritePortB(NE2000Dev.IO_Base + REG_TPSR, $40);
  WritePortB(NE2000Dev.IO_Base + REG_PSTART, $46);
  WritePortB(NE2000Dev.IO_Base + REG_BNRY, $46);
  WritePortB(NE2000Dev.IO_Base + REG_PSTOP, $60);
  WritePortB(NE2000Dev.IO_Base + REG_IMR, $1F);
  WritePortB(NE2000Dev.IO_Base + REG_CR, $61);
  WritePortB(NE2000Dev.IO_Base + REG_CR, $61);

  WritePortB(NE2000Dev.IO_Base + REG_CR + $1, Buffer[0]);
  WritePortB(NE2000Dev.IO_Base + REG_CR + $2, Buffer[2]);
  WritePortB(NE2000Dev.IO_Base + REG_CR + $3, Buffer[4]);
  WritePortB(NE2000Dev.IO_Base + REG_CR + $4, Buffer[6]);
  WritePortB(NE2000Dev.IO_Base + REG_CR + $5, Buffer[8]);
  WritePortB(NE2000Dev.IO_Base + REG_CR + $6, Buffer[10]);

  for I := $8 to $F do
     WritePortB(NE2000Dev.IO_Base + REG_CR + I, $FF);

  for I := 0 to 5 do
     NE2000Dev.mac_addr[I] := Buffer[I * 2];

  WritePortB(NE2000Dev.IO_Base + REG_DCR, dcr);
  NE2000Dev.NextPacket := RX_PAGE_START + 1;
  WritePortB(NE2000Dev.IO_Base + REG_CURR, NE2000Dev.NextPacket);
  WritePortB(NE2000Dev.IO_Base + REG_CR, $22);
  WritePortB(NE2000Dev.IO_Base + REG_TCR, 0);
  WritePortB(NE2000Dev.IO_Base + REG_RCR, $0C);

 

  RegisterISR(32 + NE2000Dev.irq_num, @NE2000_IRQHandler);
         
  NE2000Dev.Active :=True;
  Result:=True;
 



end;



end.
Program UPaint;

Uses
  UserGUI,Draw32;
{$R test.RES}

const
  alNone   = 0;
  alTop    = 1;
  alBottom = 2;
  alLeft   = 3;
  alRight  = 4;
  alClient = 5;

var
  Form: Pointer;
  Pnl: LongWord;
  BtnClose: LongWord;
  LblTitle: LongWord;
  EdInput: LongWord;
  Msg: TMessage;
  dst:Integer=0;

function Add(a, b: Integer): Integer;  stdcall; external 'kernel.dll';


procedure TestPint(X,Y,C:LongWord); stdcall;
asm
 Mov eax,200
 Mov eBX,X
 Mov eCX,Y
 Mov eDX,C
 int $80
end;


procedure MyWndProc(hWnd: HWND; Msg: LongWord; WParam, LParam: LongWord);
var
 Buff:array[0..31] of Char;
 I,X,Y:Integer;
begin
  case Msg of
    WM_PAINT:begin
       X:=SmallInt(LParam and $FFFF);
       Y:=SmallInt((LParam shr 16) and $FFFF);

       KPanel3D(X+10,Y+10,50,50,True,$808080); 
    end;


     WM_COMMAND:
      begin
        { LParam = tiklanan butonun kernel handle'i }
        if LParam = BtnClose then
        begin
        dst:= Add(15,6);      //   ScreenW ;//
        IntToPChar(dst,@Buff[0]);

        EditSetText(EdInput,@Buff[0]);

      //  KStr(500,50,'EKREM KOCAK',$ffffff);

          // TestPint(100,100,$FF00FF);
          { BtnClose tiklandi }
          //ExitProcess(0);
        end;
        { Diger butonlar icin else-if zinciri kurabilirsiniz }
      end;
    
    WM_KEYDOWN:
      if WParam = 27 then ExitProcess(0);  { ESC }
    
    WM_CLOSE:
      ExitProcess(0);
  end;
end;

begin
  MainWndProc := @MyWndProc;

  { 1. Form olustur (kernel'da) }
  Form := CreateForm( 120, 100, 500, 350);

  { 2. Panel ekle (kernel'da) }
  Pnl := CreatePanel(LongWord(Form), 20, 60, 460, 200, alNone);

  { 3. Label ekle (kernel'da) }
  LblTitle := CreateLabel(LongWord(Form), 'Kernel Bilesen Testi', 
                          20, 25, 300, 24, alNone);



  { 4. Buton ekle (kernel'da) }
  BtnClose := CreateButton(LongWord(Form), 'Kapat', 
                           200, 280, 100, 32, alNone);

  { 5. Edit ekle (kernel'da) }
  EdInput := CreateEdit(LongWord(Form),
                        20, 280, 160, 24, alNone);




  { 6. Mesaj dongusu }
  while True do
  begin
    if GetMessage(Msg) then
      DispatchMessage(Msg);
  end;
end.

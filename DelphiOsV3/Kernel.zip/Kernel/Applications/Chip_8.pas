Program Chip_8;

{$IMAGEBASE $00010000}


Uses
  UserGUI,Draw32;




const
  MemorySize   = $FFF;
  ROMSize      = MemorySize - $200;
  StackSize    = $10; //16
  ClockTick    = 1000 div 60;

  ScreenWidth  = 64;
  ScreenHeight = 32;

  // array of character sprites
  Font : array [0 .. $4F] of Byte
        = ($F0, $90, $90, $90, $F0,  // 0
           $20, $60, $20, $20, $70,  // 1
           $F0, $10, $F0, $80, $F0,  // 2
           $F0, $10, $F0, $10 ,$F0,  // 3
           $90, $90, $F0, $10, $10,  // 4
           $F0, $80, $F0, $10, $F0,  // 5
           $F0, $80, $F0, $90, $F0,  // 6
           $F0, $10, $20, $40, $40,  // 7
           $F0, $90, $F0, $90 ,$F0,  // 8
           $F0, $90, $F0, $10, $F0,  // 9
           $F0, $90, $F0, $90, $90,  // A
           $E0, $90, $E0, $90, $E0,  // B
           $F0, $80, $80, $80, $F0,  // C
           $E0, $90, $90, $90, $E0,  // D
           $F0, $80, $F0, $80, $F0,  // E
           $F0, $80, $F0, $80, $80); // F

type
  Chip8ROM = array [0 .. ROMSize] of Byte;

  PChip8=^TChip8;
  TChip8 = object
    private

      Registers : array [0..$F] of Byte; //16 8-bit (one byte) general-purpose variable registers
      RegisterI : 0..$FFF;
      Memory    : array [0..MemorySize] of Byte;
      //PC        : 0..MemorySize;
      PC        : Word; //temporary
      Stack     : array [0..StackSize-1] of Word;
      SP        : Integer;  // stack pointer, 0..StackSize



      FDisplay  : array[0..ScreenHeight-1, 0..ScreenWidth-1] of Byte;

      // decoded opcode fields
      FOpcode : Word;
      FOpX    : Byte;
      FOpY    : Byte;
      FOpNNN  : Word;
      FOpKK   : Byte;
      FOpN    : Byte;

      Keys           : array[0..$F] of Boolean;
      FWaitingForKey : Boolean;
      FWaitingRegX   : Byte;
      FWaitKey       : Integer;  // -1 = none, 0..15 = key being waited on

      procedure DrawSprite(VxIndex, VyIndex, N: Byte);

    public
     
      Width,Height:Integer;
      DelayTimer, SoundTimer : Byte;
      Running:boolean;
      procedure Init(ROM: Chip8ROM);
      procedure Destroy;

      procedure Fetch;
      procedure Decode;
      procedure Execute;
      procedure TickTimers;

      procedure KeyDown(Key: Byte);
      procedure KeyUp(Key: Byte);
      function  IsKeyDown(Key: Byte): Boolean;
      property  WaitingForKey: Boolean read FWaitingForKey;

      procedure ClearDisplay;
      function PixelOn(X, Y: Integer): Boolean;
  end;


var
  Chip8        : TChip8;
  ThreadHandle : Integer;
  Msg          : TMessage;
  Form         : LongWord;

function _Random(MaxRand: Integer): Integer;  
begin
  Rand := Rand * 1103515245 + 12345;
  Result := abs((Rand div 65536) mod MaxRand);
end;



procedure FillChar(var Dest; Count: Integer; Value: Char);
var
  I: Integer;
  P: PChar;
begin
  P := PChar(@Dest);
  for I := 0 to Count - 1 do
    P[I] := Value;
end;

procedure Move(const Source; var Dest; count: Integer);
var
  S, D: PChar;
  I: Integer;
begin
  S := PChar(@Source);
  D := PChar(@Dest);
  if S = D then
    Exit;
  if Cardinal(D) > Cardinal(S) then
    for I := count - 1 downto 0 do
      D[I] := S[I]
  else
    for I := 0 to count - 1 do
      D[I] := S[I];
end;




procedure TChip8.Init(ROM: Chip8ROM);
var
   I : Integer;
begin
   

   RegisterI := 0;
   DelayTimer := 0;
   SoundTimer := 0;
   PC := $200;
   SP := 0;

   for I := Low (Font) to High (Font) do
      Memory [I] := Font [I];

   for I := Low (ROM) to High (ROM) do
      Memory [I + $200] := ROM[I];

      // clear the key array
   for I := 0 to $F do
      Keys[I] := False;

   FWaitingForKey := False;
   FWaitingRegX   := 0;
   FWaitKey       := -1;

   ClearDisplay;
end;

procedure TChip8.Destroy;
begin

end;

procedure TChip8.Fetch;
var
  Hi, Lo: Byte;
begin
  // Fetch 16-bit opcode from memory at PC, big endian
  Hi := Memory[PC];
  Lo := Memory[PC + 1];

  FOpcode := (Hi shl 8) or Lo;

  // advance PC to next instruction
  PC := PC + 2;
end;

procedure TChip8.Decode;
begin
  // Pre-decode commonly used fields
  FOpNNN := FOpcode and $0FFF;
  FOpKK  := FOpcode and $00FF;
  FOpN   := FOpcode and $000F;
  FOpX   := (FOpcode and $0F00) shr 8;
  FOpY   := (FOpcode and $00F0) shr 4;
end;

procedure TChip8.Execute;
var
  r, v, i: Integer;
  vx, vy, res, flag: Integer;
begin
  case FOpcode and $F000 of

    $0000:
      begin
        case FOpcode of
          $00E0:
            // 00E0 - CLS (clear screen)
            ClearDisplay;
            // RET - pop the saved PC and resume execution from here
          $00EE:
            begin
              if SP > 0 then
              begin
                Dec(SP);
                PC := Stack[SP];
              end
              else
              begin
                // underflow: do nothing or raise error; ignoring for now
              end;
            end;
        end;
      end;

    $1000:
      begin
        // 1nnn - JP addr
        PC := FOpNNN;
      end;

    $2000:
      begin
        // 2nnn - CALL addr
        if SP < StackSize then
        begin
          Stack[SP] := PC;   // PC already points to next instruction
          Inc(SP);
          PC := FOpNNN;
        end
        else
        begin
          // overflow: ignore or raise; we just ignore for now
        end;
      end;

    $3000:
      begin
        // 3xkk - SE Vx, byte
        if Registers[FOpX] = FOpKK then
          PC := PC + 2;
      end;

    $4000:
      begin
        // 4xkk - SNE Vx, byte
        if Registers[FOpX] <> FOpKK then
          PC := PC + 2;
      end;

    $5000:
      begin
        // 5xy0 - SE Vx, Vy
        if (FOpcode and $000F) = 0 then
          if Registers[FOpX] = Registers[FOpY] then
            PC := PC + 2;
      end;

    $6000:
      begin
        // 6xnn - LD Vx, byte
        Registers[FOpX] := FOpKK;
      end;

    $7000:
      begin
        // 7xkk - ADD Vx, byte (no carry)
        Registers[FOpX] := (Registers[FOpX] + FOpKK) and $FF;
      end;

    $8000:
      case (FOpcode and $000F) of

        $0:  // 8xy0 - LD Vx, Vy
          begin
            Registers[FOpX] := Registers[FOpY];
            // VF untouched
          end;

        $1:  // 8xy1 - OR Vx, Vy
          begin
            Registers[FOpX] := Registers[FOpX] or Registers[FOpY];
            Registers[$F]   := 0;  // Timendus expects VF reset
          end;

        $2:  // 8xy2 - AND Vx, Vy
          begin
            Registers[FOpX] := Registers[FOpX] and Registers[FOpY];
            Registers[$F]   := 0;
          end;

        $3:  // 8xy3 - XOR Vx, Vy
          begin
            Registers[FOpX] := Registers[FOpX] xor Registers[FOpY];
            Registers[$F]   := 0;
          end;

        $4:  // 8xy4 - ADD Vx, Vy (with carry)
          begin
            vx := Registers[FOpX];
            vy := Registers[FOpY];

            res := vx + vy;
            if res > $FF then
              flag := 1
            else
              flag := 0;

            if FOpX <> $F then
              Registers[FOpX] := Byte(res and $FF);

            Registers[$F] := flag;
          end;

        $5:  // 8xy5 - SUB Vx, Vy (Vx = Vx - Vy)
          begin
            vx := Registers[FOpX];
            vy := Registers[FOpY];

            // "No borrow" uses >=, even when result is 0
            if vx >= vy then
              flag := 1
            else
              flag := 0;

            res := (vx - vy) and $FF;

            if FOpX <> $F then
              Registers[FOpX] := Byte(res);

            Registers[$F] := flag;
          end;

        $6:  // 8xy6 - SHR Vx (modern: shift Vx)
          begin
            vx   := Registers[FOpX];
            flag := vx and $1;          // old bit 0
            res  := vx shr 1;

            if FOpX <> $F then
              Registers[FOpX] := Byte(res);

            Registers[$F] := flag;
          end;

        $7:  // 8xy7 - SUBN Vx, Vy (Vx = Vy - Vx)
          begin
            vx := Registers[FOpX];
            vy := Registers[FOpY];

            if vy >= vx then
              flag := 1
            else
              flag := 0;

            res := (vy - vx) and $FF;

            if FOpX <> $F then
              Registers[FOpX] := Byte(res);

            Registers[$F] := flag;
          end;

        $E:  // 8xyE - SHL Vx (modern: shift Vx)
          begin
            vx   := Registers[FOpX];
            flag := (vx shr 7) and $1;       // old bit 7
            res  := (vx shl 1) and $FF;

            if FOpX <> $F then
              Registers[FOpX] := Byte(res);

            Registers[$F] := flag;
          end;
        
      end;

    $9000:
      begin
        // 9xy0 - SNE Vx, Vy
        if (FOpcode and $000F) = 0 then
        begin
          if Registers[FOpX] <> Registers[FOpY] then
            PC := PC + 2;
        end;
      end;

    $A000:
      begin
        // Annn - LD I, addr
        RegisterI := FOpNNN;
      end;

    $C000:  // Cxkk - RND Vx, byte
      begin
        r := _Random(256);  // 0..255
        Registers[FOpX] := Byte(r and FOpKK);
      end;

    $D000:
      begin
        // Dxyn - DRW Vx, Vy, nibble
        DrawSprite(FOpX, FOpY, FOpN);
      end;

    $E000:
      case (FOpcode and $00FF) of
        $9E:  // Ex9E - SKP Vx
          begin
            if IsKeyDown(Registers[FOpX]) then
              PC := PC + 2;
          end;

        $A1:  // ExA1 - SKNP Vx
          begin
            if not IsKeyDown(Registers[FOpX]) then
              PC := PC + 2;
          end;
      end;

    $F000:
      case (FOpcode and $00FF) of
        $07:  // Fx07 - LD Vx, DT
          Registers[FOpX] := DelayTimer;

        $0A:  // Fx0A - LD Vx, K (wait for key)
          begin
            // Just start waiting; don't read any key state here
            FWaitingForKey := True;
            FWaitingRegX   := FOpX;
            // IMPORTANT: do NOT change PC here
            // PC already points to the *next* instruction after Fx0A
            // and we want to resume there once a key is pressed.
          end;

        $15:  // Fx15 - LD DT, Vx
          DelayTimer := Registers[FOpX];

        $18:  // Fx18 - LD ST, Vx
          SoundTimer := Registers[FOpX];

        $1E:  // Fx1E - ADD I, Vx
          RegisterI := (RegisterI + Registers[FOpX]) and $0FFF;  // keep I 12-bit

        $29:  // Fx29 - LD F, Vx (font sprite for digit Vx)
          // each digit is 5 bytes, starting at 0
          RegisterI := (Registers[FOpX] and $0F) * 5;

        $33:  // Fx33 - BCD of Vx at [I], [I+1], [I+2]
          begin
            v := Registers[FOpX];
            Memory[RegisterI + 2] := Byte(v mod 10);
            Memory[RegisterI + 1] := Byte((v div 10) mod 10);
            Memory[RegisterI]     := Byte((v div 100) mod 10);
          end;

        $55:  // Fx55 - LD [I], V0..Vx
          begin
            for i := 0 to FOpX do
              Memory[RegisterI + i] := Registers[i];
            // original CHIP-8 increments I; many modern emus do too:
            RegisterI := RegisterI + FOpX + 1;
          end;

        $65:  // Fx65 - LD V0..Vx, [I]
          begin
            for i := 0 to FOpX do
              Registers[i] := Memory[RegisterI + i];
            RegisterI := RegisterI + FOpX + 1;
          end;
  end;

  else
    // Unimplemented opcodes are just ignored for now
    // (PC already advanced in Fetch)
  end;
end;

procedure TChip8.TickTimers;
begin
  if DelayTimer > 0 then
    Dec(DelayTimer);
  if SoundTimer > 0 then
    Dec(SoundTimer);
end;

procedure TChip8.DrawSprite(VxIndex, VyIndex, N: Byte);
var
  Row, Bit: Integer;
  SpriteByte: Byte;
  Px, Py: Integer;
  OldPixel: Byte;
begin
  // VF = collision flag
  Registers[$F] := 0;

  for Row := 0 to N - 1 do
  begin
    SpriteByte := Memory[RegisterI + Row];

    // Y position wraps vertically
    Py := (Registers[VyIndex] + Row) mod ScreenHeight;

    for Bit := 0 to 7 do
    begin
      if (SpriteByte and ($80 shr Bit)) <> 0 then
      begin
        // X position wraps horizontally
        Px := (Registers[VxIndex] + Bit) mod ScreenWidth;

        OldPixel := FDisplay[Py, Px];

        // XOR draw
        if OldPixel = 1 then
        begin
          FDisplay[Py, Px] := 0;
          Registers[$F] := 1; // collision
        end
        else
          FDisplay[Py, Px] := 1;
      end;
    end;
  end;
end;

procedure TChip8.ClearDisplay;
var
  X, Y: Integer;
begin
  for Y := 0 to ScreenHeight - 1 do
    for X := 0 to ScreenWidth - 1 do
      FDisplay[Y, X] := 0;
end;

function TChip8.PixelOn(X, Y: Integer): Boolean;
begin
  Result := (X >= 0) and (X < ScreenWidth) and
            (Y >= 0) and (Y < ScreenHeight) and
            (FDisplay[Y, X] <> 0);
end;

procedure TChip8.KeyDown(Key: Byte);
begin
  if (Key <= $F) then
  begin
    Keys[Key] := True;

    // If Fx0A is waiting and we don't yet have a key, capture this one
    if FWaitingForKey and (FWaitKey = -1) then
    begin
      FWaitKey := Key;
      Registers[FWaitingRegX] := Key;
      // IMPORTANT: do NOT clear FWaitingForKey here.
      // We only resume once this key is released.
    end;
  end;
end;

procedure TChip8.KeyUp(Key: Byte);
begin
  if (Key <= $F) then
  begin
    Keys[Key] := False;

    // If we're waiting for this key to be released, resume now
    if FWaitingForKey and (FWaitKey = Key) then
    begin
      FWaitingForKey := False;
      FWaitKey       := -1;
    end;
  end;
end;

function TChip8.IsKeyDown(Key: Byte): Boolean;
begin
  if (Key <= $F) then
    Result := Keys[Key]
  else
    Result := False;
end;


procedure DrawForm1(Sender: LongWord; AX, AY: Integer);
const
  BORDER = 5;
  TOP_OFFSET = 30;    { Küçüldü: başlık çubuğu için }
var
  X, Y, CellW, CellH: Integer;
  DrawW, DrawH: Integer;
begin
  DrawW := Chip8.Width  - BORDER * 2;
  DrawH := Chip8.Height - TOP_OFFSET - BORDER;

  { Arkaplan }
  KFill(AX + BORDER, AY + TOP_OFFSET, DrawW, DrawH, clBlack);

  CellW := DrawW div ScreenWidth;
  CellH := DrawH div ScreenHeight;
  if CellW < 1 then CellW := 1;
  if CellH < 1 then CellH := 1;

  { Pikselleri çiz }
  for Y := 0 to ScreenHeight - 1 do
    for X := 0 to ScreenWidth - 1 do
      if Chip8.PixelOn(X, Y) then
        KFill(
          AX + BORDER + X * CellW,
          AY + TOP_OFFSET + Y * CellH,
          CellW, CellH,
          clYellow  { Beyaz piksel }
        );
end;


procedure DrawForm(Sender:LongWord;AX, AY: Integer);
const
  C8Width  = 64;
  C8Height = 32;
var
  X, Y: Integer;
  CellW, CellH: Integer;
begin
  // CHIP8 alan�n� temizle (form arka plan�)
  KFill(AX+5,AY+30,Chip8.Width-10, Chip8.Height-38, clBlack);

  // Her bir CHIP8 pikseli i�in �l�ek
  CellW := (Chip8.Width-10) div C8Width;
  CellH := ((Chip8.Height-38) div C8Height);

  // Ekran tarama
  for Y := 0 to C8Height - 1 do
  begin
    for X := 0 to C8Width - 1 do
    begin
      if Chip8.PixelOn(X, Y) then
      begin
        // Geni�lik = CellW
        // Y�kseklik = CellH
        KFill(
          5+AX + X * CellW,
          30+AY + Y * CellH,
          CellW,
          CellH,
          clYellow  // aktif piksel rengi
        );
      end
      else
      begin
        // �ster siyah piksel de �izebilirsin (temizleme i�in)
        // KernelAPI.DrawRect(AX + X*CellW, AY + Y*CellH, CellW, CellH, clBlack);
      end;
    end;
  end;
end;



function MapKeyToChip8(Key: Word): Integer;
var ch: Char;
begin
  Result := -1;

  { Normal karakter: $100 + ASCII }
  if Key >= $100 then
    ch := Char(Key and $FF)
  else
    Exit;  { VK kodu — CHIP-8 için gerekli değil }

  case ch of
    '1': Result := $1;   '2': Result := $2;
    '3': Result := $3;   '4': Result := $C;
    'Q','q': Result := $4;   'W','w': Result := $5;
    'E','e': Result := $6;   'R','r': Result := $D;
    'A','a': Result := $7;   'S','s': Result := $8;
    'D','d': Result := $9;   'F','f': Result := $E;
    'Z','z': Result := $A;   'X','x': Result := $0;
    'C','c': Result := $B;   'V','v': Result := $F;
  end;
end;


procedure OnFormKeyDown(Sender: LongWord; Key: Word);
var chipKey: Integer;
begin
  chipKey := MapKeyToChip8(Key);
  if chipKey >= 0 then
    Chip8.KeyDown(chipKey);
end;

procedure OnFormKeyUp(Sender: LongWord; Key: Word);
var chipKey: Integer;
begin
  chipKey := MapKeyToChip8(Key);
  if chipKey >= 0 then
    Chip8.KeyUp(chipKey);
end;

procedure OnCloseForm(Sender: LongWord);
begin
  Chip8.Running := False;
  if ThreadHandle > 0 then
    KillThread(ThreadHandle);
end;


procedure ThreadWorker(Proc: PChip8);stdcall;
var
  I: Integer;
begin


             //
  While Proc^.Running do
  begin

  // Run several instructions per frame, but stop immediately if Fx0A starts waiting
  for I := 0 to 9 do
  begin
    if Proc^.WaitingForKey then
      Break;

    Proc^.Fetch;
    Proc^.Decode;
    Proc^.Execute;
  end;


  // Timers tick at 60 Hz (once per FMX timer tick), even while waiting for a key
  Proc^.TickTimers;





 // if Chip8.SoundTimer > 0 then Beep;
  DelayMs(1);
 end;
end;



procedure LoadFile(FileName: PChar);
var
  F       : Integer;
  Size    : Integer;
  ROM     : Chip8ROM;
  Buff:array[0..31] of Char;
begin
  
  
  F := FileOpen(FileName, FILE_READ);
  if F <> INVALID_HANDLE then
  begin
     FillChar(ROM, SizeOf(ROM), #0);
     Size := FileGetSize(F);
     if Size > SizeOf(ROM) then Size := SizeOf(ROM);
     FileRead(F, @ROM[0], Size);

     Chip8.Init(ROM);
     Chip8.Running := True;
     FileClose(F);

  ThreadHandle := BeginThread(
    @ThreadWorker,
    @Chip8,
    'Chip8',
    1,
    $01
  ); 

   end;
end;


procedure MyWndProc(hWnd: LongWord; Msg: LongWord;
                    WParam, LParam: LongWord);
var
  X,Y:Integer;
begin
  case Msg of
    WM_PAINT:
      begin
         X:=SmallInt(LParam and $FFFF);
         Y:=SmallInt((LParam shr 16) and $FFFF);


        // ThreadWorker(@Chip8)

      //  DrawForm(hWnd,X,Y);
      end;
    WM_CLOSE:
      begin
       Chip8.Running := False;
        if ThreadHandle > 0 then KillThread(ThreadHandle);
           ExitProcess(0);
      end;
  end;
  { WM_PAINT, WM_KEYDOWN, WM_KEYUP → GuiBindXxx callback'leri ile hallediliyor }
end;


begin
  MainWndProc   := @MyWndProc;
  ThreadHandle  := -1;

  Chip8.Width   := 640;
  Chip8.Height  := 380;
  Chip8.Running := False;

  { Form oluştur }
  Form := LongWord(CreateForm(80, 60, Chip8.Width, Chip8.Height));

  { Event'leri bağla   }
  GuiBindPaint  (Form, @DrawForm);
  GuiBindKeyDown(Form, @OnFormKeyDown);
  GuiBindKeyUp  (Form, @OnFormKeyUp);
  GuiBindDestroy(Form, @OnCloseForm);


  LoadFile('C:\Games\Tetris.cp8');


  while true do
  begin
    if GetMessage(Msg) then
      DispatchMessage(Msg);
  end;

  ExitProcess(0);
end.

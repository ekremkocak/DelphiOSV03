program Hello;

{$APPTYPE CONSOLE}

uses
  UserGUI;


var
  hIn, hOut: LongWord;
  Msg: PChar;
  Buf: array[0..255] of Char;
  ReadBytes: LongWord;
  Written: LongWord;
begin
  hOut := GetStdHandle(STD_OUTPUT_HANDLE );  { STD_OUTPUT_HANDLE }
  hIn  := GetStdHandle(STD_INPUT_HANDLE);  { STD_INPUT_HANDLE }

 SetConsoleTextAttribute(hOut, $01);
  Msg := 'Adinizi girin: ';
  WriteConsole(hOut, Msg, StrLen(Msg)); // , Written, nil

  { Enter bas�lana kadar bekle (Yield ile polling) }
  repeat
    ReadBytes := ReadConsole(hIn, @Buf[0], 255);
    if ReadBytes = 0 then Yield;   // Sat�r haz�r de�il, CPU'yu b�rak
  until ReadBytes > 0;

  { Son karakter #13 (Enter) ise kald�r }
  if (ReadBytes > 0) and (Buf[ReadBytes - 1] = #13) then
    Buf[ReadBytes - 1] := #0;

  SetConsoleTextAttribute(hOut, $07);
  Msg := #13#10'Merhaba, ';
  WriteConsole(hOut, Msg, StrLen(Msg));       //  , Written, nil
  WriteConsole(hOut, @Buf[0], StrLen(@Buf[0]));   //   , Written, nil

  while True do Yield;
end.

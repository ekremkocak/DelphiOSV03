unit Draw32;

interface

uses UserGUI;

{ ============================================================
  Renk Sabitleri (BGR format)
  ============================================================ }
const
  clBlack      = $00000000;
  clWhite      = $00FFFFFF;
  clRed        = $000000FF;
  clGreen      = $0000FF00;
  clBlue       = $00FF0000;
  clYellow     = $0000FFFF;
  clCyan       = $00FFFF00;
  clMagenta    = $00FF00FF;
  clGray       = $00808080;
  clSilver     = $00C0C0C0;
  clDkGray     = $00404040;
  clLtGray     = $00D0D0D0;
  clNavy       = $00800000;
  clMaroon     = $00000080;
  clOlive      = $00008080;
  clTeal       = $00808000;
  clBtnFace    = $FFF0F0F0;
  cl3DLight     = $00E8E8E8;
  cl3DHighLight = $00FFFFFF;
  cl3DShadow    = $00808080;
  cl3DDkShadow  = $00404040;
  cl3DFace      = $00D4D0C8;

{ ============================================================
  Draw32 API � Hepsi kernel �zerinden SYS_DRAW32 ile �al���r
  ============================================================ }

procedure PutPixel(X, Y: Integer; Color: LongWord); stdcall;

procedure KLine(X1, Y1, X2, Y2: Integer; Color: LongWord); stdcall;
procedure KLineH(X, Y, W: Integer; Color: LongWord); stdcall;
procedure KLineV(X, Y, H: Integer; Color: LongWord); stdcall;
procedure KLineDashed(X1, Y1, X2, Y2: Integer; Color: LongWord; DashLen: Integer); stdcall;
procedure KLineAlpha(X1, Y1, X2, Y2: Integer; Color: LongWord; Alpha: Byte); stdcall;

procedure KRect(X, Y, W, H: Integer; Color: LongWord); stdcall;
procedure KFill(X, Y, W, H: Integer; Color: LongWord); stdcall;
procedure KRoundRect(X, Y, W, H, Radius: Integer; BorderColor, FillColor: LongWord); stdcall;
procedure K3D(X, Y, W, H: Integer; Pressed: Boolean); stdcall;

procedure KCircle(CX, CY, R: Integer; Color: LongWord); stdcall;
procedure KFillCircle(CX, CY, R: Integer; Color: LongWord); stdcall;
procedure KEllipse(CX, CY, RX, RY: Integer; Color: LongWord); stdcall;
procedure KFillEllipse(CX, CY, RX, RY: Integer; Color: LongWord); stdcall;
procedure KArc(CX, CY, R, StartAngle, EndAngle: Integer; Color: LongWord); stdcall;
procedure KPie(CX, CY, R, StartAngle, EndAngle: Integer; Color: LongWord); stdcall;

procedure KTriangle(X1, Y1, X2, Y2, X3, Y3: Integer; Color: LongWord); stdcall;
procedure KFillTriangle(X1, Y1, X2, Y2, X3, Y3: Integer; Color: LongWord); stdcall;
procedure KPolygon(Points: Pointer; Count: Integer; Color: LongWord); stdcall;

procedure KChar(X, Y: Integer; Ch: Char; Color: LongWord); stdcall;
procedure KStr(X, Y: Integer; S: PChar; Color: LongWord); stdcall;
procedure KStrCentered(X, Y, W: Integer; S: PChar; Color: LongWord); stdcall;
procedure KStrRight(X, Y, W: Integer; S: PChar; Color: LongWord); stdcall;
procedure KStrClipped(X, Y, MaxW: Integer; S: PChar; Color: LongWord); stdcall;
procedure KStrShadow(X, Y: Integer; S: PChar; Color, ShadowColor: LongWord); stdcall;
procedure KStrOutlined(X, Y: Integer; S: PChar; Color, OutlineColor: LongWord); stdcall;

procedure KRect3D(X, Y, W, H: Integer; Raised: Boolean); stdcall;
procedure KButton3D(X, Y, W, H: Integer; Pressed: Boolean; FillColor: LongWord); stdcall;
procedure KButton3DEx(X, Y, W, H: Integer; Pressed, Hover: Boolean; FillColor: LongWord); stdcall;
procedure KButton3DDisabled(X, Y, W, H: Integer; FillColor: LongWord); stdcall;
procedure KPanel3D(X, Y, W, H: Integer; Raised: Boolean; FillColor: LongWord); stdcall;
procedure KGroove(X, Y, W, H: Integer); stdcall;
procedure KBevel(X, Y, W, H, BevelW: Integer; Raised: Boolean); stdcall;
procedure KEdge(X, Y, W, H: Integer; EdgeType: Integer); stdcall;
procedure KTitleBar(X, Y, W, H: Integer; Active: Boolean; Title: PChar); stdcall;
procedure KSunken(X, Y, W, H: Integer; FillColor: LongWord); stdcall;

procedure KGradientH(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
procedure KGradientV(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
procedure KGradientD(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
procedure KGradientRadial(CX, CY, R: Integer; InnerColor, OuterColor: LongWord); stdcall;
procedure KRainbow(X, Y, W, H: Integer); stdcall;

procedure KFillAlpha(X, Y, W, H: Integer; Color: LongWord; Alpha: Byte); stdcall;
procedure KBlendPixel(X, Y: Integer; Color: LongWord; Alpha: Byte); stdcall;

procedure KShadowRect(X, Y, W, H, ShadowSize: Integer; FillColor: LongWord); stdcall;
procedure KGlowRect(X, Y, W, H, GlowSize: Integer; GlowColor: LongWord); stdcall;
procedure KEmboss(X, Y, W, H: Integer); stdcall;
procedure KBlurRect(X, Y, W, H: Integer; Passes: Integer); stdcall;
procedure KInvert(X, Y, W, H: Integer); stdcall;
procedure KGrayscale(X, Y, W, H: Integer); stdcall;

procedure KBitBlt(DstX, DstY, W, H: Integer; Src: Pointer; SrcW, SrcX, SrcY: Integer); stdcall;
procedure KStretchBlt(DstX, DstY, DstW, DstH: Integer; Src: Pointer; SrcW, SrcH: Integer); stdcall;
procedure KTransBlt(DstX, DstY, W, H: Integer; Src: Pointer; SrcW, SrcX, SrcY: Integer; TransColor: LongWord); stdcall;
procedure KFlipH(X, Y, W, H: Integer); stdcall;
procedure KFlipV(X, Y, W, H: Integer); stdcall;

procedure KGranite(X, Y, W, H: Integer; BaseColor: LongWord; Density: Integer); stdcall;
procedure KMarble(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
procedure KWood(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
procedure KMetal(X, Y, W, H: Integer; BaseColor: LongWord); stdcall;
procedure KChecker(X, Y, W, H, TileSize: Integer; Color1, Color2: LongWord); stdcall;
procedure KDots(X, Y, W, H, Spacing: Integer; Color: LongWord); stdcall;
procedure KHatch(X, Y, W, H, Spacing: Integer; Color: LongWord); stdcall;
procedure KCrossHatch(X, Y, W, H, Spacing: Integer; Color: LongWord); stdcall;

function  RGB(R, G, B: Byte): LongWord; stdcall;
function  ColorR(C: LongWord): Byte; stdcall;
function  ColorG(C: LongWord): Byte; stdcall;
function  ColorB(C: LongWord): Byte; stdcall;
function  ColorBlend(C1, C2: LongWord; T: Byte): LongWord; stdcall;
function  ColorDarken(C: LongWord; Pct: Integer): LongWord; stdcall;
function  ColorLighten(C: LongWord; Pct: Integer): LongWord; stdcall;
function  ColorToGray(C: LongWord): LongWord; stdcall;

implementation

{ Yard�mc�: Record'u s�f�rla }
procedure ClearCmd(var Cmd: TDraw32Cmd);
begin
  FillChar(Cmd, SizeOf(TDraw32Cmd), 0);
end;

{---------------------------------------------------------------}
{  TEMEL ��Z�M                                                  }
{---------------------------------------------------------------}
procedure PutPixel(X, Y: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_PUTPIXEL; Cmd.X := X; Cmd.Y := Y; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KLine(X1, Y1, X2, Y2: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KLINE; Cmd.X := X1; Cmd.Y := Y1; Cmd.X2 := X2; Cmd.Y2 := Y2; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KLineH(X, Y, W: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KLINEH; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KLineV(X, Y, H: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KLINEV; Cmd.X := X; Cmd.Y := Y; Cmd.H := H; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KLineDashed(X1, Y1, X2, Y2: Integer; Color: LongWord; DashLen: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KLINEDASHED; Cmd.X := X1; Cmd.Y := Y1; Cmd.X2 := X2; Cmd.Y2 := Y2; Cmd.Color := Color; Cmd.DashLen := DashLen; Draw32Cmd(Cmd); end;

procedure KLineAlpha(X1, Y1, X2, Y2: Integer; Color: LongWord; Alpha: Byte); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KLINEALPHA; Cmd.X := X1; Cmd.Y := Y1; Cmd.X2 := X2; Cmd.Y2 := Y2; Cmd.Color := Color; Cmd.Alpha := Alpha; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  D�RTGEN / DA�RE                                               }
{---------------------------------------------------------------}
procedure KRect(X, Y, W, H: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KRECT; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KFill(X, Y, W, H: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KFILL; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KRoundRect(X, Y, W, H, Radius: Integer; BorderColor, FillColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KROUNDRECT; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Radius := Radius; Cmd.Color := BorderColor; Cmd.Color2 := FillColor; Draw32Cmd(Cmd); end;

procedure K3D(X, Y, W, H: Integer; Pressed: Boolean); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_K3D; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Pressed := Ord(Pressed); Draw32Cmd(Cmd); end;

procedure KCircle(CX, CY, R: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KCIRCLE; Cmd.X := CX; Cmd.Y := CY; Cmd.Radius := R; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KFillCircle(CX, CY, R: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KFILLCIRCLE; Cmd.X := CX; Cmd.Y := CY; Cmd.Radius := R; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KEllipse(CX, CY, RX, RY: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KELLIPSE; Cmd.X := CX; Cmd.Y := CY; Cmd.W := RX; Cmd.H := RY; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KFillEllipse(CX, CY, RX, RY: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KFILLELLIPSE; Cmd.X := CX; Cmd.Y := CY; Cmd.W := RX; Cmd.H := RY; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KArc(CX, CY, R, StartAngle, EndAngle: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KARC; Cmd.X := CX; Cmd.Y := CY; Cmd.Radius := R; Cmd.StartAngle := StartAngle; Cmd.EndAngle := EndAngle; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KPie(CX, CY, R, StartAngle, EndAngle: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KPIE; Cmd.X := CX; Cmd.Y := CY; Cmd.Radius := R; Cmd.StartAngle := StartAngle; Cmd.EndAngle := EndAngle; Cmd.Color := Color; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  �OKGEN                                                        }
{---------------------------------------------------------------}
procedure KTriangle(X1, Y1, X2, Y2, X3, Y3: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KTRIANGLE; Cmd.X := X1; Cmd.Y := Y1; Cmd.X2 := X2; Cmd.Y2 := Y2; Cmd.W := X3; Cmd.H := Y3; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KFillTriangle(X1, Y1, X2, Y2, X3, Y3: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KFILLTRIANGLE; Cmd.X := X1; Cmd.Y := Y1; Cmd.X2 := X2; Cmd.Y2 := Y2; Cmd.W := X3; Cmd.H := Y3; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KPolygon(Points: Pointer; Count: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KPOLYGON; Cmd.Points := Points; Cmd.Count := Count; Cmd.Color := Color; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  MET�N                                                         }
{---------------------------------------------------------------}
procedure KChar(X, Y: Integer; Ch: Char; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KCHAR; Cmd.X := X; Cmd.Y := Y; Cmd.W := Ord(Ch); Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KStr(X, Y: Integer; S: PChar; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KSTR; Cmd.X := X; Cmd.Y := Y; Cmd.Text := S; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KStrCentered(X, Y, W: Integer; S: PChar; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KSTRCENTERED; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.Text := S; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KStrRight(X, Y, W: Integer; S: PChar; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KSTRRIGHT; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.Text := S; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KStrClipped(X, Y, MaxW: Integer; S: PChar; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KSTRCLIPPED; Cmd.X := X; Cmd.Y := Y; Cmd.W := MaxW; Cmd.Text := S; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KStrShadow(X, Y: Integer; S: PChar; Color, ShadowColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KSTRSHADOW; Cmd.X := X; Cmd.Y := Y; Cmd.Text := S; Cmd.Color := Color; Cmd.Color2 := ShadowColor; Draw32Cmd(Cmd); end;

procedure KStrOutlined(X, Y: Integer; S: PChar; Color, OutlineColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KSTROUTLINED; Cmd.X := X; Cmd.Y := Y; Cmd.Text := S; Cmd.Color := Color; Cmd.Color2 := OutlineColor; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  3D EFEKTLER                                                   }
{---------------------------------------------------------------}
procedure KRect3D(X, Y, W, H: Integer; Raised: Boolean); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KRECT3D; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Raised := Ord(Raised); Draw32Cmd(Cmd); end;

procedure KButton3D(X, Y, W, H: Integer; Pressed: Boolean; FillColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KBUTTON3D; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Pressed := Ord(Pressed); Cmd.Color := FillColor; Draw32Cmd(Cmd); end;

procedure KButton3DEx(X, Y, W, H: Integer; Pressed, Hover: Boolean; FillColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KBUTTON3DEX; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Pressed := Ord(Pressed); Cmd.Hover := Ord(Hover); Cmd.Color := FillColor; Draw32Cmd(Cmd); end;

procedure KButton3DDisabled(X, Y, W, H: Integer; FillColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KBUTTON3DDIS; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := FillColor; Draw32Cmd(Cmd); end;

procedure KPanel3D(X, Y, W, H: Integer; Raised: Boolean; FillColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KPANEL3D; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Raised := Ord(Raised); Cmd.Color := FillColor; Draw32Cmd(Cmd); end;

procedure KGroove(X, Y, W, H: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KGROOVE; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Draw32Cmd(Cmd); end;

procedure KBevel(X, Y, W, H, BevelW: Integer; Raised: Boolean); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KBEVEL; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.BevelW := BevelW; Cmd.Raised := Ord(Raised); Draw32Cmd(Cmd); end;

procedure KEdge(X, Y, W, H: Integer; EdgeType: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KEDGE; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.EdgeType := EdgeType; Draw32Cmd(Cmd); end;

procedure KTitleBar(X, Y, W, H: Integer; Active: Boolean; Title: PChar); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KTITLEBAR; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Active := Ord(Active); Cmd.Text := Title; Draw32Cmd(Cmd); end;

procedure KSunken(X, Y, W, H: Integer; FillColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KSUNKEN; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := FillColor; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  GRADIENT / DOKU                                               }
{---------------------------------------------------------------}
procedure KGradientH(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KGRADIENTH; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := Color1; Cmd.Color2 := Color2; Draw32Cmd(Cmd); end;

procedure KGradientV(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KGRADIENTV; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := Color1; Cmd.Color2 := Color2; Draw32Cmd(Cmd); end;

procedure KGradientD(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KGRADIENTD; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := Color1; Cmd.Color2 := Color2; Draw32Cmd(Cmd); end;

procedure KGradientRadial(CX, CY, R: Integer; InnerColor, OuterColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KGRADIENTRAD; Cmd.X := CX; Cmd.Y := CY; Cmd.Radius := R; Cmd.Color := InnerColor; Cmd.Color2 := OuterColor; Draw32Cmd(Cmd); end;

procedure KRainbow(X, Y, W, H: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KRAINBOW; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  ALPHA / BLEND                                                 }
{---------------------------------------------------------------}
procedure KFillAlpha(X, Y, W, H: Integer; Color: LongWord; Alpha: Byte); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KFILLALPHA; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := Color; Cmd.Alpha := Alpha; Draw32Cmd(Cmd); end;

procedure KBlendPixel(X, Y: Integer; Color: LongWord; Alpha: Byte); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KBLENDPIXEL; Cmd.X := X; Cmd.Y := Y; Cmd.Color := Color; Cmd.Alpha := Alpha; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  EFEKTLER                                                      }
{---------------------------------------------------------------}
procedure KShadowRect(X, Y, W, H, ShadowSize: Integer; FillColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KSHADOWRECT; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.ShadowSize := ShadowSize; Cmd.Color := FillColor; Draw32Cmd(Cmd); end;

procedure KGlowRect(X, Y, W, H, GlowSize: Integer; GlowColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KGLOWRECT; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.GlowSize := GlowSize; Cmd.Color := GlowColor; Draw32Cmd(Cmd); end;

procedure KEmboss(X, Y, W, H: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KEMBOSS; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Draw32Cmd(Cmd); end;

procedure KBlurRect(X, Y, W, H: Integer; Passes: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KBLUR; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Passes := Passes; Draw32Cmd(Cmd); end;

procedure KInvert(X, Y, W, H: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KINVERT; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Draw32Cmd(Cmd); end;

procedure KGrayscale(X, Y, W, H: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KGRAYSCALE; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  BITMAP ��LEMLER�                                              }
{---------------------------------------------------------------}
procedure KBitBlt(DstX, DstY, W, H: Integer; Src: Pointer; SrcW, SrcX, SrcY: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KBITBLT; Cmd.X := DstX; Cmd.Y := DstY; Cmd.W := W; Cmd.H := H; Cmd.Src := Src; Cmd.SrcW := SrcW; Cmd.X2 := SrcX; Cmd.Y2 := SrcY; Draw32Cmd(Cmd); end;

procedure KStretchBlt(DstX, DstY, DstW, DstH: Integer; Src: Pointer; SrcW, SrcH: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KSTRETCHBLT; Cmd.X := DstX; Cmd.Y := DstY; Cmd.W := DstW; Cmd.H := DstH; Cmd.Src := Src; Cmd.SrcW := SrcW; Cmd.SrcH := SrcH; Draw32Cmd(Cmd); end;

procedure KTransBlt(DstX, DstY, W, H: Integer; Src: Pointer; SrcW, SrcX, SrcY: Integer; TransColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KTRANSBLT; Cmd.X := DstX; Cmd.Y := DstY; Cmd.W := W; Cmd.H := H; Cmd.Src := Src; Cmd.SrcW := SrcW; Cmd.X2 := SrcX; Cmd.Y2 := SrcY; Cmd.TransColor := TransColor; Draw32Cmd(Cmd); end;

procedure KFlipH(X, Y, W, H: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KFLIPH; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Draw32Cmd(Cmd); end;

procedure KFlipV(X, Y, W, H: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KFLIPV; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  DOKU / DESEN                                                  }
{---------------------------------------------------------------}
procedure KGranite(X, Y, W, H: Integer; BaseColor: LongWord; Density: Integer); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KGRANITE; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := BaseColor; Cmd.Density := Density; Draw32Cmd(Cmd); end;

procedure KMarble(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KMARBLE; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := Color1; Cmd.Color2 := Color2; Draw32Cmd(Cmd); end;

procedure KWood(X, Y, W, H: Integer; Color1, Color2: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KWOOD; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := Color1; Cmd.Color2 := Color2; Draw32Cmd(Cmd); end;

procedure KMetal(X, Y, W, H: Integer; BaseColor: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KMETAL; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Color := BaseColor; Draw32Cmd(Cmd); end;

procedure KChecker(X, Y, W, H, TileSize: Integer; Color1, Color2: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KCHECKER; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.TileSize := TileSize; Cmd.Color := Color1; Cmd.Color2 := Color2; Draw32Cmd(Cmd); end;

procedure KDots(X, Y, W, H, Spacing: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KDOTS; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Spacing := Spacing; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KHatch(X, Y, W, H, Spacing: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KHATCH; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Spacing := Spacing; Cmd.Color := Color; Draw32Cmd(Cmd); end;

procedure KCrossHatch(X, Y, W, H, Spacing: Integer; Color: LongWord); stdcall;
var Cmd: TDraw32Cmd;
begin ClearCmd(Cmd); Cmd.Cmd := DCMD_KCROSSHATCH; Cmd.X := X; Cmd.Y := Y; Cmd.W := W; Cmd.H := H; Cmd.Spacing := Spacing; Cmd.Color := Color; Draw32Cmd(Cmd); end;

{---------------------------------------------------------------}
{  RENK YARDIMCILARI (EXE taraf�nda local hesaplan�r)            }
{---------------------------------------------------------------}
function RGB(R, G, B: Byte): LongWord; stdcall;
begin
  Result := LongWord(B) or (LongWord(G) shl 8) or (LongWord(R) shl 16);
end;

function ColorR(C: LongWord): Byte; stdcall;
begin Result := Byte((C shr 16) and $FF); end;

function ColorG(C: LongWord): Byte; stdcall;
begin Result := Byte((C shr 8) and $FF); end;

function ColorB(C: LongWord): Byte; stdcall;
begin Result := Byte(C and $FF); end;

function ColorBlend(C1, C2: LongWord; T: Byte): LongWord; stdcall;
var
  r1, g1, b1: Byte;
  r2, g2, b2: Byte;
  r,  g,  b:  Byte;
begin
  r1 := ColorR(C1); g1 := ColorG(C1); b1 := ColorB(C1);
  r2 := ColorR(C2); g2 := ColorG(C2); b2 := ColorB(C2);
  r  := Byte((Word(r1) * (255 - T) + Word(r2) * T) div 255);
  g  := Byte((Word(g1) * (255 - T) + Word(g2) * T) div 255);
  b  := Byte((Word(b1) * (255 - T) + Word(b2) * T) div 255);
  Result := RGB(r, g, b);
end;

function ColorDarken(C: LongWord; Pct: Integer): LongWord; stdcall;
var
  r, g, b: Byte;
begin
  r := ColorR(C); g := ColorG(C); b := ColorB(C);
  r := Byte(Integer(r) * (100 - Pct) div 100);
  g := Byte(Integer(g) * (100 - Pct) div 100);
  b := Byte(Integer(b) * (100 - Pct) div 100);
  Result := RGB(r, g, b);
end;

function ColorLighten(C: LongWord; Pct: Integer): LongWord; stdcall;
var
  r, g, b: Word;
begin
  r := ColorR(C); g := ColorG(C); b := ColorB(C);
  r := r + Word((255 - r) * Pct div 100);
  g := g + Word((255 - g) * Pct div 100);
  b := b + Word((255 - b) * Pct div 100);
  if r > 255 then r := 255;
  if g > 255 then g := 255;
  if b > 255 then b := 255;
  Result := RGB(Byte(r), Byte(g), Byte(b));
end;

function ColorToGray(C: LongWord): LongWord; stdcall;
var
  gray: Byte;
begin
  gray := Byte((Integer(ColorR(C)) * 30 + Integer(ColorG(C)) * 59 + Integer(ColorB(C)) * 11) div 100);
  Result := RGB(gray, gray, gray);
end;

end.

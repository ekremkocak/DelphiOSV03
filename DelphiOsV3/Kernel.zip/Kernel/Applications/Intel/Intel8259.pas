unit Intel8259;

interface


type
  TIntel8259= Object
  private
     imr: Integer;
     irr: Integer;
     isr: Integer;
     icw: array[0..4-1] of Integer;
     icwStep :Integer;
  public
    procedure Create();
    function isConnected(port: Integer):Boolean;
    function portIn( w: Integer;  port: Integer): Integer;
    procedure portOut( w:Integer;  port:Integer;  val: Integer); 
    procedure callIRQ(line: Integer);
    function hasInt():Boolean;
    function nextInt():Integer;
end;


var
  pic:TIntel8259;




implementation

{ TIntel8259 }

procedure TIntel8259.Create();
begin
   icwStep:=0;
end;

procedure TIntel8259.callIRQ(line: Integer);
begin
   irr :=irr or  (1 shl line);
end;


function TIntel8259.hasInt: Boolean;
begin
   Result:= (irr and (not imr))>0;
end;

function TIntel8259.isConnected(port: Integer): Boolean;
begin
  Result:= (port = $20) or (port = $21);
  
end;

function TIntel8259.nextInt: Integer;
var
 bits: Integer;
 I: Integer;
begin
 Result:= 0;
  bits := irr and  not imr;
        for i := 0 to 8-1 do begin
            if (((bits shr i) and 1)>0) then begin
                irr :=irr xor (1 shl i);
                isr :=isr or (1 shl i);
                Result:= icw[1] + i;
                break;
            end;
        end;

end;

function TIntel8259.portIn( w: Integer;  port: Integer): Integer;
begin
   Result:=0;
   case port of
    $20: Result:=irr;
    $21: Result:=imr;
   end;
end;

procedure TIntel8259.portOut( w:Integer;  port:Integer;  val: Integer);
var
 i: integer;
begin
   case (port) of
        $20: begin
            if ((val and $10)>0) then begin
                imr := 0;
                 
                icw[icwStep] := val;
                 icwStep:=icwStep+1;
            end;
            if ((val and $20)>0) then// EOI
                for i := 0 to  8-1 do
                    if (((isr shr i) and 1)>0) then
                        isr := isr xor (1 shl i);
         end;
        $21:
            if (icwStep = 1) then begin
                
                icw[icwStep] := val;
                 icwStep:=icwStep+1;
                if ((icw[0] and $02)>0 ) then
                    icwStep:=icwStep+1;
            end else if (icwStep < 4) then begin
                
                icw[icwStep] := val;
                icwStep:=icwStep+1;
            end  else
                imr := val;
          
        end;

end;

end.

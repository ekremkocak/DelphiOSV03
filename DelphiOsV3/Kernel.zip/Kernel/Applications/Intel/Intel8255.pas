unit Intel8255;

interface
Uses Intel8259;

type
  TIntel8255= Object
  private

     ports: array[0..4-1] of Integer;
  public
    procedure Create();
    function isConnected(port: Integer):Boolean;
    function portIn( w: Integer;  port: Integer): Integer;
    procedure portOut( w:Integer;  port:Integer;  val: Integer);
    procedure keyTyped(scanCode:Integer);
end;

var
  ppi: TIntel8255;
implementation

{ TIntel8255 }

procedure TIntel8255.Create();
begin

  ports[0] := $2c;
end;

function TIntel8255.isConnected(port: Integer): Boolean;
begin
  Result:= (port >= $60) and (port < $64);
end;

procedure TIntel8255.keyTyped(scanCode: Integer);
begin
   ports[0] := scanCode;
   pic.callIRQ(1);
end;

function TIntel8255.portIn( w: Integer;  port: Integer): Integer;
begin
   

   Result:= ports[port and 3];
end;

procedure TIntel8255.portOut(w:Integer;  port:Integer;  val: Integer);
begin
   ports[port and 3] := val;

   
end;

end.

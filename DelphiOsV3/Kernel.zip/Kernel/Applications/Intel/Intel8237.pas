unit Intel8237;

interface


type

  
  TIntel8237= Object
  private
     addr: array[0..4-1] of Integer;
     cnt: array[0..4-1] of Integer;
     flipflop: array[0..4-1] of Boolean;
  public
    procedure Create();
    function isConnected(port: Integer):Boolean;
    function portIn( w: Integer;  port: Integer): Integer;
    procedure portOut( w:Integer;  port:Integer;  val: Integer); 

end;

var
  dma: TIntel8237;

implementation


{ TIntel8237 }

procedure TIntel8237.Create();
begin

end;

function TIntel8237.isConnected(port: Integer): Boolean;
begin
 Result:= (port >= $00) and (port < $20);
end;

function TIntel8237.portIn( w: Integer;  port: Integer): Integer;
var
 chan: Integer;
begin
   Result:= 0;
  case (port) of
    0,2,4,6:begin
      chan := port div  2;
      if (not flipflop[chan]) then begin
        flipflop[chan] := true;
        Result:= addr[chan] and $ff;

      end else begin
        flipflop[chan] := false;
        Result:= addr[chan] shr 8 and $ff;

      end;
    end;
    1,3,5,7:begin
      chan := (port - 1) div 2;
      if (not flipflop[chan]) then begin
        flipflop[chan] := true;
        Result:= cnt[chan] and $ff;

      end else begin
        flipflop[chan] := false;
        Result:= cnt[chan] shr 8 and $ff;
        
      end;
    end;
  end;

end;

procedure TIntel8237.portOut(w:Integer;  port:Integer;  val: Integer);
var
 chan: Integer;
begin
  case (port) of
    0,2,4,6:begin
      chan := port div 2;
      if (not flipflop[chan]) then begin
        flipflop[chan] := true;
        addr[chan] := addr[chan] and $ff00 or val;
      end else begin
        flipflop[chan] := false;
        addr[chan] := val shl 8 or addr[chan] and $ff;
      end;
    end;
    1,3,5,7:begin
      chan := (port - 1) div 2;
      if (not flipflop[chan]) then begin
        flipflop[chan] := true;
        cnt[chan] := cnt[chan] and $ff00 or val;
      end else begin
        flipflop[chan] := false;
        cnt[chan] := val shl 8 or cnt[chan] and $ff;
      end;
    end;
  end;
end;

end.

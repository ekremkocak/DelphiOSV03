unit Motorola6845;

interface



type
  TMotorola6845= Object
  private
   index: Integer;
   registers: array[0..$10] of Integer;
   retrace: Integer;
  public
    procedure Create();
    function isConnected(port: Integer):Boolean;
    function portIn( w: Integer;  port: Integer): Integer;
    procedure portOut( w:Integer;  port:Integer;  val: Integer);
    function getRegister(aindex: Integer):Integer;
end;

var
  crtc: TMotorola6845;

implementation

{ TMotorola6845 }

procedure TMotorola6845.Create();
begin

end;

function TMotorola6845.getRegister(aindex: Integer): Integer;
begin
 Result:= registers[aindex];
end;

function TMotorola6845.isConnected(port: Integer): Boolean;
begin
 Result:= (port >= $3d0) and (port < $3e0);
end;

function TMotorola6845.portIn( w: Integer;  port: Integer): Integer;
begin
  Result:=0;
  case port of
      $3da:begin
        retrace:=retrace+1;
        retrace := retrace mod 4;
        
        case retrace of
        0: Result:= 8;
        1: Result:= 0;
        2: Result:= 1;
        3: Result:= 0;
        end;
      end;


  end;
end;

procedure TMotorola6845.portOut(w:Integer;  port:Integer;  val: Integer);
begin
  case port of
    $3d4: Index:=val;
    $3d5: registers[index] := val;
  end;
end;

end.

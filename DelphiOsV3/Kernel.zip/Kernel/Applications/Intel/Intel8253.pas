unit Intel8253;

interface

Uses Intel8259;

type
  TIntel8253= Object
  private

    count: array[0..3-1] of Integer;
    value: array[0..3-1] of Integer;
    latch: array[0..3-1] of Integer;
    control: array[0..3-1] of Integer;
    enabled: array[0..3-1] of Boolean;
    latched: array[0..3-1] of Boolean;
    output: array[0..3-1] of Boolean;
    toggle: array[0..3-1] of Boolean;
    procedure outport(sc: Integer; state: Boolean);
  public
    procedure Create();
    function isConnected(port: Integer):Boolean;
    function portIn( w: Integer;  port: Integer): Integer;
    procedure portOut( w:Integer;  port:Integer;  val: Integer); 
    procedure  tick() ;
end;

var
   Intelpit:TIntel8253;

implementation



{ TIntel8255 }

procedure TIntel8253.Create();
begin

end;

function TIntel8253.isConnected(port: Integer): Boolean;
begin
  Result:= (port >= $40) and (port < $44);
end;

procedure TIntel8253.outport(sc: Integer; state: Boolean);
begin
  if (not output[sc] and state) then begin
    case (sc) of
      0:  pic.callIRQ(0);
    end;
  end;
  output[sc] := state;
end;

function TIntel8253.portIn( w: Integer;  port: Integer): Integer;
var
 sc,rl,val: Integer;
begin
   

   Result:= 0;
   sc := port and 3;
        case (sc) of
        0,1,2:begin
            // Read operation.
            rl := control[sc] shr 4 and 3;
            // Use latch if set.
            val := count[sc];
            if (latched[sc])  then begin
                val := latch[sc];
                if ((rl < 3) or (not toggle[sc])) then
                    latched[sc] := false;
            end;
            case (rl) of
              1:begin // Read least significant byte only.
                Result:= val and $ff;

              end;
              2: begin// Read most significant byte only.
                Result:= (val shr 8) and $ff;

              end;
              3: // Read lsb first, then msb.
                if (not toggle[sc]) then begin
                    toggle[sc] := true;
                    Result:= val and $ff;

                end else begin
                    toggle[sc] := false;
                    Result:= val shr 8 and $ff;
                    
                end;
            end;
          end;
       end;

end;

procedure TIntel8253.portOut(w:Integer;  port:Integer;  val: Integer);
var
 sc,m,rl: Integer;
begin
      sc := port and 3;
        case (sc) of
        0,1,2:begin
            // Counter loading.
             m := control[sc] shr 1 and 7;
             rl := control[sc] shr 4 and 3;
            case (rl) of
                1: // Load least significant byte only.
                value[sc] := value[sc] and $ff00 or val;

               2: // Load most significant byte only.
                value[sc] := val shl 8 or value[sc] and $ff;

               3: // Load lsb first, then msb.
                if (not toggle[sc]) then begin
                    toggle[sc] := true;
                    value[sc] := value[sc] and $ff00 or val;
                end else begin
                    toggle[sc] := false;
                    value[sc] := val shl 8 or value[sc] and $ff;
                end;

            end;
            if ((rl < 3) or  (not toggle[sc])) then begin
                count[sc] := value[sc];
                enabled[sc] := true;
                output[sc] := (m = 2) or (m = 3);
            end;

        end;
        3: begin
            sc := val shr 6 and 3;
            if ((val shr 4 and 3) = 0) then begin
                // Counter latching.
                latch[sc] := count[sc];
                latched[sc] := true;
            end else
                // Counter programming.
                control[sc] := val and $ffff;

        end;
   end;

end;

procedure  TIntel8253.tick() ;
var
  sc: Integer;
begin


    for  sc := 0 to   3-1 do
            if (enabled[sc]) then
                case (control[sc] shr 1 and 7) of
                    0:begin
                     // Decrement count.
                     
                     count[sc] := count[sc] and $ffff;
                     count[sc]:=count[sc] -1;
                    if (count[sc] = 0) then
                        outport(sc, true);
                    end;
                    2: begin

                    // Decrement count.
                    
                    count[sc] := count[sc] and $ffff;
                    count[sc]:=count[sc]-1;
                    // Reload count if necessary.
                    if (count[sc] = 1)  then begin
                        count[sc] := value[sc];
                        outport(sc, false);
                    end else
                        outport(sc, true);
                   end;
                  3:begin

                    // Decrement count.
                    if ((count[sc] and 1) = 1) then begin
                        if (output[sc]) then
                            count[sc] := (count[sc] - 1) and $ffff
                        else
                            count[sc] := (count[sc] - 3) and $ffff;
                    end else
                        count[sc] := (count[sc] - 2)  and $ffff;

                    // Reload count if necessary.
                    if (count[sc] = 0) then begin
                        count[sc] := value[sc];
                        outport(sc, not output[sc]);
                    end;
                    end;
                end;
    
end;

end.

Program Basic;

//{$APPTYPE CONSOLE}

{$IMAGEBASE $00010000}

Uses
  SysUtils,UserGUI,Draw32,Intel8237,Intel8253,Intel8255,Intel8259,Motorola6845;




const
 colors:array[0..16-1,0..3-1]of integer = (
    (   0,   0,   0 ),
    (   0,   0, 176 ),
    (   0, 176,   0 ),
    (   0, 176, 176 ),
    ( 176,   0,   0 ),
    ( 176,   0, 176 ),
    ( 176, 176,   0 ),
    ( 176, 176, 176 ),
    (  88,  88,  88 ),
    (  88,  88, 255 ),
    (  88, 255,  88 ),
    (  88, 255, 255 ),
    ( 255,  88,  88 ),
    ( 255,  88, 255 ),
    ( 255, 255,  85 ),
    ( 255, 255, 255 ));

const
  CharWidth  = 8;
  CharHeight = 8;


const
  CF = 1 shl  0;
  PF = 1 shl  2;
  AF = 1 shl  4;
  ZF = 1 shl  6;
  SF = 1 shl  7;
  TF = 1 shl  8;
  IF1= 1 shl  9;
  DF = 1 shl  10;
  OF1= 1 shl  11;

  B_SIZE =  0;
  W_SIZE =  1;
  S_SIZE = -1;

  REG_AX =0;
  REG_CX =1;
  REG_DX =2;
  REG_BX =3;

  MASK:array[0..2-1] of Integer =($FF,$FFFF);
  BITS:array[0..2-1] of Integer =(8,16);
  SIGN:array[0..2-1] of Integer =($80,$8000);

  PARITY:array[0..256-1] of Integer = (
  1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
  0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
  0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
  1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
  0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
  1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
  1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
  0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
  0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
  1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
  1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
  0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
  1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
  0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
  0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
  1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1
  );

 

type
  { PByteArray tan�m� � SysAlloc'tan gelen pointer'� indexlemek i�in }

  PByteArray = ^TByteArray;
  TByteArray = array[0..0] of Byte;  // 1MB, senin ihtiyac�n kadar

  
  PPCEmulator=^TPCEmulator;
  TPCEmulator = object
  private
    Width,Height:Integer;
    ah,al,ch,cl,dh,dl,bh,bl,sp, bp,si,di:Integer;
    ES,cs,ss,ds:Integer;
    OS:Integer;
    disp:Integer;
    Mode,Reg,Rm:Byte;
    OpCode:Byte;
    IP:Integer;
    Clocks:Integer;
    Flags:Integer;
    procedure SetFlag(flag:Integer; Value:boolean);
    function  GetFlag(flag:Integer):boolean;
    procedure SetFlags(Size:Integer; res:Integer);
    function  Op_Adc(Size:Integer; dst:Integer;src:Integer):Integer;
    function  Op_Add(Size:Integer;dst:Integer;  src:Integer):Integer;
    function  Op_Dec(Size:Integer;dst:Integer):Integer;
    function  Op_Inc(Size:Integer;dst:Integer):Integer;
    function  Op_Sbb(Size:Integer;dst:Integer; src:Integer):Integer;
    function  Op_Sub(Size:Integer; dst:Integer; src:Integer):Integer;
    procedure Op_Logic( Size:Integer;  res:Integer);
    function  GetMem( Size:Integer;addr:Integer) :Integer;overload;
    function  GetMem(Size:Integer):Integer;overload;
    procedure SetMem( Size:Integer;  addr:Integer;val:Integer);
    function  Pop():Integer;
    procedure Push( val:Integer);
    procedure CallInt(Value:integer);
    procedure SetRM( Size:Integer; _mode:Integer;  _rm:Integer; val:Integer);
    function  GetRM(Size:Integer;_mode:Integer;_rm:Integer):Integer;
    procedure ModRegRM();
    function  GetEA(_mode:Integer;_rm:Integer):Integer;
 public
    Ruing:boolean;
    

    function  Execute():Boolean;
    function  getFlags(flag:Integer):Integer;
    procedure SetReg(Size:Integer;_reg:Integer;val:Integer);
    function  GetReg(Size:Integer; _reg:Integer):Integer;
    function  getSegReg(_reg:Integer):Integer;
    procedure setSegReg(_reg:Integer;val:Integer);
    procedure LoadFile(FileName:PChar;Addr:Integer);
    procedure Reset();
    Procedure Run();
    function  PortIn( w:Integer;  port:Integer):Integer;
    procedure PortOut( w:Integer; port:Integer; val:Integer);
    procedure Create();
    procedure  Destroy;
end;


var
  PCEmulator1:TPCEmulator;
  CursorX:Integer = 1;
  CursorY:Integer = 1;
  Memory :Array[0..$100000] of Byte;
  KeyCode:Char=#0;

  CursorBlinkOn: Boolean = True;
  LastBlinkTick: LongWord = 0;


  ThreadHandle : Integer;
  Msg          : TMessage;
  Form         : LongWord;
  str:Array[0..31] of Char;



  procedure DrawForm(Sender: LongWord; AX, AY: Integer);forward;

procedure ShowmessageDlg(str:Pchar);
begin
   DebugPrint(str);
end;






function IfThen(AValue: Boolean; const ATrue: Integer; const AFalse: Integer): Integer;
begin
  if AValue then
    Result := ATrue
  else
    Result := AFalse;
end;

function msb( Size:Integer;  Value:Integer) :boolean;
begin
  Result:= (Value and SIGN[Size]) = SIGN[Size];
end;

function shift(Value:Integer; n:Integer):Integer;
begin
  if n >= 0 then
  Result:=  Value shl n
  else
  Result:= Value shr -n;
end;


function signconv(Size:Integer;  Value:Longint):Longint;
begin
  case Size of
    B_SIZE: Result:= Integer(ShortInt(Value));
    W_SIZE: Result:= Integer(SmallInt(Value));
  end;
end;

function SignConv1(const w, x: Integer): Integer;
begin
  Result := (x shl (32 - BITS[w])) shr (32 - BITS[w]);
end;



function GetAddr(seg:Integer;off:Integer):Integer;
begin
  Result:= (seg shl 4) + (off);
end;

{ TPCEmulator }

procedure TPCEmulator.SetFlag(flag:Integer; Value:boolean);
begin
  if (value) then
  flags :=flags or  flag
  else
  flags :=flags and  not flag;
end;

function TPCEmulator.GetFlag(flag:Integer):boolean;
begin
  Result:= (flags and flag) > 0;
end;

procedure TPCEmulator.SetFlags(Size:Integer; res:Integer);
begin
  setFlag(PF,PARITY[res and $ff]>0);
  setFlag(ZF, res = 0);
  setFlag(SF, (shift(res, 8 - BITS[Size]) and SF) <> 0);
end;

function  TPCEmulator.Op_Adc(Size:Integer; dst:Integer;src:Integer):Integer;
var
  carry:Integer;
  res:Integer;
begin
  carry := IfThen((flags and CF) = CF,  1, 0);
  res := (dst + src + carry) and MASK[Size];
  if carry=1 then setFlag(CF, res <= dst) else setFlag(CF, res < dst);
  setFlag(AF, ((res xor  dst xor src) and AF) > 0);
  setFlag(OF1, (shift((dst xor src xor -1) and (dst xor res), 12 - BITS[Size]) and OF1) > 0);
  setFlags(Size, res);

  Result:= res;
end;

function TPCEmulator.Op_Add(Size:Integer;dst:Integer;  src:Integer):Integer;
var
  res:Integer;
begin
  res := (dst + src) and MASK[Size];
  setFlag(CF, res < dst);
  setFlag(AF, ((res xor dst xor src) and AF) > 0);
  setFlag(OF1, (shift((dst xor src xor -1) and (dst xor res), 12 - BITS[Size]) and OF1) > 0);
  setFlags(Size, res);

  Result:= res;
end;

function TPCEmulator.Op_Sbb(Size:Integer;dst:Integer; src:Integer):Integer;
var
  carry,res:Integer;
begin
  carry := IfThen((flags and CF) = CF, 1 , 0);
  res := (dst - src - carry) and MASK[Size];
  if  carry > 0 then setFlag(CF,  dst <= src) else setFlag(CF, dst < src);
  setFlag(AF, ((res xor dst xor src) and AF) > 0);
  setFlag(OF1, (shift((dst xor src) and (dst xor res), 12 - BITS[Size]) and OF1) > 0);
  setFlags(Size, res);

  Result:= res;
end;

function TPCEmulator.Op_Sub(Size:Integer; dst:Integer; src:Integer):Integer;
var
  res:Integer;
begin
  res := (dst - src) and MASK[Size];
  setFlag(CF, dst < src);
  setFlag(AF, ((res xor dst xor  src) and AF) > 0);
  setFlag(OF1, (shift((dst xor src) and (dst xor res), 12 - BITS[Size]) and OF1) > 0);
  setFlags(Size, res);

  Result:= res;
end;

function TPCEmulator.Op_Dec(Size:Integer;dst:Integer):Integer;
var
  res:Integer;
begin
  res := (dst - 1) and MASK[Size];
  setFlag(AF, ((res xor dst xor 1) and AF) > 0);
  setFlag(OF1, res = SIGN[Size] - 1);
  setFlags(Size, res);

  Result:= res;
end;

function TPCEmulator.Op_Inc(Size:Integer;dst:Integer):Integer;
var
  res:Integer;
begin
  res := (dst + 1) and MASK[Size];
  setFlag(AF, ((res xor dst xor 1) and AF) > 0);
  setFlag(OF1, res = SIGN[Size]);
  setFlags(Size, res);

  Result:= res;
end;



procedure TPCEmulator.Op_Logic( Size:Integer;  res:Integer);
begin
  setFlag(CF, false);
  setFlag(OF1, false);
  setFlags(Size, res);
end;

function TPCEmulator.GetSegReg(_reg:Integer):Integer;
begin
  Result:=0;
  case (_reg) of
    0: Result:= es;
    1: Result:= cs;
    2: Result:= ss;
    3: Result:= ds;
  end;
end;

procedure TPCEmulator.SetSegReg( _reg:Integer;val:Integer);
begin
  case (_reg) of
    0: es := val and $ffff;
    1: cs := val and $ffff;
    2: ss := val and $ffff;
    3: ds := val and $ffff;
  end;
end;


function TPCEmulator.GetMem( Size:Integer;addr:Integer) :Integer;
begin
  Result:=0;
  case Size of
    B_SIZE : //
    begin
      Result := Memory[addr];
    end;
    W_SIZE  : //
    begin
      Result := Memory[addr+1] shl 8  or Memory[addr];
      if ((addr and 1) = 1)  then clocks :=clocks + 4;
    end;
  end;
end;

function TPCEmulator.GetMem(Size:Integer):Integer;
var
  addr:Integer;
begin
  Result:=0;
  addr := getAddr(CS, IP);
  case Size of
    B_SIZE : //
    begin
      Result := Memory[addr]; ip := (ip + 1) and $ffff;
    end;
    W_SIZE  : //
    begin
      Result := Memory[addr+1] shl 8  or Memory[addr]; ip := (ip + 2) and $ffff;
    end;
    S_SIZE ://
    begin
       Result := Integer(ShortInt(Memory[addr])); ip := (ip + 1) and $ffff;
    end;
  end;
end;


procedure TPCEmulator.SetMem( Size:Integer;  addr:Integer;val:Integer);
var
 X,Y:Integer;
begin


  if (addr >= $f6000) then exit;

  case Size of
    B_SIZE  : Memory[addr]:=val and $ff;
    W_SIZE  : //
    begin
      Memory[addr]:=val and $ff;
      Memory[addr+1]:=(val shr 8) and $ff;
      if ((addr and 1) = 1)  then clocks :=clocks + 4;
    end;
  end;

 
   


 if (addr>=$B8000)  and  (addr<$B8000+(25*80*2)) then
 begin


  // X:= ADR mod 80;
  // y:= ADR MOD 80 DIV 25;
  // KernelAPI.ProcessDraw(@Memory[$B8000],addr-$B8000,200,200,80,25);

  // Screen[Y,X]:=VAL;

  
   //  ProcessMessages();
  end;


    
end;

function TPCEmulator.Pop():Integer;
var
  val:Integer;
begin
  val := GetMem(W_SIZE, getAddr(SS, SP));
  SP := (SP + 2) and $ffff;
  Result:= val;
end;

procedure TPCEmulator.Push(val:Integer);
begin
  SP := (SP - 2) and $ffff;
  SetMem(W_SIZE, getAddr(SS, SP), val);
end;

procedure TPCEmulator.CallInt(Value:integer);
begin

   Case Value of
      $13: begin
      Showmessagedlg('file');
      exit;
      end;



     $16:begin
         case AH of
            0:begin
               while (KeyCode = #0) and Ruing  do
               begin

               end;

               ah := ORD(keycode);
               al := ah;
               KeyCode := #0;
            end;

           1:begin
             if KeyCode = #0 then
                SetFlag(zf, True) // Tampon bo�
             else
              SetFlag(zf, False); // Tampon dolu
            end;
         end;
   end;



   end;




  push(flags);
  setFlag(IF1, false);
  setFlag(TF, false);
  push(CS);
  push(IP);
  IP := GetMem(1, Value * 4);
  CS := GetMem(1, Value * 4 + 2);
end;


function TPCEmulator.PortIn( w:Integer;  port:Integer):Integer;
begin
  

   case port  of
    $00..$19 : Result := dma.portIn(w,port);
    $20,$21  : Result := pic.portIn(w,port);
    $40..$43  : Result := Intelpit.portIn(w,port);
    $60..$63 : Result := ppi.portIn(w,port);
    $3d0..$3e0 : Result := crtc.portIn(w,port);
    else
      Result:=0;
   end;

end;

procedure TPCEmulator.PortOut( w:Integer; port:Integer; val:Integer);
begin

   case port  of
    $00..$19 : dma.portOut(w,port,val);
    $20,$21  : pic.portOut(w,port,val);
    $40..$43  : Intelpit.portOut(w,port,val);
    $60..$63 : ppi.portOut(w,port,val);
    $3d0..$3e0 : crtc.portOut(w,port,val);
   end;

end;




procedure TPCEmulator.SetRM( Size:Integer; _mode:Integer;  _rm:Integer; val:Integer);
begin
  if (_mode = 3) then
    SetReg(Size, _Rm, val)
  else
    SetMem(Size, getEA(_mode, _rm) , val)
end;

function TPCEmulator.GetRM(Size:Integer;_mode:Integer;_rm:Integer):Integer;
begin
  if (_mode = 3) then
    Result:= GetReg(Size, _Rm)
  else
    Result:= GetMem(Size, getEA(_mode, _rm) )
end;


procedure TPCEmulator.ModRegRM();
var
   _OpCode:Byte;
begin
  _OpCode:=byte(getMem(B_SIZE));
  mode:= _OpCode shr 6 and 3;
  reg := _OpCode shr 3 and 7;
  rm  := _OpCode       and 7;

  if ((mode=0) and (rm=6)) then
  begin
    disp:= getMem(W_SIZE)
  end
  else
  if( mode = 1 ) then
  begin
    disp:= getMem(B_SIZE);
    clocks := clocks +4;
  end
  else if (mode =2)  then
  begin
    disp:= getMem(W_SIZE);
    clocks := clocks +4;
  end
  else  disp:=0;
end;


function TPCEmulator.GetEA(_mode:Integer;_rm:Integer):Integer;
var
  ea:Integer;
begin
  ea:=0;
  case (_rm) of
    0: // EA = (BX) + (SI) + DISP
    begin
      clocks :=clocks + 7;
      ea := bh shl 8 or bl + si + disp;
    end;
    1: // EA = (BX) + (DI) + DISP
    begin
      clocks := clocks +8;
      ea := bh shl 8 or bl + di+ disp;
    end;
    2: // EA = (BP) + (SI) + DISP
    begin
      clocks := clocks +8;
      ea := bp + si + disp;
    end;
    3: //  EA = (BP) + (DI) + DISP
    begin
      clocks := clocks +7;
      ea := bp + di + disp;
    end;
    4: //  EA = (SI) + DISP
    begin
      clocks :=clocks + 5;
      ea := si + disp;
    end;
    5: //  EA = (DI) + DISP
    begin
      clocks :=clocks + 5;
      ea := di+ disp;
    end;
    6: //
    begin
      if (_mode = 0)then
      begin  // Direct address
        clocks := clocks +6;
        ea := disp;
      end
      else
      begin  // EA = (BP) + DISP
        clocks := clocks +5;
        ea := bp + disp;
      end;
    end;
    7: //  EA = (BX) + DISP
    begin
      clocks := clocks +5;
      ea := bh shl 8 or bl + disp;
    end;
  end;

  Result:= (os shl 4) + (ea and $ffff);
end;

function TPCEmulator.getFlags(flag:Integer):Integer;
begin
  Result:= IfThen((Flags and flag)>0,1,0);
end;

procedure TPCEmulator.SetReg(Size:Integer;_Reg:Integer;Val:Integer);
begin
  if (Size = B_SIZE) then
  begin
    // Byte data
    case (_reg) of
      0: al := val and $ff;
      1: cl := val and $ff;
      2: dl := val and $ff;
      3: bl := val and $ff;
      4: ah := val and $ff;
      5: ch := val and $ff;
      6: dh := val and $ff;
      7: bh := val and $ff;
    end;
  end
  else
  begin
    // Word data
    case (_reg) of
      0: //
      begin
        al := val and $ff;
        ah := val shr 8 and $ff;
      end;
      1: //
      begin
        cl := val and $ff;
        ch := val shr 8 and $ff;
      end;
      2: //
      begin
        dl := val and $ff;
        dh := val shr 8 and $ff;
      end;
      3: //
      begin
        bl := val and $ff;
        bh := val shr 8 and $ff;
      end;
      4: sp := val and $ffff;
      5: bp := val and $ffff;
      6: si := val and $ffff;
      7: di := val and $ffff;
    end;
  end;
end;

function TPCEmulator.GetReg(Size:Integer; _Reg:Integer):Integer;
begin
  Result:= 0;
  if (Size = B_SIZE) then
  begin
    // Byte data
    case (_reg) of
      0: result:= al; // AL
      1: result:= cl; // CL
      2: result:= dl; // DL
      3: result:= bl; // BL
      4: result:= ah; // AH
      5: result:= ch; // CH
      6: result:= dh; // DH
      7: result:= bh; // BH
    end;
  end
  else
  begin
    // Word data
    case (_reg) of
      0: result:= ah shl 8 or al; // AX
      1: result:= ch shl 8 or cl; // CX
      2: result:= dh shl 8 or dl; // DX
      3: result:= bh shl 8 or bl; // BX
      4: result:= sp;             // SP
      5: result:= bp;             // BP
      6: result:= si;             // SI
      7: result:= di;             // DI
    end;
  end;
end;



function TPCEmulator.Execute():Boolean;
var
  Res,Dst,Src: Integer;
  Rep: Integer;
  D,W: Integer;
  C_X: Integer;
  I:Integer;
  tempCF:Boolean;
  oldAL:Integer;
  oldCF:Boolean;
  lres,ldst:Integer;
  str:array[0..64] of char;
begin
  
  if (GetFlag(TF)) then
  begin
    CallInt(1);
    Clocks:= Clocks+ 50;
  end;
  if (GetFlag(IF1) and pic.hasInt()) then
  begin
    CallInt(pic.nextInt());
    Clocks:= Clocks+ 61;
  end;

  OS := DS;
  Rep := 0;

  repeat
    OpCode:= byte(GetMem(B_SIZE));
    case OpCode of
      $26: //  ES: (segment override prefix)
      begin
        OS:=ES; Clocks := Clocks +2;
      end;
      $2e: //  CS: (segment override prefix)
      begin
        OS:=CS; Clocks := Clocks +2;
      end;
      $36: //  SS: (segment override prefix)
      begin
        OS:=SS; Clocks := Clocks +2;
      end;
      $3e: //  DS: (segment override prefix)
      begin
        OS:=DS; Clocks := Clocks +2;
      end;
      $f2: // REPNE/REPNZ
      begin
        Rep:=2; Clocks := Clocks +9;
      end;
      $f3: // REP/REPE/REPZ
      begin
        Rep:=1; Clocks := Clocks +9;
      end;
    end;
  until (not (OpCode in [$F2, $F3, $2E, $36, $3E, $26]));

  D  := OpCode shr 1 and 1;
  W  := OpCode       and 1;

  case OpCode of
    $A4,$A5,$AA,$AB: if Rep=0 then Clocks:= Clocks+1;
    $AC,$AD:         if Rep=0 then Clocks:= Clocks-1;
    $A6,$A7,$AE,$AF:begin  end;
    else Rep:=0;
  end;

  repeat

  

    if (Rep > 0)  then
    begin
      C_X := getReg(W_SIZE, REG_CX);
      if (C_X = 0) then break;
      setReg(W_SIZE, REG_CX, C_X - 1);
    end;

    While (Clocks > 3) do
    begin
      Clocks:= Clocks-4;
      Intelpit.tick();
    end;


   // IntToHex(opcode,4,str);

   // showmessage(str);


   //   ProcessMessages();

    Case (OpCode) of
      $00,$01,$02,$03: // ADD   REG RM
      begin
        ModRegRM();
        if (d = 0) then
        begin
          dst := getRM(w, mode, rm);
          src := getReg(w, reg);
        end
        else
        begin
          dst := getReg(w, reg);
          src := getRM(w, mode, rm);
        end;
        res := op_add(w, dst, src);
        if (d = 0) then
        begin
          setRM(w, mode, rm, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +16;
        end
        else
        begin
          setReg(w, reg, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +9;
        end;
      end;

      $04,$05: //  ADD  IMM
      begin
        dst := getReg(w,0);
        src := getMem(w);
        res := op_add(w, dst, src);
        setReg(w, REG_AX, res);
        clocks :=clocks + 4;
      end;

      $08,$09,$0A,$0B: //  OR   REG RM
      begin
        ModRegRM();
        if (d = 0) then
        begin
          dst := getRM(w, mode, rm);
          src := getReg(w, reg);
        end
        else
        begin
          dst := getReg(w, reg);
          src := getRM(w, mode, rm);
        end;
        res := dst or src;
        op_logic(w, res);
        if (d = 0) then
        begin
          setRM(w, mode, rm, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +16;
        end
        else
        begin
          setReg(w, reg, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +9;
        end;
      end;

      $10,$11,$12,$13: //  ADC   REG RM
      begin
        ModRegRM();
        if (d = 0) then
        begin
          dst := getRM(w, mode, rm);
          src := getReg(w, reg);
        end
        else
        begin
          dst := getReg(w, reg);
          src := getRM(w, mode, rm);
        end;
        res := op_adc(w, dst, src);
        if (d = 0) then
        begin
          setRM(w, mode, rm, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +16;
        end
        else
        begin
          setReg(w, reg, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +9;
        end;
      end;

      $0C,$0D: //  OR IMM
      begin
        dst := getReg(w, REG_AX);
        src := getMem(w);
        res := dst or src;
        op_logic(w, res);
        setReg(w, REG_AX, res);
        clocks := clocks +4;
      end;

      $14,$15: //   ADC IMM
      begin
        dst := getReg(w, REG_AX);
        src := getMem(w);
        res := op_adc(w, dst, src);
        setReg(w, REG_AX, res);
        clocks :=clocks + 4;
      end;

      $1C,$1D: //  SBB IMM
      begin
        dst := getReg(w, REG_AX);
        src := getMem(w);
        res := op_sbb(w, dst, src);
        setReg(w, REG_AX, res);
        clocks :=clocks + 4;
      end;

      $18,$19,$1a,$1b: //  SBB REG RM
      begin
        ModRegRM();
        if (d = 0) then
        begin
          dst := getRM(w, mode, rm);
          src := getReg(w, reg);
        end
        else
        begin
          dst := getReg(w, reg);
          src := getRM(w, mode, rm);
        end;
        res := op_sbb(w, dst, src);
        if (d = 0) then
        begin
          setRM(w, mode, rm, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +16;
        end
        else
        begin
          setReg(w, reg, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +9;
        end;
      end;

      $07,$0f,$17,$1f: //   POP SEG
      begin
        reg := opcode shr 3 and 7;
        src := pop();
        SetSegReg(reg,src);
        clocks :=clocks + 8;
      end;

      $20,$21,$22,$23: //   AND REG RM
      begin
        ModRegRM();
        if (d = 0) then
        begin
          dst := getRM(w, mode, rm);
          src := getReg(w, reg);
        end
        else
        begin
          dst := getReg(w, reg);
          src := getRM(w, mode, rm);
        end;
        res := dst and src;
        op_logic(w, res);
        if (d = 0) then
        begin
          setRM(w, mode, rm, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +16;
        end
        else
        begin
          setReg(w, reg, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +9;
        end;
      end;

      $24,$25: //    AND IMM
      begin
        dst := getReg(w, REG_AX);
        src := getMem(w);
        res := dst and src;
        op_logic(w, res);
        setReg(w,REG_AX, res);
        clocks := clocks +4;
      end;

      $2C,$2D: //   SUB REG RM
      begin
        dst := getReg(w, REG_AX);
        src := getMem(w);
        res := op_sub(w, dst, src);
        setReg(w, REG_AX, res);
        clocks :=clocks + 4;
      end;

      $27: //  DAA
      begin
        oldAL := al;
        oldCF := getFlag(CF);
        setFlag(CF, false);
        if ((al and $f) > 9) or (getFlag(AF)) then
        begin
          al :=al + 6;
          setFlag(CF, oldCF or (al < 0));
          al :=al and $ff;
          setFlag(AF, true);
        end
        else
        setFlag(AF, false);
        if (oldAL > $99) or (oldCF) then
        begin

          al := al + $60 and $ff;
          setFlag(CF, true);
        end
        else
        setFlag(CF, false);
        setFlags(B_SIZE, al);
        clocks :=clocks + 4;
      end;

      $28,$29,$2a,$2b: //  SUB REG IMM
      begin
        ModRegRM();
        if (d = 0) then
        begin
          dst := getRM(w, mode, rm);
          src := getReg(w, reg);
        end
        else
        begin
          dst := getReg(w, reg);
          src := getRM(w, mode, rm);
        end;
        res := op_sub(w, dst, src);
        if (d = 0) then
        begin
          setRM(w, mode, rm, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +16;
        end
        else
        begin
          setReg(w, reg, res);
          if mode =3 then
          clocks :=clocks +3 else clocks :=clocks +9;
        end;
      end;

      $2f: //  DAS
      begin
        oldAL := al;
        oldCF := getFlag(CF);
        setFlag(CF, false);
        if ((al and $f) > 9) or  (getFlag(AF)) then
        begin
          al :=al - 6;
          setFlag(CF, oldCF or ((al and $ff) > 0));
          al := al and $ff;
          setFlag(AF, true);
        end
        else
        setFlag(AF, false);
        if ((oldAL > $99) or oldCF) then
        begin
          al := al - $60 and $ff;
          setFlag(CF, true);
        end
        else
        setFlag(CF, false);
        setFlags(B_SIZE, al);
        clocks :=clocks + 4;
      end;

      $30,$31,$32,$33: //  XOR REG RM
      begin
        ModRegRM();
        if (D = 0) then
        begin
          Dst := GetRM(W, Mode, Rm);
          Src := GetReg(W, Reg);
        end
        else
        begin
          Dst := GetReg(W, Reg);
          Src := GetRM(W, Mode, Rm);
        end;
        Res := (Dst xor Src);
        Op_Logic(W, Res);
        if (D = 0) then
        begin
          SetRM(W, Mode, Rm, Res);
          if Mode =3 then
          Clocks :=Clocks +3 else Clocks :=Clocks +16;
        end
        else
        begin
          SetReg(W, Reg, Res);
          if  Mode =3 then
          Clocks :=Clocks +3 else Clocks :=Clocks +9;
        end;
      end;

      $34,$35: //   XOR REG IMM
      begin
        dst := getReg(w, REG_AX);
        src := getMem(w);
        res := dst xor src;
        op_logic(w, res);
        setReg(w, REG_AX, res);
        clocks := clocks +4;
      end;

      $37: //  AAA
      begin
        if ((al and $f) > 9) or (getFlag(AF)) then
        begin
          al :=al + 6;
          ah := ah + 1 and $ff;
          setFlag(CF, true);
          setFlag(AF, true);
        end
        else
        begin
          setFlag(CF, false);
          setFlag(AF, false);
        end;
        al :=al and  $f;
        clocks := clocks +4;
      end;

      $38,$39,$3a,$3b: //  CMP REG  RM IMM
      begin
        ModRegRM();
        if (d = 0) then
        begin
          dst := getRM(w, mode, rm);
          src := getReg(w, reg);
        end
        else
        begin
          dst := getReg(w, reg);
          src := getRM(w, mode, rm);
        end;
        op_sub(w, dst, src);
        if mode =3 then
        clocks :=clocks +3 else clocks :=clocks +9;
      end;

      $3C,$3D: //  CMP AX
      begin
        dst := getReg(w, REG_AX);
        src := getMem(w);
        op_sub(w, dst, src);
        clocks :=clocks + 4;
      end;

      $3F: //  AAS
      begin
        if ((al and $f) > 9) or (getFlag(AF)) then
        begin
          al :=al - 6;
          ah := ah - 1 and $ff;
          setFlag(CF, true);
          setFlag(AF, true);
        end
        else
        begin
          setFlag(CF, false);
          setFlag(AF, false);
        end;
        al :=al and $f;
        clocks :=clocks + 4;
      end;

      $40..$47: //   INC
      begin
        reg := OpCode and 7;
        src := getReg(W_SIZE, reg);
        res := op_inc(W_SIZE, src);
        setReg(W_SIZE, reg, res);
        clocks :=clocks + 2;
      end;

      $48..$4F: //  DEC
      begin
        reg := OpCode and 7;
        dst := getReg(W_SIZE, reg);
        res := op_dec(W_SIZE, dst);
        setReg(W_SIZE, reg, res);
        clocks :=clocks + 2;
      end;

      $50..$57: //  PUSH
      begin
        reg := OpCode and 7;
        src := getReg(W_SIZE, reg);
        push(src);
        clocks := clocks +11;
      end;

      $58..$5f: //   POP
      begin
        reg := OpCode and 7;
        src := pop();
        setReg(W_SIZE, reg, src);
        clocks := clocks +8;
      end;

      $06,$0e, $16, $1e: //  PUSH ES..DS
      begin
        reg := OpCode shr 3 and 7;
        src := GetSegReg(reg);
        push(src);
        clocks := clocks +10;
      end;

      $70: //  JO SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (getFlag(OF1)) then
        begin
          ip := (ip + dst) and $ffff;
          clocks :=clocks + 16;
        end
        else
        clocks :=clocks + 4;
      end;

      $71: //  JNO SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (not GetFlag(OF1)) then
        begin
          ip := (ip + dst) and $ffff;
          Clocks :=Clocks + 16;
        end
        else
        Clocks :=Clocks + 4;
      end;

      $72: //  JB/JNAE/JC SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (getFlag(CF)) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +16;
        end
        else
        clocks := clocks +4;
      end;

      $73: //  JNB/JAE/JNC SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (not GetFlag(CF)) then
        begin
          IP := (ip + dst) and $ffff;
          Clocks := Clocks +16;
        end
        else
        Clocks := Clocks +4;
      end;

      $74: //  JE/JZ SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (getFlag(ZF)) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +16;
        end
        else
        clocks :=clocks + 4;
      end;

      $75: //  JNE/JNZ SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if ( not GetFlag(ZF)) then
        begin
          IP := (ip + dst) and $ffff;
          Clocks := Clocks +16;
        end
        else
        Clocks := Clocks +4;
      end;

      $76: //  JBE/JNA SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (GetFlag(CF) or getFlag(ZF)) then
        begin
          IP := (ip + dst) and $ffff;
          Clocks := Clocks +16;
        end
        else
        Clocks := Clocks + 4;
      end;

      $77: //  JNBE/JA SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (not (getFlag(CF) or getFlag(ZF))) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +16;
        end
        else
        clocks := clocks +4;
      end;

      $78: //  JS SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (getFlag(SF)) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +16;
        end
        else
        clocks := clocks +4;
      end;

      $79: //  JNS SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (not GetFlag(SF))then
        begin
          IP := (ip + dst) and $ffff;
          Clocks :=Clocks + 16;
        end
        else
        Clocks :=Clocks + 4;
      end;

      $7A: //  JP/JPE SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (getFlag(PF)) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +16;
        end
        else
        clocks := clocks +4;
      end;

      $7B: //  JNP/JPO SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (not GetFlag(PF)) then
        begin
          IP := (ip + dst) and $ffff;
          Clocks := Clocks +16;
        end
        else
        Clocks := Clocks +4;
      end;

      $7C: //  JL/JNGE SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (getFlag(SF) xor getFlag(OF1)) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +16;
        end
        else
        clocks := clocks +4;
      end;

      $7D: //  JNL/JGE SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (not (getFlag(SF) xor getFlag(OF1))) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +16;
        end
        else
        clocks := clocks +4;
      end;

      $7e: //  JLE/JNG SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (getFlag(SF) xor getFlag(OF1) or getFlag(ZF)) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +16;
        end
        else
        clocks := clocks +4;
      end;

      $7F: //  JNLE/JG SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (not (getFlag(SF) xor getFlag(OF1) or getFlag(ZF))) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +16;
        end
        else
        clocks :=clocks + 4;
      end;

      $80,$81,$82,$83: //  GROUP 1
      begin
        ModRegRM();
        dst := getRM(w, mode, rm);
        src := getMem(B_SIZE);
        if (OpCode = $81) then
        src := src or getMem(B_SIZE) shl 8
                // Perform sign extension if needed.
        else if (OpCode = $83) and ((src and SIGN[B_SIZE]) > 0) then
        src :=src or $ff00;
        case (reg) of
          0: //  ADD
          begin
            res := op_add(w, dst, src);
            setRM(w, mode, rm, res);
          end;
          1: //  OR
          begin
            if (OpCode = $80) or (OpCode = $81) then
            begin
              res := dst or src;
              op_logic(w, res);
              setRM(w, mode, rm, res);
            end;
          end;

          2: //  ADC
          begin
            res := op_adc(w, dst, src);
            setRM(w, mode, rm, res);
          end;
          3: //  SBB
          begin
            res := op_sbb(w, dst, src);
            setRM(w, mode, rm, res);
          end;
          4: //   AND
          begin
            if (OpCode = $80) or (OpCode = $81) then
            begin
              res := dst and src;
              op_logic(w, res);
              setRM(w, mode, rm, res);
            end;
          end;
          5: //  SUB
          begin
            res := op_sub(w, dst, src);
            setRM(w, mode, rm, res);
          end;
          6: //  XOR
          begin
            if (OpCode = $80) or (OpCode = $81) then
            begin
              res := dst xor src;
              op_logic(w, res);
              setRM(w, mode, rm, res);
            end;
          end;
          7: //  CMP
          begin  
            op_sub(w, dst, src);
            if (mode = 3)  then
            clocks := clocks -7;
          end;
          else ShowMessageDlg('Hata reg');
        end;

        if mode=3 then clocks :=clocks +4 else  clocks :=clocks +17;
      end;

      $84,$85: // TEST REG8-16/MEM8-16,REG8-16
      begin
        ModRegRM();
        dst := getRM(w, mode, rm);
        src := getReg(w, reg);
        op_logic(w, dst and src);
        if mode =3 then
        clocks :=clocks +3 else clocks :=clocks +9;
      end;

      $86,$87: //  XCHG REG8-16,REG8-16/MEM8-16
      begin
        ModRegRM();
        dst := getReg(w, reg);
        src := getRM(w, mode, rm);
        setReg(w, reg, src);
        setRM(w, mode, rm, dst);
        if mode =3 then
        clocks :=clocks +3 else clocks :=clocks +17;
      end;

      $8A,$8B,$88,$89: //  MOV REG8-16,REG8-16/MEM8-16
      begin
        ModRegRM();
        if (d = 0) then
        begin
          src := getReg(w, reg);
          setRM(w, mode, rm, src);
          if mode =3 then
          clocks :=clocks +2 else clocks :=clocks + 9;
        end
        else
        begin
          src := getRM(w, mode, rm);
          setReg(w, reg, src);
          if mode =3 then
          clocks :=clocks +2 else clocks :=clocks + 8;
        end;
      end;

      $8D: //  LEA REG16,MEM16
      begin
        ModRegRM();
        src := getEA(mode, rm) - (os shl 4);
        setReg(w, reg, src);
        clocks := clocks +2;
      end;

      $8C,$8E: //  MOV REG16/MEM16,SEGREG
      begin
        ModRegRM();
        if (d = 0) then
        begin
          src := GetSegReg(reg);
          setRM(W_SIZE, mode, rm, src);
          if mode =3 then
          clocks :=clocks +2 else clocks :=clocks +9;
        end
        else
        begin
          src :=getRM(W_SIZE, mode, rm);
          SetSegReg(reg,src);
          if mode =3 then
          clocks :=clocks +2 else clocks :=clocks +8;
        end;
      end;

      $8F: //  POP REG16/MEM16
      begin
        ModRegRM();
        case (reg) of
          0 : //
          begin // POP
            src := pop();
            setRM(w, mode, rm, src);
          end;
          else ShowMessageDlg('Hata reg');
        end;
        if mode=3 then clocks :=clocks +8 else  clocks :=clocks +17;
      end;

      $90: //  NOP
      begin
        clocks :=clocks + 3;
      end;

      $91..$97: //  XCHG AX,CX ..DI
      begin
        reg := opcode and 7;
        dst := getReg(W_SIZE, REG_AX);
        src := getReg(W_SIZE, reg);
        setReg(W_SIZE, REG_AX, src);
        setReg(W_SIZE, reg, dst);
        clocks :=clocks + 3;
      end;

      $98: //  CBW
      begin
        if ((al and $80) = $80) then
        ah := $ff
        else
        ah := $00;
        clocks := clocks +2;
      end;

      $99: //  CWD
      begin
        if ((ah and $80) = $80)then
        setReg(W_SIZE, REG_DX, $ffff)
        else
        setReg(W_SIZE, REG_DX, $0000);
        clocks :=clocks + 5;
      end;

      $9A: //  CALL FAR-PROC
      begin
        dst := getMem(W_SIZE);
        src := getMem(W_SIZE);
        push(cs);
        push(ip);
        ip := dst;
        cs := src;
        clocks := clocks +28;
      end;

      $9B: // CLD
      begin
        clocks := clocks +3;
      end;

      $9c: //  PUSHF
      begin
        push(flags);
        clocks :=clocks + 10;
      end;

      $9d: //  POPF
      begin
        flags := pop();
        clocks :=clocks + 8;
      end;

      $9E: //  SAHF
      begin
        Flags := Flags and $ff00 or AH;
        Clocks:= Clocks + 4;
      end;

      $9F: //  LAHF
      begin
        AH := Flags and $ff;
        Clocks := Clocks +4;
      end;

      $a0,$a1,$a2,$a3: //   MOV AL,MEM8
      begin
        dst := getMem(W_SIZE);
        if (d = 0) then
        begin
          src := getMem(w, getAddr(os, dst));
          setReg(w, REG_AX, src);
        end
        else
        begin
          src := getReg(w, REG_AX);
          setMem(w, getAddr(os, dst), src);
        end;
        clocks := clocks +10;
      end;

      $A4,$A5: //  MOVS DEST-STR8 16 ,SRC-STR8  16
      begin
        src := getMem(w, getAddr(os, si));
        setMem(w, getAddr(es, di), src);
        si := SI + (IfThen(getFlag(DF), -1, 1)) * (1 + w) and $ffff;
        di := DI + (IfThen(getFlag(DF), -1, 1)) * (1 + w) and $ffff;
        clocks := clocks +17;
      end;

      $A6,$A7: //  CMPS DEST-STR8,SRC-STR8-16
      begin
        dst := getMem(w, getAddr(es, di));
        src := getMem(w, getAddr(os, si));
        op_sub(w, src, dst);
        si := (SI + (IfThen(getFlag(DF), -1 , 1)) * (1 + w)) and $ffff;
        di := (DI + (IfThen(getFlag(DF) , -1 , 1)) * (1 + w))  and $ffff;
        if (rep = 1) and (not getFlag(ZF)) or (rep = 2) and (getFlag(ZF)) then rep := 0;
        clocks :=clocks + 22;
      end;

      $A8,$A9: // TEST AX AL ,IMMED8 16
      begin
        dst := getReg(w, REG_AX);
        src := getMem(w);
        op_logic(w, dst and src);
        clocks := clocks +4;
      end;

      $AE,$AF: // SCAS DEST-STR8-16
      begin
        dst := getMem(w, getAddr(ES, DI));
        src := getReg(w, REG_AX);
        op_sub(w, src, dst);
        DI := (DI + (IfThen(getFlag(DF), -1, 1)) * (1 + w)) and $ffff;
        if (rep = 1) and (not getFlag(ZF)) or (rep = 2) and (getFlag(ZF)) then
        rep := 0;
        clocks :=clocks + 15;
      end;

      $AC,$AD: // LODS SRC-STR8-16
      begin
        src := getMem(w, getAddr(os, si));
        setReg(w, REG_AX, src);
        si := (si + (IfThen(getFlag(DF) , -1, 1)) * (1 + w)) and $ffff;
        clocks := clocks +13;
      end;

      $AA,$AB: //  STOS DEST-STR8-16
      begin
        src := getReg(w, REG_AX);
        setMem(w, getAddr(es, di), src);
        di := (di + (IfThen(getFlag(DF) , -1, 1)) * (1 + w))  and $ffff;
        clocks :=clocks + 10;
      end;

      $B0..$BF: //  MOV AL..DI,IMMED
      begin
        W:= OpCode shr 3 and 1;
        Reg := OpCode    and 7;
        Src := GetMem(W);
        SetReg(W, Reg, Src);
        Clocks :=Clocks + 4;
      end;

      $C2: //  // RET IMMED16 32
      begin
        src := getMem(W_SIZE);
        ip := pop();
        sp := sp +src;
        clocks :=clocks + 12;
      end;

      $C3: // RET
      begin
        ip := pop();
        clocks :=clocks + 8;
      end;

      $C4: //  LES REG,MEM
      begin
        ModRegRM();
        src := getEA(mode, rm);
        setReg(w, reg, getMem(W_SIZE, src));
        es := getMem(W_SIZE, src + 2);
        clocks :=clocks + 16;
      end;

      $c5: //  LDS REG16,MEM32
      begin
        ModRegRM();
        src := getEA(mode, rm);
        setReg(w, reg, getMem(W_SIZE, src));
        ds := getMem(W_SIZE, src + 2);
        clocks := clocks +16;
      end;

      $C6,$C7: //  MOV REG/MEM,IMMED
      begin
        ModRegRM();
        case Reg of
          0: //
          begin
            src := getMem(W);
            setRM(W, mode, rm, src);
          end;
          else ShowMessageDlg('Hata reg');
        end;
        if mode =3 then
        clocks :=clocks +4 else clocks :=clocks +10;
      end;

      $CA: // RET IMMED16
      begin
        src := getMem(W_SIZE);
        ip := pop();
        cs := pop();
        sp :=sp + src;
        clocks :=clocks + 17;
      end;

      $CB: // RET (intersegment)
      begin
        ip := pop();
        cs := pop();
        clocks :=clocks + 18;
      end;

      $CC,$CD: //  INT 3
      begin
        if OpCode=$CC then callInt(3) else
        callInt( getMem(B_SIZE));
        if OpCode=$CC then clocks:=clocks+52 else clocks:=clocks+51;
      end;

      $CE: //  INTO
      begin
        if (getFlag(OF1)) then
        begin
          callInt(4);
          clocks:=clocks+53;
        end
        else
        clocks:=clocks+ 4;
      end;

      $CF: //  IRET
      begin
        ip := pop();
        cs := pop();
        flags := pop();
        clocks := clocks +24;
      end;

      $D0,$D1,$D2,$D3: //
      begin
        ModRegRM();
        Dst := GetRM(W, Mode, Rm);
        Src := IfThen((OpCode = $D0) or (OpCode = $D1), 1, CL);
        case (Reg) of
          0: //   ROL
          begin
            for I := 0 to  Src-1 do
            begin
              tempCF := msb(W, Dst);
              Dst :=Dst shl 1;
              Dst := Dst or IfThen(tempCF ,1 ,0);
              Dst :=Dst and MASK[W];
            end;
            SetFlag(CF, (Dst and 1) = 1);
            if (Src = 1) then
            SetFlag(OF1, msb(W, Dst) xor GetFlag(CF));
          end;
          1: // ROR
          begin
            for  I := 0 to Src-1 do
            begin
              tempCF := (Dst and 1) = 1;
              Dst :=Dst shr 1;
              Dst :=Dst or (IfThen(tempCF ,1,  0)) * SIGN[W];
              Dst := Dst and MASK[W];
            end;
            setFlag(CF, msb(W, Dst));
            if (Src = 1) then
            SetFlag(OF1, msb(W, Dst)xor  msb(W, Dst shl 1));
          end;
          2: // RCL
          begin
            for I := 0 to  Src-1 do
            begin
              tempCF := msb(W, Dst);
              Dst :=Dst shl 1;
              Dst :=Dst or  IfThen(getFlag(CF) , 1,0);
              Dst :=Dst and MASK[W];
              SetFlag(CF, tempCF);
            end;
            if (src = 1) then
            SetFlag(OF1, msb(W, Dst) xor GetFlag(CF));
          end;
          3: //  RCR
          begin
            if (Src = 1) then
            SetFlag(OF1, msb(w, dst) xor getFlag(CF));
            for I := 0 to  Src-1 do
            begin
              tempCF := (Dst and 1) = 1;
              Dst :=Dst shr 1;
              Dst := Dst or (IfThen(getFlag(CF),1,0)) * SIGN[W];
              Dst := Dst and MASK[W];
              SetFlag(CF, tempCF);
            end;
          end;
          4: //  SAL/SHL
          begin
            for I := 0 to  Src-1 do
            begin
              SetFlag(CF, (Dst and SIGN[W]) = SIGN[W]);
              Dst := Dst shl 1;
              Dst :=Dst and MASK[w];
            end;
                    // Determine overflow.
            if (Src = 1) then
            SetFlag(OF1, ((Dst and SIGN[W]) = SIGN[W]) xor getFlag(CF));
            if (src > 0) then
            SetFlags(W, Dst);
          end;
          5: //
          begin // SHR
                    // Determine overflow.
            if (Src = 1) then
            SetFlag(OF1, (Dst and SIGN[w]) = SIGN[W]);
            for I := 0 to  Src-1 do
            begin
              SetFlag(CF, (dst and 1) = 1);
              Dst :=Dst shr 1;
              Dst :=Dst and MASK[W];
            end;
            if (Src > 0) then
            SetFlags(w, dst);
          end;
          7: //
          begin // SAR
                    // Determine overflow.
            if (src = 1) then
            setFlag(OF1, false);
            for I := 0 to  src-1 do
            begin
              setFlag(CF, (dst and 1) = 1);
              dst := signconv(w, dst);
              dst := dst shr 1;
              dst :=dst and MASK[w];
            end;
            if (src > 0) then
            setFlags(w, dst);
          end;
          else ShowMessageDlg('Hata reg');
         end;
        setRM(w, mode, rm, dst);
        if (OpCode = $D0) or  (OpCode = $D1) then
        if mode=3 then clocks :=clocks +2 else  clocks :=clocks +15
        else
        begin
          if mode=3 then clocks :=clocks +(8 + 4 * src) else  clocks :=clocks +(20 + 4 * src);
        end;
      end;

      $D4: //  AAM
      begin
        src := getMem(B_SIZE);
        if (src = 0) then
        callInt(0)
        else
        begin
          ah := al div src and $ff;
          al := al mod src and $ff;
          setFlags(W_SIZE, getReg(W_SIZE, REG_AX));
          clocks := clocks +83;
        end;
      end;

      $D5: // AAD
      begin
        src := getMem(B_SIZE);
        al := ah * src + al and $ff;
        ah := 0;
        setFlags(B_SIZE, al);
        clocks := clocks +60;
      end;

      $D7: // XLAT SOURCE-TABLE
      begin
        al := getMem(B_SIZE, getAddr(os, getReg(W_SIZE, REG_BX) + al));
        clocks :=clocks + 11;
      end;

      $D8..$DF: //  ESC 0..7,SOURCE
      begin
        ModRegRM();
        if mode=3 then clocks :=clocks +2 else  clocks :=clocks +8;

      end;

      $E0: //  LOOPNE/LOOPNZ SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        src := (getReg(W_SIZE, REG_CX)- 1) and $ffff;
        setReg(W_SIZE, REG_CX, src);
        if (src <> 0) and  (not getFlag(ZF)) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +19;
        end
        else
        clocks := clocks +5;
      end;

      $E1: //  LOOPE/LOOPZ SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        src := (getReg(W_SIZE, REG_CX)- 1) and $ffff;
        setReg(W_SIZE, REG_CX, src);
        if (src <> 0) and (getFlag(ZF)) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +18;
        end
        else
        clocks :=clocks + 6;
      end;

      $E2: // LOOP SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        src := (getReg(W_SIZE, REG_CX) - 1) and $ffff;
        setReg(W_SIZE, REG_CX, src);
        if (src <> 0) then
        begin
          ip := (ip + dst) and $ffff;
          clocks := clocks +17;
        end
        else
        clocks := clocks +5;
      end;

      $E3: //  JCXZ SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        if (getReg(W_SIZE, REG_CX) = 0) then
        begin
          ip := (ip + dst) and $ffff;
          clocks :=clocks + 18;
        end
        else
        clocks := clocks +6;
      end;

      $E4,$E5: //  IN AX AL,IMMED8
      begin
        src := getMem(B_SIZE);
        SetReg(W,REG_AX, portIn(w, src));
        clocks := clocks +10;
        if (w = W_SIZE) and ((src and 1) = 1)  then
        clocks := clocks +4;
      end;

      $E8: // CALL NEAR-PROC
      begin
        dst := getMem(W_SIZE);
        dst := signconv(W_SIZE, dst);
        push(ip);
        ip := (ip + dst) and $ffff;
        clocks :=clocks + 19;
      end;

      $E9: // JMP NEAR-LABEL
      begin
        dst := getMem(W_SIZE);
        dst := signconv(W_SIZE, dst);
        ip := (ip + dst) and $ffff;
        clocks :=clocks + 15;
      end;

      $EA: //  JMP FAR-LABEL
      Begin
        Dst := getMem(W_SIZE);
        Src := getMem(W_SIZE);
        IP := dst;
        CS := Src;
        Clocks:= Clocks +15;
      end;

      $EB: //  JMP SHORT-LABEL
      begin
        Dst := GetMem(S_SIZE);
        ip := (ip + dst) and $ffff;
        clocks := clocks +15;
      end;

      $EC,$ED: //  IN AX AL ,DX
      begin
        src := getReg(W_SIZE,REG_DX);
        setReg(W, REG_AX, portIn(W, src));
        clocks := clocks +8;
        if (w = W_SIZE) and ((src and 1) = 1)then
        clocks := clocks +4;
      end;

      $E6,$E7: // OUT AX AL ,IMMED8
      begin
        src := getMem(B_SIZE);
        portOut(w, src,GetReg(w,REG_AX));
        clocks := clocks +10;
        if (w = W_SIZE) and ((src and 1) = 1)then
        clocks :=clocks + 4;
      end;

      $EE,$EF: // OUT  AX AL ,DX
      begin
        src := getReg(W_SIZE, REG_DX);
        portOut(w, src,getReg(W, REG_AX));
        clocks :=clocks + 8;
        if (w = W_SIZE) and ((src and 1) = 1) then
        clocks := clocks +4;
      end;

      $F0: //  LOCK
      begin
        clocks :=clocks + 2;
      end;

      $FE: //  INC DEC REG8/MEM8
      begin
        ModRegRM();
        src := getRM(w, mode, rm);
        case (reg) of
          0: //  INC
          begin
            res := op_inc(w, src);
            setRM(w, mode, rm, res);
          end;
          1: //  DEC
          begin
            res := op_dec(w, src);
            setRM(w, mode, rm, res);
          end;
          else ShowMessageDlg('Hata reg');
        end;
        if mode=3 then clocks :=clocks +3 else  clocks :=clocks +15;
      end;

      $F4: // CLD
      begin
        ShowMessageDlg('hata f4');



        clocks := clocks +2;
        result:=false;
        exit;
      end;

      $F5: //  CMC
      begin
        SetFlag(CF, not getFlag(CF));
        Clocks :=Clocks + 2;
      end;

      $f6,$f7: // GROUP 3
      begin
        ModRegRM();
        src := getRM(w, mode, rm);
        case (reg) of
          0: // TEST
          begin
            dst := getMem(w);
            op_logic(w, dst and src);
            if mode=3 then clocks :=clocks +5 else  clocks :=clocks +11;
          end;
          2: // NOT
          begin
            setRM(w, mode, rm, not src);
            if mode=3 then clocks :=clocks +3 else  clocks :=clocks +16;
          end;
          3: //  NEG
          begin
            dst := op_sub(w, 0, src);
            setFlag(CF, dst > 0);
            setRM(w, mode, rm, dst);
            if mode=3 then clocks :=clocks +3 else  clocks :=clocks +16
          end;
          4: //  MUL
          begin
            if (w = B_SIZE) then
            begin
              dst := al;
              res := (dst * src) and $ffff;
              setReg(W_SIZE, REG_AX, res);
              if (ah > 0) then
              begin
                setFlag(CF, true);
                setFlag(OF1, true);
              end
              else
              begin
                setFlag(CF, false);
                setFlag(OF1, false);
              end;
              if mode=3 then clocks :=clocks +(77 - 70) div 2 else  clocks :=clocks +(83 - 76) div 2;

            end
            else
            begin
              dst := getReg(W_SIZE, REG_AX);
              lres := Integer( dst) * Integer( src) and $ffffffff;
              setReg(W_SIZE, REG_AX, Integer( lres));
              setReg(W_SIZE, REG_DX, Integer (lres shr 16));
              if (getReg(W_SIZE, REG_DX) > 0) then
              begin
                setFlag(CF, true);
                setFlag(OF1, true);
              end
              else
              begin
                setFlag(CF, false);
                setFlag(OF1, false);
              end;
              if mode=3 then clocks :=clocks +(133 - 118) div 2 else  clocks :=clocks +(139 - 124) div 2;

            end;
          end;
          5: //  IMUL
          begin
            if (w = B_SIZE) then
            begin
              src := signconv(B_SIZE, src);
              dst := al;
              dst := signconv(B_SIZE, dst);
              res := (dst * src) and $ffff;
              setReg(W_SIZE, REG_AX, res);
              if (ah > $00) and (ah < $ff) then
              begin
                setFlag(CF, true);
                setFlag(OF1, true);
              end
              else
              begin
                setFlag(CF, false);
                setFlag(OF1, false);
              end;
              if mode=3 then clocks :=clocks +(98 - 80) div 2 else  clocks :=clocks +(154 - 128) div 2;

            end
            else
            begin
              src := signconv(W_SIZE, src);
              dst := ah shl 8 or al;
              dst := signconv(W_SIZE, dst);
              lres :=  (Integer(dst) *  Integer(src)) and $ffffffff;

              setReg(W_SIZE, REG_AX, Integer(lres));
              setReg(W_SIZE, REG_DX, Integer((lres shr 16)));
              i := getReg(W_SIZE, REG_DX);
              if (i > $0000) and (i < $ffff) then
              begin
                setFlag(CF, true);
                setFlag(OF1, true);
              end
              else
              begin
                setFlag(CF, false);
                setFlag(OF1, false);
              end;
              if mode=3 then clocks :=clocks +(104 - 86) div 2 else  clocks :=clocks +(160 - 134) div 2;
            end;
          end;
          6: // DIV
          begin
            if (src = 0)  then
            callInt(0)
            else if (w = B_SIZE) then
            begin
              dst := ah shl 8 or al;
              res := (dst div src) and $ffff;
              if (res > $ff) then
              callInt(0)
              else
              begin
                al := res and $ff;
                ah := dst mod src and $ff;
              end;
              if mode=3 then clocks :=clocks +(90 - 80) div 2 else  clocks :=clocks +(96 - 86) div 2;

            end
            else
            begin
              ldst := Integer( getReg(W_SIZE, REG_DX) shl 16 or getReg(W_SIZE, REG_AX));
              lres := (ldst div src) and $ffffffff;
              if (lres > $ffff) then
              callInt(0)
              else
              begin
                setReg(W_SIZE, REG_AX, integer( lres));
                lres := (ldst mod src) and $ffff;
                setReg(W_SIZE, REG_DX, Integer( lres));
              end;
              if mode=3 then clocks :=clocks +(162 - 144) div 2 else  clocks :=clocks +(168 - 150) div 2;

            end;
          end;
          7: //  IDIV
          begin
            if (src = 0) then
            callInt(0)
            else if (w = B_SIZE) then
            begin
              src := signconv(B_SIZE, src);
              dst := getReg(W_SIZE, REG_AX);
              dst := signconv(W_SIZE, dst);
              res := (dst div src) and $ffff;
              if (res > $007f) and (res < $ff81) then
              callInt(0)
              else
              begin
                al := res and $ff;
                ah := dst mod src and $ff;
              end;
              if mode=3 then clocks :=clocks +(112 - 101) div 2 else  clocks :=clocks +(118 - 107) div 2;

            end
            else
            begin
              src := signconv(W_SIZE, src);
              ldst :=  Integer(getReg(W_SIZE, REG_DX) shl 16 or getReg(W_SIZE, REG_AX));
                        // Do sign conversion manually.

              ldst := ldst shl 32 shr 32;
              lres := (ldst div src) and $ffffffff;
              if (lres > $00007fff) or (lres < $ffff8000) then
              callInt(0)
              else
              begin
                setReg(W_SIZE, REG_AX, Integer( lres));
                lres := (ldst mod src) and $ffff;
                setReg(W_SIZE, REG_DX, Integer( lres));
              end;
              if mode=3 then clocks :=clocks +(184 - 165) div 2 else  clocks :=clocks +(190 - 171) div 2;

            end;
          end
          else ShowMessageDlg('Hata reg');
        end;
      end;


      $F8: // CLC
      begin
        SetFlag(CF, false);
        Clocks := Clocks + 2;
      end;

      $F9: //  STC
      begin
        SetFlag(CF, true);
        Clocks := Clocks +2;
      end;

      $FA: //  CLD
      begin
        setFlag(IF1, false);
        clocks := clocks +2;

        // IntToHex(opcode2,4,str);

       // showmessage(str);
      end;

      $FB: // CLD
      begin
        setFlag(IF1, true);
        clocks := clocks +2;
      end;

      $FC: // CLD
      begin
        setFlag(DF, false);
        clocks := clocks +2;
      end;
      
      $FD: //  CLD
      begin
        setFlag(DF, true);
        clocks := clocks +2;
      end;

      $ff: //  GROUP 5
      begin
        ModRegRM();
        src := getRM(w, mode, rm);
        case (reg) of
          0: //  INC
          begin
            res := op_inc(w, src);
            setRM(w, mode, rm, res);
            if mode=3 then clocks :=clocks +3 else  clocks :=clocks +15;
          end;
          1: //  DEC
          begin
            res := op_dec(w, src);
            setRM(w, mode, rm, res);
            if mode=3 then clocks :=clocks +3 else  clocks :=clocks +15;
          end;
          2: //  CALL
          begin
            push(ip);
            ip := src;
            if mode=3 then clocks :=clocks +16 else  clocks :=clocks +21;
          end;
          3: //  CALL
          begin
            push(cs);
            push(ip);
            dst := getEA(modE, rm);
            ip := getMem(W_SIZE, dst);
            cs := getMem(W_SIZE, dst + 2);
            clocks := clocks +37;
          end;
          4: //  JMP
          begin
            ip := src;
            if mode=3 then clocks :=clocks +11 else  clocks :=clocks +18;
          end;
          5: //  JMP
          begin
            dst := getEA(mode, rm);;
            ip :=  getMem(W_SIZE, dst);
            cs :=  getMem(W_SIZE, dst + 2);
            clocks := clocks +24;
          end;
          6: //  PUSH
          begin 
            push(src);
            if mode=3 then clocks :=clocks +11 else  clocks :=clocks +16;
          end;
          else ShowMessageDlg('Hata reg');

        end;
      end;
      else
      begin
        ShowMessageDlg('HATALI OPCODE  '); Result:=false; exit;
      end;



    end;// Case op
  until  not (rep > 0);


  Result:= true;
end;



procedure TPCEmulator.LoadFile(FileName: PChar; Addr: Integer);
var
 F       : Integer;
 Size    : Integer;
begin
  F := FileOpen(FileName, FILE_READ);
  if F <> INVALID_HANDLE then 
  begin
    Size := FileGetSize(F);
    FileRead(F, @Memory[Addr], Size);
    FileClose(F);
 end;
end;


procedure TPCEmulator.Reset();
begin
  Ruing:=False;
  Flags := 0;
  IP := $0000;
  CS := $ffff;
  SP := $FFFE;
  DS := $0000;
  SS := $0000;
  ES := $0000;
  Clocks := 0;
  FillChar(Memory, $100000, #0);
end;

function RGB(r, g, b: Byte): LongInt;
begin
    RGB := (b shl 16) or (g shl 8) or r;
end;

procedure TPCEmulator.Run();
begin
   Ruing:=True;
end;

procedure TPCEmulator.Create();   // GetKernelMemPtr
begin
  dma.Create;
  pic.Create();
  Intelpit.Create();
  ppi.Create();
  crtc.Create;
end;

procedure TPCEmulator.Destroy;
begin
  Reset();
end;

procedure UpdateCursorBlink;
const
  BLINK_INTERVAL = 50;
var
  t: LongWord;
begin
  t := GetTickCount;
  if (t - LastBlinkTick) >= BLINK_INTERVAL then
  begin
    CursorBlinkOn := not CursorBlinkOn;
    LastBlinkTick := t;
  end;
end;

procedure DrawForm(Sender: LongWord; AX, AY: Integer);
var
  x, y: Integer;
  character: Byte;
  attribute: Byte;
  foreColor, backColor: TColor;
  cellX, cellY: Integer;
  curAttr,curLoc:integer;
begin
  curAttr := crtc.getRegister($a) shr 4;
  curLoc := crtc.getRegister($f) or crtc.getRegister($e) shl 8;
  UpdateCursorBlink();

 for y := 0 to 24 do
  begin
    for x := 0 to 79 do
    begin
      character  :=Memory[$B8000 + 2 * (x + y * 80)];
      attribute  :=Memory[$B8000 + 2 * (x + y * 80) + 1];

      foreColor := RGB(
                   colors[attribute and $0F,0],
                   colors[attribute and $0F,1],
                   colors[attribute and $0F,2]);

      backColor := RGB(
                   colors[(attribute shr 4) and $0F,0],
                   colors[(attribute shr 4) and $0F,1],
                   colors[(attribute shr 4) and $0F,2]);

       cellX :=8  + AX + x * CharWidth;
       cellY :=30 + AY + y * CharHeight;

      if (cellX + CharWidth  > AX + PCEmulator1.Width)  then Continue;
      if (cellY + CharHeight > AY + PCEmulator1.Height) then Continue;

     KFill(cellX, cellY, CharWidth, CharHeight, backColor);

     if ((x + y * 80 = curLoc) and (curAttr and 1 = 0 )) and CursorBlinkOn  then
     begin
        KChar(cellX, cellY, Char('_'),foreColor);
     end
     else
     if (character >= 32) and (character < 128) then  
     begin
        KChar(cellX, cellY,Char(character) ,foreColor);
     end;
    end;
  end;
end;

procedure OnCloseForm(Sender: LongWord);
begin
  PCEmulator1.Ruing:=False;

  if ThreadHandle > 0 then
    KillThread(ThreadHandle);
end;

procedure OnFormKeyDown(Sender: LongWord; Key: Word);
begin
   KeyCode:=Char(key);
end;

procedure OnFormKeyUp(Sender: LongWord; Key: Word);
begin
end;

procedure BasicWorker(Proc: PPCEmulator); stdcall;
begin
  while Proc^.Ruing and  Proc^.Execute do
  begin
  
  end;
end;



procedure MyWndProc(hWnd: LongWord; Msg: LongWord;
                    WParam, LParam: LongWord);
var
  X,Y:Integer;
begin
  case Msg of
    WM_PAINT:
      begin
         X:=SmallInt(LParam and $FFFF);
         Y:=SmallInt((LParam shr 16) and $FFFF);
      end;
    WM_CLOSE:
      begin
         ExitProcess(0);
      end;
  end;
end;

begin
  MainWndProc   := @MyWndProc;
  ThreadHandle  := -1;

  PCEmulator1.Width   :=(8*(80))+16;
  PCEmulator1.Height  :=(8*(25))+38;
 


  Form := LongWord(CreateForm(80, 60, PCEmulator1.Width, PCEmulator1.Height));

  GuiBindPaint  (Form, @DrawForm);
  GuiBindKeyDown(Form, @OnFormKeyDown);
  GuiBindKeyUp  (Form, @OnFormKeyUp);
  GuiBindDestroy(Form, @OnCloseForm);
 
 
  {
  IntToPChar(PCEmulator1.Memory[$FE000], @str[0]);
  DebugPrint(str);  }
   
  PCEmulator1.Create;
  PCEmulator1.Reset;

  PCEmulator1.LoadFile('C:\Bios.bin',$fe000);
  PCEmulator1.LoadFile('C:\Basic.bin',$f6000);

  
  ThreadHandle := BeginThread(
    @BasicWorker,
    @PCEmulator1,
    'Basic',
    PRIO_HIGH, TF_KERNEL
  );  

   PCEmulator1.Run();



  while true do
  begin
    if GetMessage(Msg) then
       DispatchMessage(Msg);
  end;

  ExitProcess(0);
 
end.

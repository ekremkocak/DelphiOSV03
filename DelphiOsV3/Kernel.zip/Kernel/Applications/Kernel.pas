library Kernel;



function _Add(A,B:Integer):Integer; stdcall;
begin
  Result := A + B;
end;

exports
   _Add  name 'Add';

begin
end.

unit UserGUI;

interface

const
    { Olay tipleri }
  REDRAW_EVENT = 1;
  KEY_EVENT    = 2;
  BUTTON_EVENT = 3;

   // Priority seviyeleri
  PRIO_IDLE        = 0;
  PRIO_LOW         = 1;
  PRIO_NORMAL      = 2;
  PRIO_HIGH        = 3;
  PRIO_REALTIME    = 4;

  // Thread flag'leri
  TF_KERNEL        = $01;      // Kernel thread
  TF_USER          = $02;      // User thread
  TF_DETACHED      = $04;      // Join beklenmiyor

  { Yeni syscall numaralar� }
  SYS_WAIT_EVENT  = 20;
  SYS_DRAW_WINDOW = 21;
  SYS_DRAW_TEXT   = 22;
  SYS_GET_KEY     = 23;
  SYS_GET_BUTTON  = 24;

  SYS_CREATE_BUTTON = 40;
  SYS_CREATE_PANEL  = 41;
  SYS_CREATE_LABEL  = 42;
  SYS_CREATE_EDIT   = 43;


  SYS_FILL_RECT = 201;
  SYS_LINE_H    = 202;
  SYS_LINE_V    = 203;

const
  // ============================================================
  // WINDOW MESSAGES ($0000 - $0300)
  // ============================================================
  WM_NULL           = $0000;
  WM_CREATE         = $0001;
  WM_DESTROY        = $0002;
  WM_MOVE           = $0003;
  WM_SIZE           = $0005;
  WM_ACTIVATE       = $0006;
  WM_SETFOCUS       = $0007;
  WM_KILLFOCUS      = $0008;
  WM_ENABLE         = $000A;
  WM_SETREDRAW      = $000B;
  WM_SETTEXT        = $000C;
  WM_GETTEXT        = $000D;
  WM_GETTEXTLENGTH  = $000E;
  WM_PAINT          = $000F;
  WM_CLOSE          = $0010;
  WM_QUERYENDSESSION= $0011;
  WM_QUIT           = $0012;
  WM_QUERYOPEN      = $0013;
  WM_ERASEBKGND     = $0014;
  WM_SYSCOLORCHANGE = $0015;
  WM_SHOWWINDOW     = $0018;
  WM_CTLCOLORMSGBOX = $0132;
  
  // Keyboard Messages ($0100 - $0108)
  WM_KEYDOWN        = $0100;
  WM_KEYUP          = $0101;
  WM_CHAR           = $0102;
  WM_DEADCHAR       = $0103;
  WM_SYSKEYDOWN     = $0104;
  WM_SYSKEYUP       = $0105;
  WM_SYSCHAR        = $0106;
  WM_SYSDEADCHAR    = $0107;
  WM_KEYLAST        = $0108;
  
  // Mouse Messages ($0200 - $020E)
  WM_MOUSEMOVE      = $0200;
  WM_LBUTTONDOWN    = $0201;
  WM_LBUTTONUP      = $0202;
  WM_LBUTTONDBLCLK  = $0203;
  WM_RBUTTONDOWN    = $0204;
  WM_RBUTTONUP      = $0205;
  WM_RBUTTONDBLCLK  = $0206;
  WM_MBUTTONDOWN    = $0207;
  WM_MBUTTONUP      = $0208;
  WM_MBUTTONDBLCLK  = $0209;
  WM_MOUSEWHEEL     = $020A;
  WM_MOUSELEAVE     = $02A3;
  WM_MOUSEENTER     = $02A1;

  WM_MEMOCUT        = $300;
  WM_MEMOCOPY       = $302;
  WM_MEMOPASTE      = $304;
  WM_SELECTALL      = $306;

  
  // Scroll Messages ($0100 - $0115)
  WM_VSCROLL        = $0115;
  WM_HSCROLL        = $0114;
  
  // Command & Control Messages ($0110 - $0150)
  WM_COMMAND        = $0111;
  WM_INITDIALOG     = $0110;
  WM_TIMER          = $0113;
  WM_MEMO           = $0120;
  WM_NOTIFY         = $004E;
  
  // Custom Messages ($0400 - $7FFF)
  WM_USER           = $0400;
  WM_APP            = $8000;

  WM_PARAMS         = $0403;

  // ============================================================
  // WINDOW STYLES (Base & Extended)
  // ============================================================
  
  // Base Window Styles ($00000000 - $F0000000)
  WS_OVERLAPPED     = $00000000;  // Default overlapped window
  WS_POPUP          = $80000000;  // Pop-up window
  WS_CHILD          = $40000000;  // Child window
  WS_MINIMIZE       = $20000000;  // Minimized window
  WS_VISIBLE        = $10000000;  // Visible window
  WS_DISABLED       = $08000000;  // Disabled window
  WS_CLIPSIBLINGS   = $04000000;  // Clip siblings
  WS_CLIPCHILDREN   = $02000000;  // Clip children
  WS_MAXIMIZE       = $01000000;  // Maximized window
  WS_MODAL          = $06000000; 
  
  // Window Decoration Styles ($00C00000 - $00000000)
  WS_CAPTION        = $00C00000;  // WS_BORDER | WS_DLGFRAME
  WS_BORDER         = $00800000;  // Window border
  WS_DLGFRAME       = $00400000;  // Dialog frame
  WS_VSCROLL        = $00200000;  // Vertical scroll bar
  WS_HSCROLL        = $00100000;  // Horizontal scroll bar
  
  // Window Feature Styles ($00080000 - $00000000)
  WS_SYSMENU        = $00080000;  // System menu
  WS_THICKFRAME     = $00040000;  // Resizable frame
  WS_GROUP          = $00020000;  // Group radio buttons
  WS_TABSTOP        = $00010000;  // Tab stop
  WS_MINIMIZEBOX    = $00020000;  // Minimize box
  WS_MAXIMIZEBOX    = $00010000;  // Maximize box
  
  // Composite Styles
  WS_OVERLAPPEDWINDOW = WS_OVERLAPPED or WS_CAPTION or WS_SYSMENU or
                        WS_THICKFRAME or WS_MINIMIZEBOX or WS_MAXIMIZEBOX;
  WS_POPUPWINDOW      = WS_POPUP or WS_BORDER or WS_SYSMENU;
  WS_CHILDWINDOW      = WS_CHILD;
  WS_TILEDWINDOW      = WS_OVERLAPPEDWINDOW;
  
  // ============================================================
  // ALIGN STYLES ($0000F000 - Window Align)
  // ============================================================
  WS_ALIGN_MASK     = $0000F000;  // Align bits mask
  WS_ALIGN_NONE     = $00000000;  // alNone - Manual positioning
  WS_ALIGN_TOP      = $00001000;  // alTop - Dock to top
  WS_ALIGN_BOTTOM   = $00002000;  // alBottom - Dock to bottom
  WS_ALIGN_LEFT     = $00003000;  // alLeft - Dock to left
  WS_ALIGN_RIGHT    = $00004000;  // alRight - Dock to right
  WS_ALIGN_CLIENT   = $00005000;  // alClient - Fill remaining space
  
  // ============================================================
  // CONTROL STYLES (Button, Edit, Static, etc.)
  // ============================================================
  
  // Button Styles (BS_*)
  BS_PUSHBUTTON     = $00000000;  // Standard push button
  BS_DEFPUSHBUTTON  = $00000001;  // Default push button
  BS_CHECKBOX       = $00000002;  // Checkbox
  BS_AUTOCHECKBOX   = $00000003;  // Auto checkbox
  BS_RADIOBUTTON    = $00000004;  // Radio button
  BS_3STATE         = $00000005;  // 3-state button
  BS_AUTO3STATE     = $00000006;  // Auto 3-state
  BS_GROUPBOX       = $00000007;  // Group box
  BS_USERBUTTON     = $00000008;  // User button
  BS_AUTORADIOBUTTON= $00000009;  // Auto radio button
  BS_OWNERDRAW      = $0000000B;  // Owner draw
  BS_SPLITBUTTON    = $0000000C;  // Split button
  BS_DEFSPLITBUTTON = $0000000D;  // Default split button
  BS_COMMANDLINK    = $0000000E;  // Command link
  BS_DEFCOMMANDLINK = $0000000F;  // Default command link
  
  // Button State Styles (BS_*)
  BS_TEXT           = $00000000;  // Text
  BS_ICON           = $00000040;  // Icon
  BS_BITMAP         = $00000080;  // Bitmap
  BS_LEFT           = $00000100;  // Left align
  BS_RIGHT          = $00000200;  // Right align
  BS_CENTER         = $00000300;  // Center align
  BS_TOP            = $00000400;  // Top align
  BS_BOTTOM         = $00000800;  // Bottom align
  BS_VCENTER        = $00000C00;  // Vertical center
  BS_PUSHLIKE       = $00001000;  // Push-like
  BS_MULTILINE      = $00002000;  // Multi-line text
  BS_NOTIFY         = $00004000;  // Notify parent
  BS_FLAT           = $00008000;  // Flat appearance
  
  // Edit Styles (ES_*)
  ES_LEFT           = $00000000;  // Left aligned text
  ES_CENTER         = $00000001;  // Center aligned text
  ES_RIGHT          = $00000002;  // Right aligned text
  ES_MULTILINE      = $00000004;  // Multi-line edit
  ES_UPPERCASE      = $00000008;  // Convert to uppercase
  ES_LOWERCASE      = $00000010;  // Convert to lowercase
  ES_PASSWORD       = $00000020;  // Password field (show *)
  ES_AUTOVSCROLL    = $00000040;  // Auto vertical scroll
  ES_AUTOHSCROLL    = $00000080;  // Auto horizontal scroll
  ES_NOHIDESEL      = $00000100;  // Don't hide selection
  ES_OEMCONVERT     = $00000400;  // OEM conversion
  ES_READONLY       = $00000800;  // Read-only
  ES_WANTRETURN     = $00001000;  // Want return key
  ES_NUMBER         = $00002000;  // Numbers only
  
  // Static Styles (SS_*)
  SS_LEFT           = $00000000;  // Left aligned static
  SS_CENTER         = $00000001;  // Center aligned static
  SS_RIGHT          = $00000002;  // Right aligned static
  SS_ICON           = $00000003;  // Icon static
  SS_BLACKRECT      = $00000004;  // Black rectangle
  SS_GRAYRECT       = $00000005;  // Gray rectangle
  SS_WHITERECT      = $00000006;  // White rectangle
  SS_BLACKFRAME     = $00000007;  // Black frame
  SS_GRAYFRAME      = $00000008;  // Gray frame
  SS_WHITEFRAME     = $00000009;  // White frame
  SS_USERITEM       = $0000000A;  // User drawn
  SS_SIMPLE         = $0000000B;  // Simple text
  SS_LEFTNOWORDWRAP = $0000000C;  // Left, no word wrap
  SS_OWNERDRAW      = $0000000D;  // Owner drawn
  SS_BITMAP         = $0000000E;  // Bitmap
  SS_ENHMETAFILE    = $0000000F;  // Enhanced metafile
  SS_ETCHEDHORZ     = $00000010;  // Etched horizontal
  SS_ETCHEDVERT     = $00000011;  // Etched vertical
  SS_ETCHEDFRAME    = $00000012;  // Etched frame
  SS_TYPEMASK       = $0000001F;  // Type mask
  SS_REALSIZECONTROL= $00000040;  // Real size control
  SS_NOPREFIX       = $00000080;  // No prefix processing
  SS_NOTIFY         = $00000100;  // Notify parent
  SS_CENTERIMAGE    = $00000200;  // Center image
  SS_RIGHTJUST      = $00000400;  // Right justify
  SS_REALSIZEIMAGE  = $00000800;  // Real size image
  SS_SUNKEN         = $00001000;  // Sunken style
  SS_EDITCONTROL    = $00002000;  // Edit control style
  SS_ENDELLIPSIS    = $00004000;  // End with ellipsis
  SS_PATHELLIPSIS   = $00008000;  // Path with ellipsis
  SS_WORDELLIPSIS   = $0000C000;  // Word with ellipsis
  SS_ELLIPSISMASK   = $0000C000;  // Ellipsis mask
  

  // ============================================================
  // COLOR CONSTANTS (BGR format - $00BBGGRR)
  // ============================================================
  CLR_BLACK         = $00000000;  // ???
  CLR_MAROON        = $00000080;  // ???
  CLR_GREEN         = $00008000;  // ??
  CLR_OLIVE         = $00008080;  // ???
  CLR_NAVY          = $00800000;  // ????
  CLR_PURPLE        = $00800080;  // ???
  CLR_TEAL          = $00808000;  // ???
  CLR_GRAY          = $00808080;  // ??
  CLR_SILVER        = $00C0C0C0;  // ??
  CLR_RED           = $000000FF;  // ???
  CLR_LIME          = $0000FF00;  // ???
  CLR_YELLOW        = $0000FFFF;  // ???
  CLR_BLUE          = $00FF0000;  // ???
  CLR_FUCHSIA       = $00FF00FF;  // ???
  CLR_AQUA          = $00FFFF00;  // ???
  CLR_WHITE         = $00FFFFFF;  // ??
  CLR_WINDOW        = $00FFFFFF;  // Window background
  CLR_WINDOWFRAME   = $00808080;  // Window frame
  CLR_WINDOWTEXT    = $00000000;  // Window text
  CLR_HIGHLIGHT     = $00000080;  // Highlight color
  CLR_HIGHLIGHTTEXT = $00FFFFFF;  // Highlight text
  CLR_BTNFACE       = $00C0C0C0;  // Button face
  CLR_BTNSHADOW     = $00808080;  // Button shadow
  CLR_BTNTEXT       = $00000000;  // Button text
  
  // ============================================================
  // MAX CONSTANTS
  // ============================================================
  MAX_WINDOWS       = 256;
  MAX_WINDOW_NAME   = 256;
  MAX_CLASS_NAME    = 64;
  MAX_TEXT_SIZE     = 4096;
  MAX_SCREEN_WIDTH  = 1920;
  MAX_SCREEN_HEIGHT = 1080;

  ID_PATHSTATIC = $1000;
  ID_DIRVIEW    = $1001;
  ID_FILENAME   = $1005;
  ID_FILETYPE   = $1006;
  ID_OPEN_BTN   = $1007;
  ID_CANCEL_BTN = $1008;
  ID_SAVE_BTN   = $1009;
  ID_BACK_BTN   = $1010;
  ID_UP_BTN     = $1011;



  // Control class names
  WC_BUTTON    = 'TBUTTON';
  WC_EDIT      = 'TEDIT';
  WC_STATIC    = 'TSTATIC';
  WC_LABEL     = 'TLABEL';
  WC_LISTBOX   = 'TLISTBOX';
  WC_MEMO      = 'TMEMO';
  WC_DIRECTORYVIEW = 'TDIRECTORYVIEW';
  WC_COMBOBOX  = 'TCOMBOBOX';
  WC_PANEL     = 'TPANEL';
  WC_GROUPBOX  = 'TGROUPBOX';
  WC_SCROLLBAR = 'TSCROLLBAR';
  WC_TOOLBAR   = 'TTOOLBAR';
  WC_CHECKBOX  = 'TCHECKBOX';
  WC_TREEVIEW  = 'TTREEVIEW';
  WC_TABCONTROL = 'TTABCONTROL';
  WC_PROGRESSBAR = 'TPROGRESSBAR';
  WC_RADIOBUTTON = 'TRADIOBUTTON';
  WC_RADIOGROUP = 'TRADIOGROUP';
  WC_PAINTBOX = 'TPAINTBOX';
  WC_IMAGE    = 'TIMAGE';
  WC_LISTVIEW  = 'TLISTVIEW';
  
  COLOR_WINDOW  = 5;
  COLOR_BTNFACE = 15;
  
  MAX_WNDCLASS  = 128;


const
  SYS_CREATE_FORM    = 1;
  SYS_DESTROY_FORM   = 2;
  SYS_SHOW_FORM      = 3;
  SYS_HIDE_FORM      = 4;
  SYS_SET_CAPTION    = 5;
  SYS_GET_MESSAGE    = 6;
  SYS_POST_MESSAGE   = 7;
  SYS_EXIT_PROCESS   = 8;
  SYS_ALLOC          = 9;
  SYS_FREE           = 10;
  SYS_GET_PID        = 11;
  SYS_GET_CMDLINE    = 12;
  SYS_GET_YIELD      = 13;
  SYS_BEGIN_THREAD = 14;
  SYS_KILL_THREAD  = 15;
  SYS_REPAINT      = 16;
  SYS_DELAY_MS     = 17;
  SYS_GETTICKCOUNT = 18;


const
  { FAT32 Dosya Sistemi Syscall Numaraları }
  SYS_FILE_OPEN       = $200;
  SYS_FILE_CLOSE      = $201;
  SYS_FILE_READ       = $202;
  SYS_FILE_WRITE      = $203;
  SYS_FILE_SEEK       = $204;
  SYS_FILE_POS        = $205;
  SYS_FILE_SIZE       = $206;
  SYS_FILE_MKDIR      = $207;
  SYS_FILE_DELETE     = $208;
  SYS_FILE_FINDFIRST  = $209;
  SYS_FILE_FINDNEXT   = $20A;
  SYS_FILE_FINDCLOSE  = $20B;
  SYS_FILE_EXISTS     = $20C;
  SYS_DRIVE_COUNT     = $20D;
  SYS_DRIVE_INFO      = $20E;

  { Dosya aç modları }
  FILE_READ    = $01;
  FILE_WRITE   = $02;
  FILE_CREATE  = $04;
  FILE_APPEND  = $08;

  { Seek kaynakları }
  SEEK_SET     = 0;   { Baştan }
  SEEK_CUR     = 1;   { Şu pozisyondan }
  SEEK_END     = 2;   { Sondan }

  { Dosya öznitelikleri (FindFirst için) }
  FA_READONLY  = $01;
  FA_HIDDEN    = $02;
  FA_SYSFILE   = $04;
  FA_VOLID     = $08;
  FA_DIREC     = $10;
  FA_ARCHIVE   = $20;
  FA_ANYFILE   = $3F;

  MAX_PATH     = 256;
  INVALID_HANDLE = -1;  { Geçersiz dosya handle'ı }

const
  SYS_BIND_KEYDOWN    = $300;
  SYS_BIND_KEYUP      = $301;
  SYS_BIND_MOUSEDOWN  = $302;
  SYS_BIND_MOUSEUP    = $303;
  SYS_BIND_MOUSEMOVE  = $304;
  SYS_BIND_PAINT      = $305;
  SYS_BIND_DBLCLICK   = $306;
  SYS_BIND_DESTROY    = $307;
  SYS_UNBIND_ALL      = $308;


const
  { Dialog Syscall'lar� }
  SYS_SHOW_MESSAGE     = 50;
  SYS_MESSAGE_DLG      = 51;
  SYS_INPUT_BOX        = 52;
  SYS_OPEN_DLG         = 53;
  SYS_SAVE_DLG         = 54;
  SYS_GET_DLG_RESULT   = 55;
  SYS_GET_DLG_FILENAME = 56;
  SYS_DEBUG_PRINT      = 57;

const
{ ============================================================
  CONSOLE SYSCALLS (20-24) � eski GUI event'lerinin yerine
  ============================================================ }
  SYS_GETSTDHANDLE  = 20;
  SYS_WRITECONSOLE  = 21;
  SYS_READCONSOLE   = 22;
  SYS_PUTCHAR       = 23;
  SYS_CLEARSCREEN   = 24;
  SYS_SET_CONSOLE_ATTR = 25;

{ ============================================================
  DRAW32 TEK SYSCALL � T�m grafik fonksiyonlar� tek kap�dan
  ============================================================ }
const
  SYS_DRAW32 = $400;
  SYS_MAP_MEMORY = $602;

  { Draw32 Komut Kodlar� }
  DCMD_PUTPIXEL       = 1;
  DCMD_KLINE          = 2;
  DCMD_KLINEH         = 3;
  DCMD_KLINEV         = 4;
  DCMD_KFILL          = 5;
  DCMD_KRECT          = 6;
  DCMD_KCIRCLE        = 7;
  DCMD_KFILLCIRCLE    = 8;
  DCMD_KELLIPSE       = 9;
  DCMD_KFILLELLIPSE   = 10;
  DCMD_KARC           = 11;
  DCMD_KPIE           = 12;
  DCMD_KTRIANGLE      = 13;
  DCMD_KFILLTRIANGLE  = 14;
  DCMD_KROUNDRECT     = 15;
  DCMD_KSTR           = 16;
  DCMD_KSTRCENTERED   = 17;
  DCMD_KSTRRIGHT      = 18;
  DCMD_KCHAR          = 19;
  DCMD_KBUTTON3D      = 20;
  DCMD_KBUTTON3DEX    = 21;
  DCMD_KRECT3D        = 22;
  DCMD_KPANEL3D       = 23;
  DCMD_KSUNKEN        = 24;
  DCMD_KGRADIENTH     = 25;
  DCMD_KGRADIENTV     = 26;
  DCMD_KGRADIENTD     = 27;
  DCMD_KGRADIENTRAD   = 28;
  DCMD_KRAINBOW       = 29;
  DCMD_KFILLALPHA     = 30;
  DCMD_KBLENDPIXEL    = 31;
  DCMD_KSHADOWRECT    = 32;
  DCMD_KGLOWRECT      = 33;
  DCMD_KBITBLT        = 34;
  DCMD_KSTRETCHBLT    = 35;
  DCMD_KTRANSBLT      = 36;
  DCMD_KFLIPH         = 37;
  DCMD_KFLIPV         = 38;
  DCMD_KINVERT        = 39;
  DCMD_KGRAYSCALE     = 40;
  DCMD_KBLUR          = 41;
  DCMD_KGRANITE       = 42;
  DCMD_KMARBLE        = 43;
  DCMD_KWOOD          = 44;
  DCMD_KMETAL         = 45;
  DCMD_KCHECKER       = 46;
  DCMD_KDOTS          = 47;
  DCMD_KHATCH         = 48;
  DCMD_KCROSSHATCH    = 49;
  DCMD_KLINEDASHED    = 50;
  DCMD_KLINEALPHA     = 51;
  DCMD_KSTRSHADOW     = 52;
  DCMD_KSTROUTLINED   = 53;
  DCMD_KBEVEL         = 54;
  DCMD_KEDGE          = 55;
  DCMD_KGROOVE        = 56;
  DCMD_KTITLEBAR      = 57;
  DCMD_K3D            = 58;
  DCMD_KEMBOSS        = 59;
  DCMD_KPOLYGON       = 60;
  DCMD_KBUTTON3DDIS   = 62;
  DCMD_KSTRCLIPPED    = 63;

type
  { Tek ortak parametre record'u � kullan�lmayan alanlar 0 kal�r }
  TDraw32Cmd = packed record
    Cmd: Byte;
    Pad: Byte;
    X, Y, W, H: Integer;
    X2, Y2: Integer;
    Color, Color2: LongWord;
    Text: PChar;
    Radius: Integer;
    Alpha: Byte;
    Raised, Pressed, Hover: Byte;
    DashLen: Integer;
    StartAngle, EndAngle: Integer;
    Src: Pointer;
    SrcW, SrcH: Integer;
    TransColor: LongWord;
    TileSize, Spacing: Integer;
    Density: Integer;
    BevelW: Integer;
    EdgeType: Integer;
    ShadowSize, GlowSize: Integer;
    Passes: Integer;
    Active: Byte;
    DstW, DstH: Integer;
    Count: Integer;
    Points: Pointer;
  end;
  PDraw32Cmd = ^TDraw32Cmd;



type
  TConsoleWriteParams = packed record
    Handle: LongWord;
    Buffer: PChar;
    Count: LongWord;
  end;
  PConsoleWriteParams = ^TConsoleWriteParams;

  TConsoleReadParams = packed record
    Handle: LongWord;
    Buffer: PChar;
    Count: LongWord;
  end;
  PConsoleReadParams = ^TConsoleReadParams;

type

 TRepaintParams = packed record
    H: LongWord;
 end;

 TDelayRec = packed record
    MS: LongWord;
 end;


type
  TShowMessageParams = packed record
    Msg: PChar;
  end;

  TMessageDlgParams = packed record
    Msg: PChar;
    DlgType: Byte;
    Buttons: LongWord;
  end;

  TInputBoxParams = packed record
    Caption: PChar;
    Prompt: PChar;
    Default: PChar;
    ResultBuffer: PChar;
    BufferSize: Integer;
  end;

  TOpenDlgParams = packed record
    Title: PChar;
    StartPath: PChar;
    ResultBuffer: PChar;
    BufferSize: Integer;
  end;

  TSaveDlgParams = packed record
    Title: PChar;
    StartPath: PChar;
    ResultBuffer: PChar;
    BufferSize: Integer;
  end;

  TGetDlgResultParams = packed record
    FormHandle: LongWord;
  end;

  TGetDlgFileNameParams = packed record
    FormHandle: LongWord;
    Buffer: PChar;
    BufSize: Integer;
  end;

  

type
  { EXE tarafındaki callback imzaları — kernel TObject'teki ile aynı }
  TDestroyProc  = procedure(Sender: LongWord);
  TMouseProc    = procedure(Sender: LongWord; AX, AY: Integer; Btn: Byte);
  TPaintProc    = procedure(Sender: LongWord; AX, AY: Integer);
  TKeyDownProc  = procedure(Sender: LongWord; Key: Word);

  { Tek ortak param record }
  TBindEventParams = packed record
    Handle : LongWord;   { CreateForm/CreateButton vb. döndürdüğü handle }
    Proc   : Pointer;    { @MyProcedure }
  end;




type
  { Dosya bulma bilgisi (kernel TSearchRec ile aynı yapı) }
  TSearchRec = record
    Name      : array[0..MAX_PATH-1] of Char;
    ShortName : array[0..12] of Char;
    Attr      : Byte;
    FileSize  : LongWord;
    StartCluster : LongWord;
    IsDir     : Boolean;
    ImageFile : PChar;
  end;
  PSearchRec = ^TSearchRec;

  { Sürücü bilgisi (basit) }
  TDriveInfoOut = packed record
    Present  : Byte;
    Letter   : Char;
    IsFAT32  : Byte;
    TotalMB  : LongWord;
  end;
  PDriveInfoOut = ^TDriveInfoOut;

  { ── İç Param Record'lar (DoSyscall için) ── }
  TFileOpenParams = packed record
    Path : PChar;
    Mode : Byte;
  end;

  TFileHandleParams = packed record
    Handle : Integer;
  end;

  TFileRWParams = packed record
    Handle : Integer;
    Buffer : Pointer;
    Size   : LongWord;
  end;

  TFileSeekParams = packed record
    Handle : Integer;
    Offset : LongInt;
    Origin : Byte;
  end;

  TFilePathParams = packed record
    Path : PChar;
  end;

  TFileFindFirstParams = packed record
    Path      : PChar;
    Pattern   : PChar;
    Attr      : Byte;
    SearchRec : PSearchRec;
  end;

  TFileFindNextParams = packed record
    FindHandle : Integer;
    SearchRec  : PSearchRec;
  end;

  TDriveInfoParams = packed record
    DriveIndex : Integer;
    InfoOut    : PDriveInfoOut;
  end;


type
  HWND     = LongWord;
  WPARAM   = LongWord;
  LPARAM   = LongWord;
  LRESULT  = LongWord;

type
  TMessage = packed record
    hWnd   : HWND;
    Msg    : LongWord;
    WParam : LongWord;
    LParam : LongWord;
  end;


 type
  TCreatePanelParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateButtonParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateLabelParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateEditParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateMemoParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateComboBoxParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateListBoxParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateCheckBoxParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateRadioButtonParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateGroupBoxParams = packed record
    Parent: LongWord;
    Caption: PChar;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateProgressBarParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateTrackBarParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateImageParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateSplitterParams = packed record
    Parent: LongWord;
    Left, Top: Integer;
    Size: Integer;
    Horizontal: Byte;
    Align: Byte;
  end;

  TCreateStatusBarParams = packed record
    Parent: LongWord;
    Left, Top, Width: Integer;
    Align: Byte;
  end;

  TCreateMenuItemParams = packed record
    Caption: PChar;
  end;

  TCreateMenuBarParams = packed record
    Parent: LongWord;
    Left, Top, Width: Integer;
    Align: Byte;
  end;

  TCreateListViewParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateTabControlParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateTreeViewParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateSplitterPanelParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Orientation: Byte;
    Align: Byte;
  end;

  TCreateToolBarParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TCreateScrollBarParams = packed record
    Parent: LongWord;
    Left, Top, Width, Height: Integer;
    Align: Byte;
  end;

  TGuiHandleParams = packed record
    Handle: LongWord;
  end;

  TGuiSetIntParams = packed record
    Handle: LongWord;
    Value: Integer;
  end;

  TGuiSetTextParams = packed record
    Handle: LongWord;
    Text: PChar;
  end;

  TGuiGetTextParams = packed record
    Handle: LongWord;
    Buffer: PChar;
    BufSize: Integer;
  end;

  TGuiSetBoolParams = packed record
    Handle: LongWord;
    Value: Byte;
  end;

  TGuiAddItemParams = packed record
    Handle: LongWord;
    Text: PChar;
  end;

  TGuiListViewColumnParams = packed record
    Handle: LongWord;
    Caption: PChar;
    Width: Integer;
  end;

  TGuiListViewSubItemParams = packed record
    Handle: LongWord;
    ItemIdx, SubIdx: Integer;
    Text: PChar;
  end;

  TGuiMenuItemAddParams = packed record
    Parent, Child: LongWord;
  end;

  TGuiStatusBarSetTextParams = packed record
    Handle: LongWord;
    Index: Integer;
    Text: PChar;
  end;

  TGuiTabControlAddTabParams = packed record
    Handle: LongWord;
    Caption: PChar;
  end;

  TGuiTreeViewAddNodeParams = packed record
    Handle: LongWord;
    ParentIndex: Integer;
    Caption: PChar;
  end;

  TGuiToolBarAddButtonParams = packed record
    Handle: LongWord;
    Caption: PChar;
    Width: Integer;
  end;

  TGuiToolBarSetEnabledParams = packed record
    Handle: LongWord;
    Index: Integer;
    Enabled: Byte;
  end;

    TGuiScrollBarSetPosParams = packed record
    Handle: LongWord;
    Position: Integer;
  end;

  TGuiEditGetTextParams = packed record
    Handle: LongWord;
    Buffer: PChar;
    BufSize: Integer;
  end;


  type
  TBeginThreadParams = packed record
    Entry    : Pointer;      { Thread entry point }
    Param    : Pointer;      { Thread parametresi }
    Name     : PChar;        { Thread ad� }
    Priority : Byte;         { PRIO_* }
    Flags    : Byte;         { TF_* }
  end;
  PBeginThreadParams = ^TBeginThreadParams;


  type
  TKillThreadParams = packed record
    TID: Integer;
  end;
  PKillThreadParams = ^TKillThreadParams;




{===========================================================================}
{  USER-MODE SYSCALL STUB'LARI                                             }
{===========================================================================}

function  BeginThread(Entry: Pointer; Param: Pointer;
                      Name: PChar; Priority: Byte; Flags: Byte): Integer; stdcall;
procedure KillThread(TID: Integer); stdcall;



{ Dialog Functions }
procedure ShowMessageDlg(const Msg: PChar); stdcall;
function  MessageDlgEx(const Msg: PChar; DlgType: Byte; Buttons: LongWord): Integer; stdcall;
function  InputBoxEx(const ACaption, APrompt, ADefault: PChar; 
                     Buffer: PChar; BufSize: Integer): Boolean; stdcall;
function  OpenDlgEx(const Title, StartPath: PChar; 
                    Buffer: PChar; BufSize: Integer): Pointer; stdcall;
function  SaveDlgEx(const Title, StartPath: PChar): Boolean; stdcall;
function  GetDialogResult(FormHandle: Pointer): Integer; stdcall;
function  GetDialogFileName(FormHandle: Pointer; 
                            Buffer: PChar; BufSize: Integer): Integer; stdcall;


{ Bind fonksiyonları }
procedure GuiBindKeyDown   (Handle: LongWord; P: TKeyDownProc);stdcall;
procedure GuiBindKeyUp     (Handle: LongWord; P: TKeyDownProc); stdcall;
procedure GuiBindMouseDown (Handle: LongWord; P: TMouseProc); stdcall;
procedure GuiBindMouseUp   (Handle: LongWord; P: TMouseProc); stdcall;
procedure GuiBindMouseMove (Handle: LongWord; P: TMouseProc); stdcall;
procedure GuiBindPaint     (Handle: LongWord; P: TPaintProc); stdcall;
procedure GuiBindDblClick  (Handle: LongWord; P: TMouseProc); stdcall;
procedure GuiBindDestroy   (Handle: LongWord; P: TDestroyProc); stdcall;
procedure GuiUnbindAll     (Handle: LongWord); stdcall;


function  CreateForm(X, Y, W, H: Integer): Pointer;stdcall;
procedure DestroyForm(FormHandle: LongWord); stdcall;
procedure ExitProcess(ExitCode: LongWord);  stdcall;
function  GetPID: LongWord; stdcall;
procedure GetCmdLine(Buffer: PChar; MaxLen: Integer); stdcall;
function  SysAlloc(Size: LongWord): Pointer; stdcall;
procedure SysFree(P: Pointer);stdcall;

function GetMessage(var Msg:TMessage):Boolean; stdcall;

function GetTickCount():LongWord;  stdcall;



procedure Yield; stdcall;

procedure DispatchMessage(var Msg:TMessage);

var
    MainWndProc : procedure(
        hWnd:HWND;
        Msg:LongWord;
        WParam:LongWord;
        LParam:LongWord);



     

procedure FillRect(X, Y, W, H: Integer; Color: LongWord); stdcall;
procedure LineH(X, Y, W: Integer; Color: LongWord); stdcall;
procedure LineV(X, Y, H: Integer; Color: LongWord); stdcall;


function CreateButton(Parent: LongWord; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
function CreatePanel(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord;  stdcall;
function CreateLabel(Parent: LongWord; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
function CreateEdit(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;

  procedure EditSetText(Handle: LongWord; const AText: PChar); stdcall;
 // procedure DrawInit(out ABuffer: Pointer; out W, H, ABitsPerPixel: Integer); stdcall;


function  FileOpen(const Path: PChar; Mode: Byte): Integer; stdcall;
procedure FileClose(Handle: Integer); stdcall;
function  FileRead(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;  stdcall;
function  FileWrite(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;  stdcall;
function  FileSeek(Handle: Integer; Offset: LongInt; Origin: Byte): LongWord;  stdcall;
function  FileTell(Handle: Integer): LongWord; stdcall;
function  FileGetSize(Handle: Integer): LongWord; stdcall;
function  FileExists(const Path: PChar): Boolean;  stdcall;

{ Dizin İşlemleri }
function  FileMakeDir(const Path: PChar): Boolean; stdcall;
function  FileDelete(const Path: PChar): Boolean;  stdcall;

{ Arama İşlemleri }
function  FileFindFirst(const Path, Pattern: PChar; Attr: Byte;
                        var Rec: TSearchRec): Integer; stdcall;
function  FileFindNext(FindHandle: Integer; var Rec: TSearchRec): Boolean;  stdcall;
procedure FileFindClose(FindHandle: Integer);   stdcall;

{ Sürücü Bilgisi }
function  GetDriveCount: Integer;  stdcall;
function  GetDriveInfo(DriveIndex: Integer; var Info: TDriveInfoOut): Boolean;  stdcall;

{ Yardımcı — Dosya içeriğini tamamen oku (heap'e) }
function  FileReadAll(const Path: PChar; out Buffer: PChar;
                      out Size: LongWord): Boolean;  stdcall;

procedure RepaintForm(Handle: LongWord); stdcall;
procedure DelayMs(MS: LongWord); stdcall;


function  GetStdHandle(nStdHandle: LongWord): LongWord; stdcall;
function  WriteConsole(hOut: LongWord; Buf: PChar; Count: LongWord): LongWord; stdcall;
function  ReadConsole(hIn: LongWord; Buf: PChar; Count: LongWord): LongWord; stdcall;
procedure SetConsoleTextAttribute(hOut: LongWord; Attr: LongWord); stdcall;
procedure PutChar(Ch: Char); stdcall;
procedure ClearScreen; stdcall;

procedure Draw32Cmd(var Cmd: TDraw32Cmd); stdcall;
function GetKernelMemPtr: Pointer; stdcall;

procedure DebugPrint(S: PChar); stdcall;





implementation


{==============================================}
{  EXE tarafi: Syscall Wrapper Fonksiyonlar    }
{==============================================}

function DoSyscall(SysNo: LongWord; var Params): LongWord; stdcall;
var
  P: Pointer;
begin
  P := @Params;          // Record'un ger�ek adresini al
  asm
    push ebx
    mov  eax, SysNo
    mov  ebx, P          // Local de�i�kenin de�erini (record adresi) y�kle
    int  $80
    mov  @Result, eax
    pop  ebx
  end;
end;


procedure DebugPrint(S: PChar); stdcall;
asm
    mov  eax, SYS_DEBUG_PRINT
    mov  ebx, S          // Local de�i�kenin de�erini (record adresi) y�kle
    int  $80
end;


procedure Draw32Cmd(var Cmd: TDraw32Cmd); stdcall;
begin
  DoSyscall(SYS_DRAW32, Cmd);
end;


function GetKernelMemPtr: Pointer; stdcall;
var
  Dummy: Byte;
begin
  Result := Pointer(DoSyscall(SYS_MAP_MEMORY, Dummy));
end;


function GetStdHandle(nStdHandle: LongWord): LongWord; stdcall;
var P: LongWord;
begin
  P := nStdHandle;
  Result := DoSyscall(SYS_GETSTDHANDLE, P);
end;

function WriteConsole(hOut: LongWord; Buf: PChar; Count: LongWord): LongWord; stdcall;
var P: TConsoleWriteParams;
begin
  P.Handle := hOut;
  P.Buffer := Buf;
  P.Count  := Count;
  Result := DoSyscall(SYS_WRITECONSOLE, P);
end;

function ReadConsole(hIn: LongWord; Buf: PChar; Count: LongWord): LongWord; stdcall;
var P: TConsoleReadParams;
begin
  P.Handle := hIn;
  P.Buffer := Buf;
  P.Count  := Count;
  Result := DoSyscall(SYS_READCONSOLE, P);
end;


procedure SetConsoleTextAttribute(hOut: LongWord; Attr: LongWord); stdcall;
asm
  mov  eax, SYS_SET_CONSOLE_ATTR
  mov  ebx, Attr         
  int  $80
end;

procedure PutChar(Ch: Char); stdcall;
var P: Byte;
begin
  P := Byte(Ch);
  DoSyscall(SYS_PUTCHAR, P);
end;

procedure ClearScreen; stdcall;
var P: LongWord;
begin
  DoSyscall(SYS_CLEARSCREEN, P);
end;


procedure RepaintForm(Handle: LongWord); stdcall;
var P: TRepaintParams;
begin
  P.H := Handle;
  DoSyscall(SYS_REPAINT, P);
end;


procedure DelayMs(MS: LongWord); stdcall;
var P: TDelayRec;
begin
  P.MS := MS;
  DoSyscall(SYS_DELAY_MS, P);
end;







{---------------------------------------------------------------------------}
{  BeginThread � Thread olu�tur                                           }
{  EAX = SYS_BEGIN_THREAD, EBX = @TBeginThreadParams                       }
{  D�ner: EAX = Thread ID                                                  }
{---------------------------------------------------------------------------}
function BeginThread(Entry: Pointer; Param: Pointer;
                     Name: PChar; Priority: Byte; Flags: Byte): Integer; stdcall;
var
  P: TBeginThreadParams;
begin
  P.Entry    := Entry;
  P.Param    := Param;
  P.Name     := Name;
  P.Priority := Priority;
  P.Flags    := Flags;

  Result := Integer(DoSyscall(SYS_BEGIN_THREAD, P));
end;

{---------------------------------------------------------------------------}
{  KillThread � Thread �ld�r                                               }
{  EAX = SYS_KILL_THREAD, EBX = @TKillThreadParams                         }
{---------------------------------------------------------------------------}
procedure KillThread(TID: Integer); stdcall;
var
  P: TKillThreadParams;
begin
  P.TID := TID;
  DoSyscall(SYS_KILL_THREAD, P);
end;



{---------------------------------------------------------------------------}
{  ShowMessageDlg � Basit mesaj g�ster                                    }
{---------------------------------------------------------------------------}
procedure ShowMessageDlg(const Msg: PChar); stdcall;
var
  P: TShowMessageParams;
begin
  P.Msg := PChar(Msg);
  DoSyscall(SYS_SHOW_MESSAGE, P);
end;

{---------------------------------------------------------------------------}
{  MessageDlgEx � Dialog tipi ve butonlarla mesaj                          }
{  DlgType: 0=Warning, 1=Error, 2=Information, 3=Confirmation, 4=Custom    }
{  Buttons: Bitmask (0x001=Yes, 0x002=No, 0x004=OK, 0x008=Cancel, ...)    }
{  D�ner: Modal result kodu                                                }
{---------------------------------------------------------------------------}
function MessageDlgEx(const Msg: PChar; DlgType: Byte; Buttons: LongWord): Integer; stdcall;
var
  P: TMessageDlgParams;
begin
  P.Msg := PChar(Msg);
  P.DlgType := DlgType;
  P.Buttons := Buttons;
  Result := Integer(DoSyscall(SYS_MESSAGE_DLG, P));
end;

{---------------------------------------------------------------------------}
{  InputBoxEx � Metin giri�i                                               }
{  ACaption: Dialog ba�l���                                                }
{  APrompt: Soru metni                                                     }
{  ADefault: Varsay�lan metin                                              }
{  Buffer: Sonucu almak i�in buffer                                        }
{  BufSize: Buffer boyutu                                                  }
{  D�ner: True (OK) veya False (Cancel)                                    }
{---------------------------------------------------------------------------}
function InputBoxEx(const ACaption, APrompt, ADefault: PChar; 
                    Buffer: PChar; BufSize: Integer): Boolean; stdcall;
var
  P: TInputBoxParams;
begin
  P.Caption := PChar(ACaption);
  P.Prompt := PChar(APrompt);
  P.Default := PChar(ADefault);
  P.ResultBuffer := Buffer;
  P.BufferSize := BufSize;
  Result := DoSyscall(SYS_INPUT_BOX, P) <> 0;
end;

{---------------------------------------------------------------------------}
{  OpenDlgEx � Dosya a� diyalo�u                                           }
{  D�ner: Form handle veya nil                                             }
{---------------------------------------------------------------------------}
function OpenDlgEx(const Title, StartPath: PChar; 
                   Buffer: PChar; BufSize: Integer): Pointer; stdcall;
var
  P: TOpenDlgParams;
begin
  P.Title := PChar(Title);
  P.StartPath := PChar(StartPath);
  P.ResultBuffer := Buffer;
  P.BufferSize := BufSize;
  Result := Pointer(DoSyscall(SYS_OPEN_DLG, P));
end;

{---------------------------------------------------------------------------}
{  SaveDlgEx � Dosya kaydet diyalo�u                                       }
{  D�ner: True (Kaydet) veya False (�ptal)                                 }
{---------------------------------------------------------------------------}
function SaveDlgEx(const Title, StartPath: PChar): Boolean;stdcall;
var
  P: TSaveDlgParams;
begin
  P.Title := PChar(Title);
  P.StartPath := PChar(StartPath);
  P.ResultBuffer := nil;
  P.BufferSize := 0;
  Result := DoSyscall(SYS_SAVE_DLG, P) <> 0;
end;

{---------------------------------------------------------------------------}
{  GetDialogResult � Dialog sonucunu al                                    }
{  D�ner: Modal result kodu                                                }
{---------------------------------------------------------------------------}
function GetDialogResult(FormHandle: Pointer): Integer;  stdcall;
var
  P: TGetDlgResultParams;
begin
  P.FormHandle := LongWord(FormHandle);
  Result := Integer(DoSyscall(SYS_GET_DLG_RESULT, P));
end;

{---------------------------------------------------------------------------}
{  GetDialogFileName � Dialog'dan se�ilen dosya ad�n� al                   }
{  D�ner: Dosya ad� uzunlu�u                                               }
{---------------------------------------------------------------------------}
function GetDialogFileName(FormHandle: Pointer; 
                           Buffer: PChar; BufSize: Integer): Integer;  stdcall;
var
  P: TGetDlgFileNameParams;
begin
  P.FormHandle := LongWord(FormHandle);
  P.Buffer := Buffer;
  P.BufSize := BufSize;
  Result := Integer(DoSyscall(SYS_GET_DLG_FILENAME, P));
end;


procedure GuiBindKeyDown(Handle: LongWord; P: TKeyDownProc); stdcall;
var Params: TBindEventParams;
begin
  Params.Handle := Handle;
  Params.Proc   := @P;
  DoSyscall(SYS_BIND_KEYDOWN, Params);
end;

procedure GuiBindKeyUp(Handle: LongWord; P: TKeyDownProc);  stdcall;
var Params: TBindEventParams;
begin
  Params.Handle := Handle;
  Params.Proc   := @P;
  DoSyscall(SYS_BIND_KEYUP, Params);
end;

procedure GuiBindMouseDown(Handle: LongWord; P: TMouseProc); stdcall;
var Params: TBindEventParams;
begin
  Params.Handle := Handle;
  Params.Proc   := @P;
  DoSyscall(SYS_BIND_MOUSEDOWN, Params);
end;

procedure GuiBindMouseUp(Handle: LongWord; P: TMouseProc); stdcall;
var Params: TBindEventParams;
begin
  Params.Handle := Handle;
  Params.Proc   := @P;
  DoSyscall(SYS_BIND_MOUSEUP, Params);
end;

procedure GuiBindMouseMove(Handle: LongWord; P: TMouseProc); stdcall;
var Params: TBindEventParams;
begin
  Params.Handle := Handle;
  Params.Proc   := @P;
  DoSyscall(SYS_BIND_MOUSEMOVE, Params);
end;

procedure GuiBindPaint(Handle: LongWord; P: TPaintProc);  stdcall;
var Params: TBindEventParams;
begin
  Params.Handle := Handle;
  Params.Proc   := @P;
  DoSyscall(SYS_BIND_PAINT, Params);
end;

procedure GuiBindDblClick(Handle: LongWord; P: TMouseProc); stdcall;
var Params: TBindEventParams;
begin
  Params.Handle := Handle;
  Params.Proc   := @P;
  DoSyscall(SYS_BIND_DBLCLICK, Params);
end;

procedure GuiBindDestroy(Handle: LongWord; P: TDestroyProc);stdcall;
var Params: TBindEventParams;
begin
  Params.Handle := Handle;
  Params.Proc   := @P;
  DoSyscall(SYS_BIND_DESTROY, Params);
end;

procedure GuiUnbindAll(Handle: LongWord);  stdcall;
var Params: TBindEventParams;
begin
  Params.Handle := Handle;
  Params.Proc   := nil;
  DoSyscall(SYS_UNBIND_ALL, Params);
end;


function FileOpen(const Path: PChar; Mode: Byte): Integer; stdcall;
var
  P: TFileOpenParams;
begin
  P.Path := Path;
  P.Mode := Mode;
  Result := Integer(DoSyscall(SYS_FILE_OPEN, P));
end;

procedure FileClose(Handle: Integer);stdcall;
var
  P: TFileHandleParams;
begin
  P.Handle := Handle;
  DoSyscall(SYS_FILE_CLOSE, P);
end;

function FileRead(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord;stdcall;
var
  P: TFileRWParams;
begin
  P.Handle := Handle;
  P.Buffer := Buffer;
  P.Size   := Size;
  Result := DoSyscall(SYS_FILE_READ, P);
end;

function FileWrite(Handle: Integer; Buffer: Pointer; Size: LongWord): LongWord; stdcall;
var
  P: TFileRWParams;
begin
  P.Handle := Handle;
  P.Buffer := Buffer;
  P.Size   := Size;
  Result := DoSyscall(SYS_FILE_WRITE, P);
end;

function FileSeek(Handle: Integer; Offset: LongInt; Origin: Byte): LongWord; stdcall;
var
  P: TFileSeekParams;
begin
  P.Handle := Handle;
  P.Offset := Offset;
  P.Origin := Origin;
  Result := DoSyscall(SYS_FILE_SEEK, P);
end;

function FileTell(Handle: Integer): LongWord; stdcall;
var
  P: TFileHandleParams;
begin
  P.Handle := Handle;
  Result := DoSyscall(SYS_FILE_POS, P);
end;

function FileGetSize(Handle: Integer): LongWord; stdcall;
var
  P: TFileHandleParams;
begin
  P.Handle := Handle;
  Result := DoSyscall(SYS_FILE_SIZE, P);
end;

function FileExists(const Path: PChar): Boolean;stdcall;
var
  P: TFilePathParams;
begin
  P.Path := Path;
  Result := DoSyscall(SYS_FILE_EXISTS, P) <> 0;
end;

function FileMakeDir(const Path: PChar): Boolean; stdcall;
var
  P: TFilePathParams;
begin
  P.Path := Path;
  Result := DoSyscall(SYS_FILE_MKDIR, P) <> 0;
end;

function FileDelete(const Path: PChar): Boolean; stdcall;
var
  P: TFilePathParams;
begin
  P.Path := Path;
  Result := DoSyscall(SYS_FILE_DELETE, P) <> 0;
end;

function FileFindFirst(const Path, Pattern: PChar; Attr: Byte;
                       var Rec: TSearchRec): Integer; stdcall;
var
  P: TFileFindFirstParams;
begin
  P.Path      := Path;
  P.Pattern   := Pattern;
  P.Attr      := Attr;
  P.SearchRec := @Rec;
  Result := Integer(DoSyscall(SYS_FILE_FINDFIRST, P));
end;

function FileFindNext(FindHandle: Integer; var Rec: TSearchRec): Boolean;stdcall;
var
  P: TFileFindNextParams;
begin
  P.FindHandle := FindHandle;
  P.SearchRec  := @Rec;
  Result := DoSyscall(SYS_FILE_FINDNEXT, P) <> 0;
end;

procedure FileFindClose(FindHandle: Integer); stdcall;
var
  P: TFileHandleParams;
begin
  P.Handle := FindHandle;
  DoSyscall(SYS_FILE_FINDCLOSE, P);
end;

function GetDriveCount: Integer; stdcall;
var
  P: TFileHandleParams;   { dummy — handle alanı kullanılmaz }
begin
  P.Handle := 0;
  Result := Integer(DoSyscall(SYS_DRIVE_COUNT, P));
end;

function GetDriveInfo(DriveIndex: Integer; var Info: TDriveInfoOut): Boolean;  stdcall;
var
  P: TDriveInfoParams;
begin
  P.DriveIndex := DriveIndex;
  P.InfoOut    := @Info;
  Result := DoSyscall(SYS_DRIVE_INFO, P) <> 0;
end;

{ ── Yardımcı: Dosyayı tamamen belleğe oku ── }
function FileReadAll(const Path: PChar; out Buffer: PChar;
                     out Size: LongWord): Boolean; stdcall;
var
  H: Integer;
begin
  Result := False;
  Buffer := nil;
  Size   := 0;

  H := FileOpen(Path, FILE_READ);
  if H = INVALID_HANDLE then Exit;

  Size := FileGetSize(H);
  if Size = 0 then
  begin
    FileClose(H);
    Exit;
  end;

  { Bellek ayır (SysAlloc — UserGUI'de zaten var) }
  Buffer := SysAlloc(Size + 1);
  if Buffer = nil then
  begin
    FileClose(H);
    Size := 0;
    Exit;
  end;

  if FileRead(H, Buffer, Size) = Size then
  begin
    Buffer[Size] := #0;   { Null-terminate et }
    Result := True;
  end
  else
  begin
    SysFree(Buffer);
    Buffer := nil;
    Size   := 0;
  end;

  FileClose(H);
end;





{ --- Factory: Create --- }
function CreatePanel(Parent: LongWord; ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord;  stdcall;
var P: TCreatePanelParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($100, P);
end;

function CreateButton(Parent: LongWord; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateButtonParams;
begin
  P.Parent := Parent; P.Caption := ACaption; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($101, P);
end;

function CreateLabel(Parent: LongWord; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord;  stdcall;
var P: TCreateLabelParams;
begin
  P.Parent := Parent; P.Caption := ACaption; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($102, P);
end;

function CreateEdit(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateEditParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($103, P);
end;

function CreateMemo(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateMemoParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($104, P);
end;

function CreateComboBox(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateComboBoxParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($105, P);
end;

function CreateListBox(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateListBoxParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($106, P);
end;

function CreateCheckBox(Parent: LongWord; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateCheckBoxParams;
begin
  P.Parent := Parent; P.Caption := ACaption; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($107, P);
end;

function CreateRadioButton(Parent: LongWord; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateRadioButtonParams;
begin
  P.Parent := Parent; P.Caption := ACaption; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($108, P);
end;

function CreateGroupBox(Parent: LongWord; const ACaption: PChar;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateGroupBoxParams;
begin
  P.Parent := Parent; P.Caption := ACaption; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($109, P);
end;

function CreateProgressBar(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateProgressBarParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($10A, P);
end;

function CreateTrackBar(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateTrackBarParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($10B, P);
end;

function CreateImage(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateImageParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($10C, P);
end;

function CreateSplitter(Parent: LongWord; ALeft, ATop, ASize: Integer;
  AHorizontal: Byte; AAlign: Byte): LongWord; stdcall;
var P: TCreateSplitterParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Size := ASize; P.Horizontal := AHorizontal; P.Align := AAlign;
  Result := DoSyscall($10D, P);
end;

function CreateStatusBar(Parent: LongWord; ALeft, ATop, AWidth: Integer;
  AAlign: Byte): LongWord; stdcall;
var P: TCreateStatusBarParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Align := AAlign;
  Result := DoSyscall($10E, P);
end;

function CreateMenuItem(const ACaption: PChar): LongWord; stdcall;
var P: TCreateMenuItemParams;
begin
  P.Caption := ACaption;
  Result := DoSyscall($10F, P);
end;

function CreateMenuBar(Parent: LongWord; ALeft, ATop, AWidth: Integer;
  AAlign: Byte): LongWord; stdcall;
var P: TCreateMenuBarParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Align := AAlign;
  Result := DoSyscall($110, P);
end;

function CreateListView(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateListViewParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($111, P);
end;

function CreateTabControl(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateTabControlParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($112, P);
end;

function CreateTreeView(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateTreeViewParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($113, P);
end;

function CreateSplitterPanel(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AOrientation: Byte; AAlign: Byte): LongWord; stdcall;
var P: TCreateSplitterPanelParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight;
  P.Orientation := AOrientation; P.Align := AAlign;
  Result := DoSyscall($114, P);
end;

function CreateToolBar(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateToolBarParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($115, P);
end;

function CreateScrollBar(Parent: LongWord;
  ALeft, ATop, AWidth, AHeight: Integer; AAlign: Byte): LongWord; stdcall;
var P: TCreateScrollBarParams;
begin
  P.Parent := Parent; P.Left := ALeft; P.Top := ATop;
  P.Width := AWidth; P.Height := AHeight; P.Align := AAlign;
  Result := DoSyscall($116, P);
end;

{ --- Helper Wrappers --- }
procedure EditSetText(Handle: LongWord; const AText: PChar); stdcall;
var P: TGuiSetTextParams;
begin
  P.Handle := Handle;
  P.Text := PChar(AText);
  DoSyscall($120, P);
end;

procedure EditGetText(Handle: LongWord; Buffer: PChar; BufSize: Integer); stdcall;
var P: TGuiEditGetTextParams;
begin
  P.Handle := Handle; P.Buffer := Buffer; P.BufSize := BufSize;
  DoSyscall($121, P);
end;

procedure MemoSetText(Handle: LongWord; const AText: PChar); stdcall;
var P: TGuiSetTextParams;
begin
  P.Handle := Handle; P.Text := PChar(AText);
  DoSyscall($122, P);
end;

procedure ComboBoxAddItem(Handle: LongWord; const AText: PChar); stdcall;
var P: TGuiAddItemParams;
begin
  P.Handle := Handle; P.Text := PChar(AText);
  DoSyscall($123, P);
end;

procedure ComboBoxClear(Handle: LongWord); stdcall;
var P: TGuiHandleParams;
begin
  P.Handle := Handle;
  DoSyscall($124, P);
end;

procedure ListBoxAddItem(Handle: LongWord; const AText: PChar); stdcall;
var P: TGuiAddItemParams;
begin
  P.Handle := Handle; P.Text := PChar(AText);
  DoSyscall($125, P);
end;

procedure ListBoxClear(Handle: LongWord); stdcall;
var P: TGuiHandleParams;
begin
  P.Handle := Handle;
  DoSyscall($126, P);
end;

procedure StatusBarSetText(Handle: LongWord; Index: Integer; const AText: PChar); stdcall;
var P: TGuiStatusBarSetTextParams;
begin
  P.Handle := Handle; P.Index := Index; P.Text := PChar(AText);
  DoSyscall($127, P);
end;

procedure MenuItemAddSubItem(Parent, Child: LongWord); stdcall;
var P: TGuiMenuItemAddParams;
begin
  P.Parent := Parent; P.Child := Child;
  DoSyscall($128, P);
end;

procedure MenuBarAddItem(MenuBar, Item: LongWord); stdcall;
var P: TGuiMenuItemAddParams;
begin
  P.Parent := MenuBar; P.Child := Item;
  DoSyscall($129, P);
end;

procedure ListViewAddColumn(Handle: LongWord; const ACaption: PChar; AWidth: Integer); stdcall;
var P: TGuiListViewColumnParams;
begin
  P.Handle := Handle; P.Caption := PChar(ACaption); P.Width := AWidth;
  DoSyscall($12A, P);
end;

function ListViewAddItem(Handle: LongWord; const ACaption: PChar): Integer; stdcall;
var P: TGuiAddItemParams;
begin
  P.Handle := Handle; P.Text := PChar(ACaption);
  Result := Integer(DoSyscall($12B, P));
end;

procedure ListViewSetSubItem(Handle: LongWord; ItemIdx, SubIdx: Integer; const AText: PChar); stdcall;
var P: TGuiListViewSubItemParams;
begin
  P.Handle := Handle; P.ItemIdx := ItemIdx; P.SubIdx := SubIdx; P.Text := PChar(AText);
  DoSyscall($12C, P);
end;

procedure ListViewClear(Handle: LongWord); stdcall;
var P: TGuiHandleParams;
begin
  P.Handle := Handle;
  DoSyscall($12D, P);
end;

procedure ListViewSetViewStyle(Handle: LongWord; AStyle: Byte); stdcall;
var P: TGuiSetIntParams;
begin
  P.Handle := Handle; P.Value := AStyle;
  DoSyscall($12E, P);
end;

function TabControlAddTab(Handle: LongWord; const ACaption: PChar): LongWord; stdcall;
var P: TGuiTabControlAddTabParams;
begin
  P.Handle := Handle; P.Caption := PChar(ACaption);
  Result := DoSyscall($12F, P);
end;

procedure TabControlSetActive(Handle: LongWord; Index: Integer); stdcall;
var P: TGuiSetIntParams;
begin
  P.Handle := Handle; P.Value := Index;
  DoSyscall($130, P);
end;

function TreeViewAddNode(Handle: LongWord; AParentIndex: Integer; const ACaption: PChar): Integer; stdcall;
var P: TGuiTreeViewAddNodeParams;
begin
  P.Handle := Handle; P.ParentIndex := AParentIndex; P.Caption := PChar(ACaption);
  Result := Integer(DoSyscall($131, P));
end;

procedure TreeViewClear(Handle: LongWord); stdcall;
var P: TGuiHandleParams;
begin
  P.Handle := Handle;
  DoSyscall($132, P);
end;

procedure TreeViewExpand(Handle: LongWord; Index: Integer; AExpand: Boolean); stdcall;
var P: TGuiSetBoolParams;
begin
  P.Handle := Handle; P.Value := Ord(AExpand);
  { Index'i Value olarak kullanmak icin farkli bir record gerekir,
    ama kernel tarafinda TGuiSetBoolParams yerine farkli okuma yapiliyor.
    Basit tutalim: kernel handler'da duzeltme yapilabilir. }
  DoSyscall($133, P);
end;

function TreeViewGetSelectedText(Handle: LongWord): PChar; stdcall;
var P: TGuiHandleParams;
begin
  P.Handle := Handle;
  Result := PChar(DoSyscall($134, P));
end;

function ToolBarAddButton(Handle: LongWord; const ACaption: PChar; AWidth: Integer): Integer; stdcall;
var P: TGuiToolBarAddButtonParams;
begin
  P.Handle := Handle; P.Caption := PChar(ACaption); P.Width := AWidth;
  Result := Integer(DoSyscall($135, P));
end;

procedure ToolBarAddSeparator(Handle: LongWord); stdcall;
var P: TGuiHandleParams;
begin
  P.Handle := Handle;
  DoSyscall($136, P);
end;

procedure ToolBarClear(Handle: LongWord); stdcall;
var P: TGuiHandleParams;
begin
  P.Handle := Handle;
  DoSyscall($137, P);
end;

procedure ToolBarSetButtonEnabled(Handle: LongWord; Index: Integer; AEnabled: Boolean); stdcall;
var P: TGuiToolBarSetEnabledParams;
begin
  P.Handle := Handle; P.Index := Index; P.Enabled := Ord(AEnabled);
  DoSyscall($138, P);
end;

procedure ScrollBarSetPosition(Handle: LongWord; APos: Integer); stdcall;
var P: TGuiScrollBarSetPosParams;
begin
  P.Handle := Handle; P.Position := APos;
  DoSyscall($139, P);
end;

{ --- Generic Property Wrappers --- }
procedure GuiSetLeft(Handle: LongWord; Value: Integer); stdcall;
var P: TGuiSetIntParams;
begin P.Handle := Handle; P.Value := Value; DoSyscall($140, P); end;

procedure GuiSetTop(Handle: LongWord; Value: Integer); stdcall;
var P: TGuiSetIntParams;
begin P.Handle := Handle; P.Value := Value; DoSyscall($141, P); end;

procedure GuiSetWidth(Handle: LongWord; Value: Integer); stdcall;
var P: TGuiSetIntParams;
begin P.Handle := Handle; P.Value := Value; DoSyscall($142, P); end;

procedure GuiSetHeight(Handle: LongWord; Value: Integer); stdcall;
var P: TGuiSetIntParams;
begin P.Handle := Handle; P.Value := Value; DoSyscall($143, P); end;

procedure GuiSetColor(Handle: LongWord; Value: LongWord); stdcall;
var P: TGuiSetIntParams;
begin P.Handle := Handle; P.Value := Integer(Value); DoSyscall($144, P); end;

procedure GuiSetVisible(Handle: LongWord; Value: Boolean); stdcall;
var P: TGuiSetBoolParams;
begin P.Handle := Handle; P.Value := Ord(Value); DoSyscall($145, P); end;

procedure GuiSetEnabled(Handle: LongWord; Value: Boolean); stdcall;
var P: TGuiSetBoolParams;
begin P.Handle := Handle; P.Value := Ord(Value); DoSyscall($146, P); end;

procedure GuiSetCaption(Handle: LongWord; const Value: PChar); stdcall;
var P: TGuiSetTextParams;
begin P.Handle := Handle; P.Text := PChar(Value); DoSyscall($147, P); end;

procedure GuiSetText(Handle: LongWord; const Value: PChar); stdcall;
var P: TGuiSetTextParams;
begin P.Handle := Handle; P.Text := PChar(Value); DoSyscall($148, P); end;

function GuiGetText(Handle: LongWord; Buffer: PChar; BufSize: Integer): Integer; stdcall;
var P: TGuiGetTextParams;
begin P.Handle := Handle; P.Buffer := Buffer; P.BufSize := BufSize;
  Result := Integer(DoSyscall($149, P)); end;

procedure GuiSetChecked(Handle: LongWord; Value: Boolean); stdcall;
var P: TGuiSetBoolParams;
begin P.Handle := Handle; P.Value := Ord(Value); DoSyscall($14A, P); end;

function GuiGetChecked(Handle: LongWord): Boolean; stdcall;
var P: TGuiHandleParams;
begin P.Handle := Handle; Result := DoSyscall($14B, P) <> 0; end;

procedure GuiSetPosition(Handle: LongWord; Value: Integer); stdcall;
var P: TGuiSetIntParams;
begin P.Handle := Handle; P.Value := Value; DoSyscall($14C, P); end;

function GuiGetPosition(Handle: LongWord): Integer; stdcall;
var P: TGuiHandleParams;
begin P.Handle := Handle; Result := Integer(DoSyscall($14D, P)); end;

procedure GuiSetItemIndex(Handle: LongWord; Value: Integer); stdcall;
var P: TGuiSetIntParams;
begin P.Handle := Handle; P.Value := Value; DoSyscall($14E, P); end;

function GuiGetItemIndex(Handle: LongWord): Integer; stdcall;
var P: TGuiHandleParams;
begin P.Handle := Handle; Result := Integer(DoSyscall($14F, P)); end;

function GuiGetItemCount(Handle: LongWord): Integer; stdcall;
var P: TGuiHandleParams;
begin P.Handle := Handle; Result := Integer(DoSyscall($150, P)); end;

procedure GuiDestroyObject(Handle: LongWord); stdcall;
var P: TGuiHandleParams;
begin P.Handle := Handle; DoSyscall($151, P); end;


procedure FillRect(X, Y, W, H: Integer; Color: LongWord); stdcall;
asm
  mov eax, SYS_FILL_RECT
  mov ebx, X
  mov ecx, Y
  mov edx, W
  mov esi, H
  mov edi, Color
  int $80
end;

procedure LineH(X, Y, W: Integer; Color: LongWord); stdcall;
asm
  mov eax, SYS_LINE_H
  mov ebx, X
  mov ecx, Y
  mov edx, W
  mov esi, Color
  int $80
end;

procedure LineV(X, Y, H: Integer; Color: LongWord); stdcall;
asm
  mov eax, SYS_LINE_V
  mov ebx, X
  mov ecx, Y
  mov edx, H
  mov esi, Color
  int $80
end;


procedure Yield; stdcall;
asm
  mov eax, SYS_GET_YIELD
  int $80
end;


procedure DispatchMessage(var Msg:TMessage);
begin
    if Assigned(MainWndProc) then
        MainWndProc(
            Msg.hWnd,
            Msg.Msg,
            Msg.WParam,
            Msg.LParam);
end;


function GetMessage(var Msg:TMessage):Boolean; stdcall;
asm
    mov eax,SYS_GET_MESSAGE
    mov ebx,Msg
    int $80
end;



{---------------------------------------------------------------------------}
{  CreateForm — Process bağlantılı!                                        }
{  EAX=1, EBX=WndProc, ECX=X, EDX=Y, ESI=W, EDI=H                         }
{  Dönüş: EAX = FormHandle                                                }
{---------------------------------------------------------------------------}
function CreateForm(X, Y, W, H: Integer): Pointer; stdcall;
asm
  mov eax, SYS_CREATE_FORM
  mov ebx, X
  mov ecx, Y
  mov edx, W
  mov esi, H
  int $80
  // EAX = FormHandle (kernel'den dönen)
end;

{---------------------------------------------------------------------------}
{  DestroyForm                                                             }
{  EAX=2, EBX=FormHandle                                                   }
{---------------------------------------------------------------------------}
procedure DestroyForm(FormHandle: LongWord); stdcall;
asm
  mov eax, SYS_DESTROY_FORM
  mov ebx, FormHandle
  int $80
end;

{---------------------------------------------------------------------------}
{  ExitProcess                                                             }
{---------------------------------------------------------------------------}
procedure ExitProcess(ExitCode: LongWord); stdcall;
asm
  mov eax, SYS_EXIT_PROCESS
  mov ebx, ExitCode
  int $80
@hang:
  jmp @hang
end;

{---------------------------------------------------------------------------}
{  GetPID                                                                  }
{---------------------------------------------------------------------------}
function GetPID: LongWord; stdcall;
asm
  mov eax, SYS_GET_PID
  int $80
end;

{---------------------------------------------------------------------------}
{  GetCmdLine                                                              }
{---------------------------------------------------------------------------}
procedure GetCmdLine(Buffer: PChar; MaxLen: Integer); stdcall;
asm
  mov eax, SYS_GET_CMDLINE
  mov ebx, Buffer
  mov ecx, MaxLen
  int $80
end;

{---------------------------------------------------------------------------}
{  Bellek                                                                  }
{---------------------------------------------------------------------------}
function SysAlloc(Size: LongWord): Pointer;stdcall;
asm
  mov eax, SYS_ALLOC
  mov ebx, Size
  int $80
end;

procedure SysFree(P: Pointer); stdcall;
asm
  mov eax, SYS_FREE
  mov ebx, P
  int $80
end;

function GetTickCount():LongWord;  stdcall;
asm
  mov eax, SYS_GETTICKCOUNT
  int $80
end;

end.
